﻿using System.Configuration;
using System.Linq;

namespace GreaterGiving.Tokyo.CrossCutting.Configuration
{
    public static class ConfigManager
    {
        #region Private Fields & Constants

        private const string BIDDING_DB_CONNECTION_STRING_KEY = "BiddingDBContext";

        private const string CDN_PROJECT_ASSETS_ENDPOINT_KEY = "CdnProjectAssetsEndpoint";
        private const string STORAGE_CONNECTION_STRING_KEY = "StorageConnectionString";
        private const string SEND_GRID_API_KEY = "SendGridAPIKey";
        private const string SERVICE_BUS_ENDPOINT_KEY = "ServiceBusEndpoint";
        private const string AES_CRYPTOGRAPHY_PWD_KEY = "AESPassword";
        private const string AES_CRYPTOGRAPHY_SALT_KEY = "AESSalt";

        private const string CERTIFICATE_THUMBPRINT_KEY = "CertificateThumbprint";
        private const string ALLOWED_ORIGINS_LIST_KEY = "AllowedOriginsList";

        private const string TWILIO_ACCOUNT_SID = "TwilioAccountSid";
        private const string TWILIO_AUTH_TOKEN = "TwilioAuthToken";
        private const string TWILIO_FROM_SHORT_CODE = "TwilioFromShortCode";
        private const string SMS_MESSAGE_FORMAT = "SMSMessageFormat";
        private const string DIRECT_ACCESS_URL = "DirectAccessURL";
        private const string SALE_SERVICE_URL = "SaleServiceURL";
        private const string SALE_USERNAME = "SaleUserName";
        private const string SALE_PASSWORD = "SalePassword";
        private const string SALE_PARTNERID = "SalePartnerID";
        private const string EMAIL_FROM_ADDRESS = "EmailFromAddress";
        private const string OUTBID_EMAIL_SUBJECT = "OutbidEmailSubject";
        private const string ADD_DAYS_FOR_PACKAGE_START_TIME = "AddDaysForPackageStartTime";
        private const string APP_TOKEN_KEY = "AppTokenKey";
        private const string EMAIL_MESSAGE_FORMAT = "EmailMessageFormat";
        private const string BIDDING_URL = "BiddingURL";
        private const string SMSBODYMAXLENGTH = "SMSBodyMaxLength";
        private const string EMAILSUBJECTMAXLENGTH = "EmailSubjectMaxLength";
        private const string TWILIO_HELP_MESSAGE = "TwilioHelpMessage";
        private const string TWILIO_STOP_MESSAGE = "TwilioStopMessage";
        private const string IDENTITY_BASE_URL = "IdentityBaseURL";
        private const string BIDDING_BASE_URL = "BiddingBaseURL";
        private const string ADMIN_BASE_URL = "AdminBaseURL";
        private const string ERROR_PAGE_URL = "ErrorPageURL";
        private const string PBI_USERNAME = "pbiUserName";
        private const string PBI_PASSWORD = "pbiPassword";
        private const string PBI_AUTHORITY_URL = "authorityUrl";
        private const string PBI_RESOURCE_URL = "resourceUrl";
        private const string PBI_CLIENTID = "clientId";
        private const string PBI_API_URL = "apiUrl";
        private const string PBI_GROUPID = "groupId";
        private const string PBI_REPORTID = "reportId";

        private static readonly string _biddingDatabaseConnectionString;
        private static readonly string _cdnProjectAssetsEndpoint;
        private static readonly string _storageConnectionString;
        private static readonly string _allowedOriginsList;
        private static readonly string _sendGridAPIKey;
        private static readonly string _serviceBusEndpoint;
        private static readonly string _aesPassword;
        private static readonly string _aesSalt;
        private static readonly string _certificateThumbprint;

        private static readonly string _twilioAccountSid;
        private static readonly string _twilioAuthToken;
        private static readonly string _twilioFromShortCode;
        private static readonly string _smsMessageFormat;
        private static readonly string _directAccessURL;
        private static readonly string _saleServiceURL;
        private static readonly string _saleUserName;
        private static readonly string _salePassword;
        private static readonly string _salePartnerId;
        private static readonly string _emailFromAddress;
        private static readonly string _outbidEmailSubject;
        private static readonly string _addDaysForPackageStartTime;
        private static readonly string _appTokenKey;
        private static readonly string _emailMessageFormat;
        private static readonly string _biddingURL;
        private static readonly string _smsBodyMaxLength;
        private static readonly string _emailSubjectMaxLength;
        private static readonly string _twilioHelpMessage;
        private static readonly string _twilioStopMessage;
        private static readonly string _identityBaseURL;
        private static readonly string _biddingBaseURL;
        private static readonly string _adminBaseURL;
        private static readonly string _errorPageURL;
        private static readonly string _pbiUserName;
        private static readonly string _pbiPassword;
        private static readonly string _pbiAuthorityUrl;
        private static readonly string _pbiResourceUrl;
        private static readonly string _pbiClientId;
        private static readonly string _pbiApiUrl;
        private static readonly string _pbiGroupId;
        private static readonly string _pbiReportId;

        #endregion Private Fields & Constants

        #region Constructors

        static ConfigManager()
        {
            // Read from config and populate the read-only fields
            // (pertaining to appSettings and connectionStrings)

            _biddingDatabaseConnectionString = ConfigHelper.GetConnectionString(BIDDING_DB_CONNECTION_STRING_KEY);

            _storageConnectionString = ConfigHelper.GetConfigValue(STORAGE_CONNECTION_STRING_KEY);
            _cdnProjectAssetsEndpoint = ConfigHelper.GetConfigValue(CDN_PROJECT_ASSETS_ENDPOINT_KEY);

            _allowedOriginsList = ConfigHelper.GetConfigValue(ALLOWED_ORIGINS_LIST_KEY);

            _certificateThumbprint = ConfigHelper.GetConfigValue(CERTIFICATE_THUMBPRINT_KEY);

            _sendGridAPIKey = ConfigHelper.GetConfigValue(SEND_GRID_API_KEY);
            _serviceBusEndpoint = ConfigHelper.GetConfigValue(SERVICE_BUS_ENDPOINT_KEY);
            _twilioAccountSid = ConfigHelper.GetConfigValue(TWILIO_ACCOUNT_SID);
            _twilioAuthToken = ConfigHelper.GetConfigValue(TWILIO_AUTH_TOKEN);
            _twilioFromShortCode = ConfigHelper.GetConfigValue(TWILIO_FROM_SHORT_CODE);
            _smsMessageFormat = ConfigHelper.GetConfigValue(SMS_MESSAGE_FORMAT);
            _directAccessURL = ConfigHelper.GetConfigValue(DIRECT_ACCESS_URL);
            _aesPassword = ConfigHelper.GetConfigValue(AES_CRYPTOGRAPHY_PWD_KEY);
            _aesSalt = ConfigHelper.GetConfigValue(AES_CRYPTOGRAPHY_SALT_KEY);
            _saleServiceURL = ConfigHelper.GetConfigValue(SALE_SERVICE_URL);
            _saleUserName = ConfigHelper.GetConfigValue(SALE_USERNAME);
            _salePassword = ConfigHelper.GetConfigValue(SALE_PASSWORD);
            _salePartnerId = ConfigHelper.GetConfigValue(SALE_PARTNERID);
            _emailFromAddress = ConfigHelper.GetConfigValue(EMAIL_FROM_ADDRESS);
            _outbidEmailSubject = ConfigHelper.GetConfigValue(OUTBID_EMAIL_SUBJECT);
            _addDaysForPackageStartTime = ConfigHelper.GetConfigValue(ADD_DAYS_FOR_PACKAGE_START_TIME);
            _emailMessageFormat = ConfigHelper.GetConfigValue(EMAIL_MESSAGE_FORMAT);
            _biddingURL = ConfigHelper.GetConfigValue(BIDDING_URL);
            _appTokenKey = ConfigHelper.GetConfigValue(APP_TOKEN_KEY);

            _smsBodyMaxLength = ConfigHelper.GetConfigValue(SMSBODYMAXLENGTH);
            _emailSubjectMaxLength = ConfigHelper.GetConfigValue(EMAILSUBJECTMAXLENGTH);
            _twilioHelpMessage = ConfigHelper.GetConfigValue(TWILIO_HELP_MESSAGE);
            _twilioStopMessage = ConfigHelper.GetConfigValue(TWILIO_STOP_MESSAGE);
            _identityBaseURL = ConfigHelper.GetConfigValue(IDENTITY_BASE_URL);
            _biddingBaseURL = ConfigHelper.GetConfigValue(BIDDING_BASE_URL);
            _adminBaseURL = ConfigHelper.GetConfigValue(ADMIN_BASE_URL);
            _errorPageURL = ConfigHelper.GetConfigValue(ERROR_PAGE_URL);
            _pbiUserName = ConfigHelper.GetConfigValue(PBI_USERNAME);
            _pbiPassword = ConfigHelper.GetConfigValue(PBI_PASSWORD);
            _pbiAuthorityUrl = ConfigHelper.GetConfigValue(PBI_AUTHORITY_URL);
            _pbiResourceUrl = ConfigHelper.GetConfigValue(PBI_RESOURCE_URL);
            _pbiClientId = ConfigHelper.GetConfigValue(PBI_CLIENTID);
            _pbiApiUrl = ConfigHelper.GetConfigValue(PBI_API_URL);
            _pbiGroupId = ConfigHelper.GetConfigValue(PBI_GROUPID);
            _pbiReportId = ConfigHelper.GetConfigValue(PBI_REPORTID);
        }

        #endregion Constructors

        #region Properties
                
        public static string BiddingConnectionString
        {
            get { return _biddingDatabaseConnectionString; }
        }

        public static string StorageConnectionString
        {
            get { return _storageConnectionString; }
        }

        public static string CdnProjectAssetsEndpoint
        {
            get { return _cdnProjectAssetsEndpoint; }
        }

        public static string SendGridAPIKey
        {
            get { return _sendGridAPIKey; }
        }

        public static string ServiceBusEndpoint
        {
            get { return _serviceBusEndpoint; }
        }

        public static string AESPassword
        {
            get { return _aesPassword; }
        }

        public static string AESSalt
        {
            get { return _aesSalt; }
        }

        public static string RedisHostAddress
        {
            get { return "localhost:6379"; }
        }

        public static string CertificateThumbprint
        {
            get { return _certificateThumbprint; }
        }

        public static string AllowedOriginsList
        {
            get { return _allowedOriginsList; }
        }

        public static string TwilioAccountSid
        {
            get { return _twilioAccountSid; }
        }

        public static string TwilioAuthToken
        {
            get { return _twilioAuthToken; }
        }

        public static string TwilioFromShortCode
        {
            get { return _twilioFromShortCode; }
        }

        public static string SMSMessageFormat
        {
            get { return _smsMessageFormat; }
        }

        public static string DirectAccessURL
        {
            get { return _directAccessURL; }
        }

        public static string SaleServiceURL
        {
            get { return _saleServiceURL; }
        }

        public static string SaleUserName
        {
            get { return _saleUserName; }
        }

        public static string SalePassword
        {
            get { return _salePassword; }
        }

        public static string SalePartnerId
        {
            get { return _salePartnerId; }
        }

        public static string EmailFromAddress
        {
            get { return _emailFromAddress; }
        }

        public static string OutbidEmailSubject
        {
            get { return _outbidEmailSubject; }
        }

        public static string AddDaysForPackageStartTime
        {
            get { return _addDaysForPackageStartTime; }
        }

        public static string AppTokenKey
        {
            get { return _appTokenKey; }
        }

        public static string EmailMessageFormat
        {
            get { return _emailMessageFormat; }
        }

        public static string BiddingURL
        {
            get { return _biddingURL; }
        }

        public static string SMSBodyMaxLength
        {
            get { return _smsBodyMaxLength; }
        }

        public static string EmailSubjectMaxLength
        {
            get { return _emailSubjectMaxLength; }
        }

        public static string TwilioHelpMessage
        {
            get { return _twilioHelpMessage; }
        }

        public static string TwilioStopMessage
        {
            get { return _twilioStopMessage; }
        }

        public static string IdentityBaseURL
        {
            get { return _identityBaseURL; }
        }

        public static string BiddingBaseURL
        {
            get { return _biddingBaseURL; }
        }

        public static string AdminBaseURL
        {
            get { return _adminBaseURL; }
        }

        public static string ErrorPageURL
        {
            get { return _errorPageURL; }
        }

        public static string PBIUserName
        {
            get { return _pbiUserName; }
        }

        public static string PBIPassword
        {
            get { return _pbiPassword; }
        }

        public static string PBIAuthorityUrl
        {
            get { return _pbiAuthorityUrl; }
        }

        public static string PBIResourceUrl
        {
            get { return _pbiResourceUrl; }
        }

        public static string PBIClientId
        {
            get { return _pbiClientId; }
        }

        public static string PBIApiUrl
        {
            get { return _pbiApiUrl; }
        }

        public static string PBIGroupId
        {
            get { return _pbiGroupId; }
        }

        public static string PBIReportId
        {
            get { return _pbiReportId; }
        }

        #endregion Properties

        #region Private Helpers

        private static string GetConfigValue(string key)
        {
            var configValue = string.Empty;

            if (ConfigurationManager.AppSettings.AllKeys.Contains(key))
                configValue = ConfigurationManager.AppSettings[key].Trim();
            //else
            //    throw new TokyoException(MessageCode.Error90001, key);

            return configValue;
        }

        private static string GetConnectionString(string connectionStringName)
        {
            var configValue = string.Empty;

            if (ConfigurationManager.ConnectionStrings[connectionStringName] != null)
                configValue = ConfigurationManager.ConnectionStrings[connectionStringName].ConnectionString;
            //else
            //    throw new TokyoException(MessageCode.Error90002, connectionStringName);

            return configValue;
        }

        #endregion Private Helpers
    }
}
