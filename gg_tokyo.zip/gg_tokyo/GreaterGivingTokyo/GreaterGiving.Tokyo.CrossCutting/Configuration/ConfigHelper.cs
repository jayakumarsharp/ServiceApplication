﻿using GreaterGiving.Tokyo.CrossCutting.Logging;
using System.Configuration;
using System.Linq;

namespace GreaterGiving.Tokyo.CrossCutting.Configuration
{
    public static class ConfigHelper
    {
        #region Methods

        public static string GetConfigValue(string key)
        {
            var configValue = string.Empty;

            if (ConfigurationManager.AppSettings.AllKeys.Contains(key))
                configValue = ConfigurationManager.AppSettings[key].Trim();            

            return configValue;
        }

        public static string GetConnectionString(string connectionStringKey)
        {
            var configValue = string.Empty;

            if (ConfigurationManager.ConnectionStrings[connectionStringKey] != null)
                configValue = ConfigurationManager.ConnectionStrings[connectionStringKey].ConnectionString;
            else
                Logger.WriteInfoLog(string.Format("Web.config file doesn't contain the connection string key: '{0}'",
                    connectionStringKey));

            return configValue;
        }

        #endregion Methods
    }
}
