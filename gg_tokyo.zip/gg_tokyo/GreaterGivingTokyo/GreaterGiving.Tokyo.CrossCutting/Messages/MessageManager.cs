﻿using GreaterGiving.Tokyo.Entities.Output;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GreaterGiving.Tokyo.CrossCutting.Messages
{
    public static class MessageManager
    {
        private static readonly IDictionary<MessageCode, string> _messageDictionary;

        static MessageManager()
        {
            _messageDictionary = new Dictionary<MessageCode, string>();

            InitializeMessageDictionary();
        }

        internal static Message CreateMessage(MessageCode messageCode, params object[] args)
        {
            return new Message(messageCode, (args == null || !args.Any())
                                ? _messageDictionary[messageCode]
                                : String.Format(_messageDictionary[messageCode], args));
        }

        private static void InitializeMessageDictionary()
        {
            //Add messages to dictionary if required
        }

        public static string GetEnumResultCode(MessageCode val)
        {
            string returnStatusString = string.Empty;
            switch (val)
            {
                case MessageCode.Success: { return returnStatusString = "001"; }
                case MessageCode.Fail: { return returnStatusString = "002"; }
                case MessageCode.NoRecord: { return returnStatusString = "003"; }
                case MessageCode.InUse: { return returnStatusString = "004"; }

            }
            return returnStatusString;
        }
        public static string GetEnumResultReason(MessageCode val)
        {
            string returnStatusString = string.Empty;
            switch (val)
            {
                case MessageCode.Info001: { return returnStatusString = "Project already exists"; }
                case MessageCode.Info002: { return returnStatusString = "Project not found"; }
                case MessageCode.Success001: { return returnStatusString = "Event was added successfully."; }
                case MessageCode.Success002: { return returnStatusString = "Success"; }

                case MessageCode.Info003: { return returnStatusString = "Package not found"; }
                case MessageCode.Info004: { return returnStatusString = "No records updated"; }
                case MessageCode.Info005: { return returnStatusString = "Package already exists"; }


                case MessageCode.Info008: { return returnStatusString = "Bidder not found"; }
                case MessageCode.Info009: { return returnStatusString = "No records deleted"; }
                case MessageCode.Info010: { return returnStatusString = "Bidder already exists"; }
                case MessageCode.Info011: { return returnStatusString = "No records were found to remove."; }

                case MessageCode.Error001: { return returnStatusString = "Internal Server Error"; }
                case MessageCode.Error002: { return returnStatusString = "ProjectXid cannot be null"; }
                case MessageCode.Error003: { return returnStatusString = "PackageXid cannot be null"; }
                case MessageCode.Error004: { return returnStatusString = "BidderXid cannot be null"; }
                case MessageCode.Error005: { return returnStatusString = "SponsorXid cannot be null"; }

                case MessageCode.Success003: { return returnStatusString = "Sponsor was added successfully."; }
                case MessageCode.Success004: { return returnStatusString = "Sponsor was updated successfully."; }
                case MessageCode.Info006: { return returnStatusString = "Sponsor not found"; }
                case MessageCode.Info007: { return returnStatusString = "Sponsor already exists"; }

                case MessageCode.Success005: { return returnStatusString = "Message(s) Accepted."; }
                case MessageCode.Success006: { return returnStatusString = "Success"; }
                case MessageCode.Error006: { return returnStatusString = "Message(s) Accept failed"; }
                case MessageCode.Error007: { return returnStatusString = "Phone Or Message cannot be null"; }
                case MessageCode.Error008: { return returnStatusString = "No records updated. Package Ids missing:"; }
                case MessageCode.Error009: { return returnStatusString = "Message Or Subject Or From Email Address Or To Email Address Or From Name cannot be null"; }
                case MessageCode.Error010: { return returnStatusString = "Unsubscribed"; }
                case MessageCode.Error011: { return returnStatusString = "Invalid PhoneNo"; }
            }
            return returnStatusString;
        }

        public static ResultModel GetResultMessage(MessageCode code, MessageCode reason)
        {
            ResultModel result = new ResultModel();
            result.ResultCode = GetEnumResultCode(code);
            result.Reason = GetEnumResultReason(reason);
            return result;
        }

        // to append the extendedReason with the reason
        public static ResultModel GetResultMessage(MessageCode code, MessageCode reason, string extendedReason)
        {
            ResultModel result = new ResultModel();
            result.ResultCode = GetEnumResultCode(code);
            result.Reason = string.Concat(GetEnumResultReason(reason), extendedReason);
            return result;
        }
    }
}
