﻿
namespace GreaterGiving.Tokyo.CrossCutting.Messages
{
    public class Message
    {
        private readonly MessageCode _messageCode;
        private readonly string _messageText;

        public Message(MessageCode messageCode, string messageText)
        {
            _messageCode = messageCode;
            _messageText = messageText;
        }

        public MessageCode MessageCode
        {
            get { return _messageCode; }
        }

        public string MessageText
        {
            get { return _messageText; }
        }
    }
}
