﻿namespace GreaterGiving.Tokyo.CrossCutting.Messages
{
    public enum MessageCode
    {
        #region Success Message Codes

        Success = 001,

        Success001 = 1001,
        Success002 = 1002,
        Success003 = 1003,
        Success004 = 1004,
        Success005 = 1005,
        Success006 = 1006,

        #endregion Success Message Codes

        #region Error Message Codes

        Fail = 002,
        NoRecord = 003,
        InUse = 004,

        Error001 = 2001,
        Error002 = 2002,
        Error003 = 2003,
        Error004 = 2004,
        Error005 = 2005,
        Error006 = 2006,
        Error007 = 2007,
        Error008 = 2008,
        Error009 = 2009,
        Error010 = 2010,
        Error011 = 2011,
        #endregion Error Message Codes

        #region Info Message Codes

        None = 0,
        Info001 = 3001,
        Info002 = 3002,
        Info003 = 3003,
        Info004 = 3004,
        Info005 = 3005,
        Info006 = 3006,
        Info007 = 3007,
        Info008 = 3008,
        Info009 = 3009,
        Info010 = 3010,
        Info011 = 3011,

        #endregion Info Message Codes
    }
}
