﻿using System;
using System.Threading.Tasks;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace GreaterGiving.Tokyo.CrossCutting.Email
{
    public static class SendEmail
    {
        public static async Task<Response> SendEmailNotification(string fromAddress, string fromName, string subject, string body, string toAddress, string toName)
        {
            Logger.WriteInfoLog(string.Format("Method: SendEmailTextMessage, Email Sent From Email Address: {0}, Email Sent To Email Address: {1}", fromAddress, toAddress));
            try
            {
                var client = new SendGridClient(ConfigManager.SendGridAPIKey);
                var msg = new SendGridMessage()
                {
                    From = new EmailAddress(fromAddress, fromName),
                    Subject = subject,
                    HtmlContent = body
                };
                msg.AddTo(new EmailAddress(toAddress));
                var response = await client.SendEmailAsync(msg).ConfigureAwait(false);
                return response;
            }
            catch(Exception ex)
            {
                Logger.WriteInfoLog(string.Format("Method: SendEmailTextMessage, Error :{0}", ex.Message));
                throw new Exception(ex.Message);
            }
        }
    }
}
