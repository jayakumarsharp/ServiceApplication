﻿using GreaterGiving.Tokyo.CrossCutting.Logging;
using System;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace GreaterGiving.Tokyo.CrossCutting.SMS
{
    public static class SendSMS
    {
        public static MessageResource SendTextMessage(string fromPhoneNumber, string toPhoneNumber, string body,string twilioAccountSid,string twilioAuthToken)
        {
            MessageResource messageStatus = null;
            Logger.WriteInfoLog(string.Format("Method: SendTextMessage, Message Sent From Phone Number: {0}, Message Sent To Phone Number: {1}", fromPhoneNumber, toPhoneNumber));
            try
            {
                // Initialize the Twilio client
                TwilioClient.Init(twilioAccountSid, twilioAuthToken);

                // Send a new outgoing SMS by POSTing to the Messages resource
                //TODO later: fromPhoneNumber needs to be replaced with shortcode, when client provides
                var message = MessageResource.Create(
                    from: new PhoneNumber(fromPhoneNumber),
                    to: new PhoneNumber(toPhoneNumber),
                    body: body);

                //TODO: As of now because of immediate fetch status is still in "sent". Need to see how "delivered" can be fetch.
                messageStatus = MessageResource.Fetch(message.Sid);
            }
            catch (Exception ex)
            {
                Logger.WriteInfoLog(string.Format("Method: SendTextMessage, Error :{0}", ex.Message));
                var errorDetails = " Twilio Error Message: " + ex.Message + " Error Link: " + ((Twilio.Exceptions.ApiException)ex).MoreInfo;
                throw new Exception(errorDetails);
            }
            Logger.WriteInfoLog(string.Format("Method: SendTextMessage, Message Sent From Phone Number: {0}, Message Sent To Phone Number: {1},Status:{2}", fromPhoneNumber, toPhoneNumber, messageStatus.Status));
            return messageStatus;
        }
    }
}
