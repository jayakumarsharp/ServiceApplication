﻿using PostSharp.Aspects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GreaterGiving.Tokyo.CrossCutting.Logging
{
    [Serializable]
    public class LogAspect : OnMethodBoundaryAspect
    {
        #region Private Fields & Constants

        private static readonly IEnumerable<string> ForbiddenMethodNames = new List<string> { ".ctor", ".cctor" };

        private static readonly IEnumerable<string> ForbiddenArgMethodNames = new List<string>
        {
            "Login",
            "Authenticate",
            "Authentication",
            "Logout"
        };

        #endregion Private Fields & Constants

        #region Constructors

        /// <summary>
        /// Bootsrtaps the logger
        /// </summary>
        static LogAspect()
        {
            Logger.Log.ToString();
        }

        #endregion Constructors

        #region OnMethodBoundaryAspect Members

        /// <summary>
        /// Logs the method entry
        /// </summary>
        /// <param name="args"></param>
        public override sealed void OnEntry(MethodExecutionArgs args)
        {
            try
            {
                if (SkipMethodLogging(args))
                    return;

                Logger.WriteInfoLog(GetEntryMethodLogString(args));

                base.OnEntry(args);
            }
            catch (Exception exc)
            {
                // Swallow the exception, for now ;-)
            }
        }

        /// <summary>
        /// Logs the method exit
        /// </summary>
        /// <param name="args"></param>
        public override sealed void OnExit(MethodExecutionArgs args)
        {
            try
            {
                if (SkipMethodLogging(args))
                    return;

                Logger.WriteInfoLog(GetExitMethodLogString(args));

                base.OnExit(args);
            }
            catch (Exception exc)
            {
                // Swallow the exception, for now ;-)
            }
        }

        #endregion OnMethodBoundaryAspect Members

        #region Private Helpers

        /// <summary>
        /// Constructs and Returns the entry method string
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        private string GetEntryMethodLogString(MethodExecutionArgs args)
        {
            var sb = new StringBuilder();

            sb.AppendFormat("{0}\tEntered {1}", Environment.NewLine, GetMethodNameSansReturn(args));

            if (args.Arguments == null || !args.Arguments.Any())
                sb.AppendLine(", with no arguments.");
            else
            {
                if (!SkipArgumentLogging(args))
                {
                    sb.AppendLine(", with these arguments: ");

                    foreach (var arg in args.Arguments)
                        sb.AppendFormat("\t\t{0}: {1}{2}", arg, arg.GetType(), Environment.NewLine);
                }
                else
                    sb.AppendLine();
            }

            return sb.ToString();
        }

        /// <summary>
        /// Constructs and Returns the exit method string
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        private string GetExitMethodLogString(MethodExecutionArgs args)
        {
            var sb = new StringBuilder();

            sb.AppendFormat("{0}\tExited {1}, ", Environment.NewLine, GetMethodNameSansReturn(args));

            if (args.ReturnValue == null)
                sb.AppendLine("with no return value.");
            else
            {
                sb.AppendLine("with the return value of: ");
                sb.AppendFormat("\t\t{0}: {1}{2}", args.ReturnValue, args.ReturnValue.GetType(), Environment.NewLine);
            }

            return sb.ToString();
        }

        /// <summary>
        ///     Returns the method name, without the return type specification
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        private static object GetMethodNameSansReturn(MethodExecutionArgs args)
        {
            return args.Method.DeclaringType.Name + "." + args.Method.Name + "()";
        }

        /// <summary>
        ///     Specifies whether to skip logging of the arguments of the specified method
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        private bool SkipArgumentLogging(MethodExecutionArgs args)
        {
            var retValue = ForbiddenArgMethodNames.Any(fma => args.Method.ToString().Contains(fma));
            return retValue;
        }

        /// <summary>
        ///     Specifies whether to skip logging of the specified method
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        private bool SkipMethodLogging(MethodExecutionArgs args)
        {
            var retValue = false;

            // Config setting to skip logging
            if (false)
            {
                args.FlowBehavior = FlowBehavior.Return;
                retValue = true;
            }
            // Skip logging of certain methods
            if (ForbiddenMethodNames.Any(fmn => args.Method.ToString().Contains(fmn)))
                retValue = true;

            return retValue;
        }

        #endregion Private Helpers
    }
}
