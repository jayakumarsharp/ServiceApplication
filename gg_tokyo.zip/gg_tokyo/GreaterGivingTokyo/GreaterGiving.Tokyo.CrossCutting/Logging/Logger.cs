﻿using log4net;
using log4net.Config;
using System;

namespace GreaterGiving.Tokyo.CrossCutting.Logging
{
    public static class Logger
    {
        static Logger()
        {
            XmlConfigurator.Configure();
            Log = LogManager.GetLogger("BiddingLogger");

            // Write start up logs
            WriteInfoLog(string.Format("{0}{0}=======================================", Environment.NewLine));
            WriteInfoLog(string.Format("Service started.{0}", Environment.NewLine));
        }

        public static ILog Log { get; private set; }

        public static void WriteInfoLog(string message)
        {
            Log.Info(message);
        }

        public static void WriteDebugLog(string message)
        {
            Log.Debug(message);
        }

        public static void WriteErrorLog(string message)
        {
            Log.Error(message);
        }
    }
}