﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading;

namespace GreaterGiving.Tokyo.CrossCutting.Identity
{
    public static class CurrentBidder
    {
        #region Properties

        /// <summary>
        /// Gets the current Bidder Name
        /// </summary>
        /// <returns></returns>
        public static string BidderName
        {
            get
            {
                return GetBidderInfoValue<string>(ClaimTypes.Name);
            }
        }

        /// <summary>
        /// Gets the current Bidder Number
        /// </summary>
        /// <returns></returns>
        public static int BidderNumber
        {
            get
            {
                return GetBidderInfoValue<int>(ClaimTypes.NameIdentifier);
            }
        }

        /// <summary>
        /// Gets the current Table Number
        /// </summary>
        /// <returns></returns>
        public static int TableNumber
        {
            get
            {
                return GetBidderInfoValue<int>(ClaimTypes.UserData);
            }
        }

        /// <summary>
        /// Gets the current Online Bidder Key
        /// </summary>
        /// <returns></returns>
        public static string OnlineBidderKey
        {
            get
            {
                return GetBidderInfoValue<string>(ClaimTypes.Sid);
            }
        }

        /// <summary>
        /// Gets the current Prefix
        /// </summary>
        /// <returns></returns>
        public static string Prefix
        {
            get
            {
                return GetBidderInfoValue<string>(ClaimTypes.PrimarySid);
            }
        }

        #endregion Properties

        #region Private Helpers

        /// <summary>
        /// Gets the current user's info values
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="claimType"></param>
        /// <returns></returns>
        private static T GetBidderInfoValue<T>(string claimType, T defaultValue = default(T))
            where T : IConvertible
        {
            T bidderInfoValue = defaultValue;

            try
            {
                var claimsIdentity = Thread.CurrentPrincipal.Identity as ClaimsIdentity;

                if (claimsIdentity != null)
                {
                    var claim = claimsIdentity.Claims.Where(c => c.Type.Equals(claimType, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

                    bidderInfoValue = claim != null ? (T)Convert.ChangeType(claim.Value, typeof(T)) : bidderInfoValue;
                }
            }
            catch (Exception exc)
            { }

            return bidderInfoValue;
        }

        #endregion Private Helpers
    }
}
