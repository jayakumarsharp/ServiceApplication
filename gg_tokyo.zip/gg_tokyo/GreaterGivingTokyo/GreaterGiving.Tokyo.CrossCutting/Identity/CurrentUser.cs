﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading;

namespace GreaterGiving.Tokyo.CrossCutting.Identity
{
    public static class CurrentUser
    {
        #region Properties

        /// <summary>
        /// Gets the current user's GUID
        /// </summary>
        /// <returns></returns>
        public static Guid UserGuid
        {
            get
            {
                var userID = GetUserInfoValue<string>(ClaimTypes.NameIdentifier);

                return String.IsNullOrWhiteSpace(userID) ? Guid.Empty : new Guid(userID);
            }
        }

        /// <summary>
        /// Gets the current user's ID
        /// </summary>
        /// <returns></returns>
        public static int UserID
        {
            get
            {
                return GetUserInfoValue<int>(ClaimTypes.Sid);
            }
        }

        /// <summary>
        /// Gets the current user's role ID
        /// </summary>
        /// <returns></returns>
        public static int RoleID
        {
            get
            {
                return GetUserInfoValue<int>(ClaimTypes.Role);
            }
        }

        /// <summary>
        /// Gets the current user's Tenant ID
        /// </summary>
        /// <returns></returns>
        public static int TenantID
        {
            get
            {
                return GetUserInfoValue<int>(ClaimTypes.GroupSid);
            }
        }

        /// <summary>
        /// Gets the current user's Tenant ID
        /// </summary>
        /// <returns></returns>
        public static Guid CurrentTenantGuid
        {
            get
            {
                return (TenantGuids != null && TenantGuids.Any()) ? TenantGuids.First() : Guid.Empty;
            }
        }

        /// <summary>
        /// Gets the current user's list of tenants (csv)
        /// </summary>
        /// <returns></returns>
        public static List<Guid> TenantGuids
        {
            get
            {
                string csvTenants = GetUserInfoValue<string>(ClaimTypes.PrimaryGroupSid);

                var tenantList = csvTenants.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

                return tenantList.Select(t => new Guid(t.Trim())).ToList();
            }
        }

        /// <summary>
        /// Gets the current user's tenant name
        /// </summary>
        /// <returns></returns>
        public static string TenantName
        {
            get
            {
                return GetUserInfoValue<string>(ClaimTypes.GivenName);
            }
        }

     
       

        #endregion Main Methods

        #region Private Helpers

        /// <summary>
        /// Gets the current user's info values
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="claimType"></param>
        /// <returns></returns>
        private static T GetUserInfoValue<T>(string claimType, T defaultValue = default(T))
            where T : IConvertible
        {
            T userInfoValue = defaultValue;

            try
            {
                var claimsIdentity = Thread.CurrentPrincipal.Identity as ClaimsIdentity;

                if (claimsIdentity != null)
                {
                    var claim = claimsIdentity.Claims.Where(c => c.Type.Equals(claimType, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

                    userInfoValue = claim != null ? (T)Convert.ChangeType(claim.Value, typeof(T)) : userInfoValue;
                }
            }
            catch (Exception exc)
            { }

            return userInfoValue;
        }

       

        #endregion Private Helpers
    }
}
