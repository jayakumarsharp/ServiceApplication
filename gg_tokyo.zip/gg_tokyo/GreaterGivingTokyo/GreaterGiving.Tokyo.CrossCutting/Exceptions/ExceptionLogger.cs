﻿using System;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Identity;
using GreaterGiving.Tokyo.Entities;
using GreaterGiving.Tokyo.Entities.Core;
using SystemThread = System.Threading.Tasks;

namespace GreaterGiving.Tokyo.CrossCutting.Exceptions
{
    public static class ExceptionLogger
    {
        #region Core Methods

        public static void LogException(Exception exc)
        {
            // Fire and Forget!
            SystemThread.Task.Factory.StartNew(() => AddNewException(exc, CurrentUser.UserID));
        }

        #endregion Core Methods

        #region Private Helpers

        /// <summary>
        /// Adds the specified exception to db
        /// </summary>
        /// <param name="exc"></param>
        /// <param name="userID"></param>
        private static void AddNewException(Exception exc, int userID)
        {
            try
            {
                using (var dbContext = new BiddingContext(ConfigManager.BiddingConnectionString))
                {
                    ServerException parentServerException = null;

                    while (exc != null)
                    {
                        var serverException = CreateNewServerException(exc, userID);
                        //serverException.ServerException1 = parentServerException;

                        parentServerException = serverException;

                        exc = exc.InnerException;
                    }

                    dbContext.SaveChanges();
                }
            }
            catch (Exception)
            {
                // Simply swollow the exception ;-)
            }
        }

        /// <summary>
        /// Creates a new ServerException
        /// </summary>
        /// <param name="exc"></param>
        /// <returns></returns>
        private static ServerException CreateNewServerException(Exception exc, int userID)
        {
            var serverException = new ServerException();

            if (exc != null)
            {
                /*serverException.Description = "An unhandled exception occurred in application!";
                serverException.Source = exc.Source;
                serverException.ErrorMessage = exc.Message;
                serverException.StackTrace = String.IsNullOrWhiteSpace(exc.StackTrace)
                    ? String.Empty
                    : exc.StackTrace.Trim();

                string stringifiedData = String.Empty;
                if (exc.Data.Keys.Count > 0)
                    stringifiedData = exc.Data.Cast<object>()
                        .Aggregate((string)null, (current, item) => current + (item != null ? item.ToString() : String.Empty));
                serverException.ErrorData = stringifiedData;

                serverException.HelpLink = exc.HelpLink;
                //serverException.HResult = exc.HResult;
                serverException.TargetSite = exc.TargetSite == null ? String.Empty : exc.TargetSite.ToString();
                serverException.CreatedBy = userID;
                serverException.CreatedOn = DateTime.UtcNow;*/
            }

            return serverException;
        }

        #endregion Private Helpers
    }
}
