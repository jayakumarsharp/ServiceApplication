﻿using GreaterGiving.Tokyo.CrossCutting.Messages;
using System;

namespace GreaterGiving.Tokyo.CrossCutting.Exceptions
{
    [Serializable]
    public class TokyoException: ApplicationException
    {
        #region Private Fields & Constants

        private readonly Message _errorMessage;

        #endregion Private Fields & Constants

        #region Properties

        public Message ErrorMessage => _errorMessage;

        #endregion Properties

        #region Constructors

        private TokyoException(Message message)
            : base(message.MessageText)
        {
            _errorMessage = message;
        }

        public TokyoException(MessageCode messageCode, params object[] args)
            : this(MessageManager.CreateMessage(messageCode, args))
        {
        }

        private TokyoException(string errorMessage)
            : base(errorMessage)
        {
        }

        #endregion Constructors
    }
}