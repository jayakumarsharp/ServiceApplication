﻿using GreaterGiving.Tokyo.CrossCutting.Logging;
using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http.Filters;

namespace GreaterGiving.Tokyo.CrossCutting.Exceptions
{
    public class TokyoExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override sealed void OnException(HttpActionExecutedContext context)
        {
            var exception = context.Exception;

            if (exception is UnauthorizedAccessException)
                context.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
            else if (exception is TokyoException)
            {
                var tokyoException = exception as TokyoException;

                context.Response = context.Request.CreateErrorResponse(
                    HttpStatusCode.BadRequest, tokyoException.ErrorMessage.MessageCode.ToString());

                context.Response.ReasonPhrase = tokyoException.ErrorMessage.MessageText;
            }
            else
            {
                // Log the error in the log file
                Logger.WriteErrorLog(GetCompleteExceptionString(exception));

                // Log the error in the database
                ExceptionLogger.LogException(exception);

                context.Response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    ReasonPhrase = exception.Message
                };
            }
        }

        private static string GetCompleteExceptionString(Exception exc)
        {
            return exc.InnerException != null
                ? GetCompleteExceptionString(exc.InnerException)
                : GetExceptionDetails(exc);
        }

        private static string GetExceptionDetails(Exception exc)
        {
            var sbErrorString = new StringBuilder();

            if (!string.IsNullOrWhiteSpace(exc.Message))
                sbErrorString.AppendFormat("\tMessage: {0}{1}", exc.Message, Environment.NewLine);

            if (!string.IsNullOrWhiteSpace(exc.StackTrace))
                sbErrorString.AppendFormat("\tStackTrace: {0}{1}", exc.StackTrace, Environment.NewLine);

            if (!string.IsNullOrWhiteSpace(exc.Source))
                sbErrorString.AppendFormat("\tSource: {0}{1}", exc.Source, Environment.NewLine);

            return sbErrorString.ToString();
        }
    }
}
