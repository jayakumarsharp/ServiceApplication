﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace GreaterGiving.Tokyo.CrossCutting.Crypto
{
    public static class CryptoHelper
    {
        #region Public Methods

        /// <summary>
        /// Encrypts the specified text, and returns the cypher text
        /// </summary>
        /// <param name="plainText"></param>
        /// <param name="password"></param>
        /// <param name="salt"></param>
        /// <returns></returns>
        public static string Encrypt(string plainText, string password, string salt)
        {
            return Encrypt<AesManaged>(plainText, password, salt);
        }

        /// <summary>
        /// Decrypts the specified cypher text, and returns the plain text
        /// </summary>
        /// <param name="encryptedText"></param>
        /// <param name="password"></param>
        /// <param name="salt"></param>
        /// <returns></returns>
        public static string Decrypt(string encryptedText, string password, string salt)
        {
            return Decrypt<AesManaged>(encryptedText, password, salt);
        }

        #endregion Public Methods

        #region Private Helpers

        private static string Encrypt<T>(string plainText, string password, string salt)
            where T : SymmetricAlgorithm, new()
        {
            var transform = PrepareCipher<T>(password, salt, true);

            using (var buffer = new MemoryStream())
            {
                using (var stream = new CryptoStream(buffer, transform, CryptoStreamMode.Write))
                using (var writer = new StreamWriter(stream, Encoding.Unicode))
                {
                    writer.Write(plainText);
                }

                return Convert.ToBase64String(buffer.ToArray());
            }
        }

        private static string Decrypt<T>(string decryptedText, string password, string salt)
           where T : SymmetricAlgorithm, new()
        {
            var transform = PrepareCipher<T>(password, salt, false);

            using (var buffer = new MemoryStream(Convert.FromBase64String(decryptedText)))
            using (var stream = new CryptoStream(buffer, transform, CryptoStreamMode.Read))
            using (var reader = new StreamReader(stream, Encoding.Unicode))
            {
                return reader.ReadToEnd();
            }
        }

        private static ICryptoTransform PrepareCipher<T>(string password, string salt, bool encrypt = true)
            where T : SymmetricAlgorithm, new()
        {
            var rgb = new Rfc2898DeriveBytes(password, Encoding.Unicode.GetBytes(salt));

            var algorithm = new T { Mode = CipherMode.CBC };

            byte[] rgbKey = rgb.GetBytes(algorithm.KeySize >> 3);
            byte[] rgbIV = rgb.GetBytes(algorithm.BlockSize >> 3);

            return encrypt ? algorithm.CreateEncryptor(rgbKey, rgbIV) : algorithm.CreateDecryptor(rgbKey, rgbIV);
        }

        #endregion Private Helpers
    }
}
