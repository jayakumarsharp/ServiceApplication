﻿using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Core;

namespace GreaterGiving.Tokyo.CrossCutting.DBFactory
{
    public static class DbContextFactory
    {
        public static IBiddingContext GetBiddingContext()
        {
            return new BiddingContext(ConfigManager.BiddingConnectionString);
        }
    }
}
