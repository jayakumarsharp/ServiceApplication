﻿
namespace GreaterGiving.Tokyo.CrossCutting.Common
{
    public static class AppConstants
    {
        public const string TokyoScheme = "TokyoScheme";
        public const string ValidAudience = "https://www.greatergiving.com/";
        public const string ValidIssuer = "BiddingTokyo";

        public const string SuperAdmin = "SuperAdmin";
        public const string DonorDelimiter =  "#$%";
        public const string EmailDelimiter = ";";
        public const string CommaDelimiter = ",";

        public const string AmountFormat = "{0:0.##}";
        public const string UTCDateTimeFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ss";
        public const string USCountryCode = "+1";
    }
}
