﻿using System;
using System.Collections.Generic;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Contracts
{
    public interface IBiddingData
    {
        #region Project

        bool ValidateProject(int projectXid);

        ProjectOutput GetProject(string prefix);

        ProjectOutput GetProjectByProjectKey(string projectKey);

        Project GetProjectByProjectId(int projectXid);

        Project GetProjectDetails(string prefix);

        ResultModel IsShortNameAvailable(string shortName);

        ResultModel CreateProject(ProjectFieldValues project);

        ResultModel UpdateProject(ProjectFieldValues project);

        ResultModel DeleteProject(int projectid);

        int InsertSMSRequest(TextMessageFieldValues message, int purpose);

        bool InsertSMSDeliveryStatus(int requestId, string toPhoneNumber, string statusIndicator, DateTime sendTime, DateTime deliveryTime, string sId, int? bidderId);

        void InsertSMSErrorLog(string errorCode, string errorMsg, string phoneNo);

        void UpdateSMSStatus(int smsrequestId, string statusIndicator,string smsSid);

        int InsertEmailRequest(EmailMessageFieldValues emailMessage, int projectId, int purpose);

        bool InsertEmailDeliveryStatus(EmailDeliveryStatusInput emailDeliveryStatusInput);

        void InsertUnsubscribePhoneNo(string phoneNo);

        void DeleteUnsubscribePhoneNo(string phoneNo);

        List<SMSUnsubscribe> GetUnsubscribePhoneNos();

        #endregion Project

        #region Package

        List<PackageOutput> GetAllPackages(string prefix);

        List<PackageOutput> GetPackages(string prefix, int pageno, int size, string packageFilterType);

        Package GetPackagebyPackageId(int packageXid);

        PackageOutput GetPackagebyPackageId(string prefix, int packageXid);

        List<PackageOutput> GetRelatedPackages(string prefix, int packageXid, string displayedPackages);

        PackageOutput GetAppealDonationPackage(string prefix);

        ResultModel AddOrUpdatePackage(PackageFieldValues package);

        ResultModel DeletePackage(int packageId);

        ResultModel UpdateTimeAndItemTypeForPackages(BulkPackageFieldValues package);

        List<string> GetPackageTypesByProject(string prefix);

        List<string> GetCategoryTypesByProject(string prefix);

        List<PackageOutput> SearchPackagesByPackageNameOrNumber(string prefix, int pageno, int size, string packageNameOrNumber);

        List<PackageOutput> GetPackagesByCategory(string prefix, int pageno, int size, string categoryName);

        List<PackageOutput> NoBidPackagesFilter(Project project);

        List<PackageOutput> CurrentlyOpenPackagesFilter(Project project);

        List<PackageOutput> OpeningSoonPackagesFilter(Project project);

        List<PackageOutput> BuyNowPackagesFilter(Project project);

        List<PackageOutput> MultiSalePackagesFilter(Project project);

        List<PackageOutput> PreviewOnlyPackagesFilter(Project project);

        List<PackageOutput> GetFavoritePackagesByBidder(string prefix, int pageno, int size);

        List<PackageOutput> GetBidActivityByBidder(string prefix, string activityType, int pageno, int size);

        void AddOrRemoveFavorite(string prefix, int packageId, bool isFavorite);

        Sale BuyRegularPackage(string prefix, int packageId);

        Package GetPackageBySaleId(int saleId);

        ResultMessage AddBid(string prefix, int packageId, decimal amount, string bidType);

        ResultMessage SetMaxBid(string prefix, int packageId, decimal amount, string bidType);

        Sale BuyMultiSalePackages(string prefix, int packageId, int quantity);

        Sale BuyDonationPackage(string prefix, int packageId, decimal amount);

        Sale BuyAppealDonationPackage(string prefix, decimal donationAmount);

        List<DisplayLookup> GetDisplayLookupListByType(string type);

        Bidder GetCurrentBidderDetails();

        CodeLookup GetCodeLookupByTypeDescription(string type, string description);
               
        void UpdateSaleGGOUpdateStatus(int saleId, int ggoUpdateStatus);

        CountdownBoardOutput GetFurthestPackageClosingTimeByProject(string prefix);

        List<PackageOutput> GetLeaderBoardPackages(string prefix, LeaderBoardInput input);

        void UpdateEventStatisticsReport(int projectXid);

        #endregion Package

        #region Bidder

        ResultModel AddOrUpdateBidder(BidderFieldValues bidder);

        ResultModel DeleteBidder(int bidderId);

        List<BidderOutput> GetBidderHistoryOrCurrentBuyers(string prefix, int packageid);

        Bidder GetBidderByBidderKey(string bidderKey);

        List<Bidder> GetBidderByProjectId(int projectId);

        #endregion Bidder

        #region Sponsor    

        SponsorOutput GetSponsorBySponsorId(int sponsorXid);

        List<SponsorOutput> GetSponsorImagesByPrefix(string prefix);

        ResultModel AddOrUpdateSponsor(SponsorFieldValues sponsor);

        ResultModel DeleteSponsor(int sponsorid);

        #endregion Sponsor 

        #region Bid

        Bid GetBidByBidId(int bidId);

        List<Bid> GetBidsByProject(int projectId);

        #endregion Bid

        #region Sale

        Sale GetSaleBySaleId(int saleId);
        
        #endregion Sale


        #region Admin

        List<BidderOutput> GetTopBiddersForAdmin(string prefix, int count);

        List<BidderSearchOutput> GetAllBiddersForAdmin(string prefix, BidderSearchInput bidderSearchInput);

        List<PackageOutput> GetTopPackagesForAdmin(string prefix, int count);

        List<PackageSearchOutput> GetAllPackagesForAdmin(string prefix, PackageSearchInput input);

        BidderSearchOutput GetBidderDetailsForAdmin(string prefix, int bidderId);

        List<MaxBidOutput> GetBidderMaxBidForAdmin(string prefix, int bidderId);

        List<BidHistoryOutput> GetBidderBidHistoryForAdmin(string prefix, int bidderId);
        MaxBidOutput GetPackageMaxBidForAdmin(string prefix, int packageId);

        PackageSearchOutput GetPackageDetailsForAdmin(string prefix, int packageId);

        List<BidHistoryOutput> GetPackageBidHistoryForAdmin(string prefix, int packageId);

        ResultMessage ClearMaxBidForAdmin(string prefix, int packageId);

        ResultMessage RemoveBidForAdmin(string prefix, int bidId, int saleId);

        ResultMessage SaveEmailTemplateForAdmin(string prefix, EmailMessageFieldValues emailMessage);

        List<EmailTemplateOutput> GetEmailTemplatesForAdmin(string prefix);

        ResultMessage DeleteEmailTemplateForAdmin(int projectId, int emailTemplateId);

        List<SMSTemplateOutput> GetSMSTemplatesForAdmin(string prefix);

        ResultMessage SaveSMSTemplateForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues);

        ResultMessage DeleteSMSTemplateForAdmin(int projectId, int smsTemplateId);

        Tuple<ResultMessage, List<Package>> RemoveAllBidsForAdmin(string prefix);

        List<ExportBidHistoryOutput> ExportAllBiddingHistoryForAdmin(string prefix);

        EmbedReportOutput EmbedReportLastUpdatedDateTimeByProject(string prefix);
        #endregion Admin
    }
}
