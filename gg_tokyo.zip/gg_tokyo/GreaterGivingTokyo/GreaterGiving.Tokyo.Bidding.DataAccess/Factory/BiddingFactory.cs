﻿using GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding;
using GreaterGiving.Tokyo.CrossCutting.DBFactory;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Factory
{
    public static class BiddingFactory
    {
        public static BiddingProject GetBiddingProject()
        {
            return new BiddingProject(DbContextFactory.GetBiddingContext());
        }

        public static BiddingPackage GetBiddingPackage()
        {
            return new BiddingPackage(DbContextFactory.GetBiddingContext());
        }

        public static BiddingBidder GetBiddingBidder()
        {
            return new BiddingBidder(DbContextFactory.GetBiddingContext());
        }

        public static BiddingSponsor GetBiddingSponsor()
        {
            return new BiddingSponsor(DbContextFactory.GetBiddingContext());
        }

        public static BiddingBase GetBiddingBaseData()
        {
            return new BiddingBase(DbContextFactory.GetBiddingContext());
        }

        public static BiddingAdmin GetBiddingAdmin()
        {
            return new BiddingAdmin(DbContextFactory.GetBiddingContext());
        }
    }
}
