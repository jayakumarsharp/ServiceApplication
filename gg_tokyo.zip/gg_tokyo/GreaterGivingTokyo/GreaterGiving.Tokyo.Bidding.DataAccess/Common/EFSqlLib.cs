﻿using System.Data.Entity.SqlServer;

namespace GreaterGiving.Tokyo.Admin.DataAccess.Common
{
    internal static class EFSqlLib
    {
        private static SqlProviderServices _instance = SqlProviderServices.Instance;
    }
}