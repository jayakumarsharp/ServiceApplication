﻿namespace GreaterGiving.Tokyo.Bidding.DataAccess.Common
{
    public static class Common
    {
        //Removed Common methods to Framework\GreaterGiving.Tokyo.Common.Resusable since these methods does not deal with the database.
    }
}
