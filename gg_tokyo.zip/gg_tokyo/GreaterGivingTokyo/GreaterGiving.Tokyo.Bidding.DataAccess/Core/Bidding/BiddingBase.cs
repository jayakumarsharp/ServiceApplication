﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.CrossCutting.Identity;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Core;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Models;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding
{
    public class BiddingBase : IDisposable
    {
        protected IBiddingContext _dbContext;

        public BiddingBase(IBiddingContext context)
        {
            _dbContext = context;
        }

        public void Dispose()
        {
            if (_dbContext != null)
                _dbContext.Dispose();

            _dbContext = null;
        }

        public Project GetProject(int projectid)
        {
            return _dbContext.Projects.FirstOrDefault(i => i.ProjectXid == projectid && (!i.IsDeleted));
        }

        public Project GetProjectDetailByProjectKey(string projectKey)
        {
            return _dbContext.Projects.FirstOrDefault(i => i.ProjectKey == projectKey && (!i.IsDeleted));
        }

        public Project GetProjectByPrefix(string prefix)
        {
            return _dbContext.Projects.FirstOrDefault(i => i.Prefix.Trim().ToLower() == prefix.Trim().ToLower() && (!i.IsDeleted));
        }

        public Project GetProjectByProjectIdWithDeleted(int projectid)
        {
            return _dbContext.Projects.FirstOrDefault(i => i.ProjectXid == projectid);
        }

        public Project GetProjectByProjectId(int projectId)
        {
            return _dbContext.Projects.FirstOrDefault(i => i.ProjectXid == projectId && (!i.IsDeleted));
        }

        public Package GetPackage(int packageid)
        {
            return _dbContext.Packages.FirstOrDefault(i => i.PackageXid == packageid && (!i.IsDeleted));
        }

        public Package GetPackage(int packageid, int projectid)
        {
            return _dbContext.Packages.FirstOrDefault(i => i.PackageXid == packageid && i.ProjectXid == projectid && (!i.IsDeleted));
        }

        public List<Package> GetPackagesByProjectId(int projectid)
        {
            var project = GetProject(projectid);
            return _dbContext.Packages.Where(i => i.ProjectXid == projectid && i.PackageXid != project.DonationPackageXid && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetPackagesByProjectIdWithAppealDonation(int projectid)
        {
            return _dbContext.Packages.Where(i => i.ProjectXid == projectid && (!i.IsDeleted)).ToList();
        }

        public void InsertEventLog(EventLog eventLog, string eventType)
        {
            var eventTypeId = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, eventType).CodeValue;
            eventLog.EventType = eventTypeId;
            eventLog.EventDate = DateTime.UtcNow;
            if (eventLog != null)
            {
                _dbContext.EventLogs.Add(eventLog);
                _dbContext.SaveChanges();
            }
        }

        public List<PackageImage> GetPackageImages(int packageid)
        {
            return _dbContext.PackageImage.Where(x => x.PackageXid == packageid).ToList();
        }

        public Bidder GetBidder(int bidderid)
        {
            return _dbContext.Bidders.FirstOrDefault(i => i.BidderXid == bidderid && (!i.IsDeleted));
        }

        public Bidder GetBidder(int bidderid, int projectid)
        {
            return _dbContext.Bidders.FirstOrDefault(i => i.BidderXid == bidderid && i.ProjectXid == projectid && (!i.IsDeleted));
        }

        public List<Bidder> GetBidderByProjectId(int projectid)
        {
            return _dbContext.Bidders.Where(i => i.ProjectXid == projectid && (!i.IsDeleted)).ToList();
        }

        public Sponsor GetSponsor(int sponsorid)
        {
            return _dbContext.Sponsors.FirstOrDefault(i => i.SponsorXid == sponsorid && (!i.IsDeleted));
        }

        public List<SMSUnsubscribe> GetSMSUnsubscribePhoneNos()
        {
            return _dbContext.SMSUnsubscribes.ToList();
        }

        public SMSUnsubscribe GetSMSUnsubscribePhoneNo(string phoneNo)
        {
            return _dbContext.SMSUnsubscribes.Where(x => x.PhoneNo.Trim() == phoneNo.Trim()).FirstOrDefault();
        }

        public Sponsor GetSponsor(int sponsorid, int projectid)
        {
            return _dbContext.Sponsors.FirstOrDefault(i => i.SponsorXid == sponsorid && i.ProjectXid == projectid && (!i.IsDeleted));
        }

        public List<Sponsor> GetSponsorByProjectId(int projectid)
        {
            return _dbContext.Sponsors.Where(i => i.ProjectXid == projectid && (!i.IsDeleted)).ToList();
        }

        public List<Class> GetActiveClasses(int projectid)
        {
            return _dbContext.Class.Where(i => i.ProjectXid == projectid && (!i.IsDeleted)).ToList();
        }
              
        public void UpdateAppealTotalRaisedInProject(Project project, int donationPackageId)
        {
            var totalSaleAmount = GetTotalSaleByPackage(donationPackageId);
            project.AppealTotalRaised = totalSaleAmount;
        }

        public Class GetClass(int? classid)
        {
            return _dbContext.Class.FirstOrDefault(i => i.ClassID == classid && (!i.IsDeleted));
        }

        public Class GetClassByClassName(int projectid, string className)
        {
            return _dbContext.Class.FirstOrDefault(i => i.ClassName == className && i.ProjectXid == projectid && (!i.IsDeleted));
        }

        public Class GetDeletedClassByClassName(int projectid, string className)
        {
            return _dbContext.Class.FirstOrDefault(i => i.ClassName == className && i.ProjectXid == projectid && (i.IsDeleted));
        }

        public SMSRequest GetSmsRequestByProjectId(int Projectid)
        {
            return _dbContext.SMSRequests.FirstOrDefault(i => i.ProjectXid == Projectid);
        }

        public Bid GetHighBidByPackage(int packageid)
        {
            return _dbContext.Bids.Where(i => i.PackageXid == packageid && !(i.IsDeleted) && !(i.Canceled)).OrderByDescending(a => a.Amount).FirstOrDefault();
        }

        public List<Bid> GetHighBidsByProject(int projectId)
        {
            var highBids = _dbContext.Bids.Where(i => i.ProjectXid == projectId && !(i.IsDeleted) && !(i.Canceled)).GroupBy(a => a.PackageXid, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();
            return highBids;
        }

        public List<Bid> GetBidsByProject(int projectId)
        {
            var bids = _dbContext.Bids.Where(i => i.ProjectXid == projectId && !(i.IsDeleted) && !(i.Canceled)).ToList();
            return bids;
        }

        public List<Bid> GetBidsByPackage(int projectId, int packageId)
        {
            var bids = _dbContext.Bids.Where(i => i.ProjectXid == projectId && i.PackageXid == packageId && !(i.IsDeleted) && !(i.Canceled)).ToList();
            return bids;
        }

        public Bid GetBidByBidId(int bidId)
        {
            var bid = _dbContext.Bids.FirstOrDefault(i => i.BidXid == bidId && !(i.IsDeleted) && !(i.Canceled));
            return bid;
        }

        public Package GetPackageBySaleId(int saleId)
        {
            var sale = GetSaleBySaleId(saleId);

            if (sale != null)
                return GetPackage(sale.PackageXid, sale.ProjectXid);
            else
                return null;
        }

        public List<Package> GetNoBidPackagesByProject(int projectId)
        {
            var bidList = _dbContext.Bids.Where(a => a.ProjectXid == projectId && !(a.IsDeleted) && !(a.Canceled)).Select(b => b.PackageXid).ToList();
            return GetPackagesByProjectId(projectId).Where(i => !bidList.Contains(i.PackageXid)).ToList();
        }

        public List<Package> GetNoSalePackagesByProject(int projectId)
        {
            var saleList = _dbContext.Sales.Where(a => a.ProjectXid == projectId && !(a.IsDeleted)).Select(b => b.PackageXid).ToList();
            return GetPackagesByProjectId(projectId).Where(i => !saleList.Contains(i.PackageXid)).ToList();
        }

        public Package GetSalePackageByPackageId(int projectId, int packageId)
        {
            var sale = _dbContext.Sales.FirstOrDefault(a => a.ProjectXid == projectId && a.PackageXid == packageId && !(a.IsDeleted));
            return (sale != null) ? GetPackage(packageId, projectId) : null;
        }

        public bool IsSalePackageAvailableByPackageId(int projectId, int packageId)
        {
            var sale = _dbContext.Sales.FirstOrDefault(a => a.ProjectXid == projectId && a.PackageXid == packageId && !(a.IsDeleted));
            return (sale != null);
        }

        public List<Package> GetSalePackagesByProject(int projectId)
        {
            var saleList = _dbContext.Sales.Where(a => a.ProjectXid == projectId && !(a.IsDeleted)).Select(b => b.PackageXid).ToList();
            return GetPackagesByProjectId(projectId).Where(i => saleList.Contains(i.PackageXid)).ToList();
        }

        public decimal GetTotalSaleByPackage(int packageId)
        {
            decimal totalSale = 0;
            var sale = _dbContext.Sales.Where(a => a.PackageXid == packageId && !(a.IsDeleted)).ToList();
            if (sale.Count > 0)
                totalSale = sale.Sum(x => x.Amount);
            return totalSale;
        }

        public Sale GetSaleBySaleId(int saleId)
        {
            return _dbContext.Sales.FirstOrDefault(x => x.SaleID == saleId && !(x.IsDeleted));
        }

        public List<Sale> GetSaleListByProject(int projectId)
        {
            return _dbContext.Sales.Where(a => a.ProjectXid == projectId && !(a.IsDeleted)).ToList();
        }

        public List<Sale> GetSalesByPackage(int projectId, int packageId)
        {
            var sales = _dbContext.Sales.Where(a => a.PackageXid == packageId && a.ProjectXid == projectId && !(a.IsDeleted)).ToList();
            return sales;
        }

        public List<Package> GetSalePackagesByBidder(int projectId, int bidderId)
        {
            var saleList = _dbContext.Sales.Where(a => a.ProjectXid == projectId && a.BidderXid == bidderId && !(a.IsDeleted)).Select(b => b.PackageXid).ToList();
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var packages = GetPackagesByProjectId(projectId).ToList();
            var regularPackages = packages.Where(i => saleList.Contains(i.PackageXid) && (i.Price > 0 || i.Price == null) && i.MobileBiddingTypeID == regularPackageType).ToList();
            var salePackages = packages.Where(i => saleList.Contains(i.PackageXid) && i.Price > 0 && i.MobileBiddingTypeID != regularPackageType).ToList();
            return regularPackages.Union(salePackages).ToList();
        }

        public List<Package> GetRegularSalePackagesByDifferentBidder(int projectId, int bidderId)
        {   
            var saleList = _dbContext.Sales.Where(a => a.ProjectXid == projectId && a.BidderXid != bidderId && !(a.IsDeleted)).Select(b => b.PackageXid).ToList();
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            return GetPackagesByProjectId(projectId).Where(i => saleList.Contains(i.PackageXid) && (i.Price > 0 || i.Price == null) && i.MobileBiddingTypeID == regularPackageType).ToList();
        }

        public List<Package> GetCurrentlyOpenRegularPackagesByProject(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == regularPackageType && i.StartTimeUTC < currentDateTime && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null) && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetCurrentlyOpenMultiSalePackagesByProject(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var giversPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == giversPackageType && i.StartTimeUTC < currentDateTime && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null) && i.MaxAvailable > 0 && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetPackagesWithCloseTimeFutureByProject(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var project = GetProject(projectId);
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.PackageXid != project.DonationPackageXid && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null) && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetPackagesWithCloseTimePastByProject(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var project = GetProject(projectId);
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.PackageXid != project.DonationPackageXid && i.EndTimeUTC < currentDateTime && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetOpeningPackagesByProject(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var project = GetProject(projectId);
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.PackageXid != project.DonationPackageXid && i.StartTimeUTC > currentDateTime && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetOpeningSoonRegularPackagesByProject(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.StartTimeUTC > currentDateTime && i.MobileBiddingTypeID == regularPackageType && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetOpeningSoonRegularMultisalePackagesByProject(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var multisalePackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.StartTimeUTC > currentDateTime && (i.MobileBiddingTypeID == regularPackageType || i.MobileBiddingTypeID == multisalePackageType) && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetOpeningSoonPackagesByProject(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.StartTimeUTC > currentDateTime && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetRegularPackagesByProject(int projectId)
        {
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == regularPackageType && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetMultiSalePackagesByProject(int projectId)
        {
            var giversPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == giversPackageType && (!i.IsDeleted)).ToList();
        }

        public List<Package> GetBidderMultisalePackagesByProject(int projectId, int bidderId)
        {
            var saleList = _dbContext.Sales.Where(a => a.ProjectXid == projectId && a.BidderXid == bidderId && !(a.IsDeleted)).Select(b => b.PackageXid).ToList();
            var giversPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            return GetPackagesByProjectId(projectId).Where(i => i.MobileBiddingTypeID == giversPackageType && saleList.Contains(i.PackageXid) && i.Price > 0).ToList();
        }

        public List<Package> GetBidderDonationPackagesByProject(int projectId, int bidderId)
        {
            var saleList = _dbContext.Sales.Where(a => a.ProjectXid == projectId && a.BidderXid == bidderId && !(a.IsDeleted)).Select(b => b.PackageXid).ToList();
            var donationPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;
            return GetPackagesByProjectId(projectId).Where(i => i.MobileBiddingTypeID == donationPackageType && saleList.Contains(i.PackageXid)).ToList();
        }

        public List<Package> GetDonationPackagesByProject(int projectId)
        {
            var project = GetProject(projectId);
            var donationPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;
            return _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.PackageXid != project.DonationPackageXid && i.MobileBiddingTypeID == donationPackageType).ToList();
        }

        public List<Package> GetPackagesByProject(int projectId, int browsePageSortOrder)
        {
            var getPackages = GetPackagesByProjectId(projectId);
            return GetPackagesWithSortOrder(getPackages, projectId, browsePageSortOrder);
        }
        
        public List<Package> GetPackagesWithSortOrder(List<Package> Packages, int projectId, int browsePageSortOrder, bool isAdmin = false)
        {
            var classList = new List<Class>();

            if (isAdmin)
                classList = GetAllClassesByProject(projectId);
            else
                classList = GetActiveClasses(projectId);

            var sortedPackages = new List<Package>();

            var getPackageCategoryDetails = (from packages in Packages.AsEnumerable()
                                             join category in classList on packages.ClassId equals category.ClassID
                                             orderby category.ClassName
                                             select new { packages }).ToList();

            List<Package> getPackageswithnullclassname = (from packages in Packages.AsEnumerable()
                                                          where packages.ClassId == null
                                                          select packages).ToList();

            var browserPageSortOrderNumber = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BrowsePageSortOrderType, CodeLookupConstants.CodeBPSType_Number).CodeValue;
            if (browsePageSortOrder == browserPageSortOrderNumber)
            {
                var getPackageNumber = getPackageCategoryDetails.Select(x => x.packages.Number);
                var getNullClassPackageNumber = getPackageswithnullclassname.Select(x => x.Number);
                var resultPackageNumbers = getPackageNumber.Union(getNullClassPackageNumber).ToArray();

                Array.Sort(resultPackageNumbers, new AlphanumComparatorFast());

                foreach (var packageNumber in resultPackageNumbers)
                {
                    var package = Packages.FirstOrDefault(x => x.Number == packageNumber);
                    sortedPackages.Add(package);
                }
            }
            else
            {
                var arrayCategoriesSortByClassName = getPackageCategoryDetails.Select(x => x.packages.Class.ClassName).Distinct().ToList();

                foreach (var category in arrayCategoriesSortByClassName)
                {
                    var packageNumberArray = getPackageCategoryDetails.Where(x => x.packages.Class.ClassName == category).Select(x => x.packages.Number).ToArray();
                    Array.Sort(packageNumberArray, new AlphanumComparatorFast());

                    foreach (var package in packageNumberArray)
                        sortedPackages.Add(Packages.FirstOrDefault(x => x.Number == package));
                }
                sortedPackages.AddRange(getPackageswithnullclassname);
            }

            Packages = sortedPackages;

            return Packages;
        }

        public List<CodeLookup> GetCodeLookupListByType(string type)
        {
            return _dbContext.CodeLookups.Where(x => x.CodeType == type).ToList();
        }

        public List<DisplayLookup> GetDisplayLookupListByType(string type)
        {
            return _dbContext.DisplayLookups.Where(x => x.DisplayType == type).ToList();
        }


        public DisplayLookup GetDisplayLookupByTypeCode(string type, string code)
        {
            return _dbContext.DisplayLookups.Where(x => x.DisplayType == type && x.DisplayCode == code).FirstOrDefault();
        }

        public CodeLookup GetCodeLookupByTypeDescription(List<CodeLookup> codeLookupList, string description)
        {
            return codeLookupList.Where(x => x.CodeDescription.ToLower() == description.ToLower()).FirstOrDefault();
        }

        public CodeLookup GetCodeLookupByTypeDescription(string type, string description)
        {
            return _dbContext.CodeLookups.Where(x => x.CodeType == type && x.CodeDescription.ToLower() == description.ToLower()).FirstOrDefault();
        }

        public CodeLookup GetCodeLookupByValue(string type, byte? value)
        {
            return _dbContext.CodeLookups.Where(x => x.CodeType == type && x.CodeValue == value).FirstOrDefault();
        }

        public string GetCodeLookupName(string codeLookupType, byte? codeLookupValue)
        {
            if (codeLookupValue != null)
            {
                if (codeLookupType == CodeLookupConstants.CodeType_MobileBiddingType)
                {
                    var codeLookupName = GetCodeLookupByValue(CodeLookupConstants.CodeType_MobileBiddingType, codeLookupValue).CodeDescription;
                    return codeLookupName;
                }
                else if (codeLookupType == CodeLookupConstants.CodeType_LeaderboardStyleType)
                {
                    var codeLookupName = GetCodeLookupByValue(CodeLookupConstants.CodeType_LeaderboardStyleType, codeLookupValue).CodeDescription;
                    return codeLookupName;
                }
                else if (codeLookupType == CodeLookupConstants.CodeType_LeaderboardThemeType)
                {
                    var codeLookupName = GetCodeLookupByValue(CodeLookupConstants.CodeType_LeaderboardThemeType, codeLookupValue).CodeDescription;
                    return codeLookupName;
                }
            }
            return string.Empty;
        }

        public byte? GetCodeLookupValue(string codeLookupString, string codeLookupType)
        {
            if (codeLookupString != null)
            {
                if (codeLookupType == CodeLookupConstants.CodeType_MobileBiddingType)
                {
                    var codeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, codeLookupString).CodeValue;
                    return (byte)codeValue;
                }
                else if (codeLookupType == CodeLookupConstants.CodeType_WinningBidderDetailType)
                {
                    var codeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_WinningBidderDetailType, codeLookupString).CodeValue;
                    return (byte)codeValue;
                }
                else if (codeLookupType == CodeLookupConstants.CodeType_BrowsePageSortOrderType)
                {
                    var codeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BrowsePageSortOrderType, codeLookupString).CodeValue;
                    return (byte)codeValue;
                }
                else if (codeLookupType == CodeLookupConstants.CodeType_LeaderboardThemeType)
                {
                    var codeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_LeaderboardThemeType, codeLookupString).CodeValue;
                    return (byte)codeValue;
                }
                else if (codeLookupType == CodeLookupConstants.CodeType_LeaderboardStyleType)
                {
                    var codeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_LeaderboardStyleType, codeLookupString).CodeValue;
                    return (byte)codeValue;
                }
                else if (codeLookupType == CodeLookupConstants.CodeType_SMSDeliveryStatusesType)
                {
                    var codeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SMSDeliveryStatusesType, codeLookupString).CodeValue;
                    return (byte)codeValue;
                }
            }
            return null;
        }

        public DisplayLookup GetDisplayLookupByTypeCode(List<DisplayLookup> displayLookupList, string displayCode)
        {
            return displayLookupList.Where(x => x.DisplayCode == displayCode).FirstOrDefault();
        }

        public Bidder GetBidderByBidderKey(string bidderKey)
        {
            return _dbContext.Bidders.FirstOrDefault(i => i.OnlineBidderKey == bidderKey && (!i.IsDeleted));
        }

        public int GetCurrentBidderIdByBidderKey()
        {
            int bidderId = 0;
            if (CurrentBidder.OnlineBidderKey != null)
            {
                bidderId = GetBidderByBidderKey(CurrentBidder.OnlineBidderKey).BidderXid;
            }

            return bidderId;
        }

        public List<BidderList> GetFavoritesByBidder(int projectId, int bidderId)
        {
            var codeLookupList = GetCodeLookupListByType(CodeLookupConstants.CodeType_BidderListType);
            int value = GetCodeLookupByTypeDescription(codeLookupList, CodeLookupConstants.CodeBidderListType_Favorites).CodeValue;
            return _dbContext.BidderLists.Where(i => i.ProjectXid == projectId && i.BidderXid == bidderId && i.ListType == value).ToList();
        }

        public Package CurrentlyOpenRegularPackage(int packageId)
        {
            var currentDateTime = DateTime.UtcNow;
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            return _dbContext.Packages.FirstOrDefault(i => i.PackageXid == packageId && i.MobileBiddingTypeID == regularPackageType && i.StartTimeUTC < currentDateTime && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null) && (!i.IsDeleted));
        }

        public Package CurrentlyOpenMultiSalePackage(int packageId)
        {
            var currentDateTime = DateTime.UtcNow;
            var giversPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            return _dbContext.Packages.FirstOrDefault(i => i.PackageXid == packageId && i.MobileBiddingTypeID == giversPackageType && i.Price > 0 && (i.MaxAvailable > 0 || i.MaxAvailable == null) && i.StartTimeUTC < currentDateTime && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null) && (!i.IsDeleted));
        }

        public Package CurrentlyOpenDonationPackage(int packageId)
        {
            var currentDateTime = DateTime.UtcNow;
            var donationPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;
            return _dbContext.Packages.FirstOrDefault(i => i.PackageXid == packageId && i.MobileBiddingTypeID == donationPackageType && i.Price > 0 && i.StartTimeUTC < currentDateTime && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null) && (!i.IsDeleted));
        }

        public Package GetAppealDonationPackage(int packageId)
        {
            var appealPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Appeal).CodeValue;
            return _dbContext.Packages.FirstOrDefault(i => i.PackageXid == packageId && i.MobileBiddingTypeID == appealPackageType && (!i.IsDeleted));
        }

        public Bidder GetCurrentBidderByBidderKey()
        {
            Bidder bidder = new Bidder();

            if (CurrentBidder.OnlineBidderKey != null)
            {
                bidder = GetBidderByBidderKey(CurrentBidder.OnlineBidderKey);
            }

            return bidder;
        }

        public List<Bid> GetBidsByPackageId(int packageId)
        {
            return _dbContext.Bids.Where(i => i.PackageXid == packageId && !(i.IsDeleted) && !(i.Canceled)).OrderByDescending(a => a.Amount).ToList();
        }

        public List<BidderList> GetBidderMaxBidByPackage(int projectId, int packageid, int listType)
        {
            return _dbContext.BidderLists.Where(i => i.ProjectXid == projectId && i.PackageXid == packageid && i.ListType == listType && i.MaxBidAmount != null).OrderByDescending(a => a.MaxBidAmount).ToList();
        }

        /// <summary>
        /// Used to check the passed date is valid sql date time
        /// </summary>
        /// <param name="dateTimeToVerify">dateTimeToVerify</param>
        /// <returns>true or false</returns>
        public bool IsValidSqlDateTime(DateTime dateTimeToVerify)
        {
            dateTimeToVerify = DateTime.Parse(dateTimeToVerify.ToString(AppConstants.UTCDateTimeFormat));
            DateTime minValue = DateTime.Parse(SqlDateTime.MinValue.Value.ToString(AppConstants.UTCDateTimeFormat));

            return (dateTimeToVerify < minValue) ? false : true;
        }

        public List<BidderList> GetPackageCurrentMaxBidByProject(int projectId)
        {
            var maxBidType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderListType, CodeLookupConstants.CodeBidderListType_MaxBid).CodeValue;
            var maxBids = _dbContext.BidderLists.Where(i => i.ProjectXid == projectId && i.ListType == maxBidType && i.MaxBidAmount != null).GroupBy(a => a.PackageXid, (key, b) => b.OrderByDescending(x => x.MaxBidAmount).FirstOrDefault()).ToList();
            return maxBids;
        }

        public void ClearMaxBidByPackage(int projectId, int packageId, int eventType)
        {
            var maxBidListType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderListType, CodeLookupConstants.CodeBidderListType_MaxBid).CodeValue;
            var maxBidActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_MaxBid).CodeValue;

            var maxBidRecordsByPackage = _dbContext.BidderLists.Where(x => x.ProjectXid == projectId && x.PackageXid == packageId && x.ListType == maxBidListType).ToList();

            foreach (BidderList bidderlist in maxBidRecordsByPackage)
            {
                _dbContext.BidderLists.Remove(bidderlist);
                BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
                {
                    ProjectXid = bidderlist.ProjectXid,
                    BidderXid = bidderlist.BidderXid,
                    PackageXid = bidderlist.PackageXid,
                    BidderActionType = maxBidActionType,
                    EventType = eventType
                };
                AddBidSaleLog(bidSaleLogInfo);
            }
        }

        public void ClearMaxBidsAndFavorites(List<BidderList> bidderLists, int eventType)
        {           
            var maxBidActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_MaxBid).CodeValue;
            var favoritesActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Favorites).CodeValue;

            foreach (BidderList bidderlist in bidderLists)
            {
                _dbContext.BidderLists.Remove(bidderlist);
                BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
                {
                    ProjectXid = bidderlist.ProjectXid,
                    BidderXid = bidderlist.BidderXid,
                    PackageXid = bidderlist.PackageXid,
                    BidderActionType = (bidderlist.ListType == maxBidActionType) ? maxBidActionType : favoritesActionType,
                    EventType = eventType
                };
                AddBidSaleLog(bidSaleLogInfo);
            }
        }

        public void UpdateEventStatisticsReport(int projectXid)
        {
            List<SqlParameter> paramValues = new List<SqlParameter>();
            paramValues.Add(new SqlParameter("@ProjectXid", projectXid));
            _dbContext.ExecuteSQLCommand("exec SP_UpdateEventStatisticsReport @ProjectXid", paramValues.ToArray());
        }

        public void AddBidSaleLog(BidSaleLogInfo bidSaleLogInfo)
        {
            HttpContext context = HttpContext.Current;
            HttpBrowserCapabilities capability = context.Request.Browser;
            var browserName = capability.Browser;
            var version = capability.Version;
            var deviceType = capability.IsMobileDevice ? capability.MobileDeviceModel : capability.Platform;

            BidSaleLog bidSaleLog = new BidSaleLog();
            bidSaleLog.ProjectXid = bidSaleLogInfo.ProjectXid;
            bidSaleLog.BidderXid = bidSaleLogInfo.BidderXid;
            bidSaleLog.PackageXid = bidSaleLogInfo.PackageXid;
            bidSaleLog.BidXid = bidSaleLogInfo.BidXid;
            bidSaleLog.SaleID = bidSaleLogInfo.SaleID;
            bidSaleLog.BidderActionType = bidSaleLogInfo.BidderActionType;
            bidSaleLog.BidAmount = bidSaleLogInfo.BidAmount;
            bidSaleLog.QtyPurchased = bidSaleLogInfo.QtyPurchased;
            bidSaleLog.EventType = bidSaleLogInfo.EventType;
            bidSaleLog.BidActionDate = DateTime.UtcNow;
            bidSaleLog.BrowserName = browserName;
            bidSaleLog.Version = version;
            bidSaleLog.DeviceType = deviceType;
            _dbContext.BidSaleLogs.Add(bidSaleLog);
        }

        #region Admin

        public List<Bidder> GetBidderByProjectIdForAdmin(int projectid)
        {
            var bidders = _dbContext.Bidders.Where(i => i.ProjectXid == projectid).ToList();
            return bidders;
        }

        public Project GetProjectForAdmin(int projectid)
        {
            var project = _dbContext.Projects.FirstOrDefault(i => i.ProjectXid == projectid);
            return project;
        }

        public List<Package> GetPackagesByProjectIdForAdmin(int projectid)
        {
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectid).ToList();
            return packages;
        }

        public List<Package> GetOpenPackagesByProjectForAdmin(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var project = GetProject(projectId);
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.StartTimeUTC < currentDateTime && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null)).ToList();
            return packages;
        }

        public List<Package> GetOpeningSoonPackagesByProjectForAdmin(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.StartTimeUTC > currentDateTime).ToList();
            return packages;
        }

        public List<Package> GetOpeningSoonRegularPackagesByProjectForAdmin(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.StartTimeUTC > currentDateTime && i.MobileBiddingTypeID == regularPackageType).ToList();
            return packages;
        }

        public List<Package> GetNoBidPackagesByProjectForAdmin(int projectId)
        {
            var bidList = _dbContext.Bids.Where(a => a.ProjectXid == projectId && !(a.IsDeleted) && !(a.Canceled)).Select(b => b.PackageXid).ToList();
            var packages = GetPackagesByProjectIdForAdmin(projectId).Where(i => !bidList.Contains(i.PackageXid)).ToList();
            return packages;
        }

        public List<Package> GetNoSalePackagesByProjectForAdmin(int projectId)
        {
            var saleList = _dbContext.Sales.Where(a => a.ProjectXid == projectId).Select(b => b.PackageXid).ToList();
            var packages = GetPackagesByProjectIdForAdmin(projectId).Where(i => !saleList.Contains(i.PackageXid)).ToList();
            return packages;
        }

        public List<Package> GetOpenRegularPackagesByProjectForAdmin(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == regularPackageType && i.StartTimeUTC < currentDateTime && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null)).ToList();
            return packages;
        }

        public List<Package> GetOpenMultiSalePackagesByProjectForAdmin(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;
            var giversPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == giversPackageType && i.StartTimeUTC < currentDateTime && (i.EndTimeUTC >= currentDateTime || i.EndTimeUTC == null) && i.MaxAvailable > 0).ToList();
            return packages;
        }

        public List<Package> GetRegularPackagesByProjectForAdmin(int projectId)
        {
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == regularPackageType).ToList();
            return packages;
        }

        public List<Package> GetSalePackagesByProjectForAdmin(int projectId)
        {
            var saleList = _dbContext.Sales.Where(a => a.ProjectXid == projectId && (!a.IsDeleted)).Select(b => b.PackageXid).ToList();
            var packages = GetPackagesByProjectIdForAdmin(projectId).Where(i => saleList.Contains(i.PackageXid)).ToList();
            return packages;
        }

        public List<Package> GetMultiSalePackagesByProjectForAdmin(int projectId)
        {
            var giversPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == giversPackageType).ToList();
            return packages;
        }

        public List<Package> GetDonationPackagesByProjectForAdmin(int projectId)
        {
            var project = GetProject(projectId);
            var donationPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;
            var packages = _dbContext.Packages.Where(i => i.ProjectXid == projectId && i.MobileBiddingTypeID == donationPackageType).ToList();
            return packages;
        }

        public List<Class> GetAllClassesByProject(int projectid)
        {
            var classes = _dbContext.Class.Where(i => i.ProjectXid == projectid).ToList();
            return classes;
        }

        public List<Bid> GetBidsByProjectForAdmin(int projectId)
        {
            var deletedBids = _dbContext.BidDeletedHistories.Where(x => x.ProjectXid == projectId).ToList();
            var bids = _dbContext.Bids.Where(i => i.ProjectXid == projectId).ToList();
            bids = GetBidsWithBidDeletedHistoryForAdmin(bids, deletedBids);
            return bids;
        }

        public List<Bid> GetBidsWithBidDeletedHistoryForAdmin(List<Bid> bids, List<BidDeletedHistory> bidDeletedHistories)
        {
            List<Bid> bidDeletedList = new List<Bid>();
            foreach (var bid in bidDeletedHistories)
            {
                Bid bidDeleted = new Bid();
                bidDeleted.BidXid = bid.BidXid;
                bidDeleted.BidderXid = bid.BidderXid;
                bidDeleted.ProjectXid = bid.ProjectXid;
                bidDeleted.PackageXid = bid.PackageXid;
                bidDeleted.Amount = bid.Amount;
                bidDeleted.BidType = bid.BidType;
                bidDeleted.Canceled = bid.Canceled;
                bidDeleted.IsDeleted = bid.IsDeleted;
                bidDeleted.CreatedDate = bid.CreatedDate;
                bidDeleted.UpdatedDate = bid.UpdatedDate;
                bidDeletedList.Add(bidDeleted);
            }
            bids = bids.Union(bidDeletedList).ToList();

            return bids;
        }

        public Bidder GetBidderForAdmin(int bidderid, int projectid)
        {
            return _dbContext.Bidders.FirstOrDefault(i => i.BidderXid == bidderid && i.ProjectXid == projectid);
        }

        public Package GetPackageForAdmin(int packageid, int projectId)
        {
            return _dbContext.Packages.FirstOrDefault(i => i.PackageXid == packageid && i.ProjectXid == projectId);
        }

        public Sponsor GetSponsorForAdmin(int sponsorid, int projectid)
        {
            return _dbContext.Sponsors.FirstOrDefault(i => i.SponsorXid == sponsorid && i.ProjectXid == projectid);
        }

        public List<Bid> GetBidsByPackageForAdmin(int projectId, int packageId)
        {
            var deletedBids = _dbContext.BidDeletedHistories.Where(x => x.ProjectXid == projectId && x.PackageXid == packageId).ToList();
            var bids = _dbContext.Bids.Where(i => i.ProjectXid == projectId && i.PackageXid == packageId).ToList();
            bids = GetBidsWithBidDeletedHistoryForAdmin(bids, deletedBids);
            return bids;
        }

        public List<Sale> GetSaleListByProjectForAdmin(int projectId)
        {
            return _dbContext.Sales.Where(a => a.ProjectXid == projectId).ToList();
        }

        public Bid GetBidByBidIdForAdmin(int bidId, int projectId)
        {
            var bid = _dbContext.Bids.FirstOrDefault(i => i.BidXid == bidId && i.ProjectXid == projectId && !(i.IsDeleted) && !(i.Canceled));
            return bid;
        }

        public Sale GetSaleBySaleIdForAdmin(int saleId, int projectId)
        {
            return _dbContext.Sales.FirstOrDefault(x => x.SaleID == saleId && x.ProjectXid == projectId && !(x.IsDeleted));
        }

        /// <summary>
        /// TransactionCommitOrRollback
        /// </summary>        
        /// <param name="transaction">transaction</param>
        /// <param name="resultCount">resultCount</param>
        /// <returns></returns>
        public void TransactionCommitOrRollback(DbContextTransaction transaction, int resultCount)
        {
            // Transaction will always be null for Unit Test.
            if (transaction != null)
            {
                if (resultCount > 0)
                    transaction.Commit();               
            }
            AzureSqlConfiguration.SuspendExecutionStrategy = false;
        }

        public List<EmailTemplate> GetEmailTemplatesByProject(int projectId)
        {
            var emailTemplates = _dbContext.EmailTemplates.Where(a => a.ProjectXid == projectId).ToList();
            return emailTemplates;
        }

        public EmailTemplate GetEmailTemplate(int projectId, int emailTemplateId)
        {
            var emailTemplate = _dbContext.EmailTemplates.Where(a => a.ProjectXid == projectId && a.EmailTemplateID == emailTemplateId).FirstOrDefault();
            return emailTemplate;
        }

        public List<SMSTemplate> GetSMSTemplatesByProject(int projectId)
        {
            var smsTemplates = _dbContext.SMSTemplates.Where(a => a.ProjectXid == projectId).ToList();
            return smsTemplates;
        }

        public SMSTemplate GetSMSTemplate(int projectId, int templateId)
        {
            var smsTemplate = _dbContext.SMSTemplates.Where(a => a.ProjectXid == projectId && a.SMSTemplateID == templateId).FirstOrDefault();
            return smsTemplate;
        }              

        private void InsertToBidDeletedHistoryAndRemoveFromBid(Bid bid)
        {
            BidDeletedHistory bidDeleted = new BidDeletedHistory();
            bidDeleted.BidXid = bid.BidXid;
            bidDeleted.BidderXid = bid.BidderXid;
            bidDeleted.ProjectXid = bid.ProjectXid;
            bidDeleted.PackageXid = bid.PackageXid;
            bidDeleted.Amount = bid.Amount;
            bidDeleted.BidType = bid.BidType;
            bidDeleted.Canceled = bid.Canceled;
            bidDeleted.IsDeleted = true;
            bidDeleted.CreatedDate = bid.CreatedDate;
            bidDeleted.UpdatedDate = DateTime.UtcNow;

            _dbContext.BidDeletedHistories.Add(bidDeleted);

            _dbContext.Bids.Remove(bid);
        }

        public void RemoveBid(Bid bid, int deleteEventType)
        {
            InsertToBidDeletedHistoryAndRemoveFromBid(bid);

            BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
            {
                ProjectXid = bid.ProjectXid,
                BidderXid = bid.BidderXid,
                PackageXid = bid.PackageXid,
                BidderActionType = bid.BidType,
                EventType = deleteEventType,
                BidAmount = bid.Amount,
                BidXid = bid.BidXid
            };

            AddBidSaleLog(bidSaleLogInfo);            
        }

        public void RemoveSale(Sale sale, int actionType, int eventType)
        {            
            sale.IsDeleted = true;
            sale.LastAttempted = DateTime.UtcNow;

            BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
            {
                ProjectXid = sale.ProjectXid,
                BidderXid = sale.BidderXid,
                PackageXid = sale.PackageXid,
                BidderActionType = actionType,
                EventType = eventType,
                BidAmount = sale.Amount,
                QtyPurchased = sale.QtyPurchased,
                SaleID = sale.SaleID
            };

            AddBidSaleLog(bidSaleLogInfo);
        }
       
        public void DeleteEmailTemplate(EmailTemplate emailTemplate)
        {
            _dbContext.EmailTemplates.Remove(emailTemplate);
        }

        public void DeleteSMSTemplate(SMSTemplate smsTemplate)
        {
            _dbContext.SMSTemplates.Remove(smsTemplate);
        }

        public List<Bid> GetBidsByBidder(int projectId, int bidderId)
        {
            var bids = _dbContext.Bids.Where(i => i.BidderXid == bidderId && i.ProjectXid == projectId && !(i.IsDeleted) && !(i.Canceled)).ToList();
            return bids;
        }

        public List<Sale> GetSalesByBidder(int projectId, int bidderId)
        {
            var sales = _dbContext.Sales.Where(i => i.BidderXid == bidderId && i.ProjectXid == projectId && !(i.IsDeleted)).ToList();
            return sales;
        }

        public void RemovePackageBids(Package package, int deleteEventType)
        {
            var packageBids = GetBidsByPackage(package.ProjectXid, package.PackageXid);
            var regularPackageSale = GetSalesByPackage(package.ProjectXid, package.PackageXid).FirstOrDefault();

            foreach (var bid in packageBids)
            {
                RemoveBid(bid, deleteEventType);                                            /* remove bid */

                if (regularPackageSale != null && bid.Amount == regularPackageSale.Amount)
                {
                    RemoveSale(regularPackageSale, (int)bid.BidType, deleteEventType);      /* remove sale for regular package */

                    package.IsSaleCreated = null;                                           /*update package IsSaleCreated to null for the regular package */
                }
            }
        }

        public void RemovePackageSales(Package package, List<CodeLookup> packageTypes, Project project, int deleteEventType)
        {
            var multiSalePackageType = GetCodeLookupByTypeDescription(packageTypes, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            var appealPackageType = GetCodeLookupByTypeDescription(packageTypes, CodeLookupConstants.CodeMobileBiddingType_Appeal).CodeValue;
            var donationPackageType = GetCodeLookupByTypeDescription(packageTypes, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;

            var packageSales = GetSalesByPackage(package.ProjectXid, package.PackageXid);

            var buyActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Buy).CodeValue;
            var donationActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Donation).CodeValue;
            var appealActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Donation).CodeValue;

            foreach (Sale sale in packageSales)
            {
                /* MultiSale Packages */
                if (package.MobileBiddingTypeID == multiSalePackageType)
                {
                    RemoveSale(sale, buyActionType, deleteEventType);

                    /* update Purchased Quantity and  Remaining Quantity for the package*/
                    int purchasedQuantity = (sale.QtyPurchased ?? 0);
                    package.QtyPurchased = (package.QtyPurchased ?? 0) - purchasedQuantity;

                    if (package.MaxAvailable != null)
                        package.QtyRemaining = (package.QtyRemaining ?? 0) + purchasedQuantity;
                }

                /* Donation package */
                if (package.MobileBiddingTypeID == donationPackageType)
                {
                    RemoveSale(sale, donationActionType, deleteEventType);
                }

                /* Appeal package */
                if (package.MobileBiddingTypeID == appealPackageType)
                {
                    RemoveSale(sale, appealActionType, deleteEventType);
                    project.DonationPackageXid = 0;  /* Reset appeal package in project */
                    project.AppealTotalRaised = 0;   /* Reset appeal package total raised value in project */
                }
            }
        }

        public EventStatistics GetEventStatistics(int projectId)
        {
            var eventstatisticsByProject = _dbContext.Eventstatistics.FirstOrDefault(x=>x.ProjectXid == projectId);
            return eventstatisticsByProject;
        }

        #endregion Admin
    }
}
