﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Entities.Output;
using CommonUtil = GreaterGiving.Tokyo.Common.Reusables;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding
{
    public class BiddingPackage : BiddingBase
    {
        /// <summary>
        /// BiddingPackage Constructor for setting the context
        /// </summary>
        /// <param name="context"></param>
        public BiddingPackage(IBiddingContext context) : base(context)
        { }

        /// <summary>
        /// Gets all the Packages using Prefix value
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> GetAllPackages(string prefix)
        {
            var result = new List<PackageOutput>();
            var project = GetProjectByPrefix(prefix);

            if (project == null) { return result; }

            foreach (var package in GetPackagesByProject(project.ProjectXid, (int)project.BrowsePageSortOrder))
            {
                var packageoutput = MapModel(package, project);
                result.Add(packageoutput);
                Logger.WriteDebugLog(string.Format("Method: GetAllPackages Prefix {0},PackageXid {1} is added to the list", prefix, packageoutput.PackageXid));
            }
            result = UpdatePackageStatus(result, project.ProjectXid);

            return result;
        }

        /// <summary>
        /// Gets the Related Packages with PackageXid
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="PackageXid">PackageXid</param>  
        /// <param name="displayedPackages">displayedPackages</param> 
        /// <returns></returns>
        public List<PackageOutput> GetRelatedPackages(string prefix, int packageXid, string displayedPackages)
        {
            var result = new List<PackageOutput>();

            var bidderId = GetCurrentBidderIdByBidderKey();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return result; }

            var package = GetPackage(packageXid, project.ProjectXid);
            if (package == null) { return result; }

            if (displayedPackages == null)
                displayedPackages = string.Empty;

            if (package.ClassId == null)
                return result;
            
            var soldPackageList = SoldPackagesFilter(project.ProjectXid, bidderId);

            var closedPackageList = ClosedPackagesFilter(project.ProjectXid);

            var wonPackageList = WonPackagesFilter(project.ProjectXid, bidderId);

            var alreadyDisplayed = displayedPackages.Split(',').Select((s, i) => int.TryParse(s, out i) ? i : 0);

            var getRelatedPackages = _dbContext.Packages.Where(x => x.ClassId == package.ClassId && x.ProjectXid == package.ProjectXid && x.PackageXid != project.DonationPackageXid  && x.PackageXid != packageXid && (!x.IsDeleted)).ToList();

            //Remove Sold Packages from Related packages
            getRelatedPackages = getRelatedPackages.Where(x => !soldPackageList.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            //Remove Closed Packages from Related packages
            getRelatedPackages = getRelatedPackages.Where(x => !closedPackageList.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            //Remove Won Packages from Related packages
            getRelatedPackages = getRelatedPackages.Where(x => !wonPackageList.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            var getRelatedPackagesExcludeDisplayed = getRelatedPackages.Where(x => !alreadyDisplayed.Contains(x.PackageXid)).ToList();

            if (getRelatedPackagesExcludeDisplayed.Count == 1)
            {
                result.Add(MapModel(getRelatedPackagesExcludeDisplayed.FirstOrDefault(), project));
            }
            else
            {
                getRelatedPackages = getRelatedPackagesExcludeDisplayed.Count == 0 ? getRelatedPackages : getRelatedPackagesExcludeDisplayed;
            }

            foreach (var packageDetail in getRelatedPackages)
            {
                if (result.Count < 2 && !result.Select(x => x.PackageXid).Contains(packageDetail.PackageXid))
                {
                    result.Add(MapModel(packageDetail, project));
                }
            }

            result = UpdatePackageStatus(result, project.ProjectXid);

            return result;
        }

        /// <summary>
        /// Gets Appeal Donation Package
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>PackageOutput</returns>
        public PackageOutput GetAppealDonationPackage(string prefix)
        {
            var result = new PackageOutput();
            var project = GetProjectByPrefix(prefix);

            if (project == null) { return result; }

            var package = GetPackage(project.DonationPackageXid, project.ProjectXid);

            if (package == null) { return result; }

            var packageoutput = MapModel(package, project);
            packageoutput.AppealGoal = project.AppealGoal;
            if (!string.IsNullOrWhiteSpace(project.AppealImagePath))
                packageoutput.AppealImagePath = ConfigManager.CdnProjectAssetsEndpoint + "/" + project.AppealImagePath;
            packageoutput.SuggestedDonationAmounts = GetSuggestedDonationAmounts(project.SuggestedDonationAmounts);
            packageoutput.DonationLabel = project.DonationLabel;
            packageoutput.TotalRaised = project.AppealTotalRaised ?? 0;
            result = packageoutput;
            return result;
        }

        /// <summary>
        /// Gets the Packages by packageIds
        /// </summary>
        /// <param name="prefix">prefix</param>   
        /// <param name="packageIds">packageIds</param>        
        /// <returns></returns>
        public PackageOutput GetPackagebyPackageId(string prefix, int packageXid)
        {
            var result = new PackageOutput();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return result; }

            var package = GetPackage(packageXid, project.ProjectXid);
            if (package == null) { return result; }

            result = MapModel(package, project);
            var packageList = new List<PackageOutput>();
            packageList.Add(result);
            result = UpdatePackageStatus(packageList, package.ProjectXid).FirstOrDefault();

            return result;
        }

        public Package GetPackagebyPackageId(int packageXid)
        {
            return GetPackage(packageXid);
        }

        /// <summary>
        /// Gets the Packages with Page No and Size
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageNo">pageNo</param>
        /// <param name="pageSize">pageSize</param>
        /// <returns></returns>
        public List<PackageOutput> GetPackages(string prefix, int pageNo, int pageSize, string packageFilterType)
        {
            var project = GetProjectByPrefix(prefix);
            List<PackageOutput> getPackages = new List<PackageOutput>();

            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_PackageFilterType);

            if (packageFilterType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_All).DisplayText)
            {
                getPackages = GetAllPackages(prefix);
            }
            else if (packageFilterType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_NoBids).DisplayText)
            {
                getPackages = NoBidPackagesFilter(project);
            }
            else if (packageFilterType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_CurrentlyOpen).DisplayText)
            {
                getPackages = CurrentlyOpenPackagesFilter(project);
            }
            else if (packageFilterType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_BuyNow).DisplayText)
            {
                getPackages = BuyNowPackagesFilter(project);
            }
            else if (packageFilterType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_Multisale).DisplayText)
            {
                getPackages = MultiSalePackagesFilter(project);
            }
            else if (packageFilterType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_PreviewOnly).DisplayText)
            {
                getPackages = PreviewOnlyPackagesFilter(project);
            }
            else if (packageFilterType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_OpeningSoon).DisplayText)
            {
                getPackages = OpeningSoonPackagesFilter(project);
            }

            return GetPackagesPerPageSize(getPackages, pageNo, pageSize);
        }

        /// <summary>
        /// Inserts or updates the package
        /// </summary>
        /// <param name="package">package</param>
        /// <returns>ResultModel</returns>
        public ResultModel AddOrUpdatePackage(PackageFieldValues package)
        {
            ResultModel result = new ResultModel();

            try
            {
                var project = GetProject(package.ProjectXid);
                if (project == null) { return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error002); }

                
                if (package.PackageXid == 0) { return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error003); }

                var packageTypeList = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
                var appealPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Appeal).CodeValue;
                var livePackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Live).CodeValue;

                var mobileBiddingTypeID = GetCodeLookupValue(package.MobileBiddingType, CodeLookupConstants.CodeType_MobileBiddingType);
                DateTime? packageStartTime = null;
                bool hasStartDateValid = false;
                if ((mobileBiddingTypeID == appealPackageType && project.DonationPackageXid == package.PackageXid) || (mobileBiddingTypeID == livePackageType)) // Check for appeal donation package or Preview only package
                {
                    //checks whether the date is a valid sql date
                    if (!IsValidSqlDateTime(package.StartTimeUTC))
                    {
                        int addDays = !string.IsNullOrEmpty(ConfigManager.AddDaysForPackageStartTime) ? Convert.ToInt32(ConfigManager.AddDaysForPackageStartTime) : 0;
                        packageStartTime = DateTime.UtcNow.AddDays(addDays); // Add 10 days past from current date for appeal donation package and preview only package
                    }
                    else
                    {
                        packageStartTime = package.StartTimeUTC;
                        hasStartDateValid = true;
                    }
                }

                var addupdatePackage = GetPackageForAdmin(package.PackageXid, package.ProjectXid);

                if (addupdatePackage != null)
                {
                    // Update Package
                    addupdatePackage.Name = package.Name;
                    addupdatePackage.Number = package.Number.Trim();
                    addupdatePackage.ClassId = GetClassIDbyName(package.ClassName, package.ProjectXid);
                    addupdatePackage.Description = package.Description;
                    addupdatePackage.RestrictionNotes = package.RestrictionNotes;
                    addupdatePackage.Donors = GetDonor(package.Donors);
                    if(package.Value.ToLower() == "priceless")
                        addupdatePackage.Value = "0.00";
                    else
                        addupdatePackage.Value = package.Value;
                    addupdatePackage.MinimumBid = package.MinimumBid;
                    addupdatePackage.MinimumRaise = package.MinimumRaise;
                    addupdatePackage.Price = package.Price;
                    addupdatePackage.MaxAvailable = package.MaxAvailable;
                    addupdatePackage.EndTimeUTC = package.EndTimeUTC;
                    if ((packageStartTime == null) || (hasStartDateValid))
                        addupdatePackage.StartTimeUTC = package.StartTimeUTC;
                    addupdatePackage.MobileBiddingTypeID = mobileBiddingTypeID;
                    var qtyRemaining = (package.MaxAvailable != null) ? (package.MaxAvailable - (addupdatePackage.QtyPurchased ?? 0)) : package.MaxAvailable;
                    addupdatePackage.QtyRemaining = (qtyRemaining < 0) ? 0 : qtyRemaining;
                    addupdatePackage.UpdatedDate = DateTime.UtcNow;

                    /*If Package Images is null all package images should be removed form package image table*/
                    if(package.Images == null)
                        RemovePackageImages(package.PackageXid);

                    var reenableFlag = false;
                    /* Re enable package */
                    if (addupdatePackage.IsDeleted)
                    {
                        addupdatePackage.IsDeleted = false;
                        reenableFlag = true;                        
                    }

                    var isUpdated = _dbContext.SaveChanges();

                    if (isUpdated > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        if (reenableFlag)
                            InsertPackageEventLog(addupdatePackage, CodeLookupConstants.CodeEventType_Reenable);
                    }
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info004);
                }
                else
                {
                    // Insert Package
                    var addnewPackage = new Package();
                    addnewPackage.PackageXid = package.PackageXid;
                    addnewPackage.ProjectXid = package.ProjectXid;
                    addnewPackage.Name = package.Name;
                    addnewPackage.Number = package.Number.Trim();
                    addnewPackage.ClassId = GetClassIDbyName(package.ClassName, package.ProjectXid);
                    addnewPackage.Description = package.Description;
                    addnewPackage.RestrictionNotes = package.RestrictionNotes;
                    addnewPackage.Donors = GetDonor(package.Donors);
                    if (package.Value.ToLower() == "priceless")
                        addnewPackage.Value = "0.00";
                    else
                        addnewPackage.Value = package.Value;
                    addnewPackage.MinimumBid = package.MinimumBid;
                    addnewPackage.MinimumRaise = package.MinimumRaise;
                    addnewPackage.Price = package.Price;
                    addnewPackage.MaxAvailable = package.MaxAvailable;
                    addnewPackage.EndTimeUTC = package.EndTimeUTC;
                    addnewPackage.StartTimeUTC = packageStartTime ?? package.StartTimeUTC;
                    addnewPackage.MobileBiddingTypeID = mobileBiddingTypeID;
                    addnewPackage.QtyRemaining = package.MaxAvailable;
                    addnewPackage.CreatedDate = DateTime.UtcNow;

                    _dbContext.Packages.Add(addnewPackage);
                    var isInserted = _dbContext.SaveChanges();

                    if (isInserted > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        InsertPackageEventLog(addnewPackage, CodeLookupConstants.CodeEventType_Insert);
                    }
                }

                Logger.WriteInfoLog(string.Format("Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
            }
            catch (Exception ex)
            {
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
            }

            return result;
        }

        /// <summary>
        /// Deletes the package details using PackageXId
        /// </summary>
        /// <param name="packageid">packageid</param>
        /// <returns>ResultModel</returns>
        public ResultModel DeletePackage(int packageid)
        {
            ResultModel result = new ResultModel();

            if (packageid == 0)
                return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error003);

            var deletePackage = GetPackage(packageid);
            if (deletePackage == null)
                return result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);

            var deleteEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Delete).CodeValue;
            var packageTypes = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
            
            //delete Package                    
            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    RemovePackage(deletePackage, packageTypes, deleteEventType);        /* Remove package and its bids, sales and maxbids */

                    var deletedCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, deletedCount);

                    if (deletedCount > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        InsertPackageEventLog(deletePackage, CodeLookupConstants.CodeEventType_Delete);
                    }
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);

                    Logger.WriteInfoLog(string.Format("Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
                }
                catch (Exception ex)
                {
                    int defaultResultCount = 0;  //By default ResultCount - 0 for Rollback
                    TransactionCommitOrRollback(transaction, defaultResultCount);
                    result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                    Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
                }
            }
            return result;
        }

        public void RemovePackage(Package package,List<CodeLookup> packageTypes, int deleteEventType)
        {
            var regularPackageType = GetCodeLookupByTypeDescription(packageTypes, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var previewPackageType = GetCodeLookupByTypeDescription(packageTypes, CodeLookupConstants.CodeMobileBiddingType_Live).CodeValue;

            package.IsDeleted = true;
            package.UpdatedDate = DateTime.UtcNow;

            RemovePackageImages(package.PackageXid);                                             /* Remove package image */
            RemovePackageCategory(package.PackageXid, package.ClassId);                          /* Remove package category */

            if (package.MobileBiddingTypeID == regularPackageType)
            {
                RemovePackageBids(package, deleteEventType);                                     /* Remove package bids */
            }
            else if (package.MobileBiddingTypeID != previewPackageType)
            {
                var project = GetProject(package.ProjectXid);
                if (project != null)
                {
                    RemovePackageSales(package, packageTypes, project, deleteEventType);        /* Remove package multisale, donation and appeal */
                }
            }

            RemovePackageMaxBidsAndFavorites(package, deleteEventType);                      /* Remove package maxbids and favorites */
        }

        public void RemovePackageMaxBidsAndFavorites(Package package, int deleteEventType)
        {           
            var bidderListByPackage = _dbContext.BidderLists.Where(x => x.ProjectXid == package.ProjectXid && x.PackageXid == package.PackageXid).ToList();
            ClearMaxBidsAndFavorites(bidderListByPackage, deleteEventType);
        }

        /// <summary>
        /// Updates the Packages time and item type
        /// </summary>
        /// <param name="package">package</param>
        /// <returns>ResultModel</returns>
        public ResultModel UpdateTimeAndItemTypeForPackages(BulkPackageFieldValues package)
        {
            ResultModel result = new ResultModel();
            try
            {
                var inputPackageList = package.BulkPackageFields.ToList();
                var actualPackageList = GetPackagesByProjectIdWithAppealDonation(package.ProjectXid);

                //if the packages dbcontext has data for that ProjectXid(input json)
                if (actualPackageList.Count > 0)
                {
                    //Used to check whether the packages exist in database(input Json array and Package DB Context).if exisit return true
                    bool checkExistingPackages = (inputPackageList.All(y => actualPackageList.Exists(w => w.PackageXid == y.PackageXid)));

                    //If all the package list exist in db
                    if (checkExistingPackages)
                    {
                        foreach (var checkPackage in package.BulkPackageFields)
                        {
                            var updateBulkPackages = actualPackageList.Where(x => x.PackageXid == checkPackage.PackageXid).FirstOrDefault();
                            updateBulkPackages.StartTimeUTC = checkPackage.StartTimeUTC;
                            updateBulkPackages.EndTimeUTC = checkPackage.EndTimeUTC;
                            updateBulkPackages.MobileBiddingTypeID = GetCodeLookupValue(checkPackage.MobileBiddingType, CodeLookupConstants.CodeType_MobileBiddingType);
                            updateBulkPackages.UpdatedDate = DateTime.UtcNow;
                        }

                        var isUpdated = _dbContext.SaveChanges();
                        if (isUpdated > 0)
                        {
                            result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        }
                        else
                        {
                            result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                        }
                    }
                    //If any one of the PackageXids doesnt exist in the database
                    else
                    {
                        var getOutputPackagesList = actualPackageList.Select(a => a.PackageXid).ToList();

                        //Used to get the missing packages List(input Json array and Package DB Context)
                        List<int> missingPackagesList = inputPackageList.Where(w => !getOutputPackagesList.Contains(w.PackageXid)).Select(b => b.PackageXid).ToList();

                        //Used to concatenate the missing packages with comma seperated package string
                        var missingPackages = string.Join(AppConstants.CommaDelimiter, missingPackagesList
                                              .Select(x => x.ToString())
                                               .ToArray());

                        Logger.WriteDebugLog(string.Format("Method: UpdateTimeAndItemTypeForPackages,No Records Updated,PackageXId missing: {0}", missingPackages));
                        result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error008, missingPackages);
                    }
                }
                //If the given Json input ProjectXid is null or invalid 
                else
                {
                    result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error002);
                }
            }
            catch (Exception ex)
            {
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
            }

            return result;
        }

        /// <summary>
        /// Gets Package Types by Project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>List<string></returns>
        public List<string> GetPackageTypesByProject(string prefix)
        {
            var project = GetProjectByPrefix(prefix);
            List<string> packageTypes = new List<string>();
            if (project != null)
            {
                var result = GetActNowLabelForPackage(project);
                if (result.Count > 0)
                    packageTypes.AddRange(result);
            }
            return packageTypes.ToList();
        }

        /// <summary>
        /// Gets Category types by project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>List<string></returns>

        public List<string> GetCategoryTypesByProject(string prefix)
        {
            var project = GetProjectByPrefix(prefix);
            List<string> categoryTypes = new List<string>();
            if (project != null)
            {
                var getPackageCategoryNameList = GetPackagesByProject(project.ProjectXid, (int)project.BrowsePageSortOrder).Where(a => a.Class != null).OrderBy(x => x.Class.ClassName).Select(a => a.Class.ClassName).Distinct().ToList();
                categoryTypes.AddRange(getPackageCategoryNameList);
                Logger.WriteDebugLog(string.Format("Method: GetCategoryTypesByProject Total No. of Category : {0} are added to the list", getPackageCategoryNameList.Count));
            }
            return categoryTypes;
        }

        /// <summary>
        /// Search Packages by package name or number
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageNo">pageNo</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="packageNameOrNumber">packageNameOrNumber</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> SearchPackagesByPackageNameOrNumber(string prefix, int pageNo, int pageSize, string packageNameOrNumber)
        {
            var result = new List<PackageOutput>();
            var project = GetProjectByPrefix(prefix);
            if (project != null)
            {
                foreach (var package in GetPackagesByProject(project.ProjectXid, (int)project.BrowsePageSortOrder).Where(i => (i.Name.ToLower().Contains(packageNameOrNumber.ToLower()) || i.Number.ToLower().Contains(packageNameOrNumber.ToLower()))))
                {
                    var packageoutput = MapModel(package, project);
                    result.Add(packageoutput);
                    Logger.WriteDebugLog(string.Format("Method: SearchPackagesByPackageNameOrNumber, PackageXid: {0} is added to the list", packageoutput.PackageXid));
                }
                result = UpdatePackageStatus(result, project.ProjectXid);
            }
            return GetPackagesPerPageSize(result, pageNo, pageSize);
        }

        /// <summary>
        /// Gets Packages by category name
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageNo">pageNo</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="categoryName">categoryName</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> GetPackagesByCategory(string prefix, int pageNo, int pageSize, string categoryName)
        {
            var result = new List<PackageOutput>();

            var project = GetProjectByPrefix(prefix);
            if (project != null)
            {
                foreach (var package in GetPackagesByProject(project.ProjectXid, (int)project.BrowsePageSortOrder).Where(i => i.Class != null && i.Class.ClassName == categoryName))
                {
                    var packageoutput = MapModel(package, project);
                    result.Add(packageoutput);
                    Logger.WriteDebugLog(string.Format("Method: GetPackagesByCategory, PackageXid: {0} is added to the list", packageoutput.PackageXid));
                }
                result = UpdatePackageStatus(result, project.ProjectXid);
            }
            return GetPackagesPerPageSize(result, pageNo, pageSize);
        }

        /// <summary>
        /// Update Package Status - Status Indicator
        /// </summary>
        /// <param name="packageOutput">packageOutput</param>
        /// <param name="projectId">projectId</param>
        /// <returns>List<PackageOutput></returns>
        private List<PackageOutput> UpdatePackageStatus(List<PackageOutput> packageOutput, int projectId)
        {
            // Favorite Status
            var bidderId = GetCurrentBidderIdByBidderKey();
            var bidderList = GetFavoritesByBidder(projectId, bidderId);
            var highBidList = GetHighBidsByProject(projectId);
            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_PackageStatusType);
            var saleList = GetSaleListByProject(projectId);
            var biddersInfoByProject = GetBidderByProjectId(projectId);

            // Package Status Indicator
            var resultPackages = new List<Package>();
            var outBidPackageList = new List<Package>();
            var winningPackageList = new List<Package>();
            var wonPackageList = new List<Package>();
            var soldPackageList = new List<Package>();
            var closedPackageList = new List<Package>();
            var openingPackageList = new List<Package>();

            soldPackageList = SoldPackagesFilter(projectId, bidderId);

            closedPackageList = ClosedPackagesFilter(projectId);

            openingPackageList = OpeningPackagesFilter(projectId);

            if (bidderId != 0)
            {
                outBidPackageList = OutBidPackagesFilter(projectId, bidderId);

                winningPackageList = WinningPackagesFilter(projectId, bidderId);

                wonPackageList = WonPackagesFilter(projectId, bidderId);
            }

            foreach (var package in packageOutput)
            {
                //Total Packages Count
                package.TotalCount = packageOutput.Count();

                var hasBid = highBidList.FirstOrDefault(x => x.PackageXid == package.PackageXid);
                var salePackage = saleList.FirstOrDefault(x => x.PackageXid == package.PackageXid);
                package.IsFavorite = bidderList.Any(x => x.PackageXid == package.PackageXid);
                if (salePackage != null)
                    package.CurrentHighBid = salePackage.Amount;
                else
                    package.CurrentHighBid = hasBid != null ? hasBid.Amount : 0;

                //get bidder name and number only for regular packages
                if (hasBid != null)
                {
                    package.IsBid = true;
                    var bidderInfo = biddersInfoByProject.FirstOrDefault(x => x.BidderXid == hasBid.BidderXid);
                    if (bidderInfo != null)
                    {
                        package.BidderName = bidderInfo.SupporterName;
                        package.BidderNumber = bidderInfo.Number;
                    }
                }
                if (outBidPackageList.Select(y => y.PackageXid).Contains(package.PackageXid))
                    package.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_OutBid).DisplayText;
                else if (winningPackageList.Select(y => y.PackageXid).Contains(package.PackageXid))
                    package.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Winning).DisplayText;
                else if (wonPackageList.Select(y => y.PackageXid).Contains(package.PackageXid))
                    package.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Won).DisplayText;
                else if (soldPackageList.Select(y => y.PackageXid).Contains(package.PackageXid))
                    package.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Sold).DisplayText;
                else if (closedPackageList.Select(y => y.PackageXid).Contains(package.PackageXid))
                    package.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Closed).DisplayText;
                else if (openingPackageList.Select(y => y.PackageXid).Contains(package.PackageXid))
                    package.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Opening).DisplayText;

            }
            return packageOutput;
        }

        #region Common Methods for GetPackages and Add Update Packages

        /// <summary>
        /// Remove Package Images by PackageID
        /// </summary>
        /// <param name="packageID">packageID</param>
        /// <returns></returns>
        public void RemovePackageImages(int packageID)
        {
            foreach (var packageImage in GetPackageImages(packageID))
            {
                _dbContext.PackageImage.Remove(packageImage);
            }
        }

        /// <summary>
        /// Remove Package category by packageId and classId
        /// </summary>
        /// <param name="packageID">packageID</param>
        ///  <param name="packageID">classId</param>
        /// <returns></returns>
        public void RemovePackageCategory(int packageId, int? classId)
        {
            var deletePackageCategory = _dbContext.Packages.FirstOrDefault(i => i.PackageXid != packageId && i.ClassId == classId && (!i.IsDeleted));
            if (deletePackageCategory == null)
            {
                var packageCategory = GetClass(classId);
                if (packageCategory != null)
                {
                    packageCategory.IsDeleted = true;
                    packageCategory.UpdatedDate = DateTime.UtcNow;
                }
            }
        }

        /// <summary>
        /// Get Donor string for Update Package
        /// </summary>
        /// <param name="donor">donor</param>
        /// <returns>string</returns>
        private string GetDonor(string[] donor)
        {
            var donorList = string.Empty;
            if (donor != null)
            {
                donorList = string.Join(AppConstants.DonorDelimiter, donor
                          .Select(x => x.ToString())
                          .ToArray());
            }
            return donorList;
        }

        private void InsertPackageEventLog(Package package, string eventType)
        {
            EventLog eventLog = new EventLog();
            eventLog.ProjectXid = package.ProjectXid;
            eventLog.PackageXid = package.PackageXid;
            eventLog.EventDate = DateTime.UtcNow;
            InsertEventLog(eventLog, eventType);
        }

        /// <summary>
        /// Updates the Class
        /// </summary>
        /// <param name="className">className</param>
        /// <param name="projectXid">projectXid</param>
        /// <returns>int</returns>
        private int? AddClass(string className, int projectXid)
        {
            var addClass = new Class();

            //check whether the category is deleted for the classid and the projectid. If so, undelete it and use.
            var classDetails = GetDeletedClassByClassName(projectXid, className);

            if (classDetails == null)
            {
                addClass.ClassName = className;
                addClass.ProjectXid = projectXid;
                addClass.CreatedDate = DateTime.UtcNow;
                _dbContext.Class.Add(addClass);
            }
            else
            {
                classDetails.IsDeleted = false;
                addClass = classDetails;
                addClass.UpdatedDate = DateTime.UtcNow;
            }
            _dbContext.SaveChanges();

            return addClass.ClassID;
        }

        /// <summary>
        /// Gets the class id by name
        /// </summary>
        /// <param name="className">className</param>
        /// <param name="projectXid">projectXid</param>
        /// <returns>string</returns>
        private int? GetClassIDbyName(string className, int projectXid)
        {
            var classDetails = GetClassByClassName(projectXid, className);

            if (classDetails != null)
            {
                return classDetails.ClassID;
            }
            else
            {
                if (!string.IsNullOrEmpty(className))
                    return AddClass(className, projectXid);
                return null;
            }
        }

        /// <summary>
        /// Gets the class name by Id
        /// </summary>
        /// <param name="classID">classID</param>
        /// <returns>string</returns>
        public string GetClassNamebyID(int? classID)
        {
            var classDetails = GetClass(classID);
            if (classDetails == null)
            {
                return string.Empty;
            }
            else
            {
                return classDetails.ClassName;
            }
        }

        /// <summary>
        /// Get Images
        /// </summary>
        /// <param name="packageID">packageID</param>
        /// <returns>string array</returns>
        private string[] GetImages(int packageID)
        {
            var imageArray = new List<string>();
            foreach (var packageImage in GetPackageImages(packageID))
            {
                if (!string.IsNullOrWhiteSpace(packageImage.ImagePath))
                {
                    imageArray.Add(ConfigManager.CdnProjectAssetsEndpoint + "/" + packageImage.ImagePath);
                    Logger.WriteDebugLog(string.Format("Package Image : {0},Package Order : {1}", packageImage.PackageImageID, packageImage.Order));
                }
            }
            return imageArray.ToArray();
        }

        /// <summary>
        /// Gets the donors with the specified delimiter 
        /// </summary>
        /// <param name="donors">donors</param>
        /// <returns>string array</returns>
        private string[] GetDonors(string donors)
        {
            if (!string.IsNullOrEmpty(donors))
            {
                return donors.Split(new string[] { AppConstants.DonorDelimiter }, StringSplitOptions.RemoveEmptyEntries);
            }
            return null;
        }

        /// <summary>
        /// Gets the suggested amount with the specified delimiter 
        /// </summary>
        /// <param name="suggestedamounts">suggestedamounts</param>
        /// <returns>int array</returns>
        private decimal[] GetSuggestedDonationAmounts(string suggestedDonationAmounts)
        {
            if (!string.IsNullOrEmpty(suggestedDonationAmounts))
            {
                return suggestedDonationAmounts.Split(Convert.ToChar(AppConstants.CommaDelimiter)).Select(x => Convert.ToDecimal(x)).ToArray();
            }
            return null;
        }

        /// <summary>
        /// Map Package Model to Package Output
        /// </summary>
        /// <param name="package">package</param>
        /// <param name="project">project</param>
        /// <returns>string array</returns>
        private PackageOutput MapModel(Package package, Project project)
        {
            var packageoutput = new PackageOutput();
            packageoutput.PackageXid = package.PackageXid;
            packageoutput.ProjectXid = package.ProjectXid;
            packageoutput.Name = package.Name;
            packageoutput.Number = package.Number.Trim();
            packageoutput.ClassName = GetClassNamebyID(package.ClassId);
            packageoutput.Description = package.Description;
            packageoutput.RestrictionNotes = package.RestrictionNotes;
            packageoutput.Donors = GetDonors(package.Donors);
            packageoutput.Value = package.Value;
            packageoutput.MinimumBid = package.MinimumBid;
            packageoutput.MinimumRaise = package.MinimumRaise;
            packageoutput.Price = package.Price;
            packageoutput.MaxAvailable = package.MaxAvailable;
            packageoutput.QtyPurchased = package.QtyPurchased;
            packageoutput.QtyRemaining = package.QtyRemaining;
            packageoutput.EndTimeUTC = package.EndTimeUTC;
            packageoutput.StartTimeUTC = package.StartTimeUTC;
            packageoutput.Images = GetImages(package.PackageXid);
            packageoutput.MobileBiddingType = GetCodeLookupName(CodeLookupConstants.CodeType_MobileBiddingType, package.MobileBiddingTypeID);
            packageoutput.ShowFmv = project.ShowFmv;
            packageoutput.ShowHistoryOnRegularPackages = project.ShowHistoryOnRegularPackages;
            packageoutput.ShowHistoryOnMultisalePackages = project.ShowHistoryOnMultisalePackages;
            packageoutput.ShowDonors = project.ShowDonors;
            return packageoutput;
        }

        /// <summary>
        /// No Bids Package Filter
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> NoBidPackagesFilter(Project project)
        {
            var result = new List<PackageOutput>();

            var resultPackages = NoBidPackages(project);

            var packagesWithSortOrder = GetPackagesWithSortOrder(resultPackages, project.ProjectXid, (int)project.BrowsePageSortOrder);
            foreach (var package in packagesWithSortOrder)
            {
                var packageoutput = MapModel(package, project);
                result.Add(packageoutput);
            }
            result = UpdatePackageStatus(result, project.ProjectXid);
            return result;
        }

        /// <summary>
        /// No Bids Packages
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<Package> NoBidPackages(Project project)
        {
            var resultPackages = new List<Package>();
            var OpeningSoonPackages = GetOpeningSoonRegularPackagesByProject(project.ProjectXid);
            var PackagesLists = new List<List<Package>>() { GetNoBidPackagesByProject(project.ProjectXid), GetNoSalePackagesByProject(project.ProjectXid), GetCurrentlyOpenRegularPackagesByProject(project.ProjectXid) };
            var currentlyOpenPackages = PackagesLists.Aggregate((previous, next) => previous.Intersect(next).ToList());

            resultPackages = OpeningSoonPackages.Union(currentlyOpenPackages).ToList();

            return resultPackages;
        }

        ////// <summary>
        /// Opening Soon Package Filter
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> OpeningSoonPackagesFilter(Project project)
        {
            var result = new List<PackageOutput>();

            var resultPackages = GetOpeningSoonRegularMultisalePackagesByProject(project.ProjectXid);

            var packagesWithSortOrder = GetPackagesWithSortOrder(resultPackages, project.ProjectXid, (int)project.BrowsePageSortOrder);
            foreach (var package in packagesWithSortOrder)
            {
                var packageoutput = MapModel(package, project);
                result.Add(packageoutput);
            }
            result = UpdatePackageStatus(result, project.ProjectXid);
            return result;
        }    

        /// <summary>
        /// Currently Open Packages Filter
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> CurrentlyOpenPackagesFilter(Project project)
        {
            var result = new List<PackageOutput>();
            var currentlyOpenPackages = CurrentlyOpenPackages(project);
            var packagesWithSortOrder = GetPackagesWithSortOrder(currentlyOpenPackages, project.ProjectXid, (int)project.BrowsePageSortOrder);
            foreach (var package in packagesWithSortOrder)
            {
                var packageoutput = MapModel(package, project);
                result.Add(packageoutput);
            }
            result = UpdatePackageStatus(result, project.ProjectXid);
            return result;
        }

        /// <summary>
        /// Currently Open Packages
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<Package> CurrentlyOpenPackages(Project project)
        {
            var result = new List<Package>();
            var regularCurrentlyOpen = GetCurrentlyOpenRegularPackagesByProject(project.ProjectXid).Intersect(GetNoSalePackagesByProject(project.ProjectXid));
            var multiSaleCurrentlyOpen = GetCurrentlyOpenMultiSalePackagesByProject(project.ProjectXid);

            result = regularCurrentlyOpen.Union(multiSaleCurrentlyOpen).ToList();

            return result;
        }

        /// <summary>
        /// Buy Now Packages Filter
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> BuyNowPackagesFilter(Project project)
        {
            var result = new List<PackageOutput>();

            var buyNowPackages = BuyNowPackages(project);
            var packagesWithSortOrder = GetPackagesWithSortOrder(buyNowPackages, project.ProjectXid, (int)project.BrowsePageSortOrder);
            foreach (var package in packagesWithSortOrder)
            {
                var packageoutput = MapModel(package, project);
                result.Add(packageoutput);
            }
            result = UpdatePackageStatus(result, project.ProjectXid);
            return result;
        }

        /// <summary>
        /// Buy Now Packages
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<Package> BuyNowPackages(Project project)
        {
            var buyNowPackages = new List<Package>();
            var getRegularPackagesByProject = GetRegularPackagesByProject(project.ProjectXid);
            var getHighbidPackages = from p in getRegularPackagesByProject
                                     join h in GetHighBidsByProject(project.ProjectXid) on p.PackageXid equals h.PackageXid
                                     where p.Price > 0 && h.Amount >= p.Price
                                     select p;

            var getRegularPackages = getRegularPackagesByProject.Where(x => x.Price > 0 && !getHighbidPackages.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            var getSoldRegularPackages = GetSalePackagesByProject(project.ProjectXid).Where(x => getRegularPackagesByProject.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            var PackagesLists = new List<List<Package>>() { getRegularPackages, getSoldRegularPackages };
            buyNowPackages = PackagesLists.Aggregate((previous, next) => previous.Union(next).ToList());

            return buyNowPackages;
        }

        /// <summary>
        /// Multisale Packages Filter
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> MultiSalePackagesFilter(Project project)
        {
            var result = new List<PackageOutput>();
            var multisalePackages = MultiSalePackages(project);
            foreach (var package in GetPackagesWithSortOrder(multisalePackages, project.ProjectXid, (int)project.BrowsePageSortOrder))
            {
                var packageoutput = MapModel(package, project);
                result.Add(packageoutput);
            }
            result = UpdatePackageStatus(result, project.ProjectXid);
            return result;
        }

        /// <summary>
        /// Multisale Packages
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<Package> MultiSalePackages(Project project)
        {
            var multisalePackages = GetMultiSalePackagesByProject(project.ProjectXid).Where(i => i.Price > 0 && (i.MaxAvailable > 0 || i.MaxAvailable == null)).ToList();
            return multisalePackages;
        }

        /// <summary>
        /// Preview Only Packages Filter
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> PreviewOnlyPackagesFilter(Project project)
        {
            var result = new List<PackageOutput>();
            var previewPackages = PreviewOnlyPackages(project.ProjectXid);
            foreach (var package in GetPackagesWithSortOrder(previewPackages, project.ProjectXid, (int)project.BrowsePageSortOrder))
            {
                var packageoutput = MapModel(package, project);
                result.Add(packageoutput);
            }
            result = UpdatePackageStatus(result, project.ProjectXid);
            return result;
        }

        public List<PackageOutput> GetSoldPackageFilter(Project project)
        {
            List<PackageOutput> resultPackages = new List<PackageOutput>();
            List<Package> packages = SoldPackagesFilter(project.ProjectXid, 0);
            foreach (var package in packages)
            {
                var packageoutput = MapModel(package, project);
                resultPackages.Add(packageoutput);
            }
            resultPackages = UpdatePackageStatus(resultPackages, project.ProjectXid);
            return resultPackages;
        }

        /// <summary>
        /// Preview Only Packages
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<PackageOutput></returns>
        public List<Package> PreviewOnlyPackages(int projectId)
        {
            var livePackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Live).CodeValue;
            var previewPackages = GetPackagesByProjectId(projectId).Where(i => i.MobileBiddingTypeID == livePackageType).ToList();

            return previewPackages;
        }

        /// <summary>
        /// Get ActNow Label for package
        /// </summary>        
        /// <param name="project">project</param>
        /// <returns>List<string></returns>
        private List<string> GetActNowLabelForPackage(Project project)
        {
            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_PackageFilterType);

            List<string> actNowLabelList = new List<string>();
            if (NoBidPackagesFilter(project).Count > 0)
                actNowLabelList.Add(GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_NoBids).DisplayText);
            if (CurrentlyOpenPackagesFilter(project).Count > 0)
                actNowLabelList.Add(GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_CurrentlyOpen).DisplayText);
            if (OpeningSoonPackagesFilter(project).Count > 0)
                actNowLabelList.Add(GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_OpeningSoon).DisplayText);
            if (BuyNowPackagesFilter(project).Count > 0)
                actNowLabelList.Add(GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_BuyNow).DisplayText);
            if (MultiSalePackagesFilter(project).Count > 0)
                actNowLabelList.Add(GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_Multisale).DisplayText);
            if (PreviewOnlyPackagesFilter(project).Count > 0)
                actNowLabelList.Add(GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_PreviewOnly).DisplayText);

            return actNowLabelList;
        }

        /// <summary>
        /// Get Packages per Page Size
        /// </summary>        
        /// <param name="packages">packages</param>
        /// <param name="pageNo">pageNo</param>
        /// <param name="pageSize">pageSize</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> GetPackagesPerPageSize(List<PackageOutput> packages, int pageNo, int pageSize)
        {
            var skip = pageSize * (pageNo - 1);
            return packages.Skip(skip).Take(pageSize).ToList();
        }

        /// <summary>
        /// Add or Remove Favorites List
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <param name="isFavorite">isFavorite</param>
        /// <returns>List<PackageOutput></returns>
        public void AddOrRemoveFavorite(string prefix, int packageId, bool isFavorite)
        {
            BidderList favorite = new BidderList();
            
            var project = GetProjectByPrefix(prefix);
            if (project != null)
            {
                var bidderId = GetCurrentBidderIdByBidderKey();
                var codeLookupList = GetCodeLookupListByType(CodeLookupConstants.CodeType_BidderListType);
                int? bidderListType = GetCodeLookupByTypeDescription(codeLookupList, CodeLookupConstants.CodeBidderListType_Favorites).CodeValue;

                favorite = _dbContext.BidderLists.Where(x => x.BidderXid == bidderId && x.PackageXid == packageId && x.ProjectXid == project.ProjectXid && x.ListType == bidderListType).FirstOrDefault(); /* TOK-1096 - added the List type filteration */
                if (isFavorite)
                {
                    if (favorite == null)
                    {
                        favorite = new BidderList();
                        favorite.BidderXid = bidderId;
                        favorite.ProjectXid = project.ProjectXid;
                        favorite.PackageXid = packageId;
                        favorite.ListType = bidderListType;
                        favorite.CreatedDate = DateTime.UtcNow;
                        _dbContext.BidderLists.Add(favorite);
                    }
                }
                else
                {
                    if (favorite != null)
                        _dbContext.BidderLists.Remove(favorite);
                }
                _dbContext.SaveChanges();
            }
        }

        /// <summary>
        /// Get Favorite Packages by bidder
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> GetFavoritePackagesByBidder(string prefix, int pageno, int size)
        {
            var result = new List<PackageOutput>();
            var project = GetProjectByPrefix(prefix);
            if (project != null)
            {
                var bidderId = GetCurrentBidderIdByBidderKey();
                var favoritePackages = GetFavoritesByBidder(project.ProjectXid, bidderId).Select(x => x.PackageXid).ToList();
                var bidderListPackages = GetPackagesByProjectId(project.ProjectXid).Where(x => favoritePackages.Contains(x.PackageXid)).ToList();
                var resultPackages = GetPackagesWithSortOrder(bidderListPackages, project.ProjectXid, (int)project.BrowsePageSortOrder);
                foreach (Package package in resultPackages)
                {
                    var packageoutput = MapModel(package, project);
                    result.Add(packageoutput);
                }
                result = UpdatePackageStatus(result, project.ProjectXid);
            }
            return GetPackagesPerPageSize(result, pageno, size);
        }

        /// <summary>
        /// Get Bid Activity by bidder
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="activityType">activityType</param>
        /// <param name="pageNo">pageNo</param>
        /// <param name="size">size</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> GetBidActivityByBidder(string prefix, string activityType, int pageno, int size)
        {
            var result = new List<PackageOutput>();
            var project = GetProjectByPrefix(prefix);
            if (project != null)
            {
                var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_PackageStatusType);
                var bidderId = GetCurrentBidderIdByBidderKey();
                if (bidderId != 0)
                {
                    var resultPackages = new List<Package>();
                    var outBidPackageList = new List<Package>();
                    var soldPackageList = new List<Package>();
                    var winningPackageList = new List<Package>();
                    var wonPackageList = new List<Package>();
                    var bidderMultiSalePackages = new List<Package>();
                    var bidderDonationPackages = new List<Package>();

                    var highBidList = GetHighBidsByProject(project.ProjectXid);
                    var bidderList = GetFavoritesByBidder(project.ProjectXid, bidderId);
                    var saleList = GetSaleListByProject(project.ProjectXid);

                    if (activityType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_All).DisplayText)
                    {
                        outBidPackageList = OutBidPackagesFilter(project.ProjectXid, bidderId);
                        soldPackageList = SoldPackagesForBidderFilter(project.ProjectXid, bidderId);
                        winningPackageList = WinningPackagesFilter(project.ProjectXid, bidderId);
                        wonPackageList = WonPackagesFilter(project.ProjectXid, bidderId);
                        bidderMultiSalePackages = GetBidderMultisalePackagesByProject(project.ProjectXid, bidderId);
                        bidderDonationPackages = GetBidderDonationPackagesByProject(project.ProjectXid, bidderId);

                        var PackagesLists = new List<List<Package>>() { outBidPackageList, soldPackageList, winningPackageList, wonPackageList, bidderMultiSalePackages, bidderDonationPackages };
                        resultPackages = PackagesLists.Aggregate((previous, next) => previous.Union(next).ToList());
                    }
                    else if (activityType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_OutBid).DisplayText)
                    {
                        outBidPackageList = OutBidPackagesFilter(project.ProjectXid, bidderId);
                        resultPackages = outBidPackageList.ToList();
                    }
                    else if (activityType == GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Winning).DisplayText)
                    {
                        winningPackageList = WinningPackagesFilter(project.ProjectXid, bidderId);
                        resultPackages = winningPackageList.ToList();
                    }
                    var packagesWithSortOrder = GetPackagesWithSortOrder(resultPackages, project.ProjectXid, (int)project.BrowsePageSortOrder);
                    foreach (Package package in packagesWithSortOrder)
                    {
                        var packageoutput = MapModel(package, project);

                        if (outBidPackageList.Select(y => y.PackageXid).Contains(packageoutput.PackageXid))
                            packageoutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_OutBid).DisplayText;
                        else if (winningPackageList.Select(y => y.PackageXid).Contains(packageoutput.PackageXid))
                            packageoutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Winning).DisplayText;
                        else if (wonPackageList.Select(y => y.PackageXid).Contains(packageoutput.PackageXid))
                            packageoutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Won).DisplayText;
                        else if (soldPackageList.Select(y => y.PackageXid).Contains(packageoutput.PackageXid))
                            packageoutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayPackageStatusType_Sold).DisplayText;

                        var hasBid = highBidList.FirstOrDefault(x => x.PackageXid == package.PackageXid);
                        var salePackage = saleList.FirstOrDefault(x => x.PackageXid == package.PackageXid);
                        packageoutput.IsFavorite = bidderList.Any(x => x.PackageXid == package.PackageXid);
                        packageoutput.IsBid = hasBid != null;
                        if (salePackage != null)
                            packageoutput.CurrentHighBid = salePackage.Amount;
                        else
                            packageoutput.CurrentHighBid = hasBid != null ? hasBid.Amount : 0;

                        result.Add(packageoutput);
                    }
                }
            }
            return GetPackagesPerPageSize(result, pageno, size);
        }

        /// <summary>
        /// Winning Packages filter
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>List<Package></returns>
        public List<Package> WinningPackagesFilter(int projectId, int bidderId)
        {
            var highBidsBidderPackageList = GetHighestBidPackagesByBidder(projectId, bidderId);

            var closeTimeFuturePackages = GetPackagesWithCloseTimeFutureByProject(projectId);

            var salePackages = GetSalePackagesByProject(projectId).Select(x => x.PackageXid);

            var winningPackages = closeTimeFuturePackages.Where(x => highBidsBidderPackageList.Contains(x.PackageXid) && !salePackages.Contains(x.PackageXid)).ToList();

            return winningPackages;
        }

        /// <summary>
        /// Opening Packages Filter
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <returns>List<Package></returns>
        public List<Package> OpeningPackagesFilter(int projectId)
        {
            var openingPackages = GetOpeningPackagesByProject(projectId);

            return openingPackages;
        }


        /// <summary>
        /// Closed Packages Filter
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <returns>List<Package></returns>
        public List<Package> ClosedPackagesFilter(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;

            var packageTypeList = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
            var regularPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var giversPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;

            var noBidsRegularPackages = GetNoBidPackagesByProject(projectId).Where(i => i.EndTimeUTC < currentDateTime && i.MobileBiddingTypeID == regularPackageType).ToList();

            var noSaleMultiPackages = GetNoSalePackagesByProject(projectId).Where(i => i.MaxAvailable > 0 && i.MobileBiddingTypeID == giversPackageType && i.EndTimeUTC < currentDateTime).ToList();

            var multiSalePackage = GetMultiSalePackagesByProject(projectId).Where(x => x.QtyRemaining > 0 && (x.QtyRemaining <= x.MaxAvailable) && x.EndTimeUTC < currentDateTime).ToList();

            var donationPackages = GetDonationPackagesByProject(projectId).Where(x => x.EndTimeUTC < currentDateTime).ToList();

            var PackagesLists = new List<List<Package>>() { noBidsRegularPackages, noSaleMultiPackages, multiSalePackage, donationPackages };
            var closedPackages = PackagesLists.Aggregate((previous, next) => previous.Union(next).ToList());

            return closedPackages;
        }

        /// <summary>
        /// Won Packages Filter
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>List<Package></returns>
        public List<Package> WonPackagesFilter(int projectId, int bidderId)
        {
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;

            var highBidsBidderPackageList = GetHighestBidPackagesByBidder(projectId, bidderId);

            var packages = GetPackagesWithCloseTimePastByProject(projectId);

            var allwonPackages = packages.Where(x => highBidsBidderPackageList.Contains(x.PackageXid)).ToList();

            var wonByBidder = GetSalePackagesByBidder(projectId, bidderId).Where(x => x.MobileBiddingTypeID == regularPackageType).ToList();

            allwonPackages = allwonPackages.Union(wonByBidder).ToList();

            return allwonPackages;
        }

        /// <summary>
        /// Sold Packages Filter
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>List<Package></returns>
        public List<Package> SoldPackagesFilter(int projectId, int bidderId)
        {
            List<Package> soldPackages = new List<Package>();

            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;

            var multiSalePackage = GetMultiSalePackagesByProject(projectId).Where(x => x.QtyRemaining == 0).ToList();

            if (bidderId != 0)
            {
                var bids = GetBidsByProject(projectId);

                var differentbidderHighBids = bids.GroupBy(a => new { a.BidderXid, a.PackageXid }, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();

                differentbidderHighBids = differentbidderHighBids.Where(x => x.BidderXid != bidderId).ToList();

                var closeTimePastpackages = GetPackagesWithCloseTimePastByProject(projectId).Where(x => x.MobileBiddingTypeID == regularPackageType).ToList();

                soldPackages = closeTimePastpackages.Where(x => differentbidderHighBids.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

                var salePackagesByAnotherBidders = GetRegularSalePackagesByDifferentBidder(projectId, bidderId).ToList();

                soldPackages = soldPackages.Union(salePackagesByAnotherBidders).Union(multiSalePackage).ToList();
            }
            else
            {
                soldPackages = GetSalePackagesByProject(projectId).Where(x => x.MobileBiddingTypeID == regularPackageType).ToList();

                soldPackages = soldPackages.Union(multiSalePackage).ToList();
            }

            return soldPackages;
        }

        /// <summary>
        /// Sold Packages for Bidder Filter
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>List<Package></returns>
        public List<Package> SoldPackagesForBidderFilter(int projectId, int bidderId)
        {
            List<Package> soldPackages = new List<Package>();

            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;

            var totalbids = GetBidsByProject(projectId);

            var closeTimePastpackages = GetPackagesWithCloseTimePastByProject(projectId).Where(x => x.MobileBiddingTypeID == regularPackageType).ToList();

            var differentbidderHighBids = totalbids.GroupBy(a => new { a.BidderXid, a.PackageXid }, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();

            differentbidderHighBids = differentbidderHighBids.Where(x => x.BidderXid != bidderId).ToList();

            var differentbidderHighBidsPackages = closeTimePastpackages.Where(x => differentbidderHighBids.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            var bids = totalbids.Where(x => x.BidderXid == bidderId).ToList();

            differentbidderHighBidsPackages = differentbidderHighBidsPackages.Where(x => bids.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            var regularPackages = GetPackagesByProjectId(projectId).Where(x => x.MobileBiddingTypeID == regularPackageType).ToList();

            var salePackages = GetSaleListByProject(projectId).Where(x => bids.Select(y => y.PackageXid).Contains(x.PackageXid) && x.BidderXid != bidderId).Select(x => x.PackageXid);

            soldPackages = regularPackages.Where(x => salePackages.Contains(x.PackageXid)).ToList();

            var multiSalePackages = GetBidderMultisalePackagesByProject(projectId, bidderId).Where(x => x.QtyRemaining == 0).ToList();

            var PackagesLists = new List<List<Package>>() { soldPackages, differentbidderHighBidsPackages, multiSalePackages };

            return PackagesLists.Aggregate((previous, next) => previous.Union(next).ToList()); ;
        }

        /// <summary>
        /// OutBid Packages Filter
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>List<Package></returns>
        public List<Package> OutBidPackagesFilter(int projectId, int bidderId)
        {
            var bids = GetBidsByProject(projectId);

            var highBids = bids.GroupBy(a => a.PackageXid, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();

            var bidderHighBids = bids.Where(x => x.BidderXid == bidderId).GroupBy(a => new { a.BidderXid, a.PackageXid }, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();

            var outBidPackageList = (from hb in highBids
                                     join bidderHb in bidderHighBids on hb.PackageXid equals bidderHb.PackageXid
                                     where hb.Amount > bidderHb.Amount
                                     select hb.PackageXid).ToList();


            var closeTimeFuturePackages = GetPackagesWithCloseTimeFutureByProject(projectId);

            var salePackages = GetSalePackagesByProject(projectId).Select(x => x.PackageXid);

            var outBidPackages = closeTimeFuturePackages.Where(x => outBidPackageList.Contains(x.PackageXid) && !salePackages.Contains(x.PackageXid)).ToList();

            return outBidPackages;
        }

        /// <summary>
        /// Get Highest Bid Packages by bidder
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>List<int></returns>
        private List<int> GetHighestBidPackagesByBidder(int projectId, int bidderId)
        {
            var bids = GetBidsByProject(projectId);

            var highBids = bids.GroupBy(a => a.PackageXid, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();

            var bidderHighBids = bids.Where(x => x.BidderXid == bidderId).GroupBy(a => new { a.BidderXid, a.PackageXid }, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();

            var packageList = (from r in highBids
                               join t in bidderHighBids on r.PackageXid equals t.PackageXid
                               where r.Amount == t.Amount
                               select r.PackageXid).ToList();

            return packageList;
        }

        /// <summary>
        /// Add Bid
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <param name="amount">Amount</param>
        /// <param name="bidType">bidType</param>
        /// <returns>ResultMessage</returns>
        public ResultMessage AddBid(string prefix, int packageId, decimal amount, string bidType)
        {
            ResultMessage result = new ResultMessage();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return result; }

            var package = CurrentlyOpenRegularPackage(packageId);
            var isPackageSold = IsSalePackageAvailableByPackageId(project.ProjectXid, packageId);

            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);
            if (package == null || isPackageSold)
            {
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
                return result;
            }

            var quantity = 0;
            var currentBidderId = GetCurrentBidderIdByBidderKey();

            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    var bidTypeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, bidType).CodeValue;
                    var insertEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Insert).CodeValue;

                    var highBid = GetHighBidByPackage(packageId);
                    bool isHighBid = (highBid != null) ? amount > highBid.Amount : true;
                    if (isHighBid)
                    {
                        var maxBidType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderListType, CodeLookupConstants.CodeBidderListType_MaxBid).CodeValue;
                        var getBidderMaxBidByPackage = GetBidderMaxBidByPackage(project.ProjectXid, packageId, maxBidType);
                        int bidderId;
                        if (getBidderMaxBidByPackage.Count > 0)
                        {
                            var highMaxBidRecord = getBidderMaxBidByPackage.FirstOrDefault();
                            if (highMaxBidRecord.MaxBidAmount >= amount)
                                bidderId = highMaxBidRecord.BidderXid;
                            else
                                bidderId = currentBidderId;
                        }
                        else
                        {
                            bidderId = currentBidderId;
                        }
                        var addBid = AddBidRecord(project.ProjectXid, packageId, bidderId, amount, null, bidTypeValue);
                        if (bidderId == currentBidderId)
                            result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
                        else
                            result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_OutBided).DisplayText;
                    }
                    else
                    {
                        result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_OutBided).DisplayText;
                    }

                    BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
                    {
                        ProjectXid = project.ProjectXid,
                        BidderXid = currentBidderId,
                        PackageXid = packageId,
                        BidderActionType = bidTypeValue,
                        BidAmount = amount,
                        QtyPurchased = quantity,
                        EventType = insertEventType
                    };
                    AddBidSaleLog(bidSaleLogInfo);

                    var resultCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, resultCount);
                }
                catch (Exception ex)
                {
                    TransactionCommitOrRollback(transaction, 0);
                    SqlException sqlException = ex.InnerException.InnerException as SqlException;
                    /* 2627 represents duplicate primary key and 1205 represent deadlock */
                    if (sqlException.Number == 2627 || sqlException.Number == 1205)
                    {
                        result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_OutBided).DisplayText;                        
                    }
                    else
                    {
                        throw ex;
                    }                    
                }
            }

            return result;
        }

        /// <summary>
        /// Set Max Bid
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <param name="maxAmount">Amount</param>
        /// <param name="bidType">bidType</param>
        /// <returns>ResultMessage</returns>
        public ResultMessage SetMaxBid(string prefix, int packageId, decimal maxAmount, string bidType)
        {
            ResultMessage result = new ResultMessage();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return result; }

            var package = CurrentlyOpenRegularPackage(packageId);
            var isPackageSold = IsSalePackageAvailableByPackageId(project.ProjectXid, packageId);
            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            if (package == null || isPackageSold)
            {
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
                return result;
            }

            var quantity = 0;
            var bidderId = GetCurrentBidderIdByBidderKey();

            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    var bidTypeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, bidType).CodeValue;
                    var insertEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Insert).CodeValue;
                    
                    var highBid = GetHighBidByPackage(packageId);
                    bool isHighBid = (highBid != null) ? maxAmount > highBid.Amount : true;
                    if (isHighBid)
                    {
                        var maxBidTypeValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderListType, CodeLookupConstants.CodeBidderListType_MaxBid).CodeValue;

                        var getMaxBidListByPackage = GetBidderMaxBidByPackage(project.ProjectXid, packageId, maxBidTypeValue);
                        var currentBidderHighMaxBid = getMaxBidListByPackage.FirstOrDefault(x => x.BidderXid == bidderId);
                        var otherBidderHighMaxBid = getMaxBidListByPackage.FirstOrDefault(x => x.BidderXid != bidderId);
                        bool isHighMaxBid = (otherBidderHighMaxBid != null) ? maxAmount > otherBidderHighMaxBid.MaxBidAmount : true;
                        if (isHighMaxBid)
                        {
                            var deleteEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Delete).CodeValue;

                            ClearMaxBidByPackage(project.ProjectXid, packageId, deleteEventType); /* delete the previous max bid record by package */

                            var addMaxBid = new BidderList();
                            addMaxBid.BidderXid = bidderId;
                            addMaxBid.PackageXid = packageId;
                            addMaxBid.ProjectXid = project.ProjectXid;
                            addMaxBid.MaxBidAmount = maxAmount;
                            addMaxBid.ListType = maxBidTypeValue;
                            addMaxBid.CreatedDate = DateTime.UtcNow;
                            _dbContext.BidderLists.Add(addMaxBid);

                            var currentHighBidAmount = (highBid != null) ? highBid.Amount : 0;
                            decimal highBidAmount = 0;
                            if (otherBidderHighMaxBid != null)
                            {
                                highBidAmount = ((otherBidderHighMaxBid.MaxBidAmount > currentHighBidAmount) ? (decimal)otherBidderHighMaxBid.MaxBidAmount : currentHighBidAmount) + (package.MinimumRaise ?? 0);
                            }
                            else
                            {
                                highBidAmount = ((currentHighBidAmount > 0) ? currentHighBidAmount + (package.MinimumRaise ?? 0) : (package.MinimumBid ?? 0));
                            }

                            var hasSameHighBidder = (highBid != null) ? highBid.BidderXid == bidderId : false;
                            if (!hasSameHighBidder)
                                AddBidRecord(project.ProjectXid, packageId, bidderId, highBidAmount, null, bidTypeValue);
                            result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
                        }
                        else
                        {
                            AddBidRecord(project.ProjectXid, packageId, otherBidderHighMaxBid.BidderXid, maxAmount, null, bidTypeValue);
                            result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_OutBided).DisplayText;
                        }
                    }
                    else
                    {
                        result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_OutBided).DisplayText;
                    }

                    BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
                    {
                        ProjectXid = project.ProjectXid,
                        BidderXid = bidderId,
                        PackageXid = packageId,
                        BidderActionType = bidTypeValue,
                        BidAmount = maxAmount,
                        QtyPurchased = quantity,
                        EventType = insertEventType
                    };
                    AddBidSaleLog(bidSaleLogInfo);

                    var resultCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, resultCount);
                }
                catch (Exception ex)
                {
                    TransactionCommitOrRollback(transaction, 0); //By default ResultCount - 0 for Rollback
                    SqlException sqlException = ex.InnerException.InnerException as SqlException;
                    /* 2627 represents duplicate primary key and 1205 represent deadlock */
                    if (sqlException.Number == 2627 || sqlException.Number == 1205)
                    {
                        result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_OutBided).DisplayText;
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Buy Regular Package
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <returns>Sale</returns>
        public Sale BuyRegularPackage(string prefix, int packageId)
        {
            Sale addSale = null;

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return null; }

            var package = CurrentlyOpenRegularPackage(packageId);
            if (package == null) { return null; }

            var bidderId = GetCurrentBidderIdByBidderKey();

            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    var bidType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Buy).CodeValue;
                    var insertEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Insert).CodeValue;

                    var quantity = 0;
                    var isPurchased = IsSalePackageAvailableByPackageId(project.ProjectXid, packageId);
                    var highBid = GetHighBidByPackage(packageId);
                    bool isHighBid = (highBid != null) ? highBid.Amount >= package.Price : false;
                    if (!isHighBid && !isPurchased)
                    {
                        quantity = 1;// Regular package quantity always one.

                        var addBid = AddBidWhenBuy(project.ProjectXid, packageId, bidderId, package.Price, quantity, bidType);
                        SaleInfo saleInfo = new SaleInfo() { ProjectXid = project.ProjectXid, BidderXid = bidderId, Amount = addBid.Amount, PackageXid = packageId, QtyPurchased = quantity };
                        addSale = AddSale(saleInfo);
                    }

                    BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
                    {
                        ProjectXid = project.ProjectXid,
                        BidderXid = bidderId,
                        PackageXid = packageId,
                        BidderActionType = bidType,
                        BidAmount = package.Price,
                        QtyPurchased = quantity,
                        EventType = insertEventType
                    };
                    AddBidSaleLog(bidSaleLogInfo);
                    var resultCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, resultCount);
                }
                catch (Exception ex)
                {
                    TransactionCommitOrRollback(transaction, 0); //By default ResultCount - 0 for Rollback
                    SqlException sqlException = ex.InnerException.InnerException as SqlException;
                    /* 2627 represents duplicate primary key and 1205 represent deadlock */
                    if (sqlException.Number == 2627 || sqlException.Number == 1205)
                    {
                        return null;
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }

            return addSale;
        }

        /// <summary>
        /// Buy Multisale Packages
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <param name="quantity">quantity</param>
        /// <returns>Sale</returns>
        public Sale BuyMultiSalePackages(string prefix, int packageId, int quantity)
        {
            Sale addSale = null;

            var project = GetProjectByPrefix(prefix);

            if (project == null) { return null; }

            var package = CurrentlyOpenMultiSalePackage(packageId);
            if (package == null) { return null; }

            var bidderId = GetCurrentBidderIdByBidderKey();

            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    var checkAvailableQuantity = package.MaxAvailable != null ? (package.QtyRemaining != null ? package.QtyRemaining >= quantity : true) : true;
                    if (quantity > 0 && checkAvailableQuantity)
                    {
                        SaleInfo saleInfo = new SaleInfo() { ProjectXid = project.ProjectXid, BidderXid = bidderId, Amount = (package.Price ?? 0) * quantity, PackageXid = packageId, QtyPurchased = quantity };
                        addSale = AddSale(saleInfo);

                        var purchased = (package.QtyPurchased ?? 0) + quantity;
                        var remaining = (package.MaxAvailable != null) ? (package.MaxAvailable - purchased) : null;
                        package.QtyPurchased = purchased;
                        package.QtyRemaining = (remaining < 0) ? 0 : remaining;
                    }

                    var bidType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Buy).CodeValue;
                    var insertEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Insert).CodeValue;

                    BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
                    {
                        ProjectXid = project.ProjectXid,
                        BidderXid = bidderId,
                        PackageXid = packageId,
                        BidderActionType = bidType,
                        BidAmount = (package.Price ?? 0) * quantity,
                        QtyPurchased = quantity,
                        EventType = insertEventType
                    };
                    AddBidSaleLog(bidSaleLogInfo);

                    var resultCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, resultCount);
                }
                catch (Exception ex)
                {
                    TransactionCommitOrRollback(transaction, 0); //By default ResultCount - 0 for Rollback
                    SqlException sqlException = ex.InnerException.InnerException as SqlException;
                    /* 2627 represents duplicate primary key and 1205 represent deadlock */
                    if (sqlException.Number == 2627 || sqlException.Number == 1205)
                    {
                        return null;
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }
            return addSale;
        }

        /// <summary>
        /// Buy Donation Package
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <param name="amount">amount</param>
        /// <returns>Sale</returns>
        public Sale BuyDonationPackage(string prefix, int packageId, decimal amount)
        {
            Sale addSale = null;

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return null; }

            var package = CurrentlyOpenDonationPackage(packageId);
            if (package == null) { return null; }

            var bidderId = GetCurrentBidderIdByBidderKey();

            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    var quantity = 0;
                    var bidType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Donation).CodeValue;
                    var insertEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Insert).CodeValue;

                    if (amount >= package.Price)
                    {
                        quantity = 1;// Donation package quantity always one.                
                        SaleInfo saleInfo = new SaleInfo() { ProjectXid = project.ProjectXid, BidderXid = bidderId, Amount = amount, PackageXid = packageId, QtyPurchased = quantity };
                        addSale = AddSale(saleInfo);
                    }

                    BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
                    {
                        ProjectXid = project.ProjectXid,
                        BidderXid = bidderId,
                        PackageXid = packageId,
                        BidderActionType = bidType,
                        BidAmount = amount,
                        QtyPurchased = quantity,
                        EventType = insertEventType
                    };
                    AddBidSaleLog(bidSaleLogInfo);

                    var resultCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, resultCount);
                }
                catch (Exception ex)
                {
                    TransactionCommitOrRollback(transaction, 0); //By default ResultCount - 0 for Rollback
                    SqlException sqlException = ex.InnerException.InnerException as SqlException;
                    /* 2627 represents duplicate primary key and 1205 represent deadlock */
                    if (sqlException.Number == 2627 || sqlException.Number == 1205)
                    {
                        return null;
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }
            return addSale;
        }

        /// <summary>
        /// Buy Appeal Donation Package
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="donationAmount">donationAmount</param>
        /// <returns>Sale</returns>
        public Sale BuyAppealDonationPackage(string prefix, decimal donationAmount)
        {
            Sale addSale = null;

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return null; }

            var package = GetAppealDonationPackage(project.DonationPackageXid);
            if (package == null) { return null; }

            var bidderId = GetCurrentBidderIdByBidderKey();

            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    var quantity = 1; // Donation package quantity always one.
                    var bidType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Donation).CodeValue;
                    var insertEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Insert).CodeValue;

                    SaleInfo saleInfo = new SaleInfo() { ProjectXid = project.ProjectXid, BidderXid = bidderId, Amount = donationAmount, PackageXid = package.PackageXid, QtyPurchased = quantity };
                    addSale = AddSale(saleInfo);
                    _dbContext.SaveChanges();
                    //Update Appeal Total Raised in Project
                    UpdateAppealTotalRaisedInProject(project, package.PackageXid);

                    BidSaleLogInfo bidSaleLogInfo = new BidSaleLogInfo()
                    {
                        ProjectXid = project.ProjectXid,
                        BidderXid = bidderId,
                        PackageXid = package.PackageXid,
                        BidderActionType = bidType,
                        BidAmount = donationAmount,
                        QtyPurchased = quantity,
                        EventType = insertEventType
                    };
                    AddBidSaleLog(bidSaleLogInfo);

                    var resultCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, resultCount);
                }
                catch (Exception ex)
                {
                    TransactionCommitOrRollback(transaction, 0); //By default ResultCount - 0 for Rollback
                    SqlException sqlException = ex.InnerException.InnerException as SqlException;
                    /* 2627 represents duplicate primary key and 1205 represent deadlock */
                    if (sqlException.Number == 2627 || sqlException.Number == 1205)
                    {
                        return null;
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }
            return addSale;
        }

        /// <summary>
        /// Add Bid Sale Log
        /// </summary>        
        /// <param name="projectXid">projectXid</param>
        /// <param name="bidderXid">bidderXid</param>
        /// <param name="packageXid">packageXid</param>
        /// <param name="bidderActionType">bidderActionType</param>
        /// <param name="bidAmount">bidAmount</param>
        /// <param name="qtyPurchased">qtyPurchased</param>
        /// <returns></returns>
        public void AddBidSaleLog(int projectXid, int bidderXid, int packageXid, int bidderActionType, decimal? bidAmount, int? qtyPurchased)
        {
            HttpContext context = HttpContext.Current;
            HttpBrowserCapabilities capability = context.Request.Browser;
            var browserName = capability.Browser;
            var version = capability.Version;
            var deviceType = capability.IsMobileDevice ? capability.MobileDeviceModel : capability.Platform;

            BidSaleLog bidSaleLog = new BidSaleLog();
            bidSaleLog.ProjectXid = projectXid;
            bidSaleLog.BidderXid = bidderXid;
            bidSaleLog.PackageXid = packageXid;
            bidSaleLog.BidderActionType = bidderActionType;
            bidSaleLog.BidAmount = bidAmount;
            bidSaleLog.QtyPurchased = qtyPurchased;
            bidSaleLog.BidActionDate = DateTime.UtcNow;
            bidSaleLog.BrowserName = browserName;
            bidSaleLog.Version = version;
            bidSaleLog.DeviceType = deviceType;
            _dbContext.BidSaleLogs.Add(bidSaleLog);
        }

        /// <summary>
        /// Add Bid when Buy
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="packageId">packageId</param>
        /// <param name="bidderId">bidderId</param>
        /// <param name="price">price</param>
        /// <param name="quantity">quantity</param>
        /// <param name="bidType">bidType</param>
        /// <returns>Bid</returns>
        public Bid AddBidWhenBuy(int projectId, int packageId, int bidderId, decimal? price, int quantity, int bidType)
        {
            var insertBid = AddBidRecord(projectId, packageId, bidderId, (price ?? 0) * quantity, quantity, bidType);
            return insertBid;
        }

        /// <summary>
        /// Add Sale
        /// </summary>        
        /// <param name="Bid">bid</param>
        /// <returns>Sale</returns>
        public Sale AddSale(SaleInfo saleInfo)
        {
            var sale = new Sale()
            {
                BidderXid = saleInfo.BidderXid,
                PackageXid = saleInfo.PackageXid,
                ProjectXid = saleInfo.ProjectXid,
                Amount = saleInfo.Amount,
                QtyPurchased = saleInfo.QtyPurchased,
                SaleDate = DateTime.UtcNow,
                GGOUpdateStatus = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SaleResultType, CodeLookupConstants.CodeSaleResultType_Queued).CodeValue
            };

            // Create a new Sale
            _dbContext.Sales.Add(sale);

            // Fetch the corresponding package
            var package = _dbContext.Packages.FirstOrDefault(p => p.PackageXid == saleInfo.PackageXid);

            // Update IsSaleCreated to true for the package
            if (package != null)
                package.IsSaleCreated = true;

            return sale;
        }

        /// <summary>
        /// Add Bid Record
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="packageId">packageId</param>
        /// <param name="bidderId">bidderId</param>
        /// <param name="amount">amount</param>
        /// <param name="quantity">quantity</param>
        /// <param name="bidType">bidType</param>
        /// <returns>Bid</returns>
        public Bid AddBidRecord(int projectId, int packageId, int bidderId, decimal amount, int? quantity, int bidType)
        {
            var insertBid = new Bid();
            insertBid.BidderXid = bidderId;
            insertBid.PackageXid = packageId;
            insertBid.ProjectXid = projectId;
            insertBid.Amount = amount;
            insertBid.BidType = bidType;
            insertBid.CreatedDate = DateTime.UtcNow;
            _dbContext.Bids.Add(insertBid);
            return insertBid;
        }

        /// <summary>
        /// Update Sale GGOUpdateStatus
        /// </summary>        
        /// <param name="saleId">saleId</param>
        /// <param name="status">status</param>
        /// <returns></returns>
        public void UpdateSaleGGOUpdateStatus(int saleId, int status)
        {
            var updateSale = GetSaleBySaleId(saleId);

            if (updateSale != null)
            {
                updateSale.GGOUpdateStatus = status;
                updateSale.LastAttempted = DateTime.UtcNow;
                updateSale.NoOfTries = updateSale.NoOfTries + 1 ?? 1;
                _dbContext.SaveChanges();
            }
        }

        /// <summary>
        /// Get the furthest or latest package closing date and time
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>CountdownBoardOutput</returns>
        public CountdownBoardOutput GetFurthestPackageClosingTimeByProject(string prefix)
        {
            CountdownBoardOutput countdownResult = new CountdownBoardOutput();

            var project = GetProjectByPrefix(prefix); // gets the project using prefix value
            if (project == null) { return countdownResult; }

            //gets the packageslist for which the package EndDateTimeUTC is in future
            var closeTimeFuturePackages = GetPackagesWithCloseTimeFutureByProject(project.ProjectXid);
            //sorts the package -  EndDateTimeUTC  descending and takes the furthest/latest package in the list
            var sortfurthestpackageByClosingTime = closeTimeFuturePackages.OrderByDescending(a => a.EndTimeUTC).FirstOrDefault();

            if (sortfurthestpackageByClosingTime != null)
            {
                countdownResult.PackageXid = sortfurthestpackageByClosingTime.PackageXid;
                if(sortfurthestpackageByClosingTime.EndTimeUTC != null)
                    countdownResult.CountdownTime = sortfurthestpackageByClosingTime.EndTimeUTC.Value.ToString(AppConstants.UTCDateTimeFormat);
            }

            return countdownResult;
        }

        /// <summary>
        /// Get LeaderBoard Packages
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="input">input</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> GetLeaderBoardPackages(string prefix, LeaderBoardInput input)
        {
            List<PackageOutput> sortedPackages = new List<PackageOutput>();
            var project = GetProjectByPrefix(prefix);
            if (project == null) { return sortedPackages; }

            var PackagesByFilterType = GetPackagesByLeaderBoardPackageType(project, input.PackageFilterType, input.CategoryFilterType);
            var getPackageSortType = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_PackageSortType);

            if (input.PackageSort == getPackageSortType.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayPackageSortType_PackageNumber).DisplayText)
            {
                var getPackageNumberArray = PackagesByFilterType.Select(x => x.Number).ToArray();

                Array.Sort(getPackageNumberArray, new AlphanumComparatorFast());

                foreach (var packageNumber in getPackageNumberArray)
                {
                    var package = PackagesByFilterType.FirstOrDefault(x => x.Number == packageNumber);
                    sortedPackages.Add(package);
                }
            }
            else if (input.PackageSort == getPackageSortType.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayPackageSortType_ClosingTime).DisplayText)
            {
                sortedPackages = PackagesByFilterType.OrderBy(x => x.EndTimeUTC).ToList();
            }
            else if (input.PackageSort == getPackageSortType.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayPackageSortType_Bidder).DisplayText)
            {
                /*gets packages by Bidder Number*/
                var packagesByBidderNumber = PackagesByFilterType.Where(y=>y.BidderNumber!= null && y.BidderNumber != 0).ToList();

                /*gets packages by Bidder Name */
                var packagesByBidderName = PackagesByFilterType.Where(y => (y.BidderNumber == null || y.BidderNumber == 0) && !string.IsNullOrWhiteSpace(y.BidderName)).ToList();

                /*get packages by package number if package has no bidder details*/
                var packagesByPackageNumber = PackagesByFilterType.Where(y => (y.BidderNumber == null || y.BidderNumber == 0) && string.IsNullOrWhiteSpace(y.BidderName)).ToList();

                if (packagesByBidderNumber.Any())
                {
                    /*Primary sorting by Bidder Number and Secondary sorting by Bidder Name*/
                    var packagesSortByBidderNumber = packagesByBidderNumber.OrderBy(x => x.BidderNumber).ThenBy(y => y.BidderName).ToList();
                    sortedPackages.AddRange(packagesSortByBidderNumber);
                }
                if (packagesByBidderName.Any())
                {
                    /*sorting by Bidder Name*/
                    var packagesSortByBidderName = packagesByBidderName.OrderBy(x => x.BidderName).ToList();
                    sortedPackages.AddRange(packagesSortByBidderName);
                }
                if(packagesByPackageNumber.Any())
                {
                    /*sorting by package number if package has no bidder details*/
                    var getPackageNumberArray = packagesByPackageNumber.Select(x => x.Number).Distinct().ToArray();

                    Array.Sort(getPackageNumberArray, new AlphanumComparatorFast());

                    foreach (var packageNumber in getPackageNumberArray)
                    {
                        var packagesSortByPackageNumber = packagesByPackageNumber.Where(x => x.Number == packageNumber).OrderBy(y => y.Name).ToList();
                        sortedPackages.AddRange(packagesSortByPackageNumber);
                    }
                }
            }
            var GetPackagesExcludeDisplayed = sortedPackages.Where(x => !input.DisplayedPackages.Contains(x.PackageXid)).ToList();

            if (sortedPackages.Count >= input.DisplayCount && GetPackagesExcludeDisplayed.Count < input.DisplayCount)
            {
                GetPackagesExcludeDisplayed.AddRange(sortedPackages);
            }

            return GetPackagesExcludeDisplayed.Take(input.DisplayCount).ToList();
        }

        /// <summary>
        /// Get packages by leaderBoard package filter type
        /// </summary>        
        /// <param name="project">project</param>
        /// <param name="packageType">packageType</param>
        /// <param name="categoryType">categoryType</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> GetPackagesByLeaderBoardPackageType(Project project, string packageType, string categoryType)
        {
            List<PackageOutput> resultPackages = new List<PackageOutput>();
            var getLeaderBoardPackageFilter = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_LeaderBoardPackageFilter);

            if (packageType == getLeaderBoardPackageFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayLeaderBoardPackageFilter_Open).DisplayText)
            {
                resultPackages = CurrentlyOpenPackagesFilter(project);
            }
            else if (packageType == getLeaderBoardPackageFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayLeaderBoardPackageFilter_NoBid).DisplayText)
            {
                resultPackages = NoBidPackagesFilter(project);
            }
            else if (packageType == getLeaderBoardPackageFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayLeaderBoardPackageFilter_All).DisplayText)
            {
                resultPackages = GetAllPackages(project.Prefix);
            }
            else if (packageType == getLeaderBoardPackageFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayLeaderBoardPackageFilter_Buy).DisplayText)
            {
                resultPackages = BuyNowPackagesFilter(project);
            }
            else if (packageType == getLeaderBoardPackageFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayLeaderBoardPackageFilter_Multisale).DisplayText)
            {
                resultPackages = MultiSalePackagesFilter(project);
            }
            else if (packageType == getLeaderBoardPackageFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayLeaderBoardPackageFilter_Preview).DisplayText)
            {
                resultPackages = PreviewOnlyPackagesFilter(project);
            }
            else if (packageType == getLeaderBoardPackageFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayLeaderBoardPackageFilter_Category).DisplayText)
            {
                resultPackages = GetPackagesByLeaderBoardCategoryType(project, categoryType);
            }
            else if (packageType == getLeaderBoardPackageFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayLeaderBoardPackageFilter_Sold).DisplayText)
            {
                resultPackages = GetSoldPackageFilter(project);                
            }
            return resultPackages;
        }

        /// <summary>
        /// Get packages by leaderBoard category filter type
        /// </summary>        
        /// <param name="project">project</param>
        /// <param name="categoryType">categoryType</param>
        /// <returns>List<PackageOutput></returns>
        public List<PackageOutput> GetPackagesByLeaderBoardCategoryType(Project project, string categoryType)
        {
            List<Package> packages = new List<Package>();
            List<PackageOutput> packageOutput = new List<PackageOutput>();
            var getLeaderBoardCategoryFilter = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_CategoryFilter);

            if (categoryType != getLeaderBoardCategoryFilter.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayCategoryFilter_All).DisplayText)
            {
                packages = GetPackagesByProject(project.ProjectXid, (int)project.BrowsePageSortOrder).Where(i => i.Class != null && i.Class.ClassName == categoryType).ToList();
            }
            else
            {
                packages = GetPackagesByProject(project.ProjectXid, (int)project.BrowsePageSortOrder).ToList();
            }
            foreach (var package in packages)
            {
                var packageoutput = MapModel(package, project);
                packageOutput.Add(packageoutput);
            }
            packageOutput = UpdatePackageStatus(packageOutput, project.ProjectXid);
            return packageOutput;
        }

        #endregion Private Methods for GetPackages and Add Update Packages

    }
}
