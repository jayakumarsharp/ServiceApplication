﻿using System;
using System.Collections.Generic;
using System.Linq;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using CommonUtil = GreaterGiving.Tokyo.Common.Reusables;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding
{
    public class BiddingBidder : BiddingBase
    {
        /// <summary>
        /// BiddingBidder Constructor for setting the context
        /// </summary>
        /// <param name="context"></param>
        public BiddingBidder(IBiddingContext context) : base(context)
        { }

        /// <summary>
        /// Insert or Update the Bidder
        /// </summary>
        /// <param name="bidder"></param>
        /// <returns>ResulModel</returns>
        public ResultModel AddOrUpdateBidder(BidderFieldValues bidder)
        {
            ResultModel result = new ResultModel();

            try
            {
                if (bidder.BidderXid == 0)
                    return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error004);

                var updateBidder = GetBidderForAdmin(bidder.BidderXid, bidder.ProjectXid);
                //if no data exists in the database
                if (updateBidder == null)
                {
                    Bidder createBidder = new Bidder();
                    AssignModelData(createBidder, bidder);

                    createBidder.CreatedDate = DateTime.UtcNow;
                    _dbContext.Bidders.Add(createBidder);
                    var inserted = _dbContext.SaveChanges();

                    if (inserted > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);                        
                        InsertBidderEventLog(createBidder, CodeLookupConstants.CodeEventType_Insert);
                    }
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info004);
                }
                //Data already exists, so update the data in the database
                else
                {
                    AssignModelData(updateBidder, bidder);

                    var reenableBidder = false;
                    /* Re enable bidder */
                    if (updateBidder.IsDeleted)
                    {
                        updateBidder.IsDeleted = false;
                        reenableBidder = true;
                    }

                    updateBidder.UpdatedDate = DateTime.UtcNow;

                    var updated = _dbContext.SaveChanges();

                    if (updated > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        if(reenableBidder)
                            InsertBidderEventLog(updateBidder, CodeLookupConstants.CodeEventType_Reenable);
                    }
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info004);
                }
                Logger.WriteInfoLog(string.Format("Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
            }
            catch (Exception ex)
            {
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
            }
            return result;
        }

        /// <summary>
        /// Deletes the bidder details 
        /// </summary>
        /// <param name="bidder"></param>
        /// <returns>result model</returns>
        public ResultModel DeleteBidder(int bidderId)
        {
            ResultModel result = new ResultModel();
            int updatedResultCount = 0;

            if (bidderId == 0)
                return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error004);

            var deleteBidder = GetBidder(bidderId);
            if (deleteBidder == null)
                return MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);

            //Delete Bidder
            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    /* Get Delete Event Type */
                    var deleteEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Delete).CodeValue;

                    RemoveBidder(deleteBidder, deleteEventType);                                       /* Delete bidder and its bids,sales and maxbids*/
                    updatedResultCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, updatedResultCount);

                    if (updatedResultCount > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        InsertBidderEventLog(deleteBidder, CodeLookupConstants.CodeEventType_Delete);
                    }
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info009);
                }
                catch (Exception ex)
                {
                    int defaultResultCount = 0;                                                       /* By default ResultCount - 0 for Rollback */
                    TransactionCommitOrRollback(transaction, defaultResultCount);
                    Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
                    result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                }
            }
            return result;
        }

        public void RemoveBidder(Bidder bidder, int deleteEventType)
        {
            bidder.IsDeleted = true;                                    /* remove bidder */
            bidder.UpdatedDate = DateTime.UtcNow;

            RemoveBidderBids(bidder, deleteEventType);                  /* remove bidder Bids */
            RemoveBidderSales(bidder, deleteEventType);                 /* remove bidder Sales */
            ClearBidderMaxBidsAndFavorites(bidder, deleteEventType);    /* remove bidder bidderLists; */
        }

        public List<BidderOutput> GetBidderHistoryOrCurrentBuyers(string prefix, int packageId)
        {
            List<BidderOutput> listBidderOutput = new List<BidderOutput>();
            var project = GetProjectByPrefix(prefix);
            if (project == null) { return listBidderOutput; }

            var currentPackage = GetPackage(packageId, project.ProjectXid);
            if (currentPackage == null) { return listBidderOutput; }

            var packageTypeList = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
            var regularPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var giversPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            var donationPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;
            var appealPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Appeal).CodeValue;

            if (currentPackage.MobileBiddingTypeID == regularPackageType)
            {
                var bidHistory = GetBidsByPackage(project.ProjectXid, packageId);
                foreach (var bid in bidHistory)
                {
                    var bidderOutput = GetAndMapBidderDetail(bid.BidderXid, packageId, bid.Amount);
                    if (bidderOutput != null)
                    {
                        bidderOutput.CreatedDate = bid.CreatedDate;
                        listBidderOutput.Add(bidderOutput);
                    }
                }
            }
            else if (currentPackage.MobileBiddingTypeID == giversPackageType || currentPackage.MobileBiddingTypeID == donationPackageType || currentPackage.MobileBiddingTypeID == appealPackageType)
            {
                var CurrentBuyersHistory = GetSalesByPackage(project.ProjectXid, packageId);
                foreach (var sale in CurrentBuyersHistory)
                {
                    var bidderOutput = GetAndMapBidderDetail(sale.BidderXid, packageId, sale.Amount);
                    if (bidderOutput != null)
                    {
                        bidderOutput.CreatedDate = sale.SaleDate;
                        listBidderOutput.Add(bidderOutput);
                    }
                }
            }
            return listBidderOutput.OrderByDescending(a => a.CreatedDate).ToList();
        }

        private void RemoveBidderBids(Bidder bidder, int deleteEventType)
        {
            var bids = GetBidsByBidder(bidder.ProjectXid, bidder.BidderXid);                            /* get bids by bidder id and project id */
            var highBidsBidId = GetHighBidsByProject(bidder.ProjectXid).Select(x => x.BidXid).ToList();
            foreach (var bidItem in bids)
            {
                RemoveBid(bidItem, deleteEventType);                                                    /* remove bid */

                if (highBidsBidId.Contains(bidItem.BidXid))
                {
                    /* SALE - soft deleting sale record if exists and update package*/
                    var regularSales = GetSalesByPackage(bidItem.ProjectXid, bidItem.PackageXid).FirstOrDefault();
                    if (regularSales != null && regularSales.Amount == bidItem.Amount)
                    {
                        RemoveSale(regularSales, (int)bidItem.BidType, deleteEventType);                /* Remove Sale */

                        var regularPackage = GetPackage(regularSales.PackageXid, regularSales.ProjectXid);
                        if (regularPackage != null)
                            regularPackage.IsSaleCreated = null;                                        /*update package IsSaleCreated to null for the package */
                    }
                }
            }
        }

        private void RemoveBidderSales(Bidder bidder, int deleteEventType)
        {
            /*Get all package type*/
            var packageTypeList = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
            var multiSalePackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            var appealPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Appeal).CodeValue;
            var donationPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;

            /* Get all bidder action type */
            var actionTypes = GetCodeLookupListByType(CodeLookupConstants.CodeType_BidderActionType);

            /* Get Project */
            var project = GetProject(bidder.ProjectXid);
            var sales = GetSalesByBidder(bidder.ProjectXid, bidder.BidderXid);  /* get sales by bidder id and project id */

            foreach (var saleItem in sales)
            {
                /* get sale package */
                var getSalePackage = GetPackage(saleItem.PackageXid, saleItem.ProjectXid);
                if (getSalePackage != null && getSalePackage.MobileBiddingTypeID != null)
                {
                    /* MultiSale Packages */
                    if (getSalePackage.MobileBiddingTypeID == multiSalePackageType)
                    {
                        var buyActionType = GetCodeLookupByTypeDescription(actionTypes, CodeLookupConstants.CodeBidderActionType_Buy).CodeValue;

                        RemoveSale(saleItem, buyActionType, deleteEventType);                                       /* remove sale */

                        /* update Purchased Quantity and  Remaining Quantity for the package*/
                        int purchasedQuantity = (saleItem.QtyPurchased ?? 0);
                        getSalePackage.QtyPurchased = (getSalePackage.QtyPurchased ?? 0) - purchasedQuantity;

                        if (getSalePackage.MaxAvailable != null)
                            getSalePackage.QtyRemaining = (getSalePackage.QtyRemaining ?? 0) + purchasedQuantity;
                    }

                    /* Appeal package */
                    if (getSalePackage.MobileBiddingTypeID == appealPackageType)
                    {
                        var appealActionType = GetCodeLookupByTypeDescription(actionTypes, CodeLookupConstants.CodeBidderActionType_Appeal).CodeValue;

                        RemoveSale(saleItem, appealActionType, deleteEventType);                                    /* remove sale */

                        if (project.AppealTotalRaised != null)
                            project.AppealTotalRaised = project.AppealTotalRaised - saleItem.Amount;
                    }

                    /* Donation package */
                    if (getSalePackage.MobileBiddingTypeID == donationPackageType)
                    {
                        var donationActionType = GetCodeLookupByTypeDescription(actionTypes, CodeLookupConstants.CodeBidderActionType_Donation).CodeValue;

                        RemoveSale(saleItem, donationActionType, deleteEventType);                                  /* remove sale */
                    }
                }
            }
        }

        private void ClearBidderMaxBidsAndFavorites(Bidder bidder, int deleteEventType)
        {           
            var bidderListByBidder = _dbContext.BidderLists.Where(x => x.BidderXid == bidder.BidderXid && x.ProjectXid == bidder.ProjectXid).ToList();
            ClearMaxBidsAndFavorites(bidderListByBidder, deleteEventType);
        }

        public BidderOutput GetBidderDetailByBidderId(int bidderid)
        {
            var result = new BidderOutput();

            var bidderDetail = GetBidder(bidderid);

            if (bidderDetail != null)
                result = MapBidderIntoBidderOutput(bidderDetail);

            return result;
        }

        private BidderOutput MapBidderIntoBidderOutput(Bidder bidder)
        {
            var bidderOutput = new BidderOutput();
            bidderOutput.BidderXid = bidder.BidderXid;
            bidderOutput.ProjectXid = bidder.ProjectXid;
            bidderOutput.OnlineBidderKey = bidder.OnlineBidderKey;
            bidderOutput.SupporterName = bidder.SupporterName;
            bidderOutput.MobilePhones = bidder.MobilePhones;
            bidderOutput.Emails = bidder.Emails;
            bidderOutput.Number = bidder.Number;
            bidderOutput.TableNumber = bidder.TableNumber;

            return bidderOutput;
        }

        public BidderOutput GetAndMapBidderDetail(int bidderid, int packageid, decimal amount)
        {
            var currentBidder = GetBidder(bidderid);
            if (currentBidder != null)
            {
                BidderOutput bidderDetail = new BidderOutput();
                bidderDetail.BidderXid = currentBidder.BidderXid;
                bidderDetail.SupporterName = currentBidder.SupporterName;
                bidderDetail.Number = currentBidder.Number;
                bidderDetail.Amount = amount;
                bidderDetail.OnlineBidderKey = currentBidder.OnlineBidderKey.Trim();
                bidderDetail.MobilePhones = currentBidder.MobilePhones;
                bidderDetail.ProjectXid = currentBidder.ProjectXid;
                bidderDetail.Emails = currentBidder.Emails;
                return bidderDetail;
            }
            else
                return null;
        }

        private void InsertBidderEventLog(Bidder bidder, string eventType)
        {
            EventLog eventLog = new EventLog();
            eventLog.ProjectXid = bidder.ProjectXid;
            eventLog.BidderXid = bidder.BidderXid;
            eventLog.EventDate = DateTime.UtcNow;
            InsertEventLog(eventLog, eventType);
        }

        private decimal GetBidderAmount(int bidderid, int packageid)
        {
            var currentBidder = _dbContext.Bids.Where(i => i.BidderXid == bidderid && i.PackageXid == packageid && !(i.IsDeleted) && !(i.Canceled)).OrderByDescending(b => b.CreatedDate).FirstOrDefault();
            return currentBidder != null ? currentBidder.Amount : 0;
        }

        #region Private Methods for AddOrUpdateBider
        /// <summary>
        /// Assigns the model data for either insert nor update bidder
        /// </summary>
        /// <param name="updateBidder">updateBidder</param>
        /// <param name="bidder">bidder</param>
        private void AssignModelData(Bidder updateBidder, BidderFieldValues bidder)
        {
            updateBidder.BidderXid = bidder.BidderXid;
            updateBidder.ProjectXid = bidder.ProjectXid;
            updateBidder.OnlineBidderKey = bidder.OnlineBidderKey;
            updateBidder.SupporterName = bidder.SupporterName;
            updateBidder.MobilePhones = CommonUtil.Utils.ConcatStringWithDelimiters(bidder.MobilePhones, AppConstants.CommaDelimiter);
            updateBidder.Emails = CommonUtil.Utils.ConcatStringWithDelimiters(bidder.Emails, AppConstants.EmailDelimiter);
            updateBidder.Number = bidder.Number;
            updateBidder.TableNumber = bidder.TableNumber;
        }

        #endregion Private Methods for AddOrUpdateBider
    }
}
