﻿using System;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Crypto;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using CommonUtil = GreaterGiving.Tokyo.Common.Reusables;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding
{
    public class BiddingProject : BiddingBase
    {
        public readonly IBiddingContext _context;

        public BiddingProject(IBiddingContext context) : base(context)
        {
            _context = context;
        }

        /// <summary>
        /// Get Project Details using prefix value
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>ProjectOutput</returns>
        public ProjectOutput GetProject(string prefix)
        {
            var resultProject = new ProjectOutput();
            var project = GetProjectByPrefix(prefix);
            if (project != null)
            {
                resultProject.ProjectXid = project.ProjectXid;
                resultProject.ProjectDisplayName = project.ProjectDisplayName.Trim();
                if(!string.IsNullOrWhiteSpace(project.ProjectImagePath))
                    resultProject.ProjectImagePath = ConfigManager.CdnProjectAssetsEndpoint + "/" + project.ProjectImagePath;
                resultProject.TimeZoneId = project.TimeZoneId.Trim();
                resultProject.LegalTerms = project.LegalTerms;
                resultProject.ClientName = project.ClientName;
                resultProject.AllowMaxBidding = project.AllowMaxBidding;
                resultProject.DonationPackageXid = project.DonationPackageXid;
                resultProject.AppealOnlyEvent = project.AppealOnlyEvent;
                resultProject.DisplayBiddersOnAppealBoard = project.DisplayBiddersOnAppealBoard;
                resultProject.LeaderBoardTheme = GetCodeLookupName(CodeLookupConstants.CodeType_LeaderboardThemeType, project.LeaderboardTheme);
                resultProject.LeaderboardScreenDisplaySeconds = project.LeaderboardScreenDisplaySeconds;
                resultProject.ProjectKey = project.ProjectKey;
                resultProject.Prefix = project.Prefix;
                resultProject.LeaderboardStyle = GetCodeLookupName(CodeLookupConstants.CodeType_LeaderboardStyleType, project.LeaderboardStyle);
                resultProject.WinningBidderDetail = project.WinningBidderDetail;
            }

            return resultProject;
        }

        public ProjectOutput GetProjectByProjectKey(string projectKey)
        {
            var resultProject = new ProjectOutput();
            var project = GetProjectDetailByProjectKey(projectKey);
            if(project != null)
            {
                return GetProject(project.Prefix);
            }
            return null;
        }

        public Project GetProjectDetails(string prefix)
        {
            var resultProject = new Project();
            var project = GetProjectByPrefix(prefix);
            if (project != null)
            {
                resultProject = project;
            }
            return resultProject;
        }

        /// <summary>
        /// Check IsShortNameAvailable for Project
        /// </summary>
        /// <param name="shortName">shortName</param>
        /// <returns>ResultModel</returns>
        public ResultModel IsShortNameAvailable(string shortName)
        {
            ResultModel result = new ResultModel();
            try
            {
                if (shortName != null)
                {
                    var shortNameValue = GetProjectByPrefix(shortName);
                    if (shortNameValue == null)
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.None);
                    else
                        result = MessageManager.GetResultMessage(MessageCode.InUse, MessageCode.None);
                }
                else
                    result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);

            }
            catch (Exception ex)
            {
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
            }

            return result;
        }

        /// <summary>
        /// Create Project
        /// </summary>
        /// <param name="ProjectFieldValues">ProjectFieldValues</param>
        /// <returns>ResultModel</returns>
        public ResultModel CreateProject(ProjectFieldValues project)
        {
            ResultModel result = new ResultModel();            

            try
            {
                if (project.ProjectXid == 0)
                    return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error002);

                var existingProject = GetProjectByProjectIdWithDeleted(project.ProjectXid);
                if (existingProject != null)
                {
                    if (existingProject.IsDeleted)
                    {                        
                        MapProjectFieldValuesIntoProject(existingProject, project);
                        existingProject.IsDeleted = false;
                        existingProject.UpdatedDate = DateTime.UtcNow;

                        var isUpdated = _dbContext.SaveChanges();
                        
                        if (isUpdated > 0)
                        {
                            result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                            InsertProjectEventLog(existingProject, CodeLookupConstants.CodeEventType_Reenable);
                        }
                        else
                        {
                            result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info002);
                        }
                    }
                    else
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Info001);
                    }
                }
                else
                {
                    var createProject = new Project();
                    MapProjectFieldValuesIntoProject(createProject, project);

                    createProject.ProjectXid = project.ProjectXid;                    
                    createProject.CreatedDate = DateTime.UtcNow;
                                        
                    _dbContext.Projects.Add(createProject);
                    var isInserted = _dbContext.SaveChanges();

                    if (isInserted > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success001);                        
                        InsertProjectEventLog(createProject, CodeLookupConstants.CodeEventType_Insert);
                    }

                }
            }
            catch (DbUpdateException ex)
            {
                SqlException sqlException = ex.InnerException.InnerException as SqlException;
                if (sqlException.Number == 2627)
                    result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Info001); // Cannot insert duplicate - Primary Key
                else
                    result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);

                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
            }
            catch (Exception ex)
            {
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
            }

            return result;
        }

        /// <summary>
        /// Update Project
        /// </summary>
        /// <param name="ProjectFieldValues">ProjectFieldValues</param>
        /// <returns>ResultModel</returns>
        public ResultModel UpdateProject(ProjectFieldValues project)
        {
            ResultModel result = new ResultModel();

            try
            {
                if (project.ProjectXid == 0)
                    return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error002);

                var updateProject = GetProject(project.ProjectXid);

                if (updateProject != null)
                {                    
                    MapProjectFieldValuesIntoProject(updateProject, project);

                    updateProject.UpdatedDate = DateTime.UtcNow;

                    var isUpdated = _dbContext.SaveChanges();

                    if (isUpdated > 0)
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info002);
                }
                else
                    result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info002);
            }
            catch (Exception ex)
            {
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
            }

            return result;
        }              

        private void MapProjectFieldValuesIntoProject(Project project, ProjectFieldValues projectFieldValues)
        {
            //update appeal donation type in package
            if (project.ProjectXid > 0 && (project.DonationPackageXid != projectFieldValues.DonationPackageXid))
                UpdateAppealDonationPackage(projectFieldValues);

            project.Prefix = projectFieldValues.Prefix.Trim();
            project.ProjectDisplayName = projectFieldValues.ProjectDisplayName.Trim();
            project.ClientName = projectFieldValues.ClientName;
            project.TimeZoneId = projectFieldValues.TimeZoneId;

            // If the input password has content then encrypt it else update as it is
            if (!string.IsNullOrWhiteSpace(projectFieldValues.Password))
                project.Password = CryptoHelper.Encrypt(projectFieldValues.Password, ConfigManager.AESPassword, ConfigManager.AESSalt);
            else
                project.Password = projectFieldValues.Password;
            project.ProjectImage = projectFieldValues.ProjectImage;
            project.DisplayBiddersOnAppealBoard = projectFieldValues.DisplayBiddersOnAppealBoard;
            project.SendSmsOutbidNotices = projectFieldValues.SendSmsOutbidNotices;
            project.SendEmailOutbidNotices = projectFieldValues.SendEmailOutbidNotices;
            project.ShowFmv = projectFieldValues.ShowFmv;
            project.AppealOnlyEvent = projectFieldValues.AppealOnlyEvent;
            project.WinningBidderDetail = GetCodeLookupValue(projectFieldValues.WinningBidderDetail, CodeLookupConstants.CodeType_WinningBidderDetailType);
            project.ShowHistoryOnRegularPackages = projectFieldValues.ShowHistoryOnRegularPackages;
            project.ShowHistoryOnMultisalePackages = projectFieldValues.ShowHistoryOnMultisalePackages;
            project.ShowDonors = projectFieldValues.ShowDonors;
            project.BrowsePageSortOrder = GetCodeLookupValue(projectFieldValues.BrowsePageSortOrder, CodeLookupConstants.CodeType_BrowsePageSortOrderType);
            project.AppealGoal = projectFieldValues.AppealGoal;
            project.LegalTerms = projectFieldValues.LegalTerms;
            project.LeaderboardNumberOfPackages = projectFieldValues.LeaderboardNumberOfPackages;
            project.DonationPackageXid = projectFieldValues.DonationPackageXid;
            project.DonationLabel = projectFieldValues.DonationLabel;
            project.AppealImage = projectFieldValues.AppealImage;
            project.LeaderboardTheme = GetCodeLookupValue(projectFieldValues.LeaderBoardTheme, CodeLookupConstants.CodeType_LeaderboardThemeType);
            project.LeaderboardScreenDisplaySeconds = projectFieldValues.LeaderboardScreenDisplaySeconds;
            project.RevenueGoal = projectFieldValues.RevenueGoal;
            project.AllowMaxBidding = projectFieldValues.AllowMaxBidding;
            project.LeaderboardStyle = GetCodeLookupValue(projectFieldValues.LeaderboardStyle, CodeLookupConstants.CodeType_LeaderboardStyleType);
            project.SuggestedDonationAmounts = GetSuggestedDonationAmounts(projectFieldValues.SuggestedDonationAmounts);
            project.ProjectKey = projectFieldValues.ProjectKey;
            if (project.ProjectImage == null)
                project.ProjectImagePath = null;
            if (project.AppealImage == null)
                project.AppealImagePath = null;

            //Update Appeal Total Raised in Project
            UpdateAppealTotalRaisedInProject(project, projectFieldValues.DonationPackageXid);
        }

        /// <summary>
        /// Gets the suggested amount with the specified delimiter 
        /// </summary>
        /// <param name="suggestedamounts">suggestedamounts</param>
        /// <returns>string array</returns>
        private string GetSuggestedDonationAmounts(decimal[] suggestedDonationAmounts)
        {
            var suggestedDonationAmountList = string.Empty;
            if (suggestedDonationAmounts != null)
            {
                return suggestedDonationAmountList = string.Join(AppConstants.CommaDelimiter, suggestedDonationAmounts
                          .Select(x => x)
                          .ToArray());
            }
            return null;
        }

        private void UpdateAppealDonationPackage(ProjectFieldValues project)
        {
            var packages = GetPackagesByProjectIdWithAppealDonation(project.ProjectXid);
            if (packages.Count() > 0)
            {
                var appealPackageType = (byte)GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Appeal).CodeValue;
                var donationPackageType = (byte)GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;

                //Update existing appeal package to donation package type
                var existingAppealDonationPackage = packages.Where(x => x.ProjectXid == project.ProjectXid && x.MobileBiddingTypeID == appealPackageType).FirstOrDefault();
                if (existingAppealDonationPackage != null)
                    existingAppealDonationPackage.MobileBiddingTypeID = donationPackageType;

                //Update current appeal donation package in package
                var package = GetPackage(project.DonationPackageXid);
                if (package != null)
                    package.MobileBiddingTypeID = appealPackageType;

            }
        }

        /// <summary>
        /// Delete Project
        /// </summary>
        /// <param name="ProjectId">ProjectId</param>
        /// <returns>ResultModel</returns>
        public ResultModel DeleteProject(int projectid)
        {
            ResultModel result = new ResultModel();

            try
            {
                if (projectid == 0)
                    return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error002);

                var deleteProject = GetProject(projectid);
                if (deleteProject != null)
                {                    
                    RemovePackages(deleteProject.ProjectXid);
                    RemoveBidders(deleteProject.ProjectXid);
                    RemoveSponsors(deleteProject.ProjectXid);
                    RemoveEmailtemplate(deleteProject.ProjectXid);
                    RemoveSMStemplate(deleteProject.ProjectXid);

                    //delete Project                    
                    deleteProject.IsDeleted = true;
                    deleteProject.UpdatedDate = DateTime.UtcNow;

                    var isDeleted = _dbContext.SaveChanges();
                    if (isDeleted > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        InsertProjectEventLog(deleteProject, CodeLookupConstants.CodeEventType_Delete);
                    }
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info009);
                }
                else
                    result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);
            }
            catch (Exception ex)
            {
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));

            }
            return result;
        }

        /// <summary>
        /// Validate Project
        /// </summary>
        /// <param name="ProjectXid">ProjectXid</param>
        /// <returns>ResultModel</returns>
        public bool ValidateProject(int ProjectXid)
        {
            return (GetProject(ProjectXid) != null);
        }

        /// <summary>
        /// Logs the data in the SMSRequest table
        /// </summary>
        /// <param name="message">message</param>
        /// <returns>true or false</returns>
        public int InsertSMSRequest(TextMessageFieldValues message, int purpose)
        {
            SMSRequest createRequest = new SMSRequest();
            createRequest = new SMSRequest();
            createRequest.ProjectXid = message.ProjectXid;
            createRequest.Message = message.Message;
            createRequest.Phone = message.Phone;
            createRequest.CreatedDate = DateTime.UtcNow;
            createRequest.UpdatedDate = DateTime.UtcNow;
            createRequest.Purpose = purpose;
            createRequest.ProcessStatus = 0; //default status is "0". Not Processed in Batch Process - InQueue

            _dbContext.SMSRequests.Add(createRequest);
            var inserted = _dbContext.SaveChanges();

            return createRequest.SMSRequestID;
        }

        /// <summary>
        /// Inserts the data in the SMSDeliveryStatus
        /// </summary>
        /// <param name="smsRequestId">smsRequestId</param>
        /// <param name="toPhoneNumber">toPhoneNumber</param>
        /// <param name="statusIndicator">statusIndicator</param>
        /// <param name="sendTime">sendTime</param>
        /// <param name="deliveryTime">deliveryTime</param>
        /// <param name="sId">sId</param>
        /// <returns>true or false</returns>
        public bool InsertSMSDeliveryStatus(int smsRequestId, string toPhoneNumber, string statusIndicator, DateTime sendTime, DateTime deliveryTime, string sId, int? bidderId)
        {
            bool isInserted = false;

            if (smsRequestId > 0)
            {
                SMSDeliveryStatus deliveryStatus = new SMSDeliveryStatus();
                deliveryStatus.SMSRequestID = smsRequestId;
                deliveryStatus.BidderXid = bidderId; //Used for SMS Text Bidding Notifications for OutBid SMS Message.If it from PUSH API the value will be null.
                deliveryStatus.PhoneNumber = toPhoneNumber;
                deliveryStatus.StatusIndicator = GetCodeLookupValue(statusIndicator, CodeLookupConstants.CodeType_SMSDeliveryStatusesType);
                deliveryStatus.SendTime = sendTime;
                deliveryStatus.DeliveryTime = deliveryTime;
                deliveryStatus.Sid = sId;

                _dbContext.SMSDeliveryStatus.Add(deliveryStatus);
                var inserted = _dbContext.SaveChanges();
                if (inserted > 0)
                    isInserted = true;
            }
            return isInserted;
        }

        public int InsertEmailRequest(EmailMessageFieldValues emailMessage, int projectId, int purpose)
        {
            EmailRequest emailRequest = new EmailRequest();
            emailRequest.ProjectXid = projectId;
            emailRequest.Subject = emailMessage.Subject;
            emailRequest.Message = emailMessage.Message;
            emailRequest.FromName = emailMessage.FromName;
            emailRequest.From = emailMessage.FromEmailAddress;
            emailRequest.ToAddress = emailMessage.ToEmailAddress;
            emailRequest.CreatedDate = DateTime.UtcNow;
            emailRequest.UpdatedDate = DateTime.UtcNow;
            emailRequest.Purpose = purpose;

            _dbContext.EmailRequests.Add(emailRequest);
            var inserted = _dbContext.SaveChanges();

            return emailRequest.EmailRequestID;
        }

        public void InsertSMSErrorLog(string errorCode, string errorMsg, string phoneNo)
        {
            SMSErrorLog smsErrorLog = new SMSErrorLog();
            smsErrorLog.SMSErrorCode = errorCode;
            smsErrorLog.SMSErrorDescription = errorMsg;
            smsErrorLog.PhoneNo = phoneNo;
            smsErrorLog.SMSErrorDate = DateTime.UtcNow;
            smsErrorLog.CreatedDate = DateTime.UtcNow;
            _dbContext.SMSErrorLogs.Add(smsErrorLog);
            _dbContext.SaveChanges();
        }

        public bool InsertEmailDeliveryStatus(EmailDeliveryStatusInput emailDeliveryStatusInput)
        {
            bool isInserted = false;

            if (emailDeliveryStatusInput.EmailRequestId > 0)
            {
                EmailDeliveryStatus emailDeliveryStatus = new EmailDeliveryStatus();
                emailDeliveryStatus.EmailRequestID = emailDeliveryStatusInput.EmailRequestId;
                emailDeliveryStatus.EmailAddress = emailDeliveryStatusInput.EmailAddress;
                emailDeliveryStatus.StatusIndicator = emailDeliveryStatusInput.StatusIndicator;
                emailDeliveryStatus.SendTime = emailDeliveryStatusInput.SendTime;
                emailDeliveryStatus.DeliveryTime = emailDeliveryStatusInput.DeliveryTime;
                emailDeliveryStatus.DeliveryStatus = emailDeliveryStatusInput.DeliveryStatus;
                emailDeliveryStatus.BidderXid = emailDeliveryStatusInput.BidderId;
                emailDeliveryStatus.MessageID = emailDeliveryStatusInput.MessageId;

                _dbContext.EmailDeliveryStatus.Add(emailDeliveryStatus);
                var inserted = _dbContext.SaveChanges();
                if (inserted > 0)
                    isInserted = true;
            }
            return isInserted;
        }

        public void InsertUnsubscribePhoneNo(string phoneNo)
        {
            var existingPhoneNo = GetSMSUnsubscribePhoneNo(phoneNo);            
            if (!string.IsNullOrWhiteSpace(phoneNo) && existingPhoneNo == null)
            {
                SMSUnsubscribe createRequest = new SMSUnsubscribe();
                createRequest.PhoneNo = phoneNo.Trim();
                createRequest.Unsubscribe = true;
                createRequest.CreatedDate = DateTime.UtcNow;
                _dbContext.SMSUnsubscribes.Add(createRequest);
                _dbContext.SaveChanges();
            }
        }

        public void DeleteUnsubscribePhoneNo(string phoneNo)
        {
            if (!string.IsNullOrWhiteSpace(phoneNo))
            {
                var unsubscribtPhoneList = _dbContext.SMSUnsubscribes.Where(x => x.PhoneNo.Trim() == phoneNo.Trim()).ToList();
                foreach (var unsubscribe in unsubscribtPhoneList)
                {
                    _dbContext.SMSUnsubscribes.Remove(unsubscribe);                    
                }
                _dbContext.SaveChanges();
            }
        }

        public void UpdateSMSStatus(int smsRequestId, string statusIndicator, string smsSid)
        {
            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    var smsRequest = _dbContext.SMSRequests.Where(x => x.SMSRequestID == smsRequestId).FirstOrDefault();
                    if (smsRequestId > 0 && smsRequest != null)
                    {
                        var smsStatus = GetCodeLookupValue(statusIndicator, CodeLookupConstants.CodeType_SMSDeliveryStatusesType);

                        SMSDeliveryStatus deliveryStatus = new SMSDeliveryStatus();
                        deliveryStatus.SMSRequestID = smsRequestId;
                        deliveryStatus.BidderXid = null; //Used for SMS Text Bidding Notifications for OutBid SMS Message.If it from PUSH API the value will be null.
                        deliveryStatus.PhoneNumber = smsRequest.Phone;
                        deliveryStatus.StatusIndicator = smsStatus;
                        deliveryStatus.SendTime = smsRequest.UpdatedDate;
                        deliveryStatus.DeliveryTime = DateTime.UtcNow;
                        deliveryStatus.Sid = smsSid;

                        _dbContext.SMSDeliveryStatus.Add(deliveryStatus);
                        if (smsRequest.StatusIndicator != GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SMSDeliveryStatusesType, CodeLookupConstants.CodeSMSDeliveryStatusType_Delivered).CodeValue)
                        {
                            smsRequest.StatusIndicator = smsStatus;
                            if (statusIndicator.ToLower() == CodeLookupConstants.CodeSMSDeliveryStatusType_Delivered.ToLower())
                                smsRequest.ProcessStatus = 2;
                        }

                        _dbContext.SaveChanges();

                        transaction.Commit();
                    }
                }
                catch (Exception ex)
                {
                    TransactionCommitOrRollback(transaction, 0);
                }
            }
        }

        #region Common Methods for Project

        private void InsertProjectEventLog(Project project, string eventType)
        {
            EventLog eventLog = new EventLog();
            eventLog.ProjectXid = project.ProjectXid;
            eventLog.EventDate = DateTime.UtcNow;
            InsertEventLog(eventLog, eventType);
        }

        private void RemovePackages(int projectid)
        {
            BiddingPackage biddingPackage = new BiddingPackage(_context);
            var deleteEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Delete).CodeValue;
            var packageTypes = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
            foreach (var package in GetPackagesByProjectIdWithAppealDonation(projectid))
            {
                //delete Package          
                biddingPackage.RemovePackage(package, packageTypes, deleteEventType);
            }
        }

        private void RemoveBidders(int projectid)
        {
            foreach (var bidder in GetBidderByProjectId(projectid))
            {
                //delete Bidder                    
                bidder.IsDeleted = true;
                bidder.UpdatedDate = DateTime.UtcNow;
            }
        }

        private void RemoveSponsors(int projectid)
        {
            foreach (var sponsor in GetSponsorByProjectId(projectid))
            {
                //delete Sponsor                    
                sponsor.IsDeleted = true;
                sponsor.UpdatedDate = DateTime.UtcNow;
            }
        }

        private void RemoveEmailtemplate(int projectid)
        {
            var emailTemplates = GetEmailTemplatesByProject(projectid);
            foreach(var emailTemplate in emailTemplates)
            {
                DeleteEmailTemplate(emailTemplate);
            }
        }

        private void RemoveSMStemplate(int projectid)
        {
            var smsTemplates = GetSMSTemplatesByProject(projectid);
            foreach (var smsTemplate in smsTemplates)
            {
                DeleteSMSTemplate(smsTemplate);
            }
        }

        #endregion Common Methods for Project
    }
}
