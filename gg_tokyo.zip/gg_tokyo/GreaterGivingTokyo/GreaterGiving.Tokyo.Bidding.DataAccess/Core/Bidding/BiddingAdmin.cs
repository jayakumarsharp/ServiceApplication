﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using CommonUtil = GreaterGiving.Tokyo.Common.Reusables;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding
{
    public class BiddingAdmin : BiddingBase
    {
        private readonly IBiddingContext _context;
        /// <summary>
        /// Bidding Admin Constructor for setting the context
        /// </summary>
        /// <param name="context"></param>
        public BiddingAdmin(IBiddingContext context) : base(context)
        {
            _context = context;
        }

        public List<BidderOutput> GetTopBiddersForAdmin(string prefix, int count)
        {
            List<BidderOutput> bidderListOutput = new List<BidderOutput>();
            int? noofbids = 0;

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return bidderListOutput; }

            //Get Regular packages by project
            var regularPackages = GetRegularPackagesByProject(project.ProjectXid).Select(x => x.PackageXid);

            //Get list of bids for project
            var bids = GetBidsByProject(project.ProjectXid).Where(y => regularPackages.Contains(y.PackageXid));

            //Get only bidders with bids placed for packages
            var bidders = GetBidderByProjectId(project.ProjectXid).Where(x => bids.Select(y => y.BidderXid).Contains(x.BidderXid));

            //Get list of sales for project for regular package
            var sales = GetSaleListByProject(project.ProjectXid).Where(y => regularPackages.Contains(y.PackageXid));

            foreach (var bidder in bidders)
            {
                if (bids != null)
                    noofbids = bids.Where(x => x.BidderXid == bidder.BidderXid).Count();

                var bidderOutput = MapBidderIntoBidderOutput(bidder);
                bidderOutput.Bids = noofbids;
                bidderListOutput.Add(bidderOutput);
            }

            bidderListOutput = bidderListOutput.OrderByDescending(x => x.Bids).ThenBy(y => y.SupporterName).ToList();

            if (count > 0)
                bidderListOutput = bidderListOutput.Take(count).ToList();

            return bidderListOutput;
        }

        public List<BidderSearchOutput> GetAllBiddersForAdmin(string prefix, BidderSearchInput bidderSearchInput)
        {
            List<BidderSearchOutput> bidderListOutput = new List<BidderSearchOutput>();
            int? noofbids = 0;

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return bidderListOutput; }

            //Get Regular packages by project
            var regularPackages = GetRegularPackagesByProject(project.ProjectXid).Select(x => x.PackageXid);

            //Get list of bids for project
            var bids = GetBidsByProject(project.ProjectXid).Where(y => regularPackages.Contains(y.PackageXid));

            //Get only bidders with bids placed for packages
            var getBidders = GetBidderByProjectIdForAdmin(project.ProjectXid);
            var bidderNameFilter = getBidders;
            var bidderNumberFilter = getBidders;

            // Search for bidder using bidder name
            if (!string.IsNullOrWhiteSpace(bidderSearchInput.BidderName))
            {
                bidderNameFilter = bidderNameFilter.Where(x => x.SupporterName.ToLower().Contains(bidderSearchInput.BidderName.ToLower())).ToList();
            }

            // search for bidder using bidder number
            if (bidderSearchInput.BidderNumber != null && bidderSearchInput.BidderNumber >= 0)
            {
                bidderNumberFilter = bidderNumberFilter.Where(x => x.Number.ToString().Contains(bidderSearchInput.BidderNumber.ToString())).ToList();
            }

            var bidderLists = new List<List<Bidder>>() { bidderNameFilter, bidderNumberFilter };
            var resultBidders = bidderLists.Aggregate((previous, next) => previous.Intersect(next).ToList());

            foreach (var bidder in resultBidders)
            {
                if (bids != null)
                    noofbids = bids.Where(x => x.BidderXid == bidder.BidderXid).Count();

                var bidderOutput = MapBidderIntoBidderSearchOutput(bidder);
                if(!bidderOutput.IsDeleted)
                    bidderOutput.Bids = noofbids;
                bidderListOutput.Add(bidderOutput);
            }

            return bidderListOutput.OrderBy(x => x.SupporterName).ToList();
        }

        public BidderSearchOutput GetBidderDetailsForAdmin(string prefix, int bidderId)
        {
            BidderSearchOutput bidderOutput = new BidderSearchOutput();
            int? totalNoOfBidsCount; // count of all bids placed by the bidder on regular auction packages

            //Gets the project details 
            var project = GetProjectByPrefix(prefix);
            if (project == null) { return bidderOutput; }

            //Gets the bidder details
            var bidder = GetBidderForAdmin(bidderId, project.ProjectXid);
            if (bidder == null) { return bidderOutput; }

            //Get Regular packages for project
            var regularPackages = GetRegularPackagesByProjectForAdmin(project.ProjectXid).Select(x => x.PackageXid).ToList();

            //Get list of bids for project with count of all bids placed by the bidder on regular auction packages
            totalNoOfBidsCount = GetBidsByProject(project.ProjectXid).Where(y => regularPackages.Contains(y.PackageXid) && y.BidderXid == bidder.BidderXid).Count();

            bidderOutput = MapBidderIntoBidderSearchOutput(bidder);
            bidderOutput.Bids = totalNoOfBidsCount;

            return bidderOutput;
        }

        public List<BidHistoryOutput> GetBidderBidHistoryForAdmin(string prefix, int bidderId)
        {
            List<BidHistoryOutput> bidHistoryOutputs = new List<BidHistoryOutput>();

            // Gets the project
            var project = GetProjectByPrefix(prefix);
            if (project == null) { return bidHistoryOutputs; }

            //Get bidder
            var bidder = GetBidderForAdmin(bidderId, project.ProjectXid);
            if (bidder == null) { return bidHistoryOutputs; }

            //Get packages by project
            var packages = GetPackagesByProjectIdForAdmin(project.ProjectXid);

            //Get list of bids for project
            var bids = GetBidsByProjectForAdmin(project.ProjectXid).Where(y => y.BidderXid == bidder.BidderXid).ToList();

            /* Get Multisale or donation packages for the bidder */
            var salePackages = GetSaleListByProjectForAdmin(project.ProjectXid).Where(s => s.BidderXid == bidder.BidderXid).ToList();

            foreach (var bid in bids)
            {
                /* gets the package information */
                var package = packages.FirstOrDefault(z => z.PackageXid == bid.PackageXid);
                if (package != null)
                {
                    var bidHistoryOutput = MapBidIntoBidHistoryOutput(bid);
                    bidHistoryOutput.Name = package.Name;
                    bidHistoryOutput.Number = package.Number.Trim();
                    bidHistoryOutput.MobileBiddingType = GetCodeLookupName(CodeLookupConstants.CodeType_MobileBiddingType, package.MobileBiddingTypeID);
                    bidHistoryOutputs.Add(bidHistoryOutput);
                }
            }

            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            foreach (var salePackage in salePackages)
            {
                /*gets the package based on sale package and project id */
                var package = packages.FirstOrDefault(z => z.PackageXid == salePackage.PackageXid);
                
                if (package != null && package.MobileBiddingTypeID.Value != regularPackageType)
                {
                    var bidHistoryOutput = MapSaleIntoBidHistoryOutput(salePackage);
                    bidHistoryOutput.Name = package.Name;
                    bidHistoryOutput.Number = package.Number.Trim();
                    bidHistoryOutput.MobileBiddingType = GetCodeLookupName(CodeLookupConstants.CodeType_MobileBiddingType, package.MobileBiddingTypeID);
                    bidHistoryOutputs.Add(bidHistoryOutput);
                }
            }

            bidHistoryOutputs = bidHistoryOutputs.OrderByDescending(x => x.CreatedDate).ToList(); /* Date in desc the bid was placed on */

            return bidHistoryOutputs;
        }

        public List<MaxBidOutput> GetBidderMaxBidForAdmin(string prefix, int bidderId)
        {
            List<MaxBidOutput> maxBidListOutput = new List<MaxBidOutput>();

            //Gets the project details
            var project = GetProjectByPrefix(prefix);
            if (project == null) { return maxBidListOutput; }

            //Gets the bidder details using biderid and project id
            var bidder = GetBidderForAdmin(bidderId, project.ProjectXid);
            if (bidder == null) { return maxBidListOutput; }

            // Check whether the max bid is enabled
            if (project.AllowMaxBidding)
            {
                //Get Currently Open Regular packages for this project
                var regularPackages = GetCurrentlyOpenRegularPackagesByProject(project.ProjectXid).Where(x => x.IsSaleCreated == null || (bool)x.IsSaleCreated).ToList();

                //Gets current high bid by project
                var highBidList = GetHighBidsByProject(project.ProjectXid).Where(y => y.BidderXid == bidder.BidderXid).ToList();

                var maxBidType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderListType, CodeLookupConstants.CodeBidderListType_MaxBid).CodeValue;

                foreach (var package in regularPackages)
                {
                    //check the package is sold
                    var hasBid = highBidList.FirstOrDefault(x => x.PackageXid == package.PackageXid);

                    bool hasMaxBid = false;

                    //Gets bidder has max bid
                    var getBidderMaxBidByPackage = GetBidderMaxBidByPackage(project.ProjectXid, package.PackageXid, maxBidType).Where(x => x.BidderXid == bidder.BidderXid).FirstOrDefault();

                    if (getBidderMaxBidByPackage != null)
                        hasMaxBid = (hasBid != null) ? (hasBid.Amount < getBidderMaxBidByPackage.MaxBidAmount) : true;

                    if (hasMaxBid)
                    {
                        var maxBidOutput = MapBidderIntoMaxBidOutput(getBidderMaxBidByPackage);
                        maxBidOutput.Name = package.Name;
                        maxBidOutput.Number = package.Number.Trim();
                        maxBidListOutput.Add(maxBidOutput);
                    }
                }
                maxBidListOutput = maxBidListOutput.OrderByDescending(x => x.CreatedDate).ToList(); // Date in desc the bid placed on
            }

            return maxBidListOutput;
        }

        public MaxBidOutput GetPackageMaxBidForAdmin(string prefix, int packageId)
        {
            var maxBidOutput = new MaxBidOutput();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return maxBidOutput; }

            var bidder = GetBidderByProjectId(project.ProjectXid);

            // Check whether the max bid is enabled
            if (project.AllowMaxBidding)
            {
                //Get Current Max Bid for this Package
                var currentMaxBidofPackage = GetPackageCurrentMaxBidByProject(project.ProjectXid).Where(x => x.PackageXid == packageId && x.MaxBidAmount != null).OrderByDescending(y => y.MaxBidAmount).FirstOrDefault();
                if (currentMaxBidofPackage != null)
                {
                    //Gets current high bid of package
                    var highBid = GetHighBidsByProject(project.ProjectXid).Where(y => y.PackageXid == packageId).FirstOrDefault();
                    if (highBid != null)
                    {
                        var isPurchased = IsSalePackageAvailableByPackageId(project.ProjectXid, packageId);
                        // check high bid amount is greater than current max bid amount
                        if (highBid.Amount < currentMaxBidofPackage.MaxBidAmount && !isPurchased)
                        {
                            maxBidOutput.PackageXid = currentMaxBidofPackage.PackageXid;
                            maxBidOutput.MaxBidAmount = currentMaxBidofPackage.MaxBidAmount;
                            var bidderDetail = bidder.Where(x => x.BidderXid == currentMaxBidofPackage.BidderXid).FirstOrDefault();
                            maxBidOutput.Name = bidderDetail.SupporterName;
                            maxBidOutput.Number = bidderDetail.Number.ToString();

                            return maxBidOutput;
                        }
                    }

                }
            }
            return null;
        }

        public PackageSearchOutput GetPackageDetailsForAdmin(string prefix, int packageId)
        {
            var packageDetail = new PackageSearchOutput();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return packageDetail; }

            var package = GetPackageForAdmin(packageId, project.ProjectXid);
            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;

            if (package != null)
            {
                var packageList = new List<Package>();
                packageList.Add(package);
                var packageSearchList = MapPackageSearchModalAndUpdateStatusForAdmin(packageList, project.ProjectXid);

                if (packageSearchList.Count > 0)
                    packageDetail = packageSearchList[0];

                //Get list of bids for project
                if (package.MobileBiddingTypeID == regularPackageType)
                {
                    var bidsCount = GetBidsByPackage(project.ProjectXid, packageId).Count();
                    packageDetail.BidCount = bidsCount;
                }
                else
                {
                    //Get Sale List by packageId
                    var saleCount = GetSalesByPackage(project.ProjectXid, packageId).Count();
                    packageDetail.BidCount = saleCount;
                }
            }

            return packageDetail;
        }

        public List<BidHistoryOutput> GetPackageBidHistoryForAdmin(string prefix, int packageId)
        {
            List<BidHistoryOutput> bidSaleHistoryList = new List<BidHistoryOutput>();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return bidSaleHistoryList; }

            var package = GetPackageForAdmin(packageId, project.ProjectXid);
            if (package == null) { return bidSaleHistoryList; }

            //Get bidder
            var bidderList = GetBidderByProjectIdForAdmin(project.ProjectXid);
            if (bidderList == null) { return bidSaleHistoryList; }

            //Get list of bids for project and package
            var bids = GetBidsByPackageForAdmin(project.ProjectXid, packageId);

            foreach (var bid in bids)
            {
                var bidder = bidderList.FirstOrDefault(z => z.BidderXid == bid.BidderXid);
                if (bidder != null)
                {
                    var bidHistoryOutput = MapBidIntoBidHistoryOutput(bid);
                    bidHistoryOutput.Name = bidder.SupporterName;
                    bidHistoryOutput.Number = (bidder.Number == null || bidder.Number == 0) ? string.Empty : bidder.Number.ToString();
                    bidSaleHistoryList.Add(bidHistoryOutput);
                }
            }

            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            if (package.MobileBiddingTypeID.Value != regularPackageType)
            {
                var saleList = GetSaleListByProjectForAdmin(project.ProjectXid).Where(x => x.PackageXid == packageId);
                foreach (var sale in saleList)
                {
                    var bidder = bidderList.FirstOrDefault(z => z.BidderXid == sale.BidderXid);
                    if (bidder != null)
                    {
                        var saleHistoryOutput = MapSaleIntoBidHistoryOutput(sale);
                        saleHistoryOutput.Name = bidder.SupporterName;
                        saleHistoryOutput.Number = bidder.Number.ToString();
                        bidSaleHistoryList.Add(saleHistoryOutput);
                    }
                }
            }
            bidSaleHistoryList = bidSaleHistoryList.OrderByDescending(x => x.CreatedDate).ToList(); // Date in desc the bid placed on

            return bidSaleHistoryList;
        }


        private BidderOutput MapBidderIntoBidderOutput(Bidder bidder)
        {
            var bidderOutput = new BidderOutput();
            bidderOutput.BidderXid = bidder.BidderXid;
            bidderOutput.ProjectXid = bidder.ProjectXid;
            bidderOutput.OnlineBidderKey = bidder.OnlineBidderKey;
            bidderOutput.SupporterName = bidder.SupporterName;
            bidderOutput.MobilePhones = bidder.MobilePhones;
            bidderOutput.Emails = bidder.Emails;
            bidderOutput.Number = bidder.Number;
            bidderOutput.TableNumber = bidder.TableNumber;

            return bidderOutput;
        }

        private BidderSearchOutput MapBidderIntoBidderSearchOutput(Bidder bidder)
        {
            var bidderSearchOutput = new BidderSearchOutput();
            bidderSearchOutput.BidderXid = bidder.BidderXid;
            bidderSearchOutput.ProjectXid = bidder.ProjectXid;
            bidderSearchOutput.SupporterName = bidder.SupporterName;
            bidderSearchOutput.MobilePhones = bidder.MobilePhones.Split(Convert.ToChar(AppConstants.CommaDelimiter)).Select(x => x).ToArray();
            bidderSearchOutput.Emails = bidder.Emails.Split(Convert.ToChar(AppConstants.EmailDelimiter)).Select(x => x).ToArray();
            bidderSearchOutput.Number = bidder.Number;
            bidderSearchOutput.TableNumber = bidder.TableNumber;
            bidderSearchOutput.IsDeleted = bidder.IsDeleted;

            return bidderSearchOutput;
        }

        public List<PackageOutput> GetTopPackagesForAdmin(string prefix, int count)
        {
            List<PackageOutput> packageListOutput = new List<PackageOutput>();

            decimal? currentHighBidAmount = 0;

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return packageListOutput; }

            var highBids = GetHighBidsByProject(project.ProjectXid);

            var regularPackages = GetRegularPackagesByProject(project.ProjectXid).Where(y => highBids.Select(z => z.PackageXid).Contains(y.PackageXid));

            foreach (var package in regularPackages)
            {
                if (highBids != null)
                    currentHighBidAmount = highBids.Where(x => x.PackageXid == package.PackageXid).Select(y => y.Amount).FirstOrDefault();

                var packageOutput = MapModel(package);
                packageOutput.CurrentHighBidAmount = currentHighBidAmount;
                packageListOutput.Add(packageOutput);
            }

            packageListOutput = packageListOutput.OrderByDescending(x => x.CurrentHighBidAmount).ThenBy(y => y.Number).ToList();

            if (count > 0)
                packageListOutput = packageListOutput.Take(count).ToList();

            return packageListOutput;
        }

        /// <summary>
        /// Get all packages for admin
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="input">input</param>
        /// <returns>List<PackageSearchOutput></returns>
        public List<PackageSearchOutput> GetAllPackagesForAdmin(string prefix, PackageSearchInput input)
        {
            List<PackageSearchOutput> packageSearchOutput = new List<PackageSearchOutput>();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return packageSearchOutput; }

            var getPackages = GetPackagesByProjectIdForAdmin(project.ProjectXid);
            var packageNameFilter = getPackages;
            var packageNumberFilter = getPackages;
            var categoryFilter = getPackages;
            var includePackagesFilter = getPackages;

            var AllCategoryFilterText = GetDisplayLookupByTypeCode(DisplayLookupConstants.DisplayType_CategoryFilter, DisplayLookupConstants.DisplayCategoryFilter_All).DisplayText;

            //Filter packages based on packagename
            if (!string.IsNullOrWhiteSpace(input.Name))
                packageNameFilter = getPackages.Where(x => x.Name.ToLower().Contains(input.Name.ToLower())).ToList();

            //Filter packages based on packagenumber
            if (!string.IsNullOrWhiteSpace(input.Number))
                packageNumberFilter = getPackages.Where(x => x.Number.ToLower().Contains(input.Number.ToLower())).ToList();

            //Filter packages based on category
            if (input.ClassName != AllCategoryFilterText)
            {
                GetAllClassesByProject(project.ProjectXid);
                categoryFilter = getPackages.Where(i => i.Class != null && i.Class.ClassName == input.ClassName).ToList();
            }

            //Filter packages based on includefilter
            if (input.ShouldNoBids || input.ShouldCurrentlyOpen || input.ShouldBuyNow || input.ShouldMultisale || input.ShouldPreview)
            {
                includePackagesFilter = IncludeFilteredPackagesForAdmin(project.ProjectXid, input);
            }

            var PackagesLists = new List<List<Package>>() { packageNameFilter, packageNumberFilter, categoryFilter, includePackagesFilter };
            var resultPackages = PackagesLists.Aggregate((previous, next) => previous.Intersect(next).ToList());

            var numberSortOrderValue = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BrowsePageSortOrderType, CodeLookupConstants.CodeBPSType_Number).CodeValue;

            //Sort order by package number by default
            var sortedPackages = GetPackagesWithSortOrder(resultPackages, project.ProjectXid, numberSortOrderValue, true);  /* true represent sortorder for admin */

            //map packages into packageSearchOutput with highbid, maxbid and status
            packageSearchOutput = MapPackageSearchModalAndUpdateStatusForAdmin(sortedPackages, project.ProjectXid);

            return packageSearchOutput;
        }

        /// <summary>
        /// return filtered packages based on input
        /// </summary>        
        /// <param name="project">project</param>
        /// <param name="input">input</param>
        /// <returns>List<Package></returns>
        public List<Package> IncludeFilteredPackagesForAdmin(int projectId, PackageSearchInput input)
        {
            var includePackages = new List<Package>();

            //get packages based on filter
            var noBidPackages = new List<Package>();
            var currentlyOpenPackages = new List<Package>();
            var buyNowPackages = new List<Package>();
            var multiSalePackages = new List<Package>();
            var previewPackages = new List<Package>();

            if (input.ShouldNoBids)
                noBidPackages = NoBidPackagesForAdmin(projectId);
            if (input.ShouldCurrentlyOpen)
                currentlyOpenPackages = CurrentlyOpenPackagesForAdmin(projectId);
            if (input.ShouldBuyNow)
                buyNowPackages = BuyNowPackagesForAdmin(projectId);
            if (input.ShouldMultisale)
                multiSalePackages = MultiSalePackagesForAdmin(projectId);
            if (input.ShouldPreview)
                previewPackages = PreviewOnlyPackagesForAdmin(projectId);

            var PackagesLists = new List<List<Package>>() { noBidPackages, currentlyOpenPackages, buyNowPackages, multiSalePackages, previewPackages };
            includePackages = PackagesLists.Aggregate((previous, next) => previous.Union(next).ToList());

            return includePackages;
        }

        /// <summary>
        /// Map packages into PackageSearchOutput
        /// </summary>        
        /// <param name="packages">packages</param>
        /// <param name="projectId">projectId</param>
        /// <returns>List<PackageSearchOutput></returns>
        public List<PackageSearchOutput> MapPackageSearchModalAndUpdateStatusForAdmin(List<Package> packages, int projectId)
        {
            var packageSearchOutputs = new List<PackageSearchOutput>();
            var biddingPackage = new BiddingPackage(_context);

            var soldPackages = SoldPackagesForAdmin(projectId);
            var closedPackage = ClosedPackagesForAdmin(projectId);
            var previewPackages = PreviewOnlyPackagesForAdmin(projectId);
            var openingSoonPackages = GetOpeningSoonPackagesByProjectForAdmin(projectId);
            var openPackages = GetOpenPackagesByProjectForAdmin(projectId);
            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_AdminPackageStatusType);
            var highBidList = GetHighBidsByProject(projectId);
            var packageCurrentMaxBidList = GetPackageCurrentMaxBidByProject(projectId);

            foreach (Package package in packages)
            {
                var mobileBiddingType = GetCodeLookupName(CodeLookupConstants.CodeType_MobileBiddingType, package.MobileBiddingTypeID);
                var hasMultisaleOrDonationOrAppeal = (mobileBiddingType == CodeLookupConstants.CodeMobileBiddingType_Givers || mobileBiddingType == CodeLookupConstants.CodeMobileBiddingType_Donation || mobileBiddingType == CodeLookupConstants.CodeMobileBiddingType_Live || mobileBiddingType == CodeLookupConstants.CodeMobileBiddingType_Appeal);

                var packageSearchOutput = new PackageSearchOutput();
                packageSearchOutput.ProjectXid = package.ProjectXid;
                packageSearchOutput.PackageXid = package.PackageXid;
                packageSearchOutput.Name = package.Name;
                packageSearchOutput.Number = package.Number.Trim();
                packageSearchOutput.ClassName = biddingPackage.GetClassNamebyID(package.ClassId);
                packageSearchOutput.Price = (package.Price != null)? package.Price : -1;                            /* -1 indicates Not applicable */
                if(!hasMultisaleOrDonationOrAppeal)
                {
                    packageSearchOutput.MinimumBid = (package.MinimumBid != null) ? package.MinimumBid : -1;        /* -1 indicates Not applicable */
                    packageSearchOutput.MinimumRaise = (package.MinimumRaise != null) ? package.MinimumRaise : -1;  /* -1 indicates Not applicable */
                }
                else
                {
                    packageSearchOutput.MinimumBid = null;
                    packageSearchOutput.MinimumRaise = null;
                    packageSearchOutput.Bid = null;
                    packageSearchOutput.MaxBid = null;
                }
                packageSearchOutput.EndTimeUTC = (!package.IsDeleted) ? package.EndTimeUTC : null;
                packageSearchOutput.StartTimeUTC = (!package.IsDeleted) ? (DateTime?)package.StartTimeUTC : null;
                packageSearchOutput.IsDeleted = package.IsDeleted;
                packageSearchOutput.Value = !string.IsNullOrEmpty(package.Value) ? ((Convert.ToDecimal(package.Value) == 0) ? null : Convert.ToDecimal(package.Value).ToString("0.00")) : null;
                packageSearchOutput.MobileBiddingType = mobileBiddingType;

                //update current high bid for package
                var currentHighBid = highBidList.FirstOrDefault(x => x.PackageXid == package.PackageXid);
                if (currentHighBid != null && !hasMultisaleOrDonationOrAppeal && !package.IsDeleted)
                    packageSearchOutput.Bid = currentHighBid.Amount;
                else if (!hasMultisaleOrDonationOrAppeal && currentHighBid == null)
                    packageSearchOutput.Bid = -1;                                                                   /* -1 indicates Not applicable */

                //update current maxbid for package
                var currentMaxBid = packageCurrentMaxBidList.FirstOrDefault(x => x.PackageXid == package.PackageXid);
                if (currentMaxBid != null && !hasMultisaleOrDonationOrAppeal && !package.IsDeleted)
                    packageSearchOutput.MaxBid = currentMaxBid.MaxBidAmount;
                else if (!hasMultisaleOrDonationOrAppeal && currentMaxBid == null)
                    packageSearchOutput.MaxBid = -1;                                                                /* -1 indicates Not applicable */

                //update package status
                if (packageSearchOutput.IsDeleted)
                    packageSearchOutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayAdminPackageStatusType_Deleted).DisplayText;
                else if (soldPackages.Select(y => y.PackageXid).Contains(package.PackageXid))
                    packageSearchOutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayAdminPackageStatusType_Sold).DisplayText;
                else if (closedPackage.Select(y => y.PackageXid).Contains(package.PackageXid))
                    packageSearchOutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayAdminPackageStatusType_Closed).DisplayText;
                else if (previewPackages.Select(y => y.PackageXid).Contains(package.PackageXid))
                    packageSearchOutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayAdminPackageStatusType_Preview).DisplayText;
                else if (openingSoonPackages.Select(y => y.PackageXid).Contains(package.PackageXid))
                    packageSearchOutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayAdminPackageStatusType_OpeningSoon).DisplayText;
                else if (openPackages.Select(y => y.PackageXid).Contains(package.PackageXid))
                    packageSearchOutput.Status = GetDisplayLookupByTypeCode(displayLookupList, DisplayLookupConstants.DisplayAdminPackageStatusType_Open).DisplayText;
               
                packageSearchOutputs.Add(packageSearchOutput);
            }
            return packageSearchOutputs;
        }

        public ResultMessage ClearMaxBidForAdmin(string prefix, int packageId)
        {
            ResultMessage result = new ResultMessage();
           
            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return result; }

            var deleteEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Delete).CodeValue;

            ClearMaxBidByPackage(project.ProjectXid, packageId, deleteEventType);  /* delete the max bid record by package */

            var updatedCount = _dbContext.SaveChanges();

            if(updatedCount > 0)
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            else
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;

            return result;
        }
        
        /// <summary>
        /// Save EmailTemplate
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <param name="emailMessage">emailMessage</param>
        /// <returns>ResultMessage</returns>
        public ResultMessage SaveEmailTemplateForAdmin(string prefix, EmailMessageFieldValues emailMessage)
        {
            ResultMessage result = new ResultMessage();

            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return result; }

            int insertCount = 0;
            /* save email template */
            if (!string.IsNullOrWhiteSpace(emailMessage.Subject) && !string.IsNullOrWhiteSpace(emailMessage.Message))
            {
                var insertEmailTemplate = new EmailTemplate()
                {
                    ProjectXid = project.ProjectXid,
                    Subject = emailMessage.Subject,
                    Message = emailMessage.Message,
                    CreatedDate = DateTime.UtcNow
                };
                _dbContext.EmailTemplates.Add(insertEmailTemplate);
                insertCount = _dbContext.SaveChanges();
            }

            if (insertCount > 0)
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            else
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;

            return result;
        }

        /// <summary>
        /// Get EmailTemplate
        /// </summary>        
        /// <param name="prefix">prefix</param>
        /// <returns>List<EmailTemplateOutput></returns>
        public List<EmailTemplateOutput> GetEmailTemplatesForAdmin(string prefix)
        {
            List<EmailTemplateOutput> emailTemplateOutputs = new List<EmailTemplateOutput>();
            var project = GetProjectByPrefix(prefix);
            if (project == null) { return emailTemplateOutputs; }

            var emailTemplates = GetEmailTemplatesByProject(project.ProjectXid);

            foreach(EmailTemplate emailTemplate in emailTemplates)
            {
                var insertEmailTemplateOutput = new EmailTemplateOutput()
                {
                    EmailTemplateID = emailTemplate.EmailTemplateID,
                    ProjectXid = emailTemplate.ProjectXid,
                    Subject = emailTemplate.Subject,
                    Message = emailTemplate.Message,
                    CreatedDate = emailTemplate.CreatedDate
                };
                emailTemplateOutputs.Add(insertEmailTemplateOutput);
            }

            return emailTemplateOutputs.OrderByDescending(x => x.CreatedDate).ToList();
        }

        /// <summary>
        /// Delete EmailTemplate
        /// </summary>        
        /// <param name="projectId">projectId</param>
        /// <param name="emailTemplateId">emailTemplateId</param>
        /// <returns>ResultMessage</returns>
        public ResultMessage DeleteEmailTemplateForAdmin(int projectId, int emailTemplateId)
        {
            ResultMessage result = new ResultMessage();

            var project = GetProject(projectId);
            if (project == null) { return result; }

            int deleteCount = 0;    /* Default delete count*/
            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            var getEmailTemplate = GetEmailTemplate(projectId, emailTemplateId);

            if(getEmailTemplate != null)
            {
                DeleteEmailTemplate(getEmailTemplate);
                deleteCount = _dbContext.SaveChanges();
            }
            
            if (deleteCount > 0)
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            else
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;

            return result;
        }               

        /// <summary>
        /// Get SMSTemplate
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>List<SMSTemplateOutput></returns>
        public List<SMSTemplateOutput> GetSMSTemplatesForAdmin(string prefix)
        {
            List<SMSTemplateOutput> smsTemplateOutputs = new List<SMSTemplateOutput>();

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return smsTemplateOutputs; }

            /* Get SMSTemplate */
            var smsTemplates = GetSMSTemplatesByProject(project.ProjectXid);
            if (smsTemplates.Count == 0) { return smsTemplateOutputs; }

            foreach (var output in smsTemplates)
            {
                var smsOutput = new SMSTemplateOutput();
                smsOutput.SMSTemplateID = output.SMSTemplateID;
                smsOutput.ProjectXid = output.ProjectXid;
                smsOutput.Message = output.Message;
                smsOutput.CreatedDate = output.CreatedDate;
                smsTemplateOutputs.Add(smsOutput);
            }

            return smsTemplateOutputs.OrderByDescending(x => x.CreatedDate).ToList(); /* Created Date in desc newest on top */
        }

        /// <summary>
        /// Save SMSTemplate
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="textMessageFieldValues">textMessageFieldValues</param>
        /// <returns>ResultMessage</returns>
        public ResultMessage SaveSMSTemplateForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues)
        {
            ResultMessage result = new ResultMessage();

            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            var project = GetProjectByPrefix(prefix);
            if (project == null) { return result; }

            int insertCount = 0;    /* insertCount default 0 */
            /* save SMS Templates */
            if (!string.IsNullOrWhiteSpace(textMessageFieldValues.Message))
            {
                var addSmsTemplate = new SMSTemplate();
                addSmsTemplate.ProjectXid = project.ProjectXid;
                addSmsTemplate.Message = textMessageFieldValues.Message;
                addSmsTemplate.CreatedDate = DateTime.UtcNow;

                _dbContext.SMSTemplates.Add(addSmsTemplate);
                insertCount = _dbContext.SaveChanges();
            }

            if (insertCount > 0)
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            else
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;

            return result;
        }

        /// <summary>
        /// Delete SMS Template
        /// </summary>
        /// <param name="projectId">projectId</param>
        /// <param name="smsTemplateId">smsTemplateId</param>
        /// <returns>ResultMessage</returns>
        public ResultMessage DeleteSMSTemplateForAdmin(int projectId, int smsTemplateId)
        {
            ResultMessage result = new ResultMessage();

            var project = GetProject(projectId);
            if (project == null) { return result; }

            int deletedCount = 0; /* delete count default 0*/
            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            var getSmsTemplate = GetSMSTemplate(projectId, smsTemplateId);
            if (getSmsTemplate != null)
            {
                DeleteSMSTemplate(getSmsTemplate);
                deletedCount = _dbContext.SaveChanges();
            }

            if (deletedCount > 0)
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            else
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;

            return result;
        }               

        /// <summary>
        /// Bid / Sale - Soft Delete
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="bidId">bidId</param>
        /// <param name="saleId">saleId</param>
        /// <returns></returns>
        public ResultMessage RemoveBidForAdmin(string prefix, int bidId, int saleId)
        {
            ResultMessage result = new ResultMessage();
            int updatedCount = 0;

            var displayLookupList = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            /* get project using Prefix */
            var project = GetProjectByPrefix(prefix);
            if (project == null) { return result; }

            /* Get Delete Event Type */
            var deleteEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Delete).CodeValue;
            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    /* Regular Packages */
                    if (bidId > 0)
                    {
                        /* get bid by bidid */
                        var bid = GetBidByBidIdForAdmin(bidId, project.ProjectXid);
                        if (bid == null) { return result; }
                                        
                        RemoveBid(bid, deleteEventType);                                            /* remove bid */

                        /* SALE - soft deleting sale record if exists and update package*/
                        var regularSales = GetSalesByPackage(bid.ProjectXid, bid.PackageXid).FirstOrDefault();
                        if (regularSales != null && regularSales.Amount == bid.Amount)
                        {
                            RemoveSale(regularSales,(int) bid.BidType, deleteEventType);            /* Remove Sale */

                            var regularPackage = GetPackage(regularSales.PackageXid, regularSales.ProjectXid);
                            if (regularPackage != null)
                                regularPackage.IsSaleCreated = null;                                /* update package IsSaleCreated to null for the package */
                        }
                    }
                    /* Multisale, Appeal and Donation Packages */
                    else if (saleId > 0)
                    {                        
                        var sale = GetSaleBySaleIdForAdmin(saleId, project.ProjectXid);             /* get sale by saleid */
                        if (sale == null) { return result; }
                        
                        var salePackage = GetPackage(sale.PackageXid, project.ProjectXid);          /* get packages by sale */
                        if (salePackage == null) { return result; }
                        
                        UpdatePackageByRemovedSale(sale, salePackage, deleteEventType, project);    /* Remove Sale entry and Update Package  */
                    }

                    updatedCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, updatedCount);

                    if (updatedCount > 0)
                        result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
                    else
                        result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
                }
                catch (Exception ex)
                {
                    int defaultResultCount = 0;  //By default ResultCount - 0 for Rollback
                    TransactionCommitOrRollback(transaction, defaultResultCount);
                    Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
                    result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
                }
            }           
            return result;
        }

        /// <summary>
        /// Remove all bids, sales,donations and Maxbid based on packages in the project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>Tuple<ResultMessage, List<Package>></returns>
        public Tuple<ResultMessage, List<Package>> RemoveAllBidsForAdmin(string prefix)
        {
            ResultMessage result = new ResultMessage();
            int updatedCount = 0;
            var resultModel = new Tuple<ResultMessage, List<Package>>(new ResultMessage(), new List<Package>());

            /* Gets the Result Status Type */
            var displayLookups = GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            /* Get Delete Event Type */
            var deleteEventType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EventType, CodeLookupConstants.CodeEventType_Delete).CodeValue;

            /* Get all package types */
            var packageTypes = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
            var regularPackageType = GetCodeLookupByTypeDescription(packageTypes, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var previewPackageType = GetCodeLookupByTypeDescription(packageTypes, CodeLookupConstants.CodeMobileBiddingType_Live).CodeValue;

            var project = GetProjectByPrefix(prefix);                                                       /* gets project using prefix */
            if (project == null) { return resultModel; }

            var packages = GetPackagesByProjectIdWithAppealDonation(project.ProjectXid);                    /* gets packages using project id */
            if (packages == null) { return resultModel; }

            using (var transaction = _dbContext.BeginTransaction())
            {
                try
                {
                    foreach (var packageItem in packages)
                    {
                        if (packageItem.MobileBiddingTypeID == regularPackageType)
                        {
                            RemovePackageBids(packageItem, deleteEventType);                                /* Remove Package bids */
                        }
                        else if (packageItem.MobileBiddingTypeID != previewPackageType)
                        {
                            RemovePackageSales(packageItem, packageTypes, project, deleteEventType);        /* Remove package multisale, donation and appeal */
                        }

                        ClearMaxBidByPackage(project.ProjectXid, packageItem.PackageXid, deleteEventType); /* delete the max bid record by package */
                    }

                    updatedCount = _dbContext.SaveChanges();
                    TransactionCommitOrRollback(transaction, updatedCount);

                    if (updatedCount > 0)
                        result.Message = displayLookups.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
                    else
                        result.Message = displayLookups.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
                }
                catch (Exception ex)
                {
                    int defaultResultCount = 0;                                                     /* By default ResultCount - 0 for Rollback */
                    TransactionCommitOrRollback(transaction, defaultResultCount);
                    Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
                    result.Message = displayLookups.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
                }
            }
            resultModel = new Tuple<ResultMessage, List<Package>>(result, packages);
            return resultModel;
        }

        /// <summary>
        /// Gets the all bidding history for the project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>List<ExportBidHistoryOutput></returns>
        public List<ExportBidHistoryOutput> ExportAllBiddingHistoryForAdmin(string prefix)
        {
            List<ExportBidHistoryOutput> exportbidHistoryOutputs = new List<ExportBidHistoryOutput>();

            var project = GetProjectByPrefix(prefix);                                               /* Get the project by prefix*/
            if (project == null)
            {
                return exportbidHistoryOutputs;
            }

            var bidderList = GetBidderByProjectIdForAdmin(project.ProjectXid);                      /* Gets the bidder by project id */
            if (bidderList == null)
            {
                return exportbidHistoryOutputs;
            }

            var packages = GetPackagesByProjectIdWithAppealDonation(project.ProjectXid);            /* Get packages by project id*/

            /* Primary Sort - package number by default */
            var sortedPackages = GetPackagesWithSortOrder(packages, project.ProjectXid, (int)project.BrowsePageSortOrder);

            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var multiSalePackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;

            var getBidsByProject = GetBidsByProjectForAdmin(project.ProjectXid);                    /*Get  bids by project id*/
            var getSalesByproject = GetSaleListByProjectForAdmin(project.ProjectXid);               /* Gets the Sale list by project id */
            
            foreach (Package package in sortedPackages)
            {
                var exportBidHistorySortList = new List<ExportBidHistoryOutput>();

                if (package.MobileBiddingTypeID == regularPackageType)
                {
                    var bids = getBidsByProject.Where(x => x.PackageXid == package.PackageXid).ToList(); /* Filters bids by package id */

                    foreach (var bid in bids)
                    {
                        var bidder = bidderList.FirstOrDefault(z => z.BidderXid == bid.BidderXid);   /* Filters the bidder details using bidder id*/
                        if (bidder != null)
                        {
                            var exportBidHistoryOutput = MapBidIntoExportBidHistoryOutput(bid, bidder);
                            exportBidHistoryOutput.PackageNumber = package.Number.Trim();
                            exportBidHistoryOutput.PackageName = package.Name;

                            /* Value for regular packages */
                            exportBidHistoryOutput.Value = (package.Value != null) ? string.Format(AppConstants.AmountFormat, package.Value) : string.Empty;

                            exportBidHistorySortList.Add(exportBidHistoryOutput);
                        }
                    }
                }
                else
                {
                    var sales = getSalesByproject.Where(x => x.PackageXid == package.PackageXid).ToList();  /* Filters the Sales by package id */

                    foreach (var sale in sales)
                    {
                        var bidder = bidderList.FirstOrDefault(z => z.BidderXid == sale.BidderXid);         /* Filters the bidder details using bidder id*/
                        if (bidder != null)
                        {
                            var exportSaleHistoryOutput = MapSaleIntoExportBidHistoryOutput(sale, bidder);
                            exportSaleHistoryOutput.PackageNumber = package.Number.Trim();
                            exportSaleHistoryOutput.PackageName = package.Name;
                            if (package.MobileBiddingTypeID == multiSalePackageType)
                            {
                                /* Value for multisale packages */
                                exportSaleHistoryOutput.Value = (package.Value != null) ? string.Format(AppConstants.AmountFormat, package.Value) : string.Empty;
                            }
                            else
                            {
                                exportSaleHistoryOutput.Value = null;
                            }

                            exportBidHistorySortList.Add(exportSaleHistoryOutput);
                        }
                    }
                }
                exportbidHistoryOutputs.AddRange(exportBidHistorySortList.OrderByDescending(x=>x.CreatedDate).ToList());
            }

            return exportbidHistoryOutputs;
        }

        public EmbedReportOutput EmbedReportLastUpdatedDateTimeByProject(string prefix)
        {
            EmbedReportOutput embedReportOutput = new EmbedReportOutput();
            var project = GetProjectByPrefix(prefix);                                               /* Get the project by prefix*/
            if (project == null)
            {
                return embedReportOutput;
            }

            var getEmbedReportByProject = GetEventStatistics(project.ProjectXid);

            if(getEmbedReportByProject != null)
            {
                embedReportOutput.UpdatedDate = getEmbedReportByProject.UpdatedDate;
            }
            return embedReportOutput;
        }

        #region Common methods 
        public List<Package> NoBidPackagesForAdmin(int projectId)
        {
            var resultPackages = new List<Package>();
            var OpeningSoonPackages = GetOpeningSoonRegularPackagesByProjectForAdmin(projectId);
            var PackagesLists = new List<List<Package>>() { GetNoBidPackagesByProjectForAdmin(projectId), GetNoSalePackagesByProjectForAdmin(projectId), GetOpenRegularPackagesByProjectForAdmin(projectId) };
            var currentlyOpenPackages = PackagesLists.Aggregate((previous, next) => previous.Intersect(next).ToList());

            resultPackages = OpeningSoonPackages.Union(currentlyOpenPackages).ToList();

            return resultPackages;
        }

        public List<Package> CurrentlyOpenPackagesForAdmin(int projectId)
        {
            var result = new List<Package>();
            var regularCurrentlyOpen = GetOpenRegularPackagesByProjectForAdmin(projectId).Intersect(GetNoSalePackagesByProjectForAdmin(projectId));
            var multiSaleCurrentlyOpen = GetOpenMultiSalePackagesByProjectForAdmin(projectId);

            result = regularCurrentlyOpen.Union(multiSaleCurrentlyOpen).ToList();

            return result;
        }

        public List<Package> BuyNowPackagesForAdmin(int projectId)
        {
            var buyNowPackages = new List<Package>();
            var getRegularPackagesByProject = GetRegularPackagesByProjectForAdmin(projectId);
            var getHighbidPackages = from p in getRegularPackagesByProject
                                     join h in GetHighBidsByProject(projectId) on p.PackageXid equals h.PackageXid
                                     where p.Price > 0 && h.Amount >= p.Price
                                     select p;

            var getRegularPackages = getRegularPackagesByProject.Where(x => x.Price > 0 && !getHighbidPackages.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            var getSoldRegularPackages = GetSalePackagesByProjectForAdmin(projectId).Where(x => getRegularPackagesByProject.Select(y => y.PackageXid).Contains(x.PackageXid)).ToList();

            var PackagesLists = new List<List<Package>>() { getRegularPackages, getSoldRegularPackages };
            buyNowPackages = PackagesLists.Aggregate((previous, next) => previous.Union(next).ToList());

            return buyNowPackages;
        }

        public List<Package> MultiSalePackagesForAdmin(int projectId)
        {
            var multisalePackages = GetMultiSalePackagesByProjectForAdmin(projectId).Where(i => i.Price > 0 && (i.MaxAvailable > 0 || i.MaxAvailable == null)).ToList();
            return multisalePackages;
        }

        public List<Package> PreviewOnlyPackagesForAdmin(int projectId)
        {
            var livePackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Live).CodeValue;
            var previewPackages = GetPackagesByProjectIdForAdmin(projectId).Where(i => i.MobileBiddingTypeID == livePackageType).ToList();

            return previewPackages;
        }

        public List<Package> SoldPackagesForAdmin(int projectId)
        {
            List<Package> soldPackages = new List<Package>();

            var regularPackageType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;

            var multiSalePackage = GetMultiSalePackagesByProjectForAdmin(projectId).Where(x => x.QtyRemaining == 0).ToList();

            soldPackages = GetSalePackagesByProjectForAdmin(projectId).Where(x => x.MobileBiddingTypeID == regularPackageType).ToList();

            soldPackages = soldPackages.Union(multiSalePackage).ToList();

            return soldPackages;
        }

        public List<Package> ClosedPackagesForAdmin(int projectId)
        {
            var currentDateTime = DateTime.UtcNow;

            var packageTypeList = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
            var regularPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Regular).CodeValue;
            var giversPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;

            var noBidsRegularPackages = GetNoBidPackagesByProjectForAdmin(projectId).Where(i => i.EndTimeUTC < currentDateTime && i.MobileBiddingTypeID == regularPackageType).ToList();

            var noSaleMultiPackages = GetNoSalePackagesByProjectForAdmin(projectId).Where(i => i.MaxAvailable > 0 && i.MobileBiddingTypeID == giversPackageType && i.EndTimeUTC < currentDateTime).ToList();

            var multiSalePackage = GetMultiSalePackagesByProjectForAdmin(projectId).Where(x => x.QtyRemaining > 0 && (x.QtyRemaining <= x.MaxAvailable) && x.EndTimeUTC < currentDateTime).ToList();

            var donationPackages = GetDonationPackagesByProjectForAdmin(projectId).Where(x => x.EndTimeUTC < currentDateTime).ToList();

            var PackagesLists = new List<List<Package>>() { noBidsRegularPackages, noSaleMultiPackages, multiSalePackage, donationPackages };
            var closedPackages = PackagesLists.Aggregate((previous, next) => previous.Union(next).ToList());

            return closedPackages;
        }

        public void UpdatePackageByRemovedSale(Sale sale, Package salePackage, int deleteEventType, Project project)
        {
            /*Gets all package type*/
                var packageTypeList = GetCodeLookupListByType(CodeLookupConstants.CodeType_MobileBiddingType);
            var multiSalePackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Givers).CodeValue;
            var appealPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Appeal).CodeValue;
            var donationPackageType = GetCodeLookupByTypeDescription(packageTypeList, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;

            if (salePackage.MobileBiddingTypeID != null)
            {
                /* MultiSale Packages */
                if (salePackage.MobileBiddingTypeID == multiSalePackageType)
                {
                    var buyActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Buy).CodeValue;

                    RemoveSale(sale, buyActionType, deleteEventType);                                       /* remove sale */

                    /* update Purchased Quantity and  Remaining Quantity for the package */
                    int purchasedQuantity = (sale.QtyPurchased ?? 0);
                    salePackage.QtyPurchased = (salePackage.QtyPurchased ?? 0) - purchasedQuantity;

                    if (salePackage.MaxAvailable != null)
                        salePackage.QtyRemaining = (salePackage.QtyRemaining ?? 0) + purchasedQuantity;
                }

                /* Appeal package */
                if (salePackage.MobileBiddingTypeID == appealPackageType)
                {
                    var appealActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Donation).CodeValue;

                    RemoveSale(sale, appealActionType, deleteEventType);                                    /* remove sale */

                    if (project.AppealTotalRaised != null)
                        project.AppealTotalRaised =  project.AppealTotalRaised - sale.Amount ;
                }

                /* Donation package */
                if (salePackage.MobileBiddingTypeID == donationPackageType)
                {
                    var donationActionType = GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_BidderActionType, CodeLookupConstants.CodeBidderActionType_Donation).CodeValue;

                    RemoveSale(sale, donationActionType, deleteEventType);                                  /* remove sale */
                }
            }
        }

        #endregion Common methods 

        #region Map Model 

        private PackageOutput MapModel(Package package)
        {
            var packageoutput = new PackageOutput();
            packageoutput.PackageXid = package.PackageXid;
            packageoutput.ProjectXid = package.ProjectXid;
            packageoutput.Name = package.Name;
            packageoutput.Number = package.Number.Trim();
            packageoutput.Price = package.Price;
            return packageoutput;
        }

        private MaxBidOutput MapBidderIntoMaxBidOutput(BidderList bidderLists)
        {
            var maxBidOutput = new MaxBidOutput();
            maxBidOutput.BidderId = bidderLists.BidderXid;
            maxBidOutput.PackageXid = bidderLists.PackageXid;
            maxBidOutput.MaxBidAmount = bidderLists.MaxBidAmount;
            maxBidOutput.CreatedDate = bidderLists.CreatedDate;
            return maxBidOutput;
        }

        private BidHistoryOutput MapBidIntoBidHistoryOutput(Bid bid)
        {
            var bidHistoryOutput = new BidHistoryOutput();
            bidHistoryOutput.BidXid = bid.BidXid;
            bidHistoryOutput.BidderXid = bid.BidderXid;
            bidHistoryOutput.PackageXid = bid.PackageXid;
            bidHistoryOutput.CreatedDate = bid.CreatedDate;
            bidHistoryOutput.ProjectXid = bid.ProjectXid;
            bidHistoryOutput.Amount = bid.Amount;
            bidHistoryOutput.IsDeleted = bid.IsDeleted;

            return bidHistoryOutput;
        }

        private BidHistoryOutput MapSaleIntoBidHistoryOutput(Sale sale)
        {
            var bidHistoryOutput = new BidHistoryOutput();
            bidHistoryOutput.SaleId = sale.SaleID;
            bidHistoryOutput.BidderXid = sale.BidderXid;
            bidHistoryOutput.PackageXid = sale.PackageXid;
            bidHistoryOutput.CreatedDate = sale.SaleDate;
            bidHistoryOutput.ProjectXid = sale.ProjectXid;
            bidHistoryOutput.Amount = sale.Amount;
            bidHistoryOutput.IsDeleted = sale.IsDeleted;

            return bidHistoryOutput;
        }

        private ExportBidHistoryOutput MapBidIntoExportBidHistoryOutput(Bid bid, Bidder bidder)
        {
            var exportBidHistoryOutput = new ExportBidHistoryOutput();
            exportBidHistoryOutput.PackageXid = bid.PackageXid;
            exportBidHistoryOutput.BidderXid = bid.BidderXid;
            exportBidHistoryOutput.BidXid = bid.BidXid;
            exportBidHistoryOutput.CreatedDate = bid.CreatedDate;
            exportBidHistoryOutput.ProjectXid = bid.ProjectXid;
            exportBidHistoryOutput.Amount = bid.Amount;
            exportBidHistoryOutput.IsDeleted = bid.IsDeleted;
            exportBidHistoryOutput.BidderName = bidder.SupporterName;
            exportBidHistoryOutput.BidderNumber = (bidder.Number == null || bidder.Number == 0) ? string.Empty : bidder.Number.ToString();
            exportBidHistoryOutput.MobilePhones = bidder.MobilePhones;
            exportBidHistoryOutput.Emails = bidder.Emails;
            
            return exportBidHistoryOutput;
        }

        private ExportBidHistoryOutput MapSaleIntoExportBidHistoryOutput(Sale sale, Bidder bidder)
        {
            var exportBidHistoryOutput = new ExportBidHistoryOutput();
            exportBidHistoryOutput.PackageXid = sale.PackageXid;
            exportBidHistoryOutput.BidderXid = sale.BidderXid;
            exportBidHistoryOutput.SaleId = sale.SaleID;
            exportBidHistoryOutput.CreatedDate = sale.SaleDate;
            exportBidHistoryOutput.ProjectXid = sale.ProjectXid;
            exportBidHistoryOutput.Amount = sale.Amount;
            exportBidHistoryOutput.IsDeleted = sale.IsDeleted;
            exportBidHistoryOutput.BidderName = bidder.SupporterName;
            exportBidHistoryOutput.BidderNumber = (bidder.Number == null || bidder.Number == 0) ? string.Empty : bidder.Number.ToString();
            exportBidHistoryOutput.MobilePhones = bidder.MobilePhones;
            exportBidHistoryOutput.Emails = bidder.Emails;

            return exportBidHistoryOutput;
        }
        #endregion Map Model 
    }
}
