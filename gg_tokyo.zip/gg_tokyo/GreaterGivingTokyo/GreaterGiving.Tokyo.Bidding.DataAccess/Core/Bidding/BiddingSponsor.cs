﻿using System;
using System.Collections.Generic;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using CommonUtil = GreaterGiving.Tokyo.Common.Reusables;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding
{
    public class BiddingSponsor : BiddingBase
    {
        /// <summary>
        /// BiddingSponsor Constructor for setting the context
        /// </summary>
        /// <param name="context"></param>
        public BiddingSponsor(IBiddingContext context) : base(context)
        { }

        /// <summary>
        /// Get Sponsor Details using SponsorXid
        /// </summary>
        /// <param name="SponsorXid">SponsorXid</param>
        /// <returns>SponsorOutput</returns>
        public SponsorOutput GetSponsorBySponsorId(int sponsorXid)
        {
            var resultSponsor = new SponsorOutput();
            var sponsor = GetSponsor(sponsorXid);
            if (sponsor != null)
            {
                resultSponsor.ProjectXid = sponsor.ProjectXid;
                resultSponsor.ImagePath = ConfigManager.CdnProjectAssetsEndpoint + "/" + sponsor.ImagePath;
                resultSponsor.SponsorXid = sponsor.SponsorXid;
            }
            return resultSponsor;
        }

        /// <summary>
        /// Get Sponsor Images
        /// </summary>
        /// <param name="SponsorXid">SponsorXid</param>
        /// <returns>List<SponsorOutput></SponsorOutput></returns>
        public List<SponsorOutput> GetSponsorImagesByPrefix(string prefix)
        {
            var resultSponsorList = new List<SponsorOutput>();
            var project = GetProjectByPrefix(prefix);

            if (project == null) return null;
            
            var sponsors = GetSponsorByProjectId(project.ProjectXid);
            if (sponsors != null)
            {
                foreach (var sponsor in sponsors)
                {
                    var sponsorOutPut = new SponsorOutput();
                    sponsorOutPut.SponsorXid = sponsor.SponsorXid;
                    sponsorOutPut.ProjectXid = sponsor.ProjectXid;
                    if (!string.IsNullOrWhiteSpace(sponsor.ImagePath))
                        sponsorOutPut.ImagePath = ConfigManager.CdnProjectAssetsEndpoint + "/" + sponsor.ImagePath;
                    resultSponsorList.Add(sponsorOutPut);
                }
            }
            return resultSponsorList;
        }
        

        /// <summary>
        /// Adds Or Updates the sponsor details
        /// </summary>
        /// <param name="sponsor">sponsor</param>
        /// <returns>ResultModel</returns>
        public ResultModel AddOrUpdateSponsor(SponsorFieldValues sponsor)
        {
            ResultModel result = new ResultModel();

            try
            {
                if(sponsor.SponsorXid == 0)                
                    return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error005);               

                var addUpdateSponsor = GetSponsorForAdmin(sponsor.SponsorXid, sponsor.ProjectXid);

                if (addUpdateSponsor == null)
                {
                    /* insert Sponsor */
                    Sponsor createSponsor = new Sponsor();
                    createSponsor.SponsorXid = sponsor.SponsorXid;
                    createSponsor.ProjectXid = sponsor.ProjectXid;
                    createSponsor.CreatedDate = DateTime.UtcNow;

                    _dbContext.Sponsors.Add(createSponsor);
                    var isInserted = _dbContext.SaveChanges();
                    if (isInserted > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        InsertSponsorEventLog(createSponsor, CodeLookupConstants.CodeEventType_Insert);
                    }
                }
                else
                {
                    /* Update Sponsor */
                    addUpdateSponsor.SponsorXid = sponsor.SponsorXid;
                    addUpdateSponsor.ProjectXid = sponsor.ProjectXid;
                    addUpdateSponsor.UpdatedDate = DateTime.UtcNow;

                    if (sponsor.Images == null)
                        addUpdateSponsor.Images = null;

                    var reenableSponsor = false;
                    /* Re enable sponsor */
                    if (addUpdateSponsor.IsDeleted)
                    {
                        addUpdateSponsor.IsDeleted = false;
                        reenableSponsor = true;
                    }

                    var isUpdated = _dbContext.SaveChanges();

                    if (isUpdated > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        if (reenableSponsor)
                            InsertSponsorEventLog(addUpdateSponsor, CodeLookupConstants.CodeEventType_Reenable);
                    }
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info004);
                }
                Logger.WriteInfoLog(string.Format("Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
            }
            catch (Exception ex)
            {
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
            }

            return result;
        }

        /// <summary>
        /// Deletes the sponsor details
        /// </summary>
        /// <param name="sponsorid">sponsorid</param>
        /// <returns>ResultModel</returns>
        public ResultModel DeleteSponsor(int sponsorid)
        {
            ResultModel result = new ResultModel();
            try
            {
                if (sponsorid == 0)
                    return MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error005);

                var deleteSponsor = GetSponsor(sponsorid);
                if (deleteSponsor != null)
                {
                    //delete Sponsor                    
                    deleteSponsor.IsDeleted = true;
                    deleteSponsor.UpdatedDate = DateTime.UtcNow;

                    var isDeleted = _dbContext.SaveChanges();
                    if (isDeleted > 0)
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
                        InsertSponsorEventLog(deleteSponsor, CodeLookupConstants.CodeEventType_Delete);
                    }
                    else
                        result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info009);
                }
                else
                    result = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);
                Logger.WriteInfoLog(string.Format("Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
            }
            catch (Exception ex)
            {
                Logger.WriteErrorLog(string.Format("Error: {0}", CommonUtil.Utils.GetCompleteExceptionString(ex)));
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
            }

            return result;
        }

        private void InsertSponsorEventLog(Sponsor sponsor, string eventType)
        {
            EventLog eventLog = new EventLog();
            eventLog.ProjectXid = sponsor.ProjectXid;
            eventLog.SponsorXid = sponsor.SponsorXid;
            eventLog.EventDate = DateTime.UtcNow;
            InsertEventLog(eventLog, eventType);
        }
    }
}
