﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using GreaterGiving.Tokyo.Bidding.DataAccess.Contracts;
using GreaterGiving.Tokyo.Bidding.DataAccess.Factory;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;

namespace GreaterGiving.Tokyo.Admin.DataAccess.Core
{
    [Export(typeof(IBiddingData)), LogAspect, PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class BiddingData : IBiddingData
    {
        #region Constructors

        public BiddingData()
        {

        }

        #endregion Constructors

        #region Project

        bool IBiddingData.ValidateProject(int projectXid)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.ValidateProject(projectXid);
            }
        }

        ProjectOutput IBiddingData.GetProject(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.GetProject(prefix);
            }
        }

        ProjectOutput IBiddingData.GetProjectByProjectKey(string projectKey)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.GetProjectByProjectKey(projectKey);
            }
        }

        Project IBiddingData.GetProjectByProjectId(int projectXid)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.GetProjectByProjectId(projectXid);
            }
        }

        Project IBiddingData.GetProjectDetails(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.GetProjectDetails(prefix);
            }
        }

        ResultModel IBiddingData.IsShortNameAvailable(string shortName)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.IsShortNameAvailable(shortName);
            }
        }

        ResultModel IBiddingData.CreateProject(ProjectFieldValues project)
        {
            // Logging of member values in complex types
            Logger.WriteInfoLog($"ProjectFieldValues: {nameof(project.ProjectXid)}='{project.ProjectXid}', " +
                                $"{nameof(project.Prefix)}='{project.Prefix}'");

            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.CreateProject(project);
            }
        }

        ResultModel IBiddingData.UpdateProject(ProjectFieldValues project)
        {
            // Logging of member values in complex types
            Logger.WriteInfoLog($"ProjectFieldValues: {nameof(project.ProjectXid)}='{project.ProjectXid}', " +
                                $"{nameof(project.Prefix)}='{project.Prefix}'");
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.UpdateProject(project);
            }
        }

        ResultModel IBiddingData.DeleteProject(int projectid)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.DeleteProject(projectid);
            }
        }

        int IBiddingData.InsertSMSRequest(TextMessageFieldValues message, int purpose)
        {
            // Logging of member values in complex types
            Logger.WriteInfoLog($"TextMessageFieldValues: {nameof(message.ProjectXid)}='{message.ProjectXid}', " +
                                $"{nameof(message.Phone)}='{message.Phone}', {nameof(message.Message)}='{message.Message}', {nameof(purpose)}='{purpose}'");

            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.InsertSMSRequest(message, purpose);
            }
        }

        bool IBiddingData.InsertSMSDeliveryStatus(int smsRequestId, string toPhoneNumber, string statusIndicator, DateTime sendTime, DateTime deliveryTime, string sId, int? bidderId)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.InsertSMSDeliveryStatus(smsRequestId, toPhoneNumber, statusIndicator, sendTime, deliveryTime, sId, bidderId);
            }
        }

        void IBiddingData.InsertSMSErrorLog(string errorCode,string errorMsg,string phoneNo)
        {   
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                obj.InsertSMSErrorLog(errorCode, errorMsg, phoneNo);
            }
        }

        void IBiddingData.UpdateSMSStatus(int smsrequestId, string statusIndicator, string smsSid)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                obj.UpdateSMSStatus(smsrequestId, statusIndicator, smsSid);
            }
        }

        int IBiddingData.InsertEmailRequest(EmailMessageFieldValues emailMessage, int projectId,int purpose)
        {
            // Logging of member values in complex types
            Logger.WriteInfoLog($"EmailMessageFieldValues: {nameof(emailMessage.Subject)}='{emailMessage.Subject}', " +
                                 $"{nameof(emailMessage.FromEmailAddress)}='{emailMessage.FromEmailAddress}', {nameof(emailMessage.ToEmailAddress)}='{emailMessage.ToEmailAddress}', " + $"{ nameof(emailMessage.Message)}= '{emailMessage.Message}', " + $"{ nameof(purpose)}= '{purpose}'");

            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.InsertEmailRequest(emailMessage, projectId, purpose);
            }
        }

        bool IBiddingData.InsertEmailDeliveryStatus(EmailDeliveryStatusInput emailDeliveryStatusInput)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                return obj.InsertEmailDeliveryStatus(emailDeliveryStatusInput);
            }
        }

        void IBiddingData.InsertUnsubscribePhoneNo(string phoneNo)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                obj.InsertUnsubscribePhoneNo(phoneNo);
            }
        }

        void IBiddingData.DeleteUnsubscribePhoneNo(string phoneNo)
        {
            using (var obj = BiddingFactory.GetBiddingProject())
            {
                obj.DeleteUnsubscribePhoneNo(phoneNo);
            }
        }

        List<SMSUnsubscribe> IBiddingData.GetUnsubscribePhoneNos()
        {
            using (var obj = BiddingFactory.GetBiddingBaseData())
            {
                return obj.GetSMSUnsubscribePhoneNos();
            }
        }

        #endregion Project

        #region Package

        List<PackageOutput> IBiddingData.GetAllPackages(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetAllPackages(prefix);
            }
        }

        List<PackageOutput> IBiddingData.GetRelatedPackages(string prefix, int packageXid, string displayedPackages)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetRelatedPackages(prefix, packageXid, displayedPackages);
            }
        }

        Package IBiddingData.GetPackagebyPackageId(int packageXid)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetPackagebyPackageId(packageXid);
            }
        }

        PackageOutput IBiddingData.GetPackagebyPackageId(string prefix, int packageXid)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetPackagebyPackageId(prefix, packageXid);
            }
        }

        List<PackageOutput> IBiddingData.GetPackages(string prefix, int pageno, int size, string packageFilterType)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetPackages(prefix, pageno, size, packageFilterType);
            }
        }

        Package IBiddingData.GetPackageBySaleId(int saleId)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetPackageBySaleId(saleId);
            }
        }

        PackageOutput IBiddingData.GetAppealDonationPackage(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetAppealDonationPackage(prefix);
            }
        }

        ResultModel IBiddingData.AddOrUpdatePackage(PackageFieldValues package)
        {
            Logger.WriteInfoLog($"AddOrUpdatePackage: {nameof(package.ProjectXid)}='{package.ProjectXid}', " +
                                $"{nameof(package.PackageXid)}='{package.PackageXid}'");
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.AddOrUpdatePackage(package);
            }
        }

        ResultModel IBiddingData.DeletePackage(int packageId)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.DeletePackage(packageId);
            }
        }

        ResultModel IBiddingData.UpdateTimeAndItemTypeForPackages(BulkPackageFieldValues package)
        {
            Logger.WriteInfoLog($"UpdateTimeAndItemTypeForPackages: {nameof(package.ProjectXid)}='{package.ProjectXid}'");
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.UpdateTimeAndItemTypeForPackages(package);
            }
        }

        List<string> IBiddingData.GetPackageTypesByProject(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetPackageTypesByProject(prefix);
            }
        }

        List<string> IBiddingData.GetCategoryTypesByProject(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetCategoryTypesByProject(prefix);
            }
        }

        List<PackageOutput> IBiddingData.SearchPackagesByPackageNameOrNumber(string prefix, int pageno, int size, string packageNameOrNumber)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.SearchPackagesByPackageNameOrNumber(prefix, pageno, size, packageNameOrNumber);
            }
        }

        List<PackageOutput> IBiddingData.GetPackagesByCategory(string prefix, int pageno, int size, string categoryName)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetPackagesByCategory(prefix, pageno, size, categoryName);
            }
        }

        List<PackageOutput> IBiddingData.NoBidPackagesFilter(Project project)
        {
            Logger.WriteInfoLog($"project: {nameof(project.ProjectXid)}='{project.ProjectXid}', " +
                                $"{nameof(project.Prefix)}='{project.Prefix}'");
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.NoBidPackagesFilter(project);
            }
        }

        List<PackageOutput> IBiddingData.OpeningSoonPackagesFilter(Project project)
        {
            Logger.WriteInfoLog($"project: {nameof(project.ProjectXid)}='{project.ProjectXid}', " +
                                $"{nameof(project.Prefix)}='{project.Prefix}'");
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.OpeningSoonPackagesFilter(project);
            }
        }

        List<PackageOutput> IBiddingData.CurrentlyOpenPackagesFilter(Project project)
        {
            Logger.WriteInfoLog($"project: {nameof(project.ProjectXid)}='{project.ProjectXid}', " +
                                $"{nameof(project.Prefix)}='{project.Prefix}'");
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.CurrentlyOpenPackagesFilter(project);
            }
        }

        List<PackageOutput> IBiddingData.BuyNowPackagesFilter(Project project)
        {
            Logger.WriteInfoLog($"project: {nameof(project.ProjectXid)}='{project.ProjectXid}', " +
                                $"{nameof(project.Prefix)}='{project.Prefix}'");
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.BuyNowPackagesFilter(project);
            }
        }

        List<PackageOutput> IBiddingData.MultiSalePackagesFilter(Project project)
        {
            Logger.WriteInfoLog($"project: {nameof(project.ProjectXid)}='{project.ProjectXid}', " +
                                $"{nameof(project.Prefix)}='{project.Prefix}'");
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.MultiSalePackagesFilter(project);
            }
        }

        List<PackageOutput> IBiddingData.PreviewOnlyPackagesFilter(Project project)
        {
            Logger.WriteInfoLog($"project: {nameof(project.ProjectXid)}='{project.ProjectXid}', " +
                                $"{nameof(project.Prefix)}='{project.Prefix}'");
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.PreviewOnlyPackagesFilter(project);
            }
        }

        /// <summary>
        /// Get favorite packages by bidder
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="BidderId">BidderId</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <returns>PackageOutput</returns>
        List<PackageOutput> IBiddingData.GetFavoritePackagesByBidder(string prefix, int pageno, int size)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetFavoritePackagesByBidder(prefix, pageno, size);
            }
        }

        /// <summary>
        /// Get Bid Activity packages by bidder
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="bidderId">bidderId</param>
        /// <param name="activityType">activityType</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <returns>PackageOutput</returns>
        List<PackageOutput> IBiddingData.GetBidActivityByBidder(string prefix, string activityType, int pageno, int size)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetBidActivityByBidder(prefix, activityType, pageno, size);
            }
        }

        /// <summary>
        /// Add or Remove favorites to bidderlist
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <param name="BidderId">BidderId</param>
        /// <param name="isFavorite">isFavorite</param>
        void IBiddingData.AddOrRemoveFavorite(string prefix, int packageId, bool isFavorite)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                obj.AddOrRemoveFavorite(prefix, packageId, isFavorite);
            }
        }

        /// <summary>
        /// Add Bid
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <param name="amount">amount</param>
        /// <param name="bidType">bidType</param>
        /// <returns>ResultMessage</returns>
        ResultMessage IBiddingData.AddBid(string prefix, int packageId, decimal amount, string bidType)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.AddBid(prefix, packageId, amount, bidType);
            }
        }

        /// <summary>
        /// Set Max Bid
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <param name="amount">amount</param>
        /// <param name="bidType">bidType</param>
        /// <returns>ResultMessage</returns>
        ResultMessage IBiddingData.SetMaxBid(string prefix, int packageId, decimal amount, string bidType)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.SetMaxBid(prefix, packageId, amount, bidType);
            }
        }

        /// <summary>
        /// Buy Regular Package
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <returns>Sale</returns>
        Sale IBiddingData.BuyRegularPackage(string prefix, int packageId)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.BuyRegularPackage(prefix, packageId);
            }
        }

        /// <summary>
        /// Buy MultiSale Packages
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <param name="quantity">quantity</param>
        /// <returns>Sale</returns>
        Sale IBiddingData.BuyMultiSalePackages(string prefix, int packageId, int quantity)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.BuyMultiSalePackages(prefix, packageId, quantity);
            }
        }

        /// <summary>
        /// Buy Donation Packages
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <param name="amount">amount</param>
        /// <returns>Sale</returns>
        Sale IBiddingData.BuyDonationPackage(string prefix, int packageId, decimal amount)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.BuyDonationPackage(prefix, packageId, amount);
            }
        }

        /// <summary>
        /// Buy Appeal Donation Packages
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="donationAmount">donationAmount</param>
        /// <returns>Sale</returns>
        Sale IBiddingData.BuyAppealDonationPackage(string prefix, decimal donationAmount)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.BuyAppealDonationPackage(prefix, donationAmount);
            }
        }

        List<DisplayLookup> IBiddingData.GetDisplayLookupListByType(string type)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetDisplayLookupListByType(type);
            }
        }

        Bidder IBiddingData.GetCurrentBidderDetails()
        {
            using (var obj = BiddingFactory.GetBiddingBaseData())
            {
                return obj.GetCurrentBidderByBidderKey();
            }
        }

        CodeLookup IBiddingData.GetCodeLookupByTypeDescription(string type, string description)
        {
            using (var obj =  BiddingFactory.GetBiddingBaseData())
            {
                return obj.GetCodeLookupByTypeDescription(type, description);
            }
        }
                
        void IBiddingData.UpdateSaleGGOUpdateStatus(int saleId, int ggoUpdateStatus)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                obj.UpdateSaleGGOUpdateStatus(saleId, ggoUpdateStatus);
            }
        }

        List<PackageOutput> IBiddingData.GetLeaderBoardPackages(string prefix, LeaderBoardInput input)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetLeaderBoardPackages(prefix, input);
            }
        }


        CountdownBoardOutput IBiddingData.GetFurthestPackageClosingTimeByProject(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetFurthestPackageClosingTimeByProject(prefix);
            }
        }

        void IBiddingData.UpdateEventStatisticsReport(int projectXid)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                obj.UpdateEventStatisticsReport(projectXid);
            }
        }

        #endregion Package Members

        #region Bidder

        /// <summary>
        /// Inserts or Update Bidder
        /// </summary>
        /// <param name="bidder">bidder</param>
        /// <returns>Result Model</returns>
        ResultModel IBiddingData.AddOrUpdateBidder(BidderFieldValues bidder)
        {
            Logger.WriteInfoLog($"BidderFieldValues: {nameof(bidder.ProjectXid)}='{bidder.ProjectXid}', " +
                    $"{nameof(bidder.BidderXid)}='{bidder.BidderXid}'");

            using (var obj = BiddingFactory.GetBiddingBidder())
            {
                return obj.AddOrUpdateBidder(bidder);
            }
        }

        /// <summary>
        /// Deletes the bidder details 
        /// </summary>
        /// <param name="bidderId">bidderId</param>
        /// <returns>result model</returns>
        ResultModel IBiddingData.DeleteBidder(int bidderId)
        {
            using (var obj = BiddingFactory.GetBiddingBidder())
            {
                return obj.DeleteBidder(bidderId);
            }
        }

        /// <summary>
        /// Get bidder history or current buyers
        /// </summary>
        /// <param name="packageid">packageid</param>
        /// <returns>BidderOutput</returns>
        List<BidderOutput> IBiddingData.GetBidderHistoryOrCurrentBuyers(string prefix, int packageid)
        {
            using (var obj = BiddingFactory.GetBiddingBidder())
            {
                return obj.GetBidderHistoryOrCurrentBuyers(prefix, packageid);
            }
        }
                
        Bidder IBiddingData.GetBidderByBidderKey(string bidderKey)
        {
            using (var obj = BiddingFactory.GetBiddingBidder())
            {
                return obj.GetBidderByBidderKey(bidderKey);
            }
        }
        
        List<Bidder> IBiddingData.GetBidderByProjectId(int projectId)
        {
            using (var obj = BiddingFactory.GetBiddingBidder())
            {
                return obj.GetBidderByProjectId(projectId);
            }
        }
        
        #endregion Bidder

        #region Sponsor

        SponsorOutput IBiddingData.GetSponsorBySponsorId(int sponsorXid)
        {
            using (var obj = BiddingFactory.GetBiddingSponsor())
            {
                return obj.GetSponsorBySponsorId(sponsorXid);
            }
        }

        List<SponsorOutput> IBiddingData.GetSponsorImagesByPrefix(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingSponsor())
            {
                return obj.GetSponsorImagesByPrefix(prefix);
            }
        }
        

        ResultModel IBiddingData.AddOrUpdateSponsor(SponsorFieldValues sponsor)
        {
            Logger.WriteInfoLog($"AddOrUpdateSponsor: {nameof(sponsor.ProjectXid)}='{sponsor.ProjectXid}', " +
                    $"{nameof(sponsor.SponsorXid)}='{sponsor.SponsorXid}'");
            using (var obj = BiddingFactory.GetBiddingSponsor())
            {
                return obj.AddOrUpdateSponsor(sponsor);
            }
        }

        ResultModel IBiddingData.DeleteSponsor(int sponsorid)
        {
            using (var obj = BiddingFactory.GetBiddingSponsor())
            {
                return obj.DeleteSponsor(sponsorid);
            }
        }
        #endregion Sponsor

        #region Bid

        Bid IBiddingData.GetBidByBidId(int bidId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetBidByBidId(bidId);
            }
        }

        List<Bid> IBiddingData.GetBidsByProject(int projectId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetBidsByProject(projectId);
            }
        }

        #endregion Bid

        #region Sale

        Sale IBiddingData.GetSaleBySaleId(int saleId)
        {
            using (var obj = BiddingFactory.GetBiddingPackage())
            {
                return obj.GetSaleBySaleId(saleId);
            }
        }

        #endregion Sale

        #region Admin

        List<BidderOutput> IBiddingData.GetTopBiddersForAdmin(string prefix, int count)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetTopBiddersForAdmin(prefix, count);
            }
        }

        List<BidderSearchOutput> IBiddingData.GetAllBiddersForAdmin(string prefix, BidderSearchInput bidderSearchInput)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetAllBiddersForAdmin(prefix, bidderSearchInput);
            }
        }

        List<PackageOutput> IBiddingData.GetTopPackagesForAdmin(string prefix, int count)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetTopPackagesForAdmin(prefix, count);
            }
        }

        List<PackageSearchOutput> IBiddingData.GetAllPackagesForAdmin(string prefix, PackageSearchInput input)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetAllPackagesForAdmin(prefix, input);
            }
        }
        BidderSearchOutput IBiddingData.GetBidderDetailsForAdmin(string prefix, int bidderId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetBidderDetailsForAdmin(prefix, bidderId);
            }
        }

        List<MaxBidOutput> IBiddingData.GetBidderMaxBidForAdmin(string prefix, int bidderId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetBidderMaxBidForAdmin(prefix, bidderId);
            }
        }

        List<BidHistoryOutput> IBiddingData.GetBidderBidHistoryForAdmin(string prefix, int bidderId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetBidderBidHistoryForAdmin(prefix, bidderId);
            }
        }

        MaxBidOutput IBiddingData.GetPackageMaxBidForAdmin(string prefix, int packageId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetPackageMaxBidForAdmin(prefix, packageId);
            }
        }

        PackageSearchOutput IBiddingData.GetPackageDetailsForAdmin(string prefix, int packageId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetPackageDetailsForAdmin(prefix, packageId);
            }
        }

        List<BidHistoryOutput> IBiddingData.GetPackageBidHistoryForAdmin(string prefix, int packageId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetPackageBidHistoryForAdmin(prefix, packageId);
            }
        }

        ResultMessage IBiddingData.ClearMaxBidForAdmin(string prefix, int packageId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.ClearMaxBidForAdmin(prefix, packageId);
            }
        }        
        ResultMessage IBiddingData.RemoveBidForAdmin(string prefix, int bidId, int saleId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.RemoveBidForAdmin(prefix, bidId, saleId);
            }
        }

        ResultMessage IBiddingData.SaveEmailTemplateForAdmin(string prefix, EmailMessageFieldValues emailMessage)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.SaveEmailTemplateForAdmin(prefix, emailMessage);
            }
        }

        List<EmailTemplateOutput> IBiddingData.GetEmailTemplatesForAdmin(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetEmailTemplatesForAdmin(prefix);
            }
        }

        ResultMessage IBiddingData.DeleteEmailTemplateForAdmin(int projectId, int emailTemplateId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.DeleteEmailTemplateForAdmin(projectId, emailTemplateId);
            }
        }

        List<SMSTemplateOutput> IBiddingData.GetSMSTemplatesForAdmin(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.GetSMSTemplatesForAdmin(prefix);
            }
        }

        ResultMessage IBiddingData.SaveSMSTemplateForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.SaveSMSTemplateForAdmin(prefix, textMessageFieldValues);
            }
        }

        ResultMessage IBiddingData.DeleteSMSTemplateForAdmin(int projectId, int smsTemplateId)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.DeleteSMSTemplateForAdmin(projectId, smsTemplateId);
            }
        }

        Tuple<ResultMessage, List<Package>> IBiddingData.RemoveAllBidsForAdmin(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.RemoveAllBidsForAdmin(prefix);
            }
        }

        List<ExportBidHistoryOutput> IBiddingData.ExportAllBiddingHistoryForAdmin(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.ExportAllBiddingHistoryForAdmin(prefix);
            }
        }

        EmbedReportOutput IBiddingData.EmbedReportLastUpdatedDateTimeByProject(string prefix)
        {
            using (var obj = BiddingFactory.GetBiddingAdmin())
            {
                return obj.EmbedReportLastUpdatedDateTimeByProject(prefix);
            }
        }

        #endregion Admin
    }
}
