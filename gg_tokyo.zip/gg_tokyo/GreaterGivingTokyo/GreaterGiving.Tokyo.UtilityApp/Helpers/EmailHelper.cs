﻿using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.UtilityApp.Common;
using GreaterGiving.Tokyo.UtilityApp.Configuration;
using System;
using System.Web.Mail;

namespace GreaterGiving.Tokyo.UtilityApp.Helpers
{
    public static class EmailHelper
    {
        /// <summary>
        /// Sends out an e-mail with the specified details
        /// </summary>        
        public static bool SendEmail(string toAddress, string emailSubject, string emailBody)
        {
            try
            {
                MailMessage Msg = new MailMessage();
                Msg.From = ConfigManager.SenderEmailAddress;
                Msg.To = toAddress;
                Msg.Subject = emailSubject;
                Msg.Body = emailBody;
                SmtpMail.SmtpServer = ConfigManager.SMPTServerIP;
                SmtpMail.Send(Msg);
                Msg = null;

                return true;
            }
            catch (Exception ex)
            {
                Logger.WriteErrorLog(Constants.EXCEPTION_MESSAGE_PREFIX + ex.Message + Environment.NewLine +
                                     Constants.EXCEPTION_INNEREXCEPTION_PREFIX + ex.InnerException + Environment.NewLine +
                                     Constants.EXCEPTION_STACKTRACE_PREFIX + ex.StackTrace);

                return false;
            }
        }
    }
}
