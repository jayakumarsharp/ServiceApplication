﻿using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.UtilityApp.Common;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace GreaterGiving.Tokyo.UtilityApp.Helpers
{
    public static class SqlHelper
    {
        #region Methods

        /// <summary>
        /// </summary>
        public static string ExecuteScalar(string connectionString, string script)
        {
            string sReturn = string.Empty;

            var sqlConnection = new SqlConnection
            {
                ConnectionString = connectionString
            };

            try
            {
                sqlConnection.Open();
                var sqlCommand = new SqlCommand(script, sqlConnection);

                var result = sqlCommand.ExecuteScalar();
                sReturn = result != null ? result.ToString() : string.Empty;
            }
            catch (Exception ex)
            {
                Logger.WriteErrorLog(Constants.EXCEPTION_MESSAGE_PREFIX + ex.Message + Environment.NewLine +
                                     Constants.EXCEPTION_INNEREXCEPTION_PREFIX + ex.InnerException + Environment.NewLine +
                                     Constants.EXCEPTION_STACKTRACE_PREFIX + ex.StackTrace);
            }
            finally
            {
                sqlConnection.Close();
            }
            return sReturn;
        }

        /// <summary>
        /// </summary>
        public static bool ExecuteNonQuery(string connectionString, IEnumerable<string> scripts,
            bool isExecuteWithInTransaction = false)
        {
            return isExecuteWithInTransaction
                ? ExecuteNonQueryWithInTransaction(connectionString, scripts)
                : ExecuteNonQueryWithOutTransaction(connectionString, scripts);
        }

        #endregion Methods

        #region Helper Methods

        /// <summary>
        /// </summary>
        private static bool ExecuteNonQueryWithOutTransaction(string connectionString, IEnumerable<string> scripts)
        {
            var sqlConnection = new SqlConnection
            {
                ConnectionString = connectionString
            };

            try
            {
                sqlConnection.Open();
                foreach (var sqlCommand in scripts.Select(script => new SqlCommand(script, sqlConnection)))
                {
                    sqlCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteErrorLog(Constants.EXCEPTION_MESSAGE_PREFIX + ex.Message + Environment.NewLine +
                                     Constants.EXCEPTION_INNEREXCEPTION_PREFIX + ex.InnerException + Environment.NewLine +
                                     Constants.EXCEPTION_STACKTRACE_PREFIX + ex.StackTrace);
                return false;
            }
            finally
            {
                sqlConnection.Close();
            }
            return true;
        }

        /// <summary>
        /// </summary>
        private static bool ExecuteNonQueryWithInTransaction(string connectionString, IEnumerable<string> scripts)
        {
            var sqlConnection = new SqlConnection
            {
                ConnectionString = connectionString
            };

            try
            {
                sqlConnection.Open();
                var sqlTransaction = sqlConnection.BeginTransaction("transaction");

                try
                {
                    foreach (var script in scripts)
                    {
                        //split the script on "GO" commands 
                        string[] splitter = { Constants.SQL_GO_SPLITTER };
                        var commandTexts = script.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        foreach (var commandText in commandTexts)
                        {
                            var sqlCommand = new SqlCommand(commandText, sqlConnection, sqlTransaction);
                            sqlCommand.ExecuteNonQuery();
                        }
                    }
                    sqlTransaction.Commit();
                }
                catch (Exception ex)
                {
                    sqlTransaction.Rollback();
                    Logger.WriteErrorLog(Constants.EXCEPTION_MESSAGE_PREFIX + ex.Message + Environment.NewLine +
                                     Constants.EXCEPTION_INNEREXCEPTION_PREFIX + ex.InnerException + Environment.NewLine +
                                     Constants.EXCEPTION_STACKTRACE_PREFIX + ex.StackTrace);
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sqlConnection.Close();
            }
            return true;
        }

        #endregion Helper Methods
    }
}
