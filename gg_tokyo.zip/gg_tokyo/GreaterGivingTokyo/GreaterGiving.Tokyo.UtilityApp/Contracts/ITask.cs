﻿namespace GreaterGiving.Tokyo.UtilityApp.Contracts
{
    public interface ITask
    {
        #region Properties

        /// <summary>
        /// </summary>
        string TaskName { get; set; }

        #endregion Properties

        #region Methods

        /// <summary>
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        bool Execute(params string[] parameters);

        #endregion Methods
    }
}