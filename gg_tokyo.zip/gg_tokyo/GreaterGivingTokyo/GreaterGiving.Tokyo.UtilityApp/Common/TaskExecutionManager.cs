﻿namespace GreaterGiving.Tokyo.UtilityApp.Common
{
    public static class TaskExecutionManager
    {
        #region Methods

        /// <summary>
        /// Executes the task as specified in the args
        /// </summary>
        public static bool Execute(string[] args)
        {
            //args = new string[] { "ENCRYPTTEXT" };
            if (args.Length > 0)
            {               
                var task = TaskFactory.GetTask(args[0]);                

                if (task != null)
                {
                    task.Execute(args);
                }

            }

            return true;
        }

        #endregion Methods
    }
}
