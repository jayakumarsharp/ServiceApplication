﻿namespace GreaterGiving.Tokyo.UtilityApp.Common
{
    public static class Constants
    {
        public const string EXCEPTION_MESSAGE_PREFIX = "Message : ";
        public const string EXCEPTION_INNEREXCEPTION_PREFIX = "InnerException : ";
        public const string EXCEPTION_STACKTRACE_PREFIX = "StackTrace : ";
        public const string DEFAULT_TASK_NAME = "ProvisionTenant";

        public const string EMAIL_SUBJECT_SUCCESS = "Successfully provisioned Tenant database.";
        public const string EMAIL_SUBJECT_FAILURE = "Failed to provision Tenant database.";
        public const string EMAIL_SUBJECT_DATABASEEXISTS = "The database for the tenant to be provisioned already exists.";
        public const string SQL_GO_SPLITTER = "\r\nGO\r\n";
    }
}