﻿using GreaterGiving.Tokyo.UtilityApp.Contracts;
using GreaterGiving.Tokyo.UtilityApp.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace GreaterGiving.Tokyo.UtilityApp.Common
{
    public static class TaskFactory
    {
        #region Private Fields & Constants

        private static readonly IList<ITask> _taskManagerList;

        #endregion Private Fields & Constants

        #region Constructors

        /// <summary>
        /// </summary>
        static TaskFactory()
        {
            _taskManagerList = new List<ITask>
            {
                new EncryptTextTask(),
                new DecryptTextTask()
            };
        }

        #endregion Constructors

        #region Method

        /// <summary>
        /// </summary>
        public static ITask GetTask(string taskName)
        {
            return
                _taskManagerList.FirstOrDefault(item => item.TaskName.ToLower().Trim().Equals(taskName.ToLower().Trim()));
        }

        #endregion Method
    }
}
