﻿using GreaterGiving.Tokyo.UtilityApp.Contracts;

namespace GreaterGiving.Tokyo.UtilityApp.Tasks
{
    internal class ExecuteDatabaseScriptsTask : ITask
    {
        #region Constructor

        public ExecuteDatabaseScriptsTask()
        {
            (this as ITask).TaskName = "EXECUTEDATABASESCRIPTS";
        }

        #endregion Constructor

        #region ITask Implementation Fields

        string ITask.TaskName { get; set; }

        #endregion ITask Implementation Fields

        #region ITask Implementation Methods

        /// <summary>
        /// 
        /// </summary>        
        bool ITask.Execute(params string[] parameters)
        {
            return true;
        }

        #endregion ITask Implementation Methods
    }
}
