﻿using GreaterGiving.Tokyo.CrossCutting.Crypto;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.UtilityApp.Contracts;
using System.Windows.Forms;

namespace GreaterGiving.Tokyo.UtilityApp.Tasks
{
    internal class DecryptTextTask : ITask
    {
        #region Constructor

        public DecryptTextTask()
        {
            (this as ITask).TaskName = "DECRYPTTEXT";
        }

        #endregion Constructor

        #region ITask Implementation Fields

        string ITask.TaskName { get; set; }

        #endregion ITask Implementation Fields

        #region ITask Implementation Methods

        /// <summary>
        /// 
        /// </summary>        
        bool ITask.Execute(params string[] parameters)
        {
            if (parameters.Length < 4)
            {
                Logger.WriteErrorLog("Incorrect parameters passed" + (parameters.Length > 1 ? " to '" + parameters[0] + "' task" : string.Empty) + ".");
                return false;
            }

            var decryptedPassword = CryptoHelper.Decrypt(parameters[1], parameters[2], parameters[3]);
            Clipboard.SetData(DataFormats.StringFormat, decryptedPassword);

            return true;
        }

        #endregion ITask Implementation Methods
    }
}
