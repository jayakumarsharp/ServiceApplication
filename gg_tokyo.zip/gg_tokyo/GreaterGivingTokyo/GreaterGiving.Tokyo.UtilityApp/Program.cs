﻿using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.UtilityApp.Common;
using System;

namespace GreaterGiving.Tokyo.UtilityApp
{
    internal class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            try
            {
                TaskExecutionManager.Execute(args);
            }
            catch (Exception ex)
            {
                Logger.WriteErrorLog(Constants.EXCEPTION_MESSAGE_PREFIX + ex.Message + Environment.NewLine +
                                     Constants.EXCEPTION_INNEREXCEPTION_PREFIX + ex.InnerException + Environment.NewLine +
                                     Constants.EXCEPTION_STACKTRACE_PREFIX + ex.StackTrace);
            }
        }
    }
}
