﻿using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Crypto;
using System.Linq;

namespace GreaterGiving.Tokyo.UtilityApp.Configuration
{
    public static class ConfigManager
    {
        #region Constructors

        static ConfigManager()
        {
            var encryption_decryption_key = ConfigHelper.GetConfigValue(ENCRYPTION_DECRYPTION_STRING_KEY);

            _newDatabaseFolder = ConfigHelper.GetConfigValue(NEW_DATABASE_FOLDER_KEY);
            _dmlFolderPath = ConfigHelper.GetConfigValue(DML_FOLDER_PATH_KEY);
            _ddlFolderPath = ConfigHelper.GetConfigValue(DDL_FOLDER_PATH_KEY);
            _failureEmailTemplate = ConfigHelper.GetConfigValue(FAILURE_EMAIl_TEMPLATE_KEY);
            _successEmailTemplate = ConfigHelper.GetConfigValue(SUCCESS_EMAIL_TEMPLATE_KEY);
            _databaseAlreadyExistEmailTemplate = ConfigHelper.GetConfigValue(DATABASE_EXITS_EMAIL_TEMPLATE_KEY);

            _senderEmailAddress = ConfigHelper.GetConfigValue(SENDER_EMAIL_ADDRESS_KEY);
            _smptServerIP = ConfigHelper.GetConfigValue(SMTP_SERVER_IP_KEY);
            _smptServerPort = ConfigHelper.GetConfigValue(SMTP_SERVER_PORT_KEY);

            _masterDatabaseConnectionString = CryptoHelper.Decrypt(ConfigHelper.GetConnectionString(MASTER_DB_CONNECTION_STRING_KEY), encryption_decryption_key, string.Join(string.Empty, encryption_decryption_key.Reverse()));
            _sharedDatabaseConnectionString = CryptoHelper.Decrypt(ConfigHelper.GetConnectionString(SHARED_DB_CONNECTION_STRING_KEY), encryption_decryption_key, string.Join(string.Empty, encryption_decryption_key.Reverse()));
            _tenantDatabaseConnectionString = CryptoHelper.Decrypt(ConfigHelper.GetConnectionString(TENANT_DB_CONNECTION_STRING_KEY), encryption_decryption_key, string.Join(string.Empty, encryption_decryption_key.Reverse()));
            _tenantEntitiesDatabaseConnectionString = CryptoHelper.Decrypt(ConfigHelper.GetConnectionString(TENANT_ENTITIES_CONNECTION_STRING_KEY), encryption_decryption_key, string.Join(string.Empty, encryption_decryption_key.Reverse()));
        }

        #endregion Constructors

        #region Private Fields & Constants

        private const string NEW_DATABASE_FOLDER_KEY = "NewDatabaseFolder";
        private const string DML_FOLDER_PATH_KEY = "DMLFolderPath";
        private const string DDL_FOLDER_PATH_KEY = "DDLFolderPath";
        private const string FAILURE_EMAIl_TEMPLATE_KEY = "FailureEmailTemplate";
        private const string SUCCESS_EMAIL_TEMPLATE_KEY = "SuccessEmailTemplate";
        private const string DATABASE_EXITS_EMAIL_TEMPLATE_KEY = "DatabaseAlreadyExistEmailTemplate";
        private const string ENCRYPTION_DECRYPTION_STRING_KEY = "EDK"; 

        private const string SENDER_EMAIL_ADDRESS_KEY = "SenderEmailAddress";
        private const string SMTP_SERVER_IP_KEY = "SMTPServerIP";
        private const string SMTP_SERVER_PORT_KEY = "SMTPServerPort";

        private const string MASTER_DB_CONNECTION_STRING_KEY = "MasterDBConnectionString";
        private const string SHARED_DB_CONNECTION_STRING_KEY = "SharedDBConnectionString";
        private const string TENANT_DB_CONNECTION_STRING_KEY = "TenantConnectionStringTemplate";
        private const string TENANT_ENTITIES_CONNECTION_STRING_KEY = "TenantEntitiesConnectionStringTemplate";
        

        private static readonly string _newDatabaseFolder;
        private static readonly string _dmlFolderPath;
        private static readonly string _ddlFolderPath;
        private static readonly string _successEmailTemplate;
        private static readonly string _failureEmailTemplate;
        private static readonly string _databaseAlreadyExistEmailTemplate;

        private static readonly string _senderEmailAddress;
        private static readonly string _smptServerIP;
        private static readonly string _smptServerPort;

        private static readonly string _masterDatabaseConnectionString;
        private static readonly string _sharedDatabaseConnectionString;
        private static readonly string _tenantDatabaseConnectionString;
        private static readonly string _tenantEntitiesDatabaseConnectionString;      
        
        #endregion Private Fields & Constants

        #region Properties

        public static string NewDatabaseFolder
        {
            get { return _newDatabaseFolder; }
        }

        public static string DMLFolderPath
        {
            get { return _dmlFolderPath; }
        }

        public static string DDLFolderPath
        {
            get { return _ddlFolderPath; }
        }

        public static string SuccessEmailTemplate
        {
            get { return _successEmailTemplate; }
        }

        public static string FailureEmailTemplate
        {
            get { return _failureEmailTemplate; }
        }

        public static string DatabaseAlreadyExistEmailTemplate
        {
            get { return _databaseAlreadyExistEmailTemplate; }
        }        

        public static string SenderEmailAddress
        {
            get { return _senderEmailAddress; }
        }

        public static string SMPTServerIP
        {
            get { return _smptServerIP; }
        }

        public static string SMPTServerPort
        {
            get { return _smptServerPort; }
        }

        public static string MasterDatabaseConnectionString
        {
            get { return _masterDatabaseConnectionString; }
        }

        public static string SharedDatabaseConnectionString
        {
            get { return _sharedDatabaseConnectionString; }
        }

        public static string TenantDatabaseConnectionString
        {
            get { return _tenantDatabaseConnectionString; }
        }

        public static string TenantEntitiesDatabaseConnectionString
        {
            get { return _tenantEntitiesDatabaseConnectionString; }
        }        

        #endregion Properties
    }
}