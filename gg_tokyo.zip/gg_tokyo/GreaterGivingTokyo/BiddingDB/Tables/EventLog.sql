﻿CREATE TABLE [dbo].[EventLog]
(
	EventLogId INT NOT NULL IDENTITY(1,1) PRIMARY KEY
	,ProjectXid INT NULL
	,PackageXid INT NULL
	,BidderXid INT NULL
	,SponsorXid INT NULL
	,EventType INT NULL
	,EventDate DATETIME NULL
)
