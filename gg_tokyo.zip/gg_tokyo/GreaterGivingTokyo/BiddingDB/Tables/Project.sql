﻿CREATE TABLE [dbo].[Project]
(
 [ProjectXid] INT NOT NULL
,Prefix NVARCHAR(50) NOT NULL
,ProjectDisplayName NVARCHAR(40) NOT NULL
,ClientName NVARCHAR(127)
,TimeZoneId CHAR(30) NOT NULL
,[Password] NVARCHAR(100) NULL
,[ProjectImage] VARBINARY(MAX)
,ProjectImagePath VARCHAR(2000) NULL
,DisplayBiddersOnAppealBoard BIT
,SendSmsOutbidNotices BIT
,SendEmailOutbidNotices BIT
,ShowFmv BIT
,AppealOnlyEvent BIT
,WinningBidderDetail TINYINT
,ShowHistoryOnRegularPackages BIT
,ShowHistoryOnMultisalePackages BIT
,ShowDonors BIT
,BrowsePageSortOrder TINYINT
,AppealGoal MONEY
,LegalTerms NVARCHAR(MAX)
,LeaderboardNumberOfPackages INT
,[DonationPackageXid] INT
,DonationLabel NVARCHAR(128)
,[AppealImage] VARBINARY(MAX)
,AppealImagePath VARCHAR(2000) NULL
,LeaderboardTheme TINYINT
,LeaderboardScreenDisplaySeconds INT
,[RevenueGoal] MONEY NULL
,AllowMaxBidding BIT
,LeaderboardStyle TINYINT
,SuggestedDonationAmounts NVARCHAR(MAX)
,ProjectKey CHAR(16)
,[AppealTotalRaised] MONEY NULL
,[CreatedDate] DATETIME NULL
,[UpdatedDate] DATETIME NULL
,[IsDeleted] BIT NULL DEFAULT 0, 
    
    CONSTRAINT [PK_Project] PRIMARY KEY ([ProjectXid])
)