﻿CREATE TABLE [dbo].[DisplayLookup]
(
	[DisplayValue] INT NOT NULL,
	[DisplayType] NVARCHAR(45) NOT NULL,
	[DisplayCode] NVARCHAR(45),
	[DisplayText] NVARCHAR(45),
	[CreatedDate] DATETIME NULL,
	CONSTRAINT [PK_DisplayLookup_DisplayValueAndDisplayType] PRIMARY KEY ([DisplayValue],[DisplayType])
)
