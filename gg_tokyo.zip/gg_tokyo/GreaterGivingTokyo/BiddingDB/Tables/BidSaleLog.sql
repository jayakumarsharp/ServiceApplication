﻿CREATE TABLE [dbo].[BidSaleLog]
(
	[BidSaleLogId] INT NOT NULL IDENTITY(1,1), 
    [ProjectXid] INT NOT NULL, 
    [BidderXid] INT NOT NULL, 
    [PackageXid] INT NOT NULL,
	[BidXid] INT NULL, 
	[SaleID] INT NULL, 
    [BidderActionType] INT NULL, 
    [BidAmount] MONEY NULL, 
    [QtyPurchased] INT NULL, 
    [BidActionDate] DATETIME NULL, 
    [BrowserName] NVARCHAR(200) NULL, 
    [Version] NVARCHAR(50) NULL, 
    [DeviceType] NVARCHAR(50) NULL,
	[EventType] INT NULL,
	CONSTRAINT [PK_BidSaleLog_BidSaleLogId] PRIMARY KEY ([BidSaleLogId])
)
