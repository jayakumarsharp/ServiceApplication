﻿CREATE TABLE [dbo].[EmailDeliveryStatus]
(
	[EmailDeliveryID] INT NOT NULL IDENTITY(1,1), 
    [EmailRequestID] INT NOT NULL, 
    [EmailAddress] NVARCHAR(45) NOT NULL, 
    [BidderXid] INT NULL, 
    [DeliveryStatus] NVARCHAR(45) NOT NULL, 
    [SendTime] DATETIME NULL, 
    [DeliveryTime] DATETIME NULL, 
    [StatusIndicator] INT NULL,
	[MessageID] NVARCHAR(100) NULL,
	CONSTRAINT [PK_] PRIMARY KEY ([EmailDeliveryID]),
	CONSTRAINT [FK_EmailDeliveryStatus_EmailRequest] FOREIGN KEY ([EmailRequestID]) REFERENCES [EmailRequest]([EmailRequestID]),
	CONSTRAINT [FK_EmailRequest_Bidder] FOREIGN KEY ([BidderXid]) REFERENCES [Bidder]([BidderXid])
)
