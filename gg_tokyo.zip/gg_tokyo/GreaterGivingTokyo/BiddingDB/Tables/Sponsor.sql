﻿CREATE TABLE [dbo].[Sponsor]
(
	[SponsorXid] INT NOT NULL,
	[ProjectXid] INT NOT NULL,
	[Images] VARBINARY(MAX) NULL,
	[ImagePath] VARCHAR(2000) NULL,
	[CreatedDate] DATETIME NULL,
	[UpdatedDate] DATETIME NULL,
	[IsDeleted] BIT NULL DEFAULT 0, 
    CONSTRAINT [PK_Sponsor] PRIMARY KEY ([SponsorXid]),
	CONSTRAINT [FK_Sponsor_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid]),
)
