﻿CREATE TABLE [dbo].[Sale]
(
	[SaleID] INT NOT NULL IDENTITY(1,1), 
    [BidderXid] INT NOT NULL, 
    [ProjectXid] INT NOT NULL, 
    [PackageXid] INT NOT NULL, 
    [GGOUpdateStatus] INT DEFAULT 0, 
    [Amount] MONEY NOT NULL,
	[QtyPurchased] INT NULL,
	[SaleDate] DATETIME NULL,
	[LastAttempted] DATETIME NULL,
	[NoOfTries] INT NULL, 
	[IsDeleted] BIT NULL DEFAULT 0,
    CONSTRAINT [PK_Sale_SaleID] PRIMARY KEY ([SaleID]),
	CONSTRAINT [FK_Sale_Bidder] FOREIGN KEY ([BidderXid]) REFERENCES [Bidder]([BidderXid]),
	CONSTRAINT [FK_Sale_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid]), 
	CONSTRAINT [FK_Sale_Package] FOREIGN KEY ([PackageXid]) REFERENCES [Package]([PackageXid])
)
