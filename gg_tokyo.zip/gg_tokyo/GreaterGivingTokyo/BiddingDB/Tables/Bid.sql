﻿CREATE TABLE [dbo].[Bid]
(
	[BidXid] INT NOT NULL IDENTITY(1,1),
	[BidderXid] INT NOT NULL,
	[ProjectXid] INT NOT NULL,
	[PackageXid] INT NOT NULL,
	[Amount] MONEY NOT NULL,
	[BidType] INT NULL,
	[Canceled] BIT NULL DEFAULT 0,
	[IsDeleted] BIT NOT NULL DEFAULT 0,
	[CreatedDate] DATETIME NULL,
	[UpdatedDate] DATETIME NULL,
	CONSTRAINT [PK_Bid_ProjectXId_PackageXid_Amount_IsDeleted] PRIMARY KEY ([ProjectXid],[PackageXid],[Amount],[IsDeleted]),	
	CONSTRAINT [FK_Bid_Bidder] FOREIGN KEY ([BidderXid]) REFERENCES [Bidder]([BidderXid]),
    CONSTRAINT [FK_Bid_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid]),
	CONSTRAINT [FK_Bid_Package] FOREIGN KEY ([PackageXid]) REFERENCES [Package]([PackageXid])
)
