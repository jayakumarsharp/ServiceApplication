﻿CREATE TABLE [dbo].[SMSDeliveryStatus]
(
	[SMSDeliveryID] INT NOT NULL IDENTITY(1,1),
	[SMSRequestID] INT NOT NULL,
	[BidderXid] INT NULL,
	[PhoneNumber] NVARCHAR(15) NOT NULL,
	[SendTime] DATETIME NULL,
	[DeliveryTime] DATETIME NULL,
	[StatusIndicator] INT NULL,
	[Sid] NVARCHAR(100) NULL,
	CONSTRAINT [PK_SMSDeliveryStatus_SMSDeliveryID] PRIMARY KEY ([SMSDeliveryID]),
	CONSTRAINT [FK_SMSDeliveryStatus_Bidder] FOREIGN KEY ([BidderXid]) REFERENCES [Bidder]([BidderXid]) ,
	CONSTRAINT [FK_SMSDeliveryStatus_SMSRequest] FOREIGN KEY ([SMSRequestID]) REFERENCES [SMSRequest]([SMSRequestID]) 
)
