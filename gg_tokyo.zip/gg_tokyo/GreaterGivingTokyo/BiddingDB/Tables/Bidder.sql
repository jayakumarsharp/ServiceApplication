﻿CREATE TABLE [dbo].[Bidder]
(
	[BidderXid] INT NOT NULL, 
    [ProjectXid] INT NOT NULL,   
    [OnlineBidderKey] CHAR(10) NOT NULL, 
    [SupporterName] NVARCHAR(127) NOT NULL, 
    [MobilePhones] NVARCHAR(250) NULL, 
    [Emails] NVARCHAR(250) NULL, 
    [Number] INT NULL, 
    [TableNumber] INT NULL,
	[CreatedDate] DATETIME NULL, 
    [UpdatedDate] DATETIME NULL,
	[IsDeleted] BIT NULL DEFAULT 0, 
	CONSTRAINT [PK_Bidder_BidderXid] PRIMARY KEY ([BidderXid]),
    CONSTRAINT [FK_Bidder_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid])    
	)
