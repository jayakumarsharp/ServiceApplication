﻿CREATE TABLE [dbo].[BidDeletedHistory]
(
	[BidDeletedHistoryXid] INT NOT NULL IDENTITY(1,1),
	[BidXid] INT NULL,
	[BidderXid] INT NULL,
	[ProjectXid] INT NULL,
	[PackageXid] INT NULL,
	[Amount] MONEY NULL,
	[BidType] INT NULL,
	[Canceled] BIT NULL DEFAULT 0,
	[IsDeleted] BIT NULL DEFAULT 0,
	[CreatedDate] DATETIME NULL,
	[UpdatedDate] DATETIME NULL,
)
