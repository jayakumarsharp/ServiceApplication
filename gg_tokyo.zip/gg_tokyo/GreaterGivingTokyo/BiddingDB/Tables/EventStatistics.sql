﻿CREATE TABLE EventStatistics
(
EventStatisticsId INT IDENTITY(1,1) PRIMARY KEY
,ProjectXid INT NULL
,TotalRaised MONEY
,TotalPackageSale MONEY
,TotalBuyNowSale MONEY
,TotalFromMultisale MONEY
,TotalFromDonations MONEY
,ActiveBidders INT
,NonBidders INT
,PackagesBid INT
,PackagesUnBid INT
,AppealGoal MONEY
,AppealRaised MONEY
,BiddingValue MONEY
,BiddingRaised MONEY, 
[UpdatedDate] DATETIME NULL DEFAULT GETUTCDATE()
)
