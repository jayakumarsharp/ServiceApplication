﻿CREATE TABLE [dbo].[BidderList]
(
	[BidderListXId] INT NOT NULL IDENTITY(1,1),
	[BidderXid] INT NOT NULL, 
    [ProjectXid] INT NOT NULL,
	[PackageXid] INT NOT NULL,
	[ListType] INT ,
	[MaxBidAmount] MONEY NULL,
	[CreatedDate] DATETIME NULL, 
	[UpdatedDate] DATETIME NULL, 
    CONSTRAINT [PK_BidderList_BidderListXId] PRIMARY KEY ([BidderListXId]),
	CONSTRAINT [FK_BidderList_Bidder] FOREIGN KEY ([BidderXid]) REFERENCES [Bidder]([BidderXid]),
    CONSTRAINT [FK_BidderList_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid]),
	CONSTRAINT [FK_BidderList_Package] FOREIGN KEY ([PackageXid]) REFERENCES [Package]([PackageXid])
)
