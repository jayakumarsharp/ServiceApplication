﻿CREATE TABLE [dbo].[Class]
(
 ClassID INT NOT NULL IDENTITY(1,1)
,ClassName NVARCHAR(127) COLLATE Latin1_General_CS_AS NOT NULL
,[ProjectXid] INT NOT NULL
,IsDeleted BIT
,[CreatedDate] DATETIME NULL
,[UpdatedDate] DATETIME NULL
,CONSTRAINT [PK_ClassID] PRIMARY KEY (ClassID)
,CONSTRAINT [FK_Class_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid])
)