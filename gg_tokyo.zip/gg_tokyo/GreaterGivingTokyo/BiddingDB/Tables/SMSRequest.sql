﻿CREATE TABLE [dbo].[SMSRequest]
(
	[SMSRequestID] INT NOT NULL IDENTITY(1,1), 
    [ProjectXid] INT NULL, 
    [Message] NVARCHAR(160) NOT NULL, 
    [Phone] NVARCHAR(250) NOT NULL, 
    [CreatedDate] DATETIME NULL, 
    [UpdatedDate] DATETIME NULL, 
    [StatusIndicator] INT NULL,
	[Purpose] INT NOT NULL, 
    [ProcessStatus] INT NULL DEFAULT(0), 
    [ProcessTime] DATETIME NULL, 
    [NoOfTries] INT NULL, 
    CONSTRAINT [PK_SMSRequest_SMSRequestID] PRIMARY KEY ([SMSRequestID])
)
