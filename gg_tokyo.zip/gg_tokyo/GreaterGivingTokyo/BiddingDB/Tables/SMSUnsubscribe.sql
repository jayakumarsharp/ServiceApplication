﻿CREATE TABLE [dbo].[SMSUnsubscribe]
(
	[SMSUnsubscribeId] INT NOT NULL PRIMARY KEY IDENTITY(1,1)
	,PhoneNo NVARCHAR(25)
	,Unsubscribe BIT DEFAULT(0)
	,CreatedDate DATETIME
)