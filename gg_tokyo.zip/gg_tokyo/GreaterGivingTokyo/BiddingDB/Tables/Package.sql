﻿CREATE TABLE [dbo].[Package]
(
 PackageXid INT NOT NULL
,ProjectXid INT NOT NULL
,Name NVARCHAR(128) NOT NULL
,Number CHAR(20)	NOT NULL
,ClassId INT
,Description NVARCHAR(MAX)
,RestrictionNotes NVARCHAR(MAX)
,Donors NVARCHAR(MAX)
,Value NVARCHAR(127)
,MinimumBid MONEY
,MinimumRaise MONEY
,Price MONEY
,[MaxAvailable] INT NULL
,[QtyRemaining] INT NULL 
,[QtyPurchased] INT NULL
,IsSaleCreated BIT NULL
,EndTimeUTC DATETIME NULL
,StartTimeUTC DATETIME NOT NULL
,[MobileBiddingTypeID] TINYINT
,[CreatedDate] DATETIME NULL
,[UpdatedDate] DATETIME NULL
	CONSTRAINT [PK_Package] PRIMARY KEY ([PackageXid]), 
    [IsDeleted] BIT NULL DEFAULT 0,     
    CONSTRAINT [FK_Package_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid]), 
    CONSTRAINT [FK_Package_Class] FOREIGN KEY ([ClassID]) REFERENCES [Class]([ClassID])
	
)