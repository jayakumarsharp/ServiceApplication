﻿CREATE TABLE [dbo].[SMSRetryErrorList]
(
	[SMSRetryErrorListId] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [SMSErrorCode] VARCHAR(25) NULL, 
    [SMSErrorMessage] VARCHAR(250) NULL,
	[Retry] BIT NULL DEFAULT(0),
    [CreatedDate] DATETIME NULL, 
    [UpdatedDate] DATETIME NULL,
)
