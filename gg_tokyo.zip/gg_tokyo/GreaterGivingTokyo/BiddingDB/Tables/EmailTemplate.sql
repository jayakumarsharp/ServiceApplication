﻿CREATE TABLE [dbo].[EmailTemplate]
(
	[EmailTemplateID] INT NOT NULL IDENTITY(1,1), 
	[ProjectXid] INT NOT NULL, 
    [Subject] NVARCHAR(250) NOT NULL, 
    [Message] NVARCHAR(MAX) NOT NULL, 
    [CreatedDate] DATETIME NULL,
	CONSTRAINT [PK_EmailTemplate] PRIMARY KEY ([EmailTemplateID]),
	CONSTRAINT [FK_EmailTemplate_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid])
)
