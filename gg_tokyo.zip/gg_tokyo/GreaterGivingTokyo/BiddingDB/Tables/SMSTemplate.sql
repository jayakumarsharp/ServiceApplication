﻿CREATE TABLE [dbo].[SMSTemplate]
(
	[SMSTemplateID] INT NOT NULL IDENTITY(1,1), 
    [ProjectXid] INT NOT NULL, 
    [Message] NVARCHAR(160) NOT NULL, 
    [CreatedDate] DATETIME NULL,
	CONSTRAINT [PK_SMSTemplate_SMSTemplateID] PRIMARY KEY ([SMSTemplateID]),
	CONSTRAINT [FK_SMSTemplate_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid])
)
