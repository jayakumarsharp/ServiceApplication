﻿CREATE TABLE [dbo].[EmailRequest]
(
	[EmailRequestID] INT NOT NULL IDENTITY(1,1), 
    [ProjectXid] INT NOT NULL, 
    [Message] NVARCHAR(MAX) NOT NULL, 
    [ToAddress] NVARCHAR(250) NOT NULL, 
    [Subject] NVARCHAR(250) NOT NULL, 
    [From] NVARCHAR(250) NOT NULL, 
    [FromName] NVARCHAR(250) NOT NULL, 
    [CreatedDate] DATETIME NULL, 
    [UpdatedDate] DATETIME NULL,
	[StatusIndicator] INT NULL, 
    [Purpose] INT NOT NULL, 
    CONSTRAINT [PK_EmailRequest] PRIMARY KEY ([EmailRequestID]),
	CONSTRAINT [FK_EmailRequest_Project] FOREIGN KEY ([ProjectXid]) REFERENCES [Project]([ProjectXid])
)
