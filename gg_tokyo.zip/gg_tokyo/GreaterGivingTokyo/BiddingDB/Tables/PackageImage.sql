﻿CREATE TABLE [dbo].[PackageImage]
(
 PackageImageID INT NOT NULL IDENTITY(1,1)
,[PackageXid] INT
,Image VARBINARY(MAX)
,[ImagePath] VARCHAR(2000) NULL
,[Order] INT
,
    [CreatedDate] DATETIME NULL, 
    CONSTRAINT [PK_PackageImageID] PRIMARY KEY (PackageImageID), 
    CONSTRAINT [FK_PackageImage_Package] FOREIGN KEY ([PackageXid]) REFERENCES [Package]([PackageXid])
)