﻿CREATE TABLE [dbo].[CodeLookup]
(
	[CodeValue] INT NOT NULL,
	[CodeType] NVARCHAR(45) NOT NULL,
	[CodeDescription] NVARCHAR(45),
	[CreatedDate] DATETIME NULL,
	CONSTRAINT [PK_CodeLookup_CodeValueAndCodeType] PRIMARY KEY ([CodeValue],[CodeType])
)
