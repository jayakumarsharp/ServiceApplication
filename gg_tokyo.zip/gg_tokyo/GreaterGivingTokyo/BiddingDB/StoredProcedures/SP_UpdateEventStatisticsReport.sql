﻿CREATE PROCEDURE [dbo].[SP_UpdateEventStatisticsReport]
@ProjectXid INT = NULL
AS
BEGIN

	DECLARE @TotalRaised MONEY = 0
	,@TotalPackageSale MONEY = 0
	,@TotalBuyNowSale MONEY = 0
	,@TotalFromMultisale MONEY = 0
	,@TotalFromDonations MONEY = 0
	,@ActiveBidders INT = 0
	,@NonBidders INT = 0
	,@PackagesBid INT = 0
	,@PackagesUnBid INT = 0
	,@AppealGoal MONEY = 0
	,@AppealRaised MONEY = 0
	,@BiddingValue MONEY = 0
	,@BiddingRaised MONEY = 0
	,@Start INT = 0
	,@End INT = 0

	BEGIN TRY

		BEGIN TRANSACTION ES
		
		IF EXISTS (SELECT 1 FROM [dbo].[Project] WHERE [ProjectXid]=@ProjectXid AND [IsDeleted] = 0)
		BEGIN
		        -- Total Raised
				SET @TotalRaised = ISNULL((SELECT ISNULL(SUM(ISNULL(Amount,0)),0) FROM(
				SELECT b.packagexid, MAX(b.Amount)Amount FROM bid(NOLOCK) b
				INNER JOIN package(NOLOCK) p ON p.packagexid = b.packagexid 
				WHERE b.isdeleted = 0 AND p.isdeleted = 0
				AND p.mobilebiddingtypeid = 0
				AND (EndTimeUTC > GETUTCDATE() OR EndTimeUTC is null)
				AND b.projectxid = @ProjectXid
				GROUP BY b.packagexid)a) 
				+
				(SELECT ISNULL(SUM(ISNULL(s.Amount,0)),0) FROM package(NOLOCK) p
				INNER JOIN sale(NOLOCK) s ON s.packagexid = p.packagexid
				WHERE p.mobilebiddingtypeid = 0
				AND p.EndTimeUTC < GETUTCDATE()
				AND p.isdeleted = 0 AND s.isdeleted = 0
				AND p.projectxid = @ProjectXid) 
				+
				(SELECT ISNULL(SUM(ISNULL(p.Price,0)),0) FROM package(NOLOCK) p
				WHERE p.mobilebiddingtypeid = 0
				AND p.EndTimeUTC < GETUTCDATE()
				AND p.isdeleted = 0 
				AND p.projectxid = @ProjectXid
				AND packagexid not in(SELECT packagexid FROM sale(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid)) 
				+
				(SELECT ISNULL(SUM(ISNULL(Amount,0)),0) FROM sale(NOLOCK) s
				INNER JOIN package(NOLOCK) p ON p.packagexid = s.packagexid 
				WHERE p.mobilebiddingtypeid in(2, 3, 4)
				AND s.isdeleted = 0 AND p.isdeleted = 0
				AND p.projectxid = @ProjectXid), 0) 

				-- Total Package Sales

				SET @TotalPackageSale = ISNULL((
				SELECT ISNULL(SUM(ISNULL(s.amount,0)),0) FROM sale s(NOLOCK) 
				INNER JOIN package p on p.packagexid = s.packagexid
				WHERE p.mobilebiddingtypeid = 0
				AND p.EndTimeUTC < GETUTCDATE()
				AND p.isdeleted = 0 AND s.isdeleted = 0
				AND p.projectxid = @ProjectXid
				AND s.packagexid in(select packagexid from bid where projectxid = @ProjectXid and Bidtype = 3)) +
				(SELECT ISNULL(SUM(ISNULL(Amount,0)),0) FROM sale s
				INNER JOIN package(NOLOCK) p ON p.packagexid = s.packagexid 
				WHERE p.mobilebiddingtypeid in(0,3) AND p.isdeleted = 0 AND s.projectxid = @ProjectXid
				AND s.isdeleted = 0
				AND p.packagexid not in(SELECT packagexid FROM package(NOLOCK) WHERE mobilebiddingtypeid = 0 AND projectxid = @ProjectXid
				AND EndTimeUTC < GETUTCDATE()
				AND isdeleted = 0)),0)


				-- Total Buy Now Sales
				SELECT @TotalBuyNowSale = ISNULL(SUM(ISNULL(Amount,0)),0) FROM sale(NOLOCK) s
				INNER JOIN package(NOLOCK) p ON p.packagexid = s.packagexid 
				WHERE p.mobilebiddingtypeid = 0
				AND s.isdeleted = 0 AND p.isdeleted = 0
				AND p.projectxid = @ProjectXid
				AND s.packagexid in(select packagexid from bid where projectxid = @ProjectXid and Bidtype = 3)

				-- Total Multisales
				SELECT @TotalFromMultisale = ISNULL(SUM(ISNULL(Amount,0)),0) FROM sale(NOLOCK) s
				INNER JOIN package(NOLOCK) p ON p.packagexid = s.packagexid 
				WHERE p.mobilebiddingtypeid = 3
				AND s.isdeleted = 0 AND p.isdeleted = 0
				AND p.projectxid = @ProjectXid

				-- Total Donation
				SELECT @TotalFromDonations = ISNULL(SUM(ISNULL(Amount,0)),0) FROM sale(NOLOCK) s
				INNER JOIN package(NOLOCK) p ON p.packagexid = s.packagexid 
				WHERE p.mobilebiddingtypeid in(2, 4)
				AND s.isdeleted = 0 AND p.isdeleted = 0
				AND p.projectxid = @ProjectXid


				-- Bidder Activity
				--Active Bidders
				SELECT @ActiveBidders = COUNT(*) FROM bidder(NOLOCK)
				WHERE bidderxid in(
				SELECT bidderxid FROM sale(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid
				union
				SELECT bidderxid FROM bid(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid)
				AND isdeleted = 0
				AND projectxid = @ProjectXid

				--Non Bidders
				SELECT @NonBidders = COUNT(*) FROM bidder(NOLOCK)
				WHERE bidderxid not in(
				SELECT bidderxid FROM sale(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid
				union
				SELECT bidderxid FROM bid(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid)
				AND isdeleted = 0
				AND projectxid = @ProjectXid


				--	Package Activity
				--Packages Bid
				SELECT @PackagesBid = COUNT(*) FROM package(NOLOCK)
				WHERE packagexid in(
				SELECT packagexid FROM sale(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid
				union
				SELECT packagexid FROM bid(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid)
				AND isdeleted = 0
				AND projectxid = @ProjectXid
				AND mobilebiddingtypeid = 0

				--Package UnBid
				SELECT @PackagesUnBid = COUNT(*) FROM package(NOLOCK)
				WHERE packagexid not in(
				SELECT packagexid FROM sale(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid
				union
				SELECT packagexid FROM bid(NOLOCK) WHERE isdeleted = 0 AND projectxid = @ProjectXid)
				AND isdeleted = 0
				AND projectxid = @ProjectXid
				AND mobilebiddingtypeid = 0


				--Appeal Success
				SELECT @AppealGoal = ISNULL(AppealGoal,0) ,@AppealRaised = ISNULL(AppealTotalRaised,0) FROM project(NOLOCK)
				WHERE projectxid = @ProjectXid
				AND isdeleted = 0

				--Bidding Success
				--Value
				SELECT @BiddingValue = ISNULL(SUM(CAST(ISNULL(Value,0) AS MONEY)),0) FROM package(NOLOCK)
				WHERE projectxid = @ProjectXid
				AND isdeleted = 0
				AND mobilebiddingtypeid = 0

				--Raised
				SET @BiddingRaised = (
				SELECT ISNULL(SUM(ISNULL(s.amount,0)),0) FROM sale s(NOLOCK) 
				INNER JOIN package p on p.packagexid = s.packagexid
				WHERE p.mobilebiddingtypeid = 0
				AND p.EndTimeUTC < GETUTCDATE()
				AND p.isdeleted = 0 AND s.isdeleted = 0
				AND p.projectxid = @ProjectXid
				AND s.packagexid in(select packagexid from bid where projectxid = @ProjectXid and Bidtype = 3))
				+
				(SELECT ISNULL(SUM(ISNULL(Amount,0)),0) from(
				SELECT b.packagexid, MAX(b.Amount)Amount FROM bid(NOLOCK) b
				INNER JOIN package(NOLOCK) p ON p.packagexid = b.packagexid 
				WHERE b.isdeleted = 0 AND p.isdeleted = 0
				AND p.mobilebiddingtypeid = 0
				AND (EndTimeUTC > GETUTCDATE() OR EndTimeUTC is null)
				AND b.projectxid = @ProjectXid
				GROUP BY b.packagexid)a)

				IF NOT EXISTS (SELECT 1 FROM [dbo].[EventStatistics] WHERE [ProjectXid]=@ProjectXid)
				BEGIN 
  
				INSERT INTO EventStatistics
				(
				ProjectXid
				,TotalRaised
				,TotalPackageSale
				,TotalBuyNowSale
				,TotalFromMultisale
				,TotalFromDonations
				,ActiveBidders
				,NonBidders
				,PackagesBid
				,PackagesUnBid
				,AppealGoal
				,AppealRaised
				,BiddingValue
				,BiddingRaised
				,UpdatedDate
				)
				SELECT @ProjectXid
				,@TotalRaised
				,@TotalPackageSale
				,@TotalBuyNowSale
				,@TotalFromMultisale
				,@TotalFromDonations
				,@ActiveBidders
				,@NonBidders
				,@PackagesBid
				,@PackagesUnBid
				,@AppealGoal
				,@AppealRaised
				,@BiddingValue
				,@BiddingRaised
				,GETUTCDATE()
			END
			ELSE 
			BEGIN
				UPDATE [dbo].[EventStatistics] 
				SET TotalRaised = @TotalRaised
				,TotalPackageSale = @TotalPackageSale
				,TotalBuyNowSale = @TotalBuyNowSale
				,TotalFromMultisale = @TotalFromMultisale
				,TotalFromDonations = @TotalFromDonations
				,ActiveBidders = @ActiveBidders
				,NonBidders = @NonBidders
				,PackagesBid = @PackagesBid
				,PackagesUnBid = @PackagesUnBid
				,AppealGoal = @AppealGoal
				,AppealRaised =  @AppealRaised
				,BiddingValue = @BiddingValue
				,BiddingRaised = @BiddingRaised
				,UpdatedDate = GETUTCDATE()
				 WHERE [ProjectXid]=@ProjectXid

			END
				
		 END
		COMMIT TRANSACTION ES

	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION ES
	END CATCH
	
END