﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='WinningBidderDetailType' AND [CodeDescription] = 'Bidder_Number')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (0,'WinningBidderDetailType','Bidder_Number',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='WinningBidderDetailType' AND [CodeDescription] = 'Bidder_Name')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'WinningBidderDetailType','Bidder_Name',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BrowsePageSortOrderType' AND [CodeDescription] = 'Number')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (0,'BrowsePageSortOrderType','Number',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BrowsePageSortOrderType' AND [CodeDescription] = 'Category')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'BrowsePageSortOrderType','Category',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardStyleType' AND [CodeDescription] = 'AllItems_Closing')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (0,'LeaderboardStyleType','AllItems_Closing',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardStyleType' AND [CodeDescription] = 'AllItems_Item')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'LeaderboardStyleType','AllItems_Item',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardStyleType' AND [CodeDescription] = 'OpenItems_Closing')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'LeaderboardStyleType','OpenItems_Closing',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardStyleType' AND [CodeDescription] = 'OpenItems_Item')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'LeaderboardStyleType','OpenItems_Item',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardStyleType' AND [CodeDescription] = 'Unbid_Items')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (4,'LeaderboardStyleType','Unbid_Items',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardStyleType' AND [CodeDescription] = 'Bidder')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (5,'LeaderboardStyleType','Bidder',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardStyleType' AND [CodeDescription] = 'Class')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (255,'LeaderboardStyleType','Class',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardThemeType' AND [CodeDescription] = 'Blue')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (0,'LeaderboardThemeType','Blue',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardThemeType' AND [CodeDescription] = 'Brown')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'LeaderboardThemeType','Brown',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardThemeType' AND [CodeDescription] = 'Green')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'LeaderboardThemeType','Green',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardThemeType' AND [CodeDescription] = 'Gray')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'LeaderboardThemeType','Gray',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardThemeType' AND [CodeDescription] = 'Purple')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (4,'LeaderboardThemeType','Purple',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='LeaderboardThemeType' AND [CodeDescription] = 'Red')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (5,'LeaderboardThemeType','Red',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSDeliveryStatusesType' AND [CodeDescription] = 'Delivered')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (0,'SMSDeliveryStatusesType','Delivered',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSDeliveryStatusesType' AND [CodeDescription] = 'Failed')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'SMSDeliveryStatusesType','Failed',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSDeliveryStatusesType' AND [CodeDescription] = 'Queued')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'SMSDeliveryStatusesType','Queued',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSDeliveryStatusesType' AND [CodeDescription] = 'Received')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'SMSDeliveryStatusesType','Received',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSDeliveryStatusesType' AND [CodeDescription] = 'Receiving')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (4,'SMSDeliveryStatusesType','Receiving',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSDeliveryStatusesType' AND [CodeDescription] = 'Sending')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (5,'SMSDeliveryStatusesType','Sending',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSDeliveryStatusesType' AND [CodeDescription] = 'Sent')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (6,'SMSDeliveryStatusesType','Sent',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSDeliveryStatusesType' AND [CodeDescription] = 'Undelivered')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (7,'SMSDeliveryStatusesType','Undelivered',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='EmailDeliveryStatusesType' AND [CodeDescription] = 'Accepted')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'EmailDeliveryStatusesType','Accepted',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='EmailDeliveryStatusesType' AND [CodeDescription] = 'BadRequest')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'EmailDeliveryStatusesType','BadRequest',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='MobileBiddingType' AND [CodeDescription] = 'Regular')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (0,'MobileBiddingType','Regular',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='MobileBiddingType' AND [CodeDescription] = 'Live')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'MobileBiddingType','Live',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='MobileBiddingType' AND [CodeDescription] = 'Appeal')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'MobileBiddingType','Appeal',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='MobileBiddingType' AND [CodeDescription] = 'Givers')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'MobileBiddingType','Givers',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='MobileBiddingType' AND [CodeDescription] = 'Donation')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (4,'MobileBiddingType','Donation',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderListType' AND [CodeDescription] = 'Favorites')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'BidderListType','Favorites',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderListType' AND [CodeDescription] = 'MaxBid')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'BidderListType','MaxBid',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidType' AND [CodeDescription] = 'Bid')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'BidType','Bid',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidType' AND [CodeDescription] = 'BidMore')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'BidType','BidMore',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidType' AND [CodeDescription] = 'Buy')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'BidType','Buy',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SaleResultType' AND [CodeDescription] = 'Queued')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'SaleResultType','Queued',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SaleResultType' AND [CodeDescription] = 'Posted')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'SaleResultType','Posted',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SaleResultType' AND [CodeDescription] = 'Error')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'SaleResultType','Error',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SalePackageType' AND [CodeDescription] = 'Auction')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'SalePackageType','Auction',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SalePackageType' AND [CodeDescription] = 'Donation')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (4,'SalePackageType','Donation',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderActionType' AND [CodeDescription] = 'Bid')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'BidderActionType','Bid',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderActionType' AND [CodeDescription] = 'BidMore')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'BidderActionType','BidMore',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderActionType' AND [CodeDescription] = 'Buy')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'BidderActionType','Buy',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderActionType' AND [CodeDescription] = 'Donation')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (4,'BidderActionType','Donation',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderActionType' AND [CodeDescription] = 'MaxBid')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (5,'BidderActionType','MaxBid',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderActionType' AND [CodeDescription] = 'Appeal')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (6,'BidderActionType','Appeal',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='BidderActionType' AND [CodeDescription] = 'Favorites')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
  VALUES (7,'BidderActionType','Favorites',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='EventType' AND [CodeDescription] = 'INSERT')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
  VALUES (1,'EventType','INSERT',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='EventType' AND [CodeDescription] = 'DELETE')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
  VALUES (2,'EventType','DELETE',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='EventType' AND [CodeDescription] = 'REENABLE')
BEGIN 
  INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
  VALUES (3,'EventType','REENABLE',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageStatusType' AND [DisplayCode] = 'OutBid')
BEGIN 
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (1,'PackageStatusType','OutBid','Out Bid',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageStatusType' AND [DisplayCode] = 'Winning')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (2,'PackageStatusType','Winning','Winning',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageStatusType' AND [DisplayCode] = 'Won')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (3,'PackageStatusType','Won','Won',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageStatusType' AND [DisplayCode] = 'Sold')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (4,'PackageStatusType','Sold','Sold',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageStatusType' AND [DisplayCode] = 'Closed')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (5,'PackageStatusType','Closed','Closed',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageStatusType' AND [DisplayCode] = 'Opening')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (6,'PackageStatusType','Opening','Opening',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageStatusType' AND [DisplayCode] = 'All')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (7,'PackageStatusType','All','All',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='AdminPackageStatusType' AND [DisplayCode] = 'Sold')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (1,'AdminPackageStatusType','Sold','Sold',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='AdminPackageStatusType' AND [DisplayCode] = 'Closed')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (2,'AdminPackageStatusType','Closed','Closed',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='AdminPackageStatusType' AND [DisplayCode] = 'Preview')
BEGIN 
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (3,'AdminPackageStatusType','Preview','Preview',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='AdminPackageStatusType' AND [DisplayCode] = 'OpeningSoon')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (4,'AdminPackageStatusType','OpeningSoon','Opening Soon',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='AdminPackageStatusType' AND [DisplayCode] = 'Open')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (5,'AdminPackageStatusType','Open','Open',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='AdminPackageStatusType' AND [DisplayCode] = 'Deleted')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (6,'AdminPackageStatusType','Deleted','Deleted',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageFilterType' AND [DisplayCode] = 'All')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (1,'PackageFilterType','All','All',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageFilterType' AND [DisplayCode] = 'NoBids')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (2,'PackageFilterType','NoBids','No Bids',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageFilterType' AND [DisplayCode] = 'CurrentlyOpen')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (3,'PackageFilterType','CurrentlyOpen','Currently Open',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageFilterType' AND [DisplayCode] = 'BuyNow')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (4,'PackageFilterType','BuyNow','Buy Now',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageFilterType' AND [DisplayCode] = 'Multisale')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (5,'PackageFilterType','Multisale','Multisale',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageFilterType' AND [DisplayCode] = 'PreviewOnly')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (6,'PackageFilterType','PreviewOnly','Preview Only',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageFilterType' AND [DisplayCode] = 'OpeningSoon')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (7,'PackageFilterType','OpeningSoon','Opening Soon',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='ResultStatusType' AND [DisplayCode] = 'Success')
BEGIN 
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (1,'ResultStatusType','Success','Success',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='ResultStatusType' AND [DisplayCode] = 'Failure')
BEGIN 
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (2,'ResultStatusType','Failure','Failure',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='ResultStatusType' AND [DisplayCode] = 'OutBided')
BEGIN 
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (3,'ResultStatusType','OutBided','OutBided',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSPurposeType' AND [CodeDescription] = 'Welcome')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'SMSPurposeType','Welcome',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSPurposeType' AND [CodeDescription] = 'Outbid')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'SMSPurposeType','Outbid',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='SMSPurposeType' AND [CodeDescription] = 'RegistrationOpen')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'SMSPurposeType','RegistrationOpen',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='EmailPurposeType' AND [CodeDescription] = 'Welcome')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (1,'EmailPurposeType','Welcome',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='EmailPurposeType' AND [CodeDescription] = 'Outbid')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (2,'EmailPurposeType','Outbid',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CodeLookup] WHERE [CodeType]='EmailPurposeType' AND [CodeDescription] = 'RegistrationOpen')
BEGIN
 INSERT INTO [dbo].[CodeLookup]([CodeValue], [CodeType],[CodeDescription],[CreatedDate])
 VALUES (3,'EmailPurposeType','RegistrationOpen',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageSortType' AND [DisplayCode] = 'PackageNumber')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (1,'PackageSortType','PackageNumber','Package Number',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageSortType' AND [DisplayCode] = 'ClosingTime')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (2,'PackageSortType','ClosingTime','Closing Time',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='PackageSortType' AND [DisplayCode] = 'Bidder')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (3,'PackageSortType','Bidder','Bidder',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='LeaderBoardPackageFilter' AND [DisplayCode] = 'Open')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (1,'LeaderBoardPackageFilter','Open','Open',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='LeaderBoardPackageFilter' AND [DisplayCode] = 'NoBid')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (2,'LeaderBoardPackageFilter','NoBid','Open(No Bid)',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='LeaderBoardPackageFilter' AND [DisplayCode] = 'All')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (3,'LeaderBoardPackageFilter','All','All',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='LeaderBoardPackageFilter' AND [DisplayCode] = 'Buy')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (4,'LeaderBoardPackageFilter','Buy','Buy',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='LeaderBoardPackageFilter' AND [DisplayCode] = 'Multisale')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (5,'LeaderBoardPackageFilter','Multisale','Multisale',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='LeaderBoardPackageFilter' AND [DisplayCode] = 'Preview')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (6,'LeaderBoardPackageFilter','Preview','Preview',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='LeaderBoardPackageFilter' AND [DisplayCode] = 'Category')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (7,'LeaderBoardPackageFilter','Category','Category',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='LeaderBoardPackageFilter' AND [DisplayCode] = 'Sold')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (8,'LeaderBoardPackageFilter','Sold','Sold',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='CategoryFilter' AND [DisplayCode] = 'All')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (7,'CategoryFilter','All','All',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='RecipientType' AND [DisplayCode] = 'All')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (1,'RecipientType','All','All',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='RecipientType' AND [DisplayCode] = 'Winning')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (2,'RecipientType','Winning','Winning',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[DisplayLookup] WHERE [DisplayType]='RecipientType' AND [DisplayCode] = 'NonWinning')
BEGIN
  INSERT INTO [dbo].[DisplayLookup]([DisplayValue], [DisplayType],[DisplayCode],[DisplayText],[CreatedDate])
 VALUES (3,'RecipientType','NonWinning','NonWinning',GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30001')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30001','Queue overflow',1,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30002')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30002','Account suspended',1,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30003')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30003','Unreachable destination handset',1,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30004')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30004','Message blocked',0,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30005')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30005','Unknown destination handset',0,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30006')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30006','Landline or unreachable carrier',0,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30007')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30007','Carrier violation',0,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30008')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30008','Unknown error',1,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30009')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30009','Missing segment',1,GETUTCDATE())
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[SMSRetryErrorList] WHERE [SMSErrorCode]='30010')
BEGIN
  INSERT INTO [dbo].[SMSRetryErrorList]([SMSErrorCode], [SMSErrorMessage],[Retry],[CreatedDate])
 VALUES ('30010','Message price exceeds max price.',0,GETUTCDATE())
END

GO
