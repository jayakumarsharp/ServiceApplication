﻿namespace GreaterGiving.Tokyo.Entities.Constants
{
    public static class CodeLookupConstants
    {
        public const string CodeType_WinningBidderDetailType = "WinningBidderDetailType";
        public const string CodeWBDType_BidderNumber = "Bidder_Number";
        public const string CodeWBDType_BidderName = "Bidder_Name";

        public const string CodeType_BrowsePageSortOrderType = "BrowsePageSortOrderType";
        public const string CodeBPSType_Number = "Number";
        public const string CodeBPSType_Category = "Category";

        public const string CodeType_LeaderboardStyleType = "LeaderboardStyleType";
        public const string CodeLBSType_AllItemsClosing = "AllItems_Closing";
        public const string CodeLBSType_AllItemsItem = "AllItems_Item";
        public const string CodeLBSType_OpenItemsClosing = "OpenItems_Closing";
        public const string CodeLBSType_OpenItemsItem = "OpenItems_Item";
        public const string CodeLBSType_UnbidItems = "Unbid_Items";
        public const string CodeLBSType_Bidder = "Bidder";
        public const string CodeLBSType_Class = "Class";

        public const string CodeType_LeaderboardThemeType = "LeaderboardThemeType";
        public const string CodeLBTType_Blue = "Blue";
        public const string CodeLBTType_Brown = "Brown";
        public const string CodeLBTType_Green = "Green";
        public const string CodeLBTType_Gray = "Gray";
        public const string CodeLBTType_Purple = "Purple";
        public const string CodeLBTType_Red = "Red";

        public const string CodeType_SMSDeliveryStatusesType = "SMSDeliveryStatusesType";
        public const string CodeSMSDeliveryStatusType_Delivered = "Delivered";
        public const string CodeSMSDeliveryStatusType_Failed = "Failed";
        public const string CodeSMSDeliveryStatusType_Queued = "Queued";
        public const string CodeSMSDeliveryStatusType_Received = "Received";
        public const string CodeSMSDeliveryStatusType_Receiving = "Receiving";
        public const string CodeSMSDeliveryStatusType_Sending = "Sending";
        public const string CodeSMSDeliveryStatusType_Sent = "Sent";
        public const string CodeSMSDeliveryStatusType_Undelivered = "Undelivered";

        public const string CodeType_MobileBiddingType = "MobileBiddingType";
        public const string CodeMobileBiddingType_Regular = "Regular";
        public const string CodeMobileBiddingType_Live = "Live";
        public const string CodeMobileBiddingType_Appeal = "Appeal";
        public const string CodeMobileBiddingType_Givers = "Givers";
        public const string CodeMobileBiddingType_Donation = "Donation";

        public const string CodeType_EmailDeliveryStatusesType = "EmailDeliveryStatusesType";
        public const string CodeEDSType_Accepted = "Accepted";
        public const string CodeEDSType_BadRequest = "BadRequest";
        

        public const string CodeType_BidderListType = "BidderListType";
        public const string CodeBidderListType_Favorites = "Favorites";
        public const string CodeBidderListType_MaxBid = "MaxBid";

        public const string CodeType_BidType = "BidType";
        public const string CodeBidType_Bid = "Bid";
        public const string CodeBidType_BidMore = "BidMore";
        public const string CodeBidType_Buy = "Buy";

        public const string CodeType_BidderActionType = "BidderActionType";
        public const string CodeBidderActionType_Bid = "Bid";
        public const string CodeBidderActionType_BidMore = "BidMore";
        public const string CodeBidderActionType_Buy = "Buy";
        public const string CodeBidderActionType_Donation = "Donation";
        public const string CodeBidderActionType_MaxBid = "MaxBid";
        public const string CodeBidderActionType_Appeal = "Appeal";
        public const string CodeBidderActionType_Favorites = "Favorites";

        public const string CodeType_EventType = "EventType";
        public const string CodeEventType_Insert = "INSERT";
        public const string CodeEventType_Delete = "DELETE";
        public const string CodeEventType_Reenable = "REENABLE";

        public const string CodeType_SMSPurposeType = "SMSPurposeType";
        public const string CodeSMSPurposeType_Welcome = "Welcome";
        public const string CodeSMSPurposeType_Outbid = "Outbid";
        public const string CodeSMSPurposeType_RegistrationOpen = "RegistrationOpen";


        public const string CodeType_EmailPurposeType = "EmailPurposeType";
        public const string CodeEmailPurposeType_Welcome = "Welcome";
        public const string CodeEmailPurposeType_Outbid = "Outbid";
        public const string CodeEmailPurposeType_RegistrationOpen = "RegistrationOpen";

        public const string CodeType_SaleResultType = "SaleResultType";
        public const string CodeSaleResultType_Error = "Error";
        public const string CodeSaleResultType_Posted = "Posted";
        public const string CodeSaleResultType_Queued = "Queued";

        public const string CodeType_SalePackageType = "SalePackageType";
        public const string CodeSalePackageType_Auction = "Auction";
        public const string CodeSalePackageType_Donation = "Donation";
    }

    public static class DisplayLookupConstants
    {
        public const string DisplayType_PackageStatusType = "PackageStatusType";
        public const string DisplayPackageStatusType_OutBid = "OutBid";
        public const string DisplayPackageStatusType_Winning = "Winning";
        public const string DisplayPackageStatusType_Won = "Won";
        public const string DisplayPackageStatusType_Sold = "Sold";
        public const string DisplayPackageStatusType_Closed = "Closed";
        public const string DisplayPackageStatusType_Opening = "Opening";
        public const string DisplayPackageStatusType_All = "All";

        public const string DisplayType_AdminPackageStatusType = "AdminPackageStatusType";        
        public const string DisplayAdminPackageStatusType_Sold = "Sold";
        public const string DisplayAdminPackageStatusType_Closed = "Closed";
        public const string DisplayAdminPackageStatusType_Preview = "Preview";
        public const string DisplayAdminPackageStatusType_OpeningSoon = "OpeningSoon";
        public const string DisplayAdminPackageStatusType_Open = "Open";
        public const string DisplayAdminPackageStatusType_Deleted = "Deleted";

        public const string DisplayType_PackageFilterType = "PackageFilterType";
        public const string DisplayPackageFilterType_All = "All";
        public const string DisplayPackageFilterType_NoBids = "NoBids";
        public const string DisplayPackageFilterType_CurrentlyOpen = "CurrentlyOpen";
        public const string DisplayPackageFilterType_BuyNow = "BuyNow";
        public const string DisplayPackageFilterType_Multisale = "Multisale";
        public const string DisplayPackageFilterType_PreviewOnly = "PreviewOnly";
        public const string DisplayPackageFilterType_OpeningSoon = "OpeningSoon";

        public const string DisplayType_ResultStatusType = "ResultStatusType";
        public const string DisplayResultStatusType_Success = "Success";
        public const string DisplayResultStatusType_Failure = "Failure";
        public const string DisplayResultStatusType_OutBided = "OutBided";

        public const string DisplayType_LeaderBoardPackageFilter = "LeaderBoardPackageFilter";
        public const string DisplayLeaderBoardPackageFilter_Open = "Open";
        public const string DisplayLeaderBoardPackageFilter_NoBid = "NoBid";
        public const string DisplayLeaderBoardPackageFilter_All = "All";
        public const string DisplayLeaderBoardPackageFilter_Buy = "Buy";
        public const string DisplayLeaderBoardPackageFilter_Multisale = "Multisale";
        public const string DisplayLeaderBoardPackageFilter_Preview = "Preview";
        public const string DisplayLeaderBoardPackageFilter_Category = "Category";
        public const string DisplayLeaderBoardPackageFilter_Sold = "Sold";

        public const string DisplayType_PackageSortType = "PackageSortType";
        public const string DisplayPackageSortType_PackageNumber = "PackageNumber";
        public const string DisplayPackageSortType_ClosingTime = "ClosingTime";
        public const string DisplayPackageSortType_Bidder = "Bidder";

        public const string DisplayType_CategoryFilter = "CategoryFilter";
        public const string DisplayCategoryFilter_All = "All";

        public const string DisplayType_RecipientType = "RecipientType";
        public const string DisplayRecipientType_All = "All";
        public const string DisplayRecipientType_Winning = "Winning";
        public const string DisplayRecipientType_NonWinning = "NonWinning";

    }
}
