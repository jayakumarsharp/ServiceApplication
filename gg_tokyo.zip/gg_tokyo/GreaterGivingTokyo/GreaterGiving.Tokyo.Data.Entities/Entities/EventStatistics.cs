﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    /// <summary>
    /// EventStatistics
    /// </summary>
    [Table("EventStatistics")]
    public class EventStatistics
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EventStatisticsID { get; set; }             
        
        public int ProjectXid { get; set; }

        public decimal TotalRaised { get; set; }

        public decimal TotalPackageSale { get; set; }
        
        public decimal TotalBuyNowSale { get; set; }

        public decimal TotalFromMultisale { get; set; }

        public decimal TotalFromDonations { get; set; }

        public int ActiveBidders { get; set; }

        public int NonBidders { get; set; }

        public int PackagesBid { get; set; }

        public int PackagesUnBid { get; set; }

        public decimal AppealGoal { get; set; }

        public decimal AppealRaised { get; set; }

        public decimal BiddingValue { get; set; }

        public decimal BiddingRaised { get; set; }

        public DateTime? UpdatedDate { get; set; } 

    }
}
