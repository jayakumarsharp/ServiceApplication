﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("SMSRetryErrorList")]
    public class SMSRetryErrorList
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SMSRetryErrorListId { get; set; }

        public string SMSErrorCode { get; set; }

        public string SMSErrorMessage { get; set; }

        public bool Retry { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
