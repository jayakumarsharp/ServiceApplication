﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("PackageImage")]
    public class PackageImage
    {
        [Key]
        public int PackageImageID { get; set; }

        [ForeignKey("Package")]
        public int PackageXid { get; set; }

        public byte[] Image { get; set; }

        public string ImagePath { get; set; }

        public int Order { get; set; }

        public DateTime? CreatedDate { get; set; }

        public Package Package { get; set; }
    }
}
