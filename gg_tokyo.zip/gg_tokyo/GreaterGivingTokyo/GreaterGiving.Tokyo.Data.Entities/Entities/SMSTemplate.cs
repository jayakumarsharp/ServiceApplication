﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("SMSTemplate")]
    public class SMSTemplate
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SMSTemplateID { get; set; }

        public int ProjectXid { get; set; }

        [Required]
        public string Message { get; set; }

        public DateTime? CreatedDate { get; set; }

        public Project Project { get; set; }
    }
}
