﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace GreaterGiving.Tokyo.Entities.Entities
{
    /// <summary>
    /// Bid Sale Log
    /// </summary>
    [Table("BidSaleLog")]
    public class BidSaleLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int BidSaleLogId { get; set; }
        
        public int ProjectXid { get; set; }
        
        public int BidderXid { get; set; }
        
        public int PackageXid { get; set; }

        public int? BidXid { get; set; }

        public int? SaleID { get; set; }

        public int? BidderActionType { get; set; }

        public decimal? BidAmount { get; set; }
        
        public int? QtyPurchased { get; set; }
        
        public DateTime? BidActionDate { get; set; }

        public string BrowserName { get; set; }

        public string Version { get; set; }

        public string DeviceType { get; set; }

        public int? EventType { get; set; }
    }
}
