﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("EmailRequest")]
    public class EmailRequest
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmailRequestID { get; set; }

        [Required]
        [ForeignKey("Project")]
        public int ProjectXid { get; set; }

        [Required]
        public string Message { get; set; }

        [Required]
        public string ToAddress { get; set; }

        [Required]
        public string Subject { get; set; }

        [Required]
        public string From { get; set; }

        [Required]
        public string FromName { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        //TODO: Need to revisit whether StatusIndicator is required. As of now not used.
        public int? StatusIndicator { get; set; }

        public int Purpose { get; set; }

        public Project Project { get; set; }
    }
}
