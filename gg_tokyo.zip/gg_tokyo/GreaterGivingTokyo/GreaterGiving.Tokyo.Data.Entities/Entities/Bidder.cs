﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    /// <summary>
    /// Bidder
    /// </summary>
    [Table("Bidder")]
    public class Bidder
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int BidderXid { get; set; }

        [Required]
        [ForeignKey("Project")]
        public int ProjectXid { get; set; }

        [Required]
        public string OnlineBidderKey { get; set; } 

        [Required]
        public string SupporterName { get; set; }

        public string MobilePhones { get; set; }

        public string Emails { get; set; }

        public int? Number { get; set; }

        public int? TableNumber { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public bool IsDeleted { get; set; }

        public Project Project { get; set; }
    }
}
