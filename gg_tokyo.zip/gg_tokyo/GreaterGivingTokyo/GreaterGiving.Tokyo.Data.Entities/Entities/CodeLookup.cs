﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    /// <summary>
    /// CodeLookup
    /// </summary>
    [Table("CodeLookup")]
    public class CodeLookup
    {
        [Key]
        [Column (Order = 0)]
        public int CodeValue { get; set; }
        [Key]
        [Column(Order = 1)]
        public string CodeType { get; set; }

        public string CodeDescription { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
