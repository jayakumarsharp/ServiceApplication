﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("SMSDeliveryStatus")]
    public class SMSDeliveryStatus
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SMSDeliveryID { get; set; }

        [Required]
        [ForeignKey("SMSRequest")]
        public int SMSRequestID { get; set; }

        [ForeignKey("Bidder")]
        public int? BidderXid { get; set; }

        [Required]
        public string PhoneNumber { get; set; }

        public DateTime? SendTime { get; set; }

        public DateTime? DeliveryTime { get; set; }

        public int? StatusIndicator { get; set; }

        public string Sid { get; set; }

        public SMSRequest SMSRequest { get; set; }

        public Bidder Bidder { get; set; }

    }
}
