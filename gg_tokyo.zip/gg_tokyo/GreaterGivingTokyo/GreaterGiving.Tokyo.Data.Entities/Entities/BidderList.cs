﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    /// <summary>
    /// BidderList
    /// </summary>
    [Table("BidderList")]
    public class BidderList
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int BidderListXId { get; set; }

        [Required]
        [ForeignKey("Bidder")]
        public int BidderXid { get; set; }

        [Required]
        [ForeignKey("Project")]
        public int ProjectXid { get; set; }

        [Required]
        [ForeignKey("Package")]
        public int PackageXid { get; set; }

        public int? ListType { get; set; }

        public decimal? MaxBidAmount { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public Bidder Bidder { get; set; }

        public Project Project { get; set; }

        public Package Package { get; set; }
    }
}
