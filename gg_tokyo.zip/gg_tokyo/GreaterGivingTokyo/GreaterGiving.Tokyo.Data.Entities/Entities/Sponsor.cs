﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("Sponsor")]
    public class Sponsor
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int SponsorXid { get; set; }

        [Required]
        [ForeignKey("Project")]
        public int ProjectXid { get; set; }

        public byte[] Images { get; set; }

        public string ImagePath { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public bool IsDeleted { get; set; }

        public Project Project { get; set; }
    }
}
