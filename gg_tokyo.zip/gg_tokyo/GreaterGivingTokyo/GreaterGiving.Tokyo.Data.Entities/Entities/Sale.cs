﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    /// <summary>
    /// Sale
    /// </summary>
    [Table("Sale")]
    public class Sale
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SaleID { get; set; }

        [Required]
        [ForeignKey("Bidder")]
        public int BidderXid { get; set; }

        [Required]
        [ForeignKey("Project")]
        public int ProjectXid { get; set; }

        [Required]
        [ForeignKey("Package")]
        public int PackageXid { get; set; }

        public int GGOUpdateStatus { get; set; }

        [Required]
        public decimal Amount { get; set; }

        public int? QtyPurchased { get; set; }

        public DateTime? SaleDate { get; set; }

        public DateTime? LastAttempted { get; set; }

        public int? NoOfTries { get; set; }

        public bool IsDeleted { get; set; }

        public Project Project { get; set; }

        public Package Package { get; set; }

        public Bidder Bidder { get; set; }
    }
}
