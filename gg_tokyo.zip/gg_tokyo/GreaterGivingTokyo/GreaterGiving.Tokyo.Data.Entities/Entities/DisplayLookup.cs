﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    /// <summary>
    /// CodeLookup
    /// </summary>
    [Table("DisplayLookup")]
    public class DisplayLookup
    {
        [Key]
        [Column (Order = 0)]
        public int DisplayValue { get; set; }
        [Key]
        [Column(Order = 1)]
        public string DisplayType { get; set; }

        //DisplayCode is for internal purpose
        public string DisplayCode { get; set; }

        //DisplayText is for returning to UI
        public string DisplayText { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
