﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("EventLog")]
    public class EventLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EventLogId { get; set; }
        public int ProjectXid { get; set; }
        public int PackageXid { get; set; }
        public int BidderXid { get; set; }
        public int SponsorXid { get; set; }
        public int EventType { get; set; }
        public DateTime EventDate { get; set; }
    }
}
