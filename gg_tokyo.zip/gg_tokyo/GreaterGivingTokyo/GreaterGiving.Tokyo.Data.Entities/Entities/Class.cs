﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("Class")]
    public class Class
    {
        [Key]
        public int ClassID { get; set; }

        public string ClassName { get; set; }

        [Required]
        [ForeignKey("Project")]
        public int ProjectXid { get; set; }

        public bool IsDeleted { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public Project Project { get; set; }
    }
}
