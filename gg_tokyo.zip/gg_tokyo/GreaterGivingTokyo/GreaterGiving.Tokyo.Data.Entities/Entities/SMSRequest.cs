﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("SMSRequest")]
    public class SMSRequest
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SMSRequestID { get; set; }

        public int? ProjectXid { get; set; }

        [Required]
        public string Message { get; set; }

        [Required]
        public string Phone { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        //TODO: Need to revisit whether StatusIndicator is required. As of now not used.
        public int? StatusIndicator { get; set; }

        public int Purpose { get; set; }

        public int? ProcessStatus { get; set; }

        public DateTime? ProcessTime { get; set; }

        public int? NoOfTries { get; set; }
    }
}
