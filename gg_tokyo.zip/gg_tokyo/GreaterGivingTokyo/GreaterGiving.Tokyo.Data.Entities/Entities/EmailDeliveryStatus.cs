﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("EmailDeliveryStatus")]
    public class EmailDeliveryStatus
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmailDeliveryID { get; set; }

        [Required]
        [ForeignKey("EmailRequest")]
        public int EmailRequestID { get; set; }

        [Required]
        public string EmailAddress { get; set; }

        [ForeignKey("Bidder")]
        public int? BidderXid { get; set; }

        [Required]
        public string DeliveryStatus { get; set; }

        public DateTime? SendTime { get; set; }

        public DateTime? DeliveryTime { get; set; }

        public int? StatusIndicator { get; set; }

        public string MessageID { get; set; }

        public EmailRequest EmailRequest { get; set; }

        public Bidder Bidder { get; set; }
    }
}
