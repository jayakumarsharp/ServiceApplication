﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    /// <summary>
    /// Bid
    /// </summary>
    [Table("BidDeletedHistory")]
    public class BidDeletedHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int BidDeletedHistoryXid { get; set; }

        public int BidXid { get; set; }
        
        public int BidderXid { get; set; }

        public int ProjectXid { get; set; }

        public int PackageXid { get; set; }

        public decimal Amount { get; set; }

        public int? BidType { get; set; }

        public bool Canceled { get; set; }

        public bool IsDeleted { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }        
    }
}
