﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("Package")]
    public class Package
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PackageXid { get; set; }

        [Required]
        [ForeignKey("Project")]
        public int ProjectXid { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Number { get; set; }

        [ForeignKey("Class")]
        public int? ClassId { get; set; }

        public string Description { get; set; }

        public string RestrictionNotes { get; set; }

        public string Donors { get; set; }

        public string Value { get; set; }

        [Required]
        public decimal? MinimumBid { get; set; }

        [Required]
        public decimal? MinimumRaise { get; set; }

        public decimal? Price { get; set; }

        public int? MaxAvailable { get; set; }

        public int? QtyRemaining { get; set; }

        public int? QtyPurchased { get; set; }

        public bool? IsSaleCreated { get; set; }

        public DateTime? EndTimeUTC { get; set; }

        [Required]
        public DateTime StartTimeUTC { get; set; }

        [Required]
        public byte? MobileBiddingTypeID { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public bool IsDeleted { get; set; }

        public Project Project { get; set; }

        public Class Class { get; set; }
    }
}
