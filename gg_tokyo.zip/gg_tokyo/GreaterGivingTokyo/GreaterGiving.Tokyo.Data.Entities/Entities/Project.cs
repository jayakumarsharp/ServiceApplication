﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("Project")]
    public class Project
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ProjectXid { get; set; }

        public bool IsDeleted { get; set; }

        [Required]
        public string Prefix { get; set; }

        [Required]
        public string ProjectDisplayName { get; set; }

        public string ClientName { get; set; }

        [Column(TypeName = "char")]
        [Required]
        public string TimeZoneId { get; set; }

        public string Password { get; set; }

        public byte[] ProjectImage { get; set; }

        public string ProjectImagePath { get; set; }

        public bool DisplayBiddersOnAppealBoard { get; set; }

        public bool SendSmsOutbidNotices { get; set; }

        public bool SendEmailOutbidNotices { get; set; }

        public bool ShowFmv { get; set; }

        public bool AppealOnlyEvent { get; set; }

        public byte? WinningBidderDetail { get; set; }

        public bool ShowHistoryOnRegularPackages { get; set; }

        public bool ShowHistoryOnMultisalePackages { get; set; }

        public bool ShowDonors { get; set; }

        public byte? BrowsePageSortOrder { get; set; }

        public decimal? AppealGoal { get; set; }

        public string LegalTerms { get; set; }

        public int LeaderboardNumberOfPackages { get; set; }

        public int DonationPackageXid { get; set; }

        public string DonationLabel { get; set; }

        public byte[] AppealImage { get; set; }

        public string AppealImagePath { get; set; }

        public byte? LeaderboardTheme { get; set; }

        public int LeaderboardScreenDisplaySeconds { get; set; }

        public decimal? RevenueGoal { get; set; }

        public bool AllowMaxBidding { get; set; }

        public byte? LeaderboardStyle { get; set; }

        public string SuggestedDonationAmounts { get; set; }

        [Column(TypeName = "char")]
        public string ProjectKey { get; set; }

        public decimal? AppealTotalRaised { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }
    }
}
