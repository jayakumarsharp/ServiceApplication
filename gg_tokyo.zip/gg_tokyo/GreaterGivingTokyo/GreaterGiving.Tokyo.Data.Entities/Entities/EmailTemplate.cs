﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("EmailTemplate")]
    public class EmailTemplate
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmailTemplateID { get; set; }

        [Required]
        [ForeignKey("Project")]
        public int ProjectXid { get; set; }

        [Required]
        public string Message { get; set; }
                
        [Required]
        public string Subject { get; set; }

        public DateTime? CreatedDate { get; set; }

        public Project Project { get; set; }
    }
}
