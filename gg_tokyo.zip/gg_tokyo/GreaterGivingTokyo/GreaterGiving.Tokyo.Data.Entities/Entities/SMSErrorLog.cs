﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("SMSErrorLog")]
    public class SMSErrorLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SMSErrorLogId { get; set; }

        public int SMSRequestId { get; set; }

        public string SMSErrorCode { get; set; }
        
        public string SMSErrorDescription { get; set; }
        
        public string PhoneNo { get; set; }

        public DateTime? SMSErrorDate { get; set; }
        
        public DateTime? CreatedDate { get; set; }
    }
}
