﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GreaterGiving.Tokyo.Entities.Entities
{
    [Table("SMSUnsubscribe")]
    public class SMSUnsubscribe
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SMSUnsubscribeID { get; set; }

        public string PhoneNo { get; set; }

        public bool Unsubscribe { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
