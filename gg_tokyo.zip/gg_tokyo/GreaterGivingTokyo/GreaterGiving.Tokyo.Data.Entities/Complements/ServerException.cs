﻿
namespace GreaterGiving.Tokyo.Entities
{
    public partial class ServerException
    {
        public string UserName { get; set; }
    }
}
