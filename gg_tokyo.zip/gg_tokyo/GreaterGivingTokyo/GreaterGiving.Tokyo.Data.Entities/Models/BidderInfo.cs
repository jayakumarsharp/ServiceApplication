﻿using System;

namespace GreaterGiving.Tokyo.Entities.Models
{
    public class BidderInfo
    {
        public string OnlineBidderKey { get; set; }

        public string SupporterName { get; set; }

        public int? Number { get; set; }

        public int? TableNumber { get; set; }

        public string BidderToken { get; set; }

        public string Prefix { get; set; }

        public DateTime? ValidTo { get; set; }
    }
}
