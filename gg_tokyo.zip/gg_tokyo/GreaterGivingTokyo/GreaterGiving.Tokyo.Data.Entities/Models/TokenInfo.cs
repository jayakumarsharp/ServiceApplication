﻿using System;

namespace GreaterGiving.Tokyo.Entities.Models
{
    public class TokenInfo
    {
        public string Token { get; set; }
        public DateTime? ValidTo { get; set; }
    }
}
