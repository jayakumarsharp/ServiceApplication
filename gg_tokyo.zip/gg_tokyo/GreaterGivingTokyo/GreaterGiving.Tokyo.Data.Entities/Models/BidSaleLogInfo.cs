﻿namespace GreaterGiving.Tokyo.Entities.Models
{
    /// <summary>
    /// For reading the Bid Sale Log Information
    /// </summary>
    public class BidSaleLogInfo
    {
        public int ProjectXid { get; set; }

        public int BidderXid { get; set; }

        public int PackageXid { get; set; }

        public int? BidXid { get; set; }

        public int? SaleID { get; set; }

        public int? BidderActionType { get; set; }

        public decimal? BidAmount { get; set; }

        public int? QtyPurchased { get; set; }

        public int? EventType { get; set; }
    }
}