﻿using System;

namespace GreaterGiving.Tokyo.Entities.Models
{
    public class ProjectInfo
    {
        public string Prefix { get; set; }

        public string AdminToken { get; set; }

        public DateTime? ValidTo { get; set; }
    }
}
