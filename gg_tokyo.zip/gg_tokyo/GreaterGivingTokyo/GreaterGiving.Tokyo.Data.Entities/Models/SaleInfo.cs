﻿
namespace GreaterGiving.Tokyo.Entities.Models
{
    public class SaleInfo
    {
        public int BidderXid { get; set; }

        public int ProjectXid { get; set; }

        public int PackageXid { get; set; }

        public int GGOUpdateStatus { get; set; }

        public decimal Amount { get; set; }

        public int? QtyPurchased { get; set; }
    }
}
