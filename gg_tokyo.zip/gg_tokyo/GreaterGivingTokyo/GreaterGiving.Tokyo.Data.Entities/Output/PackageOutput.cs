﻿using Newtonsoft.Json;
using System;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class PackageOutput
    {
        [JsonProperty("ID")]
        public int PackageXid { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }

        [JsonProperty("itemname")]
        public string Name { get; set; }
        [JsonProperty("itemnumber")]
        public string Number { get; set; }

        [JsonProperty("category")]
        public string ClassName { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("exceptions")]
        public string RestrictionNotes { get; set; }

        [JsonProperty("donor")]
        public string[] Donors { get; set; }

        [JsonProperty("fmv")]
        public string Value { get; set; }

        [JsonProperty("startingbid")]
        public decimal? MinimumBid { get; set; }

        [JsonProperty("minimumbid")]
        public decimal? MinimumRaise { get; set; }

        [JsonProperty("buynow")]
        public decimal? Price { get; set; }

        [JsonProperty("maxavailable")]
        public int? MaxAvailable { get; set; }

        [JsonProperty("qtyremaining")]
        public int? QtyRemaining { get; set; }

        [JsonProperty("qtypurchased")]
        public int? QtyPurchased { get; set; }

        [JsonProperty("closingtime")]
        public DateTime? EndTimeUTC { get; set; }

        [JsonProperty("startingtime")]
        public DateTime StartTimeUTC { get; set; }

        [JsonProperty("imglink")]
        public string[] Images { get; set; }

        [JsonProperty("itemtype")]
        public string MobileBiddingType { get; set; }

        [JsonProperty("showfmv")]
        public bool ShowFmv { get; set; }

        [JsonProperty("showhistory")]
        public bool ShowHistoryOnRegularPackages { get; set; }

        [JsonProperty("showhistoryms")]
        public bool ShowHistoryOnMultisalePackages { get; set; }

        [JsonProperty("displaydonors")]
        public bool ShowDonors { get; set; }

        [JsonProperty("isFavorite")]
        public bool IsFavorite { get; set; }

        [JsonProperty("isBid")]
        public bool IsBid { get; set; }

        [JsonProperty("Status")]
        public string Status { get; set; }

        [JsonProperty("CurrentHighBid")]
        public decimal? CurrentHighBid { get; set; }

        [JsonProperty("appeal_logo_path")]
        public string AppealImagePath { get; set; }

        [JsonProperty("appeal")]
        public decimal[] SuggestedDonationAmounts { get; set; }

        [JsonProperty("appeal_label")]
        public string DonationLabel { get; set; }

        [JsonProperty("appealgoal")]
        public decimal? AppealGoal { get; set; }

        [JsonProperty("totalraised")]
        public decimal? TotalRaised { get; set; }

        [JsonProperty("biddername")]
        public string BidderName { get; set; }

        [JsonProperty("biddernumber")]
        public int? BidderNumber { get; set; }

        [JsonProperty("currenthighbidamount")]
        public decimal? CurrentHighBidAmount { get; set; }

        [JsonProperty("totalcount")]
        public int? TotalCount { get; set; }
    }
}
