﻿using System;
using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class PackageSearchOutput
    {
        [JsonProperty("ID")]
        public int PackageXid { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }

        [JsonProperty("itemname")]
        public string Name { get; set; }

        [JsonProperty("itemnumber")]
        public string Number { get; set; }

        [JsonProperty("category")]
        public string ClassName { get; set; }

        [JsonProperty("startingbid")]
        public decimal? MinimumBid { get; set; }

        [JsonProperty("minimumbid")]
        public decimal? MinimumRaise { get; set; }

        [JsonProperty("buynow")]
        public decimal? Price { get; set; }

        [JsonProperty("bid")]
        public decimal? Bid { get; set; }

        [JsonProperty("maxbid")]
        public decimal? MaxBid { get; set; }

        [JsonProperty("closingtime")]
        public DateTime? EndTimeUTC { get; set; }

        [JsonProperty("startingtime")]
        public DateTime? StartTimeUTC { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("isdeleted")]
        public bool IsDeleted { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }

        [JsonProperty("bidcount")]
        public decimal? BidCount { get; set; }

        [JsonProperty("itemtype")]
        public string MobileBiddingType { get; set; }
    }
}
