﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class BidderSearchOutput
    {
        [JsonProperty("ID")]
        public int BidderXid { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }
        
        [JsonProperty("biddername")]
        public string SupporterName { get; set; }

        [JsonProperty("biddernumber")]
        public int? Number { get; set; }

        [JsonProperty("tablenumber")]
        public int? TableNumber { get; set; }

        [JsonProperty("email")]
        public string[] Emails { get; set; }

        [JsonProperty("phone")]
        public string[] MobilePhones { get; set; }
        
        [JsonProperty("bids")]
        public int? Bids { get; set; }

        [JsonProperty("itemtype")]
        public string MobileBiddingType { get; set; }

        [JsonProperty("isdeleted")]
        public bool IsDeleted { get; set; }
    }
}
