﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class ResultMessage
    {
        [JsonProperty("message")]
        public string Message { get; set; }
    }
}
