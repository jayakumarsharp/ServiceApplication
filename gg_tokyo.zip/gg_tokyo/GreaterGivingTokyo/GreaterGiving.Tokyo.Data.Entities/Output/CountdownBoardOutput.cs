﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class CountdownBoardOutput
    {
        [JsonProperty("packageid")]
        public int PackageXid { get; set; }

        [JsonProperty("countdowntime")]
        public string CountdownTime { get; set; }
    }
}
