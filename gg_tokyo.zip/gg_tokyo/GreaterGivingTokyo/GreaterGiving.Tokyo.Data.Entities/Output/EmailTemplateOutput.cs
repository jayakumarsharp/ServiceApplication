﻿using System;
using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class EmailTemplateOutput
    {
        [JsonProperty("emailtemplateid")]
        public int EmailTemplateID { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }
       
        [JsonProperty("subject")]
        public string Subject { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("createddate")]
        public DateTime? CreatedDate { get; set; }
    }
}
