﻿using System;
using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class EmbedReportOutput
    {
        [JsonProperty("updateddate")]
        public DateTime? UpdatedDate { get; set; }
    }
}
