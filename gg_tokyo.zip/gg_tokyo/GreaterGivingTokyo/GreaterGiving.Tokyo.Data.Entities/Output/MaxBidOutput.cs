﻿using System;
using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class MaxBidOutput
    {
        [JsonProperty("packageid")]
        public int PackageXid { get; set; }

        [JsonProperty("number")]
        public string Number { get; set; }

        [JsonProperty("bidderid")]
        public int BidderId { get; set; }

        [JsonProperty("itemname")]
        public string Name { get; set; }

        [JsonProperty("maxbidamount")]
        public decimal? MaxBidAmount { get; set; }

        [JsonProperty("createDate")]
        public DateTime? CreatedDate { get; set; }
    }
}