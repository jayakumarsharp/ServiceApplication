﻿using System;
using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class SMSTemplateOutput
    {
        [JsonProperty("smstemplateid")]
        public int SMSTemplateID { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("createdDate")]
        public DateTime? CreatedDate { get; set; }

    }
}
