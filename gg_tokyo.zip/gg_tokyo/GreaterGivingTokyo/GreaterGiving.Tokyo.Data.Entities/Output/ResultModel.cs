﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class ResultModel
    {
        [JsonProperty("resultcode")]
        public string ResultCode { get; set; }

        [JsonProperty("reason")]
        public string Reason { get; set; }
    }
}
