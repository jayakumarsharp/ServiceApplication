﻿namespace GreaterGiving.Tokyo.SaleDataService.Model
{
    public class SaleResultModel
    {
        public bool? Status { get; set; }
        public string Error { get; set; }

    }
}
