﻿using System;
using Newtonsoft.Json;
namespace GreaterGiving.Tokyo.Entities.Output
{
    public class BidHistoryOutput
    {
        [JsonProperty("bidderid")]
        public int BidderXid { get; set; }

        [JsonProperty("bidxid")]
        public int BidXid { get; set; }

        [JsonProperty("saleid")]
        public int SaleId { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }

        [JsonProperty("packageid")]
        public int PackageXid { get; set; }

        [JsonProperty("number")]
        public string Number { get; set; }

        [JsonProperty("itemname")]
        public string Name { get; set; }

        [JsonProperty("amount")]
        public decimal? Amount { get; set; }

        [JsonProperty("itemtype")]
        public string MobileBiddingType { get; set; }

        [JsonProperty("isdeleted")]
        public bool IsDeleted { get; set; }

        [JsonProperty("createdDate")]
        public DateTime? CreatedDate { get; set; }
        
    }
}