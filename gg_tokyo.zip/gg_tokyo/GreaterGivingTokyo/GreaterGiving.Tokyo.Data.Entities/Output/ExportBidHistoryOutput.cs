﻿using System;
using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class ExportBidHistoryOutput
    {
        [JsonProperty("packageid")]
        public int PackageXid { get; set; }

        [JsonProperty("packagenumber")]
        public string PackageNumber { get; set; }

        [JsonProperty("itemname")]
        public string PackageName { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }

        [JsonProperty("bidderid")]
        public int BidderXid { get; set; }

        [JsonProperty("biddernumber")]
        public string BidderNumber { get; set; }

        [JsonProperty("biddername")]
        public string BidderName { get; set; }

        [JsonProperty("phone")]
        public string MobilePhones { get; set; }

        [JsonProperty("email")]
        public string Emails { get; set; }

        [JsonProperty("amount")]
        public decimal? Amount { get; set; }
        
        [JsonProperty("bidxid")]
        public int? BidXid { get; set; }

        [JsonProperty("saleid")]
        public int? SaleId { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }

        [JsonProperty("isdeleted")]
        public bool IsDeleted { get; set; }

        [JsonProperty("createdDate")]
        public DateTime? CreatedDate { get; set; }
    }
}
