﻿using System;
using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class BidderOutput
    {
        [JsonProperty("ID")]        
        public int BidderXid { get; set; }        
        [JsonProperty("uID")]
        public int ProjectXid { get; set; }
        [JsonProperty("bidderKey")]
        public string OnlineBidderKey { get; set; }

        [JsonProperty("biddername")]
        public string SupporterName { get; set; }

        [JsonProperty("phone")]
        public string MobilePhones { get; set; }

        [JsonProperty("email")]
        public string Emails { get; set; }

        [JsonProperty("biddernumber")]
        public int? Number { get; set; }

        [JsonProperty("tablenumber")]
        public int? TableNumber { get; set; }

        [JsonProperty("amount")]
        public decimal Amount { get; set; }

        [JsonProperty("createDate")]
        public DateTime? CreatedDate { get; set; }

        [JsonProperty("bids")]
        public int? Bids { get; set; }

        [JsonProperty("totalamount")]
        public decimal? TotalAmount { get; set; }

        [JsonProperty("Prefix")]
        public string Prefix { get; set; }

        [JsonProperty("packageid")]
        public int PackageXid { get; set; } // It is used only for Email Subject
    }
}
