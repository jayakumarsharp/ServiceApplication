﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class ProjectOutput
    {
        [JsonProperty("ggProjectId")]
        public int ProjectXid { get; set; }
        
        [JsonProperty("Organization")]
        public string ProjectDisplayName { get; set; }
        
        [JsonProperty("timezone")]
        public string TimeZoneId { get; set; }

        [JsonProperty("logo_path")]
        public string ProjectImagePath { get; set; }

        [JsonProperty("terms")]
        public string LegalTerms { get; set; }

        [JsonProperty("ClientName")]
        public string ClientName { get; set; }

        [JsonProperty("allowMaxBidding")]
        public bool AllowMaxBidding { get; set; }

        [JsonProperty("appeal_package")]
        public int? DonationPackageXid { get; set; }

        [JsonProperty("appeal_only")]
        public bool AppealOnlyEvent { get; set; }

        [JsonProperty("showthanks")]
        public bool DisplayBiddersOnAppealBoard { get; set; }

        [JsonProperty("leaderboard_theme")]
        public string LeaderBoardTheme { get; set; }

        [JsonProperty("display_loop_time")]
        public int LeaderboardScreenDisplaySeconds { get; set; }

        [JsonProperty("projectKey")]
        public string ProjectKey { get; set; }

        [JsonProperty("slug")]
        public string Prefix { get; set; }

        [JsonProperty("display_sort")]
        public string LeaderboardStyle { get; set; }

        [JsonProperty("winnertype")]
        public byte? WinningBidderDetail { get; set; }
    }
}
