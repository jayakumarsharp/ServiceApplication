﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class SponsorOutput
    {
        [JsonProperty("ID")]
        public int SponsorXid { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }

        [JsonProperty("imgpath")]
        public string ImagePath { get; set; }
    }
}
