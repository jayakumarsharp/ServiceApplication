﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class EmailDeliveryStatusInput
    {        
        public int EmailRequestId { get; set; }

        public string EmailAddress { get; set; }

        public int? StatusIndicator { get; set; }

        public DateTime SendTime { get; set; }

        public DateTime DeliveryTime { get; set; }

        public string DeliveryStatus { get; set; }

        public int? BidderId { get; set; }

        public string MessageId { get; set; }
    }
}
