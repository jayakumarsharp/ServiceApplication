﻿using Newtonsoft.Json;
using System;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class PackageFieldValues
    {
        [JsonProperty("ID")]
        public int PackageXid { get; set; }
        [JsonProperty("uID")]
        public int ProjectXid { get; set; }
        [JsonProperty("itemname")]
        public string Name { get; set; }
        [JsonProperty("itemnumber")]
        public string Number { get; set; }
        [JsonProperty("category")]
        public string ClassName { get; set; }
        [JsonProperty("description")]
        public string Description { get; set; }
        [JsonProperty("exceptions")]
        public string RestrictionNotes { get; set; }
        [JsonProperty("donor")]
        public string[] Donors { get; set; }
        [JsonProperty("fmv")]
        public string Value { get; set; }
        [JsonProperty("startingbid")]
        public decimal? MinimumBid { get; set; }
        [JsonProperty("minimumbid")]
        public decimal? MinimumRaise { get; set; }
        [JsonProperty("buynow")]
        public decimal? Price { get; set; }
        [JsonProperty("maxavailable")]
        public int? MaxAvailable { get; set; }
        [JsonProperty("closingtime")]
        public DateTime? EndTimeUTC { get; set; }
        [JsonProperty("startingtime")]
        public DateTime StartTimeUTC { get; set; }
        [JsonProperty("imglink")]
        public byte[][] Images { get; set; }
        [JsonProperty("itemtype")]
        public string MobileBiddingType { get; set; }

    }
}
