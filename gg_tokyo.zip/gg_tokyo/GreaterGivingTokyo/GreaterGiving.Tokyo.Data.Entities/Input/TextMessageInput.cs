﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class TextMessageInput
    {
        [JsonProperty("authentication")]
        public AuthenticationInput Authentication { get; set; }

        [JsonProperty("field_value_list")]
        public TextMessageFieldValues TextMessageFieldValue { get; set; }

        [JsonProperty("record_type")]
        public string RecordType { get; set; }
    }
}
