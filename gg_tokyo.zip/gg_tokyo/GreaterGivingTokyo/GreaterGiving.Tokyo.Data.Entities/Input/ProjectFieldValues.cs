﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class ProjectFieldValues
    {
        [JsonProperty("ggProjectId")]
        public int ProjectXid { get; set; }

        [JsonProperty("ID")]
        public int ID { get; set; }

        [JsonProperty("slug")]
        public string Prefix { get; set; }        

        [JsonProperty("Organization")]
        public string ProjectDisplayName { get; set; }

        [JsonProperty("status")]
        public bool IsDeleted { get; set; }

        [JsonProperty("coname")]
        public string ClientName { get; set; }

        [JsonProperty("Password")]
        public string Password { get; set; }

        [JsonProperty("timezone")]
        public string TimeZoneId { get; set; }

        [JsonProperty("logo")]
        public byte[] ProjectImage { get; set; }

        [JsonProperty("showthanks")]
        public bool DisplayBiddersOnAppealBoard { get; set; }

        [JsonProperty("sendsms")]
        public bool SendSmsOutbidNotices { get; set; }

        [JsonProperty("sendemail")]
        public bool SendEmailOutbidNotices { get; set; }

        [JsonProperty("showfmv")]
        public bool ShowFmv { get; set; }

        [JsonProperty("appeal_only")]
        public bool AppealOnlyEvent { get; set; }

        [JsonProperty("winnertype")]
        public string WinningBidderDetail { get; set; }

        [JsonProperty("showhistory")]
        public bool ShowHistoryOnRegularPackages { get; set; }

        [JsonProperty("showhistoryms")]
        public bool ShowHistoryOnMultisalePackages { get; set; }

        [JsonProperty("displaydonors")]
        public bool ShowDonors { get; set; }

        [JsonProperty("sortorder")]
        public string BrowsePageSortOrder { get; set; }

        [JsonProperty("appealgoal")]
        public decimal AppealGoal { get; set; }

        [JsonProperty("terms")]
        public string LegalTerms { get; set; }

        [JsonProperty("display_items")]
        public int LeaderboardNumberOfPackages { get; set; }

        [JsonProperty("appeal_package")]
        public int DonationPackageXid { get; set; }

        [JsonProperty("appeal_label")]
        public string DonationLabel { get; set; }

        [JsonProperty("appeal_logo")]
        public byte[] AppealImage { get; set; } 
        
        [JsonProperty("leaderboard_theme")]
        public string LeaderBoardTheme { get; set; }

        [JsonProperty("display_loop_time")]
        public int LeaderboardScreenDisplaySeconds { get; set; }

        [JsonProperty("target")]
        public decimal RevenueGoal { get; set; }

        [JsonProperty("allowmax")]
        public bool AllowMaxBidding { get; set; }

        [JsonProperty("display_sort")]
        public string LeaderboardStyle { get; set; }        

        [JsonProperty("appeal")]
        public decimal[] SuggestedDonationAmounts { get; set; }

        [JsonProperty("projectKey")]
        public string ProjectKey { get; set; }//NEED TO CHANGE DATATYPE SINCE THE DATA VALUE IS NULL
    }
}
