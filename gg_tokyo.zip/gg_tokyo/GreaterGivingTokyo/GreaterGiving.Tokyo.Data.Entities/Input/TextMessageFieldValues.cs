﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class TextMessageFieldValues
    {
        [JsonProperty("uID")]
        public int ProjectXid { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("phone")]
        public string Phone { get; set; }
    }
}
