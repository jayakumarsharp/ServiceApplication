﻿using System;

namespace GreaterGiving.Tokyo.SendSaleData.Model
{
    public class SaleData
    {
        public string UserName { get; set; }

        public string Password { get; set; }

        public int SaleId { get; set; }

        public string PartnerId { get; set; }

        public int ProjectId { get; set; }

        public int BidderId { get; set; }

        public int PackageId { get; set; }

        public int SaleQuantity { get; set; }

        public decimal SaleTotalPreTax { get; set; }

        public DateTime SaleDate { get; set; }

        public int PackageType { get; set; }
    }
}
