﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class SponsorFieldValues
    {
        [JsonProperty("ID")]
        public int SponsorXid { get; set; }
        [JsonProperty("uID")]
        public int ProjectXid { get; set; }
        [JsonProperty("img")]
        public byte[] Images { get; set; }
    }
}
