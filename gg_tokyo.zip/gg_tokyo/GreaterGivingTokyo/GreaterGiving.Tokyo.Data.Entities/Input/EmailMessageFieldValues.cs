﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class EmailMessageFieldValues
    {
        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("to")]
        public string ToEmailAddress { get; set; }

        [JsonProperty("from")]
        public string FromEmailAddress { get; set; }

        [JsonProperty("fromName")]
        public string FromName { get; set; }

        [JsonProperty("subject")]
        public string Subject { get; set; }
    }
}
