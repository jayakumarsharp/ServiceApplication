﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class PackageInput
    {
        [JsonProperty("record_type")]
        public string RecordType { get; set; }

        [JsonProperty("record_function")]
        public string RecordFunction { get; set; }

        [JsonProperty("authentication")]
        public AuthenticationInput Authentication { get; set; }

        [JsonProperty("field_value_list")]
        public PackageFieldValues PackageFieldValue { get; set; }
    }
}
