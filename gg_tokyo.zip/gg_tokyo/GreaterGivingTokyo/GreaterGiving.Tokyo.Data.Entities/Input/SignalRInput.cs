﻿using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace GreaterGiving.Tokyo.Entities.Output
{
    public class SignalRInput
    {
        [JsonProperty("prefix")]
        public string Prefix { get; set; }

        [JsonProperty("biddinghistory")]
        public List<JObject> BiddingHistory { get; set; }

        [JsonProperty("bidderdetails")]
        public JObject BidderDetails { get; set; }

        [JsonProperty("packageid")]
        public int PackageXid { get; set; }
    }
}
