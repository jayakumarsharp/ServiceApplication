﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class BulkPackageInput
    {
        [JsonProperty("authentication")]
        public AuthenticationInput Authentication { get; set; }

        [JsonProperty("field_value_list")]
        public BulkPackageFieldValues BulkPackageFieldValue { get; set; }

        [JsonProperty("record_type")]
        public string RecordType { get; set; }
    }
}