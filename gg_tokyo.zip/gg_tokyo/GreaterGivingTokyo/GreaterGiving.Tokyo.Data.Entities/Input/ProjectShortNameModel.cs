﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class ProjectShortNameModel
    {
        public AuthenticationInput Authentication { get; set; }

        [JsonProperty("field_value_list")]
        public ShortNameFieldValue ShortNameFieldValue { get; set; }
    }

    public class ShortNameFieldValue
    {
        [JsonProperty("shortname")]
        public string ShortName { get; set; }

    }
}
