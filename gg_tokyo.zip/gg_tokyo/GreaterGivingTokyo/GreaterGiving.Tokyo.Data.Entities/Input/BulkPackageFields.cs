﻿using Newtonsoft.Json;
using System;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class BulkPackageFields
    {
        [JsonProperty("closingtime")]
        public DateTime? EndTimeUTC { get; set; }

        [JsonProperty("itemtype")]
        public string MobileBiddingType { get; set; }

        [JsonProperty("packageId")]
        public int PackageXid { get; set; }

        [JsonProperty("startingtime")]
        public DateTime StartTimeUTC { get; set; }
    }
}