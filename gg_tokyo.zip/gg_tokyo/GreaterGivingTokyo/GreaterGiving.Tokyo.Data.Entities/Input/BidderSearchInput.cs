﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class BidderSearchInput
    {
        [JsonProperty("biddername")]
        public string BidderName { get; set; }

        [JsonProperty("biddernumber")]
        public int? BidderNumber { get; set; }
    }
}
