﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class LeaderBoardInput
    {
        [JsonProperty("package_filter_type")]
        public string PackageFilterType { get; set; }

        [JsonProperty("category_filter_type")]
        public string CategoryFilterType { get; set; }

        [JsonProperty("package_sort")]
        public string PackageSort { get; set; }

        [JsonProperty("display_count")]
        public int DisplayCount { get; set; }

        [JsonProperty("displayed_packages")]
        public int[] DisplayedPackages { get; set; }
    }
}
