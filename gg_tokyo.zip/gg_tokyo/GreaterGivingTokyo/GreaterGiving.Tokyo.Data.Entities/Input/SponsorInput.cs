﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class SponsorInput
    {
        [JsonProperty("record_type")]
        public string RecordType { get; set; }

        [JsonProperty("authentication")]
        public AuthenticationInput Authentication { get; set; }

        [JsonProperty("field_value_list")]
        public SponsorFieldValues SponsorFieldValue { get; set; }
    }
}
