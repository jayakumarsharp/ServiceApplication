﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    /// <summary>
    /// Bidder Field Values
    /// </summary>
    public class BidderFieldValues
    {
        [JsonProperty("ID")]
        public int BidderXid { get; set; }

        [JsonProperty("uID")]
        public int ProjectXid { get; set; }

        [JsonProperty("bidderKey")]
        public string OnlineBidderKey { get; set; }

        [JsonProperty("lname")]
        public string SupporterName { get; set; }

        [JsonProperty("phone")]
        public string[] MobilePhones { get; set; }

        [JsonProperty("email")]
        public string[] Emails { get; set; }

        [JsonProperty("biddernumber")]
        public int Number { get; set; }

        [JsonProperty("tablenumber")]
        public int TableNumber { get; set; }
    }
}
