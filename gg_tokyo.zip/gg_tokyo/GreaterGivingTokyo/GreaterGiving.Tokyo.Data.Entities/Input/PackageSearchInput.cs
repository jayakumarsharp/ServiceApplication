﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class PackageSearchInput
    {
              
        [JsonProperty("itemname")]
        public string Name { get; set; }

        [JsonProperty("itemnumber")]
        public string Number { get; set; }

        [JsonProperty("category")]
        public string ClassName { get; set; }

        [JsonProperty("nobids")]
        public bool ShouldNoBids { get; set; }

        [JsonProperty("currentlyopen")]
        public bool ShouldCurrentlyOpen{ get; set; }

        [JsonProperty("buynow")]
        public bool ShouldBuyNow { get; set; }

        [JsonProperty("preview")]
        public bool ShouldPreview { get; set; }

        [JsonProperty("multisale")]
        public bool ShouldMultisale{ get; set; }        
    }
}
