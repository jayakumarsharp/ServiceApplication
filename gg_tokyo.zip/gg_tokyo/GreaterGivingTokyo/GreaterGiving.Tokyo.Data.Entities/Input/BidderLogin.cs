﻿namespace GreaterGiving.Tokyo.Entities.Input
{
    public class BidderLogin
    {
        public string BidderToken { get; set; }
        public string OnlineBidderKey { get; set; }
    }
}
