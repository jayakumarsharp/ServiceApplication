﻿using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class EmailMessageInput
    {
        [JsonProperty("authentication")]
        public AuthenticationInput Authentication { get; set; }

        [JsonProperty("field_value_list")]
        public EmailMessageFieldValues EmailMessageFieldValue { get; set; }

        [JsonProperty("recordtype")]
        public string RecordType { get; set; }
    }
}
