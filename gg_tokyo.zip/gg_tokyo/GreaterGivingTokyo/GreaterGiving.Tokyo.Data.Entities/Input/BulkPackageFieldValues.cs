﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace GreaterGiving.Tokyo.Entities.Input
{
    public class BulkPackageFieldValues
    {
        [JsonProperty("dataArr")]
        public List<BulkPackageFields> BulkPackageFields { get; set; }
        [JsonProperty("ggProjectId")]
        public int ProjectXid { get; set; }
    }
}