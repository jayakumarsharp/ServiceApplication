﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.SqlServer;
using System.Data.SqlClient;
using System.Runtime.Remoting.Messaging;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Entities;

namespace GreaterGiving.Tokyo.Entities.Core
{
    [DbConfigurationType(typeof(AzureSqlConfiguration))]
    public class BiddingContext : DbContext, IBiddingContext
    {
        #region Constructors

        public BiddingContext(string connString) : base(connString)
        {
            Configuration.LazyLoadingEnabled = false;
            Configuration.ProxyCreationEnabled = false;
        }

        #endregion Constructors

        #region DbSet

        public IDbSet<Project> Projects { get; set; }

        public IDbSet<Package> Packages { get; set; }

        public IDbSet<Class> Class { get; set; }

        public IDbSet<PackageImage> PackageImage { get; set; }

        public IDbSet<Bidder> Bidders { get; set; }

        public IDbSet<Sponsor> Sponsors { get; set; }

        public IDbSet<Bid> Bids { get; set; }

        public IDbSet<BidDeletedHistory> BidDeletedHistories { get; set; }

        public IDbSet<BidSaleLog> BidSaleLogs { get; set; }

        public IDbSet<SMSRequest> SMSRequests { get; set; }

        public IDbSet<SMSDeliveryStatus> SMSDeliveryStatus { get; set; }

        public IDbSet<Sale> Sales { get; set; }

        public IDbSet<BidderList> BidderLists { get; set; }

        public IDbSet<CodeLookup> CodeLookups { get; set; }

        public IDbSet<DisplayLookup> DisplayLookups { get; set; }

        public IDbSet<EmailRequest> EmailRequests { get; set; }

        public IDbSet<EmailDeliveryStatus> EmailDeliveryStatus { get; set; }

        public IDbSet<EmailTemplate> EmailTemplates { get; set; }


        public IDbSet<SMSTemplate> SMSTemplates { get; set; }

        public IDbSet<SMSUnsubscribe> SMSUnsubscribes { get; set; }

        public IDbSet<EventLog> EventLogs { get; set; }

        public IDbSet<EventStatistics> Eventstatistics { get; set; }

        public IDbSet<SMSErrorLog> SMSErrorLogs { get; set; }

        public IDbSet<SMSRetryErrorList> SMSRetryErrorLists { get; set; }

        #endregion DbSet

        #region DbContext Override Implementations

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //Add any specific implementations here
        }

        public DbContextTransaction BeginTransaction()
        {
            AzureSqlConfiguration.SuspendExecutionStrategy = true;
            return Database.BeginTransaction();
        }

        public void ExecuteSQLCommand(string query, SqlParameter[] sqlParams)
        {
            Database.ExecuteSqlCommand(query, sqlParams);
        }

        #endregion DbContext Override Implementations
    }

    public class AzureSqlConfiguration : DbConfiguration
    {
        public AzureSqlConfiguration()
        {
            //Implemented SuspendExecutionStrategy to overcome limitation of SqlAzureExecutionStrategy
            //Entity Framework Limitations with Retrying Execution Strategies - https://msdn.microsoft.com/en-us/data/dn307226 
            //We get following issue https://stackoverflow.com/questions/30421695/the-configured-execution-strategy-sqlazureexecutionstrategy-does-not-support-u
            //When SuspendExecutionStrategy is not implemented
            this.SetExecutionStrategy("System.Data.SqlClient", () => SuspendExecutionStrategy
              ? (IDbExecutionStrategy)new DefaultExecutionStrategy()
              : new SqlAzureExecutionStrategy());
        }

        public static bool SuspendExecutionStrategy
        {
            get
            {
                return (bool?)CallContext.LogicalGetData("SuspendExecutionStrategy") ?? false;
            }
            set
            {
                CallContext.LogicalSetData("SuspendExecutionStrategy", value);
            }
        }
    }
}
