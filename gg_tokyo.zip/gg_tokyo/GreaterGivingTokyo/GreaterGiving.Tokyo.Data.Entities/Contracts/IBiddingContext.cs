﻿using GreaterGiving.Tokyo.Entities.Entities;
using System;
using System.Data.Entity;
using System.Data.SqlClient;

namespace GreaterGiving.Tokyo.Entities.Contracts
{
    public interface IBiddingContext : IDisposable
    {
        IDbSet<Project> Projects { get; set; }
        IDbSet<Package> Packages { get; set; }
        IDbSet<Class> Class { get; set; }
        IDbSet<PackageImage> PackageImage { get; set; }
        IDbSet<Bidder> Bidders { get; set; }
        IDbSet<Sponsor> Sponsors { get; set; }
        IDbSet<Bid> Bids { get; set; }
        IDbSet<BidDeletedHistory> BidDeletedHistories { get; set; }
        IDbSet<BidSaleLog> BidSaleLogs { get; set; }
        IDbSet<SMSRequest> SMSRequests { get; set; }
        IDbSet<SMSDeliveryStatus> SMSDeliveryStatus { get; set; }
        IDbSet<Sale> Sales { get; set; }
        IDbSet<BidderList> BidderLists { get; set; }
        IDbSet<CodeLookup> CodeLookups { get; set; }
        IDbSet<DisplayLookup> DisplayLookups { get; set; }
        IDbSet<EmailRequest> EmailRequests { get; set; }
        IDbSet<EmailDeliveryStatus> EmailDeliveryStatus { get; set; }
        IDbSet<EmailTemplate> EmailTemplates { get; set; }
        IDbSet<SMSTemplate> SMSTemplates { get; set; }
        IDbSet<SMSUnsubscribe> SMSUnsubscribes { get; set; }
        IDbSet<EventLog> EventLogs { get; set; }
        IDbSet<EventStatistics> Eventstatistics { get; set; }
        IDbSet<SMSErrorLog> SMSErrorLogs { get; set; }
        IDbSet<SMSRetryErrorList> SMSRetryErrorLists { get; set; }
        

        int SaveChanges();
        DbContextTransaction BeginTransaction();
        void ExecuteSQLCommand(string query, SqlParameter[] sqlParams);
    }
}
