﻿using GreaterGiving.Tokyo.Entities.Output;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

namespace GreaterGiving.Tokyo.Hubs
{
    [HubName("SRHub")]
    public class SignalRHub : Hub
    {
        public static void GetUpdatedPackages(int packageId)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<SignalRHub>();
            context.Clients.All.DisplayUpdatePackages(packageId);
        }

        public static void GetUpdatedProject(string prefix)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<SignalRHub>();
            context.Clients.All.DisplayUpdateProject(prefix);
        }

        public static void GetUpdatedBiddingHistory(SignalRInput input)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<SignalRHub>();
            context.Clients.All.DisplayUpdatedBiddingHistory(input);
        }

        public static void GetUpdatedAppealDonationPackages(string prefix)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<SignalRHub>();
            context.Clients.All.DisplayUpdatedAppealDonationPackages(prefix);
        }

        public static void GetUpdatedBidderForAppealDonationPackage(SignalRInput input)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<SignalRHub>();
            context.Clients.All.DisplayUpdatedBidderForAppealDonationPackage(input);
        }

        public static void GetTopBidders(string prefix)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<SignalRHub>();
            context.Clients.All.DisplayTopBidders(prefix);
        }

        public static void GetTopPackages(string prefix)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<SignalRHub>();
            context.Clients.All.DisplayTopPackages(prefix);
        }

        public static void GetUpdatedCountDownTime(string prefix)
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<SignalRHub>();
            context.Clients.All.DisplayUpdatedCountTime(prefix);
        }
    }
}
