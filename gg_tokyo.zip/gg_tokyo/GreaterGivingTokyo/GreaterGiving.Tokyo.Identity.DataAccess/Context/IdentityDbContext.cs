﻿using GreaterGiving.Tokyo.CrossCutting.Identity;
using System.Linq;

namespace GreaterGiving.Tokyo.Identity.DataAccess.Context
{
    internal class IdentityDbContext //: TokyoEntitiesDbContext
    {
        internal IdentityDbContext()
            //: base(CurrentUser.ConnectionString)
        { }

        /*internal TokyoDbContext(string tenantName)
            //: base(CurrentUser.GetEntityConnectionString(tenantName))
        { }*/

        public IQueryable<T> GetEntitySet<T>()
            where T : class
        {
            // return Set<T>().AsNoTracking();

            return null;
        }
    }
}
