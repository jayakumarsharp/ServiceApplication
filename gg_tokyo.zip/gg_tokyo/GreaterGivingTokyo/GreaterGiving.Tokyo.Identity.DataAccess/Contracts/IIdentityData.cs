﻿using GreaterGiving.Tokyo.Entities.Models;

namespace GreaterGiving.Tokyo.Identity.DataAccess.Contracts
{
    public interface IIdentityData
    {
        #region IIdentityData Members

        BidderInfo Authenticate(string onlineBidderKey);

        bool AuthenticateAdmin(string userName, string password);

        #endregion IIdentityData Members       
    }
}
