﻿using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Crypto;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Models;

namespace GreaterGiving.Tokyo.Identity.DataAccess.Core.Identity
{
    public class IdentityProject : IdentityBase
    {
        /// <summary>
        /// Identity Package Constructor for setting the context
        /// </summary>
        /// <param name="context"></param>
        public IdentityProject(IBiddingContext context) : base(context)
        { }

        public bool AuthenticateAdmin(string userName, string password)
        {
            //get encrypted password to validate with database password
            var encryptedPassword = CryptoHelper.Encrypt(password, ConfigManager.AESPassword, ConfigManager.AESSalt);

            //get project details by username(prefix) and password
            var project = GetProjectByUserNameAndPassword(userName, encryptedPassword);

            return (project != null);
        }
    }
}
