﻿using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Models;

namespace GreaterGiving.Tokyo.Identity.DataAccess.Core.Identity
{
    public class IdentityBidder : IdentityBase
    {
        /// <summary>
        /// BiddingPackage Constructor for setting the context
        /// </summary>
        /// <param name="context"></param>
        public IdentityBidder(IBiddingContext context) : base(context)
        { }


        public BidderInfo Authenticate(string onlineBidderKey)
        {
            BidderInfo bidderInfo = null;

            var bidder = GetBidderByOnlineBidderKey(onlineBidderKey);

            if (bidder == null)
                return bidderInfo;

            var project = GetProjectByProjectId(bidder.ProjectXid);

            if (project == null)
                return bidderInfo;

            bidderInfo = new BidderInfo();
            bidderInfo.OnlineBidderKey = bidder.OnlineBidderKey;
            bidderInfo.SupporterName = bidder.SupporterName;
            bidderInfo.Number = bidder.Number;
            bidderInfo.TableNumber = bidder.TableNumber;
            bidderInfo.Prefix = project.Prefix;

            return bidderInfo;
        }
    }
}
