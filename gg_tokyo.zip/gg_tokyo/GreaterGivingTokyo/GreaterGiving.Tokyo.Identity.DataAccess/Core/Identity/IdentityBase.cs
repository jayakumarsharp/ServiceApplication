﻿using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Entities;
using System;
using System.Linq;

namespace GreaterGiving.Tokyo.Identity.DataAccess.Core.Identity
{
    public class IdentityBase : IDisposable
    {
        public IBiddingContext _dbContext;

        public IdentityBase(IBiddingContext context)
        {
            _dbContext = context;
        }

        public void Dispose()
        {
            _dbContext = null;
        }

        public Bidder GetBidderByOnlineBidderKey(string onlineBidderKey)
        {
            return _dbContext.Bidders.FirstOrDefault(i => i.OnlineBidderKey == onlineBidderKey && (!i.IsDeleted));
        }

        public Project GetProjectByProjectId(int projectId)
        {
            return _dbContext.Projects.FirstOrDefault(i => i.ProjectXid == projectId && (!i.IsDeleted));
        }

        public Project GetProjectByUserNameAndPassword(string userName, string password)
        {
            return _dbContext.Projects.FirstOrDefault(i => i.Prefix.Trim().ToLower() == userName.Trim().ToLower() && i.Password == password && (!i.IsDeleted));
        }
    }
}
