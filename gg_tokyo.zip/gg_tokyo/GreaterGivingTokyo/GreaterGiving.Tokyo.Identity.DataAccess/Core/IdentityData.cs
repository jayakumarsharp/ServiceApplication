﻿using GreaterGiving.Tokyo.Bidding.DataAccess.Factory;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Identity.DataAccess.Contracts;
using System.ComponentModel.Composition;

namespace GreaterGiving.Tokyo.Identity.DataAccess.Core
{
    [Export(typeof(IIdentityData)), LogAspect, PartCreationPolicy(CreationPolicy.NonShared)]
    public sealed class IdentityData : IIdentityData
    {
        BidderInfo IIdentityData.Authenticate(string onlineBidderKey)
        {
            using (var obj = IdentityFactory.GetBiddingBidder())
            {
                return obj.Authenticate(onlineBidderKey);
            }
        }

        bool IIdentityData.AuthenticateAdmin(string userName, string password)
        {
            using (var obj = IdentityFactory.GetBiddingProject())
            {
                return obj.AuthenticateAdmin(userName, password);
            }
        }
    }
}
