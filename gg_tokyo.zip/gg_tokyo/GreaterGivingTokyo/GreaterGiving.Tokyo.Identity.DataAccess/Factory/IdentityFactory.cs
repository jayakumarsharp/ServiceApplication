﻿using GreaterGiving.Tokyo.CrossCutting.DBFactory;
using GreaterGiving.Tokyo.Identity.DataAccess.Core.Identity;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Factory
{
    public static class IdentityFactory
    {
        public static IdentityBidder GetBiddingBidder()
        {
            return new IdentityBidder(DbContextFactory.GetBiddingContext());
        }

        public static IdentityProject GetBiddingProject()
        {
            return new IdentityProject(DbContextFactory.GetBiddingContext());
        }
    }
}
