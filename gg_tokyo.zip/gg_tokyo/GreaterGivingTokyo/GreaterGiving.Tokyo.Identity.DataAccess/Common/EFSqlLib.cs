﻿using System.Data.Entity.SqlServer;

namespace GreaterGiving.Tokyo.Identity.DataAccess.Common
{
    internal static class EFSqlLib
    {
        private static SqlProviderServices _instance = SqlProviderServices.Instance;
    }
}