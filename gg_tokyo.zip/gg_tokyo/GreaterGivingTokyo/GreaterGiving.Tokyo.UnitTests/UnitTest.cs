﻿using Cdm.Via.Entities.Input;
using Cdm.Via.Entities.Models;
using Cdm.Via.IdentityService.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;

namespace Cdm.Via.UnitTests
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void LoginTestMethod()
        {
            IdentityController identityController = new IdentityController();
            UserLogin input = new UserLogin();
            input.UserName = "Sowmiyaas";
            input.Password = "behappy@24";
            input.Domain = "OFS1";
            var output = identityController.Login(input);
            Assert.IsNotNull(output);
        }        
    }
}
