﻿using System.Data.Entity;
using System.Data.SqlClient;
using GreaterGiving.Tokyo.Entities.Contracts;
using GreaterGiving.Tokyo.Entities.Entities;

namespace GreaterGiving.Tokyo.UnitTests.DataAccess
{
    public class FakeContext : IBiddingContext
    {

        public FakeContext()
        {
            Projects = new FakeDBSet<Project>();
            Packages = new FakeDBSet<Package>();
            Bidders = new FakeDBSet<Bidder>();
            Sponsors = new FakeDBSet<Sponsor>();
            Class = new FakeDBSet<Class>();
            PackageImage = new FakeDBSet<PackageImage>();
            Bids = new FakeDBSet<Bid>();
            BidDeletedHistories = new FakeDBSet<BidDeletedHistory>();
            BidSaleLogs = new FakeDBSet<BidSaleLog>();
            SMSRequests = new FakeDBSet<SMSRequest>();
            SMSDeliveryStatus = new FakeDBSet<SMSDeliveryStatus>();
            Sales = new FakeDBSet<Sale>();
            BidderLists = new FakeDBSet<BidderList>();
            CodeLookups = new FakeDBSet<CodeLookup>();
            DisplayLookups = new FakeDBSet<DisplayLookup>();
            EmailRequests = new FakeDBSet<EmailRequest>();
            EmailDeliveryStatus = new FakeDBSet<EmailDeliveryStatus>();
            EmailTemplates = new FakeDBSet<EmailTemplate>();
            SMSTemplates = new FakeDBSet<SMSTemplate>();
            SMSUnsubscribes = new FakeDBSet<SMSUnsubscribe>();
            EventLogs = new FakeDBSet<EventLog>();
            Eventstatistics = new FakeDBSet<EventStatistics>();
            SMSErrorLogs = new FakeDBSet<SMSErrorLog>();
            SMSRetryErrorLists = new FakeDBSet<SMSRetryErrorList>();
        }

        public IDbSet<Project> Projects
        {
            get; set;
        }

        public IDbSet<Package> Packages
        {
            get; set;
        }

        public IDbSet<Class> Class
        {
            get; set;
        }

        public IDbSet<PackageImage> PackageImage
        {
            get; set;
        }

        public IDbSet<Bidder> Bidders
        {
            get; set;
        }
        public IDbSet<Sponsor> Sponsors
        {
            get; set;
        }
        public IDbSet<Bid> Bids
        {
            get; set;
        }
        public IDbSet<BidDeletedHistory> BidDeletedHistories
        {
            get; set;
        }
        public IDbSet<BidSaleLog> BidSaleLogs
        {
            get; set;
        }
        public IDbSet<SMSRequest> SMSRequests
        {
            get; set;
        }
        public IDbSet<SMSDeliveryStatus> SMSDeliveryStatus
        {
            get; set;
        }

        public IDbSet<Sale> Sales
        {
            get; set;
        }
        public IDbSet<BidderList> BidderLists
        {
            get; set;
        }
        public IDbSet<CodeLookup> CodeLookups
        {
            get; set;
        }

        public IDbSet<DisplayLookup> DisplayLookups
        {
            get; set;
        }

        public IDbSet<EmailRequest> EmailRequests
        {
            get; set;
        }
        public IDbSet<EmailDeliveryStatus> EmailDeliveryStatus
        {
            get; set;
        }
        
        public IDbSet<EmailTemplate> EmailTemplates
        {
            get; set;
        }

        public IDbSet<SMSTemplate> SMSTemplates
        {
            get; set;
        }

        public IDbSet<SMSUnsubscribe> SMSUnsubscribes
        {
            get; set;
        }

        public IDbSet<EventLog> EventLogs
        {
            get; set;
        }

        public IDbSet<EventStatistics> Eventstatistics
        {
            get; set;
        }

        public IDbSet<SMSErrorLog> SMSErrorLogs
        {
            get; set;
        }

        public IDbSet<SMSRetryErrorList> SMSRetryErrorLists
        {
            get; set;
        }

        public DbContextTransaction BeginTransaction()
        {
            // Begin Transaction is set as null for Unit Tests. Setting null won't impact checking busincess logic in Unit Tests
            return null;
        }

        public void ExecuteSQLCommand(string query, SqlParameter[] sqlParams)
        {
        }

        public int SaveChanges()
        {
            return 1;
        }

        public int SaveChangesFail()
        {
            return 0;
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {                   
                }
                disposedValue = true;
            }
        }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion

    }
}
