﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.BiddingService;
using GreaterGiving.Tokyo.BiddingService.Controllers;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.UnitTests.DataAccess;
using GreaterGiving.Tokyo.SendSaleData.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Web.Http.Results;
using System;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.Services
{
    [TestClass]
    public class PackageBidderControllerTest
    {
        #region Private Members

        private static BidderFieldValues bidderFieldValues;
        private static string prefix;
        private static int pageno;
        private static int size;
        private static int packageXid;
        private static decimal amount;
        private static string activityType;
        private static int quantity;
        private static SaleData saleDataInputValues;
        private static AuthenticationInput auth;

        private FakeContext _fakeDBContext = new FakeContext();
        private static CommonFactory commonFactory = null;
        private static int saleID = 5;

        private static ResultMessage expectedOutputSuccess = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_Success };
        private static ResultMessage expectedOutputOutBid = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_OutBided };
        private static ResultMessage expectedOutputFail = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_Failure };


        #endregion Private Members

        #region Class Initialization

        public PackageBidderControllerTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            bidderFieldValues = commonFactory.CreateBidderFieldValues();
        }

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            prefix = "OBAPI";
            pageno = 1;
            size = 50;
            packageXid = 9254;
            amount = 10;
            activityType = "Favorites";
            quantity = 2;

            auth = new AuthenticationInput
            {
                UserName = "biddingtokyouser",
                Password = "biddingtokyo123",
                ProjectID = 9254
            };

            saleDataInputValues = new SaleData
            {
                UserName = auth.UserName,
                Password = auth.Password,
                PartnerId = "1",
                ProjectId = commonFactory.CreateProjectFieldValues().ProjectXid,
                BidderId = commonFactory.CreateBidderFieldValues().BidderXid,
                PackageId = commonFactory.CreatePackageFieldValues().PackageXid,
                SaleQuantity = 12,
                SaleTotalPreTax = 0,
                SaleDate = DateTime.UtcNow,
                PackageType = 1
            };


        }

        #endregion Class Initialization

        [TestMethod]
        public void TestAddOrRemoveFavoriteByBidderSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.AddOrRemoveFavorite(prefix, packageXid, true));
             
            //act
            var actionResult = controller.AddOrRemoveFavoriteByBidder(prefix, packageXid, true);

            //assert
            Assert.IsNotNull(actionResult);
        }

        [TestMethod]
        public void TestGetFavoritePackagesByBidderSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);
            mockBiddingDomain.Setup(i => i.GetFavoritePackagesByBidder(prefix, pageno, size)).Returns(new List<PackageOutput>());

            //act
            var actionResult = controller.GetFavoritePackagesByBidder(prefix, pageno, size) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }

        [TestMethod]
        public void TestAddBid_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.AddBid(prefix, packageXid, amount)).Returns(expectedOutputSuccess);

            //act
            var actionResult = controller.AddBid(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputSuccess.Message,actionResult.Content.Message);
        }

        [TestMethod]
        public void TestAddBid_OutBid()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.AddBid(prefix, packageXid, amount)).Returns(expectedOutputOutBid);

            //act
            var actionResult = controller.AddBid(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputOutBid.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestAddBid_Fail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.AddBid(prefix, packageXid, amount)).Returns(expectedOutputFail);

            //act
            var actionResult = controller.AddBid(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBidMore_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BidMore(prefix, packageXid, amount)).Returns(expectedOutputSuccess);

            //act
            var actionResult = controller.BidMore(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBidMore_OutBid()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BidMore(prefix, packageXid, amount)).Returns(expectedOutputOutBid);

            //act
            var actionResult = controller.BidMore(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputOutBid.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBidMore_Fail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BidMore(prefix, packageXid, amount)).Returns(expectedOutputFail);

            //act
            var actionResult = controller.BidMore(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestGetBidActivityByBidderSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);
            commonFactory.SetClaimsIdentity(bidderFieldValues);

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetBidActivityByBidder(prefix, activityType, pageno, size)).Returns(new List<PackageOutput>());

            //act
            var actionResult = controller.GetBidActivityByBidder(prefix, activityType, pageno, size) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
        }

        [TestMethod]
        public void TestAddBuy_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyRegularPackage(prefix, packageXid)).Returns(expectedOutputSuccess);

            //act
            var actionResult = controller.BuyRegularPackage(prefix, packageXid) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestAddBuy_OutBid()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyRegularPackage(prefix, packageXid)).Returns(expectedOutputOutBid);

            //act
            var actionResult = controller.BuyRegularPackage(prefix, packageXid) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputOutBid.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestAddBuy_Fail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyRegularPackage(prefix, packageXid)).Returns(expectedOutputFail);

            //act
            var actionResult = controller.BuyRegularPackage(prefix, packageXid) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBuyMultiSalePackages_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyMultiSalePackages(prefix, packageXid, quantity)).Returns(expectedOutputSuccess);

            //act
            var actionResult = controller.BuyMultiSalePackages(prefix, packageXid, quantity) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBuyMultiSalePackages_Fail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyMultiSalePackages(prefix, packageXid, quantity)).Returns(expectedOutputFail);

            //act
            var actionResult = controller.BuyMultiSalePackages(prefix, packageXid, quantity) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBuyDonationPackage_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyDonationPackage(prefix, packageXid, amount)).Returns(expectedOutputSuccess);

            //act
            var actionResult = controller.BuyDonationPackage(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBuyDonationPackage_Fail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyDonationPackage(prefix, packageXid, amount)).Returns(expectedOutputFail);

            //act
            var actionResult = controller.BuyDonationPackage(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSetMaxBid_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SetMaxBid(prefix, packageXid, amount)).Returns(expectedOutputSuccess);

            //act
            var actionResult = controller.SetMaxBid(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSetMaxBid_OutBid()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SetMaxBid(prefix, packageXid, amount)).Returns(expectedOutputOutBid);

            //act
            var actionResult = controller.SetMaxBid(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputOutBid.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSetMaxBid_Failure()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SetMaxBid(prefix, packageXid, amount)).Returns(expectedOutputFail);

            //act
            var actionResult = controller.SetMaxBid(prefix, packageXid, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBuyAppealDonationPackage_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyAppealDonationPackage(prefix, amount)).Returns(expectedOutputSuccess);

            //act
            var actionResult = controller.BuyAppealDonationPackage(prefix, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestBuyAppealDonationPackage_Fail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.BuyAppealDonationPackage(prefix, amount)).Returns(expectedOutputFail);

            //act
            var actionResult = controller.BuyAppealDonationPackage(prefix, amount) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSendSaleDataSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);
            mockBiddingDomain.Setup(i => i.SendSaleData(saleID, saleDataInputValues)).Returns(true);

            //act
            var actionResult = controller.SendSaleData(saleID, saleDataInputValues) as NegotiatedContentResult<bool>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsTrue(actionResult.Content == true);
        }

        [TestMethod]
        public void TestSendSaleDataFail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageBidderController(mockBiddingDomain.Object, mockAuthentication.Object);
            saleID = 1;
            mockBiddingDomain.Setup(i => i.SendSaleData(saleID, saleDataInputValues)).Returns(false);

            //act
            var actionResult = controller.SendSaleData(saleID, saleDataInputValues) as NegotiatedContentResult<bool>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsTrue(actionResult.Content == false);
        }
    }
}
