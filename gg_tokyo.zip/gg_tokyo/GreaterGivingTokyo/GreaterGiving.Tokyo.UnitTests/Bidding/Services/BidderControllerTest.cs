﻿using System.Collections.Generic;
using System.Web.Http.Results;
using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.BiddingService;
using GreaterGiving.Tokyo.BiddingService.Controllers;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.UnitTests.DataAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.Services
{
    /// <summary>
    /// Summary description for BidderControllerTest
    /// </summary>
    [TestClass]
    public class BidderControllerTest
    {
        private static int PackageId;
        private static AuthenticationInput auth;
        private static CommonFactory commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private static ProjectFieldValues createProject;
        private static List<BidderOutput> _expectedOutputSuccess;


        public BidderControllerTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            createProject = commonFactory.CreateProjectFieldValues();
        }
             

        [ClassInitialize()]
        public static void InitializeClass(TestContext testContext)
        {
            #region Input Model

            auth = new AuthenticationInput
            {
                UserName = "biddingtokyouser",
                Password = "biddingtokyo123",
                ProjectID = 5624
            };

            PackageId = 1;

            #endregion Input Model

            #region Output Model

            _expectedOutputSuccess = new List<BidderOutput> { new BidderOutput { SupporterName = "Test Bidder 1", Number = 001, Amount = 10 }};           

            #endregion Output Model
        }
                
        [TestMethod]
        public void TestGetBidderHistoryOrCurrentBuyers()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new BidderController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetBidderHistoryOrCurrentBuyers(createProject.Prefix, PackageId)).Returns(_expectedOutputSuccess);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);
            //act
            var actionResult = controller.GetBidderHistoryOrCurrentBuyers(createProject.Prefix, PackageId) as FormattedContentResult<List<BidderOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Count, actionResult.Content.Count);
        }
    }
}
