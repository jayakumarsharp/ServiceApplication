﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.BiddingService;
using GreaterGiving.Tokyo.BiddingService.Controllers;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Web.Http.Results;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.Services
{
    [TestClass]
    public class ProcessMobileBiddingDataControllerTest
    {
        #region private members

        private static AuthenticationInput auth;
        private static PackageInput packageInput;
        private static PackageFieldValues package_field_values;
        private static BidderInput bidderInput;
        private static BidderFieldValues bidder_field_values;
        private static SponsorInput sponsorInput;
        private static SponsorFieldValues sponsor_field_values;

        private static ResultModel _expectedOutputSuccess = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
        private static ResultModel _expectedOutputFail = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
        private static ResultModel _expectedOutputNotFound = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info003);

        private static JObject packageJobject;
        private static JObject bidderJobject;
        private static JObject sponsorJobject;

        #endregion private members

        #region class initialize

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            //Input model

            #region Package Input Model

            auth = new AuthenticationInput
            {
                UserName = "biddingtokyouser",
                Password = "biddingtokyo123",
                ProjectID = 5624
            };

            var images = new byte[4][];

            package_field_values = new PackageFieldValues
            {
                PackageXid = 10,
                ProjectXid = 5,
                Name = "Name",
                Number = "1",
                ClassName = "ClassName",
                Description = "Test",
                RestrictionNotes = "Test",
                Donors = new string[] { "test", "test" },
                Value = "10",
                MinimumBid = 10,
                MinimumRaise = 10,
                Price = 100,
                MaxAvailable = 1,
                EndTimeUTC = DateTime.UtcNow,
                StartTimeUTC = DateTime.UtcNow,
                Images = images,
                MobileBiddingType = "Type"
            };

            packageInput = new PackageInput
            {
                Authentication = auth,
                PackageFieldValue = package_field_values,
                RecordType = "items"
            };            

            var packagejson = JsonConvert.SerializeObject(packageInput);

            packageJobject = JObject.Parse(packagejson);

            #endregion Package Input Model

            #region Bidder Input Model

            bidder_field_values = new BidderFieldValues
            {
                BidderXid = 10,
                ProjectXid = 20,
                OnlineBidderKey = "xyz",
                SupporterName = "Name",
                MobilePhones = new String[] { "986545654" },
                Emails = new String[] { "xyz@gmail.com" },
                Number = 10,
                TableNumber = 30
            };

            bidderInput = new BidderInput
            {
                Authentication = auth,
                BidderFieldValue = bidder_field_values,
                RecordType = "bidder"
            };

            var bidderjson = JsonConvert.SerializeObject(bidderInput);

            bidderJobject = JObject.Parse(bidderjson);

            #endregion Bidder Input Model

            #region Sponsor Input Model

            sponsor_field_values = new SponsorFieldValues
            {
                SponsorXid = 10,
                ProjectXid = 20,
                Images = new byte[2]
            };

            sponsorInput = new SponsorInput
            {
                Authentication = auth,
                SponsorFieldValue = sponsor_field_values,
                RecordType = "sponsors"
            };

            var sponsorJson = JsonConvert.SerializeObject(sponsorInput);

            sponsorJobject = JObject.Parse(sponsorJson);

            #endregion Sponsor Input Model
        }

        #endregion class initialize       

        #region ProcessMobileBiddingData

        [TestMethod]
        public void TestProcessMobileBiddingData_Package_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProcessBiddingDataController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockAuthentication.Setup(i => i.ValidateUser(It.IsAny<AuthenticationInput>())).Returns(true);

            mockBiddingDomain.Setup(i => i.ValidateProject(auth.ProjectID)).Returns(true);

            mockBiddingDomain.Setup(i => i.ProcessMobileBiddingData(packageJobject)).Returns(_expectedOutputSuccess);          

            //act
            var actionResult = controller.ProcessMobileBiddingData(packageJobject) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestProcessMobileBiddingData_Bidder_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProcessBiddingDataController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockAuthentication.Setup(i => i.ValidateUser(It.IsAny<AuthenticationInput>())).Returns(true);

            mockBiddingDomain.Setup(i => i.ValidateProject(auth.ProjectID)).Returns(true);

            mockBiddingDomain.Setup(i => i.ProcessMobileBiddingData(bidderJobject)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.ProcessMobileBiddingData(bidderJobject) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestProcessMobileBiddingData_Sponsor_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProcessBiddingDataController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockAuthentication.Setup(i => i.ValidateUser(It.IsAny<AuthenticationInput>())).Returns(true);

            mockBiddingDomain.Setup(i => i.ValidateProject(auth.ProjectID)).Returns(true);

            mockBiddingDomain.Setup(i => i.ProcessMobileBiddingData(sponsorJobject)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.ProcessMobileBiddingData(sponsorJobject) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }

        #endregion UpdateProject
    }
}
