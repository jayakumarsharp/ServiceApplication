﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.BiddingService;
using GreaterGiving.Tokyo.BiddingService.Controllers;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.UnitTests.DataAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Web.Http.Results;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.Services
{
    [TestClass]
    public class PackageControllerTest
    {
        #region Private Members

        private static string prefix;
        private static int pageno;
        private static int size;
        private static string packageFilterType;
        private static int packageXid;
        private static string displayedPackages;
        private static string PackageName;
        private static string PackageFilterName;
        private static string CategoryName;
        private static string bidderKey;
        private static PackageOutput _expectedPackageOutput;
        private static List<PackageOutput> _expectedPackageOutputList;
        private static AuthenticationInput auth;
        private static CommonFactory commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private static BulkPackageInput bulkPackageInput;
        private static BulkPackageFieldValues field_values;
        private static List<BulkPackageFields> listFields;
        private static BulkPackageFields fields;
        private static ResultModel createProject;
        private static Class createClass;
        private static BidderFieldValues createBidder;
        private static ProjectFieldValues projectFieldValues;
        
        private static ResultModel expectedOutputSuccess= MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
        private static ResultModel expectedOutputFail = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
        private static ResultModel  expectedOutputNotFound= MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info003);

        private static LeaderBoardInput leaderBoardInput;
        private static CountdownBoardOutput countdownBoardOutput;
        private static JObject packageJobject;

        #endregion Private Members

        #region Class Initialization

        public PackageControllerTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            projectFieldValues = commonFactory.CreateProjectFieldValues();
            createProject = commonFactory.CreateProject(projectFieldValues);
            createClass = commonFactory.CreateClass(projectFieldValues.ProjectXid);
            createBidder = commonFactory.CreateBidderFieldValues();
        }

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            prefix = "test";
            pageno = 1;
            size = 50;
            packageXid = 1;
            displayedPackages = "2,3";
            PackageName = "testName";
            PackageFilterName = "No Bids";
            CategoryName = createClass.ClassName;
            bidderKey = createBidder.OnlineBidderKey;
            packageFilterType = "All";
            _expectedPackageOutput = new PackageOutput { PackageXid = 1, Name = "Test" };
            _expectedPackageOutputList = new List<PackageOutput>();
            _expectedPackageOutputList.Add(_expectedPackageOutput);

            #region bulkupdate 
            //Input model

            #region Input Model

            auth = new AuthenticationInput
            {
                UserName = "biddingtokyouser",
                Password = "biddingtokyo123",
                ProjectID = 9254
            };

            fields = new BulkPackageFields
            {
                PackageXid = 655423,
                StartTimeUTC = DateTime.UtcNow,
                EndTimeUTC = DateTime.UtcNow,
                MobileBiddingType = "live"
            };

            listFields = new List<BulkPackageFields>() { fields };

            field_values = new BulkPackageFieldValues
            {
                ProjectXid = 9254,
                BulkPackageFields = listFields
            };

            bulkPackageInput = new BulkPackageInput
            {
                Authentication = auth,
                BulkPackageFieldValue = field_values,
                RecordType = "items"
            };

            int[] displayedPackagesArray = new int[] { 5, 6, 7 }; 
            leaderBoardInput = new LeaderBoardInput
            {
                PackageFilterType = DisplayLookupConstants.DisplayLeaderBoardPackageFilter_Open,
                CategoryFilterType = DisplayLookupConstants.DisplayCategoryFilter_All,
                DisplayCount = 2,
                DisplayedPackages = displayedPackagesArray,
                PackageSort = DisplayLookupConstants.DisplayPackageSortType_ClosingTime
            };
            var packagejson = JsonConvert.SerializeObject(leaderBoardInput);

            packageJobject = JObject.Parse(packagejson);

            countdownBoardOutput = new CountdownBoardOutput
            {
                PackageXid = packageXid,
                CountdownTime = Convert.ToString(DateTime.UtcNow.AddDays(-1))
            };
            #endregion Input Model

            #endregion bulkupdate 
        }

        #endregion Class Initialization

        #region Packages

        [TestMethod]
        public void TestGetAllPackagesSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetAllPackages(prefix)).Returns(_expectedPackageOutputList);

            //act
            var actionResult = controller.GetAllPackages(prefix) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }

        [TestMethod]
        public void TestGetPackagesSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetPackages(prefix, pageno, size, packageFilterType)).Returns(_expectedPackageOutputList);

            //act
            var actionResult = controller.GetPackages(prefix, pageno, size, packageFilterType) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }

        [TestMethod]
        public void TestGetRelatedPackagesSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetRelatedPackages(prefix, packageXid, displayedPackages)).Returns(_expectedPackageOutputList);

            //act
            var actionResult = controller.GetRelatedPackages(prefix, packageXid, displayedPackages) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }

        [TestMethod]
        public void TestGetAppealDonationPackagesSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetAppealDonationPackage(prefix)).Returns(_expectedPackageOutput);

            //act
            var actionResult = controller.GetAppealDonationPackage(prefix) as NegotiatedContentResult<PackageOutput>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content);
        }

        [TestMethod]
        public void TestBulkUpdateSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.UpdateTimeAndItemTypeForPackages(bulkPackageInput.BulkPackageFieldValue)).Returns(expectedOutputSuccess);
            mockBiddingDomain.Setup(i => i.ValidateProject(bulkPackageInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.UpdateTimeAndItemTypeForPackages(bulkPackageInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestBulkUpdateFailToUpdateRecords()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.UpdateTimeAndItemTypeForPackages(bulkPackageInput.BulkPackageFieldValue)).Returns(expectedOutputFail);
            mockBiddingDomain.Setup(i => i.ValidateProject(bulkPackageInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.UpdateTimeAndItemTypeForPackages(bulkPackageInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(expectedOutputFail.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestBulkUpdateFailToUpdateNoRecordsUpdated()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.UpdateTimeAndItemTypeForPackages(bulkPackageInput.BulkPackageFieldValue)).Returns(expectedOutputFail);
            mockBiddingDomain.Setup(i => i.ValidateProject(bulkPackageInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.UpdateTimeAndItemTypeForPackages(bulkPackageInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(expectedOutputFail.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(expectedOutputFail.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestSearchPackagesByPackageNameOrNumberSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SearchPackagesByPackageNameOrNumber(prefix, pageno, size, PackageName)).Returns(_expectedPackageOutputList);

            //act
            var actionResult = controller.SearchPackagesByPackageNameOrNumber(prefix, pageno, size, PackageName) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }

        [TestMethod]
        public void TestGetPackageTypesByProjectSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetPackageTypesByProject(prefix)).Returns(new List<string>());

            //act
            var actionResult = controller.GetPackageTypesByProject(prefix) as NegotiatedContentResult<List<string>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }

        [TestMethod]
        public void TestGetCategoryTypesByProjectSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetCategoryTypesByProject(prefix)).Returns(new List<string>());

            //act
            var actionResult = controller.GetCategoryTypesByProject(prefix) as NegotiatedContentResult<List<string>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }

        [TestMethod]
        public void TestGetFilteredPackagesByProjectSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetFilteredPackagesByProject(prefix, PackageFilterName)).Returns(new List<PackageOutput>());

            //act
            var actionResult = controller.GetFilteredPackagesByProject(prefix, PackageFilterName) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }

        [TestMethod]
        public void TestGetPackagesByCategorySuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetFilteredPackagesByProject(prefix, CategoryName)).Returns(new List<PackageOutput>());

            //act
            var actionResult = controller.GetFilteredPackagesByProject(prefix, CategoryName) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }      

        [TestMethod]
        public void TestGetFurthestPackageClosingTimeByProjectSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetFurthestPackageClosingTimeByProject(prefix)).Returns(countdownBoardOutput);

            //act
            var actionResult = controller.GetFurthestPackageClosingTimeByProject(prefix) as NegotiatedContentResult<CountdownBoardOutput>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.PackageXid);
            Assert.IsTrue(actionResult.Content.PackageXid == countdownBoardOutput.PackageXid);
        }

        [TestMethod]
        public void TestGetFurthestPackageClosingTimeByProjectFail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var output = new CountdownBoardOutput();
            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetFurthestPackageClosingTimeByProject(prefix)).Returns(output);

            //act
            var actionResult = controller.GetFurthestPackageClosingTimeByProject(prefix) as NegotiatedContentResult<CountdownBoardOutput>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.PackageXid);
            Assert.AreSame(actionResult.Content.CountdownTime, output.CountdownTime);
        }

        [TestMethod]
        public void TestGetLeaderBoardPackagesSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new PackageController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetLeaderBoardPackages(prefix, packageJobject)).Returns(new List<PackageOutput>());

            //act
            var actionResult = controller.GetLeaderBoardPackages(prefix, packageJobject) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.Count > 0);
        }
        #endregion Packages
    }
}
