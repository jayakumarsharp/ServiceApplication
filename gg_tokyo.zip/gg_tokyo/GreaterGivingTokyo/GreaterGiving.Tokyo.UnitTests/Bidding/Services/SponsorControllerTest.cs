﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.BiddingService;
using GreaterGiving.Tokyo.BiddingService.Controllers;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.UnitTests.DataAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Web.Http.Results;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.Services
{
    /// <summary>
    /// Summary description for BidderControllerTest
    /// </summary>
    [TestClass]
    public class SponsorControllerTest
    {
        private static AuthenticationInput auth;
        private static CommonFactory commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private static ProjectFieldValues createProject;
        private static List<SponsorOutput> _expectedOutputSuccess;
        
        public SponsorControllerTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            createProject = commonFactory.CreateProjectFieldValues();
        }


        [ClassInitialize()]
        public static void InitializeClass(TestContext testContext)
        {
            #region Input Model

            auth = new AuthenticationInput
            {
                UserName = "biddingtokyouser",
                Password = "biddingtokyo123",
                ProjectID = 5624
            };
            
            #endregion Input Model

            #region Output Model

            _expectedOutputSuccess = new List<SponsorOutput> { new SponsorOutput { ProjectXid = 5624,  SponsorXid = 1 } };

            #endregion Output Model
        }

        [TestMethod]
        public void TestGetSponsorImagesByPrefix()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new SponsorController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetSponsorImagesByPrefix(createProject.Prefix)).Returns(_expectedOutputSuccess);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);
            //act
            var actionResult = controller.GetSponsorImagesByPrefix(createProject.Prefix) as NegotiatedContentResult<List<SponsorOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Count, actionResult.Content.Count);
        }
    }
}
