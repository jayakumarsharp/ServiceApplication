﻿using System;
using System.Collections.Generic;
using System.Web.Http.Results;
using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.BiddingService;
using GreaterGiving.Tokyo.BiddingService.Controllers.Admin;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.UnitTests.DataAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.Services
{
    /// <summary>
    /// Summary description for AdminControllerTest
    /// </summary>
    [TestClass]
    public class AdminControllerTest
    {
        private static CommonFactory commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private static ProjectFieldValues createProject;
        private static BidderFieldValues createBidder;
        private static PackageFieldValues createPackage;
        private static List<BidderOutput> _expectedBidderOutputSuccess;
        private static List<PackageOutput> _expectedPackageOutputSuccess;
        private static List<PackageSearchOutput> _expectedPackageSearchOutputSuccess;
        private static PackageSearchInput packageSearchInput;
        private static PackageSearchOutput packageSearchOutput;
        private static int Count = 1;
        private static BidderSearchInput bidderSearchInput;
        private static List<BidderSearchOutput> _expectedBidderSearchOutputSuccess;
        private static BidderSearchOutput _expectedBidderSearchOutput;
        private static List<MaxBidOutput> _expectedMaxBidOutputSuccess;
        private static List<BidHistoryOutput> _expectedBidHistoryOutputSuccess;
        private static PackageSearchOutput _expectedPackageSearchOutput;
        private static MaxBidOutput _expectedPackageMaxBidOutputSuccess;
        private static ResultMessage _expectedOutputSuccess = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_Success };
        private static ResultMessage _expectedOutputFail = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_Failure };
        private static EmailMessageFieldValues _emailMessageFieldValues;
        private static List<EmailTemplateOutput> _emailTemplateOutput;
        private static TextMessageFieldValues _smsMessageFieldValues;
        private static List<SMSTemplateOutput> _smsTemplateOutput;
        private static List<ExportBidHistoryOutput> _expectedExportBidHistoryOutputSuccess;

        private static int bidderId = 10;
        private static int packageId = 10;
        private static int bidId = 10;
        private static int saleId = 10;
        private static int emailTemplateId = 1;
        private static string recipientType = "All";
        private static int smsTemplateId = 1;

        public AdminControllerTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            createProject = commonFactory.CreateProjectFieldValues();
            packageSearchInput = commonFactory.CreatePackageSearchInput();
            packageSearchOutput = commonFactory.CreatePackageSearchOutput();
            createBidder = commonFactory.CreateBidderFieldValues();
            createPackage = commonFactory.CreatePackageFieldValues();
        }

        [ClassInitialize()]
        public static void InitializeClass(TestContext testContext)
        {
            _expectedBidderOutputSuccess = new List<BidderOutput> { new BidderOutput { SupporterName = "Test Bidder 1", Number = 001, Amount = 10 } };
            _expectedPackageOutputSuccess = new List<PackageOutput> { new PackageOutput { Name = "Test Package", Number = "10", CurrentHighBidAmount = 1000 } };
            bidderSearchInput = new BidderSearchInput { BidderName = "Bidder1", BidderNumber = 10 };
            _expectedBidderSearchOutputSuccess = new List<BidderSearchOutput> { new BidderSearchOutput { SupporterName = "Bidder Name", BidderXid = 10 } };
            _expectedPackageSearchOutputSuccess = new List<PackageSearchOutput> { packageSearchOutput };
            _expectedBidderSearchOutput = new BidderSearchOutput { SupporterName = "Bidder Name", BidderXid = 10, Bids = 7 };
            _expectedPackageSearchOutput = new PackageSearchOutput { Name = "Package Name", PackageXid = 10, Bid = -1 };        /* -1 indicates Not applicable */
            _expectedMaxBidOutputSuccess = new List<MaxBidOutput> { new MaxBidOutput { BidderId = 10, CreatedDate = DateTime.Now.AddDays(-1), MaxBidAmount = 300, Name = "Test Package", Number = "12", PackageXid = 123 } };
            _expectedPackageMaxBidOutputSuccess = new MaxBidOutput { BidderId = 10, CreatedDate = DateTime.Now.AddDays(-1), MaxBidAmount = 300, Name = "Test Package", Number = "12", PackageXid = 123 };
            _expectedBidHistoryOutputSuccess = new List<BidHistoryOutput> { new BidHistoryOutput { BidderXid = 10, Amount = 10, BidXid = 12, CreatedDate = DateTime.Now.AddDays(-1), IsDeleted = false, Name = "Test Package", Number = "12", PackageXid = 123, ProjectXid = 1233 } };
            _emailMessageFieldValues = new EmailMessageFieldValues { Subject = "Registration Open" , Message = "Test Message" };
            _emailTemplateOutput = new List<EmailTemplateOutput> { new EmailTemplateOutput { EmailTemplateID = 1, ProjectXid = createProject.ProjectXid, Subject = "Registration Open", Message = "Test Message", CreatedDate = DateTime.Now } };
            _smsMessageFieldValues = new TextMessageFieldValues { Message = "Test Message" };
            _smsTemplateOutput = new List<SMSTemplateOutput> { new SMSTemplateOutput { SMSTemplateID = 1, ProjectXid = createProject.ProjectXid, Message = "Test Message", CreatedDate = DateTime.Now } };
            _expectedExportBidHistoryOutputSuccess = new List<ExportBidHistoryOutput> { new ExportBidHistoryOutput { Amount=100, BidderName = createBidder.SupporterName, BidderXid=createBidder.BidderXid, BidderNumber = createBidder.Number.ToString(), Emails=createBidder.Emails.ToString(), MobilePhones=createBidder.MobilePhones.ToString(),BidXid=10,CreatedDate=DateTime.Now,IsDeleted=false,Value="10",PackageName=createPackage.Name,PackageNumber=createPackage.Number} };
        }

        [TestMethod]
        public void TestGetTopBiddersForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetTopBiddersForAdmin(createProject.Prefix, Count)).Returns(_expectedBidderOutputSuccess);

            //act
            var actionResult = controller.GetTopBiddersForAdmin(createProject.Prefix, Count) as NegotiatedContentResult<List<BidderOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedBidderOutputSuccess.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestGetAllBiddersForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetAllBiddersForAdmin(createProject.Prefix, bidderSearchInput)).Returns(_expectedBidderSearchOutputSuccess);

            //act
            var actionResult = controller.GetAllBiddersForAdmin(createProject.Prefix, bidderSearchInput) as NegotiatedContentResult<List<BidderSearchOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedBidderSearchOutputSuccess.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestGetTopPackagesForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetTopPackagesForAdmin(createProject.Prefix, Count)).Returns(_expectedPackageOutputSuccess);

            //act
            var actionResult = controller.GetTopPackagesForAdmin(createProject.Prefix, Count) as NegotiatedContentResult<List<PackageOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedBidderOutputSuccess.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestGetAllPackagesForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetAllPackagesForAdmin(createProject.Prefix, packageSearchInput)).Returns(_expectedPackageSearchOutputSuccess);

            //act
            var actionResult = controller.GetAllPackagesForAdmin(createProject.Prefix, packageSearchInput) as NegotiatedContentResult<List<PackageSearchOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedPackageSearchOutputSuccess.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestGetBidderDetailsForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetBidderDetailsForAdmin(createProject.Prefix, bidderId)).Returns(_expectedBidderSearchOutput);

            //act
            var actionResult = controller.GetBidderDetailsForAdmin(createProject.Prefix, bidderId) as NegotiatedContentResult<BidderSearchOutput>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedBidderSearchOutput.Bids, actionResult.Content.Bids);
        }

        [TestMethod]
        public void TestGetBidderMaxBidForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetBidderMaxBidForAdmin(createProject.Prefix, bidderId)).Returns(_expectedMaxBidOutputSuccess);

            //act
            var actionResult = controller.GetBidderMaxBidForAdmin(createProject.Prefix, bidderId) as NegotiatedContentResult<List<MaxBidOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedMaxBidOutputSuccess.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestGetBidderBidHistoryForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetBidderBidHistoryForAdmin(createProject.Prefix, bidderId)).Returns(_expectedBidHistoryOutputSuccess);

            //act
            var actionResult = controller.GetBidderBidHistoryForAdmin(createProject.Prefix, bidderId) as NegotiatedContentResult<List<BidHistoryOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedBidHistoryOutputSuccess.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestGetPackageDetailsForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetPackageDetailsForAdmin(createProject.Prefix, packageId)).Returns(_expectedPackageSearchOutput);

            //act
            var actionResult = controller.GetPackageDetailsForAdmin(createProject.Prefix, packageId) as NegotiatedContentResult<PackageSearchOutput>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedPackageSearchOutput.Bid, actionResult.Content.Bid);
        }

        [TestMethod]
        public void TestGetPackageMaxBidForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetPackageMaxBidForAdmin(createProject.Prefix, packageId)).Returns(_expectedPackageMaxBidOutputSuccess);

            //act
            var actionResult = controller.GetPackageMaxBidForAdmin(createProject.Prefix, packageId) as NegotiatedContentResult<MaxBidOutput>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedPackageMaxBidOutputSuccess.MaxBidAmount, actionResult.Content.MaxBidAmount);
        }

        [TestMethod]
        public void TestGetPackageBidHistoryForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetPackageBidHistoryForAdmin(createProject.Prefix, packageId)).Returns(_expectedBidHistoryOutputSuccess);

            //act
            var actionResult = controller.GetPackageBidHistoryForAdmin(createProject.Prefix, packageId) as NegotiatedContentResult<List<BidHistoryOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedBidHistoryOutputSuccess.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestClearMaxBidForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.ClearMaxBidForAdmin(createProject.Prefix, packageId)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.ClearMaxBidForAdmin(createProject.Prefix, packageId) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestRemoveBidForAdminSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.RemoveBidForAdmin(createProject.Prefix, bidId, saleId)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.RemoveBidForAdmin(createProject.Prefix, bidId, saleId) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult.Content.Message);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestRemoveBidForAdminFailure()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.RemoveBidForAdmin(createProject.Prefix, bidId, saleId)).Returns(_expectedOutputFail);

            //act
            var actionResult = controller.RemoveBidForAdmin(createProject.Prefix, bidId, saleId) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult.Content.Message);
            Assert.AreEqual(_expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSaveEmailTemplateForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SaveEmailTemplateForAdmin(createProject.Prefix, _emailMessageFieldValues)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.SaveEmailTemplateForAdmin(createProject.Prefix, _emailMessageFieldValues) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestGetEmailTemplatesForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetEmailTemplatesForAdmin(createProject.Prefix)).Returns(_emailTemplateOutput);

            //act
            var actionResult = controller.GetEmailTemplatesForAdmin(createProject.Prefix) as NegotiatedContentResult<List<EmailTemplateOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_emailTemplateOutput.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestDeleteEmailTemplateForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.DeleteEmailTemplateForAdmin(createProject.ProjectXid , emailTemplateId)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.DeleteEmailTemplateForAdmin(createProject.Prefix, createProject.ProjectXid , emailTemplateId) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSendPreviewEmailForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendPreviewEmailForAdmin(createProject.Prefix, _emailMessageFieldValues)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.SendPreviewEmailForAdmin(createProject.Prefix, _emailMessageFieldValues) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSendRegistrationEmailForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendRegistrationEmailForAdmin(createProject.Prefix, recipientType, _emailMessageFieldValues)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.SendRegistrationEmailForAdmin(createProject.Prefix, recipientType, _emailMessageFieldValues) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestGetSMSTemplatesForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetSMSTemplatesForAdmin(createProject.Prefix)).Returns(_smsTemplateOutput);

            //act
            var actionResult = controller.GetSMSTemplatesForAdmin(createProject.Prefix) as NegotiatedContentResult<List<SMSTemplateOutput>>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_smsTemplateOutput.Count, actionResult.Content.Count);
        }

        [TestMethod]
        public void TestSaveSMSTemplateForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SaveSMSTemplateForAdmin(createProject.Prefix, _smsMessageFieldValues)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.SaveSMSTemplateForAdmin(createProject.Prefix, _smsMessageFieldValues) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestDeleteSMSTemplateForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.DeleteSMSTemplateForAdmin(createProject.ProjectXid, smsTemplateId)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.DeleteSMSTemplateForAdmin(createProject.Prefix, createProject.ProjectXid, smsTemplateId) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSendPreviewSMSForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendPreviewSMSForAdmin(createProject.Prefix, _smsMessageFieldValues)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.SendPreviewSMSForAdmin(createProject.Prefix, _smsMessageFieldValues) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestSendRegistrationSMSForAdmin()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendRegistrationSMSForAdmin(createProject.Prefix, recipientType, _smsMessageFieldValues)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.SendRegistrationSMSForAdmin(createProject.Prefix, recipientType, _smsMessageFieldValues) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestRemoveAllBidsForAdminSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.RemoveAllBidsForAdmin(createProject.Prefix)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.RemoveAllBidsForAdmin(createProject.Prefix) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult.Content.Message);
            Assert.AreEqual(_expectedOutputSuccess.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestRemoveAllBidsForAdminFailure()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.RemoveAllBidsForAdmin(createProject.Prefix)).Returns(_expectedOutputFail);

            //act
            var actionResult = controller.RemoveAllBidsForAdmin(createProject.Prefix) as NegotiatedContentResult<ResultMessage>;

            //assert
            Assert.IsNotNull(actionResult.Content.Message);
            Assert.AreEqual(_expectedOutputFail.Message, actionResult.Content.Message);
        }

        [TestMethod]
        public void TestGetExportAllBiddingHistoryForAdminSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new AdminController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.ExportAllBiddingHistoryForAdmin(createProject.Prefix)).Returns(_expectedExportBidHistoryOutputSuccess);

            //act
            var actionResult = controller.ExportAllBiddingHistoryForAdmin(createProject.Prefix) as NegotiatedContentResult<List<ExportBidHistoryOutput>>;

            //assert
            Assert.IsNotNull(actionResult.Content.Count);
            Assert.AreEqual(_expectedExportBidHistoryOutputSuccess.Count, actionResult.Content.Count);
        }
    }
}
