﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.BiddingService;
using GreaterGiving.Tokyo.BiddingService.Controllers;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Web.Http.Results;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.Services
{
    [TestClass]
    public class ProjectControllerTest
    {
        #region private members

        private static AuthenticationInput auth;
        private static ProjectShortNameModel projectShortName;
        private static ProjectShortNameModel projectShortName1;
        private static ProjectShortNameModel projectShortName2;
        private static ShortNameFieldValue _shortNameInput;
        private static ShortNameFieldValue _shortNameInput1;
        private static ShortNameFieldValue _shortNameInput2;
        private static ProjectInput projectInput;
        private static ProjectFieldValues field_values;
        private static TextMessageInput textInput;
        private static TextMessageFieldValues text_field_values;
        private static EmailMessageInput emailInput;
        private static EmailMessageFieldValues email_field_values;
        private static ProjectOutput _expectedProjectOutput;
        private static ResultModel _expectedOutputSuccess= MessageManager.GetResultMessage(MessageCode.Success, MessageCode.None);
        private static ResultModel _expectedOutputFail= MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
        private static ResultModel _expectedOutputFail1 = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Info001);
        private static ResultModel _expectedOutputInUse = MessageManager.GetResultMessage(MessageCode.InUse, MessageCode.None);
        private static ResultModel _expectedOutputSuccessSMSOrEmail = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success005);
        private static ResultModel _expectedOutputFailSMSOrEmail = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Error006);
        private static ResultModel _expectedOutputAlreadyExist_Fail = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Info001);
        #endregion private members

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            //Input model
            auth = new AuthenticationInput
            {
                UserName = "biddingtokyouser",
                Password = "biddingtokyo123",
                ProjectID = 9254
            };

            #region ShortNameAvailable
            _shortNameInput = new ShortNameFieldValue
            {
                ShortName = "test"
            };

            _shortNameInput1 = new ShortNameFieldValue
            {
                ShortName = "testing12"
            };

            _shortNameInput2 = new ShortNameFieldValue
            {
                ShortName = "OBAPI Updae"
            };

            projectShortName = new ProjectShortNameModel
            {
                Authentication = auth,
                ShortNameFieldValue = _shortNameInput
            };

            projectShortName1 = new ProjectShortNameModel
            {
                Authentication = auth,
                ShortNameFieldValue = _shortNameInput1
            };

            projectShortName2 = new ProjectShortNameModel
            {
                Authentication = auth,
                ShortNameFieldValue = _shortNameInput2
            };

            #endregion ShortNameAvailable

            #region create/update 
            field_values = new ProjectFieldValues
            {
                ProjectXid = 9254,
                Prefix = "OBAPI tr",
                ProjectDisplayName = "DK OB API",
                TimeZoneId = "America/Los_Angeles",
                ProjectImage = System.Text.Encoding.UTF8.GetBytes("xkjazasd-UjsyUYVLlslsodlif"),
                DisplayBiddersOnAppealBoard = false,
                SendSmsOutbidNotices = true,
                SendEmailOutbidNotices = false,
                ShowFmv = true,
                AppealOnlyEvent = false,
                WinningBidderDetail = "bidder_name",
                ShowHistoryOnRegularPackages = true,
                ShowHistoryOnMultisalePackages = true,
                ShowDonors = true,
                BrowsePageSortOrder = "number",
                AppealGoal = 0,
                LegalTerms = "",
                LeaderboardNumberOfPackages = 10,
                DonationPackageXid = 0,
                DonationLabel = null,
                AppealImage = null,
                LeaderBoardTheme = "blue",
                LeaderboardScreenDisplaySeconds = 10,
                RevenueGoal = 0,
                AllowMaxBidding = true,
                LeaderboardStyle = "allitems_closing",
                SuggestedDonationAmounts = null,
                ProjectKey = "xxxx-dzUvQdammmA",
                Password = "[passwordGoesHere]"
            };

            projectInput = new ProjectInput
            {
                Authentication = auth,
                ProjectFieldValue = field_values,
                RecordType = "users"
            };

            #endregion create/update 

            #region Send SMS
            text_field_values = new TextMessageFieldValues
            {
                ProjectXid = 1001,
                Message = "Test Message from the OBAPI",
                Phone = "986545654"
            };

            textInput = new TextMessageInput
            {
                Authentication = auth,
                RecordType = "users",
                TextMessageFieldValue = text_field_values
            };
            #endregion Send SMS

            #region Send Email

            email_field_values = new EmailMessageFieldValues
            {
                FromEmailAddress = "",
                FromName = "Test",
                Message = "Test Welcome Message",
                Subject = "Welcome Online Bidding",
                ToEmailAddress = "test@test.com"
            };

            emailInput = new EmailMessageInput
            {
                Authentication = auth,
                EmailMessageFieldValue = email_field_values,
                RecordType = null
            };
            #endregion Send Email

            //Output model

            _expectedProjectOutput = new ProjectOutput { ProjectDisplayName = "OBAPI", TimeZoneId = "America/New York" };

             }

        #region Get Project

        [TestMethod]
        public void TestGetProjectSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.GetProject(_shortNameInput.ShortName)).Returns(_expectedProjectOutput);

            //act
            var actionResult = controller.GetProject(_shortNameInput.ShortName) as NegotiatedContentResult<ProjectOutput>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(actionResult.Content.ProjectXid);
        }

        #endregion Get Project

        #region IsShortNameAvailable 

        [TestMethod]
        public void TestIsShortNameAvailableSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();           

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);
        
            mockBiddingDomain.Setup(i => i.IsShortNameAvailable(_shortNameInput.ShortName)).Returns(_expectedOutputSuccess);

            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.IsShortNameAvailable(projectShortName) as FormattedContentResult<ResultModel>; 

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestIsShortNameAvailableFail()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.IsShortNameAvailable(_shortNameInput1.ShortName)).Returns(_expectedOutputFail);

            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.IsShortNameAvailable(projectShortName1) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputFail.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputFail.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestIsShortNameAvailableInUse()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.IsShortNameAvailable(_shortNameInput2.ShortName)).Returns(_expectedOutputInUse);

            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.IsShortNameAvailable(projectShortName2) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputInUse.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputInUse.Reason, actionResult.Content.Reason);
        }
        #endregion IsShortNameAvailable

        #region CreateProject
            [TestMethod]
            public void TestCreateProjectSuccess()
            {
                //arrange
                var mockBiddingDomain = new Mock<IBiddingDomain>();
                var mockAuthentication = new Mock<IAuthentication>();

                var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

                mockBiddingDomain.Setup(i => i.CreateProject(projectInput.ProjectFieldValue)).Returns(_expectedOutputSuccess);

                mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

                //act
                var actionResult = controller.CreateProject(projectInput) as FormattedContentResult<ResultModel>;

                //assert
                Assert.IsNotNull(actionResult);
                Assert.AreEqual(_expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
                Assert.AreEqual(_expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }

            [TestMethod]
            public void TestCreateProjectFail()
            {
                //arrange
                var mockBiddingDomain = new Mock<IBiddingDomain>();
                var mockAuthentication = new Mock<IAuthentication>();

                var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

                mockBiddingDomain.Setup(i => i.CreateProject(projectInput.ProjectFieldValue)).Returns(_expectedOutputAlreadyExist_Fail);

                mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

                //act
                var actionResult = controller.CreateProject(projectInput) as FormattedContentResult<ResultModel>;

                //assert
                Assert.IsNotNull(actionResult);
                Assert.AreEqual(_expectedOutputAlreadyExist_Fail.ResultCode, actionResult.Content.ResultCode);
                Assert.AreEqual(_expectedOutputAlreadyExist_Fail.Reason, actionResult.Content.Reason);
            }
        #endregion CreateProject

        #region UpdateProject
        [TestMethod]
        public void TestUpdateProjectSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.CreateProject(projectInput.ProjectFieldValue)).Returns(_expectedOutputSuccess);

            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.CreateProject(projectInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }

            [TestMethod]
            public void TestUpdateProjectFail()
            {
                //arrange
                var mockBiddingDomain = new Mock<IBiddingDomain>();
                var mockAuthentication = new Mock<IAuthentication>();

                var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

                mockBiddingDomain.Setup(i => i.CreateProject(projectInput.ProjectFieldValue)).Returns(_expectedOutputFail);

                mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

                //act
                var actionResult = controller.CreateProject(projectInput) as FormattedContentResult<ResultModel>;

                //assert
                Assert.IsNotNull(actionResult);
                Assert.AreEqual(_expectedOutputFail.ResultCode, actionResult.Content.ResultCode);
                Assert.AreEqual(_expectedOutputFail.Reason, actionResult.Content.Reason);
        }
        #endregion UpdateProject

        #region SendSMS - Save SMS
        [TestMethod]
        public void TestSendSMSInsertSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendSMS(textInput.TextMessageFieldValue, It.IsAny<int?>(), It.IsAny<int?>())).Returns(_expectedOutputSuccess);
            mockBiddingDomain.Setup(i => i.ValidateProject(textInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.SendSMS(textInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestSendSMSFailedToInsert()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendSMS(textInput.TextMessageFieldValue, It.IsAny<int?>(), It.IsAny<int?>())).Returns(_expectedOutputFail);
            mockBiddingDomain.Setup(i => i.ValidateProject(textInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.SendSMS(textInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputFail.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputFail.Reason, actionResult.Content.Reason);
        }

        #region SMS Bidding Status Notification
        [TestMethod]
        public void TestSendSMSInsertOutBidStatus_Success()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);
            mockBiddingDomain.Setup(x=>x.SendSMS(textInput.TextMessageFieldValue, It.IsAny<int?>(), It.IsAny<int?>())).Returns(_expectedOutputSuccess);
            mockBiddingDomain.Setup(i => i.ValidateProject(textInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.SendSMS(textInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccess.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputSuccess.Reason, actionResult.Content.Reason);
        }
        [TestMethod]
        public void TestSendSMSFailedToInsert_OutBidStatus()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendSMS(textInput.TextMessageFieldValue, It.IsAny<int?>(), It.IsAny<int?>())).Returns(_expectedOutputFail);
            mockBiddingDomain.Setup(i => i.ValidateProject(textInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.SendSMS(textInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputFail.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputFail.Reason, actionResult.Content.Reason);
        }
        #endregion SMS Bidding Status Notification

        #endregion SendSMS - Save SMS

        #region SendEmail - Save Email Request 
        [TestMethod]
        public void TestSendEmailInsertSuccess()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendEmail(emailInput.EmailMessageFieldValue, emailInput.Authentication.ProjectID, It.IsAny<int?>(), It.IsAny<int?>())).Returns(_expectedOutputSuccessSMSOrEmail);
            mockBiddingDomain.Setup(i => i.ValidateProject(emailInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.SendEmail(emailInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputSuccessSMSOrEmail.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputSuccessSMSOrEmail.Reason, actionResult.Content.Reason);
        }

        [TestMethod]
        public void TestSendEmailFailedToInsert()
        {
            //arrange
            var mockBiddingDomain = new Mock<IBiddingDomain>();
            var mockAuthentication = new Mock<IAuthentication>();

            var controller = new ProjectController(mockBiddingDomain.Object, mockAuthentication.Object);

            mockBiddingDomain.Setup(i => i.SendEmail(emailInput.EmailMessageFieldValue, emailInput.Authentication.ProjectID, It.IsAny<int?>(), It.IsAny<int?>())).Returns(_expectedOutputFailSMSOrEmail);
            mockBiddingDomain.Setup(i => i.ValidateProject(emailInput.Authentication.ProjectID)).Returns(true);
            mockAuthentication.Setup(i => i.ValidateUser(auth)).Returns(true);

            //act
            var actionResult = controller.SendEmail(emailInput) as FormattedContentResult<ResultModel>;

            //assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(_expectedOutputFailSMSOrEmail.ResultCode, actionResult.Content.ResultCode);
            Assert.AreEqual(_expectedOutputFailSMSOrEmail.Reason, actionResult.Content.Reason);
        }

        #endregion SendEmail - Save Email Request 
    }

}
