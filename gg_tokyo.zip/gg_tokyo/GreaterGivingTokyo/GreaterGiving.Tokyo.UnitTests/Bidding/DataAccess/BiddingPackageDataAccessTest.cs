﻿using System;
using System.Collections.Generic;
using GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GreaterGiving.Tokyo.UnitTests.DataAccess
{
    [TestClass]
    public class BiddingPackageDataAccessTest
    {

        #region Private Members
        private static ProjectFieldValues projectFieldValues;
        private static PackageFieldValues packageFieldValues;
        private static BidderFieldValues bidderFieldValues;
        private static Sale saleFieldValues;
        private static BulkPackageFieldValues bulkPackageFieldValues;
        private static BulkPackageFields fields;
        private static int pageno = 1;
        private static int size = 50;
        private static bool isFavorite = false;
        private static int count = 10;
        private static CommonFactory commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private static string displayedPackageList = "1,2";
        private static string activityType = DisplayLookupConstants.DisplayPackageStatusType_All;
        private ResultModel expectedSuccessModel = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
        private ResultModel expectedFailModel = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
        private ResultModel expectedNoRecordsDeletedModel = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);
        private ResultModel expectedOutputBulkNoRecordUpdated = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error008);
        private static decimal amount = 0;
        private static decimal bidAmount = 0;
        private static string bidType;
        private static int quantity = 1;
        private static int secondBidderXid = 16;
        private static string secondOnlineBidderKey = "26329";
        private ResultMessage expectedSuccessResultMessage = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_Success };
        private ResultMessage expectedOutBidResultMessage = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_OutBided };
        private LeaderBoardInput leaderBoardInput;
        

        public BiddingPackageDataAccessTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            projectFieldValues = commonFactory.CreateProjectFieldValues();
            packageFieldValues = commonFactory.CreatePackageFieldValues();
            bulkPackageFieldValues = commonFactory.CreateBulkPackageFieldValues();
            fields = commonFactory.CreateBulkPackageField();
            bidderFieldValues = commonFactory.CreateBidderFieldValues();
            saleFieldValues = commonFactory.CreateSale();
            commonFactory.InsertCodeLookupFieldvalues();
            leaderBoardInput = commonFactory.CreateLeaderBoardInputFieldValues();
        }
        #endregion Private Members

        #region CRUD

        private List<PackageOutput> GetAllPackagesList(string prefix)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.GetAllPackages(prefix);
            return packageList;
        }

        private List<PackageOutput> GetRelatedPackagesList(string prefix, int packageXid, string displayedPackages)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.GetRelatedPackages(prefix, packageXid, displayedPackages);
            return packageList;
        }

        private PackageOutput GetAppealDonationPackage(string prefix)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var package = _biddingData.GetAppealDonationPackage(prefix);
            return package;
        }

        private PackageOutput GetPackageByPackageId(string prefix, int packageXid)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var package = _biddingData.GetPackagebyPackageId(prefix, packageXid);
            return package;
        }

        private List<PackageOutput> SearchPackagesByPackageNameOrNumber(string prefix, int pageno, int size, string packageNameOrNumber)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.SearchPackagesByPackageNameOrNumber(prefix, pageno, size, packageNameOrNumber);
            return packageList;
        }

        private List<string> GetCategoryTypesByProject(string prefix)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.GetCategoryTypesByProject(prefix);
            return packageList;
        }

        private List<string> GetPackageTypesByProject(string prefix)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.GetPackageTypesByProject(prefix);
            return packageList;
        }

        private List<PackageOutput> NoBidPackagesFilter(Project project)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.NoBidPackagesFilter(project);
            return packageList;
        }

        private List<PackageOutput> CurrentlyOpenPackagesFilter(Project project)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.CurrentlyOpenPackagesFilter(project);
            return packageList;
        }

        private List<PackageOutput> BuyNowPackagesFilter(Project project)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.BuyNowPackagesFilter(project);
            return packageList;
        }

        private List<PackageOutput> MultiSalePackagesFilter(Project project)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.MultiSalePackagesFilter(project);
            return packageList;
        }

        private List<PackageOutput> PreviewOnlyPackagesFilter(Project project)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.PreviewOnlyPackagesFilter(project);
            return packageList;
        }

        private List<PackageOutput> OpeningSoonPackagesFilter(Project project)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.OpeningSoonPackagesFilter(project);
            return packageList;
        }

        private List<PackageOutput> GetPackagesByCategory(string prefix, int pageno, int size, string categoryName)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            var packageList = _biddingData.GetPackagesByCategory(prefix, pageno, size, categoryName);
            return packageList;
        }

        private void AddOrRemoveFavorite(string prefix, int packageId, bool isFavorite)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            _biddingData.AddOrRemoveFavorite(prefix, packageId, isFavorite);
        }

        private List<PackageOutput> GetFavoritePackagesByBidder(string prefix, int pageno, int size)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            var packageList = _biddingData.GetFavoritePackagesByBidder(prefix, pageno, size);
            return packageList;
        }

        private List<PackageOutput> GetBidActivityFilterByBidder(string prefix, string activityType, int pageno, int size)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            var packageList = _biddingData.GetBidActivityByBidder(prefix, activityType, pageno, size);
            return packageList;
        }

        private Sale BuyRegularPackage(string prefix, int packageId)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            var resultMessage = _biddingData.BuyRegularPackage(prefix, packageId);
            return resultMessage;
        }

        private Sale BuyMultiSalePackages(string prefix, int packageId, int quantity)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            var resultMessage = _biddingData.BuyMultiSalePackages(prefix, packageId, quantity);
            return resultMessage;
        }
        private Sale BuyDonationPackage(string prefix, int packageId, decimal amount)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            var resultMessage = _biddingData.BuyDonationPackage(prefix, packageId, amount);
            return resultMessage;
        }

        private ResultMessage SetMaxBid(string prefix, int packageXid, decimal amount)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            bidType = CodeLookupConstants.CodeBidderActionType_MaxBid; // sets the bid type
            var resultMessage = _biddingData.SetMaxBid(prefix, packageXid, amount, bidType);
            return resultMessage;
        }

        private CountdownBoardOutput GetFurthestPackageClosingTimeByProject(string prefix)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            var resultMessage = _biddingData.GetFurthestPackageClosingTimeByProject(prefix);
            return resultMessage;
        }

        private List<PackageOutput> GetLeaderBoardPackages(string prefix, LeaderBoardInput input)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            var packages = _biddingData.GetLeaderBoardPackages(prefix, input);
            return packages;
        }
        #endregion CRUD

        #region Package Public Members Functions

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetAllPackages()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            commonFactory.UpdatePackageClass();//do not remove this since this creates reference for class(like entities)


            //act
            var packageList = GetAllPackagesList(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(packageList);
            Assert.IsTrue(packageList.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetRelatedPackages()
        {
            //arrange    
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            packageFieldValues.PackageXid = packageFieldValues.PackageXid + 1;

            var addRelatedPackage = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var relatedPackage = commonFactory.CreateRelatedPackage();
            commonFactory.UpdatePackageClass(); //do not remove this since this creates reference for class(like entities)

            //act
            var packageList = GetRelatedPackagesList(projectFieldValues.Prefix, packageFieldValues.PackageXid, displayedPackageList);

            //assert
            Assert.IsNotNull(packageList);
            Assert.IsTrue(packageList.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetAppealDonationPackages()
        {
            //arrange    
            var project = commonFactory.CreateTestProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            packageFieldValues.PackageXid = packageFieldValues.PackageXid + 1;

            var addRelatedPackage = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            commonFactory.UpdatePackageClass(); //do not remove this since this creates reference for class(like entities)

            //act
            var appealDonationPackage = GetAppealDonationPackage(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(appealDonationPackage);
            Assert.IsTrue(appealDonationPackage.PackageXid == project.DonationPackageXid);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetPackageByPackageId()
        {
            //arrange
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);


            //act
            var getPackage = GetPackageByPackageId(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(getPackage);
            Assert.IsTrue(getPackage.PackageXid == packageFieldValues.PackageXid);
        }


        #endregion Package Public Members Functions

        #region CreateOrUpdate Package

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessCreateOrUpdatePackageSuccess()
        {
            //act
            var project = commonFactory.CreateProject(projectFieldValues);
            commonFactory.CreateOrUpdatePackage(packageFieldValues);//Create package
            packageFieldValues.Price = 150;//for update

            var resultModel = commonFactory.CreateOrUpdatePackage(packageFieldValues);//Update package

            var afterUpdate = GetPackageByPackageId(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.AreEqual(packageFieldValues.Price, afterUpdate.Price);
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        #endregion CreateOrUpdate Package      

        #region Delete Package

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessDeletePackageSuccess()
        {
            //arrange     
            var project = commonFactory.CreateProject(projectFieldValues);
            commonFactory.CreateOrUpdatePackage(packageFieldValues);//Create package

            //act
            ResultModel resultModel = commonFactory.DeletePackage(packageFieldValues.PackageXid);
            var deletedPackage = GetPackageByPackageId(projectFieldValues.Prefix, packageFieldValues.PackageXid);
            //assert
            Assert.AreEqual(deletedPackage.PackageXid, 0);
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessPackageFailToDelete()
        {
            //arrange
            commonFactory.CreateProject(projectFieldValues);
            commonFactory.CreateOrUpdatePackage(packageFieldValues);//Create package

            packageFieldValues.PackageXid = 10000000; //PackageId should not exist

            //act
            ResultModel resultModel = commonFactory.DeletePackage(packageFieldValues.PackageXid);

            //assert            
            Assert.AreEqual(expectedNoRecordsDeletedModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedNoRecordsDeletedModel.Reason, resultModel.Reason);
        }

        #endregion Delete Package

        #region Bulk Update

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessBulkUpdatePackageSuccess()
        {
            //arrange   
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            //act
            ResultModel resultModel = commonFactory.CreateOrUpdateBulkPackage(bulkPackageFieldValues);

            //assert           
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessBulkPackageFailToUpdate()
        {
            //arrange
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            var BulkPackageField = new BulkPackageFields();
            BulkPackageField.PackageXid = 412124545; //Package Id should not exist
            bulkPackageFieldValues.BulkPackageFields = new List<BulkPackageFields> { BulkPackageField };

            //act
            ResultModel resultModel = commonFactory.CreateOrUpdateBulkPackage(bulkPackageFieldValues);

            //assert           
            Assert.AreEqual(expectedOutputBulkNoRecordUpdated.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedOutputBulkNoRecordUpdated.Reason + BulkPackageField.PackageXid, resultModel.Reason);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessBulkPackageFailNoMatchedPackages()
        {
            //arrange
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            var BulkPackageField = new BulkPackageFields();
            BulkPackageField.PackageXid = 412124545; //Package id should not exist
            bulkPackageFieldValues.BulkPackageFields = new List<BulkPackageFields> { BulkPackageField };

            //act
            ResultModel resultModel = commonFactory.CreateOrUpdateBulkPackage(bulkPackageFieldValues);

            // assert
            Assert.AreEqual(expectedOutputBulkNoRecordUpdated.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedOutputBulkNoRecordUpdated.Reason + BulkPackageField.PackageXid, resultModel.Reason);
        }

        #endregion Bulk Update

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessSearchPackagesByPackageNameOrNumber()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            commonFactory.UpdatePackageClass(); //do not remove this since this creates reference for class(like entities)


            //act
            var searchPackageResult = SearchPackagesByPackageNameOrNumber(projectFieldValues.Prefix, pageno, size, packageFieldValues.Name);

            //assert
            Assert.IsNotNull(searchPackageResult);
            Assert.IsTrue(searchPackageResult.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetPackageTypesByProject()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            commonFactory.UpdatePackageClass();//do not remove this since this creates reference for class(like entities)


            //act
            var packageTypes = GetPackageTypesByProject(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(packageTypes);
            Assert.IsTrue(packageTypes.Count > 0);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetCategoryTypesByProject()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            commonFactory.UpdatePackageClass();//do not remove this since this creates reference for class(like entities)

            //act
            var categoryTypes = GetCategoryTypesByProject(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(categoryTypes);
            Assert.IsTrue(categoryTypes.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessNoBidPackagesFilter()
        {
            var project = commonFactory.CreateTestProject(projectFieldValues);
            packageFieldValues.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Regular;
            packageFieldValues.StartTimeUTC = DateTime.UtcNow.AddDays(2);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            commonFactory.UpdatePackageClass(); //do not remove this since this creates reference for class(like entities)

            //act
            var packages = NoBidPackagesFilter(project);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessCurrentlyOpenPackagesFilter()
        {
            var project = commonFactory.CreateTestProject(projectFieldValues);
            packageFieldValues.StartTimeUTC = DateTime.UtcNow.AddDays(-2);
            packageFieldValues.EndTimeUTC = DateTime.UtcNow.AddDays(2);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            commonFactory.UpdatePackageClass();//do not remove this since this creates reference for class(like entities)


            //act
            var packages = CurrentlyOpenPackagesFilter(project);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessBuyNowPackagesFilter()
        {
            var project = commonFactory.CreateTestProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);
            saleFieldValues.BidderXid = bidderFieldValues.BidderXid;
            saleFieldValues.ProjectXid = projectFieldValues.ProjectXid;
            saleFieldValues.PackageXid = packageFieldValues.PackageXid;
            var sale = commonFactory.CreateOrUpdateSale(saleFieldValues);

            commonFactory.UpdatePackageClass();//do not remove this since this creates reference for class(like entities)

            //act
            var packages = BuyNowPackagesFilter(project);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessMultiSalePackagesFilter()
        {
            var project = commonFactory.CreateTestProject(projectFieldValues);
            packageFieldValues.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Givers;
            packageFieldValues.Price = 100;
            packageFieldValues.MaxAvailable = 10;
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            commonFactory.UpdatePackageClass(); //do not remove this since this creates reference for class(like entities)

            //act
            var packages = MultiSalePackagesFilter(project);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessPreviewOnlyPackagesFilter()
        {
            var project = commonFactory.CreateTestProject(projectFieldValues);
            packageFieldValues.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Live;
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            commonFactory.UpdatePackageClass(); //do not remove this since this creates reference for class(like entities)           

            //act
            var packages = PreviewOnlyPackagesFilter(project);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessOpeningSoonPackagesFilter()
        {
            var project = commonFactory.CreateTestProject(projectFieldValues);
            packageFieldValues.StartTimeUTC = DateTime.UtcNow.AddDays(2);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            commonFactory.UpdatePackageClass();//do not remove this since this creates reference for class(like entities)


            //act
            var packages = OpeningSoonPackagesFilter(project);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetPackagesByCategory()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            commonFactory.UpdatePackageClass();//do not remove this since this creates reference for class(like entities)            

            //act
            var packages = GetPackagesByCategory(projectFieldValues.Prefix, pageno, size, packageFieldValues.ClassName);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count == 1);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessAddOrRemoveFavorite()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            isFavorite = true;
            //For add favorite 
            AddOrRemoveFavorite(projectFieldValues.Prefix, packageFieldValues.PackageXid, isFavorite);
            isFavorite = false;
            //For remove favorite 
            AddOrRemoveFavorite(projectFieldValues.Prefix, packageFieldValues.PackageXid, isFavorite);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetFavoritePackagesByBidder()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            isFavorite = true;
            AddOrRemoveFavorite(projectFieldValues.Prefix, packageFieldValues.PackageXid, isFavorite);
            commonFactory.UpdateBidderPackageClass();
            //act
            var packages = GetFavoritePackagesByBidder(projectFieldValues.Prefix, pageno, size);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count > 0);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetBidActivityFilterByBidder()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 10; //setting the Current Bid amount to 10
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            var packages = GetBidActivityFilterByBidder(projectFieldValues.Prefix, activityType, pageno, size);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count > 0);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessAddBidSuccess()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            //act
            var packages = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount, bidType);

            //assert
            Assert.IsNotNull(packages);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessAddBuy()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 10; //setting the Current Bid amount to 10
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            var packages = BuyRegularPackage(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(packages);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessBuyMultiSalePackages()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            packageFieldValues.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Givers;
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 10; //setting the Current Bid amount t0 10
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            var packages = BuyMultiSalePackages(projectFieldValues.Prefix, packageFieldValues.PackageXid, quantity);

            //assert
            Assert.IsNotNull(packages);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessBuyDonationPackage()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            packageFieldValues.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Donation;
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 10; //setting the Current Bid amount to 10
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            amount = 100;

            //act
            var packages = BuyDonationPackage(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            //assert
            Assert.IsNotNull(packages);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessSetMaxBidSuccess()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 10; //setting the Current Bid amount to 10
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            //assert
            Assert.IsNotNull(packages);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessSetMaxBid_Scenario1()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            //act
            amount = 100; //sets the max bid amount to 100 for Bidder X
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);
            var highBid = commonFactory.GetHighBidByPackage(packageFieldValues.PackageXid);
            var expectedhighBidAmount = ((highBid != null) ? (packageFieldValues.MinimumRaise ?? 0) : (packageFieldValues.MinimumBid ?? 0));

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(amount > highBid.Amount);
            Assert.IsTrue(highBid.Amount == expectedhighBidAmount);
        }

        [TestMethod]
        public void TestDataAccessSetMaxBid_Scenario2()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidderX = commonFactory.CreateOrUpdateBidder(bidderFieldValues); // Bidder X

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 20; //setting the current bid amount to 20
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            amount = 100; //sets the max bid amount to 100 for Bidder X
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            // Bidder Y
            bidderFieldValues.BidderXid = secondBidderXid;
            bidderFieldValues.OnlineBidderKey = secondOnlineBidderKey;
            var bidderY = commonFactory.CreateOrUpdateBidder(bidderFieldValues); 

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.SetHttpContext();

            amount = 80; //sets the max bid amount to 80 for Bidder Y
            var packages1 = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            var highBid = commonFactory.GetHighBidByPackage(packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Message == expectedSuccessResultMessage.Message);
            Assert.IsTrue(highBid.Amount == amount);
            Assert.IsNotNull(packages1);
            Assert.IsTrue(packages1.Message == expectedOutBidResultMessage.Message);
        }

        [TestMethod]
        public void TestDataAccessSetMaxBid_Scenario3()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidderX = commonFactory.CreateOrUpdateBidder(bidderFieldValues); // Bidder X

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 20; //setting the current bid amount to 20
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            amount = 80; //sets the max bid amount to 80 for bidder X
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            // Bidder Y
            bidderFieldValues.BidderXid = secondBidderXid;
            bidderFieldValues.OnlineBidderKey = secondOnlineBidderKey;
            var bidderY = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.SetHttpContext();

            amount = 100; //sets the max bid amount to 100 for bidder y
            var packages1 = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Message == expectedSuccessResultMessage.Message);
            Assert.IsNotNull(packages1);
        }

        [TestMethod]
        public void TestDataAccessSetMaxBid_Scenario4()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidderX = commonFactory.CreateOrUpdateBidder(bidderFieldValues); // Bidder X

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 10; //setting the current bid amount to 10
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            amount = 50; //sets the max bid amount to 80 for bidder X
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            // Bidder Y
            bidderFieldValues.BidderXid = secondBidderXid;
            bidderFieldValues.OnlineBidderKey = secondOnlineBidderKey;
            var bidderY = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 20; //Bidder Ysetting the Current Bid - 20 
            var bid1 = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Message == expectedSuccessResultMessage.Message);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessSetMaxBid_Scenario5()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidderX = commonFactory.CreateOrUpdateBidder(bidderFieldValues); // Bidder X

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 20; //setting the current bid amount to 20
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            amount = 100; //sets the max bid amount to 100 for bidder X
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            // Bidder Y
            bidderFieldValues.BidderXid = 16;
            bidderFieldValues.OnlineBidderKey = "26329";
            var bidderY = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.SetHttpContext();

            amount = 100; //sets the max bid amount to 100 for bidder y
            var packages1 = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            var highBid = commonFactory.GetHighBidByPackage(packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Message == expectedSuccessResultMessage.Message);
            Assert.IsTrue(highBid.Amount == amount);
            Assert.IsNotNull(packages1);
            Assert.IsTrue(packages1.Message == expectedOutBidResultMessage.Message);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessSetMaxBid_Scenario6()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidderX = commonFactory.CreateOrUpdateBidder(bidderFieldValues); // Bidder X
            
            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 20; //setting the current bid amount to 20
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            amount = 100; //sets the max bid amount to 100 for bidder X
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            // Bidder Y
            bidderFieldValues.BidderXid = secondBidderXid;
            bidderFieldValues.OnlineBidderKey = secondOnlineBidderKey;
            var bidderY = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.SetHttpContext();

            bidAmount = 100; //bidder y setting the Current Bid - 100  
            var bid1 = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);
            
            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Message == expectedSuccessResultMessage.Message);
            Assert.IsTrue(bid.Message == expectedSuccessResultMessage.Message);
            Assert.IsTrue(bid1.Message == expectedOutBidResultMessage.Message);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessBuyAppealDonationPackage()
        {
            projectFieldValues.DonationPackageXid = packageFieldValues.PackageXid;
            var project = commonFactory.CreateProject(projectFieldValues);

            packageFieldValues.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Donation;
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            //act
            var packages = BuyDonationPackage(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            //assert
            Assert.IsNotNull(packages);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetLeaderBoardPackages()
        {
            var project = commonFactory.CreateProject(projectFieldValues);

            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            //act
            var packages = GetLeaderBoardPackages(projectFieldValues.Prefix, leaderBoardInput);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count > 0);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetLeaderBoardPackagesWithEmptyCategory()
        {
            var project = commonFactory.CreateProject(projectFieldValues);

            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            leaderBoardInput.CategoryFilterType = "";
            leaderBoardInput.PackageSort = DisplayLookupConstants.DisplayPackageSortType_PackageNumber;

            //act
            var packages = GetLeaderBoardPackages(projectFieldValues.Prefix, leaderBoardInput);

            //assert
            Assert.IsNotNull(packages);
            Assert.IsTrue(packages.Count == 0);
        }

        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetFurthestPackageClosingTimeByProjectSuccess()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            commonFactory.UpdatePackageClass();

            //act
            var resultFurthestPackageDateTime = GetFurthestPackageClosingTimeByProject(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(resultFurthestPackageDateTime);
        }
       
        [TestCategory("Package")]
        [TestMethod]
        public void TestDataAccessGetFurthestPackageClosingTimeByProjectFail()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            commonFactory.UpdatePackageClass();
            projectFieldValues.Prefix = string.Concat(projectFieldValues.Prefix, projectFieldValues.Prefix);  //project Prefix doesnot exist in Package 
            //act
            var resultFurthestPackageDateTime = GetFurthestPackageClosingTimeByProject(projectFieldValues.Prefix);

            //assert
            Assert.IsNull(resultFurthestPackageDateTime.CountdownTime);
        }
    }
}
