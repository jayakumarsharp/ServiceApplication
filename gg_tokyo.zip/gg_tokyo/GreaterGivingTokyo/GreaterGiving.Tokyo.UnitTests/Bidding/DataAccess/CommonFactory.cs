﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Web;
using GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.SendSaleData.Model;

namespace GreaterGiving.Tokyo.UnitTests.DataAccess
{
    public class CommonFactory
    {
        private readonly FakeContext _fakeDBContext;
        private static BidderFieldValues bidderFieldValues;
        public CommonFactory(FakeContext fakeDBContext)
        {
            _fakeDBContext = fakeDBContext;
        }
        #region Class Initialize
        //create project which needs Project as the output for the GetBidActivityFilterByBidder,GetAppealDonationPackages,NoBidPackagesFilter,CurrentlyOpenPackagesFilter,BuyNowPackagesFilter,MultiSalePackagesFilter,MultiSalePackagesFilter
        public Project CreateTestProject(ProjectFieldValues projectFieldValues)
        {
            var winningBidderDetail = GetCodeLookupValueByDescription(CodeLookupConstants.CodeType_WinningBidderDetailType, projectFieldValues.WinningBidderDetail.ToString());
            var browsePageSortOrder = GetCodeLookupValueByDescription(CodeLookupConstants.CodeType_BrowsePageSortOrderType, projectFieldValues.BrowsePageSortOrder.ToString());
            var leaderBoardTheme = GetCodeLookupValueByDescription(CodeLookupConstants.CodeType_LeaderboardThemeType, projectFieldValues.LeaderBoardTheme.ToString());            
            var leaderboardStyle = GetCodeLookupValueByDescription(CodeLookupConstants.CodeType_LeaderboardStyleType, projectFieldValues.LeaderboardStyle.ToString());            
            var suggestedAmountList = (projectFieldValues.SuggestedDonationAmounts!= null && projectFieldValues.SuggestedDonationAmounts.ToList().Count > 0) ?
                                    string.Join(AppConstants.CommaDelimiter, projectFieldValues.SuggestedDonationAmounts.Select(x => x).ToArray()) : null;

            var insertProject = new Project();
            insertProject.ProjectXid = projectFieldValues.ProjectXid;
            insertProject.Prefix = projectFieldValues.Prefix;
            insertProject.ProjectDisplayName = projectFieldValues.ProjectDisplayName;
            insertProject.TimeZoneId = projectFieldValues.TimeZoneId;
            insertProject.ProjectImage = System.Text.Encoding.UTF8.GetBytes(projectFieldValues.ProjectImage.ToString());
            insertProject.DisplayBiddersOnAppealBoard = projectFieldValues.DisplayBiddersOnAppealBoard;
            insertProject.SendSmsOutbidNotices = projectFieldValues.SendSmsOutbidNotices;
            insertProject.SendEmailOutbidNotices = projectFieldValues.SendEmailOutbidNotices;
            insertProject.ShowFmv = projectFieldValues.ShowFmv;
            insertProject.AppealOnlyEvent = projectFieldValues.AppealOnlyEvent;
            
            insertProject.WinningBidderDetail = (byte)winningBidderDetail;
            insertProject.ShowHistoryOnRegularPackages = projectFieldValues.ShowHistoryOnRegularPackages;
            insertProject.ShowHistoryOnMultisalePackages = projectFieldValues.ShowHistoryOnRegularPackages;
            insertProject.ShowDonors = projectFieldValues.ShowDonors;
            insertProject.BrowsePageSortOrder = (byte)browsePageSortOrder;
            insertProject.AppealGoal = projectFieldValues.AppealGoal;
            insertProject.LegalTerms = projectFieldValues.LegalTerms;
            insertProject.LeaderboardNumberOfPackages = projectFieldValues.LeaderboardNumberOfPackages;
            insertProject.DonationPackageXid = projectFieldValues.DonationPackageXid;
            insertProject.DonationLabel = projectFieldValues.DonationLabel;
            insertProject.AppealImage = projectFieldValues.AppealImage;
            insertProject.LeaderboardTheme = (byte)leaderBoardTheme;
            insertProject.LeaderboardScreenDisplaySeconds = projectFieldValues.LeaderboardScreenDisplaySeconds;
            insertProject.RevenueGoal = projectFieldValues.RevenueGoal;
            insertProject.AllowMaxBidding = projectFieldValues.AllowMaxBidding;
            insertProject.LeaderboardStyle = (byte)leaderboardStyle;
            insertProject.SuggestedDonationAmounts = suggestedAmountList;
            insertProject.ProjectKey = projectFieldValues.ProjectKey;
            _fakeDBContext.Projects.Add(insertProject);

            return insertProject;
        }
        
        public byte? GetCodeLookupValueByDescription(string codeLookupType ,string description)
        {
            var codeLookupValue = _fakeDBContext.CodeLookups.FirstOrDefault(x => x.CodeType == codeLookupType && x.CodeDescription == description).CodeValue;
            return (byte)codeLookupValue;
        }

        public PackageFieldValues CreateRelatedPackage()
        {
            var insertUpdatePackage = new PackageFieldValues();
            insertUpdatePackage.ProjectXid = CreateProjectFieldValues().ProjectXid;
            insertUpdatePackage.PackageXid = 6;
            insertUpdatePackage.Name = "Related Package";
            insertUpdatePackage.Number = "2";
            insertUpdatePackage.ClassName = CreateClass(insertUpdatePackage.ProjectXid).ClassName;
            insertUpdatePackage.Description = "Test";
            insertUpdatePackage.RestrictionNotes = "Test";
            insertUpdatePackage.Donors = new string[] { "test" };
            insertUpdatePackage.Value = "10";
            insertUpdatePackage.MinimumBid = 10;
            insertUpdatePackage.MinimumRaise = 10;
            insertUpdatePackage.Price = 100;
            insertUpdatePackage.MaxAvailable = 1;
            insertUpdatePackage.EndTimeUTC = DateTime.UtcNow;
            insertUpdatePackage.StartTimeUTC = DateTime.UtcNow;
            insertUpdatePackage.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Givers;
            
            CreatePackageImage(insertUpdatePackage.PackageXid);

            return insertUpdatePackage;
        }

        public PackageFieldValues CreatePackageFieldValues()
        {
            var insertUpdatePackage = new PackageFieldValues();
            insertUpdatePackage.ProjectXid = CreateProjectFieldValues().ProjectXid;
            insertUpdatePackage.PackageXid = 5;
            insertUpdatePackage.Name = "Name";
            insertUpdatePackage.Number = "1";
            insertUpdatePackage.ClassName = CreateClass(insertUpdatePackage.ProjectXid).ClassName;
            insertUpdatePackage.Description = "Test";
            insertUpdatePackage.RestrictionNotes = "Test";
            insertUpdatePackage.Donors = new string[] { "test" };
            insertUpdatePackage.Value = "10";
            insertUpdatePackage.MinimumBid = 10;
            insertUpdatePackage.MinimumRaise = 10;
            insertUpdatePackage.Price = 100;
            insertUpdatePackage.MaxAvailable = 1;
            insertUpdatePackage.EndTimeUTC = DateTime.UtcNow.AddDays(1);
            insertUpdatePackage.StartTimeUTC = DateTime.UtcNow.AddDays(-1);
            insertUpdatePackage.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Regular;
            insertUpdatePackage.Images = new byte[4][];
            
            return insertUpdatePackage;
        }

        public byte[] CreatePackageImage(int packageId)
        {
            var packageImage = new PackageImage();
            packageImage.Image = new byte[4];
            packageImage.PackageXid = packageId;
            packageImage.Order = 1;

            _fakeDBContext.PackageImage.Add(packageImage);

            return packageImage.Image;
        }

        public Class CreateClass(int projectXid)
        {
            var isAlreadyExist = _fakeDBContext.Class.FirstOrDefault(x => x.ClassID == 1); 
            if (isAlreadyExist != null)
            {
                return isAlreadyExist;
            }
            var addClass = new Class();
            addClass.ClassID = 1;
            addClass.ClassName = "Class Name";
            addClass.ProjectXid = projectXid;
            _fakeDBContext.Class.Add(addClass);
            var insertClass = _fakeDBContext.SaveChanges();

            return addClass;
        }

        public BidderFieldValues CreateBidderFieldValues()
        {
            bidderFieldValues = new BidderFieldValues();
            bidderFieldValues.BidderXid = 15;
            bidderFieldValues.Emails = "Test@abc.com".Split(',');
            bidderFieldValues.MobilePhones = "123456789".Split(',');
            bidderFieldValues.Number = 123;
            bidderFieldValues.OnlineBidderKey = "12345";
            bidderFieldValues.ProjectXid = CreateProjectFieldValues().ProjectXid;
            bidderFieldValues.SupporterName = "Bidder Name 1";
            bidderFieldValues.TableNumber = 0;
            return bidderFieldValues;
        }

        public BulkPackageFields CreateBulkPackageField()
        {
            var BulkPackageField = new BulkPackageFields();
            BulkPackageField.PackageXid = 5;
            BulkPackageField.StartTimeUTC = DateTime.UtcNow;
            BulkPackageField.EndTimeUTC = DateTime.UtcNow;
            BulkPackageField.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Live;
            return BulkPackageField;
        }
        public BulkPackageFieldValues CreateBulkPackageFieldValues()
        {
            var BulkPackageFieldValue = new BulkPackageFieldValues();
            BulkPackageFieldValue.ProjectXid = CreateProjectFieldValues().ProjectXid;
            BulkPackageFieldValue.BulkPackageFields = new List<BulkPackageFields>() { CreateBulkPackageField() };
            return BulkPackageFieldValue;
        }

        public Sale CreateSale()
        {
            var insertSale = new Sale();
            insertSale.SaleID = 1;
            insertSale.ProjectXid = CreateProjectFieldValues().ProjectXid;
            insertSale.PackageXid = CreatePackageFieldValues().PackageXid;
            insertSale.BidderXid = CreateBidderFieldValues().BidderXid;
            insertSale.Amount = 20;
            insertSale.GGOUpdateStatus = 1;
            return insertSale;
        }
        public void InsertCodeLookupFieldvalues()
        {
            var codeList = new List<Tuple<int, string, string>>();
            var displayList = new List<Tuple<int, string, string, string>>();

            codeList.Add(new Tuple<int, string, string>(0, "WinningBidderDetailType", "Bidder_Number"));
            codeList.Add(new Tuple<int, string, string>(1, "WinningBidderDetailType", "Bidder_Name"));

            codeList.Add(new Tuple<int, string, string>(0, "BrowsePageSortOrderType", "Number"));
            codeList.Add(new Tuple<int, string, string>(1, "BrowsePageSortOrderType", "Category"));

            codeList.Add(new Tuple<int, string, string>(0, "LeaderboardStyleType", "AllItems_Closing"));
            codeList.Add(new Tuple<int, string, string>(1, "LeaderboardStyleType", "AllItems_Item"));
            codeList.Add(new Tuple<int, string, string>(2, "LeaderboardStyleType", "OpenItems_Closing"));
            codeList.Add(new Tuple<int, string, string>(3, "LeaderboardStyleType", "OpenItems_Item"));
            codeList.Add(new Tuple<int, string, string>(4, "LeaderboardStyleType", "Unbid_Items"));
            codeList.Add(new Tuple<int, string, string>(5, "LeaderboardStyleType", "Bidder"));
            codeList.Add(new Tuple<int, string, string>(255, "LeaderboardStyleType", "Class"));

            codeList.Add(new Tuple<int, string, string>(0, "LeaderboardThemeType", "Blue"));
            codeList.Add(new Tuple<int, string, string>(1, "LeaderboardThemeType", "Brown"));
            codeList.Add(new Tuple<int, string, string>(2, "LeaderboardThemeType", "Green"));
            codeList.Add(new Tuple<int, string, string>(3, "LeaderboardThemeType", "Gray"));
            codeList.Add(new Tuple<int, string, string>(4, "LeaderboardThemeType", "Purple"));
            codeList.Add(new Tuple<int, string, string>(5, "LeaderboardThemeType", "Red"));

            codeList.Add(new Tuple<int, string, string>(0, "SMSDeliveryStatusesType", "Delivered"));
            codeList.Add(new Tuple<int, string, string>(1, "SMSDeliveryStatusesType", "Failed"));
            codeList.Add(new Tuple<int, string, string>(2, "SMSDeliveryStatusesType", "Queued"));
            codeList.Add(new Tuple<int, string, string>(3, "SMSDeliveryStatusesType", "Received"));
            codeList.Add(new Tuple<int, string, string>(4, "SMSDeliveryStatusesType", "Receiving"));
            codeList.Add(new Tuple<int, string, string>(5, "SMSDeliveryStatusesType", "Sending"));
            codeList.Add(new Tuple<int, string, string>(6, "SMSDeliveryStatusesType", "Sent"));
            codeList.Add(new Tuple<int, string, string>(7, "SMSDeliveryStatusesType", "Undelivered"));

            codeList.Add(new Tuple<int, string, string>(0, "MobileBiddingType", "Regular"));
            codeList.Add(new Tuple<int, string, string>(1, "MobileBiddingType", "Live"));
            codeList.Add(new Tuple<int, string, string>(2, "MobileBiddingType", "Appeal"));
            codeList.Add(new Tuple<int, string, string>(3, "MobileBiddingType", "Givers"));
            codeList.Add(new Tuple<int, string, string>(4, "MobileBiddingType", "Donation"));

            codeList.Add(new Tuple<int, string, string>(0, "EmailDeliveryStatusesType", "Accepted"));
            codeList.Add(new Tuple<int, string, string>(1, "EmailDeliveryStatusesType", "BadRequest"));

            codeList.Add(new Tuple<int, string, string>(1, "BidderListType", "Favorites"));
            codeList.Add(new Tuple<int, string, string>(2, "BidderListType", "MaxBid"));

            codeList.Add(new Tuple<int, string, string>(1, "BidType", "Bid"));
            codeList.Add(new Tuple<int, string, string>(2, "BidType", "BidMore"));
            codeList.Add(new Tuple<int, string, string>(3, "BidType", "Buy"));

            codeList.Add(new Tuple<int, string, string>(1, "SMSPurposeType", "Welcome"));
            codeList.Add(new Tuple<int, string, string>(2, "SMSPurposeType", "OutBid"));
            codeList.Add(new Tuple<int, string, string>(3, "SMSPurposeType", "RegistrationOpen"));

            codeList.Add(new Tuple<int, string, string>(1, "EmailPurposeType", "Welcome"));
            codeList.Add(new Tuple<int, string, string>(2, "EmailPurposeType", "OutBid"));
            codeList.Add(new Tuple<int, string, string>(2, "EmailPurposeType", "RegistrationOpen"));

            codeList.Add(new Tuple<int, string, string>(1, "SaleResultType", "Error"));
            codeList.Add(new Tuple<int, string, string>(2, "SaleResultType", "Posted"));
            codeList.Add(new Tuple<int, string, string>(3, "SaleResultType", "Queued"));

            codeList.Add(new Tuple<int, string, string>(1, "SalePackageType", "Auction"));
            codeList.Add(new Tuple<int, string, string>(4, "SalePackageType", "Donation"));

            codeList.Add(new Tuple<int, string, string>(1, "BidderActionType", "Bid"));
            codeList.Add(new Tuple<int, string, string>(2, "BidderActionType", "BidMore"));
            codeList.Add(new Tuple<int, string, string>(3, "BidderActionType", "Buy"));
            codeList.Add(new Tuple<int, string, string>(4, "BidderActionType", "MaxBid"));
            codeList.Add(new Tuple<int, string, string>(5, "BidderActionType", "Donation"));
            codeList.Add(new Tuple<int, string, string>(6, "BidderActionType", "Appeal"));
            codeList.Add(new Tuple<int, string, string>(7, "BidderActionType", "Favorites"));

            codeList.Add(new Tuple<int, string, string>(1, "EventType", "INSERT"));
            codeList.Add(new Tuple<int, string, string>(2, "EventType", "DELETE"));

            displayList.Add(new Tuple<int, string, string, string>(1, "PackageStatusType", "OutBid", "Out Bid"));
            displayList.Add(new Tuple<int, string, string, string>(2, "PackageStatusType", "Winning", "Winning"));
            displayList.Add(new Tuple<int, string, string, string>(3, "PackageStatusType", "Won", "Won"));
            displayList.Add(new Tuple<int, string, string, string>(4, "PackageStatusType", "Sold", "Sold"));
            displayList.Add(new Tuple<int, string, string, string>(5, "PackageStatusType", "Closed", "Closed"));
            displayList.Add(new Tuple<int, string, string, string>(6, "PackageStatusType", "Opening", "Opening"));
            displayList.Add(new Tuple<int, string, string, string>(7, "PackageStatusType", "Preview", "Preview"));
            displayList.Add(new Tuple<int, string, string, string>(8, "PackageStatusType", "OpeningSoon", "Opening Soon"));
            displayList.Add(new Tuple<int, string, string, string>(9, "PackageStatusType", "All", "All"));
                        
            displayList.Add(new Tuple<int, string, string, string>(1, "AdminPackageStatusType", "Sold", "Sold"));
            displayList.Add(new Tuple<int, string, string, string>(2, "AdminPackageStatusType", "Closed", "Closed"));
            displayList.Add(new Tuple<int, string, string, string>(3, "AdminPackageStatusType", "Preview", "Preview"));
            displayList.Add(new Tuple<int, string, string, string>(4, "AdminPackageStatusType", "OpeningSoon", "Opening Soon"));
            displayList.Add(new Tuple<int, string, string, string>(5, "AdminPackageStatusType", "Open", "Open"));

            displayList.Add(new Tuple<int, string, string, string>(1, "ResultStatusType", "Success", "Success"));
            displayList.Add(new Tuple<int, string, string, string>(2, "ResultStatusType", "Failure", "Failure"));
            displayList.Add(new Tuple<int, string, string, string>(3, "ResultStatusType", "OutBided", "OutBided"));

            displayList.Add(new Tuple<int, string, string, string>(1, "PackageFilterType", "All", "All"));
            displayList.Add(new Tuple<int, string, string, string>(2, "PackageFilterType", "NoBids", "No Bids"));
            displayList.Add(new Tuple<int, string, string, string>(3, "PackageFilterType", "NoBids", "No Bids"));
            displayList.Add(new Tuple<int, string, string, string>(4, "PackageFilterType", "CurrentlyOpen", "Currently Open"));
            displayList.Add(new Tuple<int, string, string, string>(5, "PackageFilterType", "BuyNow", "Buy Now"));
            displayList.Add(new Tuple<int, string, string, string>(6, "PackageFilterType", "Multisale", "Multi sale"));
            displayList.Add(new Tuple<int, string, string, string>(7, "PackageFilterType", "PreviewOnly", "Preview Only"));

            displayList.Add(new Tuple<int, string, string, string>(1, "LeaderBoardPackageFilter", "Open", "Open"));
            displayList.Add(new Tuple<int, string, string, string>(2, "LeaderBoardPackageFilter", "NoBid", "No Bid"));
            displayList.Add(new Tuple<int, string, string, string>(3, "LeaderBoardPackageFilter", "All", "All"));
            displayList.Add(new Tuple<int, string, string, string>(4, "LeaderBoardPackageFilter", "Buy", "Buy"));
            displayList.Add(new Tuple<int, string, string, string>(5, "LeaderBoardPackageFilter", "BuyNow", "Buy Now"));
            displayList.Add(new Tuple<int, string, string, string>(6, "LeaderBoardPackageFilter", "Multisale", "Multi sale"));
            displayList.Add(new Tuple<int, string, string, string>(7, "LeaderBoardPackageFilter", "Preview", "Preview"));
            displayList.Add(new Tuple<int, string, string, string>(8, "LeaderBoardPackageFilter", "Category", "Category"));
            displayList.Add(new Tuple<int, string, string, string>(9, "LeaderBoardPackageFilter", "Sold", "Sold"));

            displayList.Add(new Tuple<int, string, string, string>(1, "PackageSortType", "PackageNumber", "Package Number"));
            displayList.Add(new Tuple<int, string, string, string>(2, "PackageSortType", "ClosingTime", "ClosingTime"));
            displayList.Add(new Tuple<int, string, string, string>(3, "PackageSortType", "Bidder", "Bidder"));

            displayList.Add(new Tuple<int, string, string, string>(1, "CategoryFilter", "All", "All"));

            displayList.Add(new Tuple<int, string, string, string>(1, "RecipientType", "All", "All"));
            displayList.Add(new Tuple<int, string, string, string>(2, "RecipientType", "Winning", "Winning"));
            displayList.Add(new Tuple<int, string, string, string>(3, "RecipientType", "NonWinning", "NonWinning"));

            foreach (var code in codeList)
            {
                var insertCodeLookup = new CodeLookup();
                insertCodeLookup.CodeValue = code.Item1;
                insertCodeLookup.CodeType = code.Item2;
                insertCodeLookup.CodeDescription = code.Item3;
                _fakeDBContext.CodeLookups.Add(insertCodeLookup);
            }

            foreach (var code in displayList)
            {
                var insertDisplayLookup = new DisplayLookup();
                insertDisplayLookup.DisplayValue = code.Item1;
                insertDisplayLookup.DisplayType = code.Item2;
                insertDisplayLookup.DisplayCode = code.Item3;
                insertDisplayLookup.DisplayText = code.Item4;
                _fakeDBContext.DisplayLookups.Add(insertDisplayLookup);
            }

        }

        public ProjectFieldValues CreateProjectFieldValues()
        {
            var projectFieldValues = new ProjectFieldValues();
            projectFieldValues.ProjectXid = 9254;
            projectFieldValues.Prefix = "OBAPI";
            projectFieldValues.ProjectDisplayName = "DK OB API";
            projectFieldValues.TimeZoneId = "America/Los_Angeles";
            projectFieldValues.ProjectImage = System.Text.Encoding.UTF8.GetBytes("xkjazasd-UjsyUYVLlslsodlif");
            projectFieldValues.DisplayBiddersOnAppealBoard = false;
            projectFieldValues.SendSmsOutbidNotices = true;
            projectFieldValues.SendEmailOutbidNotices = false;
            projectFieldValues.ShowFmv = true;
            projectFieldValues.AppealOnlyEvent = false;
            projectFieldValues.WinningBidderDetail = "Bidder_Number"; // Enum changed so changed the values
            projectFieldValues.ShowHistoryOnRegularPackages = true;
            projectFieldValues.ShowHistoryOnMultisalePackages = true;
            projectFieldValues.ShowDonors = true;
            projectFieldValues.BrowsePageSortOrder = "Number";// Enum changed so changed the values
            projectFieldValues.AppealGoal = 0;
            projectFieldValues.LegalTerms = "";
            projectFieldValues.LeaderboardNumberOfPackages = 0;
            projectFieldValues.DonationPackageXid = 0;
            projectFieldValues.DonationLabel = null;
            projectFieldValues.AppealImage = null;
            projectFieldValues.LeaderBoardTheme = "Brown";// Enum changed so changed the values
            projectFieldValues.LeaderboardScreenDisplaySeconds = 10;
            projectFieldValues.RevenueGoal = 0;
            projectFieldValues.AllowMaxBidding = true;
            projectFieldValues.LeaderboardStyle = "AllItems_Closing";// Enum changed so changed the values
            projectFieldValues.SuggestedDonationAmounts = null;
            projectFieldValues.ProjectKey = "xxxx-dzUvQdammmA";
            projectFieldValues.IsDeleted = false;
            return projectFieldValues;
        }

        public TextMessageFieldValues CreateSendSMSFieldValues()
        {
            var textFieldValues = new TextMessageFieldValues
            {
                Message = "Welcome Message",
                Phone = "+19718033940",
                ProjectXid = 9254
            };
            return textFieldValues;
        }

        public TextMessageFieldValues CreateSendSMSFieldValuesWithEmptyPhone()
        {
            var textFieldValues = new TextMessageFieldValues
            {
                Message = "test message",
                Phone = "",
                ProjectXid = 9254
            };
            return textFieldValues;
        }

        public EmailMessageFieldValues CreateSendEmailFieldValues()
        {
            var emailFieldValues = new EmailMessageFieldValues
            {
                FromEmailAddress = "test@ggo.mobi",
                ToEmailAddress = "test@test.com",
                FromName = "test",
                Message = "Welcome Test Message",
                Subject = "Welcome"
            };
            return emailFieldValues;
        }

        public EmailDeliveryStatusInput CreateEmailDeliveryStatusInput()
        {
            var emailDeliveryStatusInput = new EmailDeliveryStatusInput
            {
                EmailRequestId = 1,
                EmailAddress = "test@test.com",
                StatusIndicator = GetCodeLookupValueByDescription(CodeLookupConstants.CodeType_EmailDeliveryStatusesType, CodeLookupConstants.CodeEDSType_Accepted), 
                SendTime = DateTime.UtcNow.AddMinutes(-1),
                DeliveryTime = DateTime.UtcNow,
                BidderId = null,
                DeliveryStatus= "Accepted",
                MessageId = "fZjOrAQaRGaqMhCQ8472LA"
            };
            return emailDeliveryStatusInput;
        }

        public SMSRequest FindSMSRequestByRequestId(int requestId)
        {
            var request = _fakeDBContext.SMSRequests.FirstOrDefault(x => x.SMSRequestID == requestId);
            return request;
        }

        public EmailRequest FindEmailRequestByRequestId(int requestId)
        {
            var request = _fakeDBContext.EmailRequests.FirstOrDefault(x => x.EmailRequestID == requestId);
            return request;
        }

        

        public EmailDeliveryStatus CreateEmailDeliveryStatus()
        {
            var emailDeliveryStatus = new EmailDeliveryStatus();
            emailDeliveryStatus.EmailDeliveryID = 1;
            emailDeliveryStatus.EmailRequestID = 1;
            emailDeliveryStatus.DeliveryTime = DateTime.UtcNow.AddDays(1);
            emailDeliveryStatus.SendTime = DateTime.UtcNow.AddHours(-1);
            emailDeliveryStatus.StatusIndicator = 0;

            _fakeDBContext.EmailDeliveryStatus.Add(emailDeliveryStatus);
            return emailDeliveryStatus;
        }

        public SaleData CreateSaleDataFieldValues()
        {
            var saleDataFieldValues = new SaleData
            {
                UserName = "",
                Password = "",
                PartnerId = "",
                ProjectId = CreateProjectFieldValues().ProjectXid,
                BidderId = CreateBidderFieldValues().BidderXid,
                PackageId = CreatePackageFieldValues().PackageXid,
                SaleQuantity = 12,
                SaleTotalPreTax = 0,
                SaleDate = DateTime.UtcNow,
                PackageType = 1
            };
            return saleDataFieldValues;
        }
                

        public LeaderBoardInput CreateLeaderBoardInputFieldValues()
        {
            int[] displayedPackagesArray = new int[] { 5, 6, 7 };
            var leaderBoardInputValues = new LeaderBoardInput
            {
                PackageFilterType = DisplayLookupConstants.DisplayLeaderBoardPackageFilter_Open,
                CategoryFilterType = DisplayLookupConstants.DisplayCategoryFilter_All,
                DisplayCount = 1,
                DisplayedPackages = displayedPackagesArray,
                PackageSort = DisplayLookupConstants.DisplayPackageSortType_ClosingTime
            };
            return leaderBoardInputValues;
        }

        public PackageSearchInput CreatePackageSearchInput()
        {
            var packageSearchInput = new PackageSearchInput();
            packageSearchInput.Name = "";
            packageSearchInput.Number = "";
            packageSearchInput.ClassName = "All";
            packageSearchInput.ShouldBuyNow = false;
            packageSearchInput.ShouldCurrentlyOpen = false;
            packageSearchInput.ShouldMultisale = false;
            packageSearchInput.ShouldNoBids = false;
            packageSearchInput.ShouldPreview = false;

            return packageSearchInput;
        }

        public PackageSearchOutput CreatePackageSearchOutput()
        {
            var packageSearchOutput = new PackageSearchOutput();
            packageSearchOutput.Name = "";
            packageSearchOutput.Number = "";
            packageSearchOutput.ClassName = "";
            packageSearchOutput.PackageXid = 0;
            packageSearchOutput.ProjectXid = 0;
            packageSearchOutput.MinimumBid = -1;                  /* -1 indicates Not applicable */
            packageSearchOutput.MinimumRaise = -1;                /* -1 indicates Not applicable */
            packageSearchOutput.Price = -1;                       /* -1 indicates Not applicable */
            packageSearchOutput.StartTimeUTC = DateTime.UtcNow;
            packageSearchOutput.EndTimeUTC = DateTime.UtcNow;
            packageSearchOutput.Bid = -1;                         /* -1 indicates Not applicable */
            packageSearchOutput.MaxBid = -1;                      /* -1 indicates Not applicable */
            packageSearchOutput.Status = "Open";

            return packageSearchOutput;
        }
        public Bid CreateOrUpdateBid(Bid values)
        {
            _fakeDBContext.Bids.Add(values);
            return values;
        }

        public Bid CreateBid()
        {
            var insertBid = new Bid();
            insertBid.BidXid = 1;
            insertBid.ProjectXid = CreateProjectFieldValues().ProjectXid;
            insertBid.PackageXid = CreatePackageFieldValues().PackageXid;
            insertBid.BidderXid = CreateBidderFieldValues().BidderXid;
            insertBid.Amount = 20;
            return insertBid;
        }
        #endregion Class Initialize

        #region CRUD
        public ResultModel CreateProject(ProjectFieldValues values)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            ResultModel model = _biddingData.CreateProject(values);
            return model;
        }

        public ResultModel UpdateProject(ProjectFieldValues values)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            ResultModel model = _biddingData.UpdateProject(values);
            return model;
        }
        public ResultModel CreateOrUpdateBidder(BidderFieldValues values)
        {
            var _biddingData = new BiddingBidder(_fakeDBContext);

            ResultModel model = _biddingData.AddOrUpdateBidder(values);
            return model;
        }
        public ResultModel DeleteBidder(int bidderId)
        {
            var _biddingData = new BiddingBidder(_fakeDBContext);

            ResultModel model = _biddingData.DeleteBidder(bidderId);
            return model;
        }
        public ResultModel CreateOrUpdatePackage(PackageFieldValues values)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            ResultModel model = _biddingData.AddOrUpdatePackage(values);
            return model;
        }
        public ResultModel CreateOrUpdateBulkPackage(BulkPackageFieldValues values)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            ResultModel model = _biddingData.UpdateTimeAndItemTypeForPackages(values);
            return model;
        }
        public ResultModel DeletePackage(int packageId)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);

            ResultModel model = _biddingData.DeletePackage(packageId);
            return model;
        }
        public Sale CreateOrUpdateSale(Sale values)
        {
            _fakeDBContext.Sales.Add(values);
            return values;
        }

        public void UpdatePackageClass()
        {
            foreach (var package in _fakeDBContext.Packages)
            {
                package.Class = _fakeDBContext.Class.FirstOrDefault();
            }
        }

        public void UpdateBidderPackageClass()
        {
            foreach (var package in _fakeDBContext.BidderLists)
            {
                package.Package = _fakeDBContext.Packages.FirstOrDefault(); //ToDo have to be moved to FAKEDBSET
            }
        }

        public void SetClaimsIdentity(BidderFieldValues bidderFieldValues)
        {
            var identity = new ClaimsIdentity(new Claim[]
                             {
                            new Claim(ClaimTypes.Name, bidderFieldValues.SupporterName.ToString().Trim()),
                            new Claim(ClaimTypes.NameIdentifier, bidderFieldValues.Number.ToString().Trim()),
                            new Claim(ClaimTypes.UserData, bidderFieldValues.TableNumber.ToString().Trim()),
                            new Claim(ClaimTypes.Sid, bidderFieldValues.OnlineBidderKey.ToString().Trim())
                             });
            var claimsPrincipal = new ClaimsPrincipal(identity);
            Thread.CurrentPrincipal = claimsPrincipal;
        }

        public void SetHttpContext()
        {
            HttpContext.Current = new HttpContext(new HttpRequest("", "http://tempuri.org", ""), new HttpResponse(new StringWriter()));
            HttpContext.Current.Request.Browser = new HttpBrowserCapabilities
            {
                Capabilities = new Dictionary<string, string>()
            };
        }

        //needed DonationPackageXid and some of the values
        public ProjectOutput GetProject(string prefix)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            var project = _biddingData.GetProject(prefix);
            return project;
        }

        public ResultMessage AddBid(string prefix, int packageId, decimal amount, string bidType)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            var resultMessage = _biddingData.AddBid(prefix, packageId, amount, bidType);
            return resultMessage;
        }

        public Bid GetHighBidByPackage(int packageId)
        {
            BiddingBase b = new BiddingBase(_fakeDBContext);
            return b.GetHighBidByPackage(packageId);
        }
        #endregion
    }
}