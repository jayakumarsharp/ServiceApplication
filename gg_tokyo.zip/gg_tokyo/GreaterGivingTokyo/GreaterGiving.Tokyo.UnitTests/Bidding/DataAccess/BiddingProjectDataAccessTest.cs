﻿using GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace GreaterGiving.Tokyo.UnitTests.DataAccess
{
    [TestClass]    
    public class BiddingProjectDataAccessTest
    {   
        #region Private Members
    
        private static ProjectFieldValues projectFieldValues;
        private static TextMessageFieldValues textFieldValues;
        private static TextMessageFieldValues textFieldValuesFail;
        private static CommonFactory _commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private static string projectNotUsedPrefix = "Prefix";
        private ResultModel expectedIsShortNameInUseModel = MessageManager.GetResultMessage(MessageCode.InUse, MessageCode.None);
        private ResultModel expectedIsShortNameSuccessModel = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.None);
        private ResultModel expectedCreateProjectSuccessModel = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success001);
        private ResultModel expectedSuccessModel = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
        private ResultModel expectedFailModel = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
        private ResultModel expectedNoRecordsDeletedModel = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);
        private ResultModel expectedSendSMSSuccess = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success005);
        private ResultModel expectedSendSMSFail = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error006);
        private ResultModel expectedSendSMSFailMessageOrPhoneEmpty = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error007);
        private ResultModel expectedSendEmailFailMessageOrEmailAddressEmpty = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error009);
        private CommonFactory commonFactory;
        private EmailMessageFieldValues emailFieldValues;
        private EmailDeliveryStatusInput emailDeliveryStatusInput;
        private static int purpose = 1; //"Welcome"
        
        #endregion Private Members

        public BiddingProjectDataAccessTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            commonFactory.InsertCodeLookupFieldvalues();
            projectFieldValues = commonFactory.CreateProjectFieldValues();
            textFieldValues = commonFactory.CreateSendSMSFieldValues();
            textFieldValuesFail = commonFactory.CreateSendSMSFieldValuesWithEmptyPhone();
            emailFieldValues = commonFactory.CreateSendEmailFieldValues();
            emailDeliveryStatusInput = commonFactory.CreateEmailDeliveryStatusInput();            
        }

        #region CRUD

        private ResultModel DeleteProject(int projectId)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            ResultModel model = _biddingData.DeleteProject(projectId);
            return model;
        }

        private ResultModel CheckIsShortNameAvailable(string prefix)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            var project = _biddingData.IsShortNameAvailable(prefix);
            return project;
        }

        private int InsertSMSRequest(TextMessageFieldValues message, int purpose)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            int smsRequestId = _biddingData.InsertSMSRequest(message, purpose);
            return smsRequestId;
        }

        private bool InsertSMSDeliveryStatus(int smsRequestId, string toPhoneNumber, string statusIndicator, DateTime sendTime, DateTime deliveryTime, string sId, int? bidderId)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            bool inserted = _biddingData.InsertSMSDeliveryStatus(smsRequestId, toPhoneNumber, statusIndicator, sendTime, deliveryTime, sId, bidderId);
            return inserted;
        }

        private int InsertEmailRequest(EmailMessageFieldValues message,int projectId, int purpose)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            int emailRequestId = _biddingData.InsertEmailRequest(message, projectId, purpose);
            return emailRequestId;
        }

        private bool InsertEmailDeliveryStatus(EmailDeliveryStatusInput emailDeliveryStatusInput)
        {
            var _biddingData = new BiddingProject(_fakeDBContext);

            bool inserted = _biddingData.InsertEmailDeliveryStatus(emailDeliveryStatusInput);
            return inserted;
        }
        #endregion CRUD

        #region Get Project

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessGetProject()
        {
            //arrange
            _commonFactory = new CommonFactory(_fakeDBContext);
            var createProject = commonFactory.CreateProject(projectFieldValues);//Create project

            //act
            var project = commonFactory.GetProject(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(project);
            Assert.IsTrue(project.ProjectXid == projectFieldValues.ProjectXid);
        }


        #endregion Get Project

        #region IsShortNameAvailable

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessIsShortNameAvailInUse()
        {
            //arrange
            _commonFactory = new CommonFactory(_fakeDBContext);
            var createProject = commonFactory.CreateProject(projectFieldValues);//Create project

            //act
            var resultModel = CheckIsShortNameAvailable(projectFieldValues.Prefix);

            //assert
            Assert.AreEqual(expectedIsShortNameInUseModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedIsShortNameInUseModel.Reason, resultModel.Reason);
        }

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessIsShortNameAvailSuccess()
        {
            //arrange
            _commonFactory = new CommonFactory(_fakeDBContext);
            
            //act
            var resultModel = CheckIsShortNameAvailable(projectNotUsedPrefix);

            //assert
            Assert.AreEqual(expectedIsShortNameSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedIsShortNameSuccessModel.Reason, resultModel.Reason);
        }

        #endregion IsShortNameAvailable

        #region Create Project

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessCreateProjectSuccess()
        {
            //act
            var resultModel = commonFactory.CreateProject(projectFieldValues);

            //assert
            Assert.AreEqual(expectedCreateProjectSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedCreateProjectSuccessModel.Reason, resultModel.Reason);
        }

        #endregion Create Project

        #region Update Project

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessUpateProjectSuccess()
        {
            //arrange
            var createProject = commonFactory.CreateProject(projectFieldValues);

            projectFieldValues.ProjectDisplayName = "Update Project Display Name";

            //act
            var resultModel = commonFactory.UpdateProject(projectFieldValues);

            var updatedProject = commonFactory.GetProject(projectFieldValues.Prefix);

            //assert
            Assert.AreEqual(updatedProject.ProjectDisplayName, projectFieldValues.ProjectDisplayName);
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        #endregion Update Project       

        #region Delete Project

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessProjectDeleteSuccess()
        {
            //arrange
            commonFactory.CreateProject(projectFieldValues);//Create Project

            //act
            //Delete the Project - Exist in DB
            ResultModel resultModel = DeleteProject(projectFieldValues.ProjectXid);

            //assert
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessProjectDeleteFail()
        {
            //Delete the Project - Not exist in DB
            ResultModel resultModel = DeleteProject(projectFieldValues.ProjectXid);
            
            //assert
            Assert.AreEqual(expectedNoRecordsDeletedModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedNoRecordsDeletedModel.Reason, resultModel.Reason);
        }

        #endregion Delete Project

        #region SendSMS
        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessInsertSMSRequestSuccess()
        {
            //act
            var result = InsertSMSRequest(textFieldValues, purpose);

            //assert
            Assert.AreEqual(0, result);
        }

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessInsertSMSRequestFailWithEmptyPhoneNumber()
        {
            //act
            var result = InsertSMSRequest(textFieldValuesFail, purpose);

            //assert
            Assert.IsTrue(result == 0);
            Assert.AreEqual(0, result);
        }

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessInsertSMSDeliveryStatusSuccess()
        {
            //arrange
            var requestId = InsertSMSRequest(textFieldValues, purpose); // Insert SMSRequest
            var smsRequest = commonFactory.FindSMSRequestByRequestId(requestId); // fetch inserted data 

            //act
            var result = InsertSMSDeliveryStatus(smsRequest.SMSRequestID + 1, smsRequest.Phone, "Delivered", DateTime.UtcNow, DateTime.UtcNow, Guid.NewGuid().ToString(), null);

            //assert
            Assert.IsTrue(result);
        }

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessInsertSMSDeliveryStatusFailRequestId()
        {

            //arrange
            var requestId = InsertSMSRequest(textFieldValues, purpose); // Insert SMSRequest
            var smsRequest = commonFactory.FindSMSRequestByRequestId(requestId); // fetch inserted data 

            //act
            var result = InsertSMSDeliveryStatus(smsRequest.SMSRequestID, smsRequest.Phone, smsRequest.StatusIndicator.ToString(), DateTime.UtcNow, DateTime.UtcNow, Guid.NewGuid().ToString(), null);

            //assert
            Assert.IsTrue(result!=true);
        }
        #endregion SendSMS

        #region SendEmail
        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessInsertEmailRequestSuccess()
        {
            //arrange
            var project = commonFactory.CreateProject(projectFieldValues);//CreateProject 

            //act
            var result = InsertEmailRequest(emailFieldValues, projectFieldValues.ProjectXid, purpose);

            //assert
            Assert.AreEqual(0, result);
        }


        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessInsertEmailRequestFailWithEmptyEmailAndMessage()
        {
            //arrange
            var project = commonFactory.CreateProject(projectFieldValues);//CreateProject 
            emailFieldValues.ToEmailAddress = "";
            //act
            var result = InsertEmailRequest(emailFieldValues, projectFieldValues.ProjectXid, purpose);

            //assert
            Assert.IsTrue(result == 0);
            Assert.AreEqual(0, result);
        }

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessInsertEmailDeliveryStatusSuccess()
        {
            //arrange
            var project = commonFactory.CreateProject(projectFieldValues); //CreateProject 
            var requestId = InsertEmailRequest(emailFieldValues, projectFieldValues.ProjectXid, purpose); // Insert SMSRequest
            emailDeliveryStatusInput.EmailRequestId = 1;
            emailDeliveryStatusInput.EmailAddress = emailFieldValues.ToEmailAddress;
            //act
            var result = InsertEmailDeliveryStatus(emailDeliveryStatusInput);

            //assert
            Assert.IsTrue(result);
        }

        [TestCategory("Project")]
        [TestMethod]
        public void TestDataAccessInsertEmailDeliveryStatusFailRequestId()
        {
            //arrange
            var project = commonFactory.CreateProject(projectFieldValues);//CreateProject 
            var requestId = InsertEmailRequest(emailFieldValues, projectFieldValues.ProjectXid, purpose); // Insert SMSRequest
            emailDeliveryStatusInput.EmailRequestId = -1;

            //act
            var result = InsertEmailDeliveryStatus(emailDeliveryStatusInput);

            //assert
            Assert.IsTrue(result != true);
        }
        #endregion SendEmail
    }
}
