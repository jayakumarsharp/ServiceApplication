﻿using GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace GreaterGiving.Tokyo.UnitTests.DataAccess
{
    [TestClass]
    public class BiddingSponsorDataAccessTest
    {
        #region Private Members
        private static ProjectFieldValues projectFieldValues;
        private static SponsorFieldValues sponsorFieldValues;
        private static CommonFactory commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private ResultModel expectedSuccessModel = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
        private ResultModel expectedFailModel = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error001);
        private ResultModel expectedNoRecordsDeletedModel = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);

        public BiddingSponsorDataAccessTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            projectFieldValues = commonFactory.CreateProjectFieldValues();
            commonFactory.InsertCodeLookupFieldvalues();
        }
        #endregion Private Members

        #region Class Initialize

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            
            // input model 
            byte[] image = Encoding.ASCII.GetBytes("test image");
            sponsorFieldValues = new SponsorFieldValues
            {
                SponsorXid = 1234,
                ProjectXid = 9254,
                Images = image
            };
        }
        #endregion Class Initialize
        
        #region CRUD

        private ResultModel CreateOrUpdateSponsor(SponsorFieldValues values)
        {
            var _biddingData = new BiddingSponsor(_fakeDBContext);

            ResultModel model = _biddingData.AddOrUpdateSponsor(values);
            return model;
        }

        private ResultModel DeleteSponsor(int sponsorId)
        {
            var _biddingData = new BiddingSponsor(_fakeDBContext);

            ResultModel model = _biddingData.DeleteSponsor(sponsorId);
            return model;
        }

        private SponsorOutput GetSponsor(int sponsorXid)
        {
            var _biddingData = new BiddingSponsor(_fakeDBContext);

            var sponsor = _biddingData.GetSponsorBySponsorId(sponsorXid);
            return sponsor;
        }

        private List<SponsorOutput> GetSponsorImagesByPrefix(string prefix)
        {
            var _biddingData = new BiddingSponsor(_fakeDBContext);

            var sponsorList = _biddingData.GetSponsorImagesByPrefix(prefix);
            return sponsorList;
        }

        #endregion CRUD


        #region public Member functions

        [TestCategory("Sponsor")]
        [TestMethod]
        public void TestDataAccessCreateOrUpdateSponsorInsertSuccess()
        {
            //act
            ResultModel resultModel = CreateOrUpdateSponsor(sponsorFieldValues);

            //assert
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Sponsor")]
        [TestMethod]
        public void TestDataAccessCreateOrUpdateSponsorUpdateSuccess()
        {   
            var createSponsor = CreateOrUpdateSponsor(sponsorFieldValues);

            //act
            ResultModel resultModel = CreateOrUpdateSponsor(sponsorFieldValues); 

            var updatedSponsor = GetSponsor(sponsorFieldValues.SponsorXid);

            //assert
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Sponsor")]
        [TestMethod]
        public void TestDataAccessGetSponsorImagesByPrefix()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var createSponsor = CreateOrUpdateSponsor(sponsorFieldValues);

            var sponsorList = GetSponsorImagesByPrefix(projectFieldValues.Prefix);
            //assert
            Assert.AreEqual(sponsorList.Count, 1);            
        }

        [TestCategory("Sponsor")]
        [TestMethod]
        public void TestDataAccessDeleteSponsorSuccess()
        {
            //act
            //Create Bidder
            CreateOrUpdateSponsor(sponsorFieldValues);

            //Delete the Project - Exist in DB
            ResultModel resultModel = DeleteSponsor(sponsorFieldValues.SponsorXid);

            //assert
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Sponsor")]
        [TestMethod]
        public void TestDataAccessDeleteSponsorFail()
        {
            //Delete the Project - Not exist in DB
            ResultModel resultModel = DeleteSponsor(sponsorFieldValues.SponsorXid);

            //assert
            Assert.AreEqual(expectedNoRecordsDeletedModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedNoRecordsDeletedModel.Reason, resultModel.Reason);
        }

        #endregion Public Members
    }
}
