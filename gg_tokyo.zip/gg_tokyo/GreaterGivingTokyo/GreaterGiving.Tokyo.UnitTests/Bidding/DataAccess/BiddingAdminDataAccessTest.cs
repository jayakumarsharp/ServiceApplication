﻿using System;
using System.Collections.Generic;
using GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.UnitTests.DataAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.DataAccess
{
    [TestClass]
    public class BiddingAdminDataAccessTest
    {
        private static ProjectFieldValues projectFieldValues;
        private static BidderFieldValues bidderFieldValues;
        private static PackageFieldValues packageFieldValues;
        private static CommonFactory commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private static BidderSearchInput bidderSearchInput;
        private static PackageSearchInput packageSearchInput;
        private static string bidType;
        private static int amount = 100;
        private static int count = 1;
        private static decimal bidAmount = 0;
        private static ResultMessage _expectedOutputSuccess = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_Success };
        private static ResultMessage _expectedOutputFail = new ResultMessage() { Message = DisplayLookupConstants.DisplayResultStatusType_Failure };
        private static Bid bidFieldValues;
        private static Sale saleFieldValues;       
        private static EmailMessageFieldValues _emailMessageFieldValues;
        private static int emailTemplateId = 0;
        private static TextMessageFieldValues _smsMessageFieldValues;
        private static int smsTemplateId = 0;

        #region Private Members
        public BiddingAdminDataAccessTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            projectFieldValues = commonFactory.CreateProjectFieldValues();
            bidderFieldValues = commonFactory.CreateBidderFieldValues();
            packageFieldValues = commonFactory.CreatePackageFieldValues();
            commonFactory.InsertCodeLookupFieldvalues();
            packageSearchInput = commonFactory.CreatePackageSearchInput();
            bidFieldValues = commonFactory.CreateBid();
            saleFieldValues = commonFactory.CreateSale();
        }
        #endregion Private Members

        #region Class Initialize

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            bidderSearchInput = new BidderSearchInput() { BidderName = bidderFieldValues.SupporterName, BidderNumber = bidderFieldValues.Number };
            _emailMessageFieldValues = new EmailMessageFieldValues { Subject = "Registration Open", Message = "Test Message" };
            _smsMessageFieldValues = new TextMessageFieldValues { Message = "Test Message" };
        }
        #endregion Class Initialize

        #region CRUD

        private List<BidderOutput> GetBidderList(string prefix, int packageId)
        {
            var _biddingData = new BiddingBidder(_fakeDBContext);

            var bidderList = _biddingData.GetBidderHistoryOrCurrentBuyers(prefix, packageId);
            return bidderList;
        }

        private List<BidderOutput> GetTopBidderList(string prefix, int packageId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var bidderList = _biddingData.GetTopBiddersForAdmin(prefix, count);
            return bidderList;
        }

        private BidderSearchOutput GetBidderDetailsForAdmin(string prefix, int bidderId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var bidderSearchOutput = _biddingData.GetBidderDetailsForAdmin(prefix, bidderId);
            return bidderSearchOutput;
        }

        private PackageSearchOutput GetPackageDetailsForAdmin(string prefix, int packageId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var packageSearchOutput = _biddingData.GetPackageDetailsForAdmin(prefix, packageId);
            return packageSearchOutput;
        }

        private List<MaxBidOutput> GetBidderMaxBidForAdmin(string prefix, int bidderId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var maxBidOutputLists = _biddingData.GetBidderMaxBidForAdmin(prefix, bidderId);
            return maxBidOutputLists;
        }

        private MaxBidOutput GetPackageMaxBidForAdmin(string prefix, int packageId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var maxBidOutputLists = _biddingData.GetPackageMaxBidForAdmin(prefix, packageId);
            return maxBidOutputLists;
        }

        private List<BidHistoryOutput> GetBidderBidHistoryForAdmin(string prefix, int bidderId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var bidHistoryOutputLists = _biddingData.GetBidderBidHistoryForAdmin(prefix, bidderId);
            return bidHistoryOutputLists;
        }

        private List<BidHistoryOutput> GetPackageBidHistoryForAdmin(string prefix, int packageId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var bidHistoryOutputLists = _biddingData.GetPackageBidHistoryForAdmin(prefix, packageId);
            return bidHistoryOutputLists;
        }

        private ResultMessage SetMaxBid(string prefix, int packageXid, decimal amount)
        {
            var _biddingData = new BiddingPackage(_fakeDBContext);
            bidType = CodeLookupConstants.CodeBidderActionType_MaxBid; // sets the bid type
            var resultMessage = _biddingData.SetMaxBid(prefix, packageXid, amount, bidType);
            return resultMessage;
        }
        private List<BidderSearchOutput> GetAllBiddersForAdmin(string prefix, int packageXid, decimal amount)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);
            var bidderSearchOutput = _biddingData.GetAllBiddersForAdmin(prefix, bidderSearchInput);
            return bidderSearchOutput;
        }

        private List<PackageOutput> GetTopPackagesList(string prefix, int count)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var packageList = _biddingData.GetTopPackagesForAdmin(prefix, count);
            return packageList;
        }

        private List<PackageSearchOutput> GetAllPackagesListForAdmin(string prefix, PackageSearchInput input)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var packageList = _biddingData.GetAllPackagesForAdmin(prefix, input);
            return packageList;
        }

        private ResultMessage ClearMaxBidForAdmin(string prefix, int packageId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var resultMessage = _biddingData.ClearMaxBidForAdmin(prefix, packageId);
            return resultMessage;
        }

        private ResultMessage RemoveBidForAdmin(string prefix, int bidId, int saleId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);
            var resultMessage = _biddingData.RemoveBidForAdmin(prefix, bidId, saleId);
            return resultMessage;
        }

        private ResultMessage SaveEmailTemplateForAdmin(string prefix, EmailMessageFieldValues emailMessage)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var resultMessage = _biddingData.SaveEmailTemplateForAdmin(prefix, emailMessage);
            return resultMessage;
        }

        private List<EmailTemplateOutput> GetEmailTemplatesForAdmin(string prefix)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var resultMessage = _biddingData.GetEmailTemplatesForAdmin(prefix);
            return resultMessage;
        }

        private ResultMessage DeleteEmailTemplateForAdmin(int projectId, int emailTemplateId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var resultMessage = _biddingData.DeleteEmailTemplateForAdmin(projectId, emailTemplateId);
            return resultMessage;
        }

        private List<SMSTemplateOutput> GetSMSTemplatesForAdmin(string prefix)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var resultMessage = _biddingData.GetSMSTemplatesForAdmin(prefix);
            return resultMessage;
        }

        private ResultMessage SaveSMSTemplateForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var resultMessage = _biddingData.SaveSMSTemplateForAdmin(prefix, textMessageFieldValues);
            return resultMessage;
        }

        private ResultMessage DeleteSMSTemplateForAdmin(int projectId, int smsTemplateId)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);

            var resultMessage = _biddingData.DeleteSMSTemplateForAdmin(projectId, smsTemplateId);
            return resultMessage;
        }

        private Tuple<ResultMessage,List<Package>> RemoveAllBidsForAdmin(string prefix)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);
            var resultMessage = _biddingData.RemoveAllBidsForAdmin(prefix);
            return resultMessage;
        }

        private List<ExportBidHistoryOutput> ExportAllBiddingHistoryForAdmin(string prefix)
        {
            var _biddingData = new BiddingAdmin(_fakeDBContext);
            var resultMessage = _biddingData.ExportAllBiddingHistoryForAdmin(prefix);
            return resultMessage;
        }
        #endregion CRUD

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetBidderHistoryOrCurrentBuyers()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            var packages = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount, bidType);

            //act
            var bidderList = GetBidderList(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(bidderList);
            Assert.IsTrue(bidderList.Count == 1);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetTopBidders()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            var packages = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount, bidType);

            //act
            var bidderList = GetTopBidderList(projectFieldValues.Prefix, count);

            //assert
            Assert.IsNotNull(bidderList);
            Assert.IsTrue(bidderList.Count == 1);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetBidderDetailsForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            //act
            var bidderOutput = GetBidderDetailsForAdmin(projectFieldValues.Prefix, bidderFieldValues.BidderXid);

            //assert
            Assert.IsNotNull(bidderOutput);
            Assert.IsTrue(bidderOutput.ProjectXid > 0);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetBidderMaxBidForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            int bidAmount = 20; //setting the current bid amount to 20
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            amount = 100; //sets the max bid amount to 100 for bidder X
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            //act
            var maxBidOutputList = GetBidderMaxBidForAdmin(projectFieldValues.Prefix, bidderFieldValues.BidderXid);

            //assert
            Assert.IsNotNull(maxBidOutputList);
            Assert.IsTrue(maxBidOutputList.Count == 1);
        }


        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetBidderBidHistoryForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            /* adds the bid */
            bidType = CodeLookupConstants.CodeBidType_Bid;
            var packages = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount, bidType);

            //act
            var bidHistoryOutputList = GetBidderBidHistoryForAdmin(projectFieldValues.Prefix, bidderFieldValues.BidderXid);

            //assert
            Assert.IsNotNull(bidHistoryOutputList);
            Assert.IsTrue(bidHistoryOutputList.Count == 1);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetAllBiddersForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);
            decimal amount = 5;

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            var packages = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount, bidType);

            //act
            var bidderList = GetAllBiddersForAdmin(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            //assert
            Assert.IsNotNull(bidderList);
            Assert.IsTrue(bidderList.Count == 1);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetTopPackagesForAdmin()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            bidAmount = 100; //setting the Current Bid amount to 10
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            var packageList = GetTopPackagesList(projectFieldValues.Prefix, count);

            //assert
            Assert.IsNotNull(packageList);
            Assert.IsTrue(packageList.Count > 0);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetAllPackagesForAdmin()
        {
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();

            packageSearchInput.Number = packageFieldValues.Number;
            packageSearchInput.Name = packageFieldValues.Name;

            //act
            var packageList = GetAllPackagesListForAdmin(projectFieldValues.Prefix, packageSearchInput);

            //assert
            Assert.IsNotNull(packageList);
            Assert.IsTrue(packageList.Count > 0);
        }


        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetPackageDetailsForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            //act
            var packageOutput = GetPackageDetailsForAdmin(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(packageOutput);
            Assert.IsTrue(packageOutput.ProjectXid > 0);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetPackageMaxBidForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            int bidAmount = 20; //setting the current bid amount to 20
            var bid = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, bidAmount, bidType);

            //act
            amount = 100; //sets the max bid amount to 100 for bidder X
            var packages = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            //act
            var maxBidOutput = GetPackageMaxBidForAdmin(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(maxBidOutput);
            Assert.IsTrue(maxBidOutput.PackageXid > 0);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetPackageBidHistoryForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            /* adds the bid */
            bidType = CodeLookupConstants.CodeBidType_Bid;
            var packages = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount, bidType);

            //act
            var bidHistoryOutputList = GetPackageBidHistoryForAdmin(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(bidHistoryOutputList);
            Assert.IsTrue(bidHistoryOutputList.Count == 1);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessClearMaxBidForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            amount = 100; //sets the max bid amount to 100 for Bidder X
            var setMaxBid = SetMaxBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount);

            //act
            var deleteMaxBid = ClearMaxBidForAdmin(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(deleteMaxBid);
            Assert.IsTrue(deleteMaxBid.Message == _expectedOutputSuccess.Message);
        }


        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessRemoveBidForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            /* add bid */
            var bid = commonFactory.CreateOrUpdateBid(bidFieldValues);

            //act
            var result = RemoveBidForAdmin(projectFieldValues.Prefix, bid.BidXid, 0);

            //assert
            Assert.IsNotNull(result.Message);
            Assert.IsTrue(result.Message == _expectedOutputSuccess.Message);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessRemoveBidForAdmin_Sale()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            packageFieldValues.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Regular;

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            /* add sale*/
            var sale = commonFactory.CreateOrUpdateSale(saleFieldValues);

            //act
            var result = RemoveBidForAdmin(projectFieldValues.Prefix, 0, sale.SaleID);

            //assert
            Assert.IsNotNull(result.Message);
            Assert.IsTrue(result.Message == _expectedOutputSuccess.Message);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessSaveEmailTemplateForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);

            //act
            var saveEmailTemplate = SaveEmailTemplateForAdmin(projectFieldValues.Prefix, _emailMessageFieldValues);

            //assert
            Assert.IsNotNull(saveEmailTemplate);
            Assert.IsTrue(saveEmailTemplate.Message == _expectedOutputSuccess.Message);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetEmailTemplatesForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);

            //act
            var saveEmailTemplate = SaveEmailTemplateForAdmin(projectFieldValues.Prefix, _emailMessageFieldValues);
            var getEmailTemplates = GetEmailTemplatesForAdmin(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(getEmailTemplates);
            Assert.IsTrue(getEmailTemplates.Count == 1);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessDeleteEmailTemplateForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);

            //act
            var saveEmailTemplate = SaveEmailTemplateForAdmin(projectFieldValues.Prefix, _emailMessageFieldValues);
            var deleteEmailTemplate = DeleteEmailTemplateForAdmin(projectFieldValues.ProjectXid, emailTemplateId);

            //assert
            Assert.IsNotNull(deleteEmailTemplate);
            Assert.IsTrue(deleteEmailTemplate.Message == _expectedOutputSuccess.Message);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetSMSTemplatesForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);

            //act
            var saveSMSTemplate = SaveSMSTemplateForAdmin(projectFieldValues.Prefix, _smsMessageFieldValues);
            var getSMSTemplates = GetSMSTemplatesForAdmin(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(getSMSTemplates);
            Assert.IsTrue(getSMSTemplates.Count == 1);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessSaveSMSTemplateForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);

            //act
            var saveSMSTemplate = SaveSMSTemplateForAdmin(projectFieldValues.Prefix, _smsMessageFieldValues);

            //assert
            Assert.IsNotNull(saveSMSTemplate);
            Assert.IsTrue(saveSMSTemplate.Message == _expectedOutputSuccess.Message);
        }        

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessDeleteSMSTemplateForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);

            //act
            var saveSMSTemplate = SaveSMSTemplateForAdmin(projectFieldValues.Prefix, _smsMessageFieldValues);
            var deleteSMSTemplate = DeleteSMSTemplateForAdmin(projectFieldValues.ProjectXid, smsTemplateId);

            //assert
            Assert.IsNotNull(deleteSMSTemplate);
            Assert.IsTrue(deleteSMSTemplate.Message == _expectedOutputSuccess.Message);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessRemoveAllBidsForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            /* add bid */
            var bid = commonFactory.CreateOrUpdateBid(bidFieldValues);

            //act
            var result = RemoveAllBidsForAdmin(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(result.Item1.Message);
            Assert.IsTrue(result.Item1.Message == _expectedOutputSuccess.Message);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessRemoveAllBidsForAdmin_Sale()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            packageFieldValues.MobileBiddingType = CodeLookupConstants.CodeMobileBiddingType_Regular;

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            /* add sale*/
            var sale = commonFactory.CreateOrUpdateSale(saleFieldValues);

            //act
            var result = RemoveAllBidsForAdmin(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(result.Item1.Message);
            Assert.IsTrue(result.Item1.Message == _expectedOutputSuccess.Message);
        }

        [TestCategory("Admin")]
        [TestMethod]
        public void TestDataAccessGetExportAllBiddingHistoryForAdmin()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            /* adds the bid */
            bidType = CodeLookupConstants.CodeBidType_Bid;
            var packages = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount, bidType);

            //act
            var exportBidHistoryOutputList = ExportAllBiddingHistoryForAdmin(projectFieldValues.Prefix);

            //assert
            Assert.IsNotNull(exportBidHistoryOutputList);
            Assert.IsTrue(exportBidHistoryOutputList.Count == 1);
        }
    }
}
