﻿using System.Collections.Generic;
using GreaterGiving.Tokyo.Bidding.DataAccess.Core.Bidding;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Output;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GreaterGiving.Tokyo.UnitTests.DataAccess
{
    [TestClass]
    public class BiddingBidderDataAccessTest
    {
        #region Private Members
        private static ProjectFieldValues projectFieldValues;
        private static BidderFieldValues bidderFieldValues;
        private static PackageFieldValues packageFieldValues;
        private static CommonFactory commonFactory = null;
        private FakeContext _fakeDBContext = new FakeContext();
        private ResultModel expectedSuccessModel = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success002);
        private ResultModel expectedFailModel = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error004);
        private ResultModel expectedNoRecordsDeletedModel = MessageManager.GetResultMessage(MessageCode.NoRecord, MessageCode.Info011);
        private static string bidType;
        private static int amount = 100;

        public BiddingBidderDataAccessTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            projectFieldValues = commonFactory.CreateProjectFieldValues();
            bidderFieldValues = commonFactory.CreateBidderFieldValues();
            packageFieldValues = commonFactory.CreatePackageFieldValues();
            commonFactory.InsertCodeLookupFieldvalues();
        }
        #endregion Private Members

        #region Class Initialize

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
        }
        #endregion Class Initialize

        #region CRUD

        private List<BidderOutput> GetBidderList(string prefix, int packageId)
        {
            var _biddingData = new BiddingBidder(_fakeDBContext);

            var bidderList = _biddingData.GetBidderHistoryOrCurrentBuyers(prefix, packageId);
            return bidderList;
        }

        private Bidder GetBidderByBidderId(int bidderId)
        {
            var _biddingData = new BiddingBase(_fakeDBContext);

            var bidderDetail = _biddingData.GetBidder(bidderId);
            return bidderDetail;
        }
        #endregion

        #region Bidder Public Members Functions

        [TestCategory("Bidder")]
        [TestMethod]
        public void TestDataAccessBidderSuccessInsert()
        {
            //arrange

            //act
            ResultModel resultModel = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            //assert
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Bidder")]
        [TestMethod]
        public void TestDataAccessCreateOrUpdateBidderFail()
        {
            //arrange

            //Added BidderXid and removed bidderFieldValues.OnlineBidderKey since null also working.
            bidderFieldValues.BidderXid = 0;

            //act
            ResultModel resultModel = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            //assert
            Assert.AreEqual(expectedFailModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedFailModel.Reason, resultModel.Reason);
        }

        [TestCategory("Bidder")]
        [TestMethod]
        public void TestDataAccessBidderUpdateSuccess()
        {
            //arrange            
            commonFactory.CreateOrUpdateBidder(bidderFieldValues);//Create bidder
            var beforeUpdate = GetBidderByBidderId(bidderFieldValues.BidderXid);

            Assert.AreEqual(bidderFieldValues.TableNumber, beforeUpdate.TableNumber);//Check before update

            bidderFieldValues.TableNumber = 10; //for update bidder

            //act
            ResultModel resultModel = commonFactory.CreateOrUpdateBidder(bidderFieldValues);
            var afterUpdate = GetBidderByBidderId(bidderFieldValues.BidderXid);

            //assert
            Assert.AreEqual(bidderFieldValues.TableNumber, afterUpdate.TableNumber);

            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Bidder")]
        [TestMethod]
        public void TestDataAccessBidderFailToUpdate()
        {
            //arrange
            commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            //Added BidderXid and removed bidderFieldValues.OnlineBidderKey since null also working.
            bidderFieldValues.BidderXid = 0;

            //act
            ResultModel resultModel = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            //assert            
            Assert.IsNotNull(bidderFieldValues.OnlineBidderKey);
            Assert.AreEqual(expectedFailModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedFailModel.Reason, resultModel.Reason);
        }

        [TestCategory("Bidder")]
        [TestMethod]
        public void TestDataAccessBidderDeleteSuccess()
        {
            //arrange

            //act            
            commonFactory.CreateOrUpdateBidder(bidderFieldValues);//Create Bidder            
            ResultModel resultModel = commonFactory.DeleteBidder(bidderFieldValues.BidderXid);//Delete the created Bidder
            var afterDelete = GetBidderByBidderId(bidderFieldValues.BidderXid);
            //assert
            Assert.IsNull(afterDelete);
            Assert.AreEqual(expectedSuccessModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedSuccessModel.Reason, resultModel.Reason);
        }

        [TestCategory("Bidder")]
        [TestMethod]
        public void TestDataAccessBidderFailToDelete()
        {
            //arrange
            commonFactory.CreateOrUpdateBidder(bidderFieldValues);//Create Bidder
            bidderFieldValues.BidderXid = 10;
            //act
            //Delete a Bidder who does not exist
            ResultModel resultModel = commonFactory.DeleteBidder(bidderFieldValues.BidderXid);

            //assert
            Assert.AreEqual(expectedNoRecordsDeletedModel.ResultCode, resultModel.ResultCode);
            Assert.AreEqual(expectedNoRecordsDeletedModel.Reason, resultModel.Reason);
        }

        [TestCategory("Bidder")]
        [TestMethod]
        public void TestDataAccessGetBidderHistoryOrCurrentBuyers()
        {
            //arrange            
            var project = commonFactory.CreateProject(projectFieldValues);
            var package = commonFactory.CreateOrUpdatePackage(packageFieldValues);
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);

            commonFactory.SetClaimsIdentity(bidderFieldValues);
            commonFactory.UpdatePackageClass();
            commonFactory.SetHttpContext();

            bidType = CodeLookupConstants.CodeBidType_Bid;
            var packages = commonFactory.AddBid(projectFieldValues.Prefix, packageFieldValues.PackageXid, amount, bidType);
          

            //act
            var bidderList = GetBidderList(projectFieldValues.Prefix, packageFieldValues.PackageXid);

            //assert
            Assert.IsNotNull(bidderList);
            Assert.IsTrue(bidderList.Count == 1);
        }
        
        #endregion Bidder Public Members Functions
    }
}
