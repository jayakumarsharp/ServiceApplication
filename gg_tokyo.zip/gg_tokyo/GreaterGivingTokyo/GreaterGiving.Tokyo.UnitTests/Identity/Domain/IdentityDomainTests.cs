﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GreaterGiving.Tokyo.UnitTests.Identity.Domain
{
    [TestClass]
    public class IdentityDomainTests
    {
        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {

        }

        [ClassCleanup]
        public static void CleanupClass()
        {
        }

        [TestInitialize]
        public void InitializeTest()
        {
        }

        [TestCleanup]
        public void CleanupTest()
        {
        }
    }
}
