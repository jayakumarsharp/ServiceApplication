﻿using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Identity.DataAccess.Core.Identity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GreaterGiving.Tokyo.UnitTests.DataAccess
{
    [TestClass]
    public class IdentityDataAccessTest
    {
        #region Private Members
        private static BidderLogin bidderLogin;
        private static string onlinebidderKey = "12345";
        private static CommonFactory commonFactory;
        public static BidderFieldValues bidderFieldValues;
        public static ProjectFieldValues projectFieldValues;
        private FakeContext _fakeDBContext = new FakeContext();
        private BidderInfo expectedSuccessModel = new BidderInfo { BidderToken = "Token", Number = 123, OnlineBidderKey = "12345", SupporterName = "Bidder Name 1", TableNumber = 3 };

        #endregion Private Members

        public IdentityDataAccessTest()
        {
            commonFactory = new CommonFactory(_fakeDBContext);
            bidderFieldValues = commonFactory.CreateBidderFieldValues();
            projectFieldValues = commonFactory.CreateProjectFieldValues();
            commonFactory.InsertCodeLookupFieldvalues();
        }

        #region Class Initialize

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            //Input model
            bidderLogin = new BidderLogin();
            bidderLogin.OnlineBidderKey = "12345";
            bidderLogin.BidderToken = "Token";
        }
        #endregion Class Initialize

        #region CRUD
        private BidderInfo Authenticate(string onlineBidderKey)
        {
            var _identityData = new IdentityBidder(_fakeDBContext);

            BidderInfo model = _identityData.Authenticate(onlineBidderKey);

            return model;
        }

        #endregion

        #region Bidder Public Members Functions

        [TestCategory("Identity")]
        [TestMethod]
        public void TestDataAccessAuthenticateSuccess()
        {
            //arrange
            commonFactory = new CommonFactory(_fakeDBContext);

            //act
            var bidder = commonFactory.CreateOrUpdateBidder(bidderFieldValues);
            var project = commonFactory.CreateProject(projectFieldValues);
            var resultModel = Authenticate(onlinebidderKey);

            //assert

            Assert.AreEqual(expectedSuccessModel.Number, resultModel.Number);
            Assert.AreEqual(expectedSuccessModel.SupporterName, resultModel.SupporterName);
        }


        #endregion Bidder Public Members Functions
    }
}
