﻿using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Identity.Domain.Contracts;
using GreaterGiving.Tokyo.IdentityService.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Net.Http;

namespace GreaterGiving.Tokyo.UnitTests.Bidding.Services
{
    [TestClass]
    public class IdentityControllerTest
    {
        #region private members

        private static BidderInfo _expectedOutputSuccess = new BidderInfo { Number = 0, SupporterName = "Name", TableNumber = 0, BidderToken = "xk34iylywToken" };
        private static string onlineBidderKey = "xylqkhd";

        #endregion private members

        #region class initialize

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            onlineBidderKey = "xk34iylyw";
        }

        #endregion class initialize

        #region Authentication Token

        [TestMethod]
        public void TestCreateTokenSuccess()
        {
            //arrange
            var mockIdentityDomain = new Mock<IIdentityDomain>();
            
            var controller = new IdentityController(mockIdentityDomain.Object);
            
            mockIdentityDomain.Setup(i => i.Authenticate(onlineBidderKey)).Returns(_expectedOutputSuccess);

            //act
            var actionResult = controller.CreateToken(onlineBidderKey);

            //assert
            Assert.IsNotNull(actionResult);
        }

        #endregion Authentication Token
    }

}
