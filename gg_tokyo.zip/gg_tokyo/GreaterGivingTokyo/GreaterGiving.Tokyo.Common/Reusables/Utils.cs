﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace GreaterGiving.Tokyo.Common.Reusables
{
    public static class Utils
    {
        public static string GetTimeString(float hours)
        {
            return TimeSpan.FromHours(hours).ToString("hh:mm");
        }

        /// <summary>
        /// Gets the current user's info values
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="claimType"></param>
        /// <returns></returns>
        public static T GetBidderInfoValue<T>(string claimType, ClaimsIdentity claimIdentity, T defaultValue = default(T))
            where T : IConvertible
        {
            T bidderInfoValue = defaultValue;

            try
            {
                var claimsIdentity = claimIdentity as ClaimsIdentity;

                if (claimsIdentity != null)
                {
                    var claim = claimsIdentity.Claims.Where(c => c.Type.Equals(claimType, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

                    bidderInfoValue = claim != null ? (T)Convert.ChangeType(claim.Value, typeof(T)) : bidderInfoValue;
                }
            }
            catch (Exception ex)
            { }

            return bidderInfoValue;
        }

        /// <summary>
        /// Sets the string[] Email id's or Phone numbers string to array with specified delimiters.
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="delimiter"></param>
        /// <returns>outputList string</returns>
        public static string ConcatStringWithDelimiters(string[] inputStr, string delimiter)
        {
            var outputList = "";
            if (inputStr != null)
            {
                outputList = string.Join(delimiter, inputStr
                          .Select(x => x.ToString())
                          .ToArray());
            }

            return outputList;
        }

        #region ExceptionFilter

        public static string GetCompleteExceptionString(Exception exc)
        {
            return exc.InnerException != null
                ? GetCompleteExceptionString(exc.InnerException)
                : GetExceptionDetails(exc);
        }

        public static string GetExceptionDetails(Exception exc)
        {
            var sbErrorString = new StringBuilder();

            if (!string.IsNullOrWhiteSpace(exc.Message))
                sbErrorString.AppendFormat("\tMessage: {0}{1}", exc.Message, Environment.NewLine);

            if (!string.IsNullOrWhiteSpace(exc.StackTrace))
                sbErrorString.AppendFormat("\tStackTrace: {0}{1}", exc.StackTrace, Environment.NewLine);

            if (!string.IsNullOrWhiteSpace(exc.Source))
                sbErrorString.AppendFormat("\tSource: {0}{1}", exc.Source, Environment.NewLine);

            return sbErrorString.ToString();
        }
        #endregion ExceptionFilter
    }
}