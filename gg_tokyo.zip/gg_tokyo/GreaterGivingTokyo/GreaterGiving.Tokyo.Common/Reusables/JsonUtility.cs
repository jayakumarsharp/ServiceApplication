﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Dynamic;

namespace GreaterGiving.Tokyo.Bidding.DataAccess.Common
{
    public static class JsonUtility
    {
        /// <summary>
        /// Deserialize the json object with known type
        /// </summary>
        /// <param name="jobject"></param>       
        /// <returns>Deserialize object</returns>
        public static T Deserialize<T>(JObject jobject)
        {
            var serializeObject = JsonConvert.SerializeObject(jobject);
            var deserializeObject = JsonConvert.DeserializeObject<T>(serializeObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            return deserializeObject;
        }

        /// <summary>
        /// Serialize the Model with Json String
        /// </summary>
        /// <param name="Model"></param>       
        /// <returns>Serialize Model</returns>
        public static JObject DeserializeToJobject<T>(T jobject)
        {
            var serializeObject = JsonConvert.SerializeObject(jobject);
            var jsonObject = JsonConvert.DeserializeObject<JObject>(serializeObject);           
            return jsonObject;
        }


        /// <summary>
        /// Serialize the Model with Json String
        /// </summary>
        /// <param name="Model"></param>       
        /// <returns>Serialize Model</returns>
        public static List<JObject> DeserializeListofObjectToJobject<T>(List<T> jobject)
        {
            var serializeObject = JsonConvert.SerializeObject(jobject);
            var jsonObject = JsonConvert.DeserializeObject<List<JObject>>(serializeObject);
            return jsonObject;
        }

        /// <summary>
        /// Deserialize the json object with unknown type
        /// </summary>
        /// <param name="jobject"></param>       
        /// <returns>Deserialize object</returns>
        public static dynamic DeserializeAnonymousType(JObject jobject)
        {
            var serializeObject = JsonConvert.SerializeObject(jobject);
            var deserializeObject = JsonConvert.DeserializeObject<ExpandoObject>(serializeObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            return deserializeObject;
        }

        public static JObject GetJObjectRequiredOutput<T>(T jobject,string[] strArray)
        {
            var serializeObject = JsonConvert.SerializeObject(jobject);
            JObject jsonObject = JObject.Parse(serializeObject);
            foreach(var arr in strArray)
                jsonObject.Remove(arr);

            return jsonObject;
        }

    }
}
