/**
 * Created by Srigars
 * 
 * For js and css minifications
 * jsHint used for validate the standards(comma,braces,etc..)
 */

module.exports = function(grunt) {
  
  grunt.initConfig({
  	    
  	karma: {
  		 unit: {
		    configFile: 'karma.conf.js',
		    singleRun: true
		 }
  	},
  	
    uglify: {
      target: {
        files: {
          'dist/via.min.js': [ 'scripts/app.js','scripts/*.js']
        },
        options: {
          mangle: true
        }
      }
    },
    
    cssmin : {
		target: {
		    files: {
		      'dist/via.min.css': ['css/*.css']
		    }
		}
	},
	
	jshint: {
	  all: ['grunt.js', 'js/*.js'],
	  options: {
	    curly: true,
	    eqeqeq: false,
	    eqnull: true,
	  }
	}  });
  
  require('load-grunt-tasks')(grunt);
  
  grunt.registerTask('default', ['karma','jshint','uglify','cssmin']);
  
 };