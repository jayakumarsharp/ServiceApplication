describe('login controller', function() {
	
    beforeEach(module('via'));
	
    var ctrlr, scope;

	// inject the $controller and $rootScope services
	beforeEach(inject(function($controller, $rootScope) {
		// Create a new scope that's a scope for the controller
	    scope = $rootScope.$new();

	    // Create the controller
	    ctrlr = $controller('LoginController', {
			$scope: scope
	    });
	}));
	
	it('validate positive scenario', function() {
		scope.userInfo.userName = 'UserName';
		scope.userInfo.password = 'Password';
		
		scope.validation();
		expect(scope.message).toBe('Success');
	});	
});