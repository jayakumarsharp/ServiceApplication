app.controller('AppController', ['$scope', '$state', '$translate', 'LoginService', 'localStorageService',
function($scope, $state, $translate, LoginService, localStorageService) {

	/**
	 *Declarations
	 */
	$scope.logoutTemplate = "logoutTemplate";
	$scope.userInfo = localStorageService.get('userInfo');
	$scope.agencyLogos = ["Logo", "Logo", "Logo", "Logo", "Logo", "Logo", "Logo", "Logo", "Logo"];

	/**
	 * Changing language(Loalization)
	 */
	$scope.localization = function(language) {
		$translate.use(language);
	};

	/**
	 * Do Logout
	 */
	$scope.doLogout = function() {
		LoginService.logout().then(function() {
			$state.go('login');
		});
	};

	/**
	 * Auto Logout,if idle for certain time
	 */
	$scope.$on('IdleTimeout', function() {
        $state.go('login');
    });

	/**
	 * Slider action configuration
	 */
	var container = document.documentElement;
	var toggle_nav = document.querySelectorAll('.toggle-nav');

	for (var i = 0,len = toggle_nav.length; i < len; i++) {
		toggle_nav[i].addEventListener('click', toggleMenu, false);
	}
	
	document.querySelector('#main').addEventListener('click', function() {
		if (container.classList.contains('show-nav') || container.classList.contains('show-agency')) {
			container.classList.remove('show-nav');
			document.querySelector('.toggle-subnav').click();
		}
	});

	document.querySelector('.toggle-subnav').addEventListener('click', function(e) {
		e.stopPropagation();
		if (document.querySelector('.popover.agency')) {
			container.classList.remove('show-agency');
			document.querySelector('.user-image').click();
		}
	});
	function toggleMenu(e) {
		e.stopPropagation();
		container.classList.toggle('show-nav');
		container.classList.remove('show-agency');
		if (document.querySelector('.popover.agency')) {
			document.querySelector('.user-image').click();
		}
		e.preventDefault();
		return false;
	}

	/*End of Slider action configuration*/

	/*Close Popover on outside body click*/
	document.querySelector('#main').addEventListener('click', function(event) {
		var selectedElement = event.target || event.srcElement;
		if (document.querySelectorAll('.popover').length > 0 && !selectedElement.dataset.hasOwnProperty('popover')) {
			for (var i = 0; i < document.querySelectorAll('[popover-template]').length; i++) {
				document.querySelectorAll('[popover-template]')[i].click();
			}
		}
	});

	document.querySelector('.nav .user-image').addEventListener('click', function() {
		if (!document.querySelector('.popover.agency')) {
			container.classList.add('show-agency');
		} else {
			container.classList.remove('show-agency');
		}
	});
}]);
