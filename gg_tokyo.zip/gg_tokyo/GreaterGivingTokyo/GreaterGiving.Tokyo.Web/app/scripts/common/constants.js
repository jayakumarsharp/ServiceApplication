/**
 * Application constants 
 */
app.service('AppConstants',[ function() {
	return {
		/**
		 * These values need to be change while moved to testing environment 
		 * as well production environment
		 */
		/*Parent Module Service Configuration*/
		identityServiceURL: "http://pc1588:11000/API/Identity/",
        adminServiceURL: "http://pc1588:8080/CDMVIAADMIN/api/admin/",
        workflowServiceURL: "http://192.168.20.137:22000/API/Workflow/",
        reportingServiceURL: "http://192.168.20.137:23000/API/Reporting/",

        authToken: 'ViaScheme',
		
		/*Service url for across the application*/
		serviceUrls : {
			login: 'login', 
			domainList: 'domains',
			logout: 'logout'
		}
		
		//Need to include other constants which will use across the application
		//like success/error messages,etc.
	};
}]);
