/**
 * Created by Srigars
 * 
 * Common message handler for the application 
 */
'use strict';
app.factory('ErrorHandler',['$state', function($state) {
	
	var msgHandler = {};
	
	/**
	 *Don't consider this,messages will from the locale file 
	 */
	/*
	 * All Errorcodes need to bind here.
	 * Need to get these from file.
	 */
	msgHandler.errorCodes = {
		"VIA.0.0.0.0":"System Error"
	};
	
	msgHandler.getErrors = function(data,status) {
		if (status === 401) {
			//Redirect to login page,need display the alert like "Autorization failed".Possible scenario is token expiration.
			return;
		}
		
		return msgHandler.errorCodes[data] === undefined ? 'Unknown Error' : msgHandler.errorCodes[data];  
	};
	
	//Success handler function - Need to be discuss with anand/sriram
	
	return msgHandler;
}]);