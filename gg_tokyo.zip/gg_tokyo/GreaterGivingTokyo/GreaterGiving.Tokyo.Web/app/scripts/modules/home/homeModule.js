var home = angular.module('home', []);

home.config(['$stateProvider', '$urlRouterProvider',
	function($stateProvider, $urlRouterProvider) {
	
	$stateProvider.state('app.home',{
		url: 'home',
		templateUrl: 'app/views/home/homeScreen.html'
	});
}]);
