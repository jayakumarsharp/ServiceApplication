var job = angular.module('job', []);

job.config(['$stateProvider', '$urlRouterProvider',
	function($stateProvider, $urlRouterProvider) {
	
	$stateProvider.state('app.job',{
		url: 'job',
		templateUrl: 'app/views/job/job.html'
	});
}]);