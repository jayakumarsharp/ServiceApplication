job.factory('JobsService', ['Restangular', function(Restangular) {
	
	Restangular.setBaseUrl(AppConstants.adminServiceURL);
	
	var service = {};
	
	/*Sample for get service*/
	service.getFile = function() {
		return Restangular.all('Users').doGET();
	};
	
	/*Sample for post service*/
	service.doPost = function() {
		return Restangular.all('testPost').doPOST({FirstName:'Srigar',LastName:'S'});
	};
	
	return service;
}]);
