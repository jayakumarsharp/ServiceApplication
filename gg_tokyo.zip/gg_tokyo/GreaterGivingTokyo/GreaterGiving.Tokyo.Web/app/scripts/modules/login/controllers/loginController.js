login.controller('LoginController', ['$scope', '$state', '$window', 'Restangular', 'LoginService', 'localStorageService', '$translate',
	function($scope, $state, $window, Restangular, LoginService, localStorageService, $translate) {

	/**
	 * Declarations 
	 */	
	$scope.isInvalidLogin = false;
	$scope.errorMessage = null;
	$scope.userInfo = {
		userName: null,
		password: null,
		domain: null
	};
	sessionStorage.removeItem('token');
	
	/**
	 * Login service - POST
	 */
	$scope.doLogin = function(form) {
		var splitByDomain = [];
		
		/*Validation for invalid request*/
		if(form.$invalid) {
			return;
		}
		
		if ($scope.userInfo.userName.indexOf("\\") > -1) {
			splitByDomain = $scope.userInfo.userName.split("\\");
			$scope.userInfo.userName = splitByDomain[1];
			$scope.userInfo.domain = splitByDomain[0];
		}
		
		LoginService.login($scope.userInfo).then(
			function(data) {
				sessionStorage.setItem('token',data.UserToken);
				localStorageService.set('userInfo',data);
				$state.go('app.home');
			},
			function(response) {
				$scope.isInvalidLogin = true;
				$scope.errorMessage = $translate.instant(response.data.Message);
				if($scope.errorMessage === null || $scope.errorMessage === '' || angular.isUndefined($scope.errorMessage)) {
					$scope.errorMessage = "Invalid Login - Contact Administrator";
					return;
				}
			}	
		);
	};
	
	$scope.validateSpecialCharacter = function(event) {
		if (event.which === 92 && $scope.userInfo.userName && $scope.userInfo.userName.indexOf("\\") > -1) {
			event.preventDefault();
		}
	};
}]);
