var login = angular.module('login', []);

login.config(['$stateProvider', '$urlRouterProvider',
	function($stateProvider, $urlRouterProvider) {
	
	/**
	 * Login Routing configuration will bind here.Example forgot password,create user,etc.
	 */
	$stateProvider.state('login', {
   		url: '/login',
   		templateUrl: 'app/views/login/login.html',
   		controller: 'LoginController'
   	});
}]);
