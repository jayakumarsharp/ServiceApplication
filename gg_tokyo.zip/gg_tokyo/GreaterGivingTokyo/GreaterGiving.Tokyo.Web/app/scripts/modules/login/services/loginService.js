login.factory('LoginService', ['Restangular', 'AppConstants', function(Restangular, AppConstants) {
	
	Restangular.setBaseUrl(AppConstants.identityServiceURL);
	
	var loginService = {};
	
	/**
	 * Get Domain List 
	 */
	loginService.domainList = function() {
		return Restangular.all(AppConstants.serviceUrls.domainList).doGET();
	};
	
	/**
	 * Do Login - POST 
	 */
	loginService.login = function(data) {
		return Restangular.one(AppConstants.serviceUrls.login).doPOST(data);
	};
	
	/**
	 * Do Logout - GET 
	 */
	loginService.logout = function() {
		return Restangular.all(AppConstants.serviceUrls.logout).doGET();
	};
	
	return loginService;
}]);
