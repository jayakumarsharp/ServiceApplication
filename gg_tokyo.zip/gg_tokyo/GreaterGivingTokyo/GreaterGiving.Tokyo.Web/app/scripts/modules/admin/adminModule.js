var admin = angular.module('admin',[]);

admin.config(['$stateProvider', '$urlRouterProvider', 
	function($stateProvider, $urlRouterProvider){
	
}]);
