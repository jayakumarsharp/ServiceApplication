admin.factory('AdminService', ['Restangular', 'AppConstants', 
	function(Restangular, AppConstants) {
	
}]);