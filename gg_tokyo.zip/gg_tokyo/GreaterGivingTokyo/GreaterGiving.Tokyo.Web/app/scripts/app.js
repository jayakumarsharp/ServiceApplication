var app = angular.module('via', [
	 'ui.router', 
	 'pascalprecht.translate', 
	 'restangular',
	 'ui.bootstrap',
	 'LocalStorageModule',
	 'ngIdle',

	 //App Modules
	 'home', 
	 'login', 
	 'job',
	 'admin'
]);

app.config(['$stateProvider', '$urlRouterProvider', 'localStorageServiceProvider',
	function ($stateProvider, $urlRouterProvider, localStorageServiceProvider) {
	
	/**
	 * Parent routing will be configured here.
	 * For all the submodule parent will be app.html and appController
	 */
	$urlRouterProvider.otherwise('login');
	
	$stateProvider.state('app', {
   		url: '/app',
   		templateUrl: 'app/views/app.html',
   		controller: 'AppController'
   	});
   	
   	localStorageServiceProvider.setStorageType('sessionStorage');
}]);

/*
 * App Config for internationalization
 */
app.config(['$translateProvider', function($translateProvider) {

	//Loading locale based on language
	$translateProvider.useStaticFilesLoader({
		prefix: 'app/locales/',
		suffix: '.json'
	});

	$translateProvider.preferredLanguage('en-US');
}]);

/*
 * App Config for Restangular
 */
app.config(['RestangularProvider',function(RestangularProvider) {

	/*Request Interceptor to add header token*/
	RestangularProvider.addRequestInterceptor(function (element, operation, what, url) {
		var skipAuthentication = ["domains","login"];
		var isUrlExist = false;
		for(var i = 0; i < skipAuthentication.length; i++) {
			if(url.indexOf(skipAuthentication[i]) > -1) {
				isUrlExist = true;
				break;
			}
		}
		if(!isUrlExist) {
			RestangularProvider.setDefaultHeaders({ Authorization: sessionStorage.getItem('token')});
		}
		return element;
	});
}]);

/*
 * App Config for Idle
 */
app.config(['IdleProvider','KeepaliveProvider',function(IdleProvider, KeepaliveProvider) {
	  IdleProvider.idle(25);
}]);

/*
 * App Init Configurations
 */
app.run(['$rootScope', '$state', 'Idle', function($rootScope, $state, Idle) {
    $rootScope.$on('$stateChangeSuccess', function() {
        // possible to have session key  ex. login to  app, open app in new tab
        if(!sessionStorage.getItem('token')) {
        	//redirect to login
        	$state.go('login');
        } else {
        	//Start watching idle after enter into the application
        	Idle.watch();
        }
    });
}]);

/* Enabling Button Active State Support on iOS */
window.onload = function() {
	if (/iP(hone|ad)/.test(window.navigator.userAgent)) {
		document.body.addEventListener('touchstart', function() {
		}, false);
	}
}; 