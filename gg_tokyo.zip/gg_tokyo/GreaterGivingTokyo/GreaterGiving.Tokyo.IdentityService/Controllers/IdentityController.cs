﻿using GreaterGiving.Tokyo.Bidding.DataAccess.Common;
using GreaterGiving.Tokyo.CrossCutting.Exceptions;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.Identity.Domain.Contracts;
using System.Web.Http;

namespace GreaterGiving.Tokyo.IdentityService.Controllers
{
    /// <summary>
    /// Identity Controller
    /// </summary>
    /// <returns></returns>
    [TokyoExceptionFilter, LogAspect, RoutePrefix("Identity/API")]
    public class IdentityController : IdentityControllerBase
    {
        #region Constructors

        /// <summary>
        /// Constructor IdentityController
        /// </summary>
        public IdentityController()
        {

        }

        /// <summary>
        /// Constructor IdentityController
        /// </summary>
        /// <param name="identityDomain">identityDomain</param>
        public IdentityController(IIdentityDomain identityDomain)
            : base(identityDomain)
        {
        }

        #endregion Constructors

        #region Identity Service Methods

        /// <summary>
        /// Create Token for Bidder and returns token, if the onlineBidderKey is available
        /// </summary>
        /// <param name="onlineBidderKey">onlineBidderKey</param>
        /// <returns>IHttpActionResult></returns>
        [Route("Login")]
        [HttpGet]
        public IHttpActionResult CreateToken(string onlineBidderKey)
        {
            var bidder = IdentityDomain.Authenticate(onlineBidderKey);
            if (bidder != null)
            {
                var ignoreFields = new string[] { "OnlineBidderKey", "SupporterName", "Number", "TableNumber", "Prefix" };

                var jsonBidder = JsonUtility.GetJObjectRequiredOutput(bidder, ignoreFields);

                return Ok(jsonBidder);
            }
            else
                return Unauthorized();
        }

        /// <summary>
        /// Create Token for Application and returns token, if the supplied key matches with web.config APPTokenKey
        /// </summary>
        /// <param name="key">key</param>
        /// <returns>IHttpActionResult</returns>
        [Route("CreateAppToken")]
        [HttpGet]
        public IHttpActionResult CreateAppToken(string key)
        {
            var token = IdentityDomain.AuthenticateApp(key);
            if (!string.IsNullOrEmpty(token))
            {
                return Ok(token);
            }
            else
                return Unauthorized();
        }

        /// <summary>
        /// Create Token for Admin Application and returns token, if the supplied username(prefix) and password matches with database
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="password">password</param>
        /// <returns>IHttpActionResult</returns>
        [Route("CreateAdminToken")]
        [HttpGet]
        public IHttpActionResult CreateAdminToken(string userName, string password)
        {
            var projectInfo = IdentityDomain.AuthenticateAdmin(userName, password);
            if (projectInfo != null)
            {
                var ignoreField = new string[] { "Prefix" };

                var jsonProject = JsonUtility.GetJObjectRequiredOutput(projectInfo, ignoreField);

                return Ok(jsonProject);
            }
            else
                return Unauthorized();
        }

        #endregion Identity Service Methods
    }
}
