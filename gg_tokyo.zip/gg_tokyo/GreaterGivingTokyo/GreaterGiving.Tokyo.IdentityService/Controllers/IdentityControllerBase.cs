﻿using GreaterGiving.Tokyo.CrossCutting.Crypto;
using GreaterGiving.Tokyo.Foundation.Container;
using GreaterGiving.Tokyo.Foundation.Contracts;
using GreaterGiving.Tokyo.GatewayManager.Common;
using GreaterGiving.Tokyo.Identity.DataAccess.Contracts;
using GreaterGiving.Tokyo.Identity.Domain.Contracts;
using GreaterGiving.Tokyo.Identity.Domain.Factory;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Web.Http;

namespace GreaterGiving.Tokyo.IdentityService.Controllers
{
    public abstract class IdentityControllerBase : ApiController
    {
        #region Fields & Constants

        // Only for Test; this can be removed later
        private IIdentityDomain _identityDomain;

        [Import]
        private Lazy<IIdentityDomain> _lazyIdentityDomain;

        #endregion Fields & Constants

        #region Properties

        protected IIdentityDomain IdentityDomain
        {
            get
            {
                return _identityDomain ?? (_identityDomain = _lazyIdentityDomain.Value);
            }
        }

        #endregion Properties

        #region Constructors

        protected IdentityControllerBase()
        {
            TokyoContainer.ComposeContainer(this, typeof(IIdentityDomain), typeof(IIdentityData), typeof(IFoundation));
        }

        protected IdentityControllerBase(IIdentityDomain identityDomain)
        {
            _identityDomain = identityDomain;
        }

        #endregion Constructors
      
    }
}
