﻿using System.ComponentModel.Composition.Hosting;
using System.Web.Http;
using System.Web.Http.Cors;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.Foundation.Container;
using GreaterGiving.Tokyo.Foundation.Contracts;

namespace GreaterGiving.Tokyo.IdentityService
{
    public static class WebApiConfig
    {
        private static CompositionContainer _container;

        #region Core Method

        public static void Register(HttpConfiguration config)
        {
            _container = _container ?? TokyoContainer.ComposeContainer(new object(), typeof(IFoundation));
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            ConfigureCors(config);

            config.Routes.MapHttpRoute("DefaultApi", "api/{controller}/{id}", new { id = RouteParameter.Optional }
                );
        }

        #endregion Core Method

        #region Private Helpers

        private static void ConfigureCors(HttpConfiguration config)
        {
            var cors = new EnableCorsAttribute(ConfigManager.AllowedOriginsList, "*", "GET, POST, PUT, DELETE, OPTIONS");
            config.EnableCors(cors);
        }

        #endregion Private Helpers
    }
}
