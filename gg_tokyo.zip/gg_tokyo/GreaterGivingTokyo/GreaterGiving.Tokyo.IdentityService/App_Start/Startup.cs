﻿using System.Web.Http;
using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(GreaterGiving.Tokyo.IdentityService.Startup))]

namespace GreaterGiving.Tokyo.IdentityService
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();

            // Configure Swagger
            SwaggerConfig.Register(config);

            // Register routes, filters etc.
            WebApiConfig.Register(config);
            
            // Allow WebAPI to un on top of OWIN
            app.UseWebApi(config);
        }
    }
}
