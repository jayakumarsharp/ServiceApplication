﻿using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Foundation.Contracts;
using System;
using System.ComponentModel.Composition;
using System.Security.Claims;

namespace GreaterGiving.Tokyo.Foundation.Identity
{
    [Export(typeof(IClaimsManager)), PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class ClaimsManager : IClaimsManager
    {
        /// <summary>
        /// Returns a ClaimsIdentity from the specified UserInfo object
        /// </summary>
        /// <param name="user"></param>
        /// <returns>ClaimsIdentity</returns>
        ClaimsIdentity IClaimsManager.GetIdentity(BidderInfo bidder)
        {
            // New claims for a newly logged-in user
            return new ClaimsIdentity(new Claim[]
                        {
                            new Claim(ClaimTypes.Name, bidder.SupporterName.ToString().Trim()),
                            new Claim(ClaimTypes.NameIdentifier, bidder.Number.ToString().Trim()),
                            new Claim(ClaimTypes.UserData, bidder.TableNumber.ToString().Trim()),
                            new Claim(ClaimTypes.Sid, bidder.OnlineBidderKey.ToString().Trim()),
                            new Claim(ClaimTypes.PrimarySid, bidder.Prefix.ToString().Trim())
                        });
        }

        /// <summary>
        /// Returns a ClaimsIdentity from the App Key
        /// </summary>
        /// <param name="key"></param>
        /// <returns>ClaimsIdentity</returns>
        ClaimsIdentity IClaimsManager.GetAppIdentity(string key)
        {
            // New claims for App
            return new ClaimsIdentity(new Claim[]
                        {
                            new Claim(ClaimTypes.Name, "App"),
                            new Claim(ClaimTypes.UserData, DateTime.UtcNow.ToString("yyyyMMddHHmmss"))
                        });
        }

        /// <summary>
        /// Returns a ClaimsIdentity from the Project Details
        /// </summary>
        /// <param name="prefix"></param>
        /// <returns>ClaimsIdentity</returns>
        ClaimsIdentity IClaimsManager.GetAdminIdentity(string prefix)
        {
            // New claims for Admin
            return new ClaimsIdentity(new Claim[]
                        {
                            new Claim(ClaimTypes.Name, prefix),
                            new Claim(ClaimTypes.UserData, DateTime.UtcNow.ToString("yyyyMMddHHmmss"))
                        });
        }

    }
}
