﻿using GreaterGiving.Tokyo.Foundation.Contracts;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Security.Claims;

namespace GreaterGiving.Tokyo.Foundation.Identity
{
    [Export(typeof(IClaimsTransformer)), PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class ClaimsTransformer : IClaimsTransformer
    {
        /// <summary>
        /// Transforms the claims in the incoming Principal, and returns a Principal with the transformed claims
        /// </summary>
        /// <param name="incomingPrincipal"></param>
        /// <returns></returns>
        ClaimsPrincipal IClaimsTransformer.Transform(ClaimsPrincipal incomingPrincipal, IDictionary<string, string> permissions)
        {
            if (permissions != null && permissions.Any())
                foreach (var item in permissions)
                    (incomingPrincipal.Identity as ClaimsIdentity).AddClaim(new Claim("Permission", item.Key + ":" + item.Value));

            return incomingPrincipal;
        }
    }
}
