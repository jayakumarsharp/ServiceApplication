﻿using GreaterGiving.Tokyo.Common.Reusables;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.Foundation.Contracts;
using System;
using System.ComponentModel.Composition;
using System.Configuration;
using System.IdentityModel.Protocols.WSTrust;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using System.Security.Claims;
using GreaterGiving.Tokyo.Entities.Models;

namespace GreaterGiving.Tokyo.Foundation.Identity
{
    [Export(typeof(ITokenHandler)), PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class TokenHandler : ITokenHandler
    {
        #region Private Fields & Constants

        private ICertificateManager _certificateManager;

        #endregion Private Fields & Constants

        #region Constructors

        [ImportingConstructor]
        public TokenHandler(ICertificateManager certificateManager)
        {
            _certificateManager = certificateManager;
        }

        #endregion Constructors

        #region Main Methods

        /// <summary>
        /// Creates a JWT token for the specified claims identity
        /// </summary>
        /// <param name="claimsIdentity">User Identity</param>
        /// <returns>JSON Compact serialized format string token</returns>
        TokenInfo ITokenHandler.CreateToken(ClaimsIdentity claimsIdentity)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken token = null;
            TokenInfo tokeninfo = new TokenInfo();
            try
            {
                var now = DateTime.UtcNow;
                
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = claimsIdentity,
                    TokenIssuerName = AppConstants.ValidIssuer,
                    AppliesToAddress = AppConstants.ValidAudience,
                    Lifetime = new Lifetime(now, now.AddMinutes(Convert.ToDouble(ConfigurationManager.AppSettings["TokenExpirationTimeInMinutes"]))),
                    SigningCredentials = new X509SigningCredentials(_certificateManager.FindX509Certicate())
                };


                token = tokenHandler.CreateToken(tokenDescriptor);

                tokeninfo.Token = tokenHandler.WriteToken(token);
                tokeninfo.ValidTo = token.ValidTo;

                return tokeninfo;

            }
            catch(Exception ex)
            {
                Logger.WriteErrorLog(string.Format("Error: {0}", Utils.GetCompleteExceptionString(ex)));
            }

            return tokeninfo;
        }

        /// <summary>
        /// Validates the specified string token
        /// </summary>
        /// <param name="jsonCompactToken">JSON Compact serialized string token</param>
        /// <returns>Current user principal context</returns>
        ClaimsPrincipal ITokenHandler.ValidateToken(string jsonCompactToken)
        {
            // Ref: http://stackoverflow.com/questions/25693798/jwtsecuritytokenhandler-and-tokenvalidationparameters

            var tokenHandler = new JwtSecurityTokenHandler();
            var signingCert = _certificateManager.FindX509Certicate();
            var x509SecurityToken = new X509SecurityToken(signingCert);

            ClaimsPrincipal claimsPrincipal = null;

            var validationParameters = new TokenValidationParameters
            {
                ValidAudience = AppConstants.ValidAudience,
                IssuerSigningToken = x509SecurityToken,
                ValidIssuer = AppConstants.ValidIssuer,
                CertificateValidator = X509CertificateValidator.None,
                RequireExpirationTime = true
            };

            SecurityToken jwtSecurityToken;

            try
            {
                claimsPrincipal = tokenHandler.ValidateToken(jsonCompactToken, validationParameters, out jwtSecurityToken);
            }
            catch (Exception ex)
            {
                claimsPrincipal = null;
            }

            return claimsPrincipal;
        }

        #endregion Main Methods
    }
}
