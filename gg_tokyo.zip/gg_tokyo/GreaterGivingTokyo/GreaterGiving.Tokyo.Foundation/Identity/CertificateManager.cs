﻿using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.Foundation.Contracts;
using System;
using System.ComponentModel.Composition;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;

namespace GreaterGiving.Tokyo.Foundation.Identity
{
    [Export(typeof(ICertificateManager)), PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class CertificateManager : ICertificateManager
    {
        /// <summary>
        /// Returns the signing Certificate from the configured store
        /// </summary>
        /// <returns>X509 Certificate</returns>
        X509Certificate2 ICertificateManager.FindX509Certicate()
        {
            X509Store certificateStore = new X509Store(StoreName.My, StoreLocation.CurrentUser);

            try
            {
                certificateStore.Open(OpenFlags.ReadOnly);

                // Ref: http://stackoverflow.com/questions/8448147/problems-with-x509store-certificates-find-findbythumbprint
                var certificateThumprint = Regex.Replace(ConfigManager.CertificateThumbprint, @"[^\da-zA-z]", String.Empty).ToUpper();

                var signingCertCollection = certificateStore.Certificates.Find(X509FindType.FindByThumbprint, certificateThumprint, false);

                //if (signingCertCollection.Count <= 0)
                //    throw new TokyoException(MessageCode.Error90003);

                return signingCertCollection[0];
            }
            finally
            {
                certificateStore.Close();
            }
        }
    }
}
