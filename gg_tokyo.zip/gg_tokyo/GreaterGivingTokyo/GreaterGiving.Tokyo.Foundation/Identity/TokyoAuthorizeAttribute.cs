﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace GreaterGiving.Tokyo.Foundation.Identity
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class TokyoAuthorizeAttribute : AuthorizeAttribute
    {
        protected override bool IsAuthorized(HttpActionContext actionContext)
        {
            // Be pessimistic, at first
            bool authorized = false;

            var controllerName = actionContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            var actionName = actionContext.ActionDescriptor.ActionName;
            var httpVerb = actionContext.Request.Method.Method;
            
            var userIdentity = Thread.CurrentPrincipal.Identity as ClaimsIdentity;

            authorized = (userIdentity.Claims.Any(claim =>
                //(claim.Type == "UnitTest") ||
                    (claim.Type == "ACL" &&
                        String.Equals(claim.Value, String.Format("{0}:{1}", "operation", "action"),
                            StringComparison.CurrentCultureIgnoreCase))));

            //if (!authorized)
            //    throw new ExceptionComponent(MessageCode.Error90002);

            return authorized;
        }
    }
}
