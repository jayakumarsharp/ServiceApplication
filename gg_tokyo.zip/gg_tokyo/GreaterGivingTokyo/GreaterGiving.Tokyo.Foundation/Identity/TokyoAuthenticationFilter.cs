﻿using System;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Filters;
using System.Web.Http.Results;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.CrossCutting.Identity;
using GreaterGiving.Tokyo.Foundation.Container;
using GreaterGiving.Tokyo.Foundation.Contracts;

namespace GreaterGiving.Tokyo.Foundation.Identity
{
    [Export(typeof(IAuthenticationFilter)), PartCreationPolicy(CreationPolicy.NonShared)]
    public sealed class TokyoAuthenticationFilter : Attribute, IAuthenticationFilter
    {
        #region Private Fields & Constants

        private ITokenHandler _tokenHandler;
        private IClaimsTransformer _claimsTransformer;
        private static CompositionContainer _container;
        private const string ProjectPrefix = "prefix";          /* used for checking the key value prefix*/
        private const string AdminSiteRoute = "AdminBidding";   /* Admin Sites */
        private const string BiddingSiteRoute = "SecureBidding"; /* Bidding Application Sites */
        #endregion Private Fields & Constants

        #region Constructors

        public TokyoAuthenticationFilter()
        {
            _container = _container ?? TokyoContainer.ComposeContainer(new object(), typeof(IFoundation));
            _tokenHandler = _container.GetExportedValue<ITokenHandler>();
            _claimsTransformer = _container.GetExportedValue<IClaimsTransformer>();
        }

        [ImportingConstructor]
        public TokyoAuthenticationFilter(ITokenHandler tokenHandler, IClaimsTransformer claimsTransformer)
        {
            _tokenHandler = tokenHandler;
            _claimsTransformer = claimsTransformer;
        }

        #endregion Constructors

        #region IAuthenticationFilter Members

        public async Task AuthenticateAsync(HttpAuthenticationContext context, CancellationToken cancellationToken)
        {
            var req = context.Request;

            // Pull the token string from the Authorization header
            // And, if present, proceed to authenticate
            if (req.Headers.Authorization != null &&
                AppConstants.TokyoScheme.Equals(req.Headers.Authorization.Scheme, StringComparison.CurrentCulture))
            {
                var userToken = req.Headers.Authorization.Parameter;

                var principal = _tokenHandler.ValidateToken(userToken);

                var queryStringParams = req.GetQueryNameValuePairs().ToDictionary(x => x.Key, x => x.Value);

                var requestURL = req.RequestUri.OriginalString;

                // The user token is valid
                if (principal != null && principal.Identity != null && principal.Identity.IsAuthenticated)
                {
                    /* Admin Related  */
                    if (requestURL != null && requestURL.Contains(AdminSiteRoute))
                    {
                        /* used co check whether the prefix exist*/
                        if (queryStringParams.Count > 0 && queryStringParams.ContainsKey(ProjectPrefix))
                        {
                            /* gets the prefix value */
                            var prefixValue = queryStringParams.Where(x => x.Key == ProjectPrefix).Select(item => item.Value.ToLower()).FirstOrDefault();

                            /* Used to check whether the same prefix value exist in the authentication and the input parameter*/
                            if (prefixValue != null && prefixValue.Equals(principal.Identity.Name.ToLower()))
                            {
                                // Set it to the context's Principal
                                context.Principal = Thread.CurrentPrincipal = principal;
                            }
                            /* The request contains invalid token, hence set the error result*/
                            else
                            {
                                context.ErrorResult = new UnauthorizedResult(new AuthenticationHeaderValue[0], context.Request);
                            }
                        }
                        /* The request contains invalid token, hence set the error result*/
                        else
                        {
                            context.ErrorResult = new UnauthorizedResult(new AuthenticationHeaderValue[0], context.Request);
                        }
                    }
                    /* Bidding Application Related  */
                    else if (requestURL != null && requestURL.Contains(BiddingSiteRoute))
                    {
                        /* used co check whether the prefix exist*/
                        if (queryStringParams.Count > 0 && queryStringParams.ContainsKey(ProjectPrefix))
                        {
                            /* gets the prefix value */
                            var prefixValue = queryStringParams.Where(x => x.Key == ProjectPrefix).Select(item => item.Value.ToLower()).FirstOrDefault();

                            Thread.CurrentPrincipal = principal;

                            /* gets the current bidder prefix */
                            var currentBidderPrefix = CurrentBidder.Prefix;

                            /* Used to check whether the same prefix value exist in the authentication and the input parameter*/
                            if (currentBidderPrefix != null && prefixValue != null && prefixValue.Equals(currentBidderPrefix.ToLower()))
                            {
                                // Set it to the context's Principal
                                context.Principal = Thread.CurrentPrincipal;
                            }
                            /* The request contains invalid token, hence set the error result*/
                            else
                            {
                                context.ErrorResult = new UnauthorizedResult(new AuthenticationHeaderValue[0], context.Request);
                            }
                        }
                        else    /* Other than the input parameter prefix */
                        {
                            /* Set it to the context's Principal */
                            context.Principal = Thread.CurrentPrincipal = principal;
                        }
                    }
                    /* The request contains invalid token, hence set the error result*/
                    else
                    {
                        context.ErrorResult = new UnauthorizedResult(new AuthenticationHeaderValue[0], context.Request);
                    }
                }
                /* The request contains invalid token, hence set the error result*/
                else
                {
                    context.ErrorResult = new UnauthorizedResult(new AuthenticationHeaderValue[0], context.Request);
                }
            }
            /* Either the authorization header or the token is absent in the Request header; hence set the error result */
            else
            {
                context.ErrorResult = new UnauthorizedResult(new AuthenticationHeaderValue[0], context.Request);
            }

            await Task.FromResult(0);
        }

        public Task ChallengeAsync(HttpAuthenticationChallengeContext context, CancellationToken cancellationToken)
        {
            context.Result = new ResultWithChallenge(context.Result);

            return Task.FromResult(0);
        }

        bool IFilter.AllowMultiple
        {
            get { return false; }
        }

        #endregion IAuthenticationFilter Members

        #region Private Helpers

        private class ResultWithChallenge : IHttpActionResult
        {
            private readonly IHttpActionResult _next;

            public ResultWithChallenge(IHttpActionResult next)
            {
                _next = next;
            }

            public async Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
            {
                var response = await _next.ExecuteAsync(cancellationToken);

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                    response.Headers.WwwAuthenticate.Add(new AuthenticationHeaderValue(AppConstants.TokyoScheme,
                        "{Missing/Empty/Invalid - Scheme/Token/Authorization header.}"));

                return response;
            }
        }

        #endregion Private Helpers
    }
}
