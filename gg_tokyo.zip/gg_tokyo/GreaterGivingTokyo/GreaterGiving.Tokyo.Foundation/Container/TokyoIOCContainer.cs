using System;
using System.Collections.Generic;

namespace GreaterGiving.Tokyo.Foundation.Container
{
    public class TokyoIocContainer
    {
        private static readonly IDictionary<Type, Dependency> _regdTypes = new Dictionary<Type, Dependency>();

        public void Register<TBase, TType>(TType instance = null,
            TokyoLifeTimeManager lifeTimeManager = TokyoLifeTimeManager.Singleton)
            where TBase : class
            where TType : class, TBase, new()
        {
            _regdTypes[typeof (TBase)] = lifeTimeManager == TokyoLifeTimeManager.Singleton
                ? new Dependency<TBase, TType>
                {
                    ConcreteType = typeof (TBase),
                    ConcreteInstance = (instance ?? new TType())
                }
                : new Dependency<TBase, TType> {ConcreteType = typeof (TBase), ConcreteInstance = null};
        }

        public TBase Resolve<TBase>()
        {
            //return _regdTypes[typeof(TBase)].ConcreteInstance == null ? new TType() : _regdTypes[typeof(TBase)].ConcreteInstance;
            return default(TBase);
        }
    }
}