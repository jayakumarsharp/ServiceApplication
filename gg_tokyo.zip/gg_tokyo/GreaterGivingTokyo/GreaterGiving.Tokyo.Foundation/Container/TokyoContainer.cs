﻿using System;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Reflection;

namespace GreaterGiving.Tokyo.Foundation.Container
{
    public static class TokyoContainer
    {
        public static CompositionContainer ComposeContainer(object instance, params Type[] types)
        {
            var aggCatalog = new AggregateCatalog();

            if (types != null && types.Any())
                foreach (var type in types)
                    aggCatalog.Catalogs.Add(new AssemblyCatalog(Assembly.GetAssembly(type)));

            var container = new CompositionContainer(aggCatalog);
            container.SatisfyImportsOnce(instance ?? new object());
            //container.ComposeParts(instance);

            return container;
        }
    }
}
