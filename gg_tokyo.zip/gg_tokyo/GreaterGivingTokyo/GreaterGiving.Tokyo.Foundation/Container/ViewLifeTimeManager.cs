namespace GreaterGiving.Tokyo.Foundation.Container
{
    public enum TokyoLifeTimeManager
    {
        Singleton,
        NewInstance
    }
}