﻿using System;

namespace GreaterGiving.Tokyo.Foundation.Container
{
    internal abstract class Dependency
    {
        public Type ConcreteType { get; set; }
    }

    internal class Dependency<TAbstract, TConcrete> : Dependency
        where TAbstract : class
        where TConcrete : class, TAbstract, new()
    {
        public TAbstract BaseType { get; set; }
        public TConcrete ConcreteInstance { get; set; }
    }
}
