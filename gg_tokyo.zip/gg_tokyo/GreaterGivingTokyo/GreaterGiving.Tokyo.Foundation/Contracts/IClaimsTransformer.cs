﻿using System.Collections.Generic;
using System.Security.Claims;

namespace GreaterGiving.Tokyo.Foundation.Contracts
{
    public interface IClaimsTransformer : IFoundation
    {
        /// <summary>
        /// Transforms the claims in the incoming Principal, and returns a Principal with the transformed claims
        /// </summary>
        /// <param name="incomingPrincipal"></param>
        /// <returns></returns>
        ClaimsPrincipal Transform(ClaimsPrincipal incomingPrincipal, IDictionary<string, string> permissions);
    }
}
