﻿
namespace GreaterGiving.Tokyo.Foundation.Contracts
{
    public interface IFoundation
    {
    }
}
