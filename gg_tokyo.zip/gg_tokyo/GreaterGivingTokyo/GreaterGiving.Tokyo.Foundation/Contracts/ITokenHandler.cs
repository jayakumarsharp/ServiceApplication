﻿using System.Security.Claims;
using GreaterGiving.Tokyo.Entities.Models;

namespace GreaterGiving.Tokyo.Foundation.Contracts
{
    public interface ITokenHandler : IFoundation
    {
        /// <summary>
        /// Creates a JWT token for the specified claims identity
        /// </summary>
        /// <param name="claimsIdentity">User Identity</param>
        /// <returns>JSON Compact serialized format string token</returns>
        TokenInfo CreateToken(ClaimsIdentity claimsIdentity);

        /// <summary>
        /// Validates the specified string token
        /// </summary>
        /// <param name="jsonCompactToken">JSON Compact serialized string token</param>
        /// <returns>Current user principal context</returns>
        ClaimsPrincipal ValidateToken(string jsonCompactToken);
    }
}
