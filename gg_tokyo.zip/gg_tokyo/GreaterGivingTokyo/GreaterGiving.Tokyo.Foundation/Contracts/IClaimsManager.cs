﻿using GreaterGiving.Tokyo.Entities.Models;
using System.Security.Claims;

namespace GreaterGiving.Tokyo.Foundation.Contracts
{
    public interface IClaimsManager : IFoundation
    {
        /// <summary>
        /// Returns a ClaimsIdentity from the specified bidder object
        /// </summary>
        /// <param name="bidder"></param>
        /// <returns></returns>
        ClaimsIdentity GetIdentity(BidderInfo bidder);

        /// <summary>
        /// Returns a ClaimsIdentity from the specified key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        ClaimsIdentity GetAppIdentity(string key);

        /// <summary>
        /// Returns a ClaimsIdentity from the specified prefix
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        ClaimsIdentity GetAdminIdentity(string prefix);
    }
}
