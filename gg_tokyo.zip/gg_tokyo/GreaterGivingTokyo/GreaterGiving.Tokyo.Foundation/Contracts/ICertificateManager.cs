﻿using System.Security.Cryptography.X509Certificates;

namespace GreaterGiving.Tokyo.Foundation.Contracts
{
    public interface ICertificateManager : IFoundation
    {
        /// <summary>
        /// Returns the signing Certificate from the configured store
        /// </summary>
        /// <returns>X509 Certificate</returns>
        X509Certificate2 FindX509Certicate();
    }
}
