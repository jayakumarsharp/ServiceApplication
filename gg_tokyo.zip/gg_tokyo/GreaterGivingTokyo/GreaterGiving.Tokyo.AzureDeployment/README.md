# Blank Template

This is an empty template, with the schema reference and top-level properties defined.

- SriRam
