﻿using Cdm.Via.CrossCutting.Logging;
using System.ComponentModel.Composition;

namespace Cdm.Via.GatewayManager.Link9
{
    [Export(typeof(ILink9Gateway)), PartCreationPolicy(CreationPolicy.NonShared), LogAspect]
    internal sealed class Link9Gateway : ILink9Gateway
    {
    }
}
