﻿using Cdm.Via.GatewayManager.Common;

namespace Cdm.Via.GatewayManager.Link9
{
    public interface ILink9Gateway : IGateway
    {
    }
}