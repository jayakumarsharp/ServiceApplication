﻿
namespace GreaterGiving.Tokyo.GatewayManager.Common
{
    public interface IGateway
    {
    }
}
