﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using GreaterGiving.Tokyo.Entities.Core;
using GreaterGiving.Tokyo.Entities.Entities;

using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace GreaterGiving.Tokyo.CrossCutting.SMS
{
    public static class SendSMSBatchProcess
    {
        /// <summary>
        /// The startup method
        /// </summary>
        public static void Run()
        {
            // TOK-1170 Twilio SMS Batch Process(Queuing and error handling update for Twilio SMS Text API)
            /*
                -------------------------------------------------------------------------------------
                Pass 1 - Processing of SMS Request whose Status is Pending:
                    1.1 Fetch all the Pending request, which is not processed & retry failed records
                    1.2 Make an Asynchronous call to 3rd party twilio API
                    1.3 Update the corresponding SMS status in SMS Request table asynchronously
                -------------------------------------------------------------------------------------                
            */

            // Execution strategy:
            // 1. Timed execution (i.e., triggered once in 10 Mins)

            //log.Error($"Execution started at: {DateTime.UtcNow.ToString("dd-MMM-yyyy HH:mm:ss")}");

            //SMSProcessor.Log = log;

            // Setup a cancellation source
            var cancellationTokenSource = new CancellationTokenSource(TimeSpan.FromSeconds(SMSProcessor.MaxRunTimeInSeconds));

            Task sendSMSTask = null;

            try
            {
                // Setup threading tasks with the same cancellation token
                sendSMSTask = Task.Factory.StartNew(() => new SendSMS().SendTextMessage(cancellationTokenSource.Token),
                    cancellationTokenSource.Token, TaskCreationOptions.LongRunning, TaskScheduler.Current);

                // Wait for the tasks to complete, before exiting
                sendSMSTask.Wait();
            }
            catch (Exception ex)
            {
                // Oohhh...! That was unexpected!!
                //log.Error($"Oops!! An unexpected error occurred: {exc.Message}");
            }
            finally
            {
                if (cancellationTokenSource != null)
                    cancellationTokenSource.Dispose();

                if (sendSMSTask != null)
                    sendSMSTask.Dispose();

                //log.Error($"Execution finished at: {DateTime.UtcNow.ToString("dd-MMM-yyyy HH:mm:ss")}");
            }
        }

        class SMSProcessor
        {
            private const string CONNECTION_STRING_KEY = "BiddingDBContext";
            private const string MAX_RUN_TIME_IN_SECONDS_KEY = "ExitTimeInSeconds";
            private const string MAX_TRIES_KEY = "MaxTries";
            private const string RETRY_INTERVAL_IN_MIN_KEY = "RetryIntervalInMin";
            private const string BIDDING_API_SERVICE_ENDPOINT_KEY = "BiddingAPIServiceEndpoint";
            private const string TWILIO_SHORT_CODE = "TwilioFromShortCode";
            private const string TWILIO_ACCOUNT_SID = "TwilioAccountSid";
            private const string TWILIO_AUTH_TOKEN = "TwilioAuthToken";
            private const string AES_CRYPTOGRAPHY_PWD_KEY = "AESPassword";
            private const string AES_CRYPTOGRAPHY_SALT_KEY = "AESSalt";
            private const string FETCH_COUNT = "FetchCount";

            // These constants will make way for configurable app settings in the Azure Function App
            private readonly static string _connectionString;
            private readonly static int _maxRunTimeInSeconds;
            private readonly static int _maxTries;
            private readonly static int _retryIntervalInMin;
            private readonly static string _biddingAPIServiceEndpoint; // "http://projecttokyobidding-dev.azurewebsites.net/Bidding/API/UpdateSMSStatus"
            private readonly static string _twilioFromShortCode;
            private readonly static string _twilioAccountSid;
            private readonly static string _twilioAuthToken;
            private static readonly string _aesPassword;
            private static readonly string _aesSalt;
            private static readonly int _fetchCount;

            //public static TraceWriter Log { protected get; set; }

            protected static string ConnectionString { get { return _connectionString; } }

            public static int MaxRunTimeInSeconds { get { return _maxRunTimeInSeconds; } }

            protected static int MaxTries { get { return _maxTries; } }

            protected static int RetryIntervalInMin { get { return _retryIntervalInMin; } }
            
            protected static string BiddingAPIServiceEndpoint { get { return _biddingAPIServiceEndpoint; } }

            protected static string TwilioFromShortCode { get { return _twilioFromShortCode; } }

            protected static string TwilioAccountSid { get { return _twilioAccountSid; } }

            protected static string TwilioAuthToken { get { return _twilioAuthToken; } }

            protected static string AESPassword { get { return _aesPassword; } }

            protected static string AESSalt { get { return _aesSalt; } }

            protected static int FetchCount { get { return _fetchCount; } }

            static SMSProcessor()
            {
                _connectionString = GetConnectionString(CONNECTION_STRING_KEY);

                int maxRunTime = 9 * 60;  // 9 minutes (default)
                int.TryParse(GetConfigValue(MAX_RUN_TIME_IN_SECONDS_KEY, maxRunTime.ToString()), out maxRunTime);
                _maxRunTimeInSeconds = maxRunTime;

                int maxTries = 5;  // 5 (re)tries (default)
                int.TryParse(GetConfigValue(MAX_TRIES_KEY, maxTries.ToString()), out maxTries);
                _maxTries = maxTries;

                int retryIntervalInMin = 1;  // 15 min (default)
                int.TryParse(GetConfigValue(RETRY_INTERVAL_IN_MIN_KEY, retryIntervalInMin.ToString()), out retryIntervalInMin);
                _retryIntervalInMin = retryIntervalInMin;

                int fetchCount = 100;  // 100 (default)
                int.TryParse(GetConfigValue(FETCH_COUNT, fetchCount.ToString()), out fetchCount);
                _fetchCount = fetchCount;

                _biddingAPIServiceEndpoint = GetConfigValue(BIDDING_API_SERVICE_ENDPOINT_KEY, "http://projecttokyobidding-dev.azurewebsites.net/Bidding/API/UpdateSMSStatus");

                _twilioFromShortCode = GetConfigValue(TWILIO_SHORT_CODE, "91049");
                _twilioAccountSid = GetConfigValue(TWILIO_ACCOUNT_SID);
                _twilioAuthToken = GetConfigValue(TWILIO_AUTH_TOKEN);
                _aesPassword = GetConfigValue(AES_CRYPTOGRAPHY_PWD_KEY);
                _aesSalt = GetConfigValue(AES_CRYPTOGRAPHY_SALT_KEY);
            }

            /// <summary>
            /// Returns the value for the specified key from the configuration
            /// </summary>
            /// <param name="key"></param>
            /// <returns></returns>
            private static string GetConfigValue(string key, string defaultValue = "")
            {
                var configValue = defaultValue;

                if (ConfigurationManager.AppSettings.AllKeys.Contains(key))
                    configValue = ConfigurationManager.AppSettings[key].Trim();

                return configValue;
            }

            /// <summary>
            /// Returns the connection string for the specified key from the configuration
            /// </summary>
            /// <param name="connectionStringKey"></param>
            /// <returns></returns>
            private static string GetConnectionString(string connectionStringKey)
            {
                var configValue = string.Empty;

                if (ConfigurationManager.ConnectionStrings[connectionStringKey] != null)
                    configValue = ConfigurationManager.ConnectionStrings[connectionStringKey].ConnectionString;

                return configValue;
            }
        }

        class SendSMS : SMSProcessor
        {
            /// <summary>
            /// Pass 1 - Processing of packages whose Bidding has ended
            /// </summary>
            internal void SendTextMessage(CancellationToken token)
            {
                //Poll to see if a cancellation(graceful shutdown) has been requested / initiated
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        var smsRequests = FetchSMSRequest();

                        //Log.Error($"Fetched {smsRequests.Count()} Records.");
                        if (smsRequests.Any())
                        {
                            foreach (var request in smsRequests)
                            {
                                SendTwilioSMS(request);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //Log.Error($"An error occured in SendTextMessage while sending message to Twilio" + ex.Message);
                    }
                }
            }

            private void UpdateProcessStatus(SMSRequest smsRequest)
            {
                using (var biddingContext = new BiddingContext(ConnectionString))
                {
                    var request = biddingContext.SMSRequests.Where(x => x.SMSRequestID == smsRequest.SMSRequestID).FirstOrDefault();
                    request.ProcessStatus = (int)ProcessStatus.InProgress;
                    request.ProcessTime = DateTime.UtcNow;
                    request.NoOfTries = (request.NoOfTries == null) ? 1 : request.NoOfTries + 1;
                    biddingContext.SaveChanges();
                }
            }

            /// <summary>
            /// 1.1 Fetch all the Not Processed records
            /// 1.2 Fetch all In-Progress records based on Retry interval and Maximum no of tries 
            /// </summary>
            /// <returns>Packages whose Bidding has ended</returns>
            private IEnumerable<SMSRequest> FetchSMSRequest()
            {
                var currentTime = DateTime.UtcNow;

                var smsRequest = new List<SMSRequest>();
                try
                {
                    using (var biddingContext = new BiddingContext(ConnectionString))
                    {
                        var notProcessedRequests = new List<SMSRequest>();
                        if (FetchCount == 0)
                        {
                            //Fetch Not Processed Records
                            notProcessedRequests = biddingContext.SMSRequests.Where
                            (p => p.ProcessStatus == (int)ProcessStatus.NotProcessed).ToList();
                        }
                        else
                        {
                            notProcessedRequests = biddingContext.SMSRequests.Where
                            (p => p.ProcessStatus == (int)ProcessStatus.NotProcessed).Take(FetchCount).ToList();
                        }

                        //Log.Error($"Fetched {notProcessedRequests.Count()} Not Processed Records.");

                        //Fetch In-Progress Records based on Max No of Retry and Retry Interval
                        var pendingSMSRequestStatusList = new List<int?> { (int)SMSDeliveryStatus.Sent, (int)SMSDeliveryStatus.Delivered };

                        var pendingRequests = biddingContext.SMSRequests.Where
                            (x => x.ProcessStatus == (int)ProcessStatus.InProgress && !pendingSMSRequestStatusList.Contains(x.StatusIndicator) 
                            && x.NoOfTries.Value < MaxTries).ToList();

                        pendingRequests = pendingRequests.Where
                           (s => s.ProcessTime != null && (currentTime - s.ProcessTime.Value).TotalMinutes > RetryIntervalInMin).ToList();

                        //Log.Error($"Fetched {pendingRequests.Count()} Retry Records.");

                        var smsRequestList = new List<List<SMSRequest>>() { notProcessedRequests, pendingRequests};
                        smsRequest = smsRequestList.Aggregate((previous, next) => previous.Union(next).ToList());
                    }
                }
                catch (Exception ex)
                {
                    //Log.Error($"An error occured while fetching sms request record for process" + ex.Message);
                }

                return smsRequest;
            }

            /// <summary>
            /// Send SMS to Twilio API Asynchronously
            /// </summary>
            private async void SendTwilioSMS(SMSRequest request)
            {
                try
                {
                    UpdateProcessStatus(request);

                    string twilioAccountSid = CryptoHelper.Decrypt(TwilioAccountSid, AESPassword, AESSalt);
                    string twilioAuthToken = CryptoHelper.Decrypt(TwilioAuthToken, AESPassword, AESSalt);

                    // Initialize the Twilio client
                    TwilioClient.Init(twilioAccountSid, twilioAuthToken);

                    //it takes only numbers and omit special characters
                    var toPhoneNumber = Regex.Replace(request.Phone, @"[^\d]", string.Empty, RegexOptions.Compiled);

                    //Appending +1 as country code(US) if the phone number length is 10 as mentioned in TOK-873 comments
                    toPhoneNumber = (toPhoneNumber.Length == 10) ? "+1" + toPhoneNumber : "+" + toPhoneNumber;

                    // Send a new outgoing SMS by Posting to the Messages resource
                    var message = await MessageResource.CreateAsync(
                        from: new PhoneNumber(TwilioFromShortCode),
                        to: new PhoneNumber(toPhoneNumber),
                        statusCallback: new Uri(BiddingAPIServiceEndpoint + "?requestId=" + request.SMSRequestID),
                        body: request.Message);
                }
                catch (Exception ex)
                {
                    //Log.Error($"An error occured while sending SMS Via Twilio API" + ex.Message);
                    UpdateSMSErrorLog(Convert.ToString(((Twilio.Exceptions.ApiException)ex).Code), ex.Message, request.Phone, request.NoOfTries, request.SMSRequestID);
                }
            }

            /// <summary>
            /// 1.1 Log Error for the codes received from Twilio
            /// 1.2 Retry request for codes in SMSRetryErrorLists
            /// </summary>
            /// <returns>Packages whose Bidding has ended</returns>
            private void UpdateSMSErrorLog(string errorCode, string errorDescription, string phone, int? noofTries, int requestId)
            {
                using (var biddingContext = new BiddingContext(ConnectionString))
                {
                    SMSErrorLog smsErrorLog = new SMSErrorLog();
                    smsErrorLog.SMSRequestId = requestId;
                    smsErrorLog.SMSErrorCode = errorCode;
                    smsErrorLog.SMSErrorDescription = errorDescription;
                    smsErrorLog.PhoneNo = phone;
                    smsErrorLog.SMSErrorDate = DateTime.UtcNow;
                    smsErrorLog.CreatedDate = DateTime.UtcNow;

                    biddingContext.SMSErrorLogs.Add(smsErrorLog);

                    var smsRequest = biddingContext.SMSRequests.Where(x => x.SMSRequestID == requestId).FirstOrDefault();

                    var errorList = biddingContext.SMSRetryErrorLists.Where(x => x.Retry);
                    if(errorList.Where(x => x.SMSErrorCode == errorCode).Any())
                    {
                        smsRequest.ProcessStatus = (int)ProcessStatus.InProgress;
                        smsRequest.ProcessTime = DateTime.UtcNow;
                    }
                    else
                    {
                        smsRequest.ProcessStatus = (int)ProcessStatus.Failure;
                    }

                    biddingContext.SaveChanges();
                }
            }
        }
        
        enum SMSDeliveryStatus
        {
            Delivered = 0,
            Failed,
            Queued,
            Received,
            Receiving,
            Sending,
            Sent,
            Undelivered
        }

        enum ProcessStatus
        {
            NotProcessed = 0,
            InProgress,
            Delivered,
            Failure
        }

        public static class CryptoHelper
        {
            #region Public Methods
            
            /// <summary>
            /// Decrypts the specified cypher text, and returns the plain text
            /// </summary>
            /// <param name="encryptedText"></param>
            /// <param name="password"></param>
            /// <param name="salt"></param>
            /// <returns></returns>
            public static string Decrypt(string encryptedText, string password, string salt)
            {
                return Decrypt<AesManaged>(encryptedText, password, salt);
            }

            #endregion Public Methods

            #region Private Helpers

            private static string Decrypt<T>(string decryptedText, string password, string salt)
               where T : SymmetricAlgorithm, new()
            {
                var transform = PrepareCipher<T>(password, salt, false);

                using (var buffer = new MemoryStream(Convert.FromBase64String(decryptedText)))
                using (var stream = new CryptoStream(buffer, transform, CryptoStreamMode.Read))
                using (var reader = new StreamReader(stream, Encoding.Unicode))
                {
                    return reader.ReadToEnd();
                }
            }

            private static ICryptoTransform PrepareCipher<T>(string password, string salt, bool encrypt = true)
                where T : SymmetricAlgorithm, new()
            {
                var rgb = new Rfc2898DeriveBytes(password, Encoding.Unicode.GetBytes(salt));

                var algorithm = new T { Mode = CipherMode.CBC };

                byte[] rgbKey = rgb.GetBytes(algorithm.KeySize >> 3);
                byte[] rgbIV = rgb.GetBytes(algorithm.BlockSize >> 3);

                return encrypt ? algorithm.CreateEncryptor(rgbKey, rgbIV) : algorithm.CreateDecryptor(rgbKey, rgbIV);
            }

            #endregion Private Helpers
        }
    }
}
