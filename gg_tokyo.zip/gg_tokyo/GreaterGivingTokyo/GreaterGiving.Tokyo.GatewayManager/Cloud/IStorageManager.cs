﻿using System.Collections.Generic;
using GreaterGiving.Tokyo.GatewayManager.Common;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud
{
    public interface IStorageManager : IGateway
    {
        bool StoreProjectImages(int projectXId, byte[] newProjectImage, byte[] newAppealImage);

        bool StoreSponsorImage(int projectXId, int sponsorXId, byte[] newSponsorImage);

        bool StorePackageImages(int projectXId, int packageXId, IEnumerable<byte[]> newPackageImages);

        bool DeleteProjectImages(int projectXId);

        bool DeleteSponsorImage(int projectXId, int sponsorXId);

        bool DeletePackageImages(int projectXId, int packageXId);
    }
}
