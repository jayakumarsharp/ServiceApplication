﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using GreaterGiving.Tokyo.Entities.Core;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.SendSaleData.Model;
using Newtonsoft.Json;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud
{
    public static class SendSaleDataFunctionApp
    {
        /// <summary>
        /// The startup method
        /// </summary>
        public static void Run()
        {
            // TOK-534 Sending Sale Data to GGO Sale API

            /*
                -------------------------------------------------------------------------------------
                Pass 1 - Processing of packages whose Bidding has ended:
                (This is a great candidate for implementing Data Parallelism!)
                    1.1 Fetch all the ended packages, which do not have a sale record
                    1.2 Insert a sale record with the highest bid, bidder info and status as "Queued"
                    1.3 Update the corresponding package record with IsSaleCreated = true.
                -------------------------------------------------------------------------------------
                Pass 2 - Sending Sale Data to GGO Sale API, and updating the status of the Sale records:
                (This is also a good candidate for implementing Data Parallelism!)
                    2.1 Fetch all sale records that have a status of "Queued" or ("Error" AND "NumberOfTries" <= MaxTries)
                    (This will include all sales records inserted in 1.2)
                    (The value for "MaxTries" is maintained in the configuration.)
                    2.2 Invoke the new POST endpoint to send sale data to GGO
                    (The URI for the SaleData endpoint is also maintained in the configuration)
                -------------------------------------------------------------------------------------
            */

            // Execution strategy:
            // 1. Timed execution (i.e., triggered once in 10 min)
            // 2. Continuously execute the two passes (1 and 2) for up to 9 min, and then exit gracefully

            //log.Error($"Execution started at: {DateTime.UtcNow.ToString("dd-MMM-yyyy HHmmss")}");

            //BidSaleProcessor.Log = log;

            // Setup a cancellation source
            var cancellationTokenSource = new CancellationTokenSource(TimeSpan.FromSeconds(BidSaleProcessor.MaxRunTimeInSeconds));

            // Check if login has been successfully completed, and an app token is ready
            if (string.IsNullOrWhiteSpace(BidSaleProcessor.AuthToken))
            {
                // The authentication hasn't succeeded, so return!
                //log.Error($"Exiting from the app, as the auth token returned is empty/invalid.");

                return;
            }

            Task transformBidToSaleTask = null;
            Task postSaleDataTask = null;

            try
            {
                // Setup threading tasks with the same cancellation token

                transformBidToSaleTask = Task.Factory.StartNew(() => new BidToSaleTransformer().TransformBidToSale(cancellationTokenSource.Token),
                    cancellationTokenSource.Token, TaskCreationOptions.LongRunning, TaskScheduler.Current);

                postSaleDataTask = Task.Factory.StartNew(() => new PendingSalePoster().PostAllPendingSales(cancellationTokenSource.Token),
                    cancellationTokenSource.Token, TaskCreationOptions.LongRunning, TaskScheduler.Current);

                // Wait for the tasks to complete, before exiting
                transformBidToSaleTask.Wait();
                postSaleDataTask.Wait();
            }
            catch (Exception exc)
            {
                // Oohhh...! That was unexpected!!
                //log.Error($"Oops!! An unexpected error occurred: {exc.Message}");
            }
            finally
            {
                if (cancellationTokenSource != null)
                    cancellationTokenSource.Dispose();

                if (transformBidToSaleTask != null)
                    transformBidToSaleTask.Dispose();

                if (postSaleDataTask != null)
                    postSaleDataTask.Dispose();

                //log.Error($"Execution finished at: {DateTime.UtcNow.ToString("dd-MMM-yyyy HHmmss")}");
            }
        }

        class BidSaleProcessor
        {
            protected const int REGULAR_PACKAGE_TYPE = 0;

            private const string CONNECTION_STRING_KEY = "BiddingDBContext";
            private const string MAX_RUN_TIME_IN_SECONDS_KEY = "ExitTimeInSeconds";
            private const string APP_KEY = "AppKey";
            private const string MAX_TRIES_KEY = "MaxTries";
            private const string RETRY_INTERVAL_IN_MIN_KEY = "RetryIntervalInMin";
            private const string IDENTITY_API_SERVICE_ENDPOINT_KEY = "IdentityAPIServiceEndpoint";
            private const string BIDDING_API_SERVICE_ENDPOINT_KEY = "BiddingAPIServiceEndpoint";

            // These constants will make way for configurable app settings in the Azure Function App
            private readonly static string _connectionString;
            private readonly static int _maxRunTimeInSeconds;
            private readonly static int _maxTries;
            private readonly static int _retryIntervalInMin;
            private readonly static string _appKey;
            private readonly static string _identityAPIServiceEndpoint; // "http://projecttokyoidentity-dev.azurewebsites.net/Identity/API/CreateAppToken"
            private readonly static string _biddingAPIServiceEndpoint; // "http://projecttokyobidding-dev.azurewebsites.net/SecureBidding/API/Sales"

            private readonly static string _authToken;

            //public static TraceWriter Log { protected get; set; }

            public static int MaxRunTimeInSeconds { get { return _maxRunTimeInSeconds; } }

            public static string AuthToken { get { return _authToken; } }

            protected static int MaxTries { get { return _maxTries; } }

            protected static int RetryIntervalInMin { get { return _retryIntervalInMin; } }

            protected static string ConnectionString { get { return _connectionString; } }

            protected static string IdentityAPIServiceEndpoint { get { return _identityAPIServiceEndpoint; } }

            protected static string BiddingAPIServiceEndpoint { get { return _biddingAPIServiceEndpoint; } }

            static BidSaleProcessor()
            {
                _connectionString = GetConnectionString(CONNECTION_STRING_KEY);

                int maxRunTime = 9 * 60;  // 9 minutes (default)
                int.TryParse(GetConfigValue(MAX_RUN_TIME_IN_SECONDS_KEY, maxRunTime.ToString()), out maxRunTime);
                _maxRunTimeInSeconds = maxRunTime;

                int maxTries = 5;  // 5 (re)tries (default)
                int.TryParse(GetConfigValue(MAX_TRIES_KEY, maxTries.ToString()), out maxTries);
                _maxTries = maxTries;

                int retryIntervalInMin = 15;  // 15 min (default)
                int.TryParse(GetConfigValue(RETRY_INTERVAL_IN_MIN_KEY, retryIntervalInMin.ToString()), out retryIntervalInMin);
                _retryIntervalInMin = retryIntervalInMin;

                _appKey = GetConfigValue(APP_KEY, "B12F56C9-685F-45BB-8109-4423F217A651");
                _identityAPIServiceEndpoint = GetConfigValue(IDENTITY_API_SERVICE_ENDPOINT_KEY, "http://localhost:62270/Identity/API/CreateAppToken");
                _biddingAPIServiceEndpoint = GetConfigValue(BIDDING_API_SERVICE_ENDPOINT_KEY, "http://localhost:51175/SecureBidding/API/Sales");

                // Login and get an auth token
                _authToken = GetAuthToken();
            }

            /// <summary>
            /// Creates and Returns a WebClient instance to make an HTTP request.
            /// </summary>
            /// <returns></returns>
            protected static WebClient CreateNewWebClient(bool withAuthToken = true)
            {
                var webClient = new WebClient();

                webClient.Headers[HttpRequestHeader.ContentType] = "application/json";

                if (withAuthToken)
                    webClient.Headers.Add("Authorization", $"TokyoScheme {_authToken}");

                return webClient;
            }

            /// <summary>
            /// Logs in to Identity API Service, and retrieve the auth token to be sent while invoking Bidding API
            /// </summary>
            /// <returns></returns>
            private static string GetAuthToken()
            {
                string authToken = string.Empty;

                try
                {
                    using (var webClient = CreateNewWebClient(false))
                        authToken = webClient.DownloadString($@"{IdentityAPIServiceEndpoint}?key={_appKey}").Trim("\"".ToCharArray());
                }
                catch (Exception exc)
                {
                    //Log.Error($"An error occurred while logging in to get the app token: {exc.Message}");
                }

                return authToken;
            }

            /// <summary>
            /// Returns the value for the specified key from the configuration
            /// </summary>
            /// <param name="key"></param>
            /// <returns></returns>
            private static string GetConfigValue(string key, string defaultValue = "")
            {
                var configValue = defaultValue;

                if (ConfigurationManager.AppSettings.AllKeys.Contains(key))
                    configValue = ConfigurationManager.AppSettings[key].Trim();

                return configValue;
            }

            /// <summary>
            /// Returns the connection string for the specified key from the configuration
            /// </summary>
            /// <param name="connectionStringKey"></param>
            /// <returns></returns>
            private static string GetConnectionString(string connectionStringKey)
            {
                var configValue = string.Empty;

                if (ConfigurationManager.ConnectionStrings[connectionStringKey] != null)
                    configValue = ConfigurationManager.ConnectionStrings[connectionStringKey].ConnectionString;

                return configValue;
            }
        }


        class BidToSaleTransformer : BidSaleProcessor
        {
            /// <summary>
            /// Pass 1 - Processing of packages whose Bidding has ended
            /// </summary>
            internal void TransformBidToSale(CancellationToken token)
            {
                // Poll to see if a cancellation (graceful shutdown) has been requested/initiated
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        var bidClosedPackages = FetchEligibleClosedBidPackages();

                        if (bidClosedPackages.Any())
                        {
                            //Log.Error($"Fetched {bidClosedPackages.Count()} closed packages.");

                            // Data Parallelism (using Parallel.ForEach)
                            // Parallel.Foreach() is blocking, so it will wait until all its branched tasks are complete.
                            // Another option here is to harness TPL Dataflow, instead of using Parallel.ForEach().
                            // TPL Dataflow supports asynchronous tasks within each parallel branch of execution.
                            // https://docs.microsoft.com/en-us/dotnet/standard/parallel-programming/dataflow-task-parallel-library
                            Parallel.ForEach(bidClosedPackages, package => CreateSaleAndUpdatePackage(package));
                        }
                    }
                    catch (Exception exc)
                    {
                        //Log.Error($"An error occurred during transformation of bid to sale: {exc.Message}");
                    }
                }
            }

            /// <summary>
            /// 1.1 Fetch all the ended packages, which do not have a sale record 
            /// </summary>
            /// <returns>Packages whose Bidding has ended</returns>
            private IEnumerable<Package> FetchEligibleClosedBidPackages()
            {
                var currentTime = DateTime.UtcNow;

                var bidClosedPackages = new List<Package>();

                try
                {
                    using (var biddingContext = new BiddingContext(ConnectionString))
                    {
                        bidClosedPackages = biddingContext.Packages
                            .Where(p => currentTime > p.EndTimeUTC &&                           // package bidding has ended
                                        (p.IsSaleCreated == null || !p.IsSaleCreated.Value) &&  // packages for which sale isn't created yet
                                        p.MobileBiddingTypeID == REGULAR_PACKAGE_TYPE)          // regular packages
                            .ToList();
                    }
                }
                catch (Exception exc)
                {
                    //Log.Error($"An error occurred while attempting to fetch closed bid packages: {exc.Message}");
                }

                return bidClosedPackages ?? new List<Package>();
            }

            /// <summary>
            /// 1.2 Insert a sale record with the highest bid, bidder info and status as "Queued".
            /// 1.3 Update the corresponding package record with IsSaleCreated = true.
            /// </summary>
            private void CreateSaleAndUpdatePackage(Package package)
            {
                try
                {
                    using (var biddingContext = new BiddingContext(ConnectionString))
                    {
                        var maxBid = biddingContext.Bids
                            .Where(b => b.PackageXid == package.PackageXid && (!b.IsDeleted))
                            .OrderByDescending(b => b.Amount).FirstOrDefault();

                        // Ensure that there's at least one valid bid for the package
                        if (maxBid != null)
                        {
                            // Create a new sale object
                            var sale = new Sale
                            {
                                PackageXid = package.PackageXid,
                                GGOUpdateStatus = (int)GGOSaleResultType.Queued,
                                ProjectXid = package.ProjectXid,
                                Amount = maxBid.Amount,
                                BidderXid = maxBid.BidderXid,
                                SaleDate = DateTime.UtcNow,
                                QtyPurchased = 1
                            };

                            // Create the sale
                            biddingContext.Sales.Add(sale);

                            // Update the corresponding package as sale created
                            UpdatePackageAsSaleCreated(biddingContext, package.PackageXid);

                            biddingContext.SaveChanges();
                        }
                    }
                }
                catch (Exception exc)
                {
                    //Log.Error($"An error occurred while trying to create sale and/or update package: {exc.Message}");
                }
            }

            /// <summary>
            /// 1.3 Update the corresponding package record with IsSaleCreated = true.
            /// </summary>
            /// <param name="biddingContext"></param>
            /// <param name="packageXid"></param>
            private void UpdatePackageAsSaleCreated(BiddingContext biddingContext, int packageXid)
            {
                var package = biddingContext.Packages.FirstOrDefault(p => p.PackageXid == packageXid);

                if (package != null)
                    package.IsSaleCreated = true;
            }
        }


        class PendingSalePoster : BidSaleProcessor
        {
            /// <summary>
            /// Pass 2 - Sending Sale Data to GGO Sale API, and updating the status of the Sale records
            /// </summary>
            internal void PostAllPendingSales(CancellationToken token)
            {
                // Poll to see if a cancellation (graceful shutdown) has been requested/initiated
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        var nonPostedSales = FetchNonPostedSales();

                        if (nonPostedSales.Any())
                        {
                            //Log.Error($"Fetched {nonPostedSales.Count()} non-posted sale records.");

                            // Data Parallelism (using Parallel.ForEach)
                            // Parallel.Foreach() is blocking, so it will wait until all its branched tasks are complete.
                            // Another option here is to harness TPL Dataflow, instead of using Parallel.ForEach().
                            // TPL Dataflow supports asynchronous tasks within each parallel branch of execution.
                            // https://docs.microsoft.com/en-us/dotnet/standard/parallel-programming/dataflow-task-parallel-library
                            Parallel.ForEach(nonPostedSales, sale =>
                            {
                                var saleData = new SaleData
                                {
                                    SaleId = sale.SaleID,
                                    BidderId = sale.BidderXid,
                                    PackageId = sale.PackageXid,
                                    ProjectId = sale.ProjectXid,
                                    SaleDate = sale.SaleDate ?? DateTime.UtcNow,
                                    SaleQuantity = sale.QtyPurchased ?? 1,
                                    SaleTotalPreTax = sale.Amount,
                                    PackageType = 0,    // This will be populated in the Sales endpoint
                                };

                                SendSaleData(saleData);
                            });
                        }
                    }
                    catch (Exception exc)
                    {
                        //Log.Error($"An error occurred while attempting to post pending sales: {exc.Message}");
                    }
                }
            }

            /// <summary>
            /// 2.1 Fetch all sale records that have a status of "Queued" or ("Error" AND "NumberOfTries" <= MaxTries).
            /// This will include all sales records inserted in 1.2. The value for "MaxTries" is maintained in the configuration.
            /// </summary>
            private IEnumerable<Sale> FetchNonPostedSales()
            {
                var currentTime = DateTime.UtcNow;

                var nonPostedSales = new List<Sale>();

                try
                {
                    using (var biddingContext = new BiddingContext(ConnectionString))
                    {
                        var pendingSaleStatusList = new List<int> { (int)GGOSaleResultType.Error, (int)GGOSaleResultType.Queued };

                        nonPostedSales = biddingContext.Sales
                            .Where(s => pendingSaleStatusList.Contains(s.GGOUpdateStatus) &&
                                        (s.NoOfTries == null || s.NoOfTries.Value < MaxTries))
                            .ToList();

                        nonPostedSales = nonPostedSales.Where
                            (s => s.LastAttempted == null || (currentTime - s.LastAttempted.Value).TotalMinutes > RetryIntervalInMin).ToList();
                    }
                }
                catch (Exception exc)
                {
                    //Log.Error($"An error occurred while fetching non-posted sales from the database: {exc.Message}");
                }

                return nonPostedSales ?? new List<Sale>();
            }

            /// <summary>
            /// 2.2 Invoke the new POST endpoint to send sale data to GGO. The URI for the SaleData endpoint is also maintained in the configuration
            /// </summary>
            private void SendSaleData(SaleData saleData)
            {
                try
                {
                    using (var webClient = CreateNewWebClient())
                    {
                        string jsonPayload = JsonConvert.SerializeObject(saleData);

                        string result = webClient.UploadString($@"{BiddingAPIServiceEndpoint}/{saleData.SaleId}", jsonPayload);
                    }
                }
                catch (Exception exc)
                {
                    //Log.Error($"An error occurred while sending sale data to the Sale API: {exc.Message}");
                }
            }
        }


        enum GGOSaleResultType
        {
            Queued = 1,
            Posted,
            Error,
        }
    }
}
