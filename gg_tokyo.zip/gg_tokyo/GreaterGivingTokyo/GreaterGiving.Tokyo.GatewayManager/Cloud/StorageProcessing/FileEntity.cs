﻿namespace GreaterGiving.Tokyo.GatewayManager.Cloud.StorageProcessing
{
    public sealed class FileEntity
    {
        public byte[] FileContent { get; set; }

        public int Order { get; set; }

        public string Hash { get; set; }

        public string FilePath { get; set; }

        public ActionType Action { get; set; }
    }
}
