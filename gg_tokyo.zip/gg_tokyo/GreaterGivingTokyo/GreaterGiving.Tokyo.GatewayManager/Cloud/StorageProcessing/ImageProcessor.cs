﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Murmur;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud.StorageProcessing
{
    public abstract class ImageProcessor
    {
        #region Constants & Fields

        private const string CONTAINER_NAME = "projecttokyopkgassets";
        private const string DATE_TIME_FORMAT = "yyyyMMddHHmmss";

        protected const string PROJECT_PREFIX = "prj";
        protected const string PACKAGE_PREFIX = "pkg";
        protected const string SPONSOR_PREFIX = "spn";
        protected const string APPEAL_PREFIX = "apl";
        protected const string IMAGE_NAME_PREFIX = "img";

        protected const string ID_FORMAT = "00000000";

        protected readonly int _projectXId;
        protected readonly IEnumerable<byte[]> _newImages;

        protected readonly string CurrentDateTime = DateTime.UtcNow.ToString(DATE_TIME_FORMAT);

        #endregion Constants & Fields

        #region Constructors

        protected ImageProcessor(int projectXId, IEnumerable<byte[]> newImages)
        {
            _projectXId = projectXId;
            _newImages = newImages;
        }

        #endregion Constructors

        #region Main Methods

        internal void Delete()
        {
            DeleteFilesFromFolder(CONTAINER_NAME, DeriveFolderPath());
        }

        internal void Process()
        {
            // Transform the new file list onto a list of FileEntity type
            var newImageEntities = _newImages.Select((img, i) => new FileEntity
            {
                FileContent = img,
                FilePath = DeriveFilePath(i + 1),
                Hash = (img == null || img.Length <= 0) ? string.Empty : GenerateHash(img),
                Order = (i + 1),
                Action = ActionType.CreateAndUpdate
            }).ToList();

            // Retrieve the existing images from the storage account
            var storedImageEntities = GetAllFilesFromFolder(CONTAINER_NAME, DeriveFolderPath());

            // Compare the image hashes, arrive at the differences and action the delta (delete/create)
            foreach (var newImageEntity in newImageEntities.Where(fe => fe.FileContent != null))
            {
                // Perform a hash comparison
                var storedImageEntity = storedImageEntities.FirstOrDefault(sfe => sfe.Hash == newImageEntity.Hash);

                // If the image hasn't changed (not even a byte of data in content)
                if (storedImageEntity != null)
                {
                    // Leave the stored image untouched
                    storedImageEntity.Action = ActionType.NoAction;

                    // Update the current stored path
                    newImageEntity.FilePath = storedImageEntity.FilePath;

                    // Change the action to Update (i.e., update in database only)
                    newImageEntity.Action = ActionType.Update;
                }
                else
                    newImageEntity.Action = ActionType.CreateAndUpdate;
            }

            // Delete those images that are old/obsolete
            if (storedImageEntities.Any(sfe => sfe.Action == ActionType.Delete))
                DeleteListedFiles(CONTAINER_NAME, storedImageEntities.Where(sfe => sfe.Action == ActionType.Delete).Select(sfe => sfe.FilePath));

            // Upload the new images to the storage account
            if (newImageEntities.Any(sfe => sfe.Action == ActionType.CreateAndUpdate && sfe.FileContent != null))
                UploadFilesToStorage(CONTAINER_NAME, newImageEntities.Where(sfe => sfe.Action == ActionType.CreateAndUpdate && sfe.FileContent != null));

            // Update the database with the path(s) of the image(s)
            Save(newImageEntities);
        }

        #endregion Main Methods

        #region Abstract Members

        protected abstract string DeriveFolderPath();

        protected abstract void Save(List<FileEntity> newImageEntities);

        #endregion Abstract Members

        #region Private Methods

        private bool UploadFilesToStorage(string containerName, IEnumerable<FileEntity> files)
        {
            if (files != null && files.Any())
                foreach (var file in files)
                {
                    UploadToStorage(file.FileContent, containerName, file.FilePath);
                }

            return true;
        }

        private IEnumerable<FileEntity> GetAllFilesFromFolder(string containerName, string folderPath)
        {
            var container = GetBlobContainer(containerName);

            var blobItems = container.ListBlobs(folderPath, true);

            var fileEntities = new List<FileEntity>();

            if (blobItems != null && blobItems.Any())
                foreach (var blobItem in blobItems)
                {
                    string filePath = blobItem.Uri.AbsolutePath.Replace(containerName, string.Empty).Trim('/');

                    fileEntities.Add(new FileEntity
                    {
                        Action = ActionType.Delete,
                        FilePath = filePath,
                        FileContent = GetFileFromStorage(blobItem.Container.Name, filePath),
                    });
                }

            fileEntities.ForEach(fe => fe.Hash = GenerateHash(fe.FileContent));

            return fileEntities;
        }

        private void UploadToStorage(byte[] fileBytes, string containerName, string blobFilePath)
        {
            var blob = GetBlobReference(containerName, blobFilePath);

            if (blob != null)
                // Create or overwrite the blob with the incoming byte[] contents
                using (var stream = new MemoryStream(fileBytes))
                {
                    blob.UploadFromStream(stream);
                }
        }

        private byte[] GetFileFromStorage(string containerName, string blobFilePath)
        {
            var blob = GetBlobReference(containerName, blobFilePath);

            var fileBytes = new byte[] { };

            if (blob != null && blob.Exists())
                // Create or overwrite the blob with the incoming byte[] contents
                using (var stream = new MemoryStream())
                {
                    blob.DownloadToStream(stream);

                    fileBytes = stream.ToArray();
                }

            return fileBytes;
        }

        private void DeleteListedFiles(string containerName, IEnumerable<string> blobFilePaths)
        {
            if (blobFilePaths != null && blobFilePaths.Any())
                foreach (var blobFilePath in blobFilePaths)
                    DeleteFileFromStorage(containerName, blobFilePath);
        }

        private void DeleteFilesFromFolder(string containerName, string folderPath)
        {
            var container = GetBlobContainer(containerName);

            var blobItems = container.ListBlobs(folderPath, true);

            if (blobItems != null && blobItems.Any())
                foreach (var blobItem in blobItems)
                {
                    var blob = (CloudBlockBlob)blobItem;
                    DeleteFileFromStorage(containerName, blob.Name);
                }
        }

        private void DeleteFileFromStorage(string containerName, string blobFilePath)
        {
            var blob = GetBlobReference(containerName, blobFilePath);

            if (blob != null && blob.Exists())
                blob.Delete(DeleteSnapshotsOption.IncludeSnapshots);
        }

        private CloudBlockBlob GetBlobReference(string containerName, string blobFilePath)
        {
            var container = GetBlobContainer(containerName);

            return container != null ? container.GetBlockBlobReference(blobFilePath) : null;
        }

        private CloudBlobContainer GetBlobContainer(string containerName)
        {
            // Get the storage connection string
            string storageConnectionString = ConfigManager.StorageConnectionString;

            // Parse the connection string and get a reference to the storage account
            var storageAccount = CloudStorageAccount.Parse(storageConnectionString);

            // Create the blob client
            var blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve a reference to a container
            var container = blobClient.GetContainerReference(containerName);

            // Create the container, if it doesn't already exist
            container.CreateIfNotExists();

            // Set the public access to container
            container.SetPermissions(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });

            // Retrieve reference to the blob being created
            return container;
        }

        private string GenerateHash(byte[] fileBytes)
        {
            string hashString = string.Empty;

            using (var hash128 = MurmurHash.Create128(preference: AlgorithmPreference.X64))
            {
                var hash = hash128.ComputeHash(fileBytes);

                hashString = Convert.ToBase64String(hash);
            }

            return hashString;
        }

        private string DeriveFilePath(int order)
        {
            return Path.Combine(DeriveFolderPath(),
                    $"{IMAGE_NAME_PREFIX}-{order}-{CurrentDateTime}.jpg").Replace(@"\", "/");
        }

        #endregion Private Methods
    }

    public enum ActionType : byte
    {
        NoAction = 0,
        Delete = 1,
        CreateAndUpdate = 2,
        Update = 3,
    }
}
