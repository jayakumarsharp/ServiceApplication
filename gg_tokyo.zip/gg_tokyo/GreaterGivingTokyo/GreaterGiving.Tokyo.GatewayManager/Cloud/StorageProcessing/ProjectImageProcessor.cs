﻿using System.Collections.Generic;
using System.Linq;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.Entities.Core;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud.StorageProcessing
{
    internal sealed class ProjectImageProcessor : ImageProcessor
    {
        public ProjectImageProcessor(int projectXId, byte[] projectImage, byte[] appealImage) : base(projectXId, new List<byte[]> { projectImage, appealImage })
        {
        }

        protected override string DeriveFolderPath()
        {
            //"prj00012345/prjapl/img-1-20170809123456"
            return $"{PROJECT_PREFIX}{_projectXId.ToString(ID_FORMAT)}/{PROJECT_PREFIX}{APPEAL_PREFIX}";
        }

        protected override void Save(List<FileEntity> newImageEntities)
        {
            // Update the database with the image path
            using (var biddingContext = new BiddingContext(ConfigManager.BiddingConnectionString))
            {
                if (newImageEntities != null && newImageEntities.Any())
                {
                    var project = biddingContext.Projects.FirstOrDefault(prj => prj.ProjectXid == _projectXId);

                    if (project != null)
                    {
                        // Order = 1 for ProjectImage
                        const byte projectImageOrder = 1;

                        // Order = 2 for AppealImage
                        const byte appealImageOrder = 2;

                        var projectImageEntity = newImageEntities.FirstOrDefault(fe => fe.Order == projectImageOrder && fe.FileContent != null);
                        if (projectImageEntity != null)
                        {
                            project.ProjectImage = null;
                            project.ProjectImagePath = projectImageEntity.FilePath;
                        }

                        var appealImageEntity = newImageEntities.FirstOrDefault(fe => fe.Order == appealImageOrder && fe.FileContent != null);
                        if (appealImageEntity != null)
                        {
                            project.AppealImage = null;
                            project.AppealImagePath = appealImageEntity.FilePath;
                        }

                        biddingContext.SaveChanges();
                    }
                }
            }
        }
    }
}
