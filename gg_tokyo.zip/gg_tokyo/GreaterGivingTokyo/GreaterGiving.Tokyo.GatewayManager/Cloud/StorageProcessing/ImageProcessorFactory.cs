﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using GreaterGiving.Tokyo.CrossCutting.Logging;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud.StorageProcessing
{
    [Export(typeof(IImageProcessorFactory)), LogAspect, PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class ImageProcessorFactory: IImageProcessorFactory
    {
        public ImageProcessor GetImageProcessor(int projectXId, IEnumerable<byte[]> newImages, int packageXId = 0, int sponsorXId = 0)
        {
            ImageProcessor imageProcessor = null;

            if (projectXId > 0 && packageXId <= 0 && sponsorXId <= 0)
                imageProcessor = new ProjectImageProcessor(projectXId, newImages.ElementAt(0), newImages.ElementAt(1));
            else if (projectXId > 0 && sponsorXId > 0)
                imageProcessor = new SponsorImageProcessor(projectXId, sponsorXId, newImages.ElementAt(0));
            else if (projectXId > 0 && packageXId > 0)
                imageProcessor = new PackageImageProcessor(projectXId, packageXId, newImages);

            return imageProcessor;
        }
    }
}
