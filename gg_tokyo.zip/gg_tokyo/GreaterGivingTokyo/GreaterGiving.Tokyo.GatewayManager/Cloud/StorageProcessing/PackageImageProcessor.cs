﻿using System;
using System.Collections.Generic;
using System.Linq;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.Entities.Core;
using GreaterGiving.Tokyo.Entities.Entities;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud.StorageProcessing
{
    internal sealed class PackageImageProcessor : ImageProcessor
    {
        private readonly int _packageXId;

        public PackageImageProcessor(int projectXId, int packageXId, IEnumerable<byte[]> packageImages) : base(projectXId, packageImages)
        {
            _packageXId = packageXId;
        }

        protected override string DeriveFolderPath()
        {
            // Examples:
            //"prj00012345/pkg00043522/img-1-20170809123456"    1
            //"prj00012345/pkg00043522/img-2-20170809123456"    2
            //"prj00012345/pkg00043522/img-3-20170809123456"    4
            //"prj00012345/pkg00043522/img-4-20170809123456"    5

            //"prj00012345/pkg00043522/img-3-20170810123456"    3

            //"prj00012345/pkg00043522/img-4-20170811123456"    4
            return $"{PROJECT_PREFIX}{_projectXId.ToString(ID_FORMAT)}/{PACKAGE_PREFIX}{_packageXId.ToString(ID_FORMAT)}";
        }

        protected override void Save(List<FileEntity> newImageEntities)
        {
            // Update the database with the image paths
            using (var biddingContext = new BiddingContext(ConfigManager.BiddingConnectionString))
            {
                if (newImageEntities != null && newImageEntities.Any())
                {
                    var pkgImages = biddingContext.PackageImage.Where(pkgImg => pkgImg.PackageXid == _packageXId).ToList();

                    if (pkgImages != null && pkgImages.Any())
                    {
                        // Delete all the previous images
                        pkgImages.ForEach(pkgImg => biddingContext.PackageImage.Remove(pkgImg));
                    }

                    // Add all the new images with the correct order and path
                    newImageEntities.ForEach(imgEntity => biddingContext.PackageImage.Add(new PackageImage
                    {
                        Order = imgEntity.Order,
                        Image = null,
                        PackageXid = _packageXId,
                        ImagePath = imgEntity.FilePath,
                        CreatedDate = DateTime.UtcNow,
                    }));

                    biddingContext.SaveChanges();
                }
            }
        }
    }
}
