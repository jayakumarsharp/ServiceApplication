﻿using System.Collections.Generic;
using System.Linq;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.Entities.Core;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud.StorageProcessing
{
    internal sealed class SponsorImageProcessor : ImageProcessor
    {
        private readonly int _sponsorXId;

        public SponsorImageProcessor(int projectXId, int sponsorXId, byte[] sponsorImage) : base(projectXId, new List<byte[]> { sponsorImage })
        {
            _sponsorXId = sponsorXId;
        }

        protected override string DeriveFolderPath()
        {
            //"prj00012345/spn00043522/img-1-20170809123456"
            //"prj00012345/spn00043522/img-1-20170806654321"
            return $"{PROJECT_PREFIX}{_projectXId.ToString(ID_FORMAT)}/{SPONSOR_PREFIX}{_sponsorXId.ToString(ID_FORMAT)}";
        }

        protected override void Save(List<FileEntity> newImageEntities)
        {
            // Update the database with the image path
            using (var biddingContext = new BiddingContext(ConfigManager.BiddingConnectionString))
            {
                if (newImageEntities != null && newImageEntities.Any())
                {
                    var sponsor = biddingContext.Sponsors.FirstOrDefault(spn => spn.ProjectXid == _projectXId && spn.SponsorXid == _sponsorXId);

                    if (sponsor != null)
                    {
                        sponsor.Images = null;
                        sponsor.ImagePath = newImageEntities[0].FilePath;

                        biddingContext.SaveChanges();
                    }
                }
            }
        }
    }
}
