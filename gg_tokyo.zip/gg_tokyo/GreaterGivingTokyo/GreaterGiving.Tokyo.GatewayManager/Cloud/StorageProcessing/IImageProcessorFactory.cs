﻿using System.Collections.Generic;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud.StorageProcessing
{
    public interface IImageProcessorFactory
    {
        ImageProcessor GetImageProcessor(int projectXId, IEnumerable<byte[]> newImages, int packageXId = 0, int sponsorXId = 0);
    }
}
