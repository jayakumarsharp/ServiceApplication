﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.GatewayManager.Cloud.StorageProcessing;

namespace GreaterGiving.Tokyo.GatewayManager.Cloud
{
    [Export(typeof(IStorageManager)), LogAspect, PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class AzureStorageManager : IStorageManager
    {
        #region Private Fields

        private readonly IImageProcessorFactory _imageProcessorFactory;

        #endregion Private Fields

        #region Constructors

        [ImportingConstructor]
        public AzureStorageManager(IImageProcessorFactory imageProcessorFactory)
        {
            _imageProcessorFactory = imageProcessorFactory;
        }

        #endregion Constructors

        #region IStorageManager Members

        bool IStorageManager.StoreProjectImages(int projectXId, byte[] newProjectImage, byte[] newAppealImage)
        {
            bool storageResult;

            try
            {
                var projectImageProcessor = _imageProcessorFactory.GetImageProcessor(projectXId, new List<byte[]> { newProjectImage, newAppealImage });

                projectImageProcessor.Process();

                storageResult = true;
            }
            catch (Exception exc)
            {
                Logger.WriteErrorLog($"An error occurred while storing project images; ProjectXId: {projectXId}; Error: {exc.Message}");

                storageResult = false;
            }

            return storageResult;
        }

        bool IStorageManager.StoreSponsorImage(int projectXId, int sponsorXId, byte[] newSponsorImage)
        {
            bool storageResult;

            try
            {
                var sponsorImageProcessor = _imageProcessorFactory.GetImageProcessor(projectXId, new List<byte[]> { newSponsorImage }, sponsorXId: sponsorXId); ;

                sponsorImageProcessor.Process();

                storageResult = true;
            }
            catch (Exception exc)
            {
                Logger.WriteErrorLog($"An error occurred while storing sponsor image; ProjectXId: {projectXId}; SponsorXid: {sponsorXId}; Error: {exc.Message}");

                storageResult = false;
            }

            return storageResult;
        }

        bool IStorageManager.StorePackageImages(int projectXId, int packageXId, IEnumerable<byte[]> newPackageImages)
        {
            bool storageResult;

            try
            {
                var packageImageProcessor = _imageProcessorFactory.GetImageProcessor(projectXId, newPackageImages, packageXId: packageXId);

                packageImageProcessor.Process();

                storageResult = true;
            }
            catch (Exception exc)
            {
                Logger.WriteErrorLog($"An error occurred while storing package images; ProjectXId: {projectXId}; PackageXId: {packageXId}; Error: {exc.Message}");

                storageResult = false;
            }

            return storageResult;
        }

        bool IStorageManager.DeleteProjectImages(int projectXId)
        {
            bool deleteResult;

            try
            {
                var projectImageProcessor = _imageProcessorFactory.GetImageProcessor(projectXId, new List<byte[]> { null, null });

                projectImageProcessor.Delete();

                deleteResult = true;
            }
            catch (Exception exc)
            {
                Logger.WriteErrorLog($"An error occurred while deleting project images; ProjectXId: {projectXId}; Error: {exc.Message}");

                deleteResult = false;
            }

            return deleteResult;
        }

        bool IStorageManager.DeleteSponsorImage(int projectXId, int sponsorXId)
        {
            bool deleteResult;

            try
            {
                var sponsorImageProcessor = _imageProcessorFactory.GetImageProcessor(projectXId, new List<byte[]> { null }, sponsorXId: sponsorXId);

                sponsorImageProcessor.Delete();

                deleteResult = true;
            }
            catch (Exception exc)
            {
                Logger.WriteErrorLog($"An error occurred while deleting sponsor image; ProjectXId: {projectXId}; SponsorXId: {sponsorXId}; Error: {exc.Message}");

                deleteResult = false;
            }

            return deleteResult;
        }

        bool IStorageManager.DeletePackageImages(int projectXId, int packageXId)
        {
            bool deleteResult;

            try
            {
                var packageImageProcessor = _imageProcessorFactory.GetImageProcessor(projectXId, null , packageXId: packageXId);

                packageImageProcessor.Delete();

                deleteResult = true;
            }
            catch (Exception exc)
            {
                Logger.WriteErrorLog($"An error occurred while deleting package images; ProjectXId: {projectXId}; PackageXId: {packageXId}; Error: {exc.Message}");

                deleteResult = false;
            }

            return deleteResult;
        }

        #endregion IStorageManager Members
    }
}
