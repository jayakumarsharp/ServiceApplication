﻿using System;
using System.ComponentModel.Composition;
using System.Net;
using System.ServiceModel;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.GatewayManager.Contract;
using GreaterGiving.Tokyo.GatewayManager.SendSaleDataService;
using GreaterGiving.Tokyo.SaleDataService.Model;
using GreaterGiving.Tokyo.SendSaleData.Model;
using GreaterGiving.Tokyo.CrossCutting.Crypto;

namespace GreaterGiving.Tokyo.GatewayManager.SendSaleData
{
    [Export(typeof(ISendSaleData)), LogAspect, PartCreationPolicy(CreationPolicy.NonShared)]
    public sealed class SendSaleData : ISendSaleData
    {
        public SaleResultModel SendSaleDataToGGO(SaleData saleData)
        {
            SaleResultModel result = new SaleResultModel();

            BasicHttpBinding binding = new BasicHttpBinding();
            //For Https web applications
            binding.Security.Mode = BasicHttpSecurityMode.Transport;

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            EndpointAddress endpointAddress = new EndpointAddress(ConfigManager.SaleServiceURL);
            SaleAndPaymentClient saleAndPaymentClient = new SaleAndPaymentClient(binding, endpointAddress);
            ProjectIdentification projectIdentification = new ProjectIdentification();
            Authentication authentication = new Authentication();
            SaleAndPaymentData saleAndPaymentData = new SaleAndPaymentData();
            AddSaleAndPaymentSupporter supporter = new AddSaleAndPaymentSupporter();
            AddSaleAndPaymentRequestBody saleAndPaymentRequestBody = new AddSaleAndPaymentRequestBody();

            if (saleData != null)
            {
                // Authentication
                authentication = DecryptSaleCredentials();

                // Project
                projectIdentification.ProjectId = saleData.ProjectId;

                // Purchaser
                supporter.BidderId = saleData.BidderId;
                supporter.SupporterType = SupporterType.Person;

                // SalePayment
                saleAndPaymentData.AlternateSaleId = saleData.SaleId.ToString();
                saleAndPaymentData.PackageId = saleData.PackageId;
                saleAndPaymentData.SaleQuantity = saleData.SaleQuantity;
                saleAndPaymentData.SaleTotalPreTax = saleData.SaleTotalPreTax;
                saleAndPaymentData.SaleDate = saleData.SaleDate;
                saleAndPaymentData.PackageType = (PackageType)saleData.PackageType;

                saleAndPaymentRequestBody.Data = new AddSaleAndPaymentTransaction();
                saleAndPaymentRequestBody.Authentication = authentication;
                saleAndPaymentRequestBody.Data.Project = projectIdentification;
                saleAndPaymentRequestBody.Data.SalePayment = saleAndPaymentData;
                saleAndPaymentRequestBody.Data.Purchaser = supporter;

                try
                {                    
                    result.Status = null;
                    var addSale = saleAndPaymentClient.AddSaleAndPayment(saleAndPaymentRequestBody);
                    if (addSale.CreatedNewSale)
                    {
                        result.Status = true;
                    }
                }
                catch (Exception ex)
                {
                    result.Status = false;
                    result.Error = ex.Message;
                    Logger.WriteErrorLog(string.Format("Sale Service Error Message: {0}, PackageXid: {1}", ex.Message, saleData.PackageId.ToString()));
                }
            }

            return result;
        }

        public Authentication DecryptSaleCredentials()
        {
            // # symbol is not accepted in encryption and decryption logic
            Authentication saleCredentialInfo = new Authentication();
            saleCredentialInfo.UserName = CryptoHelper.Decrypt(ConfigManager.SaleUserName, ConfigManager.AESPassword, ConfigManager.AESSalt);
            saleCredentialInfo.Password = CryptoHelper.Decrypt(ConfigManager.SalePassword, ConfigManager.AESPassword, ConfigManager.AESSalt);
            saleCredentialInfo.PartnerId = CryptoHelper.Decrypt(ConfigManager.SalePartnerId, ConfigManager.AESPassword, ConfigManager.AESSalt);
            return saleCredentialInfo;            
        }
    }
}
