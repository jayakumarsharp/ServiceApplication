﻿using GreaterGiving.Tokyo.SaleDataService.Model;
using GreaterGiving.Tokyo.SendSaleData.Model;

namespace GreaterGiving.Tokyo.GatewayManager.Contract
{
    public interface ISendSaleData
    {
        SaleResultModel SendSaleDataToGGO(SaleData saleData);
    }
}
