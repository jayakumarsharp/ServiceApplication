﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Crypto;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Foundation.Container;
using System;
using System.ComponentModel.Composition;
using System.Configuration;

namespace GreaterGiving.Tokyo.BiddingService
{
    [Export(typeof(IAuthentication)), PartCreationPolicy(CreationPolicy.NonShared)]
    public class Authentication : IAuthentication
    {  
        public Authentication()
        {   
        }
       
        public bool ValidateUser(AuthenticationInput authUserDetails)
        {           
            return ValidateUserCredentials(authUserDetails);
        }

        private bool ValidateUserCredentials(AuthenticationInput authUserDetails)
        {
            var validateResult = false;

            var apiAuthUserName = ConfigurationManager.AppSettings["APIAuthUserName"].ToString();
            var apiAuthPassword = ConfigurationManager.AppSettings["APIAuthPassword"].ToString();

            var authconfigUser = CryptoHelper.Decrypt(apiAuthUserName, ConfigManager.AESPassword, ConfigManager.AESSalt);
            var authconfigPwd = CryptoHelper.Decrypt(apiAuthPassword, ConfigManager.AESPassword, ConfigManager.AESSalt);

            if (authconfigUser == authUserDetails.UserName && authconfigPwd == authUserDetails.Password)
            {
                validateResult = true;
            }

            return validateResult;
        }
    }
}