﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.Entities.Input;

namespace GreaterGiving.Tokyo.BiddingService
{
    public interface IAuthentication
    {
        bool ValidateUser(AuthenticationInput authUserDetails);
    }
}
