﻿using System.Web.Http;
using System.Web.Routing;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using Microsoft.AspNet.SignalR;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Owin;

[assembly: OwinStartup(typeof(GreaterGiving.Tokyo.BiddingService.Startup))]

namespace GreaterGiving.Tokyo.BiddingService
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();

            // Configure Swagger
            SwaggerConfig.Register(config);

            // Register routes, filters etc.
            WebApiConfig.Register(config);

            // Register routes for Mvc Controller - GGO Twilio - Subscribe and Unsubscribe Inbound SMS
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            // Setup a Service Bus messaging backplane for SignalR scaleout
            GlobalHost.DependencyResolver.UseServiceBus(ConfigManager.ServiceBusEndpoint, "ProjTokyoSignalR");

            // SignalR configuration
            app.Map("/signalr", map =>
            {
                map.UseCors(CorsOptions.AllowAll);
                map.RunSignalR(new HubConfiguration { EnableJSONP = true });
            });

            // Allow WebAPI to un on top of OWIN
            app.UseWebApi(config);
        }
    }
}
