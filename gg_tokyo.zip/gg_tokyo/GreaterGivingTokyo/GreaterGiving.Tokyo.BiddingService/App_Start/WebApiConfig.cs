﻿using System.ComponentModel.Composition.Hosting;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Filters;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.Foundation.Container;
using GreaterGiving.Tokyo.Foundation.Contracts;

namespace GreaterGiving.Tokyo.BiddingService
{
    public static class WebApiConfig
    {
        #region Private Fields & Constants

        private static CompositionContainer _container;

        #endregion Private Fields & Constants

        #region Core Method

        public static void Register(HttpConfiguration config)
        {
            _container = _container ?? TokyoContainer.ComposeContainer(new object(), typeof(IFoundation));

            // Web API routes
            config.MapHttpAttributeRoutes();

            ConfigureCors(config);

            //ConfigureFilters(config);

            config.Routes.MapHttpRoute("DefaultApi", "api/{controller}/{id}", new { id = RouteParameter.Optional });
        }

        #endregion Core Method

        #region Private Helpers

        private static void ConfigureFilters(HttpConfiguration config)
        {
            var authFilter = _container.GetExportedValue<IAuthenticationFilter>();

            config.Filters.Add(authFilter);
        }

        private static void ConfigureCors(HttpConfiguration config)
        {
            var cors = new EnableCorsAttribute(ConfigManager.AllowedOriginsList, "*", "GET, POST, PUT, DELETE, OPTIONS");
            config.EnableCors(cors);
        }

        #endregion Private Helpers
    }
}
