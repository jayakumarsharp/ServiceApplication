﻿using System.Web.Http;
using System.Net.Http;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using GreaterGiving.Tokyo.CrossCutting.Common;

namespace GreaterGiving.Tokyo.BiddingService.Controllers.Admin
{
    [RoutePrefix("AdminAuthenticate")]
    public class AdminAuthenticateController : ControllerBase
    {
        /// <summary>
        /// Constructor Admin Authenticate Controller
        /// </summary>
        public AdminAuthenticateController()
        {
        }

        /// <summary>
        /// Redirect
        /// </summary>
        /// <returns></returns>
        [Route("Redirect"), HttpPost]
        public HttpResponseMessage Redirect()
        {
            string credentials = Request.Content.ReadAsStringAsync().Result.ToString();
            string userName = credentials.Split('&')[0].Split('=')[1].ToString();
            string password = credentials.Split('&')[1].Split('=')[1].ToString();
            string adminToken = string.Empty;
            dynamic data = null;
           var httpClient = new HttpClient();
            var response = httpClient.GetAsync(ConfigManager.IdentityBaseURL + "Identity/API/CreateAdminToken?username=" + userName + "&password=" + password).Result;
            if (response.IsSuccessStatusCode)
            {
                string stateInfo = response.Content.ReadAsStringAsync().Result;
                data = JObject.Parse(stateInfo);
                adminToken = data.AdminToken;
            }
            string ConcadinateTokenAndValidity = adminToken + AppConstants.DonorDelimiter + data.ValidTo; //Token and its expiration datetime with delimitter for spliting
            var source = !string.IsNullOrWhiteSpace(adminToken) ? ConfigManager.AdminBaseURL + userName : ConfigManager.ErrorPageURL;
            var jquery = "../../scripts/jquery-3.2.1.js";
            string html = @"<html><head><meta name = 'viewport' content = 'width=device-width' /><title> Online Bidding Admin</title></head>";
            html += "<body><div>Redirecting...<iframe id = 'iframe' src = '" + source + "' style = 'display:none' ></iframe></div>";            
            html += @"</body></html>";
            html += "<script src='" + jquery + "'></script>";
            html += "<script type = 'text/javascript' > onLoad(); function onLoad() { var admintoken = '" + adminToken + "';  var domain ='" + ConfigManager.AdminBaseURL + userName + "';";
            html += "if(admintoken.length == 0){ window.top.location.href ='" + source + "'; return;}";
            html += "var iframeWin = document.getElementById('iframe').contentWindow;";
            html += "localStorage.clear();";
            html += "setInterval(function() {";
            html += "if (!iframeWin || !jQuery) { return; }";
            html += "iframeWin.postMessage('" + adminToken + "','" + ConfigManager.AdminBaseURL + userName + "'); },100);}";
            html += "</script>";

            response.Content = new StringContent(html);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("text/html");
            return response;
        }
    }
}