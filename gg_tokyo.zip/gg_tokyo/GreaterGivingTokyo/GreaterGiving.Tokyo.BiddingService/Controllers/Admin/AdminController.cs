﻿using System.Net;
using System.Web.Http;
using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Exceptions;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Foundation.Identity;

namespace GreaterGiving.Tokyo.BiddingService.Controllers.Admin
{
    [TokyoExceptionFilter, TokyoAuthenticationFilter, LogAspect, RoutePrefix("AdminBidding/API")]
    public class AdminController : ControllerBase
    {
        /// <summary>
        /// Constructor Admin Controller
        /// </summary>
        public AdminController()
        {
        }

        /// <summary>
        /// Constructor AdminController
        /// </summary>
        /// <param name="biddingDomain">biddingDomain</param>
        /// <param name="authentication">authentication</param>
        public AdminController(IBiddingDomain biddingDomain, IAuthentication authentication)
            : base(biddingDomain, authentication)
        {
        }

        /// <summary>
        /// Get Top bidders
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="count">count</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetTopBidders"), HttpGet]
        public IHttpActionResult GetTopBiddersForAdmin(string prefix, int count)
        {
            var result = BiddingDomain.GetTopBiddersForAdmin(prefix, count);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Top bidders
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="biddersearchinput">biddersearchinput</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetAllBidders"), HttpPut]
        public IHttpActionResult GetAllBiddersForAdmin(string prefix, [FromBody] BidderSearchInput bidderSearchInput)
        {
            var result = BiddingDomain.GetAllBiddersForAdmin(prefix, bidderSearchInput);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Top Packages
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="count">count</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetTopPackages"), HttpGet]
        public IHttpActionResult GetTopPackagesForAdmin(string prefix, int count)
        {
            var result = BiddingDomain.GetTopPackagesForAdmin(prefix, count);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get All Packages for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="input">input</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetAllPackages"), HttpPut]
        public IHttpActionResult GetAllPackagesForAdmin(string prefix, [FromBody] PackageSearchInput input)
        {
            var result = BiddingDomain.GetAllPackagesForAdmin(prefix, input);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Bidder Details
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetBidderDetails"), HttpGet]
        public IHttpActionResult GetBidderDetailsForAdmin(string prefix, int bidderId)
        {
            var result = BiddingDomain.GetBidderDetailsForAdmin(prefix, bidderId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Bidder's max bid list
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetBidderMaxBid"), HttpGet]
        public IHttpActionResult GetBidderMaxBidForAdmin(string prefix, int bidderId)
        {
            var result = BiddingDomain.GetBidderMaxBidForAdmin(prefix, bidderId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get active or inactive Bids placed by the bidder
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="bidderId">bidderId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetBidderBidHistory"), HttpGet]
        public IHttpActionResult GetBidderBidHistoryForAdmin(string prefix, int bidderId)
        {
            var result = BiddingDomain.GetBidderBidHistoryForAdmin(prefix, bidderId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Package Max Bid for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackageMaxBid"), HttpGet]
        public IHttpActionResult GetPackageMaxBidForAdmin(string prefix, int packageId)
        {
            var result = BiddingDomain.GetPackageMaxBidForAdmin(prefix, packageId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Package Details for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackageDetails"), HttpGet]
        public IHttpActionResult GetPackageDetailsForAdmin(string prefix, int packageId)
        {
            var result = BiddingDomain.GetPackageDetailsForAdmin(prefix, packageId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Package Bid History for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackageBidHistory"), HttpGet]
        public IHttpActionResult GetPackageBidHistoryForAdmin(string prefix, int packageId)
        {
            var result = BiddingDomain.GetPackageBidHistoryForAdmin(prefix, packageId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Category types by project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetCategoryTypesByProject"), HttpGet]
        public IHttpActionResult GetCategoryTypesByProject(string prefix)
        {
            var result = BiddingDomain.GetCategoryTypesByProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }


        /// <summary>
        /// Clear max bid for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("ClearMaxBid"), HttpPost]
        public IHttpActionResult ClearMaxBidForAdmin(string prefix, int packageId)
        {
            var result = BiddingDomain.ClearMaxBidForAdmin(prefix, packageId);

            return Content(HttpStatusCode.OK, result);
        }
        /// <summary>
        /// Remove bid
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="bidId">bidId</param>
        /// <param name="saleId">saleId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("RemoveBid"), HttpPost]
        public IHttpActionResult RemoveBidForAdmin(string prefix, int bidId, int saleId)
        {
            var result = BiddingDomain.RemoveBidForAdmin(prefix, bidId, saleId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Save Email Template for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="emailMessage">emailMessage</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SaveEmailTemplate"), HttpPost]
        public IHttpActionResult SaveEmailTemplateForAdmin(string prefix, [FromBody] EmailMessageFieldValues emailMessage)
        {
            var result = BiddingDomain.SaveEmailTemplateForAdmin(prefix, emailMessage);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Email Templates for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetEmailTemplates"), HttpGet]
        public IHttpActionResult GetEmailTemplatesForAdmin(string prefix)
        {
            var result = BiddingDomain.GetEmailTemplatesForAdmin(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Delete Email Template for admin
        /// </summary>
        /// <param name="prefix">prefix - used for authorization</param>
        /// <param name="projectId">projectId</param>
        /// <param name="emailTemplateId">emailTemplateId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("DeleteEmailTemplate"), HttpPost]
        public IHttpActionResult DeleteEmailTemplateForAdmin(string prefix, int projectId, int emailTemplateId)
        {
            var result = BiddingDomain.DeleteEmailTemplateForAdmin(projectId, emailTemplateId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Send Preview Email for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="emailMessage">emailMessage</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SendPreviewEmail"), HttpPut]
        public IHttpActionResult SendPreviewEmailForAdmin(string prefix, [FromBody] EmailMessageFieldValues emailMessage)
        {
            var result = BiddingDomain.SendPreviewEmailForAdmin(prefix, emailMessage);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Send Registration Email for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="recipientType">recipientType</param>
        /// <param name="emailMessage">emailMessage</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SendRegistrationEmail"), HttpPut]
        public IHttpActionResult SendRegistrationEmailForAdmin(string prefix, string recipientType, [FromBody] EmailMessageFieldValues emailMessage)
        {
            var result = BiddingDomain.SendRegistrationEmailForAdmin(prefix, recipientType, emailMessage);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Gets the SMS Templates for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetSMSTemplates"), HttpGet]
        public IHttpActionResult GetSMSTemplatesForAdmin(string prefix)
        {
            var result = BiddingDomain.GetSMSTemplatesForAdmin(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Save SMS Templates for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="textMessageFieldValues">textMessageFieldValues</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SaveSMSTemplate"), HttpPost]
        public IHttpActionResult SaveSMSTemplateForAdmin(string prefix, [FromBody] TextMessageFieldValues textMessageFieldValues)
        {
            var result = BiddingDomain.SaveSMSTemplateForAdmin(prefix, textMessageFieldValues);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Remove the SMS templates for admin
        /// </summary>
        /// <param name="prefix">prefix - used for authorization</param>
        /// <param name="projectId">projectId</param>
        /// <param name="templateId">templateId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("DeleteSMSTemplate"), HttpPost]
        public IHttpActionResult DeleteSMSTemplateForAdmin(string prefix, int projectId, int smsTemplateId)
        {
            var result = BiddingDomain.DeleteSMSTemplateForAdmin(projectId, smsTemplateId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Send Preview Text Message to the specified phone number for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="textMessageFieldValues">textMessageFieldValues</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SendPreviewSMS"), HttpPut]
        public IHttpActionResult SendPreviewSMSForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues)
        {
            var result = BiddingDomain.SendPreviewSMSForAdmin(prefix, textMessageFieldValues);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Send Registration SMS for Admin
        /// </summary>
        /// <param name="prefix"></param>
        /// <param name="recipientType"></param>
        /// <param name="emailMessage"></param>
        /// <returns>IHttpActionResult</returns>
        [Route("SendRegistrationSMS"), HttpPut]
        public IHttpActionResult SendRegistrationSMSForAdmin(string prefix, string recipientType, [FromBody] TextMessageFieldValues textMessageFieldValues)
        {
            var result = BiddingDomain.SendRegistrationSMSForAdmin(prefix, recipientType, textMessageFieldValues);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Remove All Bids, Sales, Donations and Max bids
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("RemoveAllBids"), HttpPost]
        public IHttpActionResult RemoveAllBidsForAdmin(string prefix)
        {
            var result = BiddingDomain.RemoveAllBidsForAdmin(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get All bidding history for Export
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("ExportAllBiddingHistory"), HttpGet]
        public IHttpActionResult ExportAllBiddingHistoryForAdmin(string prefix)
        {
            var result = BiddingDomain.ExportAllBiddingHistoryForAdmin(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Embed power BI Report access details for admin
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("EmbedReport"), HttpGet]
        public IHttpActionResult EmbedReportForAdmin(string prefix)
        {
            var result = BiddingDomain.EmbedReportForAdmin();

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Embed power BI Report last updated time by project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("EmbedReportLastUpdatedDateTimeByProject"), HttpGet]
        public IHttpActionResult EmbedReportLastUpdatedDateTimeByProject(string prefix)
        {
            var result = BiddingDomain.EmbedReportLastUpdatedDateTimeByProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }
    }
}