﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Exceptions;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Input;
using System.Net;
using System.Net.Http.Formatting;
using System.Web.Http;
using GreaterGiving.Tokyo.CrossCutting.SMS;

namespace GreaterGiving.Tokyo.BiddingService.Controllers
{
    [TokyoExceptionFilter, LogAspect, RoutePrefix("Bidding/API")]
    public class ProjectController : ControllerBase
    {
        /// <summary>
        /// Constructor ProjectController
        /// </summary>
        public ProjectController()
        {
        }

        /// <summary>
        /// Constructor ProjectController
        /// </summary>
        /// <param name="biddingDomain">biddingDomain</param>
        /// <param name="authentication">authentication</param>
        public ProjectController(IBiddingDomain biddingDomain, IAuthentication authentication)
            : base(biddingDomain, authentication)
        {
        }

        /// <summary>
        /// Get Project using prefix
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>ProjectOutput</returns>
        [Route("GetProject"), HttpGet]
        public IHttpActionResult GetProject(string prefix)
        {
            var result = BiddingDomain.GetProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Project by project Key
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>ProjectOutput</returns>
        [Route("GetProjectByProjectKey"), HttpGet]
        public IHttpActionResult GetProjectByProjectKey(string projectKey)
        {
            var result = BiddingDomain.GetProjectByProjectKey(projectKey);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Encrypt
        /// </summary>
        /// <param name="inputText">inputText</param>
        /// <returns>string</returns>
        [Route("Encrypt"), HttpGet]
        public IHttpActionResult Encrypt(string inputText)
        {
            var result = BiddingDomain.Encrypt(inputText);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Decrypt
        /// </summary>
        /// <param name="inputText">inputText</param>
        /// <returns>string</returns>
        [Route("Decrypt"), HttpGet]
        public IHttpActionResult Decrypt(string inputText)
        {
            var result = BiddingDomain.Decrypt(inputText);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Check for Short Name(Prefix) available in Project
        /// </summary>
        /// <param name="projecShortName"></param>
        /// <returns></returns>
        [Route("IsShortNameAvailable"), HttpPost]
        public IHttpActionResult IsShortNameAvailable([FromBody] ProjectShortNameModel projecShortName)
        {
            if (Authentication.ValidateUser(projecShortName.Authentication))
            {
                var result = BiddingDomain.IsShortNameAvailable(projecShortName.ShortNameFieldValue.ShortName);
                if (result.ResultCode == MessageManager.GetEnumResultCode(MessageCode.Fail))
                {
                    return Content(HttpStatusCode.InternalServerError, result, new JsonMediaTypeFormatter(), "application/json");
                }

                return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
            }
            else
            {
                return Unauthorized();
            }
        }

        /// <summary>
        /// Create New Project 
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        [Route("CreateMobileBiddingEvent"), HttpPost]
        public IHttpActionResult CreateProject([FromBody] ProjectInput project)
        {
            if (Authentication.ValidateUser(project.Authentication))
            {
                var result = BiddingDomain.CreateProject(project.ProjectFieldValue);

                if (result.ResultCode == MessageManager.GetEnumResultCode(MessageCode.Fail))
                {
                    if (result.Reason == MessageManager.GetEnumResultReason(MessageCode.Info001))
                    {
                        return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
                    }
                    else
                    {
                        return Content(HttpStatusCode.InternalServerError, result, new JsonMediaTypeFormatter(), "application/json");
                    }
                }

                return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
            }
            else
            {
                return Unauthorized();
            }
        }

        /// <summary>
        /// Send Text Messages to the phone numbers specified
        /// </summary>
        /// <param name="message">message</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SendSMS"), HttpPost]
        public IHttpActionResult SendSMS([FromBody] TextMessageInput message)
        {
            var validateProject = BiddingDomain.ValidateProject(message.Authentication.ProjectID);

            if (Authentication.ValidateUser(message.Authentication) && validateProject)
            {
                var result = BiddingDomain.SendSMS(message.TextMessageFieldValue);

                if (result.ResultCode == MessageManager.GetEnumResultCode(MessageCode.Fail))
                {
                    if ((result.Reason == MessageManager.GetEnumResultReason(MessageCode.Error006)) || (result.Reason == MessageManager.GetEnumResultReason(MessageCode.Error007)))
                    {
                        return Content(HttpStatusCode.InternalServerError, result, new JsonMediaTypeFormatter(), "application/json");
                    }
                    else
                    {
                        return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
                    }
                }

                return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
            }
            else
            {
                return Unauthorized();
            }
        }

        /// <summary>
        /// Send Email Messages to the email address specified
        /// </summary>
        /// <param name="message">message</param>
        /// <returns>IHttpActionResult</returns>
        [Route("sendEmail"), HttpPost]
        public IHttpActionResult SendEmail([FromBody] EmailMessageInput message)
        {
            var validateProject = BiddingDomain.ValidateProject(message.Authentication.ProjectID);

            if (Authentication.ValidateUser(message.Authentication) && validateProject)
            {
                var result = BiddingDomain.SendEmail(message.EmailMessageFieldValue, message.Authentication.ProjectID);
                if (result.ResultCode == MessageManager.GetEnumResultCode(MessageCode.Fail))
                {
                    if ((result.Reason == MessageManager.GetEnumResultReason(MessageCode.Error006)) || (result.Reason == MessageManager.GetEnumResultReason(MessageCode.Error009)))
                        return Content(HttpStatusCode.InternalServerError, result, new JsonMediaTypeFormatter(), "application/json");
                    else
                        return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
                }
                return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
            }
            else
                return Unauthorized();
        }

        [Route("SMSUnsubscribe"), HttpPost]
        public IHttpActionResult SMSUnsubscribe(string phoneNo)
        {
            BiddingDomain.InsertUnsubscribePhoneNo(phoneNo);

            return Content(HttpStatusCode.OK, MessageManager.GetEnumResultReason(MessageCode.Success006), new JsonMediaTypeFormatter(), "application/json");
        }

        [Route("SMSSubscribe"), HttpPost]
        public IHttpActionResult SMSSubscribe(string phoneNo)
        {
            BiddingDomain.DeleteUnsubscribePhoneNo(phoneNo);

            return Content(HttpStatusCode.OK, MessageManager.GetEnumResultReason(MessageCode.Success006), new JsonMediaTypeFormatter(), "application/json");
        }

        /// <summary>
        /// Logs SMS Delivery Status
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [Route("UpdateSMSStatus"), HttpPost]
        public IHttpActionResult UpdateSMSStatus([FromUri] int requestId)
        {
            string response = Request.Content.ReadAsStringAsync().Result;

            BiddingDomain.UpdateSMSStatus(response, requestId);

            return Content(HttpStatusCode.OK, MessageManager.GetEnumResultReason(MessageCode.Success006), new JsonMediaTypeFormatter(), "application/json");
        }
    }
}
