﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Exceptions;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using System.Web.Http;
using GreaterGiving.Tokyo.Entities.Output;
using System;
using System.Collections.Generic;
using System.Net;

namespace GreaterGiving.Tokyo.BiddingService.Controllers
{
    [TokyoExceptionFilter, LogAspect, RoutePrefix("Bidding/API")]
    public class SponsorController : ControllerBase
    {
        /// <summary>
        /// Constructor SponsorController
        /// </summary>                  
        public SponsorController()
        {
        }

        /// <summary>
        /// Constructor SponsorController
        /// </summary>
        /// <param name="biddingDomain"></param>
        /// <param name="authentication"></param>
        public SponsorController(IBiddingDomain biddingDomain, IAuthentication authentication)
            : base(biddingDomain, authentication)
        {
        }

        /// <summary>
        /// Get Sponsor Images By Prefix
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetSponsorImagesByPrefix"), HttpGet]
        public IHttpActionResult GetSponsorImagesByPrefix(string prefix)
        {
            var result = BiddingDomain.GetSponsorImagesByPrefix(prefix);

            return Content(HttpStatusCode.OK, result);
        }

    }
}
