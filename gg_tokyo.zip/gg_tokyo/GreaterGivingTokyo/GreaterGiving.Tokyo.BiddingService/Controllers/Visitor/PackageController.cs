﻿using System.Net;
using System.Net.Http.Formatting;
using System.Web.Http;
using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Exceptions;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Input;
using Newtonsoft.Json.Linq;

namespace GreaterGiving.Tokyo.BiddingService.Controllers
{
    [TokyoExceptionFilter, LogAspect, RoutePrefix("Bidding/API")]
    public class PackageController : ControllerBase
    {
        /// <summary>
        /// Constructor PackageController
        /// </summary>
        public PackageController()
        {
        }

        /// <summary>
        /// Package Controller
        /// </summary>
        /// <param name="biddingDomain">biddingDomain</param>
        /// <param name="authentication">authentication</param>
        public PackageController(IBiddingDomain biddingDomain, IAuthentication authentication)
            : base(biddingDomain, authentication)
        {
        }

        /// <summary>
        /// Gets all packages based on Prefix
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [Route("GetAllPackages"), HttpGet]
        public IHttpActionResult GetAllPackages(string prefix)
        {
            var result = BiddingDomain.GetAllPackages(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Gets Packages based on Prefix,PageNo and Size
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <param name="packageFilterType">packageFilterType</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackages"), HttpGet]
        public IHttpActionResult GetPackages(string prefix, int pageno, int size, string packageFilterType)
        {
            var result = BiddingDomain.GetPackages(prefix, pageno, size, packageFilterType);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Gets Related Packages using PackageXid
        /// </summary>
        /// <param name="packageXid">packageXid</param>
        /// <param name="displayedPackages">displayedPackages</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetRelatedPackages"), HttpGet]
        public IHttpActionResult GetRelatedPackages(string prefix, int packageXid, string displayedPackages)
        {
            var result = BiddingDomain.GetRelatedPackages(prefix, packageXid, displayedPackages);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Gets Appeal Donation Package
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [Route("GetAppealDonationPackage"), HttpGet]
        public IHttpActionResult GetAppealDonationPackage(string prefix)
        {
            var result = BiddingDomain.GetAppealDonationPackage(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Updates the packages time and item type
        /// </summary>
        /// <param name="package">package</param>
        /// <returns>IHttpActionResult</returns>
        [Route("updateData"), HttpPost]
        public IHttpActionResult UpdateTimeAndItemTypeForPackages([FromBody] BulkPackageInput package)
        {
            var validateProject = BiddingDomain.ValidateProject(package.Authentication.ProjectID);

            if (Authentication.ValidateUser(package.Authentication) && validateProject)
            {
                var result = BiddingDomain.UpdateTimeAndItemTypeForPackages(package.BulkPackageFieldValue);

                if (result.ResultCode == MessageManager.GetEnumResultCode(MessageCode.Fail))
                {
                    if (result.Reason == MessageManager.GetEnumResultReason(MessageCode.Info001))
                    {
                        Logger.WriteInfoLog(string.Format("Method: UpdateTimeAndItemTypeForPackages ended - Status Code : {0}", result.Reason));

                        return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
                    }
                    else
                    {
                        Logger.WriteInfoLog(string.Format("Method: UpdateTimeAndItemTypeForPackages ended - Status Code : {0}", result.Reason));

                        return Content(HttpStatusCode.InternalServerError, result, new JsonMediaTypeFormatter(), "application/json");
                    }
                }
                return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
            }
            else
            {
                return Unauthorized();
            }
        }

        /// <summary>
        /// Get package types by project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackageTypesByProject"), HttpGet]
        public IHttpActionResult GetPackageTypesByProject(string prefix)
        {
            var result = BiddingDomain.GetPackageTypesByProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Category types by project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetCategoryTypesByProject"), HttpGet]
        public IHttpActionResult GetCategoryTypesByProject(string prefix)
        {
            var result = BiddingDomain.GetCategoryTypesByProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Search packages by package name or package number
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <param name="packageNameOrNumber">packageNameOrNumber</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SearchPackagesByPackageName"), HttpGet]
        public IHttpActionResult SearchPackagesByPackageNameOrNumber(string prefix, int pageno, int size, string packageNameOrNumber)
        {
            var result = BiddingDomain.SearchPackagesByPackageNameOrNumber(prefix, pageno, size, packageNameOrNumber);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get packages by packageid
        /// </summary>
        /// <param name="packageXid">packageXid</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackagebyPackageId"), HttpGet]
        public IHttpActionResult GetPackagebyPackageId(string prefix, int packageXid)
        {
            var result = BiddingDomain.GetPackagebyPackageId(prefix, packageXid);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get filtered packages based on Prefix and packageFilter
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageFilter">packageFilter</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetFilteredPackagesByProject"), HttpGet]
        public IHttpActionResult GetFilteredPackagesByProject(string prefix, string packageFilter)
        {
            var result = BiddingDomain.GetFilteredPackagesByProject(prefix, packageFilter);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get packages based on Prefix and Category
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <param name="categoryName">categoryName</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackagesByCategory"), HttpGet]
        public IHttpActionResult GetPackagesByCategory(string prefix, int pageno, int size, string categoryName)
        {
            var result = BiddingDomain.GetPackagesByCategory(prefix, pageno, size, categoryName);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get furthest package closingtime based on Prefix
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetFurthestPackageClosingTime"), HttpGet]
        public IHttpActionResult GetFurthestPackageClosingTimeByProject(string prefix)
        {
            var result = BiddingDomain.GetFurthestPackageClosingTimeByProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get leader board packages based on prefix 
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="jobject">jobject</param>        
        /// <returns>IHttpActionResult</returns>
        [Route("GetLeaderBoardPackages"), HttpPut]
        public IHttpActionResult GetLeaderBoardPackages(string prefix, JObject jobject)
        {
            var result = BiddingDomain.GetLeaderBoardPackages(prefix, jobject);

            return Content(HttpStatusCode.OK, result);
        }

    }
}
