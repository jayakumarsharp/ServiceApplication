﻿using System.Net;
using System.Net.Http.Formatting;
using System.Web.Http;
using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Exceptions;
using GreaterGiving.Tokyo.CrossCutting.Logging;

namespace GreaterGiving.Tokyo.BiddingService.Controllers
{
    [TokyoExceptionFilter, LogAspect, RoutePrefix("Bidding/API")]
    public class BidderController : ControllerBase
    {
        /// <summary>
        /// Constructor BidderController
        /// </summary>
        public BidderController()
        {
        }

        /// <summary>
        /// Constructor BidderController
        /// </summary>
        /// <param name="biddingDomain">biddingDomain</param>
        /// <param name="authentication">authentication</param>
        public BidderController(IBiddingDomain biddingDomain, IAuthentication authentication)
            : base(biddingDomain, authentication)
        {
        }

        /// <summary>
        /// Get bidder history or current buyers
        /// </summary>
        /// <param name="packageid">packageid</param>
        /// <returns>BidderOutput</returns>
        [Route("GetBidderHistoryOrCurrentBuyers"), HttpGet]
        public IHttpActionResult GetBidderHistoryOrCurrentBuyers(string prefix, int packageid)
        {
            var result = BiddingDomain.GetBidderHistoryOrCurrentBuyers(prefix, packageid);

            return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
        }
    }
}
