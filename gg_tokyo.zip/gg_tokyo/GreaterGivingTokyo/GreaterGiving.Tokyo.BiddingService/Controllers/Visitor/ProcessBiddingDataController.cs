﻿using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Exceptions;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Input;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace GreaterGiving.Tokyo.BiddingService.Controllers
{
    [TokyoExceptionFilter, LogAspect, RoutePrefix("Bidding/API")]
    public class ProcessBiddingDataController : ControllerBase
    {
        /// <summary>
        /// constructor ProcessBiddingDataController
        /// </summary>
        public ProcessBiddingDataController()
        {
        }

        /// <summary>
        /// Package Controller
        /// </summary>
        /// <param name="biddingDomain">biddingDomain</param>
        /// <param name="authentication">authentication</param>
        public ProcessBiddingDataController(IBiddingDomain biddingDomain, IAuthentication authentication)
            : base(biddingDomain, authentication)
        {
        }

        /// <summary>
        /// Inserts or Update or Delete for Update Project/Package/Bidder/Sponsor
        /// </summary>
        /// <param name="jobject">jobject</param>
        /// <returns>IHttpActionResult</returns>
        [Route("ProcessMobileBiddingData"), HttpPost]
        public IHttpActionResult ProcessMobileBiddingData(JObject jobject)
        {
            var serializeObject = JsonConvert.SerializeObject(jobject["authentication"]);
            var authentication = JsonConvert.DeserializeObject<AuthenticationInput>(serializeObject);

            var validateProject = BiddingDomain.ValidateProject(authentication.ProjectID);

            if (Authentication.ValidateUser(authentication) && validateProject)
            {
                var result = BiddingDomain.ProcessMobileBiddingData(jobject);
                if (result.ResultCode == MessageManager.GetEnumResultCode(MessageCode.Fail))
                {
                    return Content(HttpStatusCode.InternalServerError, result, new JsonMediaTypeFormatter(), "application/json");
                }

                return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
            }
            else
            {
                return Unauthorized();
            }
        }
    }
}
