﻿using System.Net;
using System.Net.Http.Formatting;
using System.Web.Http;
using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Exceptions;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.Foundation.Identity;
using GreaterGiving.Tokyo.SendSaleData.Model;

namespace GreaterGiving.Tokyo.BiddingService.Controllers
{
    [TokyoExceptionFilter, TokyoAuthenticationFilter, LogAspect, RoutePrefix("SecureBidding/API")]
    public class PackageBidderController : ControllerBase
    {
        /// <summary>
        /// Constructor PackageController
        /// </summary>
        public PackageBidderController()
        {
        }
        /// <summary>
        /// Package Controller
        /// </summary>
        /// <param name="biddingDomain">biddingDomain</param>
        /// <param name="authentication">authentication</param>
        public PackageBidderController(IBiddingDomain biddingDomain, IAuthentication authentication)
            : base(biddingDomain, authentication)
        {
        }

        /// <summary>
        /// Get Project using prefix
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetProject"), HttpGet]
        public IHttpActionResult GetProject(string prefix)
        {
            var result = BiddingDomain.GetProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Project by project Key
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetProjectByProjectKey"), HttpGet]
        public IHttpActionResult GetProjectByProjectKey(string projectKey)
        {
            var result = BiddingDomain.GetProjectByProjectKey(projectKey);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Gets all packages based on Prefix
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetAllPackages"), HttpGet]
        public IHttpActionResult GetAllPackages(string prefix)
        {
            var result = BiddingDomain.GetAllPackages(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Gets Packages based on Prefix,PageNo and Size
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <param name="packageFilterType">packageFilterType</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackages"), HttpGet]
        public IHttpActionResult GetPackages(string prefix, int pageno, int size, string packageFilterType)
        {
            var result = BiddingDomain.GetPackages(prefix, pageno, size, packageFilterType);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Gets Related Packages using PackageXid
        /// </summary>
        /// <param name="packageXid">packageXid</param>
        /// <param name="displayedPackages">displayedPackages</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetRelatedPackages"), HttpGet]
        public IHttpActionResult GetRelatedPackages(string prefix, int packageXid, string displayedPackages)
        {
            var result = BiddingDomain.GetRelatedPackages(prefix, packageXid, displayedPackages);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get package types by project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackageTypesByProject"), HttpGet]
        public IHttpActionResult GetPackageTypesByProject(string prefix)
        {
            var result = BiddingDomain.GetPackageTypesByProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Category types by project
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetCategoryTypesByProject"), HttpGet]
        public IHttpActionResult GetCategoryTypesByProject(string prefix)
        {
            var result = BiddingDomain.GetCategoryTypesByProject(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Search packages by package name or package number
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <param name="packageNameOrNumber">packageNameOrNumber</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SearchPackagesByPackageName"), HttpGet]
        public IHttpActionResult SearchPackagesByPackageNameOrNumber(string prefix, int pageno, int size, string packageNameOrNumber)
        {
            var result = BiddingDomain.SearchPackagesByPackageNameOrNumber(prefix, pageno, size, packageNameOrNumber);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get packages by packageid
        /// </summary>
        /// <param name="packageXid">packageXid</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackagebyPackageId"), HttpGet]
        public IHttpActionResult GetPackagebyPackageId(string prefix, int packageXid)
        {
            var result = BiddingDomain.GetPackagebyPackageId(prefix, packageXid);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get filtered packages based on Prefix and packageFilter
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageFilter">packageFilter</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetFilteredPackagesByProject"), HttpGet]
        public IHttpActionResult GetFilteredPackagesByProject(string prefix, string packageFilter)
        {
            var result = BiddingDomain.GetFilteredPackagesByProject(prefix, packageFilter);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get packages based on Prefix and Category
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <param name="categoryName">categoryName</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetPackagesByCategory"), HttpGet]
        public IHttpActionResult GetPackagesByCategory(string prefix, int pageno, int size, string categoryName)
        {
            var result = BiddingDomain.GetPackagesByCategory(prefix, pageno, size, categoryName);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Add or Remove favorite package to bidderlist
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <param name="isFavorite">isFavorite</param>
        /// <returns>IHttpActionResult</returns>
        [Route("AddOrRemoveFavoriteByBidder"), HttpPost]
        public IHttpActionResult AddOrRemoveFavoriteByBidder(string prefix, int packageid, bool isFavorite)
        {
            BiddingDomain.AddOrRemoveFavorite(prefix, packageid, isFavorite);

            return Content(HttpStatusCode.OK, new JsonMediaTypeFormatter());
        }

        /// <summary>
        /// Get favorite packages from bidderlist
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="pageno">pageno</param>
        /// <param name="size">size</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetFavoritePackagesByBidder"), HttpGet]
        public IHttpActionResult GetFavoritePackagesByBidder(string prefix, int pageno, int size)
        {
            var result = BiddingDomain.GetFavoritePackagesByBidder(prefix, pageno, size);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Add Bid
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <param name="amount">amount</param>
        /// <returns>IHttpActionResult</returns>
        [Route("AddBid"), HttpPost]
        public IHttpActionResult AddBid(string prefix, int packageId, decimal amount)
        {
            var result = BiddingDomain.AddBid(prefix, packageId, amount);
            
            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Add Bid More
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <param name="amount">amount</param>
        /// <returns>IHttpActionResult</returns>
        [Route("BidMore"), HttpPost]
        public IHttpActionResult BidMore(string prefix, int packageId, decimal amount)
        {
            var result = BiddingDomain.BidMore(prefix, packageId, amount);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Set Max Bid
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageId">packageId</param>
        /// <param name="amount">amount</param>
        /// <returns>IHttpActionResult</returns>
        [Route("SetMaxBid"), HttpPost]
        public IHttpActionResult SetMaxBid(string prefix, int packageId, decimal amount)
        {
            var result = BiddingDomain.SetMaxBid(prefix, packageId, amount);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Gets Bid Activity Packages
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [Route("GetBidActivityPackages"), HttpGet]
        public IHttpActionResult GetBidActivityByBidder(string prefix, string activityType, int pageno, int size)
        {
            var result = BiddingDomain.GetBidActivityByBidder(prefix, activityType, pageno, size);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get bidder history or current buyers
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetBidderHistoryOrCurrentBuyers"), HttpGet]
        public IHttpActionResult GetBidderHistoryOrCurrentBuyers(string prefix, int packageid)
        {
            var result = BiddingDomain.GetBidderHistoryOrCurrentBuyers(prefix, packageid);

            return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
        }

        /// <summary>
        /// Get bidder by BidderKey
        /// </summary>
        /// <param name="bidderKey">bidderKey</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetBidderByBidderKey"), HttpGet]
        public IHttpActionResult GetBidderByBidderKey(string bidderKey)
        {
            var result = BiddingDomain.GetBidderByBidderKey(bidderKey);

            return Content(HttpStatusCode.OK, result, new JsonMediaTypeFormatter(), "application/json");
        }

        /// <summary>
        /// Gets Appeal Donation Package
        /// </summary>
        /// <returns>IHttpActionResult</returns>
        [Route("GetAppealDonationPackage"), HttpGet]
        public IHttpActionResult GetAppealDonationPackage(string prefix)
        {
            var result = BiddingDomain.GetAppealDonationPackage(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Buy Regular Package
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <returns>IHttpActionResult</returns>
        [Route("BuyRegularPackage"), HttpPost]
        public IHttpActionResult BuyRegularPackage(string prefix, int packageId)
        {
            var result = BiddingDomain.BuyRegularPackage(prefix , packageId);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Buy MultiSale Packages
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <param name="quantity">quantity</param>
        /// <returns>IHttpActionResult</returns>
        [Route("BuyMultiSalePackages"), HttpPost]
        public IHttpActionResult BuyMultiSalePackages(string prefix, int packageId, int quantity)
        {
            var result = BiddingDomain.BuyMultiSalePackages(prefix, packageId, quantity);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Buy Donation Packages
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="packageid">packageid</param>
        /// <param name="amount">amount</param>
        /// <returns>IHttpActionResult</returns>
        [Route("BuyDonationPackage"), HttpPost]
        public IHttpActionResult BuyDonationPackage(string prefix, int packageId, decimal amount)
        {
            var result = BiddingDomain.BuyDonationPackage(prefix, packageId, amount);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Buy Appeal Donation Packages
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <param name="donationAmount">donationAmount</param>
        /// <returns>IHttpActionResult</returns>
        [Route("BuyAppealDonationPackage"), HttpPost]
        public IHttpActionResult BuyAppealDonationPackage(string prefix, decimal donationAmount)
        {
            var result = BiddingDomain.BuyAppealDonationPackage(prefix, donationAmount);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Get Sponsor Images By Prefix
        /// </summary>
        /// <param name="prefix">prefix</param>
        /// <returns>IHttpActionResult</returns>
        [Route("GetSponsorImagesByPrefix"), HttpGet]
        public IHttpActionResult GetSponsorImagesByPrefix(string prefix)
        {
            var result = BiddingDomain.GetSponsorImagesByPrefix(prefix);

            return Content(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Send Sale Data
        /// </summary>
        /// <param name="SaleId">SaleId</param>
        /// <returns>IHttpActionResult</returns>
        [Route("Sales/{saleID}"), HttpPost]
        public IHttpActionResult SendSaleData(int saleID, SaleData saleData)
        {
            var result = BiddingDomain.SendSaleData(saleID, saleData);

            return Content(HttpStatusCode.OK, result);
        }
    }
}
