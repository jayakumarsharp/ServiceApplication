﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using Twilio.AspNet.Mvc;
using Twilio.TwiML;

namespace GreaterGiving.Tokyo.BiddingService.Controllers.Twilio
{
    public class SMSInboundResponseController : TwilioController
    {
        [HttpPost]
        public ActionResult InboundSMS()
        {
            string requestBody = Request.Form["Body"];
            string requestFromPhoneNo = Request.Form["From"];
            var response = new MessagingResponse();

            if (string.IsNullOrWhiteSpace(requestBody) && string.IsNullOrWhiteSpace(requestFromPhoneNo))
                return TwiML(response);

            if (requestBody.Trim().ToLower() == "help")
            {
                response.Message(ConfigManager.TwilioHelpMessage);
            }
            else if (requestBody.Trim().ToLower() == "stop")
            {
                var result = UnsubscribePhoneNo(requestFromPhoneNo, requestBody);
                response.Message(ConfigManager.TwilioStopMessage);
            }
            else if (requestBody.Trim().ToLower() == "start")
            {
                var result = SubscribePhoneNo(requestFromPhoneNo, requestBody);
            }

            return TwiML(response);
        }

        public async Task UnsubscribePhoneNo(string phoneNo, string body)
        {
            var httpClient = new HttpClient();
            var content = new FormUrlEncodedContent(new[] { new KeyValuePair<string, string>("", "") });
            var responsePost = await httpClient.PostAsync(ConfigManager.BiddingBaseURL + "Bidding/API/SMSUnsubscribe?phoneNo=" + Url.Encode(phoneNo), content).ConfigureAwait(false);
        }

        public async Task SubscribePhoneNo(string phoneNo, string body)
        {
            var httpClient = new HttpClient();
            var content = new FormUrlEncodedContent(new[] { new KeyValuePair<string, string>("", "") });
            var responsePost = await httpClient.PostAsync(ConfigManager.BiddingBaseURL + "Bidding/API/SMSSubscribe?phoneNo=" + Url.Encode(phoneNo), content).ConfigureAwait(false);
        }
    }
}