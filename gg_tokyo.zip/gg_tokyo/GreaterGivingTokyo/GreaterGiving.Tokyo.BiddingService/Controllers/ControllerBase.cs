﻿using System;
using System.ComponentModel.Composition;
using System.Web.Http;
using GreaterGiving.Tokyo.Bidding.DataAccess.Contracts;
using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.Foundation.Container;
using GreaterGiving.Tokyo.Foundation.Contracts;
using GreaterGiving.Tokyo.GatewayManager.Contract;

namespace GreaterGiving.Tokyo.BiddingService.Controllers
{
    public class ControllerBase : ApiController
    {
        #region Fields & Constants

        private IBiddingDomain _biddingDomain;
        private IAuthentication _authentication;

        [Import]
        private Lazy<IBiddingDomain> _lazyBiddingDomain;

        [Import]
        private Lazy<IAuthentication> _lazyauthentication;
        #endregion Fields & Constants

        #region Properties

        protected IBiddingDomain BiddingDomain
        {
            get
            {
                return _biddingDomain ?? (_biddingDomain = _lazyBiddingDomain.Value);
            }
        }

        protected IAuthentication Authentication
        {
            get
            {
                return _authentication ?? (_authentication = _lazyauthentication.Value);
            }
        }

        #endregion Properties

        #region Constructors

        protected ControllerBase()
        {
            TokyoContainer.ComposeContainer(this, typeof(IBiddingDomain), typeof(IBiddingData), typeof(IFoundation), typeof(IAuthentication), typeof(ISendSaleData));
        }

        protected ControllerBase(IBiddingDomain biddingDomain, IAuthentication authentication)
        {
            _biddingDomain = biddingDomain;
            _authentication = authentication;
        }

        #endregion Constructors     
    }
}
