﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Threading.Tasks;
using GreaterGiving.Tokyo.Bidding.DataAccess.Common;
using GreaterGiving.Tokyo.Bidding.DataAccess.Contracts;
using GreaterGiving.Tokyo.Bidding.Domain.Contracts;
using GreaterGiving.Tokyo.CrossCutting.Common;
using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.CrossCutting.Crypto;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.CrossCutting.Messages;
using GreaterGiving.Tokyo.Entities.Constants;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.GatewayManager.Cloud;
using GreaterGiving.Tokyo.GatewayManager.Contract;
using GreaterGiving.Tokyo.Hubs;
using GreaterGiving.Tokyo.SendSaleData.Model;
using Newtonsoft.Json.Linq;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.PowerBI.Api.V2;
using Microsoft.PowerBI.Api.V2.Models;
using Microsoft.Rest;
using System.Web;
using System.Text.RegularExpressions;

namespace GreaterGiving.Tokyo.API.Domain.Core
{
    [Export(typeof(IBiddingDomain)), LogAspect, PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class BiddingDomain : IBiddingDomain
    {
        #region Private Fields & Constants

        private IStorageManager _storageManager;
        private IBiddingData _biddingData;
        private ISendSaleData _sendSaleData;

        private static readonly string Username = ConfigManager.PBIUserName;
        private static readonly string Password = ConfigManager.PBIPassword;
        private static readonly string AuthorityUrl = ConfigManager.PBIAuthorityUrl;
        private static readonly string ResourceUrl = ConfigManager.PBIResourceUrl;
        private static readonly string ClientId = ConfigManager.PBIClientId;
        private static readonly string ApiUrl = ConfigManager.PBIApiUrl;
        private static readonly string GroupId = ConfigManager.PBIGroupId;
        private static readonly string ReportId = ConfigManager.PBIReportId;

        #endregion Private Fields & Constants

        #region Constructors

        /// <summary>
        /// Creates an biddingDomain object
        /// </summary>
        [ImportingConstructor]
        public BiddingDomain(IBiddingData biddingData
            , IStorageManager storageManager
            , ISendSaleData sendSaleData)
        {
            _storageManager = storageManager;
            _biddingData = biddingData;
            _sendSaleData = sendSaleData;
        }

        #endregion Constructors

        #region IBiddingDomain Members

        public bool ValidateProject(int projectXid)
        {
            return _biddingData.ValidateProject(projectXid);
        }

        public ProjectOutput GetProject(string prefix)
        {
            return _biddingData.GetProject(prefix);
        }

        public ProjectOutput GetProjectByProjectKey(string projectKey)
        {
            return _biddingData.GetProjectByProjectKey(projectKey);
        }

        public ResultModel IsShortNameAvailable(string shortName)
        {
            return _biddingData.IsShortNameAvailable(shortName);
        }

        public ResultModel CreateProject(ProjectFieldValues project)
        {
            var result = _biddingData.CreateProject(project);

            if (project.ProjectImage != null || project.AppealImage != null)
            {
                bool storageResult = _storageManager.StoreProjectImages(project.ProjectXid, project.ProjectImage, project.AppealImage);
            }
            UpdateEventStatisticsReportByPrefix(project.Prefix);
            return result;
        }

        public ResultModel SendSMS(TextMessageFieldValues message, int? bidderId = null, int? purposeType = null)
        {
            ResultModel result = new ResultModel();
            try
            {
                //check whether Phone Number and Message is null or empty,since these are required columns
                if ((!string.IsNullOrEmpty(message.Phone)) && (!string.IsNullOrEmpty(message.Message)))
                {
                    //check whether the SMS is from SendSMS or AddBid. if sendSMS then bidderid is null so welcome message otherwise it will be from outbid.
                    var purpose = (purposeType == null) ? ((bidderId == null)
                        ? GetCodeLookupByType_Description(CodeLookupConstants.CodeType_SMSPurposeType, CodeLookupConstants.CodeSMSPurposeType_Welcome).CodeValue
                                    : GetCodeLookupByType_Description(CodeLookupConstants.CodeType_SMSPurposeType, CodeLookupConstants.CodeSMSPurposeType_Outbid).CodeValue)
                                    : GetCodeLookupByType_Description(CodeLookupConstants.CodeType_SMSPurposeType, CodeLookupConstants.CodeSMSPurposeType_RegistrationOpen).CodeValue;

                    //Check Unsubscribed PhoneNo to block
                    var unsubscribePhoneNos = _biddingData.GetUnsubscribePhoneNos();
                    var phoneNoStatus = unsubscribePhoneNos.Where(x => x.PhoneNo == message.Phone).FirstOrDefault();
                    if (phoneNoStatus != null)
                    {
                        var unsubscribeStatus = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error010);
                        _biddingData.InsertSMSErrorLog(unsubscribeStatus.ResultCode, unsubscribeStatus.Reason, message.Phone);
                        return MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success005);
                    }

                    if (!ValidatePhone(message.Phone))
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error011);
                        _biddingData.InsertSMSErrorLog(result.ResultCode, result.Reason, message.Phone);
                        return result;
                    }

                    //Insert in the SMSRequest table
                    var smsRequestId = InsertSMSRequest(message, purpose);
                    if (smsRequestId > 0)
                    {
                        return MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success005);
                    }
                    else
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error006);
                        _biddingData.InsertSMSErrorLog(result.ResultCode, result.Reason, message.Phone);
                    }
                    Logger.WriteInfoLog(string.Format("Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
                }
                else
                {
                    Logger.WriteInfoLog(string.Format("Phone Number or Message cannot be null,Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
                    result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error007);
                    _biddingData.InsertSMSErrorLog(result.ResultCode, result.Reason, message.Phone);
                }
            }
            catch (Exception ex)
            {
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error006, ex.Message);
                _biddingData.InsertSMSErrorLog(result.ResultCode, result.Reason, message.Phone);
            }
            return result;
        }

        private bool ValidatePhone(string phoneNo)
        {
            var isValid = false;
            if (phoneNo.Length > 0)
            {
                //it takes only numbers and omit special characters
                var phone = Regex.Replace(phoneNo, @"[^\d]", string.Empty, RegexOptions.Compiled);
                if (phone.Length >= 10)
                {
                    isValid = true;
                }
            }

            return isValid;
        }

        public int InsertSMSRequest(TextMessageFieldValues message, int purpose)
        {
            return _biddingData.InsertSMSRequest(message, purpose);
        }

        public bool InsertSMSDeliveryStatus(int smsRequestId, string toPhoneNumber, string statusIndicator, DateTime sendTime, DateTime deliveryTime, string sId, int? bidderId)
        {
            return _biddingData.InsertSMSDeliveryStatus(smsRequestId, toPhoneNumber, statusIndicator, sendTime, deliveryTime, sId, bidderId);
        }

        public void InsertUnsubscribePhoneNo(string phoneNo)
        {
            _biddingData.InsertUnsubscribePhoneNo(phoneNo);
        }

        public void DeleteUnsubscribePhoneNo(string phoneNo)
        {
            _biddingData.DeleteUnsubscribePhoneNo(phoneNo);
        }

        public ResultModel SendEmail(EmailMessageFieldValues emailMessage, int projectId, int? bidderId = null, int? purposeType = null)
        {
            ResultModel result = new ResultModel();
            try
            {
                //check whether From Email Address,To Email address,From,Message and subject columns is null or empty,considered these are required columns as of now.
                if (validateEmailRequiredParams(emailMessage))
                {
                    //check whether the Email is from SendEmail or AddBid. if SendEmail then bidderid is null so welcome message otherwise it will be from outbid.
                    var purpose = (purposeType == null) ? ((bidderId == null)
                        ? GetCodeLookupByType_Description(CodeLookupConstants.CodeType_EmailPurposeType, CodeLookupConstants.CodeEmailPurposeType_Welcome).CodeValue
                        : GetCodeLookupByType_Description(CodeLookupConstants.CodeType_EmailPurposeType, CodeLookupConstants.CodeEmailPurposeType_Outbid).CodeValue)
                        : GetCodeLookupByType_Description(CodeLookupConstants.CodeType_EmailPurposeType, CodeLookupConstants.CodeEmailPurposeType_RegistrationOpen).CodeValue;

                    //Insert in the EmailRequest table
                    var emailRequestId = InsertEmailRequest(emailMessage, projectId, purpose);
                    if (emailRequestId > 0)
                    {
                        //Call Send Grid API to Send Email and get response status from send grid
                        var deliveryStatus = CrossCutting.Email.SendEmail.SendEmailNotification(emailMessage.FromEmailAddress, emailMessage.FromName, emailMessage.Subject,
                            emailMessage.Message, emailMessage.ToEmailAddress, emailMessage.ToEmailAddress).Result;

                        int statusIndicator = (CodeLookupConstants.CodeEDSType_Accepted == deliveryStatus.StatusCode.ToString())
                                            ? GetCodeLookupByType_Description(CodeLookupConstants.CodeType_EmailDeliveryStatusesType, CodeLookupConstants.CodeEDSType_Accepted).CodeValue
                                            : GetCodeLookupByType_Description(CodeLookupConstants.CodeType_EmailDeliveryStatusesType, CodeLookupConstants.CodeEDSType_BadRequest).CodeValue;

                        var messageId = (CodeLookupConstants.CodeEDSType_Accepted == deliveryStatus.StatusCode.ToString()) ? deliveryStatus.Headers.GetValues("X-Message-Id").FirstOrDefault() : null;
                        var emailDeliveryInput = new EmailDeliveryStatusInput
                        {
                            EmailRequestId = emailRequestId,
                            EmailAddress = emailMessage.ToEmailAddress,
                            StatusIndicator = statusIndicator,
                            SendTime = DateTime.UtcNow,
                            DeliveryTime = DateTime.UtcNow,
                            DeliveryStatus = deliveryStatus.StatusCode.ToString(),
                            BidderId = bidderId,
                            MessageId = messageId
                        };

                        // Insert into EmailDelivery Status table
                        if (InsertEmailDeliveryStatus(emailDeliveryInput))
                        {
                            Logger.WriteInfoLog(string.Format("Successfully handed message to SendGrid API for the Email Address: {0}", emailMessage.ToEmailAddress));
                            result = MessageManager.GetResultMessage(MessageCode.Success, MessageCode.Success005);
                        }
                    }
                    else
                    {
                        result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error006);
                        Logger.WriteInfoLog(string.Format("Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
                    }
                }
                else
                {
                    result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error009);
                    Logger.WriteInfoLog(string.Format("Result Code: {0}, Result Reason: {1}", result.ResultCode, result.Reason));
                }
            }
            catch (Exception ex)
            {
                Logger.WriteErrorLog(string.Format("Method: SendEmail, ProjectXid: {0}, From Email Address: {1}, To Email Address: {2}, Message: {3},Error: {4}", projectId, emailMessage.FromEmailAddress, emailMessage.ToEmailAddress, emailMessage.Message, ex.Message.ToString()));
                result = MessageManager.GetResultMessage(MessageCode.Fail, MessageCode.Error006);
            }
            return result;
        }

        private bool validateEmailRequiredParams(EmailMessageFieldValues emailMessage)
        {
            return ((!string.IsNullOrEmpty(emailMessage.FromEmailAddress)) && (!string.IsNullOrEmpty(emailMessage.ToEmailAddress))
                && (!string.IsNullOrEmpty(emailMessage.Message)) && (!string.IsNullOrEmpty(emailMessage.Subject))
                && (!string.IsNullOrEmpty(emailMessage.FromName))) ? true : false;
        }

        public int InsertEmailRequest(EmailMessageFieldValues emailMessage, int projectId, int purpose)
        {
            return _biddingData.InsertEmailRequest(emailMessage, projectId, purpose);
        }

        public bool InsertEmailDeliveryStatus(EmailDeliveryStatusInput emailDeliveryStatusInput)
        {
            return _biddingData.InsertEmailDeliveryStatus(emailDeliveryStatusInput);
        }

        public List<PackageOutput> GetAllPackages(string prefix)
        {
            return _biddingData.GetAllPackages(prefix);
        }

        public List<PackageOutput> GetPackages(string prefix, int pageno, int size, string packageFilterType)
        {
            return _biddingData.GetPackages(prefix, pageno, size, packageFilterType);
        }

        public List<PackageOutput> GetRelatedPackages(string prefix, int packageXid, string displayedPackages)
        {
            return _biddingData.GetRelatedPackages(prefix, packageXid, displayedPackages);
        }

        public PackageOutput GetPackagebyPackageId(string prefix, int packageXid)
        {
            return _biddingData.GetPackagebyPackageId(prefix, packageXid);
        }

        public List<BidderOutput> GetBidderHistoryOrCurrentBuyers(string prefix, int packageid)
        {
            return _biddingData.GetBidderHistoryOrCurrentBuyers(prefix, packageid);
        }

        public BidderOutput GetBidderByBidderKey(string bidderKey)
        {
            BidderOutput bidderDetail = new BidderOutput();

            var bidder = _biddingData.GetBidderByBidderKey(bidderKey);
            var project = _biddingData.GetProjectByProjectId(bidder.ProjectXid);
            if (bidder != null && project != null)
            {
                bidderDetail.SupporterName = bidder.SupporterName;
                bidderDetail.Number = bidder.Number;
                bidderDetail.OnlineBidderKey = bidder.OnlineBidderKey.Trim();
                bidderDetail.TableNumber = bidder.TableNumber;
                bidderDetail.Prefix = project.Prefix;
            }

            return bidderDetail;
        }

        public ResultModel ProcessMobileBiddingData(JObject jobject)
        {
            var inputRecordTypeString = Convert.ToString(jobject["record_type"]);
            var inputRecordFunction = Convert.ToString(jobject["record_function"]);
            Logger.WriteInfoLog(string.Format("Method ProcessMobileBiddingData , Record Type : {0} , Record Function : {1}", inputRecordTypeString, inputRecordFunction));
            switch (inputRecordTypeString)
            {
                case "users": // Project 
                    {
                        var project = JsonUtility.Deserialize<ProjectInput>(jobject);
                        if (IsDeleteBiddingData(inputRecordFunction))
                        {
                            bool deleteResult = _storageManager.DeleteProjectImages(project.ProjectFieldValue.ID);
                            var result = _biddingData.DeleteProject(project.ProjectFieldValue.ID);
                            UpdateEventStatisticsReport(project.ProjectFieldValue.ProjectXid);
                            return result;
                        }
                        else
                        {
                            var result = _biddingData.UpdateProject(project.ProjectFieldValue);

                            if (project.ProjectFieldValue.ProjectImage == null)
                            {
                                _storageManager.DeleteProjectImages(project.ProjectFieldValue.ProjectXid);
                            }
                            else if (project.ProjectFieldValue.ProjectImage != null || project.ProjectFieldValue.AppealImage != null)
                            {
                                bool storageResult = _storageManager.StoreProjectImages(project.ProjectFieldValue.ProjectXid, project.ProjectFieldValue.ProjectImage, project.ProjectFieldValue.AppealImage);
                            }

                            if (result.ResultCode == MessageManager.GetEnumResultCode(MessageCode.Success))
                            {
                                SignalRHub.GetUpdatedProject(project.ProjectFieldValue.Prefix);
                                UpdateEventStatisticsReport(project.ProjectFieldValue.ProjectXid);
                            }

                            return result;
                        }
                    }
                case "items": // Package
                    {
                        var package = JsonUtility.Deserialize<PackageInput>(jobject);
                        if (IsDeleteBiddingData(inputRecordFunction))
                        {
                            var packageDetail = _biddingData.GetPackagebyPackageId(package.PackageFieldValue.PackageXid);
                            bool deleteResult = packageDetail != null ? _storageManager.DeletePackageImages(packageDetail.ProjectXid, package.PackageFieldValue.PackageXid) : false;
                            var result = _biddingData.DeletePackage(package.PackageFieldValue.PackageXid);
                            UpdateEventStatisticsReport(package.PackageFieldValue.ProjectXid);
                            return result;
                        }
                        else
                        {
                            var result = _biddingData.AddOrUpdatePackage(package.PackageFieldValue);

                            if (package.PackageFieldValue.Images == null)
                            {
                                _storageManager.DeletePackageImages(package.PackageFieldValue.ProjectXid, package.PackageFieldValue.PackageXid);
                            }
                            else if (package.PackageFieldValue.Images != null && package.PackageFieldValue.Images.Any(img => img != null))
                            {
                                bool storageResult = _storageManager.StorePackageImages(package.PackageFieldValue.ProjectXid, package.PackageFieldValue.PackageXid, package.PackageFieldValue.Images);
                            }

                            if (result.ResultCode == MessageManager.GetEnumResultCode(MessageCode.Success))
                            {
                                SignalRHub.GetUpdatedPackages(package.PackageFieldValue.PackageXid);
                                UpdateEventStatisticsReport(package.PackageFieldValue.ProjectXid);
                            }

                            return result;
                        }
                    }
                case "bidders": // Bidder
                    {
                        var bidder = JsonUtility.Deserialize<BidderInput>(jobject);
                        if (IsDeleteBiddingData(inputRecordFunction))
                        {
                            var result = _biddingData.DeleteBidder(bidder.BidderFieldValue.BidderXid);
                            UpdateEventStatisticsReport(bidder.BidderFieldValue.ProjectXid);
                            return result;
                        }
                        else
                            return _biddingData.AddOrUpdateBidder(bidder.BidderFieldValue);
                    }
                case "sponsors": // Sponsors
                    {
                        var sponsor = JsonUtility.Deserialize<SponsorInput>(jobject);

                        if (IsDeleteBiddingData(inputRecordFunction))
                        {
                            var sponsorOutput = GetSponsorBySponsorId(sponsor.SponsorFieldValue.SponsorXid);
                            bool deleteResult = sponsorOutput != null ? _storageManager.DeleteSponsorImage(sponsorOutput.ProjectXid, sponsor.SponsorFieldValue.SponsorXid) : false;
                            return _biddingData.DeleteSponsor(sponsor.SponsorFieldValue.SponsorXid);
                        }
                        else
                        {
                            var result = _biddingData.AddOrUpdateSponsor(sponsor.SponsorFieldValue);

                            if (sponsor.SponsorFieldValue.Images == null)
                            {
                                _storageManager.DeleteSponsorImage(sponsor.SponsorFieldValue.ProjectXid, sponsor.SponsorFieldValue.SponsorXid);
                            }
                            else if (sponsor.SponsorFieldValue.Images != null)
                            {
                                bool storageResult = _storageManager.StoreSponsorImage(sponsor.SponsorFieldValue.ProjectXid, sponsor.SponsorFieldValue.SponsorXid, sponsor.SponsorFieldValue.Images);
                            }
                            return result;
                        }
                    }
            }

            return new ResultModel();
        }

        public SponsorOutput GetSponsorBySponsorId(int sponsorId)
        {
            return _biddingData.GetSponsorBySponsorId(sponsorId);
        }

        public List<SponsorOutput> GetSponsorImagesByPrefix(string prefix)
        {
            return _biddingData.GetSponsorImagesByPrefix(prefix);
        }

        public ResultModel UpdateTimeAndItemTypeForPackages(BulkPackageFieldValues bulkPackageFieldValues)
        {
            ResultModel result = new ResultModel();
            var sucessResultModel = MessageManager.GetEnumResultReason(MessageCode.Success002);

            result = _biddingData.UpdateTimeAndItemTypeForPackages(bulkPackageFieldValues);             /* updates date and time for the packages matched */

            var project = _biddingData.GetProjectByProjectId(bulkPackageFieldValues.ProjectXid);        /* Gets project by project id */

            if (result.Reason.ToLower().Equals(sucessResultModel.ToLower()))                            /* Validates for Succces Message */
            {
                var output = SignalRUpdatesForBulkPackageUpdate(project.Prefix, bulkPackageFieldValues); /* signalr updates for Closing Time refresh - package update and furthest package count down time */
            }

            return result;
        }

        public async Task SignalRUpdatesForBulkPackageUpdate(string prefix, BulkPackageFieldValues bulkPackageFieldValues)
        {
            await Task.Run(() =>
            {
                foreach (var packageItem in bulkPackageFieldValues.BulkPackageFields)
                {
                    SignalRHub.GetUpdatedPackages(packageItem.PackageXid);
                }
                SignalRHub.GetUpdatedCountDownTime(prefix);

            }).ConfigureAwait(false);
        }

        public List<string> GetPackageTypesByProject(string prefix)
        {
            return _biddingData.GetPackageTypesByProject(prefix);
        }

        public List<string> GetCategoryTypesByProject(string prefix)
        {
            return _biddingData.GetCategoryTypesByProject(prefix);
        }

        public List<PackageOutput> SearchPackagesByPackageNameOrNumber(string prefix, int pageno, int size, string packageNameOrNumber)
        {
            return _biddingData.SearchPackagesByPackageNameOrNumber(prefix, pageno, size, packageNameOrNumber);
        }

        public List<PackageOutput> GetFilteredPackagesByProject(string prefix, string packageFilter)
        {
            var project = _biddingData.GetProjectDetails(prefix);
            var displayLookupList = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_PackageFilterType);
            if (project != null)
            {
                if (packageFilter == GetDisplayLookupByType_Code(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_NoBids).DisplayText)
                {
                    return _biddingData.NoBidPackagesFilter(project);
                }
                else if (packageFilter == GetDisplayLookupByType_Code(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_CurrentlyOpen).DisplayText)
                {
                    return _biddingData.CurrentlyOpenPackagesFilter(project);
                }
                else if (packageFilter == GetDisplayLookupByType_Code(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_BuyNow).DisplayText)
                {
                    return _biddingData.BuyNowPackagesFilter(project);
                }
                else if (packageFilter == GetDisplayLookupByType_Code(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_Multisale).DisplayText)
                {
                    return _biddingData.MultiSalePackagesFilter(project);
                }
                else if (packageFilter == GetDisplayLookupByType_Code(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_PreviewOnly).DisplayText)
                {
                    return _biddingData.PreviewOnlyPackagesFilter(project);
                }
                else if (packageFilter == GetDisplayLookupByType_Code(displayLookupList, DisplayLookupConstants.DisplayPackageFilterType_OpeningSoon).DisplayText)
                {
                    return _biddingData.OpeningSoonPackagesFilter(project);
                }
            }

            return new List<PackageOutput>();
        }

        public List<PackageOutput> GetPackagesByCategory(string prefix, int pageno, int size, string categoryName)
        {
            return _biddingData.GetPackagesByCategory(prefix, pageno, size, categoryName);
        }

        public List<PackageOutput> GetFavoritePackagesByBidder(string prefix, int pageno, int size)
        {
            return _biddingData.GetFavoritePackagesByBidder(prefix, pageno, size);
        }

        public List<PackageOutput> GetBidActivityByBidder(string prefix, string activityType, int pageno, int size)
        {
            List<PackageOutput> packages = new List<PackageOutput>();

            packages = _biddingData.GetBidActivityByBidder(prefix, activityType, pageno, size);

            return packages;
        }

        public PackageOutput GetAppealDonationPackage(string prefix)
        {
            PackageOutput package = new PackageOutput();

            package = _biddingData.GetAppealDonationPackage(prefix);

            return package;
        }

        public void AddOrRemoveFavorite(string prefix, int packageId, bool isFavorite)
        {
            _biddingData.AddOrRemoveFavorite(prefix, packageId, isFavorite);
            SignalRHub.GetUpdatedPackages(packageId);
        }

        public ResultMessage AddBid(string prefix, int packageId, decimal amount)
        {
            ResultMessage result = new ResultMessage();
            result = _biddingData.AddBid(prefix, packageId, amount, CodeLookupConstants.CodeBidType_Bid);
            var output = SignalRUpdatesForBid(result, prefix, packageId);
            return result;
        }

        public async Task SignalRUpdatesForBid(ResultMessage result, string prefix, int packageId)
        {
            await Task.Run(() =>
            {
                SendBiddingNotification(result, prefix, packageId);
                SignalRHub.GetUpdatedPackages(packageId);
                SignalRHub.GetTopBidders(prefix);
                SignalRHub.GetTopPackages(prefix);
                GetUpdatedBiddingHistory(prefix, packageId);
                UpdateEventStatisticsReportByPrefix(prefix);
            }).ConfigureAwait(false);
        }

        public ResultMessage BidMore(string prefix, int packageId, decimal amount)
        {
            ResultMessage result = new ResultMessage();
            result = _biddingData.AddBid(prefix, packageId, amount, CodeLookupConstants.CodeBidType_BidMore);
            var output = SignalRUpdatesForBid(result, prefix, packageId);
            return result;
        }

        public ResultMessage SetMaxBid(string prefix, int packageId, decimal amount)
        {
            ResultMessage result = new ResultMessage();
            result = _biddingData.SetMaxBid(prefix, packageId, amount, CodeLookupConstants.CodeBidderActionType_MaxBid);
            var output = SignalRUpdatesForMaxBid(result, prefix, packageId);
            return result;
        }

        public async Task SignalRUpdatesForMaxBid(ResultMessage result, string prefix, int packageId)
        {
            await Task.Run(() =>
            {
                SendBiddingNotification(result, prefix, packageId);
                SignalRHub.GetUpdatedPackages(packageId);
                GetUpdatedBiddingHistory(prefix, packageId);
                UpdateEventStatisticsReportByPrefix(prefix);
            }).ConfigureAwait(false);
        }

        public ResultMessage BuyRegularPackage(string prefix, int packageId)
        {
            ResultMessage message = new ResultMessage();
            var sale = _biddingData.BuyRegularPackage(prefix, packageId);
            if (sale != null)
            {

                var output = SignalRUpdatesForRegularPackage(prefix, packageId, sale.SaleID);
                message.Message = GetResultMessage(DisplayLookupConstants.DisplayType_ResultStatusType, DisplayLookupConstants.DisplayResultStatusType_Success);
            }
            else
            {
                message.Message = GetResultMessage(DisplayLookupConstants.DisplayType_ResultStatusType, DisplayLookupConstants.DisplayResultStatusType_Failure);
            }
            return message;
        }

        public async Task SignalRUpdatesForRegularPackage(string prefix, int packageId, int saleId)
        {
            var packageType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SalePackageType, CodeLookupConstants.CodeSalePackageType_Auction).CodeValue;
            await Task.Run(() =>
            {
                SendAndUpdateSaleData(saleId, packageType);
                SignalRHub.GetUpdatedPackages(packageId);
                SignalRHub.GetTopBidders(prefix);
                SignalRHub.GetTopPackages(prefix);
                GetUpdatedBiddingHistory(prefix, packageId);
                UpdateEventStatisticsReportByPrefix(prefix);
            }).ConfigureAwait(false);
        }

        public ResultMessage BuyMultiSalePackages(string prefix, int packageId, int quantity)
        {
            ResultMessage message = new ResultMessage();
            var sale = _biddingData.BuyMultiSalePackages(prefix, packageId, quantity);
            if (sale != null)
            {
                var output = SignalRUpdatesForSalePackage(prefix, packageId, sale.SaleID);
                message.Message = GetResultMessage(DisplayLookupConstants.DisplayType_ResultStatusType, DisplayLookupConstants.DisplayResultStatusType_Success);
            }
            else
            {
                message.Message = GetResultMessage(DisplayLookupConstants.DisplayType_ResultStatusType, DisplayLookupConstants.DisplayResultStatusType_Failure);
            }
            return message;
        }

        public void UpdateEventStatisticsReportByPrefix(string prefix)
        {
            var project = GetProject(prefix);
            if (project != null)
            {
                UpdateEventStatisticsReport(project.ProjectXid);
            }
        }

        public void UpdateEventStatisticsReport(int projectXid)
        {
            try
            {
                _biddingData.UpdateEventStatisticsReport(projectXid);
            }
            catch(Exception exception)
            {
                Logger.WriteErrorLog(string.Format("Method: UpdateEventStatisticsReport, ProjectXid: {0}, Error: {1}", projectXid, exception.Message.ToString()));
            }
        }

        public async Task SignalRUpdatesForSalePackage(string prefix, int packageId, int saleId)
        {
            var packageType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SalePackageType, CodeLookupConstants.CodeSalePackageType_Auction).CodeValue;
            await Task.Run(() =>
            {
                SendAndUpdateSaleData(saleId, packageType);
                SignalRHub.GetUpdatedPackages(packageId);
                GetUpdatedBiddingHistory(prefix, packageId);
                UpdateEventStatisticsReportByPrefix(prefix);
            }).ConfigureAwait(false);
        }

        public ResultMessage BuyDonationPackage(string prefix, int packageId, decimal amount)
        {
            ResultMessage message = new ResultMessage();
            var sale = _biddingData.BuyDonationPackage(prefix, packageId, amount);
            if (sale != null)
            {
                var output = SignalRUpdatesForSalePackage(prefix, packageId, sale.SaleID);
                message.Message = GetResultMessage(DisplayLookupConstants.DisplayType_ResultStatusType, DisplayLookupConstants.DisplayResultStatusType_Success);
            }
            else
            {
                message.Message = GetResultMessage(DisplayLookupConstants.DisplayType_ResultStatusType, DisplayLookupConstants.DisplayResultStatusType_Failure);
            }
            return message;
        }

        public ResultMessage BuyAppealDonationPackage(string prefix, decimal donationAmount)
        {
            ResultMessage message = new ResultMessage();
            var sale = _biddingData.BuyAppealDonationPackage(prefix, donationAmount);
            if (sale != null)
            {
                var packageType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SalePackageType, CodeLookupConstants.CodeSalePackageType_Donation).CodeValue;
                var output = SignalRUpdatesForAppealPackage(prefix, sale.PackageXid, sale.SaleID);
                message.Message = GetResultMessage(DisplayLookupConstants.DisplayType_ResultStatusType, DisplayLookupConstants.DisplayResultStatusType_Success);
            }
            else
            {
                message.Message = GetResultMessage(DisplayLookupConstants.DisplayType_ResultStatusType, DisplayLookupConstants.DisplayResultStatusType_Failure);
            }
            return message;
        }

        public async Task SignalRUpdatesForAppealPackage(string prefix, int packageId, int saleId)
        {
            var packageType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SalePackageType, CodeLookupConstants.CodeSalePackageType_Donation).CodeValue;
            await Task.Run(() =>
            {
                SendAndUpdateSaleData(saleId, packageType);
                SignalRHub.GetUpdatedAppealDonationPackages(prefix);
                var bidderHistory = GetUpdatedBiddingHistory(prefix, packageId);
                var bidderDetails = bidderHistory.FirstOrDefault(x => x.BidderXid == GetCurrentBidderDetails().BidderXid);
                var bidderJson = JsonUtility.DeserializeToJobject(bidderDetails);
                var signalrInput = new SignalRInput() { Prefix = prefix, BidderDetails = bidderJson };
                SignalRHub.GetUpdatedBidderForAppealDonationPackage(signalrInput);
                UpdateEventStatisticsReportByPrefix(prefix);
            }).ConfigureAwait(false);
        }

        public string GetResultMessage(string displayType, string displayCode)
        {
            return _biddingData.GetDisplayLookupListByType(displayType).FirstOrDefault(x => x.DisplayCode == displayCode).DisplayText;
        }

        public List<BidderOutput> GetUpdatedBiddingHistory(string prefix, int packageId)
        {
            var biddingHistory = _biddingData.GetBidderHistoryOrCurrentBuyers(prefix, packageId);
            if (biddingHistory.Count > 0)
            {
                var biddingHistoryJson = JsonUtility.DeserializeListofObjectToJobject(biddingHistory);
                var signalrInput = new SignalRInput() { Prefix = prefix, BiddingHistory = biddingHistoryJson, PackageXid = packageId };
                SignalRHub.GetUpdatedBiddingHistory(signalrInput);
            }
            return biddingHistory;
        }

        public bool SendSaleData(int saleID, SaleData saleData)
        {
            var ggoUpdateStatus = 0;

            var donationPackageType = GetCodeLookupByType_Description(CodeLookupConstants.CodeType_MobileBiddingType, CodeLookupConstants.CodeMobileBiddingType_Donation).CodeValue;

            var package = _biddingData.GetPackageBySaleId(saleID);

            if (package != null)
            {
                string codeSalePackageType = (package.MobileBiddingTypeID == donationPackageType)
                                            ? CodeLookupConstants.CodeSalePackageType_Donation
                                            : CodeLookupConstants.CodeSalePackageType_Auction;

                saleData.SaleId = saleID;
                saleData.PackageType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SalePackageType, codeSalePackageType).CodeValue;
            }

            var result = _sendSaleData.SendSaleDataToGGO(saleData);

            if (result.Status != null)
            {
                ggoUpdateStatus = GetCodeLookupByType_Description(CodeLookupConstants.CodeType_SaleResultType,
                    ((bool)result.Status ? CodeLookupConstants.CodeSaleResultType_Posted : CodeLookupConstants.CodeSaleResultType_Error)).CodeValue;

                _biddingData.UpdateSaleGGOUpdateStatus(saleID, ggoUpdateStatus);

                return (bool)result.Status;
            }
            else
                return false;
        }

        public void SendAndUpdateSaleData(int saleId, int packageType)
        {
            var saleData = new SaleData();
            var ggoUpdateStatus = 0;
            var getSale = _biddingData.GetSaleBySaleId(saleId);
            if (getSale != null)
            {
                saleData.SaleId = saleId;
                saleData.BidderId = getSale.BidderXid;
                saleData.PackageId = getSale.PackageXid;
                saleData.ProjectId = getSale.ProjectXid;
                saleData.SaleDate = (DateTime)getSale.SaleDate;
                saleData.SaleQuantity = (int)getSale.QtyPurchased;
                saleData.SaleTotalPreTax = getSale.Amount;
                saleData.PackageType = packageType;

                var result = _sendSaleData.SendSaleDataToGGO(saleData);

                if (result.Status != null)
                {
                    ggoUpdateStatus = GetCodeLookupByType_Description(CodeLookupConstants.CodeType_SaleResultType,
                        ((bool)result.Status ? CodeLookupConstants.CodeSaleResultType_Posted : CodeLookupConstants.CodeSaleResultType_Error)).CodeValue;

                    _biddingData.UpdateSaleGGOUpdateStatus(getSale.SaleID, ggoUpdateStatus);
                }
            }
        }

        public string Encrypt(string inputText)
        {
            return CryptoHelper.Encrypt(inputText, ConfigManager.AESPassword, ConfigManager.AESSalt);
        }

        public string Decrypt(string inputText)
        {
            return CryptoHelper.Decrypt(inputText, ConfigManager.AESPassword, ConfigManager.AESSalt);
        }

        private bool IsDeleteBiddingData(string inputRecordFunction)
        {
            return (inputRecordFunction == "delete");
        }

        private DisplayLookup GetDisplayLookupByType_Code(List<DisplayLookup> displayLookupList, string displayCode)
        {
            return displayLookupList.Where(x => x.DisplayCode == displayCode).FirstOrDefault();
        }

        public Bidder GetCurrentBidderDetails()
        {
            return _biddingData.GetCurrentBidderDetails();
        }

        //This Method is used to process Bidding Status Notification - SMS/Email when OutBid as of now
        private void ProcessBiddingStatusNotification(BidderOutput highBidItem, BidderOutput outBidBidder, Project project)
        {
            var content = string.Empty;

            //TODO : Need to Add Preferences(TOK-83) for SMS/Email Message or Both 
            if (!string.IsNullOrEmpty(outBidBidder.OnlineBidderKey))
            {
                /* Gets the package by Package Id */
                var package = GetPackagebyPackageId(project.Prefix, outBidBidder.PackageXid);

                //Check whether the SMS OutBid Notices preference for the project is set or not
                if (project.SendSmsOutbidNotices)
                {
                    content = ConstructSMSMessage(package.PackageXid ,package.Number.Trim(), highBidItem.Amount, outBidBidder.OnlineBidderKey);
                    SendSMSNotification(outBidBidder, content);
                }
                else
                    Logger.WriteInfoLog(string.Format("Preference for SMS - SendSmsOutbidNotices for this ProjectXid: {0} is set to {1}", project.ProjectXid, project.SendSmsOutbidNotices));

                //Check whether the Email OutBid Notices preference for the project is set or not
                if (project.SendEmailOutbidNotices)
                {
                    content = ConstructEmailMessage(package.PackageXid, package.Number.Trim(), highBidItem.Amount, outBidBidder.OnlineBidderKey);
                    SendEmailNotification(outBidBidder, project, content);
                }
                else
                    Logger.WriteInfoLog(string.Format("Preference for Email - SendEmailOutbidNotices for this ProjectXid: {0} is set to {1}", project.ProjectXid, project.SendEmailOutbidNotices));
            }
        }

        //sends SMS Bidding status Notification to the phone number specified
        private void SendSMSNotification(BidderOutput outBidBidder, string message)
        {
            string[] mobilePhone;

            //check whether the Phone or Message is not empty
            if (!string.IsNullOrEmpty(outBidBidder.MobilePhones) && !string.IsNullOrEmpty(message))
            {
                mobilePhone = outBidBidder.MobilePhones.Split(new string[] { AppConstants.CommaDelimiter }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string phoneNo in mobilePhone)
                {
                    //Assign Model for SMS Notification 
                    TextMessageFieldValues fieldValues = new TextMessageFieldValues();
                    fieldValues.ProjectXid = outBidBidder.ProjectXid;
                    fieldValues.Phone = phoneNo;
                    fieldValues.Message = message;

                    //Send SMS Notification
                    SendSMS(fieldValues, outBidBidder.BidderXid);
                }
            }
        }

        //sends Email Bidding status Notification to the specified emails
        private void SendEmailNotification(BidderOutput outBidBidder, Project project, string message)
        {
            string[] toEmails;

            /* Subject for Outbid Email */
            string emailSubject = ConfigManager.OutbidEmailSubject;
            

            //check whether the email and message is empty or not
            if (!string.IsNullOrWhiteSpace(outBidBidder.Emails) && !string.IsNullOrWhiteSpace(message))
            {
                toEmails = outBidBidder.Emails.Split(new string[] { AppConstants.EmailDelimiter }, StringSplitOptions.RemoveEmptyEntries);

                var package = GetPackagebyPackageId(project.Prefix, outBidBidder.PackageXid);
                emailSubject = (package!=null) ? string.Format(emailSubject, package.Number.Trim()) : string.Empty;

                foreach (string toEmail in toEmails)
                {
                    EmailMessageFieldValues emailMessage = new EmailMessageFieldValues();
                    emailMessage.FromEmailAddress = ConfigManager.EmailFromAddress;
                    emailMessage.FromName = project.ClientName ?? string.Empty;
                    emailMessage.Subject = emailSubject;
                    emailMessage.ToEmailAddress = toEmail;
                    emailMessage.Message = message;

                    SendEmail(emailMessage, project.ProjectXid, outBidBidder.BidderXid);
                }
            }
        }

        //This method used to construct the SMS message
        private string ConstructSMSMessage(int packageId, string packageNumber, decimal highBidAmount, string bidderKey)
        {
            string messageContent = string.Empty;
            string directAccessUrl = ConfigManager.DirectAccessURL;
            string message = ConfigManager.SMSMessageFormat;

            if (!string.IsNullOrEmpty(directAccessUrl) && (!string.IsNullOrEmpty(message)))
            {
                directAccessUrl = string.Format(directAccessUrl, bidderKey.Trim(), packageId.ToString());
                var formatHighBidAmount = string.Format(AppConstants.AmountFormat, highBidAmount);
                messageContent = string.Format(message, packageNumber, formatHighBidAmount, directAccessUrl);
            }
            return messageContent;
        }

        private string ConstructEmailMessage(int packageId, string packageNumber, decimal highBidAmount, string bidderKey)
        {
            string messageContent = string.Empty;
            string directAccessUrl = ConfigManager.DirectAccessURL;
            string message = ConfigManager.EmailMessageFormat;

            if (!string.IsNullOrEmpty(directAccessUrl) && (!string.IsNullOrEmpty(message)))
            {
                directAccessUrl = string.Format(directAccessUrl, bidderKey.Trim(), packageId.ToString());
                directAccessUrl = "<a href='" + directAccessUrl + "'>" + directAccessUrl + "</a>";
                var formatHighBidAmount = string.Format(AppConstants.AmountFormat, highBidAmount);
                messageContent = string.Format(message, packageNumber, formatHighBidAmount, directAccessUrl);
            }
            return messageContent;
        }

        public CodeLookup GetCodeLookupByType_Description(string type, string description)
        {
            return _biddingData.GetCodeLookupByTypeDescription(type, description);
        }

        private void SendBiddingNotification(ResultMessage result, string prefix, int packageId)
        {
            var resultStatusTypeList = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);
            var sucessMessage = resultStatusTypeList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;

            //If inserted bidder is high bidder then send sms notification to the first leading bidder
            if (result.Message.Equals(sucessMessage))
            {
                var project = _biddingData.GetProjectDetails(prefix); // gets the project details using prefix

                var bidder = _biddingData.GetCurrentBidderDetails(); // Gets the current bidder from header values

                List<BidderOutput> bidHistory = new List<BidderOutput>();
                bidHistory = _biddingData.GetBidderHistoryOrCurrentBuyers(prefix, packageId);

                //check whether the project, bidder and bidhistory values is not null
                if ((project != null) && (bidder != null) && (bidHistory.Count > 0))
                {
                    //check whether the item has high bid 
                    var highBidItem = bidHistory.FirstOrDefault();

                    /*check whether the item has out bid - used to validate whether the package has outbided */
                    var outBidItem = bidHistory.Skip(1).FirstOrDefault();    /* fetches the second record TOK-1122 for the same bidder should not send mulitple times*/

                    /*used to validate whether the package has outbided and the bidder is no longer the current bidder and the bidder already have not received any email or sms for outbid for that package */
                    if ((highBidItem != null) && (outBidItem != null) && outBidItem.BidderXid != bidder.BidderXid) /* TOK-1122 bidder already have not received any email or sms for outbid for that package */
                    {
                        //assign packageXid to the outbid model
                        outBidItem.PackageXid = packageId;

                        //Used to send SMS the bidding status notification 
                        ProcessBiddingStatusNotification(highBidItem, outBidItem, project);
                    }
                    else
                        Logger.WriteInfoLog(string.Format("The highbid : {0} or OutBid : {1} values is null", highBidItem, outBidItem));
                }
            }
        }

        public CountdownBoardOutput GetFurthestPackageClosingTimeByProject(string prefix)
        {
            CountdownBoardOutput result = new CountdownBoardOutput();
            result = _biddingData.GetFurthestPackageClosingTimeByProject(prefix);

            return result;
        }

        public List<PackageOutput> GetLeaderBoardPackages(string prefix, JObject jobject)
        {
            var leaderBoardInput = JsonUtility.Deserialize<LeaderBoardInput>(jobject);
            var resultPackages = _biddingData.GetLeaderBoardPackages(prefix, leaderBoardInput);
            return resultPackages;
        }

        public void UpdateSMSStatus(string response, int smsRequestId)
        {
            ResultModel result = new ResultModel();
            var toPhoneNumber = string.Empty;
            var smsSid = string.Empty;
            var smsStatus = string.Empty;
            try
            {
                if (response != null)
                {
                    var messsageresource = HttpUtility.ParseQueryString(response);
                    Logger.WriteInfoLog(string.Format("Method: InsertSMSDeliveryStatus, ReturnedResponse {0}", response));
                    if (messsageresource != null && messsageresource.HasKeys())
                    {
                        smsSid = messsageresource[0].ToString();
                        smsStatus = messsageresource[1].ToString();

                        _biddingData.UpdateSMSStatus(smsRequestId, smsStatus, smsSid);                        
                    }
                }
            }
            catch (Exception exe)
            {
            }
        }

        #endregion IBiddingDomain Members

        #region Admin

        public List<BidderOutput> GetTopBiddersForAdmin(string prefix, int count)
        {
            return _biddingData.GetTopBiddersForAdmin(prefix, count);
        }

        public List<BidderSearchOutput> GetAllBiddersForAdmin(string prefix, BidderSearchInput bidderSearchInput)
        {
            return _biddingData.GetAllBiddersForAdmin(prefix, bidderSearchInput);
        }

        public List<PackageOutput> GetTopPackagesForAdmin(string prefix, int count)
        {
            return _biddingData.GetTopPackagesForAdmin(prefix, count);
        }

        public List<PackageSearchOutput> GetAllPackagesForAdmin(string prefix, PackageSearchInput input)
        {
            return _biddingData.GetAllPackagesForAdmin(prefix, input);
        }
        public BidderSearchOutput GetBidderDetailsForAdmin(string prefix, int bidderId)
        {
            return _biddingData.GetBidderDetailsForAdmin(prefix, bidderId);
        }

        public List<MaxBidOutput> GetBidderMaxBidForAdmin(string prefix, int bidderId)
        {
            return _biddingData.GetBidderMaxBidForAdmin(prefix, bidderId);
        }

        public List<BidHistoryOutput> GetBidderBidHistoryForAdmin(string prefix, int bidderId)
        {
            return _biddingData.GetBidderBidHistoryForAdmin(prefix, bidderId);
        }

        public MaxBidOutput GetPackageMaxBidForAdmin(string prefix, int packageId)
        {
            return _biddingData.GetPackageMaxBidForAdmin(prefix, packageId);
        }

        public PackageSearchOutput GetPackageDetailsForAdmin(string prefix, int packageId)
        {
            return _biddingData.GetPackageDetailsForAdmin(prefix, packageId);
        }

        public List<BidHistoryOutput> GetPackageBidHistoryForAdmin(string prefix, int packageId)
        {
            return _biddingData.GetPackageBidHistoryForAdmin(prefix, packageId);
        }

        public ResultMessage ClearMaxBidForAdmin(string prefix, int packageId)
        {
            return _biddingData.ClearMaxBidForAdmin(prefix, packageId);
        }

        public ResultMessage RemoveBidForAdmin(string prefix, int bidId, int saleId)
        {
            ResultMessage result = new ResultMessage();
            int packageId = 0;  /* set default value */
            var bid = _biddingData.GetBidByBidId(bidId);
            var sale = _biddingData.GetSaleBySaleId(saleId);
            if (bid != null)
                packageId = bid.PackageXid;
            if (sale != null)
                packageId = sale.PackageXid;

            result = _biddingData.RemoveBidForAdmin(prefix, bidId, saleId);

            /* SignalR update for bidding application */
            SignalRHub.GetUpdatedPackages(packageId);
            GetUpdatedBiddingHistory(prefix, packageId);
            SignalRHub.GetUpdatedAppealDonationPackages(prefix);
            UpdateEventStatisticsReportByPrefix(prefix);

            return result;
        }

        public ResultMessage SaveEmailTemplateForAdmin(string prefix, EmailMessageFieldValues emailMessage)
        {
            return _biddingData.SaveEmailTemplateForAdmin(prefix, emailMessage);
        }

        public List<EmailTemplateOutput> GetEmailTemplatesForAdmin(string prefix)
        {
            return _biddingData.GetEmailTemplatesForAdmin(prefix);
        }

        public ResultMessage DeleteEmailTemplateForAdmin(int projectId, int emailTemplateId)
        {
            return _biddingData.DeleteEmailTemplateForAdmin(projectId, emailTemplateId);
        }

        public ResultMessage SendPreviewEmailForAdmin(string prefix, EmailMessageFieldValues emailMessage)
        {
            ResultMessage result = new ResultMessage();

            var displayLookupList = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);
            var registrationOpenType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EmailPurposeType, CodeLookupConstants.CodeEmailPurposeType_RegistrationOpen);

            try
            {
                var project = GetProject(prefix);
                if (project == null) { return result; }

                if (!string.IsNullOrWhiteSpace(emailMessage.ToEmailAddress))
                {
                    var toEmails = emailMessage.ToEmailAddress.Split(new string[] { AppConstants.EmailDelimiter }, StringSplitOptions.RemoveEmptyEntries);

                    foreach (string toEmail in toEmails)
                    {
                        EmailMessageFieldValues previewEmailMessage = new EmailMessageFieldValues();
                        previewEmailMessage.FromEmailAddress = ConfigManager.EmailFromAddress;
                        previewEmailMessage.FromName = project.ClientName ?? string.Empty;
                        previewEmailMessage.Subject = emailMessage.Subject;
                        previewEmailMessage.ToEmailAddress = toEmail;
                        previewEmailMessage.Message = emailMessage.Message;

                        SendEmail(previewEmailMessage, project.ProjectXid, null, registrationOpenType.CodeValue);
                    }
                }
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            }
            catch(Exception exception)
            {
                Logger.WriteErrorLog(string.Format("Method: SendPreviewEmailForAdmin, Prefix: {0}, To Email Address: {1}, Error: {2}", prefix, emailMessage.ToEmailAddress, exception.Message.ToString()));
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
            }

            return result;
        }

        public ResultMessage SendRegistrationEmailForAdmin(string prefix, string recipientType, EmailMessageFieldValues emailMessage)
        {
            ResultMessage result = new ResultMessage();

            var resultStatusType = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);
            var recipientTypeList = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_RecipientType);
            var allRecipientType = recipientTypeList.FirstOrDefault(x=>x.DisplayCode == DisplayLookupConstants.DisplayRecipientType_All).DisplayText;
            var winningRecipientType = recipientTypeList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayRecipientType_Winning).DisplayText;
            var nonWinningRecipientType = recipientTypeList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayRecipientType_NonWinning).DisplayText;

            try
            {
                var project = GetProject(prefix);
                if (project == null) { return result; }

                var bids = _biddingData.GetBidsByProject(project.ProjectXid);

                var winningBids = bids.GroupBy(a => a.PackageXid, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();

                /* RecipientType All Bidders - Gets Only Active bidders */
                var bidders = _biddingData.GetBidderByProjectId(project.ProjectXid);

                if (recipientType.ToLower() == allRecipientType.ToLower())
                {
                    var bidderIdsByBids = bidders.Select(x => x.BidderXid).Distinct().ToList();
                    var output = SendRegistrationEmailForBidders(project, bidderIdsByBids, emailMessage, bidders);
                }
                else if (recipientType.ToLower() == winningRecipientType.ToLower())
                {
                    var winningBidderIdsByBids = winningBids.Select(x => x.BidderXid).Distinct().ToList();
                    var output = SendRegistrationEmailForBidders(project, winningBidderIdsByBids, emailMessage, bidders);                    
                }
                else if (recipientType.ToLower() == nonWinningRecipientType.ToLower())
                {
                    List<int> nonWinningBidderIdsByBids = new List<int>();
                    foreach (Bid winningbid in winningBids)
                    {
                        var bidderids = bids.Where(x => x.PackageXid == winningbid.PackageXid && x.BidderXid != winningbid.BidderXid).Select(x => x.BidderXid).ToList();
                        nonWinningBidderIdsByBids.AddRange(bidderids);
                    }
                    var winningBidderIds = winningBids.Select(x => x.BidderXid).ToList();
                    nonWinningBidderIdsByBids = nonWinningBidderIdsByBids.Where(x => !winningBidderIds.Contains(x)).Distinct().ToList();
                    var output = SendRegistrationEmailForBidders(project, nonWinningBidderIdsByBids, emailMessage, bidders);
                }                                
                result.Message = resultStatusType.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            }
            catch (Exception exception)
            {
                Logger.WriteErrorLog(string.Format("Method: SendRegistrationEmailForAdmin, Prefix: {0}, Error: {1}", prefix, exception.Message.ToString()));
                result.Message = resultStatusType.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
            }

            return result;
        }

        public async Task SendRegistrationEmailForBidders(ProjectOutput project, List<int> bidderIds, EmailMessageFieldValues emailMessage, List<Bidder> bidders)
        {
            await Task.Run(() =>
            {
                var registrationOpenType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EmailPurposeType, CodeLookupConstants.CodeEmailPurposeType_RegistrationOpen);
                var fromAddress = ConfigManager.EmailFromAddress;

                int subjectMaxLength = (!string.IsNullOrEmpty(ConfigManager.EmailSubjectMaxLength)) ? Convert.ToInt32(ConfigManager.EmailSubjectMaxLength) : 0;      /* subject length - limiting to 250 characters */
                foreach (int bidderId in bidderIds)
                {
                    var bidderDetail = bidders.FirstOrDefault(x => x.BidderXid == bidderId);

                    /* bidder and their email should not be empty*/
                    if (bidderDetail != null && !string.IsNullOrWhiteSpace(bidderDetail.Emails))
                    {
                        var toEmails = bidderDetail.Emails.Split(new string[] { AppConstants.EmailDelimiter }, StringSplitOptions.RemoveEmptyEntries);
                        var biddingUrl = string.Format(ConfigManager.BiddingURL, bidderDetail.OnlineBidderKey);
                        var biddingUrlHtml = "<a href='" + biddingUrl + "'>" + biddingUrl + "</a>";
                        var bidderNumber = (bidderDetail.Number == null || bidderDetail.Number == 0) ? string.Empty : bidderDetail.Number.ToString();
                        var subject = emailMessage.Subject.Replace("[n]", bidderDetail.SupporterName.Trim())
                                            .Replace("[b]", bidderNumber)
                                                .Replace("[u]", biddingUrlHtml);

                        subject = (subjectMaxLength > 0 && subject.Length > subjectMaxLength) ? subject.Substring(0, subjectMaxLength - 1) : subject;     /* subject length - limiting to 250 characters */

                        var message = emailMessage.Message.Replace("[n]", bidderDetail.SupporterName.Trim())
                                            .Replace("[b]", bidderNumber)
                                                .Replace("[u]", biddingUrlHtml);
                        foreach (string toEmail in toEmails)
                        {
                            EmailMessageFieldValues sendEmailMessage = new EmailMessageFieldValues();
                            sendEmailMessage.FromEmailAddress = fromAddress;
                            sendEmailMessage.FromName = project.ClientName ?? string.Empty;
                            sendEmailMessage.Subject = subject;
                            sendEmailMessage.ToEmailAddress = toEmail;
                            sendEmailMessage.Message = message;

                            SendEmail(sendEmailMessage, project.ProjectXid, bidderId, registrationOpenType.CodeValue);
                        }
                    }
                }
            }).ConfigureAwait(false);
        }

        public List<SMSTemplateOutput> GetSMSTemplatesForAdmin(string prefix)
        {
            return _biddingData.GetSMSTemplatesForAdmin(prefix);
        }

        public ResultMessage SaveSMSTemplateForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues)
        {
            return _biddingData.SaveSMSTemplateForAdmin(prefix, textMessageFieldValues);
        }

        public ResultMessage DeleteSMSTemplateForAdmin(int projectId, int smsTemplateId)
        {
            return _biddingData.DeleteSMSTemplateForAdmin(projectId, smsTemplateId);
        }

        public ResultMessage SendPreviewSMSForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues)
        {
            ResultMessage result = new ResultMessage();

            var displayLookupList = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);
            var registrationOpenType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_EmailPurposeType, CodeLookupConstants.CodeSMSPurposeType_RegistrationOpen).CodeValue;

            try
            {
                var project = GetProject(prefix);
                if (project == null) { return result; }

                /* check whether the Phone or Message is not empty */
                if (!string.IsNullOrWhiteSpace(textMessageFieldValues.Phone) && !string.IsNullOrWhiteSpace(textMessageFieldValues.Message))
                {
                    var mobilePhone = textMessageFieldValues.Phone.Split(new string[] { AppConstants.CommaDelimiter }, StringSplitOptions.RemoveEmptyEntries);

                    foreach (string toPhoneNumber in mobilePhone)
                    {
                        /* Assign Model for SMS Notification */
                        TextMessageFieldValues previewTextfieldValues = new TextMessageFieldValues();
                        previewTextfieldValues.ProjectXid = project.ProjectXid;
                        previewTextfieldValues.Phone = toPhoneNumber;
                        previewTextfieldValues.Message = textMessageFieldValues.Message;

                        /* Send Preview SMS Notification */
                        SendSMS(previewTextfieldValues, null, registrationOpenType);
                    }
                }
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            }
            catch (Exception exception)
            {
                Logger.WriteErrorLog(string.Format("Method: SendPreviewSMSForAdmin, Prefix: {0}, To Phone Number Address: {1}, Error: {2}", prefix, textMessageFieldValues.Phone, exception.Message.ToString()));
                result.Message = displayLookupList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
            }

            return result;
        }

        public ResultMessage SendRegistrationSMSForAdmin(string prefix, string recipientType, TextMessageFieldValues textMessageFieldValues)
        {
            ResultMessage result = new ResultMessage();

            var resultStatusType = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);
            var recipientTypeList = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_RecipientType);
            var allRecipientType = recipientTypeList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayRecipientType_All).DisplayText;
            var winningRecipientType = recipientTypeList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayRecipientType_Winning).DisplayText;
            var nonWinningRecipientType = recipientTypeList.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayRecipientType_NonWinning).DisplayText;

            try
            {
                var project = GetProject(prefix);
                if (project == null) { return result; }

                /* gets all bids */
                var bids = _biddingData.GetBidsByProject(project.ProjectXid);

                /* filters only winning bids */
                var winningBids = bids.GroupBy(a => a.PackageXid, (key, b) => b.OrderByDescending(x => x.Amount).FirstOrDefault()).ToList();

                /* RecipientType All Bidders - Gets Only Active bidders */
                var bidders = _biddingData.GetBidderByProjectId(project.ProjectXid);

                if (recipientType.ToLower() == allRecipientType.ToLower())                  /* Option - All Bidders */
                {
                    var bidderIdsByBids = bidders.Select(x => x.BidderXid).Distinct().ToList();//(bidders.Count > 0) ? bidders.Select(x => x.BidderXid).Distinct().ToList() : null;
                    var output = SendRegistrationSMSForBidders(project, bidderIdsByBids, textMessageFieldValues, bidders);
                }
                else if (recipientType.ToLower() == winningRecipientType.ToLower())         /* Option - Winning Bidders */
                {
                    var winningBidderIdsByBids = winningBids.Select(x => x.BidderXid).Distinct().ToList();
                    var output = SendRegistrationSMSForBidders(project, winningBidderIdsByBids, textMessageFieldValues, bidders);
                }
                else if (recipientType.ToLower() == nonWinningRecipientType.ToLower())      /* Option - Non Winning Bidders */
                {
                    List<int> nonWinningBidderIdsByBids = new List<int>();
                    foreach (Bid winningbid in winningBids)
                    {
                        var bidderids = bids.Where(x => x.PackageXid == winningbid.PackageXid && x.BidderXid != winningbid.BidderXid).Select(x => x.BidderXid).ToList();
                        nonWinningBidderIdsByBids.AddRange(bidderids);
                    }
                    var winningBidderIds = winningBids.Select(x => x.BidderXid).ToList();
                    nonWinningBidderIdsByBids = nonWinningBidderIdsByBids.Where(x => !winningBidderIds.Contains(x)).Distinct().ToList();
                    var output = SendRegistrationSMSForBidders(project, nonWinningBidderIdsByBids, textMessageFieldValues, bidders);
                }

                result.Message = resultStatusType.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
            }
            catch (Exception exception)
            {
                Logger.WriteErrorLog(string.Format("Method: SendRegistrationSMSForAdmin, Prefix: {0}, Error: {1}", prefix, exception.Message.ToString()));
                result.Message = resultStatusType.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Failure).DisplayText;
            }

            return result;
        }

        public async Task SendRegistrationSMSForBidders(ProjectOutput project, List<int> bidderIds, TextMessageFieldValues textMessageFieldValues, List<Bidder> bidders)
        {
            await Task.Run(() =>
            {
                var registrationOpenType = _biddingData.GetCodeLookupByTypeDescription(CodeLookupConstants.CodeType_SMSPurposeType, CodeLookupConstants.CodeSMSPurposeType_RegistrationOpen);

                int messageMaxLength = (!string.IsNullOrEmpty(ConfigManager.SMSBodyMaxLength)) ? Convert.ToInt32(ConfigManager.SMSBodyMaxLength) : 0;  /* message length - limiting to 160 characters */

                foreach (int bidderId in bidderIds)
                {
                    var bidderDetail = bidders.FirstOrDefault(x => x.BidderXid == bidderId);

                    /* bidder and their Mobile Phone should not be empty*/
                    if (bidderDetail != null && !string.IsNullOrWhiteSpace(bidderDetail.MobilePhones))
                    {
                        var toPhoneNumbers = bidderDetail.MobilePhones.Split(new string[] { AppConstants.CommaDelimiter }, StringSplitOptions.RemoveEmptyEntries);
                        var biddingUrl = string.Format(ConfigManager.BiddingURL, bidderDetail.OnlineBidderKey);
                        var bidderNumber = (bidderDetail.Number == null || bidderDetail.Number == 0) ? string.Empty : bidderDetail.Number.ToString();
                        var message = textMessageFieldValues.Message.Replace("[n]", bidderDetail.SupporterName.Trim())
                                            .Replace("[b]", bidderNumber)
                                                .Replace("[u]", biddingUrl);

                        message = (messageMaxLength > 0 && message.Length > messageMaxLength) ? message.Substring(0, messageMaxLength - 1) : message;    /* message length - limiting to 160 characters */

                        foreach (string toPhoneNumber in toPhoneNumbers)
                        {
                            /* Assign model for text message */
                            TextMessageFieldValues sendTextMessageFieldValues = new TextMessageFieldValues();
                            sendTextMessageFieldValues.ProjectXid = project.ProjectXid;
                            sendTextMessageFieldValues.Phone = toPhoneNumber;
                            sendTextMessageFieldValues.Message = message;

                            /* Send SMS Notification for Registration */
                            SendSMS(sendTextMessageFieldValues, bidderId, registrationOpenType.CodeValue);
                        }
                    }
                }
            }).ConfigureAwait(false);
        }

        public ResultMessage RemoveAllBidsForAdmin(string prefix)
        {
           ResultMessage result = new ResultMessage();

            /* Gets the Result Status Type */
            var displayLookups = _biddingData.GetDisplayLookupListByType(DisplayLookupConstants.DisplayType_ResultStatusType);

            var resultModel = _biddingData.RemoveAllBidsForAdmin(prefix);                 /* Remove all bids */

            if (resultModel != null)                                                      /* check for resultmodel is not null */
            {
                result = resultModel.Item1;                                               /* assign Result Message to result model */
                var packages = resultModel.Item2;                                         /* assign packages to update signalr */
                if (result != null && packages.Count > 0)
                {
                    var successResultMessage = displayLookups.FirstOrDefault(x => x.DisplayCode == DisplayLookupConstants.DisplayResultStatusType_Success).DisplayText;
                    if (result.Message.ToLower().Equals(successResultMessage.ToLower()))   /* check for success message */
                    {
                        foreach (var package in resultModel.Item2)
                        {
                            /* SignalR update for bidding application */
                            SignalRHub.GetUpdatedPackages(package.PackageXid);
                            GetUpdatedBiddingHistory(prefix, package.PackageXid);
                        }
                        SignalRHub.GetUpdatedAppealDonationPackages(prefix);                /*SIGNALR update for appeal donation packages */
                    }
                }
            }
            UpdateEventStatisticsReportByPrefix(prefix);
            return result;
        }

        public List<ExportBidHistoryOutput> ExportAllBiddingHistoryForAdmin(string prefix)
        {
            return _biddingData.ExportAllBiddingHistoryForAdmin(prefix);
        }        

        public async Task<EmbedConfig> EmbedReportForAdmin(string username = null, string roles = null)
        {
            var result = new EmbedConfig();
            try
            {
                result = new EmbedConfig { Username = username, Roles = roles };
                var error = GetWebConfigErrors();
                if (error != null)
                {
                    result.ErrorMessage = error;
                    return result;
                }

                var name = CryptoHelper.Decrypt(Username, ConfigManager.AESPassword, ConfigManager.AESSalt);
                var password = CryptoHelper.Decrypt(Password, ConfigManager.AESPassword, ConfigManager.AESSalt);

                // Create a user password cradentials.
                var credential = new UserPasswordCredential(name, password);

                // Authenticate using created credentials
                var authenticationContext = new AuthenticationContext(AuthorityUrl);
                var authenticationResult = await authenticationContext.AcquireTokenAsync(ResourceUrl, ClientId, credential).ConfigureAwait(false);

                if (authenticationResult == null)
                {
                    result.ErrorMessage = "Authentication Failed.";
                    return result;
                }

                var tokenCredentials = new TokenCredentials(authenticationResult.AccessToken, "Bearer");

                // Create a Power BI Client object. It will be used to call Power BI APIs.
                using (var client = new PowerBIClient(new Uri(ApiUrl), tokenCredentials))
                {
                    // Get a list of reports.
                    var reports = await client.Reports.GetReportsInGroupAsync(GroupId);


                    Report report;
                    if (string.IsNullOrEmpty(ReportId))
                    {
                        // Get the first report in the group.
                        report = reports.Value.FirstOrDefault();
                    }
                    else
                    {
                        report = reports.Value.FirstOrDefault(r => r.Id == ReportId);
                    }

                    if (report == null)
                    {
                        result.ErrorMessage = "Group has no reports.";
                        return result;
                    }

                    var datasets = await client.Datasets.GetDatasetByIdInGroupAsync(GroupId, report.DatasetId);
                    result.IsEffectiveIdentityRequired = datasets.IsEffectiveIdentityRequired;
                    result.IsEffectiveIdentityRolesRequired = datasets.IsEffectiveIdentityRolesRequired;
                    GenerateTokenRequest generateTokenRequestParameters;

                    // This is how you create embed token with effective identities
                    if (!string.IsNullOrEmpty(username))
                    {
                        var rls = new EffectiveIdentity(username, new List<string> { report.DatasetId });
                        if (!string.IsNullOrWhiteSpace(roles))
                        {
                            var rolesList = new List<string>();
                            rolesList.AddRange(roles.Split(','));
                            rls.Roles = rolesList;
                        }
                        // Generate Embed Token with effective identities.
                        generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view", identities: new List<EffectiveIdentity> { rls });
                    }
                    else
                    {
                        // Generate Embed Token for reports without effective identities.
                        generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view");
                    }

                    var tokenResponse = await client.Reports.GenerateTokenInGroupAsync(GroupId, report.Id, generateTokenRequestParameters);

                    if (tokenResponse == null)
                    {
                        result.ErrorMessage = "Failed to generate embed token.";
                        return result;
                    }

                    // Generate Embed Configuration.
                    result.EmbedToken = tokenResponse;
                    result.EmbedUrl = report.EmbedUrl;
                    result.Id = report.Id;

                    return result;
                }
            }
            catch (HttpOperationException exc)
            {
                result.ErrorMessage = string.Format("Status: {0} ({1})\r\nResponse: {2}\r\nRequestId: {3}", exc.Response.StatusCode, (int)exc.Response.StatusCode, exc.Response.Content, exc.Response.Headers["RequestId"].FirstOrDefault());
            }
            catch (Exception exc)
            {
                result.ErrorMessage = exc.ToString();
            }

            return result;
        }

        /// <summary>
        /// Check if web.config embed parameters have valid values.
        /// </summary>
        /// <returns>Null if web.config parameters are valid, otherwise returns specific error string.</returns>
        private string GetWebConfigErrors()
        {
            // Client Id must have a value.
            if (string.IsNullOrEmpty(ClientId))
            {
                return "ClientId is empty. please register your application as Native app in https://dev.powerbi.com/apps and fill client Id in web.config.";
            }

            // Client Id must be a Guid object.
            Guid result;
            if (!Guid.TryParse(ClientId, out result))
            {
                return "ClientId must be a Guid object. please register your application as Native app in https://dev.powerbi.com/apps and fill client Id in web.config.";
            }

            // Group Id must have a value.
            if (string.IsNullOrEmpty(GroupId))
            {
                return "GroupId is empty. Please select a group you own and fill its Id in web.config";
            }

            // Group Id must be a Guid object.
            if (!Guid.TryParse(GroupId, out result))
            {
                return "GroupId must be a Guid object. Please select a group you own and fill its Id in web.config";
            }

            // Username must have a value.
            if (string.IsNullOrEmpty(Username))
            {
                return "Username is empty. Please fill Power BI username in web.config";
            }

            // Password must have a value.
            if (string.IsNullOrEmpty(Password))
            {
                return "Password is empty. Please fill password of Power BI username in web.config";
            }

            return null;
        }
        
        public EmbedReportOutput EmbedReportLastUpdatedDateTimeByProject(string prefix)
        {
            return _biddingData.EmbedReportLastUpdatedDateTimeByProject(prefix);
        }
        #endregion Admin
    }
}
