﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GreaterGiving.Tokyo.Entities.Entities;
using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Entities.Output;
using GreaterGiving.Tokyo.SendSaleData.Model;
using Newtonsoft.Json.Linq;

namespace GreaterGiving.Tokyo.Bidding.Domain.Contracts
{
    public interface IBiddingDomain
    {
        bool ValidateProject(int projectXid);

        ProjectOutput GetProject(string prefix);

        ProjectOutput GetProjectByProjectKey(string projectKey);

        ResultModel IsShortNameAvailable(string shortName);

        string Encrypt(string inputText);

        string Decrypt(string inputText);

        ResultModel CreateProject(ProjectFieldValues project);

        ResultModel SendSMS(TextMessageFieldValues message, int? bidderId = null, int? purposeType = null);

        int InsertSMSRequest(TextMessageFieldValues message, int purpose);

        bool InsertSMSDeliveryStatus(int smsRequestId, string toPhoneNumber, string statusIndicator, DateTime sendTime, DateTime deliveryTime, string sId, int? bidderId);

        ResultModel SendEmail(EmailMessageFieldValues emailMessage, int projectId, int? bidderId = null, int? purposeType = null);

        int InsertEmailRequest(EmailMessageFieldValues emailMessage, int projectId, int purpose);

        bool InsertEmailDeliveryStatus(EmailDeliveryStatusInput emailDeliveryStatusInput);

        void InsertUnsubscribePhoneNo(string phoneNo);

        void DeleteUnsubscribePhoneNo(string phoneNo);

        List<PackageOutput> GetAllPackages(string prefix);

        List<PackageOutput> GetPackages(string prefix, int pageno, int size, string packageFilterType);

        List<SponsorOutput> GetSponsorImagesByPrefix(string prefix);

        List<BidderOutput> GetBidderHistoryOrCurrentBuyers(string prefix, int packageid);

        BidderOutput GetBidderByBidderKey(string bidderKey);        

        PackageOutput GetPackagebyPackageId(string prefix, int packageXid);

        List<PackageOutput> GetRelatedPackages(string prefix, int packageXid, string displayedPackages);

        ResultModel ProcessMobileBiddingData(JObject jobject);

        ResultModel UpdateTimeAndItemTypeForPackages(BulkPackageFieldValues package);

        List<string> GetPackageTypesByProject(string prefix);

        List<string> GetCategoryTypesByProject(string prefix);

        List<PackageOutput> SearchPackagesByPackageNameOrNumber(string prefix, int pageno, int size, string packageNameOrNumber);

        List<PackageOutput> GetFilteredPackagesByProject(string prefix, string packageFilter);

        List<PackageOutput> GetPackagesByCategory(string prefix, int pageno, int size, string categoryName);

        List<PackageOutput> GetFavoritePackagesByBidder(string prefix, int pageno, int size);

        List<PackageOutput> GetBidActivityByBidder(string prefix, string activityType, int pageno, int size);

        PackageOutput GetAppealDonationPackage(string prefix);

        void AddOrRemoveFavorite(string prefix, int packageId, bool isFavorite);

        ResultMessage AddBid(string prefix, int packageId, decimal amount);

        ResultMessage BuyRegularPackage(string prefix, int packageId);

        ResultMessage BidMore(string prefix, int packageId, decimal amount);

        ResultMessage SetMaxBid(string prefix, int packageId, decimal amount);

        ResultMessage BuyMultiSalePackages(string prefix, int packageId, int quantity);

        ResultMessage BuyDonationPackage(string prefix, int packageId, decimal amount);

        ResultMessage BuyAppealDonationPackage(string prefix, decimal donationAmount);

        Bidder GetCurrentBidderDetails();

        bool SendSaleData(int saleID, SaleData saleData);

        CodeLookup GetCodeLookupByType_Description(string type, string description);

        CountdownBoardOutput GetFurthestPackageClosingTimeByProject(string prefix);

        List<PackageOutput> GetLeaderBoardPackages(string prefix, JObject jobject);

        void UpdateSMSStatus(string response, int requestId);

        #region Admin

        List<BidderOutput> GetTopBiddersForAdmin(string prefix, int count);

        List<BidderSearchOutput> GetAllBiddersForAdmin(string prefix, BidderSearchInput bidderSearchInput);

        List<PackageOutput> GetTopPackagesForAdmin(string prefix, int count);

        List<PackageSearchOutput> GetAllPackagesForAdmin(string prefix, PackageSearchInput input);

        BidderSearchOutput GetBidderDetailsForAdmin(string prefix, int bidderId);

        List<MaxBidOutput> GetBidderMaxBidForAdmin(string prefix, int bidderId);

        List<BidHistoryOutput> GetBidderBidHistoryForAdmin(string prefix, int bidderId);

        MaxBidOutput GetPackageMaxBidForAdmin(string prefix, int packageId);

        PackageSearchOutput GetPackageDetailsForAdmin(string prefix, int packageId);

        List<BidHistoryOutput> GetPackageBidHistoryForAdmin(string prefix, int packageId);

        ResultMessage ClearMaxBidForAdmin(string prefix, int packageId);

        ResultMessage RemoveBidForAdmin(string prefix, int bidId, int saleId);


        ResultMessage SaveEmailTemplateForAdmin(string prefix, EmailMessageFieldValues emailMessage);

        List<EmailTemplateOutput> GetEmailTemplatesForAdmin(string prefix);

        ResultMessage DeleteEmailTemplateForAdmin(int projectId, int emailTemplateId);

        ResultMessage SendPreviewEmailForAdmin(string prefix, EmailMessageFieldValues emailMessage);

        ResultMessage SendRegistrationEmailForAdmin(string prefix, string recipientType, EmailMessageFieldValues emailMessage);

        List<SMSTemplateOutput> GetSMSTemplatesForAdmin(string prefix);

        ResultMessage SaveSMSTemplateForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues);

        ResultMessage DeleteSMSTemplateForAdmin(int projectId, int smsTemplateId);

        ResultMessage SendPreviewSMSForAdmin(string prefix, TextMessageFieldValues textMessageFieldValues);

        ResultMessage SendRegistrationSMSForAdmin(string prefix, string recipientType, TextMessageFieldValues textMessageFieldValues);

        ResultMessage RemoveAllBidsForAdmin(string prefix);

        List<ExportBidHistoryOutput> ExportAllBiddingHistoryForAdmin(string prefix);

        Task<EmbedConfig> EmbedReportForAdmin(string username = null, string roles = null);

        EmbedReportOutput EmbedReportLastUpdatedDateTimeByProject(string prefix);
        #endregion Admin
    }
}
