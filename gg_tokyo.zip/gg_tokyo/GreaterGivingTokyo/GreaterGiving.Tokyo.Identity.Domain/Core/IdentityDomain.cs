﻿using GreaterGiving.Tokyo.CrossCutting.Identity;
using GreaterGiving.Tokyo.CrossCutting.Logging;
using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Foundation.Contracts;
using GreaterGiving.Tokyo.Identity.DataAccess.Contracts;
using GreaterGiving.Tokyo.Identity.Domain.Contracts;
using GreaterGiving.Tokyo.Identity.Domain.Factory;
using System.ComponentModel.Composition;
using System.Threading;

namespace GreaterGiving.Tokyo.Identity.Domain.Core
{
    [Export(typeof(IIdentityDomain)), LogAspect, PartCreationPolicy(CreationPolicy.NonShared)]
    public sealed class IdentityDomain : IIdentityDomain
    {
        #region Private Fields & Constants

        private IIdentityData _identityData;
        private IAuthenticationProviderFactory _authenticationProviderFactory;
        private ITokenHandler _tokenHandler;
        private IClaimsManager _claimsManager;

        #endregion Private Fields & Constants

        #region Constructors

        [ImportingConstructor]
        public IdentityDomain(IIdentityData identityData, IAuthenticationProviderFactory authenticationProviderFactory,
                                IClaimsManager claimsManager, ITokenHandler tokenHandler)
        {
            _identityData = identityData;
            _authenticationProviderFactory = authenticationProviderFactory;
            _tokenHandler = tokenHandler;
            _claimsManager = claimsManager;
        }

        #endregion Constructors

        #region IIdentityDomain Members

        /// <summary>
        /// Authenticates the bidder with the onlineBidderKey
        /// </summary>
        /// <param name="onlineBidderKey">onlineBidderKey</param>
        /// <returns>BidderInfo</returns>
        public BidderInfo Authenticate(string onlineBidderKey)
        {
            BidderInfo bidder = null;

            var provider = _authenticationProviderFactory.GetAuthenticationProvider();

            bidder = provider.Authenticate(onlineBidderKey);

            if (bidder != null)
            {
                bidder = CreateToken(bidder);
            }

            return bidder;
        }


        /// <summary>
        /// Authenticates the app with the key
        /// </summary>
        /// <param name="key">key</param>
        /// <returns>string</returns>
        public string AuthenticateApp(string key)
        {
            var provider = _authenticationProviderFactory.GetAuthenticationProvider();
            string token = null;
            if (!string.IsNullOrEmpty(provider.AuthenticateApp(key)))
            {
                token = CreateAppToken(key);
            }

            return token;
        }

        /// <summary>
        /// Authenticates the admin login with prefix
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="password">password</param>
        /// <returns>ProjectInfo</returns>
        public ProjectInfo AuthenticateAdmin(string userName, string password)
        {
            ProjectInfo projectInfo = null;

            var provider = _authenticationProviderFactory.GetAuthenticationProvider();
            if (provider.AuthenticateAdmin(userName, password))
            {
                projectInfo = new ProjectInfo();
                projectInfo.Prefix = userName;
                projectInfo = CreateAdminToken(projectInfo);
            }

            return projectInfo;
        }

        /// <summary>
        /// Create Token creates new token for bidder
        /// </summary>
        /// <param name="bidder">bidder</param>
        /// <returns>BidderInfo</returns>
        private BidderInfo CreateToken(BidderInfo bidder)
        {
            var identity = _claimsManager.GetIdentity(bidder);

            var bidderTokenInfo = _tokenHandler.CreateToken(identity);

            if (!string.IsNullOrEmpty(bidderTokenInfo.Token))
            {
                bidder.BidderToken = bidderTokenInfo.Token;
                bidder.ValidTo = bidderTokenInfo.ValidTo;
            }

            return bidder;
        }

        /// <summary>
        /// Create App Token creates new token for App
        /// </summary>
        /// <param name="key">key</param>
        /// <returns>string</returns>
        private string CreateAppToken(string key)
        {
            var identity = _claimsManager.GetAppIdentity(key);

            var tokenInfo = _tokenHandler.CreateToken(identity);

            return tokenInfo.Token;
        }

        /// <summary>
        /// Create Admin Token creates new token for Admin Login
        /// </summary>
        /// <param name="key">key</param>
        /// <returns>ProjectInfo</returns>
        private ProjectInfo CreateAdminToken(ProjectInfo projectInfo)
        {
            var identity = _claimsManager.GetAdminIdentity(projectInfo.Prefix);

            var adminTokenInfo = _tokenHandler.CreateToken(identity);

            if (!string.IsNullOrEmpty(adminTokenInfo.Token))
            {
                projectInfo.AdminToken = adminTokenInfo.Token;
                projectInfo.ValidTo = adminTokenInfo.ValidTo;
            }

            return projectInfo;
        }

        #endregion IIdentityDomain Members
    }
}
