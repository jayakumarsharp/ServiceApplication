﻿using GreaterGiving.Tokyo.Entities.Models;

namespace GreaterGiving.Tokyo.Identity.Domain.Contracts
{
    public interface IIdentityDomain
    {
        #region IIdentityDomain Members

        /// <summary>
        /// Authenticates the incoming onlineBidderKey
        /// </summary>
        /// <param name="onlineBidderKey">onlineBidderKey</param>
        /// <returns>BidderInfo</returns>
        BidderInfo Authenticate(string onlineBidderKey);

        /// <summary>
        /// Authenticates the incoming key
        /// </summary>
        /// <param name="key">key</param>
        /// <returns>string</returns>
        string AuthenticateApp(string key);

        /// <summary>
        /// Authenticates admin login with the incoming username and password
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="password">password</param>
        /// <returns>ProjectInfo</returns>
        ProjectInfo AuthenticateAdmin(string userName, string password);
        
        #endregion IIdentityDomain Members
    }
}
