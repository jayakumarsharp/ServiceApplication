﻿using System.ComponentModel.Composition;
using GreaterGiving.Tokyo.Identity.DataAccess.Contracts;
using GreaterGiving.Tokyo.Identity.Domain.Providers;

namespace GreaterGiving.Tokyo.Identity.Domain.Factory
{
    [Export(typeof(IAuthenticationProviderFactory)), PartCreationPolicy(CreationPolicy.NonShared)]
    internal sealed class AuthenticationProviderFactory : IAuthenticationProviderFactory
    {
        private IIdentityData _identityData;

        [ImportingConstructor]
        public AuthenticationProviderFactory(IIdentityData identityData)
        {
            _identityData = identityData;
        }

        IAuthenticationProvider IAuthenticationProviderFactory.GetAuthenticationProvider()
        {
            return (new FormsAuthenticationProvider(_identityData) as IAuthenticationProvider);
        }
    }
}
