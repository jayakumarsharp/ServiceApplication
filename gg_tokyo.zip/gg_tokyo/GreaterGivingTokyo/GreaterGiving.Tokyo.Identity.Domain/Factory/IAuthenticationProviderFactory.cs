﻿using GreaterGiving.Tokyo.Identity.Domain.Providers;

namespace GreaterGiving.Tokyo.Identity.Domain.Factory
{
    public interface IAuthenticationProviderFactory
    {
        IAuthenticationProvider GetAuthenticationProvider();
    }
}
