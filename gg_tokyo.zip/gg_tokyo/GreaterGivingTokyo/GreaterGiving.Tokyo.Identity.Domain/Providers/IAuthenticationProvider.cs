﻿using GreaterGiving.Tokyo.Entities.Input;
using GreaterGiving.Tokyo.Entities.Models;

namespace GreaterGiving.Tokyo.Identity.Domain.Providers
{
    public interface IAuthenticationProvider
    {
        BidderInfo Authenticate(string onlineBidderKey);

        string AuthenticateApp(string key);

        bool AuthenticateAdmin(string userName, string password);
    }
}
