﻿using GreaterGiving.Tokyo.CrossCutting.Configuration;
using GreaterGiving.Tokyo.Entities.Models;
using GreaterGiving.Tokyo.Identity.DataAccess.Contracts;

namespace GreaterGiving.Tokyo.Identity.Domain.Providers
{

    internal sealed class FormsAuthenticationProvider : IAuthenticationProvider
    {
        private IIdentityData _identityData;

        public FormsAuthenticationProvider(IIdentityData identityData)
        {
            _identityData = identityData;
        }

        BidderInfo IAuthenticationProvider.Authenticate(string onlineBidderKey)
        {
            var bidderDetails = _identityData.Authenticate(onlineBidderKey);

            return bidderDetails;
        }

        string IAuthenticationProvider.AuthenticateApp(string key)
        {
            if (ConfigManager.AppTokenKey == key)
                return key;
            else
                return null;
        }

        bool IAuthenticationProvider.AuthenticateAdmin(string userName, string password)
        {
            var isAuthenticateAdmin = _identityData.AuthenticateAdmin(userName, password);

            return isAuthenticateAdmin;
        }
    }
}
