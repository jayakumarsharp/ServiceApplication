var path = require('path');
var _root = path.resolve(__dirname, '..');

function root(args) {
    args = Array.prototype.slice.call(arguments, 0);
    return path.join.apply(path, [_root].concat(args));
}

function getAppBaseURL(env) {
    env = env.toString();
    let API_URL;
    if (env === 'dev') {
        API_URL = 'https://bidding.dev.ggo.bid'
    }
    if (env === 'next') {
        API_URL = 'https://bidding.next.ggo.bid'
    }
    if (env === 'preview') {
        API_URL = 'https://bidding.preview.ggo.bid'
    }
    if (env === 'future') {
        API_URL = 'https://bidding.future.ggo.bid'
    }
    if (env === 'release') {
        API_URL = 'https://bidding.release.ggo.bid'
    }
    if (env === 'stage') {
        API_URL = 'https://bidding.stage.ggo.bid'
    }
    if (env === 'prod') {
        API_URL = 'https://bidding.ggo.bid'
    }
    if (env === 'local') {
        API_URL = 'http://192.168.8.93/BiddingTokyoApi'
    }
    if (!API_URL) {
        API_URL = 'https://bidding.dev.ggo.bid'
    }
    return API_URL;
}

function getAuthURL(env) {
    env = env.toString();
    let API_URL;
    if (env === 'dev') {
        API_URL = 'https://identity.dev.ggo.bid'
    }
    if (env === 'next') {
        API_URL = 'https://identity.next.ggo.bid'
    }
    if (env === 'preview') {
        API_URL = 'https://identity.preview.ggo.bid'
    }
    if (env === 'future') {
        API_URL = 'https://identity.future.ggo.bid'
    }
    if (env === 'release') {
        API_URL = 'https://identity.release.ggo.bid'
    }
    if (env === 'stage') {
        API_URL = 'https://identity.stage.ggo.bid'
    }
    if (env === 'prod') {
        API_URL = 'https://identity.ggo.bid'
    }
    if (env === 'local') {
        API_URL = 'http://192.168.8.93/BiddingTokyoIdentityApi'
    }
    if (!API_URL) {
        API_URL = 'https://identity.dev.ggo.bid'
    }
    return API_URL;
}


exports.root = root;
exports.getAppBaseURL = getAppBaseURL;
exports.getAuthURL = getAuthURL;
