var webpack = require('webpack');
var webpackMerge = require('webpack-merge');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var commonConfig = require('./webpack.common.js');
var helpers = require('./helpers');

const environment = process.argv[process.argv.length - 1];
module.exports = webpackMerge(commonConfig, {
  devtool: 'cheap-module-eval-source-map',

  output: {
    path: helpers.root('dist'),
    publicPath: '/',
    filename: '[name].js',
    chunkFilename: '[id].chunk.js'
  },

  plugins: [
    new ExtractTextPlugin('[name].css'),
    new webpack.DefinePlugin({
      'process.env': {
        'BIDDING_BASE_URL': JSON.stringify(helpers.getAppBaseURL(environment)),
        'AUTH_BASE_URL': JSON.stringify(helpers.getAuthURL(environment))
      }
    }),
  ],

  devServer: {
    historyApiFallback: true,
    stats: 'minimal'
  }
});
