export const appConfig = {
    BIDDING_BASE_URL: process.env.BIDDING_BASE_URL,
    AUTH_BASE_URL: process.env.AUTH_BASE_URL,

    VISITOR_URL: '/Bidding/API',
    BIDDER_URL: '/SecureBidding/API',
    AUTH_URL: '/Identity/API',
    ADMIN_URL: '/AdminBidding/API',

    PACKAGE_SIGNALR_URL: '/SignalR/Hubs',
    PACKAGE_SIGNALR_HUB : 'SRhub'
};
