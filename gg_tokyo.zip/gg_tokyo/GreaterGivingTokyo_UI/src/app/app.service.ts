import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';

import { Utils } from './bidding/common/utils';
import { appConstants } from './app.const';

declare var ga: Function;
@Injectable()
export class AppService {

    constructor(private utils: Utils) { }

    public trackingID;
    public showLoader: boolean = false;
    public isSessionStorageAccessible: boolean = false;

    public setBusy() {
        this.showLoader = true;
    };

    public resetBusy() {
        this.showLoader = false;
    };

    public convertTimeByTimeZone(dateObject, timezone) {
        return moment.tz(moment.utc(dateObject), timezone);
    };

    public isStorageSupported() {
        let testKey = 'test';
        let storage = window.sessionStorage;
        try {
            storage.setItem(testKey, '1');
            storage.removeItem(testKey);
            return true;
        } catch (error) {
            return false;
        }
    };

    public trackPages(url) {
        if (!this.trackingID) {
            this.trackingID = this.setGoogleAnalyticsTrackingID();
        }
        ga('create', this.trackingID, 'auto');
        ga('send', 'pageview', window.location.href);
    };

    public trackEvents(eventCategory, eventAction, eventLabel) {
        if (!this.trackingID) {
            this.trackingID = this.setGoogleAnalyticsTrackingID();
        }
        ga('create', this.trackingID, 'auto');
        ga('send', 'event', {
            eventCategory: eventLabel,
            // eventLabel: eventLabel,
            eventAction: eventCategory + '-' + eventAction,
            // eventValue: eventValue
        });
    };

    public getItemsInRotational(previouslyShownedItemsLastId, actualArray , noOfItems): Object[] {
        let arrayLength = actualArray.length;
        let spliceStartIndex = 0; // default splice start and end index
        spliceStartIndex = _.findIndex(actualArray, {'ID': previouslyShownedItemsLastId});
        spliceStartIndex ++;
        let spliceEndIndex = spliceStartIndex + noOfItems;
        let spliceEndIndexDiff = (arrayLength < spliceEndIndex) ? (spliceEndIndex - arrayLength) : 0;
        spliceEndIndexDiff --;
        //  = new Array();
        let items = actualArray.slice(spliceStartIndex, spliceEndIndex);
        if (spliceEndIndexDiff > -1) {
            for (let i = 0; i <= spliceEndIndexDiff; i ++) {
                items.push(actualArray[i]);
            }
        }
        return items;
    };

    private setGoogleAnalyticsTrackingID() {
        let url = window.location.href;
        if (this.utils.contains(url, 'dev.ggo.bid')) {
            return appConstants.GOOGLE_TRACKING_IDS.DEV;
        } else if (this.utils.contains(url, 'next.ggo.bid')) {
            return appConstants.GOOGLE_TRACKING_IDS.NEXT;
        } else if (this.utils.contains(url, 'preview.ggo.bid')) {
            return  appConstants.GOOGLE_TRACKING_IDS.PREVIEW;
        } else if (this.utils.contains(url, 'stage.ggo.bid')) {
            return  appConstants.GOOGLE_TRACKING_IDS.STAGE;
        } else if (this.utils.contains(url, 'prod.ggo.bid')) {
            return appConstants.GOOGLE_TRACKING_IDS.PROD;
        } else if (this.utils.contains(url, 'release.ggo.bid')) {
            return appConstants.GOOGLE_TRACKING_IDS.RELEASE;
        } else {
            return appConstants.GOOGLE_TRACKING_IDS.DEV;
        }
    };

    private findDeviceSize(): string {
        let height = screen.height;
        let width = screen.width;
        let size = width + 'X' + height;
        return size;
    };

    private findDeviceType(): string {
        let userAgent = navigator.userAgent;
        let deviceType;
        switch (true) {
            case (!!userAgent.match(/Windows Phone/i)):
                deviceType = 'Windows Phone';
                break;
            case (!!userAgent.match(/Android/i)):
                deviceType = 'Android';
                break;
            case (!!userAgent.match(/iPhone/i)):
                deviceType = 'iPhone';
                break;
            case (!!userAgent.match(/iPad/i)):
                deviceType = 'iPad';
                break;
            case (!!userAgent.match(/Opera Mini/i)):
                deviceType = 'Android';
                break;
            default:
                deviceType = 'Desktop';
                break;
        }
        return deviceType;
    };

    private findBrowserType(): string {
        let userAgent = navigator.userAgent;
        let browsers = {chrome: /chrome/i, safari: /safari/i, firefox: /firefox/i, ie: /internet explorer/i, edge: /Edge/i, opera: /opera/i};
        for (let key in browsers) {
            if (browsers[key].test(userAgent)) {
                return key;
            }
       };
       return 'unknown';
    };
}
