import { Component, Input, OnInit, OnChanges } from '@angular/core';
import { ToasterService } from 'angular2-toaster';
import * as _ from 'lodash';

import { biddingErrorConstants } from '../../bidding/bidding-app.error.const';
import { GgoAdminService } from '../ggo-admin.service';
import { AppService } from '../../app.service';

@Component({
    selector: 'sponsors',
    templateUrl: 'sponsors.component.html',
})
export class SponsorsComponent implements OnInit, OnChanges {

    constructor(private ggoAdminService: GgoAdminService,
        private toasterService: ToasterService,
        private appService: AppService) { }

    public sponsorsPerView = 3;
    public displayedSponsors = [];
    private sponorsDisplayIntervalInst;
    public startSponsorsTransistion = false;

    @Input() public sponsorsRefreshInterval;
    @Input() public sponsors;

    private displayedSponsorRefresh() {

        this.startDisplaySponsors();
        if (this.sponsors.length < 4) {
            return;
        }
        this.sponorsDisplayIntervalInst = setInterval(() => {
            this.startSponsorsTransistion = true;
            setTimeout(() => {
                this.startDisplaySponsors();
            }, 500);
        }, +this.sponsorsRefreshInterval * 1000);
    };

    private stopSponsorsUpdate() {
        clearInterval(this.sponorsDisplayIntervalInst);
    };

    private startDisplaySponsors() {
        if (this.displayedSponsors.length === 0) {
            this.displayedSponsors = this.sponsors.slice(0, this.sponsorsPerView);
            return;
        }

        let lastDisplayedSponsorId = this.displayedSponsors[this.displayedSponsors.length - 1].ID;
        this.displayedSponsors = this.appService.getItemsInRotational(lastDisplayedSponsorId, this.sponsors, this.sponsorsPerView);
        this.startSponsorsTransistion = false;
    };

    ngOnChanges() {
        if (this.displayedSponsors.length >3) {
            this.stopSponsorsUpdate();
            this.displayedSponsorRefresh();
        }
    };

    ngOnInit() {
        this.displayedSponsorRefresh(); 
    };
}
