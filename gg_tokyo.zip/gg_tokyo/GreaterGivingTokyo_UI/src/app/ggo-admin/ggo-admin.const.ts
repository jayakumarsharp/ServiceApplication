export const ggoAdminConstants = {

    APPEAL_BOARD_DONORS_ALERT_DURATION: 3 * 1000,
    SESSION_STORAGE_KEYS: {
        ADMIN_TOKEN: 'AdminToken',
        COUNTDOWN_BOARD_CONFIG: 'countDownConfig',
        PREFIX: 'prefix'
    },

    COUNT_DOWN_BOARD_QUERY_PARAMS: [
        'ShowSponsors',
        'Background',
        'Title',
        'Message'
    ],

    LEADER_BOARD_QUERY_PARAMS: [
        'PackageFilter',
        'PackageRefresh',
        'CategoryFilter',
        'PackageSort',
        'Background',
        'ShowSponsors',
        'UpdateSponsorsFrequency'
    ],

    BOARD_NAMES: {
        APPEAL_BOARD: 'AppealBoard',
        LEADER_BOARD: 'LeaderBoard',
        COUNTDOWN_BOARD: 'CountdownBoard'
    },

    LEADER_BOARD_PACKAGE_FILTER: {
        'openitems_closing': 'Open',
        'openitems_items': 'Open',
        'unbid_items': 'Open(No Bid)',
        'bidders': 'Open(No Bid)',
        'allitems_closing': 'All',
        'allitems_item': 'All'
    },

    ACTION_TYPES: {
        SEND: 'SendButton',
        PREVIEW: 'PreviewButton',
        CANCEL: 'CancelButton',
    },

    DATE_TIME_FORMATS: {
        DATE_WITH_YEAR: 'MM/DD/YY h:mm:ss A',
        DATE_WITH_YEAR_WITHOUT_SECONDS: 'MM/DD/YY hh:mmA',
        DATE_WITHOUT_YEAR: 'MM/DD h:mm A',
        MONTH_DAY: 'MM/DD',
        HOURS_MIN: 'h:mm A'
    },

    LEADER_BOARD_PACKAGE_SORT: {
        'allitems_item': 'Package Number',
        'openitems_items': 'Package Number',
        'unbid_items': 'Package Number',
        'allitems_closing': 'Closing Time',
        'openitems_closing': 'Closing Time',
        'bidders': 'Closing Time'
    },

    THEME_WITH_CLASSES: {
        'blue': 'ab-bule-theme',
        'brown': 'ab-brown-theme',
        'green': 'ab-green-theme',
        'gray': 'ab-grey-theme',
        'purple': 'ab-purple-theme',
        'red': 'ab-red-theme',
    },

    GAUGES_COLOR_FOR_THEME: {
        'blue': '#002D53',
        'brown': '#564006',
        'green': '#234403',
        'gray': '#32373E',
        'purple': '#49156B',
        'red': '#840812',
    },

    PROGRESS_COLOR: [
        'Blue',
        'Brown',
        'Green',
        'Gray',
        'Purple',
        'Red'
    ],

    GAUGES_WITH_DISPLAYNAME: {
        BAR: 'Bar',
        THERMOMETER: 'Thermometer',
        HIGH_STRIKE: 'High Strike',
        TRIANGLE_UP: 'Triangle (Pointing Up)',
        TRIANGLE_DOWN: 'Triangle (Pointing Down)',
        HOUSE: 'Schoolhouse'
    },

    REMOVE_ACTION_TYPE: {
        MAX_BID: 'Clear Max Bid',
        BID: 'Remove Bid',
        ALL_BID: 'Remove All Bids'
    },

    BACKGROUND_COLOR: [
        'Blue',
        'Brown',
        'Green',
        'Gray',
        'Purple',
        'Red'
    ]
};
