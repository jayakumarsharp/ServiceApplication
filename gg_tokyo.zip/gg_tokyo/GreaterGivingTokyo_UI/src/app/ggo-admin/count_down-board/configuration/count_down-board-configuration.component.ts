import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { DialogRef } from 'angular2-modal';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { FormsModule, NgForm }   from '@angular/forms';
import * as _   from 'lodash';

import { Config } from './../config';
import { CountdownBoardService } from '../count_down-board.service';
import { GgoAdminService } from '../../ggo-admin.service';
import { ggoAdminConstants } from '../../ggo-admin.const';


@Component({
    templateUrl: 'count_down-board-configuration.component.html',
})

export class CountDownBoardConfigurationComponent implements OnInit {

    public ggoAdminConstants = ggoAdminConstants;
    public config = new Config();
    public sponsorsRefreshInterval: any;
    public sponsorRefreshRates = [];
    public customTimeHours = [];
    public customTimeMinAndSecs = [];

    @ViewChild('form')
    public configForm: NgForm;

    constructor(private dialog: DialogRef<any>,
                private countdownBoardService: CountdownBoardService,
                private ggoAdminService: GgoAdminService) { }

    public onCancel() {
        this.dialog.close();
    };

    public onSubmit() {
        if (this.configForm.value.showsponsors) {
            let sponsorsRefreshInterval: string = this.configForm.value.sponsorsRefreshInterval;
            this.configForm.value.sponsorsRefreshInterval = sponsorsRefreshInterval.slice(0, sponsorsRefreshInterval.indexOf('S') - 1);
        }
        this.countdownBoardService.setUpdatedConfigs(this.configForm.value);
        this.dialog.close();
    };

    public onReset() {
        let config = new Config();
        config = this.countdownBoardService.getDefaultConfig();
        this.configForm.form.patchValue(config);
        setTimeout(() => {
            this.sponsorsRefreshInterval = config.sponsorsRefreshInterval + ' Second'; // for initial default drop down selection
        });
    };

    public onDefault() {
        let config = new Config();
        config = this.countdownBoardService.getDefaultSetting();
        this.configForm.form.patchValue(config);
        setTimeout(() => {
            this.sponsorsRefreshInterval = config.sponsorsRefreshInterval + ' Second'; 
        });
    };

    private setDropDownValues() {
        this.sponsorRefreshRates = this.ggoAdminService.generateValues(1, 99);
        this.customTimeHours =  this.ggoAdminService.generateValues(0, 99);
        this.customTimeMinAndSecs =  this.ggoAdminService.generateValues(0, 60);
    };

    public setDefaultValues() {
        this.config.background = _.capitalize(this.config.background);
        let sponsorsRefreshInterval = '';
        if (this.config.showsponsors) {
            sponsorsRefreshInterval = this.config.sponsorsRefreshInterval.toString() + ' Second'; // for initial default drop down selection
        } else {
            sponsorsRefreshInterval = '10 Second';
        }
        this.sponsorsRefreshInterval = sponsorsRefreshInterval;
        if (!this.config.useCutomTime) {
            this.resetCustomTime();
        }
    };

    public onCheck(e) {
        var isChecked =  e.target.checked;
        if (!isChecked) {
           this.resetCustomTime();
        }
    }
    public resetCustomTime() {
        this.config.customTimeHours = 0;
        this.config.customTimeMin = 0;
        this.config.customTimeSec = 0;
    }

    ngOnInit() {
        this.config = this.countdownBoardService.config;
        this.setDefaultValues();
        this.setDropDownValues();
    };
}
