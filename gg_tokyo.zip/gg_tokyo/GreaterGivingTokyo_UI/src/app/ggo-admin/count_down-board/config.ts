export class Config {

    public showsponsors: boolean;
    public background: string;
    public title: string;
    public message: string;
    public sponsorsRefreshInterval: number;
    public useCutomTime: boolean;
    public customTimeHours: number;
    public customTimeMin: number;
    public customTimeSec: number;
    public customDateTime;

    constructor() {
        this.showsponsors = true,
        this.sponsorsRefreshInterval = 10,
        this.background = '',
        this.title = 'Time Remaining',
        this.message = 'Check out the live update below to watch as we count down to the end of the event!',
        this.useCutomTime = false,
        this.customTimeHours = 0,
        this.customTimeMin = 0,
        this.customTimeSec = 0;
    }
};
