import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { SignalR } from 'ng2-signalr';
import { ToasterService } from 'angular2-toaster';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';

import { biddingAppConstants } from '../../bidding/bidding-app.const';
import { AppService } from '../../app.service';
import { ggoAdminConstants } from '../ggo-admin.const';
import { biddingErrorConstants } from '../../bidding/bidding-app.error.const';
import { CountdownBoardService } from './count_down-board.service';
import { CountDownBoardConfigurationComponent } from './configuration/count_down-board-configuration.component';
import { ErrorHandlerService } from '../../bidding/error-handler/error-handler.service';
import { Config } from './config';

@Component({
    selector: 'count-down-board',
    templateUrl: './count_down-board.component.html',
})


export class CountdownBoardComponent implements OnInit {

    constructor(private activatedRoute: ActivatedRoute,
        private appService: AppService,
        private router: Router,
        private toasterService: ToasterService,
        private modal: Modal,
        private signalR: SignalR,
        private errorHandlerService: ErrorHandlerService,
        private overlay: Overlay,
        private countDownBoardService: CountdownBoardService,
        private vcRef: ViewContainerRef) {
        overlay.defaultViewContainer = vcRef;
    }

    public config = new Config();
    public furthestClosingPackage = {
        packageid: 0,
        countdowntime: ''
    };
    public countDownTime: string = '';
    public sponsors = [];
    public projectInfo = this.countDownBoardService.projectInfo;

    private countDownTimerInst;
    private sponorsDisplayIntervalInst;
    public startSponsorsTransistion = false;

    public onSelectConfigMenu() {
        this.countDownBoardService.config = this.config;
        return this.modal.open(CountDownBoardConfigurationComponent, overlayConfigFactory({ dialogClass: 'modal-configuration' }, BSModalContext));
    };

    private routeToErrorPage() {
        this.errorHandlerService.errorMessage = biddingErrorConstants.PROJECT_ID_NOT_FOUND;
        this.router.navigateByUrl('bidding/error');
    };

    private connectSignalR() {
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatePackages').subscribe((updatedPackageId) => {
                this.countDownBoardService.getFathestClosingTimeOfPackage(this.countDownBoardService.projectInfo.slug).subscribe(
                    res => {
                        this.furthestClosingPackage = res.plain();
                        if (this.countDownTime = '00:00') {
                            this.startCountDownTimer();
                        }
                    }
                );
            });
        });
    };

    public listenEvents() {
        this.countDownBoardService.isConfigurationUpdated.subscribe(
            updatedConfig => {
                this.config = updatedConfig;
                this.setCustomDateTime();
            }
        );
    };

    private setCustomDateTime() {
        let customDateTime = moment().add(this.config.customTimeHours, 'hours');
        customDateTime = customDateTime.add(this.config.customTimeMin, 'minutes');
        customDateTime = customDateTime.add(this.config.customTimeSec, 'seconds');
        this.config.customDateTime = customDateTime;
    };

    private getSponsors() {
        this.countDownBoardService.getSponsors(this.countDownBoardService.projectInfo.slug).subscribe(
            res => {
                this.sponsors = _.filter(res.plain(), function (sponsor: any) { return sponsor.imgpath !== null; });
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    private countDownTimeByFurthestClosingTime() {
        if (!this.furthestClosingPackage.countdowntime) {
            return;
        }
        let currentUTCDateTime = this.appService.convertTimeByTimeZone(new Date(), this.countDownBoardService.projectInfo.timezone);
        let closingTime = this.appService.convertTimeByTimeZone(this.furthestClosingPackage.countdowntime, this.countDownBoardService.projectInfo.timezone);
        let dateDiff = closingTime.diff(currentUTCDateTime);
        this.setCountDownTime(dateDiff);
    };

    private setCountDownTime(dateDiffInMs) {
        if (dateDiffInMs < 0) {
            this.countDownTime = biddingAppConstants.DATE_TIME_FORMATS.DEFAULT_TIME;
            return;
        }
        let seconds = dateDiffInMs / 1000;
        // Extract hours:
        let hours = (seconds / 3600); // 3,600 seconds in 1 hour
        hours = parseInt(hours.toString(), 0);
        seconds = seconds % 3600; // seconds remaining after extracting hours
        // Extract minutes:
        let minutes = (seconds / 60); // 60 seconds in 1 minute
        minutes = parseInt(minutes.toString(), 0);
        // Keep only seconds not extracted to minutes:
        seconds = (seconds % 60);
        seconds = parseInt(seconds.toString(), 0);
        let hoursStr = hours.toString();
        if (hoursStr.length < 2) {
            hoursStr = '0' + hoursStr;
        }
        let minutesStr = minutes.toString();
        if (minutesStr.length < 2) {
            minutesStr = '0' + minutesStr;
        }
        let secondsStr = seconds.toString();
        if (secondsStr.length < 2) {
            secondsStr = '0' + seconds;
        }
        this.countDownTime = (hoursStr !=='00') ? (hoursStr + ':' + minutesStr + ':' + secondsStr) : (minutesStr + ':' + secondsStr);
        if (this.countDownTime === '00:00') {
            this.stopCountDownTimer();
        }
    };

    private countDownTimeByCustomTime() {
        let currentDateTime = moment();
        let dateDiff = this.config.customDateTime.diff(currentDateTime);
        this.setCountDownTime(dateDiff);
    };

    private startCountDownTimer() {
        this.countDownTimerInst = setInterval(() => {
            if (!this.config.useCutomTime) {
                this.countDownTimeByFurthestClosingTime();
            } else {
                this.countDownTimeByCustomTime();
            }
        }, 1000);
    };

    private stopCountDownTimer() {
        clearInterval(this.countDownTimerInst);
    };

    private getFathestClosingTimeOfPackage() {
        this.countDownBoardService.getFathestClosingTimeOfPackage(this.countDownBoardService.projectInfo.slug).subscribe(
            res => {
                this.furthestClosingPackage = res.plain();
                this.startCountDownTimer();
            },
            err => {

            }, () => {
                setTimeout(() => {
                    this.appService.resetBusy();
                }, 1000);
            }
        );
    };

    private getProject() {
        this.appService.setBusy();
        this.countDownBoardService.getProject(this.countDownBoardService.projectInfo.slug).subscribe(
            res => {
                this.countDownBoardService.projectInfo = res.plain();
                this.projectInfo = this.countDownBoardService.projectInfo;
                this.config = this.countDownBoardService.getDefaultConfig();
            },
            err => {
                this.routeToErrorPage();
            }
        );
    };

    public getProjectPrefix() {
        let url = window.location.href;
        this.countDownBoardService.projectInfo.slug = url.slice(url.indexOf('//') + 2, url.indexOf('.'));
    };

    ngOnInit() {
        this.getProjectPrefix();
        this.getProject();
        this.getFathestClosingTimeOfPackage();
        this.getSponsors();
        this.listenEvents();
        this.connectSignalR();
    };
}
