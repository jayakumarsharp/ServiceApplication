import { Injectable, EventEmitter } from '@angular/core';
import { Restangular } from 'ng2-restangular';
import * as _ from 'lodash';

import { Config } from './config';
import * as moment from 'moment-timezone';
@Injectable()
export class CountdownBoardService {

    constructor(private restangular: Restangular) { }

    public config = new Config();
    public isConfigurationUpdated = new EventEmitter<Object>();
    public countDownBoardTheme: string;
    public projectInfo = {
        timezone: '',
        leaderboard_theme: 'Blue',
        slug: '',
        display_loop_time: 0
    };

    public getDefaultConfig() {
        let config = new Config();
        if ((!localStorage.length) || (!localStorage.countdown)) {
            return this.getDefaultSetting();
        }
        var storage = JSON.parse(localStorage.countdown);
        for (let key in config) {
            config[key] = storage[key];
        }
        if (config.customDateTime == undefined) {
            let customDateTime = moment().add(config.customTimeHours, 'hours');
            customDateTime = customDateTime.add(config.customTimeMin, 'minutes');
            customDateTime = customDateTime.add(config.customTimeSec, 'seconds');
            config.customDateTime = customDateTime;
        }
        return config;
    };

    public getDefaultSetting() {
        let config = new Config();
        if (this.projectInfo.display_loop_time) {
            config.sponsorsRefreshInterval = this.projectInfo.display_loop_time;
        }
        config.background = this.projectInfo.leaderboard_theme ? this.projectInfo.leaderboard_theme : 'blue';
        config.background = _.capitalize(config.background);
        localStorage.removeItem('countdown')
        return config;
    }
    public setUpdatedConfigs(config) {
        localStorage.setItem("countdown", JSON.stringify(config));
        this.isConfigurationUpdated.emit(config);
    };

    public getProject(projectName) {
        let params = { 'prefix': projectName };
        return this.restangular.oneUrl('/GetProject').get(params);
    };

    public getFathestClosingTimeOfPackage(projectName) {
        let params = { 'prefix': projectName };
        return this.restangular.oneUrl('/GetFurthestPackageClosingTime').get(params);
    };

    public getAppealPackage(projectName) {
        let params = { 'prefix': projectName };
        return this.restangular.oneUrl('/GetAppealDonationPackage').get(params);
    };

    public getSponsors(projectName) {
        let params = { 'prefix': projectName };
        return this.restangular.oneUrl('/GetSponsorImagesByPrefix').get(params);
    }
}
