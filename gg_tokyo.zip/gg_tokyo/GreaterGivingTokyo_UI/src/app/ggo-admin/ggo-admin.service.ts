import { Injectable, EventEmitter } from '@angular/core';
import { Restangular } from 'ng2-restangular';

@Injectable()
export class GgoAdminService {

    constructor(private restangular: Restangular) { }

    public getProject(projectName) {
        let params = {'prefix': projectName};
        return this.restangular.oneUrl('/GetProject').get(params);
    };

    public getSponsors(projectName) {
        let params = {'prefix': projectName};
        return this.restangular.oneUrl('/GetSponsorImagesByPrefix').get(params);
    }

    public generateValues(startingValue, endValue) {
        let values = [];
        for (let i = startingValue; i <= endValue; i++) {
            values.push(i);
        }
        return values;
    };
}
