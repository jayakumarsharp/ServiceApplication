import { Component, OnInit } from '@angular/core';
import * as pbi from 'powerbi-client';
import { AdminService } from './../admin.service';
import { BiddingAppService } from '../../../bidding/bidding-app.service';
import { ggoAdminConstants } from '../../ggo-admin.const';

@Component({
    selector: 'report',
    templateUrl: './report.component.html'
})
export class ReportComponent implements OnInit {

    constructor(private adminService: AdminService,
                private biddingAppService: BiddingAppService) { }

    public report;

    private getEmbedReport() {
        this.adminService.getEmbedReport(this.adminService.prefix).subscribe(
            res => {
                var t0 = performance.now();
                let reportDetails = res.Result;
                let powerbiClient = new pbi.service.Service(pbi.factories.hpmFactory, pbi.factories.wpmpFactory, pbi.factories.routerFactory);
                var models = pbi.models;
                let reportContainer = <HTMLElement>document.getElementById('reportContainer');
                powerbiClient.reset(reportContainer);
                let basicFilter = {
                    $schema: "http://powerbi.com/product/schema#basic",
                    target: {
                        table: "EventStatistics",
                        column: "ProjectXid"
                    },
                    operator: "In",
                    filterType: 1,
                    values: [this.adminService.projectInfo.ggProjectId]
                };

                let config = {
                    type: 'report',
                    tokenType: models.TokenType.Embed,
                    accessToken: reportDetails.EmbedToken.token,
                    embedUrl: reportDetails.EmbedUrl,
                    id: reportDetails.Id,
                    permissions: models.Permissions.All,
                    settings: {
                        filterPaneEnabled: true,
                        navContentPaneEnabled: false
                    },
                    filter: [basicFilter]
                };
                this.report = powerbiClient.embed(reportContainer, config);
                this.report.on("loaded", () => {
                    let rep = <pbi.Report>this.report;
                    rep.setFilters([basicFilter]);
                    var t1 = performance.now();
                });

                this.report.on("error", function (err) {
                    console.log(err);
                });
            },

            err => {
            }, () => {
                
            }
        );
    };

    private getProjectByPrefix() {
        let projectPrefix = sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
        this.adminService.prefix = projectPrefix;
        this.adminService.getProject(projectPrefix).subscribe(
            res => {
                this.adminService.projectInfo =  res.plain();
                this.getEmbedReport();
            },
            err => {
                // this.routeToErrorPage();
            }
        );
    };

    ngOnInit() {
        this.getProjectByPrefix();
    }
}
