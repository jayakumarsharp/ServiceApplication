import { Restangular } from 'ng2-restangular';
import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class AdminSlideOutMenuService {

    public showSlideViewChange = new EventEmitter<boolean>();

    public showSlideViewChanged(isShowSlideView: boolean) {
        this.showSlideViewChange.emit(isShowSlideView);
    };
}
