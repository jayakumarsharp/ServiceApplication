import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AdminSlideOutMenuService } from './slide-out-menu.service';

@Component({
    selector: 'slide-out-menu',
    templateUrl: 'slide-out-menu.component.html',
})

export class AdminSlideOutMenuComponent implements OnInit {

    constructor(private adminSlideOutMenuService: AdminSlideOutMenuService,
                private router: Router,
                private activatedRoute: ActivatedRoute
                ) { };

    public showAdminSlideOutMenu: boolean;

    public onSelectHome() {
        this.router.navigateByUrl('admin/home');
        this.closeSlideOutMenu();
    };

    public onViewBidders() {
        this.router.navigateByUrl('admin/bidders');
        this.closeSlideOutMenu();
    };

    public onViewPackages() {
        this.router.navigateByUrl('admin/packages');
        this.closeSlideOutMenu();
    };

    public onNavigateToSendMessage() {
        this.router.navigateByUrl('admin/send-sms');
        this.closeSlideOutMenu();
    };

    public onNavigateToEmailMessage() {
        this.router.navigateByUrl('admin/send-email');
        this.closeSlideOutMenu();
    };

    private closeSlideOutMenu() {
        this.adminSlideOutMenuService.showSlideViewChanged(false);
    };

    private listenEvents() {
        this.adminSlideOutMenuService.showSlideViewChange.subscribe(isSlideOutShow => {
            this.showAdminSlideOutMenu = isSlideOutShow;
        });
    };

    ngOnInit() {
        this.listenEvents();
    };
}
