import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit} from '@angular/core';
import { ToasterService } from 'angular2-toaster';

import { Utils } from './../../../bidding/common/utils';
import { ggoAdminConstants } from './../../ggo-admin.const';
import { AdminService } from './../admin.service';

@Component({
    template: '<div>Loading...</div>'
})

export class AdminAuthComponent implements OnInit {

    constructor(private router: Router,
                private toasterService: ToasterService,
                private activatedRoute: ActivatedRoute,
                private utils: Utils,
                private adminService: AdminService) {}


    public prefix: string;

    private getProjectPrefix() {
        let prefix = this.activatedRoute.snapshot.params['id'];
        sessionStorage.setItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX, prefix);
        //this.router.navigateByUrl('admin/home'); - For Local testing
    };

    private listenEvents() {
        window.addEventListener('message', this.getAdminToken, true);
    };

    private getAdminToken(event) {
        let origin: string = event.origin;
        let apiPrefix = 'https://bidding';
        if (origin.split('.')[0] !== apiPrefix) { return; }

        let urlPrefix = origin.split('.')[1];
        let enviroment = urlPrefix === 'ggo' ? '' : urlPrefix + '.';
        let redirectUrl = 'https://' + enviroment + 'ggo.bid/';
        window.top.location.href = redirectUrl + (event.data.length ? 'admin/home': 'bidding/error');
        sessionStorage.setItem(ggoAdminConstants.SESSION_STORAGE_KEYS.ADMIN_TOKEN, event.data);
    };

    ngOnInit() {
        this.getProjectPrefix();
        this.listenEvents();
    };
}
