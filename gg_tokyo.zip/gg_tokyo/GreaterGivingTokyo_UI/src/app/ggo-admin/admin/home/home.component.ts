import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SignalR} from 'ng2-signalr';
import * as moment from 'moment';
import * as pbi from 'powerbi-client';

import { biddingErrorConstants } from './../../../bidding/bidding-app.error.const';
import { biddingAppConstants } from './../../../bidding/bidding-app.const';
import { ggoAdminConstants } from './../../ggo-admin.const';
import { CurrencyFilter } from './../../../common/currency-filter';
import { AdminService } from './../admin.service';
import { AppService } from '../../../app.service';
import { ErrorHandlerService } from '../../../bidding/error-handler/error-handler.service';
import { Utils } from '../../../bidding/common/utils';

@Component({
  selector: 'admin-home',
  templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {

    constructor(private router: Router,
                private signalR: SignalR,
                private currencyFilter: CurrencyFilter,
                private appService: AppService,
                private adminService: AdminService,
                private errorHandlerService: ErrorHandlerService,
                private utils: Utils) { }

    public biddersCount = 10;
    public packageCount = 10;
    public packages = [];
    public biddingHistory = [];
    public biddersInfo = [];
    public ggoAdminConstants = ggoAdminConstants;
    public projectPrefix: string;
    public colNamesProperty = [
        {
            colName: 'Package #',
            fieldName: 'packagenumber',
            type: ''
        },
        {
            colName: 'Package Name',
            fieldName: 'itemname',
            type: ''
        },
        {
            colName: 'Value',
            fieldName: 'value',
            type: 'Amount'
        },
        {
            colName: 'Bidder #',
            fieldName: 'biddernumber',
            type: ''
        },
        {
            colName: 'Bidder Name',
            fieldName: 'biddername',
            type: ''
        },
        {
            colName: 'Phone',
            fieldName: 'phone',
            type: ''
        },
        {
            colName: 'Email',
            fieldName: 'email',
            type: ''
        },
        {
            colName: 'Amount',
            fieldName: 'amount',
            type: 'Amount'
        },
        {
            colName: 'Date & Time',
            fieldName: 'createdDate',
            type: 'Date'
        },
        {
            colName: 'Deleted',
            fieldName: 'isdeleted',
            type: 'Delete'
        }
    ];
    public report;
    public refreshTimeInstance;
    public disableRefresh: boolean = true;
    public lastUpdatedTime:string;


    private getEmbedReport() {
        this.adminService.getEmbedReport(this.projectPrefix).subscribe(
            res => {
                var t0 = performance.now();
                let reportDetails = res.Result;
                let powerbiClient = new pbi.service.Service(pbi.factories.hpmFactory, pbi.factories.wpmpFactory, pbi.factories.routerFactory);                
                var models = pbi.models;
                let reportContainer = <HTMLElement>document.getElementById('reportContainer');
                //powerbiClient.reset(reportContainer);
                let basicFilter = {
                    $schema: "http://powerbi.com/product/schema#basic",
                    target: {
                        table: "EventStatistics",
                        column: "ProjectXid"
                    },
                    operator: "In",
                    filterType: 1,
                    values: [this.adminService.projectInfo.ggProjectId]
                };
               
                let config = {
                    type: 'report',
                    tokenType: models.TokenType.Embed,
                    accessToken: reportDetails.EmbedToken.token,
                    embedUrl: reportDetails.EmbedUrl,
                    id: reportDetails.Id,
                    permissions: models.Permissions.All,
                    settings: {
                        filterPaneEnabled: false,
                        navContentPaneEnabled: false
                    },
                    filter: [basicFilter]
                };
                this.report = powerbiClient.embed(reportContainer, config);
                this.report.on("loaded", ()=> {
                    let rep = <pbi.Report>this.report;
                    rep.setFilters([basicFilter]);
                    this.startReportTimer();
                    this.getLastUpdatedTime(new Date());
                    var t1 = performance.now();
                });

                this.report.on("error", function(err) {
                    console.log(err);
                });
            },

            err => {
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private getTopBidders() {
        this.adminService.getTopBidders(this.projectPrefix, this.biddersCount).subscribe(
            res => {
                this.biddersInfo =  res.plain();
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        )
    };

    private getBiddingHistory() {
        this.adminService.getBiddingHistory(this.projectPrefix).subscribe(
            res => {
                this.biddingHistory =  res.plain();
            },
            err => {

            }
        )
    };

    private getTopPackages() {
        this.adminService.getTopPackages(this.projectPrefix, this.packageCount).subscribe(
            res => {
                this.packages = res.plain();
            },
            err => {

            }
        )
    };
 
    private connectSignalR() {
        this.signalR.connect().then(res => {
            res.listenFor('DisplayTopBidders').subscribe((prefix) => {
                if (this.projectPrefix === prefix) {
                    this.getTopBidders();
                }
            });
        });
        this.signalR.connect().then(res => {
            res.listenFor('DisplayTopPackages').subscribe((prefix) => {
                if (this.projectPrefix === prefix) {
                    this.getTopPackages();
                }
            });
        });
    };

    public onOpenBoard(board: string) {
        let domain = window.location.hostname;
        let prefixSegment = domain.slice(0, domain.indexOf('.'));
        let projectPrefix = this.projectPrefix.toLowerCase();
        if (board === ggoAdminConstants.BOARD_NAMES.APPEAL_BOARD) {
            if (this.utils.contains(projectPrefix, prefixSegment)) {
                window.open('https://' + domain + '/appeal-board');
            } else {
                window.open('https://' + projectPrefix + '.' + domain + '/appeal-board');
            }
        } else if (board === ggoAdminConstants.BOARD_NAMES.LEADER_BOARD) {
            if (this.utils.contains(projectPrefix, prefixSegment)) {
                window.open('https://' + domain + '/leader-board');
            } else {
                window.open('https://' + projectPrefix + '.' + domain + '/leader-board');
            }
        } else if (board === ggoAdminConstants.BOARD_NAMES.COUNTDOWN_BOARD) {
            if (this.utils.contains(projectPrefix, prefixSegment)) {
                window.open('https://' + domain + '/countdown-board');
            } else {
                window.open('https://' + projectPrefix + '.' + domain + '/countdown-board');
            }
        }
    };

    public onViewAllBidders() {
        this.adminService.routeToAllBidders();
    };

    public onViewAllPackages() {
        this.adminService.routeToAllPackages();
    };

    public routeToPackageInfo(packageId) {
        this.adminService.routeToPackageInfo(packageId);
    };

    public routeToBidderDetail(bidderId) {
        this.adminService.routeToBidderDetail(bidderId);
    };

    private getProjectPrefix() {
        this.projectPrefix = sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
        this.getTopBidders();
        this.getTopPackages();
        this.getBiddingHistory();
    };

    private onNavigateToSendMessage() {
        this.router.navigateByUrl('admin/send-sms');
    };

    private onNavigateToEmailMessage() {
        this.router.navigateByUrl('admin/send-email');
    };

    private onExportBiddingHistory() {
        let data = [];
        let biddingCopy = Object.assign(this.biddingHistory, []);
        biddingCopy.forEach((item) => {
            let updatedItem = {};
            for (let i = 0; i < this.colNamesProperty.length; i++) {
                let colNameProperty = this.colNamesProperty[i];
                let fieldName = colNameProperty.fieldName;
                let value = item[fieldName];
                let colName = colNameProperty.colName;
                switch (colNameProperty.type) {
                    case 'Date':
                        value = (value) ? this.appService.convertTimeByTimeZone(value, this.adminService.projectInfo.timezone)
                                                         .format(ggoAdminConstants.DATE_TIME_FORMATS.DATE_WITHOUT_YEAR) : value;
                        break;
                    case 'Amount':
                        value = (!!value) ? '$'+(this.currencyFilter.transform(value)) : '';
                        break;
                    case 'Delete':
                        value = (item.isdeleted) ? 'X' : '';
                        break;
                    default:
                    break;
                }
                updatedItem[colName] = value;
            }
            data.push(updatedItem);
        });
        this.adminService.exportAsExcelFile(data, 'All-Bids');
    };

    public count = 0;
    private reportTimer;

    private startReportTimer() {
        this.reportTimer = setInterval(() => {
            this.updateReport();
        }, 15500);
    };

    private updateReport() {
        // if (this.disableRefresh) {
        //     return;
        // }
        <pbi.Report>this.report.refresh();
        this.getLastUpdatedTime(new Date());
        // this.disableRefresh = true;
        // // Power BI has a minimum refresh time of 15 seconds
        // setTimeout(() => {
        //     this.disableRefresh = false;
        // }, 15000);
    };

    private getLastUpdatedTime(lastUpdatedTime) {
        this.lastUpdatedTime = this.appService.convertTimeByTimeZone(lastUpdatedTime,
                                                                     this.adminService.projectInfo.timezone)
                                              .format(biddingAppConstants.DATE_TIME_FORMATS.TIME_WITH_ZONE);
    };

    ngOnInit() {
        this.appService.setBusy();
        this.getProjectPrefix();
        this.getEmbedReport();
        this.connectSignalR();
    };
}
