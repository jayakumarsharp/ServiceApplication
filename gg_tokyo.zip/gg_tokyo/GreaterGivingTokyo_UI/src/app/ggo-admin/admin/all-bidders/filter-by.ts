export class FilterBy {
    public biddername: string;
    public biddernumber: string;

    constructor() {
        this.biddername = '';
        this.biddernumber = '';
    }
};
