import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import * as $ from 'jquery';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { ggoAdminConstants } from './../../ggo-admin.const';
import { FilterBy } from './filter-by';
import { AdminService } from './../admin.service';
import { AppService } from '../../../app.service';
import { ClearMaxBidPopUpComponent } from '../clear-maxbid-pop-up/clear-maxbid-pop-up.component';

@Component({
  selector: 'all-bidders',
  templateUrl: './all-bidders.component.html',
  styleUrls: ['../../../../../node_modules/@progress/kendo-theme-default/dist/all.css']
})

export class BiddersComponent implements OnInit {

    constructor(private adminService: AdminService,
                private modal: Modal,
                private overlay: Overlay,
                private vcRef: ViewContainerRef,
                private appService: AppService) { 
                    overlay.defaultViewContainer = vcRef;
                }

    public projectPrefix: string
    public bidders = [];
    public filterBy = new FilterBy();
    private sort: SortDescriptor[] = [{
        dir: 'asc',
        field:  'biddername'
    }];
    public gridHeight = 0;

    public colNamesProperty = {
        1: {
            colName: 'Bidder Name',
            fieldName: 'biddername',
        },
        2: {
            colName: 'Bid #',
            fieldName: 'biddernumber',
            type: 'Number',
        },
        3: {
            colName: 'History',
            fieldName: 'bids',
            type: 'Bids',
        },
        4: {
            colName: 'Table',
            fieldName: 'tablenumber',
            type: 'Number',
        },
        5: {
            colName: 'Email',
            fieldName: 'email',
            type: 'Array',
        },
        6: {
            colName: 'Phone',
            fieldName: 'phone',
            type: 'Array',
        }
    };

    public onFilterBidders() {
        this.getBiddersByFilterBy();
    };

    public onResetFilter() {
        this.filterBy = new FilterBy();
        this.getBiddersByFilterBy();
    };

    public onRemoveAllBids() {
        this.adminService.actionType = ggoAdminConstants.REMOVE_ACTION_TYPE.ALL_BID;
        return this.modal.open(ClearMaxBidPopUpComponent, overlayConfigFactory({dialogClass: 'clear-bid-modal'}, BSModalContext));
    };

    public sortChange(sort: SortDescriptor[]): void {
        this.sort = sort;
        $('td').css({'background': 'white'});
        this.loadProducts(sort);
        setTimeout(() => {
            $('.sorted-col').parent('td').css({'background': '#E8ECF0'});
        });
    };

    private loadProducts(sort) {
      this.bidders = orderBy(this.bidders, this.sort);
    };

    public getBiddersByFilterBy() {
        this.appService.setBusy();
        this.adminService.getAllBidders(this.projectPrefix, this.filterBy).subscribe(
            res => {
                this.bidders = res.plain();
                this.defaultSorting();
                this.setGridHeight();
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private defaultSorting() {
        this.sort = [];
        this.sort.push({
            dir: 'asc',
            field:  this.colNamesProperty[1].fieldName
        });
        setTimeout(() => $('.sorted-col').parent('td').css({'background': '#E8ECF0'}));
    };

    public routeToBidderDetail(bidderId) {
        this.adminService.routeToBidderDetail(bidderId);
    };

    public onExportGrid() {
        let data = [];
        this.bidders.forEach((item) => {
            let updatedItem = {};
            Object.keys(this.colNamesProperty).map(key => {
                let colNameProperty= this.colNamesProperty[key];
                let fieldName = colNameProperty.fieldName;
                let value = item[fieldName];
                let colName = colNameProperty.colName;
                if (colNameProperty.type) {
                    if (colNameProperty.type === 'Bids') {
                        value = (value) ? (value + ' Bids ') : ' ';
                    }
                    if (colNameProperty.type === 'Number') {
                        value = (value) ? (value) : ' ';
                    }
                    if (colNameProperty.type === 'Array') {
                        let content: string = '';
                        for (let i = 0; i < value.length; i++) {
                           content = content.concat(value[i] + '\n');
                        }
                        value = content;
                    }
                }
                updatedItem[colName] = value;
            });
            data.push(updatedItem);
        });
        this.adminService.exportAsExcelFile(data, 'All-Bidders');
    };

    private getAllBidders() {
        this.getBiddersByFilterBy();
    };

    private listenEvents() {
        this.adminService.isAllBidRemoved.subscribe(isAllBidRemoved => {
            this.getAllBidders();
        });
    };

    private getProjectPrefix() {
        this.projectPrefix = this.projectPrefix = (this.adminService.prefix) ? this.adminService.prefix :
                                                                  sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
        this.getAllBidders();
    };

    private setGridHeight() {
        let previousScrollPosition = ($('.k-grid-content')[0]) ? $('.k-grid-content')[0].scrollTop : 0;
        this.gridHeight = this.adminService.getGridHeight();
        if (previousScrollPosition === 0) {
            previousScrollPosition = 10;
        }
        $('.k-grid-content').scrollTop( previousScrollPosition - 1);
    };

    private onBrowserResize() {
        window.onresize = () => {
            this.setGridHeight();
        };
    };

    ngOnInit() {
        this.getProjectPrefix();
        this.onBrowserResize();
        this.listenEvents();
    };
}
