import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SignalR} from 'ng2-signalr';

import { biddingErrorConstants } from './../../bidding/bidding-app.error.const';
import { CurrencyFilter } from './../../common/currency-filter';
import { ggoAdminConstants } from './../ggo-admin.const';
import { AdminService } from './admin.service';
import { ErrorHandlerService } from '../../bidding/error-handler/error-handler.service';
import { Utils } from '../../bidding/common/utils';
import { AdminSlideOutMenuService } from '../admin/slide-out-menu/slide-out-menu.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
})
export class AdminComponent implements OnInit {

    constructor(private router: Router,
                private signalR: SignalR,
                private currencyFilter: CurrencyFilter,
                private adminSlideOutMenuService: AdminSlideOutMenuService,
                private adminService: AdminService,
                private errorHandlerService: ErrorHandlerService,
                private utils: Utils) { }

    public packages = [];
    public biddersInfo = [];
    public projectInfo = {
        slug: ''
    };
    public showAdminSlideOutMenu = false;
    public currentYear = (new Date().getFullYear());
    public ggoAdminConstants = ggoAdminConstants;

    public onCloseAdmin() {
        sessionStorage.clear();
        this.router.navigateByUrl('/logout');
    };

    private getProjectByPrefix() {
        let projectPrefix = sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
        this.adminService.prefix = projectPrefix;
        this.adminService.getProject(projectPrefix).subscribe(
            res => {
                this.cbsGetProject(res);
            },
            err => {
                this.routeToErrorPage();
            }
        );
    };

    private cbsGetProject(res) {
        let projectInfo = res.plain();
        if (!projectInfo.slug || projectInfo.slug === '') {
            this.routeToErrorPage();
        }
        sessionStorage.setItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX, projectInfo.slug);
        this.projectInfo = projectInfo;
        this.adminService.projectInfo = this.projectInfo;
        this.adminService.prefix =  projectInfo.slug;
    };

    private routeToErrorPage() {
        this.errorHandlerService.errorMessage = biddingErrorConstants.PROJECT_ID_NOT_FOUND;
        this.router.navigateByUrl('bidding/error');
    };

    public onAdminSlideOutMenuToggle(isFromAdminSlideOutMenuIcon) {
        if (!isFromAdminSlideOutMenuIcon && !this.showAdminSlideOutMenu) {
            return;
        }
        this.showAdminSlideOutMenu = !this.showAdminSlideOutMenu;
    };

    private listenEvents() {
        this.adminSlideOutMenuService.showSlideViewChange.subscribe(
            isShowSlideView => this.showAdminSlideOutMenu = isShowSlideView
        );
    };

    ngOnInit() {
        this.getProjectByPrefix();
        this.listenEvents();
    };
}
