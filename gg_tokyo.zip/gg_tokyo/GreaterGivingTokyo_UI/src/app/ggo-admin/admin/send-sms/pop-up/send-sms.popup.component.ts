import { SendEmailService } from './../../send-email/send-email.service';
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { DialogRef } from 'angular2-modal';

import { SendSmsService } from '../send-sms.service';
import { ggoAdminConstants } from '../../../ggo-admin.const';

@Component({
  selector: 'send-sms-popup',
  templateUrl: './send-sms-popup.component.html'
})
export class SendSmsPopupComponent implements OnInit {

    constructor(private router: Router,
                private dialog: DialogRef<any>,
                private sendSmsService: SendSmsService,
                private sendEmailService: SendEmailService) {
                }

    public actionType: string;
    public ggoAdminConstants = ggoAdminConstants;
    public isSmsNumberValid: boolean = true;
    public number;
    public message;
    public previewSuccessMsg;
    public showLoader: boolean;

    public setBusy() {
        this.showLoader = true;
    };

    public resetBusy() {
        this.showLoader = false;
    };

    public onCancel() {
        this.dialog.close();
    };

    public onReset() {
        this.isSmsNumberValid = true;
    };

    public onSmsChange() {
        this.isSmsNumberValid = /^[(]{0,1}[0-9]{3}[)]{0,1} {0,1}[0-9]{3}[-]{0,1}[0-9]{4}$/g.test(this.number);
    };

    public onNavigateToAdmin() {
        this.onCancel();
        setTimeout(() => {
            this.sendEmailService.redirectToHome(true);
        }, 1000);
    };

    public onSendPreviewSms() {
        this.setBusy()
        this.sendSmsService.sendPreviewMessage(this.sendSmsService.prefix, this.message, this.number).subscribe(
            res => {
                this.cbsOnPreviewMessageSend(res);
            },
            err => {

            }, () => {
                this.resetBusy();
            }
        );
    };

    public cbsOnPreviewMessageSend(res) {
        let response = res.plain();
        if (response.message === 'Success') {
            this.previewSuccessMsg = true;
        }
    };

    ngOnInit() {
        this.actionType = this.sendSmsService.actionType;
        this.message = this.sendSmsService.message;
    };
}
