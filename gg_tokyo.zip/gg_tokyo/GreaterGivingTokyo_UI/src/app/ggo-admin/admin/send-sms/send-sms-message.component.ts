import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import * as _ from 'lodash';

import { SendEmailService } from './../send-email/send-email.service';
import { ggoAdminConstants } from '../../ggo-admin.const';
import { SendSmsPopupComponent } from './pop-up/send-sms.popup.component';
import { SendSmsService } from './send-sms.service';
import { AdminService } from './../admin.service';
import { AppService } from '../../../app.service';

@Component({
  selector: 'send-sms-message',
  templateUrl: './send-sms-message.component.html'
})
export class SendSmsMessageComponent implements OnInit {

    constructor(private overlay: Overlay,
                private modal: Modal,
                private sendSmsService: SendSmsService,
                private adminService: AdminService,
                private sendEmailService: SendEmailService,
                private appService: AppService,
                private vcRef: ViewContainerRef) {
                    overlay.defaultViewContainer = vcRef;
                }

    public projectPrefix: string;
    public message: string;
    public smsTemplateInfo = [];
    public ggoAdminConstants = ggoAdminConstants;
    public projectInfo = {
        ggProjectId: 0
    };
    public remainingCharacters = 120;
    public recipients = 'All';
    public isSavedMessageClicked: boolean = false;

    public onMessageChange() {
        this.remainingCharacters = 120 - (this.message.length);
        if (this.isSavedMessageClicked) {
            this.isSavedMessageClicked = false;
        }
    };

    public onSendMessage() {
        this.appService.setBusy();
        this.sendSmsService.actionType = ggoAdminConstants.ACTION_TYPES.SEND;
        this.sendSmsService.sendSms(this.projectPrefix, this.recipients, this.message).subscribe(
            res => {
                this.cbsSendMessage(res);
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    public onSaveCurrentMessage() {
        this.appService.setBusy();
        this.sendSmsService.saveCurrentMesssage(this.projectPrefix, this.message).subscribe(
            res => {
                this.cbsSaveCurrentMesssage(res);
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    public onDeleteTemplate(templateId) {
        this.appService.setBusy();
        this.sendSmsService.deleteTemplate(this.projectPrefix, this.projectInfo.ggProjectId, templateId).subscribe(
            res => {
                this.cbsDeleteTemplate(res, templateId);
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    public cbsSendMessage(res) {
        let response = res.plain();
        if (response.message === 'Success') {
            return this.modal.open(SendSmsPopupComponent, overlayConfigFactory({dialogClass: 'modal-configuration'}, BSModalContext));
        }
    };

    public cbsSaveCurrentMesssage(res) {
        let response = res.plain();
        if (response.message === 'Success') {
            this.getSmsTemplate();
        }
    };

    public cbsDeleteTemplate(res, templateId) {
        let response = res.plain();
        if (response.message === 'Success') {
            let deletedIndex = _.findIndex(this.smsTemplateInfo, {'smstemplateid': templateId});
            this.smsTemplateInfo.splice(deletedIndex, 1);
        }
    };

    public onPreviewMessage() {
        this.sendSmsService.actionType = ggoAdminConstants.ACTION_TYPES.PREVIEW;
        this.sendSmsService.message = this.message;
        return this.modal.open(SendSmsPopupComponent, overlayConfigFactory({dialogClass: 'modal-configuration'}, BSModalContext));
    };

    public onCancelMessage() {
        this.sendSmsService.actionType = ggoAdminConstants.ACTION_TYPES.CANCEL;
        return this.modal.open(SendSmsPopupComponent, overlayConfigFactory({dialogClass: 'modal-configuration'}, BSModalContext));
    };

    private getSmsTemplate() {
        this.sendSmsService.getSmsTemplate(this.projectPrefix).subscribe(
            res => {
                this.cbsGetSmsTemplate(res);
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private cbsGetSmsTemplate(res) {
        this.smsTemplateInfo = res.plain();
        this.scrollSavedMessagesSection();
    };

    public scrollSavedMessagesSection() {
        let savedSectionElement = document.getElementById("scroll-section");
        setTimeout(() => {
            savedSectionElement.scrollTop = 0;
        });
    };

    private getProjectPrefix() {
        this.projectPrefix = (this.sendSmsService.prefix) ? this.sendSmsService.prefix :
                                                                  sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
        this.sendSmsService.prefix = this.projectPrefix;
        this.adminService.getProject(this.projectPrefix).subscribe(
            res => {
                this.cbsGetProject(res);
            },
            err => {
                // this.routeToErrorPage();
            }
        );
    };

    private cbsGetProject(res) {
        this.projectInfo = res.plain();
    };

    public onSelectSavedMessage(template) {
        this.message = template.message;
        this.onMessageChange();
        this.isSavedMessageClicked = true;
    };

    public listenEvents() {
        this.sendEmailService.isToRedirectHome.subscribe((isToRedirect) => {
            this.adminService.routeToHome();
        });
    };

    ngOnInit() {
        this.appService.setBusy();
        this.listenEvents();
        this.getProjectPrefix();
        this.getSmsTemplate();
    };
}
