import { Injectable } from '@angular/core';
import { Restangular } from 'ng2-restangular';


@Injectable()
export class SendSmsService {

    constructor(private restangular: Restangular) { }

    public actionType: string;
    public prefix: string;
    public message;
    private headers = {'adminURL': true};

    public sendSms(projectPrefix, recipientType, message) {
        let queryParams = {};
        queryParams['prefix'] = projectPrefix;
        queryParams['recipientType'] = recipientType;
        let bodyParams = {};
        bodyParams['message'] = message;
        return this.restangular.all('/SendRegistrationSMS').customPUT(bodyParams, undefined, queryParams, this.headers);
    };

    public sendPreviewMessage(projectPrefix, message, number ) {
        let params = {};
        params['prefix'] = projectPrefix;
        let bodyParams = {};
        bodyParams['message'] = message;
        bodyParams['phone'] = number;
        return this.restangular.all('/SendPreviewSMS').customPUT(bodyParams, undefined, params, this.headers);
    };

    public getSmsTemplate(projectPrefix) {
        let params = {'prefix': projectPrefix};
        return this.restangular.oneUrl('/GetSMSTemplates').get(params, this.headers);
    };

    public saveCurrentMesssage(projectPrefix, message) {
        let params = {};
        params['prefix'] = projectPrefix;
        let bodyParams = {};
        bodyParams['message'] = message;
        return this.restangular.oneUrl('/SaveSMSTemplate').post(undefined, bodyParams, params, this.headers);
    };

    public deleteTemplate(projectPrefix, projectId, templateId) {
        let queryParams = {};
        queryParams['prefix'] = projectPrefix;
        queryParams['projectId'] = projectId;
        queryParams['smsTemplateId'] = templateId;
        return this.restangular.oneUrl('/DeleteSMSTemplate').post(undefined, undefined, queryParams, this.headers);
    };
}
