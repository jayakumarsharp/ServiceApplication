import { Injectable, EventEmitter } from '@angular/core';
import { Restangular } from 'ng2-restangular';
import { Router } from '@angular/router';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import * as moment from 'moment';

import { Utils } from './../../bidding/common/utils';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xls';

@Injectable()
export class AdminService {

    constructor(private restangular: Restangular,
                private router: Router,
                public utils: Utils) { }

    public prefix: string;
    public projectInfo;
    public actionType;
    public packageId;
    public bidId;
    public saleId;
    public isMaxBidCleared = new EventEmitter<boolean>();
    public isBidRemoved = new EventEmitter<boolean>();
    public isAllBidRemoved = new EventEmitter<boolean>();
    private headers = {'adminURL': true};

    public maxBidCleared(value: boolean) {
        this.isMaxBidCleared.emit(value);
    };

    public bidRemoved(value: boolean) {
        this.isBidRemoved.emit(value);
    };

    public allBidRemoved(value: boolean) {
        this.isAllBidRemoved.emit(value);
    };

    public getProject(projectPrefix) {
        let params = {'prefix': projectPrefix};
        return this.restangular.oneUrl('/GetProject').get(params);
    };

    public getEmbedReport(projectPrefix) {
        let params = {'prefix': projectPrefix};
        return this.restangular.oneUrl('/EmbedReport').get(params, this.headers);
    };

    public getTopBidders(projectPrefix, count) {
        let params = {};
        params['prefix'] = projectPrefix;
        params['count'] = count;
        return this.restangular.oneUrl('/GetTopBidders').get(params, this.headers);
    };

    public getLastUpdatedTime(projectPrefix) {
        let params = {'prefix': projectPrefix};
        return this.restangular.oneUrl('/EmbedReportLastUpdatedDateTimeByProject').get(params, this.headers);
    };

    public getTopPackages(projectPrefix, count) {
        let params = {};
        params['prefix'] = projectPrefix;
        params['count'] = count;
        return this.restangular.oneUrl('/GetTopPackages').get(params, this.headers);
    };

    public getAllPackages(projectPrefix, filterBy) {
        let params = {'prefix': projectPrefix};
        return this.restangular.all('/GetAllPackages').customPUT(filterBy, undefined, params, this.headers);
    };

    public getAllBidders(projectPrefix, filterBy) {
        let params = {'prefix': projectPrefix};
        return this.restangular.all('/GetAllBidders').customPUT(filterBy, undefined, params, this.headers);
    };

    public getCategoryTypesByProject(projectName) {
        let params = {'prefix': projectName};
        return this.restangular.oneUrl('/GetCategoryTypesByProject').get(params, this.headers);
    };

    public getBidsHistorybyBidderId(bidderId, projectPrefix) {
        let params = {'prefix': projectPrefix, 'bidderId': bidderId};
        return this.restangular.oneUrl('/GetBidderBidHistory').get(params, this.headers);
    };

    public getPackageHistorybyPackageId(packageId, projectPrefix) {
        let params = {'prefix': projectPrefix, 'bidderId': packageId};
        return this.restangular.oneUrl('/GetPackageBidHistory').get(params, this.headers);
    };

    public getMaxBidsbyBidderId(bidderId, projectPrefix) {
        let params = {'prefix': projectPrefix, 'bidderId': bidderId};
        return this.restangular.oneUrl('/GetBidderMaxBid').get(params, this.headers);
    };

    public getMaxBidsbyPackageId(packageId, projectPrefix) {
        let params = {'prefix': projectPrefix, 'bidderId': packageId};
        return this.restangular.oneUrl('/GetPackageMaxBid').get(params, this.headers);
    };

    public getBidderDetailsByBidderId(bidderId, projectPrefix) {
        let params = {'prefix': projectPrefix, 'bidderId': bidderId};
        return this.restangular.oneUrl('/GetBidderDetails').get(params, this.headers);
    };

    public getPackageDetailsByPackageId(packageId, projectPrefix) {
        let params = {'prefix': projectPrefix, 'bidderId': packageId};
        return this.restangular.oneUrl('/GetPackageDetails').get(params, this.headers);
    };

    public getMaxBidsForPackage(projectPrefix, packageId) {
        let params = {'prefix': projectPrefix, 'packageId': packageId};
        return this.restangular.oneUrl('/GetPackageMaxBid').get(params, this.headers);
    };

    public getPackageDetail(projectPrefix, packageId) {
        let params = {'prefix': projectPrefix, 'packageId': packageId};
        return this.restangular.oneUrl('/GetPackageDetails').get(params, this.headers);
    };

    public getBidsHistory(projectPrefix, packageId) {
        let params = {'prefix': projectPrefix, 'packageId': packageId};
        return this.restangular.oneUrl('/GetPackageBidHistory').get(params, this.headers);
    };

    public getBiddingHistory(projectPrefix) {
        let params = {'prefix': projectPrefix};
        let headers = {'adminURL': true};
        return this.restangular.oneUrl('/ExportAllBiddingHistory').get(params, headers);
    };

    public clearMaxBid(projectPrefix, packageId) {
        let queryParams = {};
        queryParams['prefix'] = projectPrefix;
        queryParams['packageId'] = packageId;
        return this.restangular.one('/ClearMaxBid').post(undefined, undefined, queryParams, this.headers);
    };

    public clearBid(projectPrefix, bidId, saleId) {
        let queryParams = {};
        queryParams['prefix'] = projectPrefix;
        queryParams['bidId'] = bidId;
        queryParams['saleId'] = saleId;
        return this.restangular.one('/RemoveBid').post(undefined, undefined, queryParams, this.headers);
    };

    public removeAllBids(projectPrefix) {
        let params = {'prefix': projectPrefix};
        return this.restangular.one('/RemoveAllBids').post(undefined, undefined, params, this.headers);
    };

    public exportAsExcelFile(data, fileName) {
        const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
        this.wrapAndCenterCell(worksheet.B2);
        const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
        const excelBuffer: any = XLSX.write(workbook, { bookType: 'biff2', type: 'binary' });
        this.saveAsExcelFile(excelBuffer, fileName);
    };

    private wrapAndCenterCell(cell: XLSX.CellObject) {
        const wrapAndCenterCellStyle = { alignment: { wrapText: true, vertical: 'center', horizontal: 'center' } };
        this.setCellStyle(cell, wrapAndCenterCellStyle);
    };

    private setCellStyle(cell: XLSX.CellObject, style) {
        cell.s = style;
    };

    private saveAsExcelFile(buffer: any, fileName) {
        const data: Blob = new Blob([buffer], { type: EXCEL_TYPE});
        let currentDate = moment().format('MMDDYYYYhhmmss');
        FileSaver.saveAs(data, fileName + '-' + currentDate + EXCEL_EXTENSION);
    };

    public alphaNumericSorting(data: any[], filedName: string) {
        let sortedData =  data.sort((a, b) => {
            return this.sortAlphaNumeric(a[filedName], b[filedName]);
        });
        return sortedData;
    };

    private sortAlphaNumeric(a, b) {
        let aMixed = this.normalizeMixedDataValue(a);
        let bMixed = this.normalizeMixedDataValue(b);
        return( aMixed < bMixed ? -1 : 1 );
    };

    private normalizeMixedDataValue(value) {
        let padding = '000000000000000';
        value = value.replace(
            /(\d+)((\.\d+)+)?/g,
            function( $0, integer, decimal, $3 ) {
                if ( decimal !== $3 ) {
                    return(
                        padding.slice( integer.length ) +
                        integer +
                        decimal
                    );
                }
                decimal = ( decimal || '.0' );
                return(
                    padding.slice( integer.length ) +
                    integer +
                    decimal +
                    padding.slice( decimal.length )
                );

            }
        );
        return(value);
    };

    public getGridHeight() {
        let windowHeight = window.innerHeight;
        let url = window.location.href;
        let outterHeight = ((this.utils.contains(url, '/bidder-detail')) || (this.utils.contains(url, '/package-info'))) ? 285 : 250;
        let gridHeight = windowHeight - outterHeight;
        return gridHeight;
    };

    public routeToPackageInfo(packageId) {
        this.router.navigateByUrl('/admin/package-info/' + packageId);
    };

    public routeToBidderDetail(bidderid) {
        this.router.navigateByUrl('admin/bidder-detail/' + bidderid);
    };

    public routeToAllBidders() {
        this.router.navigateByUrl('/admin/bidders');
    };

    public routeToAllPackages() {
        this.router.navigateByUrl('/admin/packages');
    };

    public routeToHome() {
        this.router.navigateByUrl('/admin/home');
    };

};
