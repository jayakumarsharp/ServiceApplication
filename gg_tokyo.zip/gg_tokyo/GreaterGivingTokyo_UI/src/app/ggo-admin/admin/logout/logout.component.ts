import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-logout',
  templateUrl: './logout.component.html'
})
export class AdminLogoutComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
