import { Component, OnInit } from '@angular/core';
import { DialogRef } from 'angular2-modal';
import { ActivatedRoute, Router } from '@angular/router';

import { AdminService } from './../admin.service';
import { ggoAdminConstants } from './../../ggo-admin.const';

@Component({
    templateUrl: 'clear-maxbid-pop-up.component.html',
})

export class ClearMaxBidPopUpComponent implements OnInit {

    constructor(private adminService: AdminService,
                private activatedRoute: ActivatedRoute,
                private dialog: DialogRef<any>) { }
    
    public actionType;
    public packageId: number;
    public projectPrefix: string;
    public ggoAdminConstants = ggoAdminConstants;
    public showErrMsg = false;
    
    public onClearMaxBid() {
        this.onCancel();
        this.adminService.clearMaxBid(this.projectPrefix, this.adminService.packageId).subscribe(
            res => {
                this.cbsClearMaxBid(res);
            },
            err => {

            },
        );  
    };

    public onRemoveBid() {
        this.onCancel();
        this.adminService.clearBid(this.projectPrefix, this.adminService.bidId, this.adminService.saleId).subscribe(
            res => {
                this.cbsRemoveBid(res);
            },
            err => {
            
            }
        );
    };

    public onRemoveAllBids() {
        this.onCancel();
        this.adminService.removeAllBids(this.projectPrefix).subscribe(
            res => {
                this.cbsRemoveAllBids(res);
            },
            err => {
            
            }
        );
    };

    private cbsClearMaxBid(res) {
        let response = res.plain();
        if (response.message === 'Success') { 
            this.adminService.maxBidCleared(true);
        } else { 
            this.showErrMsg = true; 
        } 
    };

    private cbsRemoveBid(res) {
        let response = res.plain();
        if (response.message === 'Success') {
            this.adminService.bidRemoved(true);
        } else {
            this.showErrMsg = true;
        }
    };

    private cbsRemoveAllBids(res) {
        let response = res.plain();
        if (response.message === 'Success') {
            this.adminService.allBidRemoved(true);
        } else {
            this.showErrMsg = true;
        }
    };

    private onCancel() {
        this.dialog.close();
    };

    private getProjectPrefix() {
        this.projectPrefix = this.projectPrefix = (this.adminService.prefix) ? this.adminService.prefix :
                                                                  sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
    };

    ngOnInit() {
        this.actionType = this.adminService.actionType;
        this.getProjectPrefix();
    };
}
