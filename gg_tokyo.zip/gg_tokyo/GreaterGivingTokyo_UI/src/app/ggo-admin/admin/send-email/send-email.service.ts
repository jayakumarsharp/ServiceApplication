import { Injectable, EventEmitter } from '@angular/core';
import { Restangular } from 'ng2-restangular';


@Injectable()
export class SendEmailService {

    constructor(private restangular: Restangular) { }

    public actionType: string;
    public isToRedirectHome = new EventEmitter<boolean>();
    public emailMessage = {
        subject: '',
        message: ''
    };
    private headers = {'adminURL': true};

    public redirectToHome(isToRedirect) {
        this.isToRedirectHome.emit(isToRedirect);
    };

    public saveTemplate(projectPrefix, emailMessage) {
        let params = {};
        params['prefix'] = projectPrefix;
        let bodyParams = emailMessage;
        return this.restangular.oneUrl('/SaveEmailTemplate').post(undefined, bodyParams, params, this.headers);
    };

    public getSavedTemplates(projectPrefix) {
        let params = {};
        params['prefix'] = projectPrefix;
        return this.restangular.oneUrl('/GetEmailTemplates').get(params, this.headers);
    };

    public sendPreviewMessage(projectPrefix, emailMessage, recipientAddress) {
        let params = {};
        params['prefix'] = projectPrefix;
        let bodyParams = emailMessage;
        bodyParams['to'] = recipientAddress;
        return this.restangular.all('/SendPreviewEmail').customPUT(bodyParams, undefined,  params, this.headers);
    };

    public sendEmail(projectPrefix, emailMessage, recipientType) {
        let params = {};
        params['prefix'] = projectPrefix;
        params['recipientType'] = recipientType;
        let bodyParams = emailMessage;
        return this.restangular.all('/SendRegistrationEmail').customPUT(bodyParams, undefined,  params, this.headers);
    };

    public deleteTemplate(projectPrefix, emailTemplateId, projectId) {
        let params = {};
        params['prefix'] = projectPrefix;
        params['emailTemplateId'] = emailTemplateId;
        params['projectId'] = projectId;
        return this.restangular.oneUrl('/DeleteEmailTemplate').post(undefined, undefined, params, this.headers);
    };
}
