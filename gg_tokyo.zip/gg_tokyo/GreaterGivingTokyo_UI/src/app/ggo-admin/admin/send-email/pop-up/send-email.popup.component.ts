import { Component, OnInit } from '@angular/core';
import { DialogRef } from 'angular2-modal';
import { Router } from '@angular/router';

import { SendEmailService } from '../send-email.service';
import { AdminService } from '../../admin.service';
import { ggoAdminConstants } from '../../../ggo-admin.const';

@Component({
  selector: 'send-email-popup',
  templateUrl: './send-email-popup.component.html'
})
export class SendEmailPopupComponent implements OnInit {

    constructor(private dialog: DialogRef<any>,
                private router: Router,
                private sendEmailService: SendEmailService,
                private adminService: AdminService) {}

    public actionType: string;
    public ggoAdminConstants = ggoAdminConstants;
    public isEmailMessageValid: boolean = true;
    public recipientAddress: string;
    public showSuccessMsg: boolean = false;
    public showLoader: boolean = false;

    public onCancel() {
        this.dialog.close();
    };

    public setBusy() {
        this.showLoader = true;
    };

    public resetBusy() {
        this.showLoader = false;
    };

    public onReset() {
        this.isEmailMessageValid = true;
    };

    public onSendPreviewEmail() {
        let emailMessage = Object.assign({}, this.sendEmailService.emailMessage);
        emailMessage.message = emailMessage.message.replace(/(?:\r\n|\r|\n)/g, '<br />');
        this.setBusy();
        this.sendEmailService.sendPreviewMessage(this.adminService.prefix, emailMessage, this.recipientAddress).subscribe(
            res => {
                this.cbsOnSendPreviewEmail(res);
            },
            err => {

            }, () =>{
                this.resetBusy();
            }
        );
    };

    public cbsOnSendPreviewEmail(res) {
        if (res.message === 'Success') {
            this.showSuccessMsg = true;
        }
    };

    public onRecipientAddressChange() {
        this.isEmailMessageValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/g.test(this.recipientAddress);
    };

    public onNavigateToHome() {
        this.onCancel();
        setTimeout(() => {
            this.sendEmailService.redirectToHome(true);
        }, 1000);
    };

    ngOnInit() {
        this.actionType = this.sendEmailService.actionType;
    };
}
