import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ggoAdminConstants } from '../../ggo-admin.const';
import { Router } from '@angular/router';
import * as _ from 'lodash';

import { SendEmailPopupComponent } from './pop-up/send-email.popup.component';
import { SendEmailService } from './send-email.service';
import { AdminService } from '../admin.service';
import { AppService } from '../../../app.service';

@Component({
  selector: 'send-email-message',
  templateUrl: './send-email-message.component.html'
})
export class SendEmailMessageComponent implements OnInit {

    constructor(private overlay: Overlay,
                private sendEmailService: SendEmailService,
                private modal: Modal,
                private router: Router,
                private adminService: AdminService,
                private appService: AppService,
                private vcRef: ViewContainerRef) {
                    overlay.defaultViewContainer = vcRef;
                }

    public emailMessage = {
        subject: '',
        message: ''
    };
    public isSavedTemplate: boolean = false;
    public subjectMessageInvalid: boolean = false;
    public recipientType: string = 'All';
    public savedEmailTemplates = [];
    public ggoAdminConstants = ggoAdminConstants;
    public projectPrefix: string;

    public onSendEmail() {
        this.sendEmailService.actionType = ggoAdminConstants.ACTION_TYPES.SEND;
        let emailMessage = Object.assign({}, this.emailMessage);
        emailMessage.message = emailMessage.message.replace(/(?:\r\n|\r|\n)/g, '<br />');
        this.appService.setBusy();
        this.sendEmailService.sendEmail(this.projectPrefix, emailMessage, this.recipientType).subscribe(
            res => {
                this.cbsOnSendEmail(res);
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    public onSelectSavedMessage(emailTemplate) {
        this.isSavedTemplate = true;
        this.emailMessage.subject = emailTemplate.subject;
        this.emailMessage.message = emailTemplate.message;
    };

    public cbsOnSendEmail(res) {
        if (res.message === 'Success') {
            return this.modal.open(SendEmailPopupComponent, overlayConfigFactory({dialogClass: 'modal-configuration'}, BSModalContext));
        }
    };

    public onSubjectChange() {
        if (this.isSavedTemplate) {
            this.isSavedTemplate = false;
        }
        this.subjectMessageInvalid = /\[(.*?)\]/g.test(this.emailMessage.subject);
    };

    public onMessageChange() {
        if (this.isSavedTemplate) {
            this.isSavedTemplate = false;
        }
    };

    public cbsGetSavedTemplates(res) {
        this.savedEmailTemplates = res.plain();
        this.scrollSavedMessagesSection();
    };

    public scrollSavedMessagesSection() {
         let savedSectionElement = document.getElementById("scroll-section");
        setTimeout(() => {
            savedSectionElement.scrollTop = 0;
        });
    }
    public onSelectPreview() {
        this.sendEmailService.actionType = ggoAdminConstants.ACTION_TYPES.PREVIEW;
        this.sendEmailService.emailMessage = this.emailMessage;
        return this.modal.open(SendEmailPopupComponent, overlayConfigFactory({dialogClass: 'modal-configuration'}, BSModalContext));
    };

    public onCancelMessage() {
        this.sendEmailService.actionType = ggoAdminConstants.ACTION_TYPES.CANCEL;
        return this.modal.open(SendEmailPopupComponent, overlayConfigFactory({dialogClass: 'modal-configuration'}, BSModalContext));
    };

    public onDeleteTemplate(emailTemplateId, projectId) {
        this.appService.setBusy();
        this.sendEmailService.deleteTemplate(this.projectPrefix, emailTemplateId, projectId).subscribe(
            res => {
                this.cbsOnDeleteTemplate(res, emailTemplateId);
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    public cbsOnDeleteTemplate(res, emailTemplateId) {
        if (res.message === 'Success') {
            let deletedIndex = _.findIndex(this.savedEmailTemplates, {'emailtemplateid': emailTemplateId});
            this.savedEmailTemplates.splice(deletedIndex, 1);
        }
    };

    public onSaveTemplate() {
        this.appService.setBusy();
        this.sendEmailService.saveTemplate(this.projectPrefix, this.emailMessage).subscribe(
            res => {
                this.getSavedTemplates();
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    public getSavedTemplates() {
        this.sendEmailService.getSavedTemplates(this.projectPrefix).subscribe(
            res => {
                this.cbsGetSavedTemplates(res);
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    public getProjectPrefix() {
        this.projectPrefix = (this.adminService.prefix) ? this.adminService.prefix :
                                                          sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
    };

    public listenEvents() {
        this.sendEmailService.isToRedirectHome.subscribe((isToRedirect) => {
            this.adminService.routeToHome();
        });
    };

    ngOnInit() {
        this.appService.setBusy();
        this.getProjectPrefix();
        this.getSavedTemplates();
        this.listenEvents();
    };
}
