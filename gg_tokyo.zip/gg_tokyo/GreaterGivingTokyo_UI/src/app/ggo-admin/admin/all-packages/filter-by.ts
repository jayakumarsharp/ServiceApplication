export class FilterBy {
    public itemname: string;
    public itemnumber: string;
    public category: string;
    public nobids: boolean;
    public buynow: boolean;
    public preview: boolean;
    public multisale: boolean;
    public currentlyopen: boolean;

    constructor() {
        this.itemname = '';
        this.itemnumber = '';
        this.category = 'All';
        this.nobids = false;
        this.buynow = false;
        this.preview = false;
        this.multisale = false;
        this.currentlyopen = false;
    }
};
