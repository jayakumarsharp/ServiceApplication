import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import * as moment from 'moment';
import * as $ from 'jquery';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { FilterBy } from './filter-by';
import { CurrencyFilter } from './../../../common/currency-filter';
import { ggoAdminConstants } from './../../ggo-admin.const';
import { AdminService } from './../admin.service';
import { AppService } from '../../../app.service';
import { ClearMaxBidPopUpComponent } from '../clear-maxbid-pop-up/clear-maxbid-pop-up.component';

@Component({
  selector: 'all-packages',
  templateUrl: './packages.component.html',
  styleUrls: ['../../../../../node_modules/@progress/kendo-theme-default/dist/all.css']
})

export class PackagesComponent implements OnInit {

    constructor(private currencyFilter: CurrencyFilter,
                private modal: Modal,
                private overlay: Overlay,
                private vcRef: ViewContainerRef,
                private adminService: AdminService,
                private appService: AppService) {
                    overlay.defaultViewContainer = vcRef;
                }

    public projectPrefix: string;
    public packages = [];
    public categories = [];
    public sort: SortDescriptor[] = [];
    public filterBy = new FilterBy();
    public itemType = 'regular';
    public category =  this.filterBy.category;
    public gridHeight = 0;
    public ggoAdminConstants = ggoAdminConstants;
    public colNamesProperty = {
        1: {
            colName: 'Pkg #',
            fieldName: 'itemnumber',
        },
        2: {
            colName: 'Package Name',
            fieldName: 'itemname',
        },
        3: {
            colName: 'Opening',
            fieldName: 'startingtime',
            type: 'Date'
        },
        4: {
            colName: 'Closing',
            fieldName: 'closingtime',
            type: 'Date'
        },
        5: {
            colName: 'Status',
            fieldName: 'status',
        },
        6: {
            colName: 'Min Bid',
            fieldName: 'startingbid',
            type: 'Amount'
        },
        7: {
            colName: 'Min Raise',
            fieldName: 'minimumbid',
            type: 'Amount'
        },
        8: {
            colName: 'Price',
            fieldName: 'buynow',
            type: 'Amount'
        },
        9: {
            colName: 'Amount',
            fieldName: 'bid',
            type: 'Amount'
        },
        10: {
            colName: 'Max Bid',
            fieldName: 'maxbid',
            type: 'Amount'
        }
    };

    public onFilterPackages() {
        this.category =  this.filterBy.category;
        this.getPackagesByFilterBy();
    };

    public onResetFilter() {
        this.filterBy = new FilterBy();
        this.category =  this.filterBy.category;
        this.getPackagesByFilterBy();
    };

    public onRemoveAllBids() {
        this.adminService.actionType = ggoAdminConstants.REMOVE_ACTION_TYPE.ALL_BID;
        return this.modal.open(ClearMaxBidPopUpComponent, overlayConfigFactory({dialogClass: 'clear-bid-modal'}, BSModalContext));
    }; 

    public sortChange(sort: SortDescriptor[]) {
        this.sort = sort;
        $('td').css({'background': 'white'});
        this.loadProducts();
        setTimeout(() => {
            $('.sorted-col').parent('td').css({'background': '#E8ECF0'});
        });
    };

    public routeToPackageInfo(packageId) {
        this.adminService.routeToPackageInfo(packageId);
    };

    private defaultSorting() {
        this.sort = [];
        this.sort.push({
            dir: 'asc',
            field:  this.colNamesProperty[1].fieldName
        });
        setTimeout(() => $('.sorted-col').parent('td').css({'background': '#E8ECF0'}));
    };

    private loadProducts() {
        if (this.sort[0].field === 'itemnumber') {
            this.packages = this.adminService.alphaNumericSorting(this.packages, 'itemnumber');
            if (this.sort[0].dir === 'desc') {
                this.packages.reverse();
            }
        } else {
            this.packages = orderBy(this.packages, this.sort);
        }
    };

    private getAmountValue(bidValue) {
        if (bidValue === -1) {
            bidValue = '';
            return;
        }
        return bidValue ? '$'+(this.currencyFilter.transform(bidValue)) : '- -';
    };

    public onExportGrid() {
        let data = [];
        let packagesCopy = Object.assign(this.packages, []);
        packagesCopy.forEach((item) => {
            let updatedItem = {};
            Object.keys(this.colNamesProperty).map(key => {
                let colNameProperty = this.colNamesProperty[key];
                let fieldName = colNameProperty.fieldName;
                let value = item[fieldName];
                let colName = colNameProperty.colName;
                if (colNameProperty.type) {
                    if (colNameProperty.type === 'Date') {
                        if (!item.isdeleted) {
                             value = (value) ? this.appService.convertTimeByTimeZone(value, this.adminService.projectInfo.timezone)
                                                              .format(ggoAdminConstants.DATE_TIME_FORMATS.DATE_WITHOUT_YEAR) : value;
                        } else {
                            value = '--';
                        }
                    }
                    if (colNameProperty.type === 'Amount') {
                        value = (!!value) ? '$'+(this.currencyFilter.transform(value)) : (value === null) ? '- -' : ''
                    }
                }
                updatedItem[colName] = value;
            });
            data.push(updatedItem);
        });
        this.adminService.exportAsExcelFile(data, 'All-Packages');
    };

    private getPackagesByFilterBy() {
        this.appService.setBusy();
        this.adminService.getAllPackages(this.projectPrefix, this.filterBy).subscribe(
            res => {
                this.cbsGetPackagesByFilterBy(res);
            },
            err => {
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private cbsGetPackagesByFilterBy(res) {
        this.packages = res.plain();
        this.defaultSorting();
        this.setGridHeight();
    };

    private getAllPackages() {
        this.getPackagesByFilterBy();
    };

    private listenEvents() {
        this.adminService.isAllBidRemoved.subscribe(isAllBidRemoved => {
            this.getAllPackages();
        });
    };

    private getCategories() {
        this.adminService.getCategoryTypesByProject(this.projectPrefix).subscribe(
            res => {
                this.categories = res.plain();
            },
            err => {}
        );
    };

    private getProjectPrefix() {
        this.projectPrefix = this.projectPrefix = (this.adminService.prefix) ? this.adminService.prefix :
                                                                  sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
        this.getAllPackages();
        this.getCategories();
    };

    private setGridHeight() {
        let previousScrollPosition = ($('.k-grid-content')[0]) ? $('.k-grid-content')[0].scrollTop : 0;
        this.gridHeight = this.adminService.getGridHeight();
        if (previousScrollPosition === 0) {
            previousScrollPosition = 10;
        }
        $('.k-grid-content').scrollTop( previousScrollPosition - 1);
    };

    private onBrowserResize() {
        window.onresize = () => {
            this.setGridHeight();
        };
    };

    ngOnInit() {
        this.getProjectPrefix();
        this.onBrowserResize();
        this.listenEvents();
    };
};
