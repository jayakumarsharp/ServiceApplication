import { Component, OnInit, ViewContainerRef } from '@angular/core';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import * as $ from 'jquery';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import * as _ from 'lodash';

import { AdminService } from './../admin.service';
import { CurrencyFilter } from './../../../common/currency-filter';
import { AppService } from '../../../app.service';
import { ggoAdminConstants } from './../../ggo-admin.const';
import { ClearMaxBidPopUpComponent } from '../clear-maxbid-pop-up/clear-maxbid-pop-up.component'

@Component({
    selector: 'bidder-detail',
    templateUrl: 'bidder-detail.component.html',
    styleUrls: ['../../../../../node_modules/@progress/kendo-theme-default/dist/all.css']
})
export class BidderDetailComponent implements OnInit {

    constructor(private activatedRoute: ActivatedRoute,
                private adminService: AdminService,
                private modal: Modal,
                private overlay: Overlay,
                private vcRef: ViewContainerRef,
                private currencyFilter: CurrencyFilter,
                private appService: AppService) {
                    overlay.defaultViewContainer = vcRef;
                }

    public projectPrefix: string;
    public bidderId: number;
    public bidsHistory = [];
    public bidderDetails = [];
    public maxBids = [];
    public gridHeight = 0;
    public sort: SortDescriptor[] = [];
    public ggoAdminConstants = ggoAdminConstants;
    public titleFieldIndexObject = {
        1: {
            title: 'Date & Time',
            fieldName: 'createdDate',
            type: 'Date'
        },
        2: {
            title: 'Package Name',
            fieldName: 'itemname',
        },
        3: {
            title: 'Package #',
            fieldName: 'number',
        },
        4: {
            title: 'Amount',
            fieldName: 'amount',
            type: 'Amount'
        },
        5: {
            title: 'Remove',
            colName: 'Removed',
            fieldName: 'isdeleted',
            type: 'Boolean'
        }
    };

    public sortChange(sort: SortDescriptor[]): void {
        this.sort = sort;
        $('td').css({'background': 'white'});
        this.loadProducts();
        setTimeout(() => {
            $('.sorted-col').parent('td').css({'background': '#E8ECF0'});
        });
    };

    private loadProducts() {
        if (this.sort[0].field === 'number') {
            this.bidsHistory = this.adminService.alphaNumericSorting(this.bidsHistory, 'number');
            if (this.sort[0].dir === 'desc') {
                this.bidsHistory.reverse();
            }
        } else {
            this.bidsHistory = orderBy(this.bidsHistory, this.sort);
        }
    };

    public onViewAllBidders() {
        this.adminService.routeToAllBidders();
    };

    public routeToPackgeInfo(packageId) {
        this.adminService.routeToPackageInfo(packageId);
    };

    public onExportGrid() {
        let data = [];
        this.bidsHistory.forEach((item) => {
            let updatedItem = {};
            Object.keys(this.titleFieldIndexObject).map(key => {
                let titleFieldObject = this.titleFieldIndexObject[key];
                let fieldName = titleFieldObject.fieldName;
                let value = item[fieldName];
                let title = titleFieldObject.title;
                if (titleFieldObject.colName) {
                    title = titleFieldObject.colName;
                }
                if (titleFieldObject.type) {
                    if (titleFieldObject.type === 'Boolean') {
                        value = value ? 'Yes' : 'No';
                    }
                    if (titleFieldObject.type === 'Amount') {
                        value = '$' +(this.currencyFilter.transform(value));
                    }
                    if (titleFieldObject.type === 'Date') {
                        value = (value) ? this.appService.convertTimeByTimeZone(value, this.adminService.projectInfo.timezone)
                                                         .format(ggoAdminConstants.DATE_TIME_FORMATS.DATE_WITHOUT_YEAR) : value;
                    }
                }
                updatedItem[title] = value;
            });
            data.push(updatedItem);
        });
        this.adminService.exportAsExcelFile(data, 'Bidder-Details');
    };

    private getBidsHistorybyBidderId() {
        this.adminService.getBidsHistorybyBidderId(this.bidderId, this.projectPrefix).subscribe(
            res => {
                this.bidsHistory = res.plain();
                this.setDefaultSorting();
                this.setGridHeight();
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private setDefaultSorting() {
        this.sort = [];
        this.sort.push({
            dir: 'asc',
            field:  this.titleFieldIndexObject[1].fieldName
        });
        setTimeout(() => $('.sorted-col').parent('td').css({'background': '#E8ECF0'}));
    };

    public onConfirmDelete(packageId) {
        this.adminService.actionType = ggoAdminConstants.REMOVE_ACTION_TYPE.MAX_BID;
        this.adminService.packageId = packageId;
        return this.modal.open(ClearMaxBidPopUpComponent, overlayConfigFactory({dialogClass: 'clear-bid-modal'}, BSModalContext));
    };

    public onRemoveBid(bidId, saleId) {
        this.adminService.bidId = bidId;
        this.adminService.saleId = saleId;
        this.adminService.actionType = ggoAdminConstants.REMOVE_ACTION_TYPE.BID;
        return this.modal.open(ClearMaxBidPopUpComponent, overlayConfigFactory({dialogClass: 'clear-bid-modal'}, BSModalContext));
    };

    private listenEvents() {
        this.adminService.isMaxBidCleared.subscribe(isMaxBidCleared => {
            let indexToBeSpliced: number = _.findIndex(this.maxBids, {'packageid': this.adminService.packageId});
            this.maxBids.splice(indexToBeSpliced, 1);
        });

        this.adminService.isBidRemoved.subscribe(isBidRemoved => {
            this.bidsHistory.forEach((bid) => {
                if (bid.bidxid === this.adminService.bidId && bid.saleid === this.adminService.saleId) {
                    bid.isdeleted = true;
                    return;
                }
            });
        });
    };

    private getMaxBidsbyBidderId() {
        this.adminService.getMaxBidsbyBidderId(this.bidderId, this.projectPrefix).subscribe(
            res => {
                this.maxBids = res.plain();
            },
            err => {

            }
        );
    };

    private getBidderDetailsByBidderId() {
        this.adminService.getBidderDetailsByBidderId(this.bidderId, this.projectPrefix).subscribe(
            res => {
                this.bidderDetails = res.plain();
            },
            err => {

            }
        );
    };

    private getBidderKeyFromRoute() {
        this.bidderId = this.activatedRoute.snapshot.params['id'];
    };

    private getProjectPrefix() {
        this.projectPrefix = this.projectPrefix = (this.adminService.prefix) ? this.adminService.prefix :
                                                  sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
    };

    private setGridHeight() {
        let previousScrollPosition = ($('.k-grid-content')[0]) ? $('.k-grid-content')[0].scrollTop : 0;
        this.gridHeight = this.adminService.getGridHeight();
        if (previousScrollPosition === 0) {
            previousScrollPosition = 10;
        }
        $('.k-grid-content').scrollTop( previousScrollPosition - 1);
    };

    private onBrowserResize() {
        window.onresize = () => {
            this.setGridHeight();
        };
    };

    ngOnInit() {
        this.appService.setBusy();
        this.getProjectPrefix();
        this.getBidderKeyFromRoute();
        this.getBidsHistorybyBidderId();
        this.getMaxBidsbyBidderId();
        this.getBidderDetailsByBidderId();
        this.listenEvents();
        this.onBrowserResize();
    };
}
