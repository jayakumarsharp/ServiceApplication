import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { GridModule } from '@progress/kendo-angular-grid';
import { PerfectScrollbarModule } from 'angular2-perfect-scrollbar';
import { MaskedTextBoxModule } from '@progress/kendo-angular-inputs';

import { appRoutes } from './../../app.routing';
import { AppCommonModule } from './../../common/common-module';
import { CurrencyFilter } from './../../common/currency-filter';
import { AdminComponent } from './admin.component';
import { AdminService } from './admin.service';
import { AdminAuthComponent } from './authentication/authentication.component';
import { HomeComponent } from './home/home.component';
import { AdminSlideOutMenuComponent } from './slide-out-menu/slide-out-menu.component';
import { AdminSlideOutMenuService } from './slide-out-menu/slide-out-menu.service';
import { BiddersComponent } from './all-bidders/all-bidders.component';
import { PackagesComponent } from './all-packages/packages.component';
import { BidderDetailComponent } from './bidder-detail/bidder-detail.component';
import { PackageInfoComponent } from './package-info/package-info.component';
import { AdminLogoutComponent } from './logout/logout.component';
import { TimezoneConverterDirective } from '../common/timezone-converter.directive';
import { ClearMaxBidPopUpComponent } from './clear-maxbid-pop-up/clear-maxbid-pop-up.component'
import { SendEmailMessageComponent } from './send-email/send-email-message.component';
import { SendEmailPopupComponent } from './send-email/pop-up/send-email.popup.component';
import { SendSmsMessageComponent } from './send-sms/send-sms-message.component';
import { SendSmsPopupComponent } from './send-sms/pop-up/send-sms.popup.component';
import { SendEmailService } from './send-email/send-email.service';
import { ReportComponent } from './report/report.component';
import { SendSmsService } from './send-sms/send-sms.service';
import { EllipseDirective } from '../../common/ellipse.directive';
import { SpinnerLoaderComponent } from '../../common/spinner-loader/spinner-loader.component';

@NgModule({
    imports: [
        CommonModule,
        BrowserModule,
        RouterModule.forRoot(appRoutes),
        PerfectScrollbarModule.forRoot(),
        GridModule,
        AppCommonModule,
        MaskedTextBoxModule,
        FormsModule,
        AppCommonModule
    ],
    declarations: [
        AdminComponent,
        TimezoneConverterDirective,
        ReportComponent,
        AdminSlideOutMenuComponent,
        AdminAuthComponent,
        AdminLogoutComponent,
        BiddersComponent,
        ClearMaxBidPopUpComponent,
        HomeComponent,
        PackagesComponent,
        BidderDetailComponent,
        SendEmailMessageComponent,
        SendSmsPopupComponent,
        SendSmsMessageComponent,
        SendEmailPopupComponent,
        PackageInfoComponent,
    ],
    providers: [
        AdminSlideOutMenuService,
        AdminService,
        CurrencyFilter,
        SendEmailService,
        SendSmsService,
        SpinnerLoaderComponent
    ],
    entryComponents: [
        SendEmailPopupComponent,
        ClearMaxBidPopUpComponent,
        SendSmsPopupComponent
    ]
})
export class AdminModule { }
