import { Component, OnInit, ViewContainerRef } from '@angular/core';
import * as moment from 'moment';
import { ActivatedRoute} from '@angular/router';
import { SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import * as $ from 'jquery';
import * as _ from 'lodash';

import { CurrencyFilter } from './../../../common/currency-filter';
import { AdminService } from './../admin.service';
import { AppService } from '../../../app.service';
import { ggoAdminConstants } from './../../ggo-admin.const';
import { ClearMaxBidPopUpComponent } from '../clear-maxbid-pop-up/clear-maxbid-pop-up.component'

@Component({
    selector: 'package-info',
    templateUrl: 'package-info.component.html',
    styleUrls: ['../../../../../node_modules/@progress/kendo-theme-default/dist/all.css']
})
export class PackageInfoComponent implements OnInit {

    constructor(private activatedRoute: ActivatedRoute,
                private currencyFilter: CurrencyFilter,
                private modal: Modal,
                private overlay: Overlay,
                private vcRef: ViewContainerRef,
                private adminService: AdminService,
                private appService: AppService) {
                    overlay.defaultViewContainer = vcRef;
                }

    public projectPrefix: string;
    public packageId: number;
    private sort: SortDescriptor[] = [];
    public bidsHistory = [];
    public packageDetail;
    public gridHeight = 0;
    public maxBid = {};
    public ggoAdminConstants = ggoAdminConstants;
    public itemType = {
        regular: 'Regular',
        multisale: 'Givers',
        donation: 'Donation',
        appeal: 'Appeal'
    };
    public titleFieldIndexObject = {
        1: {
            title: 'Date & Time',
            fieldName: 'createdDate',
            type: 'Date'
        },
        2: {
            title: 'Bidder Name',
            fieldName: 'itemname',
        },
        3: {
            title: 'Bidder #',
            fieldName: 'number',
            type: 'Number'
        },
        4: {
            title: {
                'Regular': 'Bid',
                'Givers' : 'Sale',
                'Donation' : 'Donated'
            },
            fieldName: 'amount',
            type: 'Amount'
        },
        5: {
            title: 'Remove',
            colName: 'Removed',
            fieldName: 'isdeleted',
            type: 'Boolean'
        }
    };

    public sortChange(sort: SortDescriptor[]): void {
        this.sort = sort;
        $('td').css({'background': 'white'});
        this.loadProducts();
        setTimeout(() => {
            $('.sorted-col').parent('td').css({'background': '#E8ECF0'});
        });
    };

    private loadProducts() {
        this.bidsHistory = orderBy(this.bidsHistory, this.sort);
    };

    public onViewAllPackages() {
        this.adminService.routeToAllPackages();
    };

    public routeToBidderDetail(bidderId) {
        this.adminService.routeToBidderDetail(bidderId);
    };

    public onExportGrid() {
        let data = [];
        this.bidsHistory.forEach((item) => {
            let updatedItem = {};
            Object.keys(this.titleFieldIndexObject).map(key => {
                let titleFieldObject = this.titleFieldIndexObject[key];
                let fieldName = titleFieldObject.fieldName;
                let value = item[fieldName];
                let title = titleFieldObject.title;
                if (titleFieldObject.colName) {
                    title = titleFieldObject.colName;
                }
                if (typeof title === 'object' ) {
                    title = title[this.packageDetail.itemtype];
                }
                if (titleFieldObject.type) {
                    if (titleFieldObject.type === 'Boolean') {
                        value = value ? 'Yes' : 'No';
                    }
                    if (titleFieldObject.type === 'Date') {
                        value = (value) ? this.appService.convertTimeByTimeZone(value, this.adminService.projectInfo.timezone)
                                                         .format(ggoAdminConstants.DATE_TIME_FORMATS.DATE_WITH_YEAR) : value;
                    }
                    if (titleFieldObject.type === 'Amount') {
                        value = '$' +(this.currencyFilter.transform(value));
                    }
                    if (titleFieldObject.type === 'Number') {
                        value = (value !== '0') ? (value) : ' ';
                    }
                }
                updatedItem[title] = value;
            });
            data.push(updatedItem);
        });
        this.adminService.exportAsExcelFile(data, 'Packages-Info');
    };

    private getBidsHistory() {
        this.adminService.getBidsHistory(this.projectPrefix, this.packageId).subscribe(
            res => {
                this.cbsGetBidsHistory(res);
            },
            err => {

            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private cbsGetBidsHistory(res) {
        this.bidsHistory = res.plain();
        this.setDefaultSort();
        this.setGridHeight();
    };

    public setDefaultSort() {
        this.sort = [];
        this.sort.push({
            dir: 'desc',
            field:  this.titleFieldIndexObject[1].fieldName
        });
        setTimeout(() => $('.sorted-col').parent('td').css({'background': '#E8ECF0'}));
    };

    public onConfirmDelete(packageId) {
        this.adminService.actionType = ggoAdminConstants.REMOVE_ACTION_TYPE.MAX_BID;
        this.adminService.packageId = packageId;
        return this.modal.open(ClearMaxBidPopUpComponent, overlayConfigFactory({dialogClass: 'clear-bid-modal'}, BSModalContext));
    };

    public onRemoveBid(bidId, saleId) {
        this.adminService.bidId = bidId;
        this.adminService.saleId = saleId;
        this.adminService.actionType = ggoAdminConstants.REMOVE_ACTION_TYPE.BID;
        return this.modal.open(ClearMaxBidPopUpComponent, overlayConfigFactory({dialogClass: 'clear-bid-modal'}, BSModalContext));
    };

    private getPackageMaxBids() {
        this.adminService.getMaxBidsForPackage(this.projectPrefix, this.packageId).subscribe(
            res => {
                this.maxBid = res.plain();
            },
            err => {

            }
        );
    };

    private getPackageDetail() {
        this.adminService.getPackageDetail(this.projectPrefix, this.packageId).subscribe(
            res => {
                this.cbsGetPackageDetail(res);
            },
            err => {

            }
        );
    };

    private cbsGetPackageDetail(res: any) {
        this.packageDetail = res.plain();
    };

    private getPackageIdFromRoute() {
        this.packageId = this.activatedRoute.snapshot.params['id'];
    };

    private getProjectPrefix() {
        this.projectPrefix = (this.adminService.prefix) ? this.adminService.prefix :
                                                                  sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.PREFIX);
    };

    private setGridHeight() {
        let previousScrollPosition = ($('.k-grid-content')[0]) ? $('.k-grid-content')[0].scrollTop : 0;
        this.gridHeight = this.adminService.getGridHeight();
        if (previousScrollPosition === 0) {
            previousScrollPosition = 10;
        }
        $('.k-grid-content').scrollTop( previousScrollPosition - 1);
    };

    private onBrowserResize() {
        window.onresize = () => {
            this.setGridHeight();
        };
    };

    private listenEvents() {
        this.adminService.isMaxBidCleared.subscribe(isMaxBidCleared => {
            this.maxBid = {};
        });

        this.adminService.isBidRemoved.subscribe(isBidRemoved => {
            this.bidsHistory.forEach((bid) => {
                if (bid.bidxid === this.adminService.bidId && bid.saleid === this.adminService.saleId) {
                    bid.isdeleted = true;
                    return;
                }
            });
        });
    };

    ngOnInit() {
        this.appService.setBusy();
        this.getProjectPrefix();
        this.getPackageIdFromRoute();
        this.getPackageDetail();
        this.getBidsHistory();
        this.listenEvents();
        this.getPackageMaxBids();
        this.onBrowserResize();
    };
}
