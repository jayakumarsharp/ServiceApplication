import { Injectable, EventEmitter } from '@angular/core';
import { Restangular } from 'ng2-restangular';
import * as _ from 'lodash';

import { Config } from './config';

@Injectable()
export class AppealBoardService {

    constructor(private restangular: Restangular) { }
    public config = new Config();
    public isConfigurationUpdated = new EventEmitter<Object>();
    public projectInfo = {
        leaderboard_theme: 'Blue',
        slug: '',
        display_loop_time: 0,
        showthanks: false
    };

    public getDefaultConfig() {
        if ((!localStorage.length) || (!localStorage.appeal)) {
            return this.getDefaultsetting();
        }
        var storage = JSON.parse(localStorage.appeal);
        let config = new Config();
        for (let key in config) {
            config[key] = storage[key];
        }
        return config;
    };

    public getDefaultsetting() {
        let config = new Config();
        config.showdonors = this.projectInfo.showthanks;
        config.sponsorRefresh = this.projectInfo.display_loop_time ? this.projectInfo.display_loop_time : 10;
        config.backgroundcolor = this.projectInfo.leaderboard_theme ? this.projectInfo.leaderboard_theme : 'blue';
        config.progresscolor = this.projectInfo.leaderboard_theme ? this.projectInfo.leaderboard_theme : 'blue';
        config.backgroundcolor = _.capitalize(config.backgroundcolor);
        localStorage.removeItem('appeal');
        return config;
    }

    public setConfiguration(updatedConfigurationValues) {
        localStorage.setItem("appeal", JSON.stringify(updatedConfigurationValues));
        this.isConfigurationUpdated.emit(updatedConfigurationValues);
    };

    public getAppealPackage(projectName) {
        let params = { 'prefix': projectName };
        return this.restangular.oneUrl('/GetAppealDonationPackage').get(params);
    };
}
