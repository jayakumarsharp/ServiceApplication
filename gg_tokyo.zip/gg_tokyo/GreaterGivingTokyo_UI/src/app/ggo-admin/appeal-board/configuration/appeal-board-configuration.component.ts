import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { DialogRef } from 'angular2-modal';
import * as _ from 'lodash';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { FormsModule, NgForm }   from '@angular/forms';

import { AppealBoardService } from '../appeal-board.service';
import { Config } from '../config';
import { ggoAdminConstants } from '../../ggo-admin.const';
import { GgoAdminService } from '../../ggo-admin.service';


@Component({
    templateUrl: 'appeal-board-configuration.component.html',
})

export class AppealBoardConfigurationComponent implements OnInit{

    public ggoAdminConstants = ggoAdminConstants;
    public sponsorRefreshRate =  [];
    public gauges = Object.keys(ggoAdminConstants.GAUGES_WITH_DISPLAYNAME).map(k =>ggoAdminConstants.GAUGES_WITH_DISPLAYNAME[k]);
    public config = new Config();

    @ViewChild('form')
    public configForm: NgForm;

    constructor(private dialog: DialogRef<any>,
                private appealBoardService: AppealBoardService,
                private ggoAdminService: GgoAdminService) { }

    public onCancel() {
        this.dialog.close();
    };

    public onSubmit() {
        this.appealBoardService.setConfiguration(this.configForm.value);
        this.dialog.close();
    };

    public onReset() {
        let config =  new Config();
        config = this.appealBoardService.getDefaultConfig();
        this.configForm.form.patchValue(config);
    };

    public onDefault() {
        let config = new Config();
        config = this.appealBoardService.getDefaultsetting();
        this.configForm.form.patchValue(config);
    };

    public setDropDownValues() {
        this.sponsorRefreshRate = this.ggoAdminService.generateValues(1, 99);
    };

    ngOnInit() {
        this.config = this.appealBoardService.config;
        this.setDropDownValues();
    };
    
}
