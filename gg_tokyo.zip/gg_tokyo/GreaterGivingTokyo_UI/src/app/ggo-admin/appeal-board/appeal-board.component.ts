import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { SignalR} from 'ng2-signalr';
import { ToasterService } from 'angular2-toaster';
import * as _ from 'lodash';
import { AppealBoardService } from './appeal-board.service';
import { AppService } from '../../app.service';
import { AppealBoardConfigurationComponent } from './configuration/appeal-board-configuration.component';
import { biddingAppConstants } from '../../bidding/bidding-app.const';
import { biddingErrorConstants } from '../../bidding/bidding-app.error.const';
import { Config } from './config';
import { ErrorHandlerService } from '../../bidding/error-handler/error-handler.service';
import { ggoAdminConstants } from '../ggo-admin.const';
import { GgoAdminService } from '../ggo-admin.service';

@Component({
  selector: 'appeal-board',
  templateUrl: './appeal-board.component.html',
})
export class AppealBoardComponent implements OnInit {
    constructor(private activatedRoute: ActivatedRoute,
                private router: Router,
                private toasterService: ToasterService,
                private modal: Modal,
                private signalR: SignalR,
                private appService: AppService,
                private errorHandlerService: ErrorHandlerService,
                private overlay: Overlay,
                private appealBoardService: AppealBoardService,
                private ggoAdminService: GgoAdminService,
                private vcRef: ViewContainerRef) {
                    overlay.defaultViewContainer = vcRef;
                }

    public ggoAdminConstants = ggoAdminConstants;
    public showSponser: boolean = true;

    public sponsors = [];
    public projectPrefix;
    public projectInfo = this.appealBoardService.projectInfo;
    public startSponsorsTransistion = false;
    public metaphor: string = 'Bar';
    public showMetaphor: boolean = true;
    public showDonors: boolean = true;
    public showDonationAmount: boolean = false;
    public config = new Config();
    public appealPackage = {
        totalraised : 0,
        appealgoal: 0,
        appeal_logo_path: {},
    };
    public progressGraphicHeight: string = '0px';
    public donor;
    public donors = new Array();
    public showDonorsAlert = false;
    private isDonorsAlertTimerStarted = false;
    private sponorsDisplayIntervalInst;

    public onAppealConfigure() {
        this.appealBoardService.config = this.config;
        return this.modal.open(AppealBoardConfigurationComponent, overlayConfigFactory({dialogClass: 'modal-configuration'}, BSModalContext));
    };

    private getProject() {
      
        this.appService.setBusy();
        this.ggoAdminService.getProject(this.appealBoardService.projectInfo.slug).subscribe(
            res => {
                this.appealBoardService.projectInfo = res.plain();
                this.projectInfo = this.appealBoardService.projectInfo;
                this.config = this.appealBoardService.getDefaultConfig();
            },
            err => {
                this.routeToErrorPage();
            }
        );
    };

    private routeToErrorPage() {
        this.errorHandlerService.errorMessage = biddingErrorConstants.PROJECT_ID_NOT_FOUND;
        this.router.navigateByUrl('bidding/error');
    };

    private getAppealPackage() {
        this.appealBoardService.getAppealPackage(this.appealBoardService.projectInfo.slug).subscribe(
            res => {
                this.appealPackage = res.plain();
                this.setProgressBarHeight();
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private setProgressBarHeight() {
        let progressGraphicHeight = (this.appealPackage.totalraised / this.appealPackage.appealgoal) * 100;
        this.progressGraphicHeight = progressGraphicHeight + '%';
    };

    private getSponsors() {
        this.ggoAdminService.getSponsors(this.appealBoardService.projectInfo.slug).subscribe(
            res => {
                this.cbsGetSponsors(res);
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        )
    };

    public cbsGetSponsors(res) {
        this.sponsors = _.filter(res.plain(), function(sponsor: any) { return sponsor.imgpath !== null ;});
    };

    private showDonor(donor) {
        if (!this.showDonorsAlert) {
            this.donor = donor;
            this.showDonorsAlert = true;
        }
        this.donors.push(donor);
        if (!this.isDonorsAlertTimerStarted) {
            this.startDisplayDonors();
        }
    };
  
    private startDisplayDonors() {
        this.isDonorsAlertTimerStarted = true;
        let donorAlertTimer = setInterval(() => {
            this.setNextDonorInfo(donorAlertTimer);
        }, ggoAdminConstants.APPEAL_BOARD_DONORS_ALERT_DURATION);
    };

    private setNextDonorInfo(donorAlertTimer) {
        if (this.donors.length === 1) {
            this.donors = new Array();
            this.stopDisplayDonors(donorAlertTimer);
            this.showDonorsAlert = false;
        } else {
            this.donor = this.donors.splice(0, 1);
            this.donor = this.donors[0];
            this.showDonorsAlert = true;
        }
    };

    private stopDisplayDonors(donorAlertTimer) {
        this.isDonorsAlertTimerStarted = false;
        clearInterval(donorAlertTimer);
    };

    private connectSignalR() {
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatedBidderForAppealDonationPackage').subscribe((appealInfo: any) => {
                if (this.appealBoardService.projectInfo.slug === appealInfo.prefix) {
                    this.showDonor(appealInfo.bidderdetails);
                }
            });
        });

        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatedAppealDonationPackages').subscribe((updatedAppealPackagePrefix) => {
                if (this.appealBoardService.projectInfo.slug === updatedAppealPackagePrefix) {
                    this.getAppealPackage();
                }
            });
        });

        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdateProject').subscribe((updatedAppealPackagePrefix) => {
                if (this.appealBoardService.projectInfo.slug === updatedAppealPackagePrefix) {
                    this.getAppealPackage();
                }
            });
        });
    };

    public listenEvents() {
        this.appealBoardService.isConfigurationUpdated.subscribe(
            updatedConfigurationValues => {
                this.config = updatedConfigurationValues;
            }
        );
    };

    public getProjectPrefix() {
        let url = window.location.href;
        this.appealBoardService.projectInfo.slug = url.slice(url.indexOf('//') + 2, url.indexOf('.'));
    };

    ngOnInit() {
        this.getProjectPrefix();
        this.getProject();
        this.getAppealPackage();
        this.getSponsors();
        this.listenEvents();
        this.connectSignalR();
    };
}
