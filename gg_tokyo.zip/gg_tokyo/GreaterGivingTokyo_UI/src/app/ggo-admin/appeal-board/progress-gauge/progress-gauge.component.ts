import { Component, Input, OnInit, OnChanges } from '@angular/core';

import { ggoAdminConstants } from './../../ggo-admin.const';

@Component({
    selector: 'progress-gauge',
    templateUrl: 'progress-gauge.component.html',
})
export class ProgressGaugeComponent implements OnInit, OnChanges {

    public metaphors = ggoAdminConstants.GAUGES_WITH_DISPLAYNAME;
    public progresscolor;
    @Input() public progressGraphicHeight;
    @Input() public gauageType;
    @Input() public background;

    ngOnInit() {
       this.progresscolor = ggoAdminConstants.GAUGES_COLOR_FOR_THEME[this.background.toLowerCase()];
    };

    ngOnChanges() {
       this.progresscolor = ggoAdminConstants.GAUGES_COLOR_FOR_THEME[this.background.toLowerCase()];
    };
}
