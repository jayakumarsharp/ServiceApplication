export class Config {
    public showdonors: boolean;
    public showdonationamount: boolean;
    public showsponsors: boolean;
    public sponsorRefresh: number;
    public gauge: string;
    public showgauge: boolean;
    public showdonationgoal: boolean;
    public backgroundcolor: string;
    public progresscolor: string;

    constructor() {
        this.showdonors = true,
        this.showdonationamount = false,
        this.showsponsors = true,
        this.showgauge = true,
        this.showdonationgoal = true,
        this.gauge = 'Bar',
        this.backgroundcolor = '',
        this.progresscolor = '',
        this.showsponsors = true,
        this.sponsorRefresh = 10
    }
};
