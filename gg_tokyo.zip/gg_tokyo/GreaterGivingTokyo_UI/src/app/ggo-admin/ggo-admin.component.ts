import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ggo-admin-root',
  templateUrl: './ggo-admin.component.html',
})
export class GGOAdminComponent implements OnInit {

    constructor() { }

    ngOnInit() {}

}
