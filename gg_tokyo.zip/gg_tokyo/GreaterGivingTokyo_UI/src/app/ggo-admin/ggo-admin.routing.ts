import { Routes } from '@angular/router';

import { AppealBoardComponent } from './appeal-board/appeal-board.component';

export const ggoAdminRouting: Routes = [
    { path: 'leader-board', component: AppealBoardComponent }
  ];
