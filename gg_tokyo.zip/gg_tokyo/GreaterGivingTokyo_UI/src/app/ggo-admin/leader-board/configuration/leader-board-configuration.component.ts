import { Component, ViewChild } from '@angular/core';
import { FormsModule, NgForm }   from '@angular/forms';
import { DialogRef } from 'angular2-modal';
import * as _ from 'lodash';
import { ToasterService } from 'angular2-toaster';

import { ggoAdminConstants } from '../../ggo-admin.const';
import { Config } from '../config';
import { biddingErrorConstants } from '../../../bidding/bidding-app.error.const';
import { GgoAdminService } from '../../ggo-admin.service';
import { LeaderBoardService } from '../leader-board.service';

@Component({
    templateUrl: 'leader-board-configuration.component.html',
})

export class LeaderBoardConfigurationComponent {

    constructor(private leaderBoardService: LeaderBoardService,
                private toasterService: ToasterService,
                private dialog: DialogRef<any>,
                private ggoAdminService: GgoAdminService
                ) {}

    public ggoAdminConstants = ggoAdminConstants;
    public config = new Config();
    public packageTypes = ['Open(No Bid)', 'Open', 'Sold', 'All', 'Buy', 'Multisale', 'Preview'];
    public categoryTypes;
    public sortOrderTypes = ['Package Number', 'Closing Time', 'Bidder'];
    public packageRefreshRate = [];
    public sponsorRefreshRate =  [];

    @ViewChild('form')
    public configForm: NgForm;

    public onSubmit() {
        // If category filter is not present in configForm value, add default value of configForm filter as 'All'
        this.leaderBoardService.setConfiguration(this.configForm.value);
        this.dialog.close();
    };

    public onReset() {
        let config =  new Config();
        config = this.leaderBoardService.getDefaultConfig();
        this.configForm.form.patchValue(config);
    };

    
    public onDefault() {
        let config =  new Config();
        config = this.leaderBoardService.getDefaultsetting();
        this.configForm.form.patchValue(config);
    };
    public onCancel() {
        this.dialog.close();
    };

    private setDropDownValues() {
        this.packageRefreshRate = this.ggoAdminService.generateValues(1, 99);
        this.sponsorRefreshRate =  this.ggoAdminService.generateValues(1, 99);
    };

    public setDefalutvalues() {
        this.config.background = _.capitalize(this.config.background);
    };

    private getCategoryTypesByProject() {
        this.leaderBoardService.getCategoryTypesByProject(this.leaderBoardService.projectInfo.slug).subscribe(
            res => {
                this.categoryTypes = res.plain();
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED)
            }
        );
    };

    ngOnInit() {
        this.config = this.leaderBoardService.config;
        this.setDefalutvalues();
        this.setDropDownValues();
        this.getCategoryTypesByProject();
    };
}
