import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { SignalR} from 'ng2-signalr';
import { ToasterService } from 'angular2-toaster';
import * as moment from 'moment-timezone';
import * as _ from 'lodash';

import { Config } from './config';
import { AppService } from './../../app.service';
import { ggoAdminConstants } from '../ggo-admin.const';
import { LeaderBoardService } from '../leader-board/leader-board.service';
import { ErrorHandlerService } from '../../bidding/error-handler/error-handler.service';
import { biddingErrorConstants } from '../../bidding/bidding-app.error.const';
import { biddingAppConstants } from '../../bidding/bidding-app.const';
import { LeaderBoardConfigurationComponent } from './configuration/leader-board-configuration.component';
import { GgoAdminService } from '../ggo-admin.service';

@Component({
  selector: 'leader-board',
  templateUrl: './leader-board.component.html',
})
export class LeaderBoardComponent implements OnInit {

    constructor(private activatedRoute: ActivatedRoute,
                private router: Router,
                private toasterService: ToasterService,
                private modal: Modal,
                private signalR: SignalR,
                private appService: AppService,
                private ggoAdminService: GgoAdminService,
                private leaderBoardService: LeaderBoardService,
                private errorHandlerService: ErrorHandlerService,
                private overlay: Overlay,
                private vcRef: ViewContainerRef) {
                    overlay.defaultViewContainer = vcRef;
                }

    public isPackageRefreshInvoked: boolean = false;
    public sponsors = [];
    public displayedPackageIds = [];
    public packageDisplayCount: number = 5;
    public packages = [];
    public packageLoadCount: number = 20;
    public nextSetOfPackges = [];
    public sponsorUpdate: number;
    private sponorsDisplayIntervalInst;
    private packageRefreshIntervalInst;
    public config = new Config();
    public projectInfo = this.leaderBoardService.projectInfo;
    public biddingAppConstants = biddingAppConstants;

    public startPackgeTransistion = false;
    public startSponsorsTransistion = false;
    public isAllPackagesReceived = false;

    public onLeaderConfigure() {
        this.leaderBoardService.config = this.config;
        return this.modal.open(LeaderBoardConfigurationComponent, overlayConfigFactory({dialogClass: 'modal-configuration'}, BSModalContext));
    };

    private getProject() {
        this.ggoAdminService.getProject(this.leaderBoardService.projectInfo.slug).subscribe(
            res => {
                this.cbsGetProject(res);
            },
            err => {
                this.routeToErrorPage();
            }
        );
    };

    private cbsGetProject(res) {
        this.leaderBoardService.projectInfo = res.plain();
        this.projectInfo = this.leaderBoardService.projectInfo;
        this.config = this.leaderBoardService.getDefaultConfig();
        this.getPackages(this.packageLoadCount);
    };

    private getPackages(packageDisplayCount) {
        this.leaderBoardService.getPackages(this.leaderBoardService.projectInfo.slug, this.config.packagefilter,
                                            this.config.categoryfilter, this.displayedPackageIds,
                                            packageDisplayCount, this.config.packagesort).subscribe(
            res => {
                this.cbsGetPackages(res);
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private cbsGetPackages(res) {
        let packages = res.plain();
        if (!packages.length) {return;}
        if (!this.packages.length) {
            this.nextSetOfPackges = Object.assign([], packages);
            this.isAllPackagesReceived = (packages.length < this.packageLoadCount);
            if (this.isAllPackagesReceived) {
                this.packages = this.nextSetOfPackges.slice(0, this.packageDisplayCount);
            } else {
                this.packages = this.nextSetOfPackges.splice(0, this.packageDisplayCount);
            }
        } else {
            this.nextSetOfPackges = this.nextSetOfPackges.concat(packages);
        }
        this.startUpdateClosingTime();
        if (packages.length <= this.packageDisplayCount) {
            return;
        }
        if (!this.isAllPackagesReceived) {
            this.setDisplayedPackgeIds(!this.isPackageRefreshInvoked, packages);
        }
        if (!this.isPackageRefreshInvoked) {
            this.packagesRefresh();
        }
    };

    private packagesRefresh() {
        if (this.packages.length < this.packageDisplayCount) {
            return;
        }
        this.isPackageRefreshInvoked = true;
        this.packageRefreshIntervalInst = setInterval(() => {
            this.displayNextSetOfPackges();
        }, (this.config.packagerefresh * 1000));
    };

    private displayNextSetOfPackges() {
        this.startPackgeTransistion = true;
        if (this.isAllPackagesReceived) {
            this.uiSidePackageRefresh();
        } else {
            this.packages = this.nextSetOfPackges.splice(0, this.packageDisplayCount);
            if (this.nextSetOfPackges.length === this.packageDisplayCount) {
                this.getPackages(this.packageLoadCount);
            }
        }
        setTimeout(() => {
            this.startPackgeTransistion = false;
        }, 100);
    };

    private uiSidePackageRefresh() {
        let lastDisplayedPackgeId = this.packages[this.packages.length - 1].ID;
        this.packages = this.appService.getItemsInRotational(lastDisplayedPackgeId, this.nextSetOfPackges, this.packageDisplayCount);
    };

    private setDisplayedPackgeIds(isToLoadFirstSetOfPackges, packageResponse) {
        let isExistingPackageId = false;
        let packageIds = [];
        packageResponse.forEach((packageObj) => {
            packageIds.push(packageObj.ID);
        });
        isExistingPackageId = packageIds.some((packageId) => {
            let packgeIdIndex = this.displayedPackageIds.indexOf(packageId);
            if (packgeIdIndex > -1) {
                return true;
            }
        });
        if (!isExistingPackageId) {
            this.displayedPackageIds = this.displayedPackageIds.concat(packageIds);
        } else {
            this.displayedPackageIds = packageIds;
        }
        if (isToLoadFirstSetOfPackges) {   // Inorder to handle ajax call latency getting next set of packages for intital page loading
            this.getPackages(this.packageLoadCount);
        }
    };

    private routeToErrorPage() {
        this.errorHandlerService.errorMessage = biddingErrorConstants.PROJECT_ID_NOT_FOUND;
        this.router.navigate(['/error']);
    };

    private getSponsors() {
        this.ggoAdminService.getSponsors(this.leaderBoardService.projectInfo.slug).subscribe(
            res => {
                this.sponsors = _.filter(res.plain(), function(sponsor: any) { return sponsor.imgpath !== null ;});
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        )
    };

    private stopPackageUpdate() {
        clearInterval(this.packageRefreshIntervalInst);
    };

    private listenEvents() {
        this.leaderBoardService.isConfigurationUpdated.subscribe(
            updatedConfigurationValues => {
                this.updateConfig(updatedConfigurationValues);
            }
        );
    };

    public updateConfig(updatedConfigurationValues) {
        this.stopPackageUpdate();
        this.config = updatedConfigurationValues;
        this.isPackageRefreshInvoked = false;
        this.displayedPackageIds = [];
        // To make Api call only when there is change in Package Filter Configurations
        if (this.checkIsPackageFilterConfigChanged()) {
            this.getPackages(this.packageLoadCount);
            this.packages = [];
            return;
        }
        this.packagesRefresh();
    };

    public checkIsPackageFilterConfigChanged() : boolean {
        let previousConfig = this.leaderBoardService.config;
        let isPackageFilterConfigChanged = ((previousConfig.categoryfilter !== this.config.categoryfilter) ||
                                            (previousConfig.packagefilter !== this.config.packagefilter) ||
                                            (previousConfig.packagesort !== this.config.packagesort));
        return isPackageFilterConfigChanged;
    };

    private connectSignalR() {
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatePackages').subscribe((updatedPackageId) => {
                this.leaderBoardService.getPackageByPackageId(this.leaderBoardService.projectInfo.slug, updatedPackageId).subscribe(
                    res => {
                        let updatedPackage = res.plain();
                        this.updatePackageBySignalR(updatedPackage);
                    }
                );
            });
        });
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatedCountTime').subscribe((prefix) => {
                if (prefix === this.leaderBoardService.projectInfo.slug) {
                    this.getPackages(this.packageLoadCount)
                }
            });
        });
    };

    private startUpdateClosingTime() {
        setInterval(() => {this.updateClosingTime(); }, 1000);
    };

    private updateClosingTime() {
        this.packages.forEach(packageObj => {
            if (!packageObj.closingtime) {
                return;
            }
            this.countDownTimeClosingTime(packageObj);
        });
    };

    private countDownTimeClosingTime(packageObj) { 
        let currentUTCDateTime = this.appService.convertTimeByTimeZone(new Date(), this.leaderBoardService.projectInfo.timezone);
        let dateDiff = this.appService.convertTimeByTimeZone(packageObj.closingtime, this.leaderBoardService.projectInfo.timezone).diff(currentUTCDateTime);
        packageObj.countDownTime = this.setCountDownTime(dateDiff);
        if (!packageObj.countDownTime) {
            if (packageObj.itemtype.toLowerCase() == biddingAppConstants.PACKAGE_TYPE.REGULAR) {
                packageObj.Status = ((packageObj.isBid) && 
                                     (packageObj.Status === biddingAppConstants.PACKAGE_STATUS.SOLD))? biddingAppConstants.PACKAGE_STATUS.SOLD : 
                                                                                                       biddingAppConstants.PACKAGE_STATUS.CLOSED;
            }
            if (packageObj.itemtype.toLowerCase() == biddingAppConstants.PACKAGE_TYPE.MULTISALE) {
                packageObj.Status = (packageObj.maxavailable == packageObj.qtyremaining) ? biddingAppConstants.PACKAGE_STATUS.CLOSED :
               (packageObj.maxavailable - packageObj.qtypurchased == 0) ? biddingAppConstants.PACKAGE_STATUS.SOLD : biddingAppConstants.PACKAGE_STATUS.CLOSED;
            }
            if (packageObj.itemtype.toLowerCase() == biddingAppConstants.PACKAGE_TYPE.DONATION || 
                packageObj.itemtype.toLowerCase() ==  biddingAppConstants.PACKAGE_TYPE.PREVIEW) {
                packageObj.Status = biddingAppConstants.PACKAGE_STATUS.CLOSED;
            }
         }
    };

    private setCountDownTime(dateDiffInMs) {
        let countDownTime;
        if (dateDiffInMs < 0) {
            countDownTime = biddingAppConstants.DATE_TIME_FORMATS.DEFAULT_TIME;
            return;
        }
        let seconds = dateDiffInMs / 1000;
        // Extract hours:
        let hours = (seconds / 3600); // 3,600 seconds in 1 hour
        hours = parseInt(hours.toString(), 0 );
        seconds = seconds % 3600; // seconds remaining after extracting hours
        // Extract minutes:
        let minutes = (seconds / 60); // 60 seconds in 1 minute
        minutes = parseInt(minutes.toString(), 0 );
        // Keep only seconds not extracted to minutes:
        seconds = (seconds % 60);
        seconds = parseInt(seconds.toString(), 0);
        let hoursStr = hours.toString();
        if (hoursStr.length < 2) {
            hoursStr = '0' + hoursStr;
        }
        let minutesStr = minutes.toString();
        if (minutesStr.length < 2) {
            minutesStr = '0' + minutesStr;
        }
        let secondsStr = seconds.toString();
        if (secondsStr.length < 2) {
            secondsStr = '0' + seconds;
        }
        countDownTime = (hoursStr !==  '00') ? (hoursStr + ':' + minutesStr + ':' + secondsStr) : (minutesStr + ':' + secondsStr);
        return countDownTime;
    };

    private updatePackageBySignalR(updatedPackage) {
        let updatedPackageIndex = _.findIndex(this.packages, {'ID': updatedPackage.ID});
        if (updatedPackageIndex < 0) { return; }
        this.packages[updatedPackageIndex] = updatedPackage;
        let updatedIndexInNextSetPackages = _.findIndex(this.nextSetOfPackges, {'ID': updatedPackage.ID});
        if (updatedIndexInNextSetPackages < 0) { return; };
        this.nextSetOfPackges[updatedIndexInNextSetPackages] = updatedPackage;
    };

    public getProjectPrefix() {
        let url = window.location.href;
        this.leaderBoardService.projectInfo.slug = url.slice(url.indexOf('//') + 2, url.indexOf('.'));
    };

    ngOnInit() {
        this.appService.setBusy();
        this.getProjectPrefix();
        this.getProject();
        this.getSponsors();
        this.connectSignalR();
        this.listenEvents();
    };
}
