import { Injectable, EventEmitter } from '@angular/core';
import { Restangular } from 'ng2-restangular';
import * as _ from 'lodash';

import { Config } from './config';
import { ggoAdminConstants } from '../ggo-admin.const';

@Injectable()
export class LeaderBoardService {

    constructor(private restangular: Restangular) { }

    public config = new Config();
    public projectInfo = {
        leaderboard_theme: 'Blue',
        timezone: '',
        display_sort: '',
        slug: '',
        display_loop_time: 0
    };
    public isConfigurationUpdated = new EventEmitter<Object>();

    public getDefaultConfig() {
        if ((!localStorage.length) || (!localStorage.leader)) {
            return this.getDefaultsetting();
        }
        var storage = JSON.parse(localStorage.leader);
        let config = new Config();
        for (let key in config) {
            config[key] = storage[key];
        }
        return config;
    };

    public getDefaultsetting() {
        let config = new Config();
        if (this.projectInfo.display_loop_time) {
            config.packagerefresh = this.projectInfo.display_loop_time;
            config.sponsorRefresh = this.projectInfo.display_loop_time;
        }
        config.showsponsors = true;
        config.background = this.projectInfo.leaderboard_theme ? this.projectInfo.leaderboard_theme : 'blue';
        if (this.projectInfo.display_sort) {
            config.packagefilter = ggoAdminConstants.LEADER_BOARD_PACKAGE_FILTER[this.projectInfo.display_sort.toLowerCase()];
            config.packagesort = ggoAdminConstants.LEADER_BOARD_PACKAGE_SORT[this.projectInfo.display_sort.toLowerCase()];
        }
        config.background = _.capitalize(config.background);
        localStorage.removeItem('leader');
        return config;
    }

    public setConfiguration(updatedConfigurationValues) {
        localStorage.setItem("leader", JSON.stringify(updatedConfigurationValues));
        this.isConfigurationUpdated.emit(updatedConfigurationValues);
    };

    public getCategoryTypesByProject(projectName) {
        let params = { 'prefix': projectName };
        return this.restangular.oneUrl('/GetCategoryTypesByProject').get(params);
    };

    public getPackageByPackageId(projectShortName, packageId) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageXid'] = packageId;
        return this.restangular.one('/GetPackagebyPackageId').get(queryParams);
    };

    public getPackages(projectName, packageFilter, categoryFilter, displayedPackageIds, displayCount, packageSort) {
        let queryParams = { 'prefix': projectName };
        let bodyParams = {};
        bodyParams = {
            package_filter_type: packageFilter,
            category_filter_type: categoryFilter,
            package_sort: packageSort,
            display_count: displayCount,
            displayed_packages: displayedPackageIds
        };
        return this.restangular.all('/GetLeaderBoardPackages').customPUT(bodyParams, undefined, queryParams);
    };
}
