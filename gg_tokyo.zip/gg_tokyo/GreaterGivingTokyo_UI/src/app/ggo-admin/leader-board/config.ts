export class Config {
    public packagefilter: string;
    public packagerefresh: number;
    public categoryfilter: string;
    public packagesort: string;
    public background: string;
    public showsponsors: boolean;
    public sponsorRefresh: number;
    public displayedPackageIds:string;

    constructor() {
        this.packagefilter = 'Open',
        this.packagerefresh = 10,
        this.categoryfilter = undefined,
        this.packagesort = 'Package Number',
        this.background = '',
        this.showsponsors = false,
        this.sponsorRefresh = 10
        this.displayedPackageIds =''
    }
};
