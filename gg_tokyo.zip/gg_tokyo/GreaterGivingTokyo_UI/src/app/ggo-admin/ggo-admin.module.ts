import { CurrencyFilter } from './../common/currency-filter';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { PerfectScrollbarModule } from 'angular2-perfect-scrollbar';

import { ggoAdminRouting } from './ggo-admin.routing';
import { GGOAdminComponent } from './ggo-admin.component';
import { appRoutes } from '../app.routing';
import { AppCommonModule } from './../common/common-module';
import { LeaderBoardComponent } from './leader-board/leader-board.component';
import { ProgressGaugeComponent } from './appeal-board/progress-gauge/progress-gauge.component';
import { AdminModule } from './admin/admin.module';
import { SponsorsComponent } from './sponsors/sponsors.component';
import { BackgroundThemeDirective } from './common/back-ground-theme.directive';
import { AppealBoardComponent } from './appeal-board/appeal-board.component';
import { AppealBoardService } from './appeal-board/appeal-board.service';
import { LeaderBoardService } from './leader-board/leader-board.service';
import { GgoAdminService } from './ggo-admin.service';
import { AppealBoardConfigurationComponent } from './appeal-board/configuration/appeal-board-configuration.component';
import { LeaderBoardConfigurationComponent } from './leader-board/configuration/leader-board-configuration.component';
import { CountdownBoardComponent } from './count_down-board/count_down-board.component';
import { CountdownBoardService } from './count_down-board/count_down-board.service';
import { CountDownBoardConfigurationComponent } from './count_down-board/configuration/count_down-board-configuration.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forRoot(appRoutes),
        PerfectScrollbarModule.forRoot(),
        FormsModule,
        AdminModule,
        AppCommonModule
    ],
    declarations: [
        BackgroundThemeDirective,
        GGOAdminComponent,
        AppealBoardComponent,
        LeaderBoardComponent,
        CountdownBoardComponent,
        AppealBoardConfigurationComponent,
        LeaderBoardConfigurationComponent,
        CountDownBoardConfigurationComponent,
        ProgressGaugeComponent,
        SponsorsComponent,
    ],
    providers: [
        AppealBoardService,
        CountdownBoardService,
        GgoAdminService,
        LeaderBoardService,
        CurrencyFilter
    ],
    entryComponents: [
        AppealBoardConfigurationComponent,
        CountDownBoardConfigurationComponent,
        LeaderBoardConfigurationComponent
    ]
})
export class GGOAdminModule { }
