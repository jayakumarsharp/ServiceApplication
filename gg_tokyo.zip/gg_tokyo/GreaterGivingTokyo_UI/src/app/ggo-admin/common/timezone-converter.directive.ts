import { Directive, ElementRef, Renderer, Input } from '@angular/core';
import * as moment from 'moment-timezone';

import { ggoAdminConstants } from './../ggo-admin.const';
import { AdminService } from '../admin/admin.service';
import { AppService } from '../../app.service';

@Directive({ selector: '[timeconverter]'})
export class TimezoneConverterDirective {

    constructor(private elementRef: ElementRef,
                private renderer: Renderer,
                private appService: AppService,
                private adminService: AdminService ) {}

    @Input() public format: string;
    @Input() public time: string;

    private convertTime() {
        if (!this.time) {return; }
        this.time = this.appService.convertTimeByTimeZone(this.time, this.adminService.projectInfo.timezone)
                                   .format(this.format);
        this.renderer.setElementProperty(this.elementRef.nativeElement, 'innerText', this.time);
    };

    ngOnInit() {
        this.convertTime();
    };
}
