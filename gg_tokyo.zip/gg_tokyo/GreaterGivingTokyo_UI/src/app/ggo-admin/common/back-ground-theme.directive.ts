import { Directive, ElementRef, Renderer, Input, OnInit, OnChanges } from '@angular/core';
import * as _ from 'lodash';

import { ggoAdminConstants } from './../ggo-admin.const';

@Directive({ selector: '[background-theme]'})
export class BackgroundThemeDirective implements OnInit, OnChanges{

    constructor(private elementRef: ElementRef,
                private renderer: Renderer) {}

    @Input() public bgTheme;

    public setBackgroundTheme() {

      let classForTheme = ggoAdminConstants.THEME_WITH_CLASSES[this.bgTheme.toLowerCase()];
      let themeClasses = Object.keys(ggoAdminConstants.THEME_WITH_CLASSES).map(key => ggoAdminConstants.THEME_WITH_CLASSES[key]);
      themeClasses.forEach(statusIndicatorClass => {
        this.renderer.setElementClass(this.elementRef.nativeElement, statusIndicatorClass, false);
      });

      this.renderer.setElementClass(this.elementRef.nativeElement, classForTheme, true);
    };

    ngOnInit() {
        this.setBackgroundTheme();
    };

    ngOnChanges() {
        this.setBackgroundTheme();
    };
}
