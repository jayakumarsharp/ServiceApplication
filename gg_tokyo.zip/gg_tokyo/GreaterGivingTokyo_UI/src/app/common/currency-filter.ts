import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'currencyFilter'})

export class CurrencyFilter implements PipeTransform {

    transform(amount: number): string {
        if (!amount || amount === 0) {return '0';}
        let no: number = 0;
        amount = parseFloat(amount.toString());
        if (amount == Math.round(amount) ) {
            no = Math.trunc(amount);
        } else {
            no = parseFloat(amount.toFixed(2));
        }
        let formattedAmount = no.toLocaleString('en');
        if (formattedAmount.indexOf('.') > -1) {
            if (!formattedAmount.charAt(formattedAmount.indexOf('.') + 2)) {
                formattedAmount = formattedAmount + 0;
            }
        }
        return formattedAmount;
    };
}
