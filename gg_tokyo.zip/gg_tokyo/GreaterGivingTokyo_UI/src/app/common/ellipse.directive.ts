import { Directive, Input, ElementRef, Renderer} from '@angular/core';

@Directive({ selector: '[ellipses]'})
export class EllipseDirective {

    constructor(private elementRef: ElementRef,
                private renderer: Renderer) {}

    @Input() public length: number;
    @Input() public text: string;

    private addEllipse() {
        if (this.text.length > (+this.length + 1)) {
            this.text = this.text.slice(0, +this.length) + '...' ;
        }
        this.renderer.setElementProperty(this.elementRef.nativeElement, 'innerText', this.text);
    };

    ngOnInit() {
        this.addEllipse();
    };
}
