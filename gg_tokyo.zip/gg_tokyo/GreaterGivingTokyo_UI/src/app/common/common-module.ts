import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { CurrencyFilter } from './currency-filter';
import { EllipseDirective } from './ellipse.directive';
import { ObfuscationDirective } from './bidder-name-obfuscation.directive';
import { SpinnerLoaderComponent } from './spinner-loader/spinner-loader.component';
@NgModule({
    imports: [
        CommonModule,
        BrowserModule
    ],
    exports: [CurrencyFilter,
              EllipseDirective,
              ObfuscationDirective,
              SpinnerLoaderComponent
             ],
    declarations: [CurrencyFilter,
                   EllipseDirective,
                   ObfuscationDirective,
                   SpinnerLoaderComponent
                  ],
    providers: [], 
})
export class AppCommonModule { }
