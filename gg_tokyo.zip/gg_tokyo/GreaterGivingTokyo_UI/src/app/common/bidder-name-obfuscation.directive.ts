import { Directive, OnInit, OnChanges, Input, ElementRef, Renderer} from '@angular/core';

@Directive({ selector: '[obfuscate]'})
export class ObfuscationDirective implements OnInit {

    constructor(private elementRef: ElementRef,
                private renderer: Renderer) {}

    @Input()
    public bidderName: string;

    @Input()
    public winningType: number;

    public obfuscate () {
        let obfuscatedString = '';
        if (+this.winningType === 1) {
            this.renderer.setElementProperty(this.elementRef.nativeElement, 'innerText', this.bidderName);
            return;
        }
        for (let i = 0; i < this.bidderName.length; i++) {
            let bidderNameChar = this.bidderName[i];
            let obfuscatedChar = (bidderNameChar === ' ' || i === 0 || i === (this.bidderName.length -1)) ? bidderNameChar : '*';
            obfuscatedString = obfuscatedString.concat(obfuscatedChar);
        }
        this.renderer.setElementProperty(this.elementRef.nativeElement, 'innerText', obfuscatedString);
    };

    ngOnInit() {
        this.obfuscate();
    };

    ngOnChanges() {
        this.obfuscate();
    };
}
