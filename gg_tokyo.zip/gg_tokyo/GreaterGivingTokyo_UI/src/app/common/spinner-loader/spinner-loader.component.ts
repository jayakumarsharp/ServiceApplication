import { Component, Input } from '@angular/core';

@Component({
    selector: 'spinner-loader',
    templateUrl: 'spinner-loader.component.html',
})
export class SpinnerLoaderComponent {

    @Input()
    public showLoader: boolean;

}
