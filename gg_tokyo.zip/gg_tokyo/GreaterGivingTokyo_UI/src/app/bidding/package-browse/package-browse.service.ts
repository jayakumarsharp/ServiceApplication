import { Injectable, EventEmitter } from '@angular/core';
import { Restangular } from 'ng2-restangular';
import * as moment from 'moment-timezone';

import { biddingAppConstants } from '../bidding-app.const';
import { BiddingAppService } from '../bidding-app.service';
import { AppService } from '../../app.service';

@Injectable()
export class PackageBrowseService {

    constructor(private restangular: Restangular,
                private appService: AppService,
                private biddingAppService: BiddingAppService) { } 

    public packages: any[];
    public slideViewPackages: any[];
    public routedPackage;
    public categoryOrPackageType;
    public isDetailViewActive = new EventEmitter<boolean> ();
    public isSlideViewActive = new EventEmitter<boolean> ();
    public isPackageUpdated = new EventEmitter<boolean>();
    public isAppealPackageReceived = new EventEmitter<boolean>();
    public isBidsFilterActive: boolean = false;
    public searchedIndex;
    public isFavorite: boolean = false;
    public appealPackage;
    public selectedPackageForSlideView: number;
    public isRemainingTime: boolean = false;

    public hideBidsFilter() {
        this.isBidsFilterActive = false;
    };

    public setAppealPackageReceived(isAppealPackageReceived) {
        this.isAppealPackageReceived.emit(true);
    };

    public getPackages(projectShortName: String, packageFilerType: string,  pageNo: number, size: number) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['pageNo'] = pageNo;
        queryParams['size'] = size;
        queryParams['packageFilterType'] = packageFilerType;
        return this.restangular.all('/GetPackages').getList(queryParams);
    };

    public getRelatedPackages(projectShortName, selectedPackageId, relatedPackageIds) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageXid'] = selectedPackageId;
        queryParams['displayedPackages'] = relatedPackageIds;
        return this.restangular.all('/GetRelatedPackages').getList(queryParams);
    };

    public getPackageBiddingHistory(projectShortName, packageId) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageid'] = packageId;
        return this.restangular.oneUrl('/GetBidderHistoryOrCurrentBuyers').get(queryParams);
    };

    public getPackageByPackageId(projectShortName, packageId) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageXid'] = packageId;
        return this.restangular.one('/GetPackagebyPackageId').get(queryParams);
    };

    public setDetailViewActive(value: boolean) {
        this.isDetailViewActive.emit(value);
    };

    public setSlideViewInactive(value: boolean) {
        this.isSlideViewActive.emit(value);
    };

    public packageUpdated(updatedPackage) {
        this.isPackageUpdated.emit(updatedPackage);
    };

    public getAppealPackage(prefix) {
        let params = {'prefix': prefix};
        return this.restangular.oneUrl('/GetAppealDonationPackage').get(params);
    };

    public getPackagesByBidStatus(prefix, status, pageno) {
        let queryParams = {};
        queryParams['prefix'] = prefix;
        queryParams['activityType'] = status;
        queryParams['pageno'] = pageno;
        queryParams['size'] = biddingAppConstants.RECORDS_PER_PAGE;
        return this.restangular.one('/GetBidActivityPackages').get(queryParams);
    };

    public getPackagesBySearchIndex(prefix, pageno, searchIndex) {
        let queryParams = {};
        queryParams['pageno'] = pageno;
        queryParams['prefix'] = prefix;
        queryParams['size'] = biddingAppConstants.RECORDS_PER_PAGE;
        queryParams['packageNameOrNumber'] = searchIndex;
        return this.restangular.all('/SearchPackagesByPackageName').getList(queryParams);
    };

    public toggleFavorites(prefix, packageId, isFavorite) {
        let queryParams = {};
        queryParams['prefix'] = prefix;
        queryParams['packageid'] = packageId;
        queryParams['isFavorite'] = isFavorite;
        return this.restangular.one('/AddOrRemoveFavoriteByBidder').post(undefined, undefined, queryParams);
    };

    public hasClosingTimeStarted(packageObj: any) {
        if(packageObj.formattedClosingTime =="00:00:00")
        {
            if (packageObj.itemtype.toLowerCase() == biddingAppConstants.PACKAGE_TYPE.REGULAR) {
                if ((packageObj.Status === biddingAppConstants.PACKAGE_STATUS.WINNING) ||
                    (packageObj.Status === biddingAppConstants.PACKAGE_STATUS.WON)) {
                    packageObj.Status = biddingAppConstants.PACKAGE_STATUS.WON;
                } else if (packageObj.Status == biddingAppConstants.PACKAGE_STATUS.OUTBID) {
                    packageObj.Status = biddingAppConstants.PACKAGE_STATUS.SOLD;
                }
            }
            if (packageObj.itemtype.toLowerCase() == biddingAppConstants.PACKAGE_TYPE.MULTISALE) {
                packageObj.Status = (packageObj.maxavailable == packageObj.qtyremaining) ? biddingAppConstants.PACKAGE_STATUS.CLOSED :
                (packageObj.maxavailable - packageObj.qtypurchased == 0) ? biddingAppConstants.PACKAGE_STATUS.SOLD : biddingAppConstants.PACKAGE_STATUS.CLOSED;
            }
            if ((packageObj.itemtype.toLowerCase() == biddingAppConstants.PACKAGE_TYPE.DONATION) ||
                (packageObj.itemtype.toLowerCase() == biddingAppConstants.PACKAGE_TYPE.PREVIEW)) {
                packageObj.Status = biddingAppConstants.PACKAGE_STATUS.CLOSED;
            }
        }
        /* get current UTC date time, beacuse closing time is always in UTC */
        let currentDateTime = this.appService.convertTimeByTimeZone(new Date(), this.biddingAppService.projectInfo.timezone);
        let startingTime = this.appService.convertTimeByTimeZone(packageObj.startingtime, this.biddingAppService.projectInfo.timezone);
        packageObj.hasClosingTimeStarted = startingTime.isBefore(currentDateTime);
        packageObj.formattedStartingTime = startingTime.format(biddingAppConstants.DATE_TIME_FORMATS.DATE_TIME_WITH_ZONE);
        if (!packageObj.hasClosingTimeStarted) { return packageObj; }
        let closingTime = this.appService.convertTimeByTimeZone(packageObj.closingtime, this.biddingAppService.projectInfo.timezone);
        packageObj.hasClosingTimeEnded = closingTime.isBefore(currentDateTime);
        if (packageObj.hasClosingTimeEnded && !packageObj.Status) {
            packageObj.Status = biddingAppConstants.PACKAGE_STATUS.CLOSED;
        }
        return packageObj;
    };

    public calculateClosingTime(packageObj) {
        /* get current UTC date time, beacuse closing time is always in UTC */
        let currentDateTime = this.appService.convertTimeByTimeZone(new Date(), this.biddingAppService.projectInfo.timezone);
        let closingTime = this.appService.convertTimeByTimeZone(packageObj.closingtime, this.biddingAppService.projectInfo.timezone);
        let dateDiff = closingTime.diff(currentDateTime);
        if (dateDiff < 0) {
            packageObj.formattedClosingTime = biddingAppConstants.DATE_TIME_FORMATS.DEFAULT_TIME;
            return;
        }
        if (dateDiff < 10800000) { /* 10800000 = 3 * 60 * 60 * 1000 (3 hours in milliseconds) */
            let duration = moment.duration(dateDiff);
            let hours = '0' + duration.hours();
            let minutes = duration.minutes().toString();
            let seconds = duration.seconds().toString();
            if (minutes.length < 2) {
                minutes = '0' + minutes;
            }
            if (seconds.length < 2) {
                seconds = '0' + seconds;
            }
            packageObj.formattedClosingTime = hours + ':' + minutes + ':' + seconds;
            packageObj.isRemainingTime = true;
            return;
        } else {
            packageObj.formattedClosingTime =  closingTime.format(biddingAppConstants.DATE_TIME_FORMATS.DATE_TIME_WITH_ZONE);
            return;
        }
    };
}
