import { Component, OnInit, OnDestroy } from '@angular/core';
import { PlatformLocation } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { SignalR} from 'ng2-signalr';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';
import { ToasterService } from 'angular2-toaster';

import { biddingAppConstants } from '../../bidding-app.const';
import { CurrencyFilter } from './../../../common/currency-filter';
import { AppService } from '../../../app.service';
import { appConstants } from '../../../app.const';
import { biddingErrorConstants } from '../../bidding-app.error.const';
import { BiddingAppService } from '../../bidding-app.service';
import { PackageBrowseService } from '../package-browse.service';
import { SlideOutMenuService } from '../slide-out-menu/slide-out-menu.service';
import { PackageBiddingComponent } from '../package-bidding/package-bidding.component';
import { PackageBiddingService } from '../package-bidding/package-bidding.service';
import { SponsorsService } from '../../shared/sponsors-logo/sponsors.service';
import { Utils } from './../../common/utils';

@Component({
    templateUrl: 'package-detail.component.html',
})

export class PackageDetailComponent implements OnInit, OnDestroy {

    constructor(private router: Router,
                private modal: Modal,
                private overlay: Overlay,
                private signalR: SignalR,
                private toasterService: ToasterService,
                private activatedRoute: ActivatedRoute,
                private appService: AppService,
                private biddingAppService: BiddingAppService,
                private location: PlatformLocation,
                private currencyFilter: CurrencyFilter,
                private packageBrowseService: PackageBrowseService,
                private packageBiddingService: PackageBiddingService,
                private sponsorsService: SponsorsService,
                private utils: Utils,
                private slideOutMenuService: SlideOutMenuService) {
                    this.location.onPopState(() => {
                        this.getRoutedPackage();
                    });
                };

    public biddingAppConstants = biddingAppConstants;
    public relatedPackages: any[];
    public projectInfo = {
        officialTime : '',
        appeal_only: ''
    };
    public package;
    public packageBiddingHistory;
    public bidderInfo;
    public appealPackage;
    public progressGraphicHeight;

    public isAppealPackage: boolean = false;
    public isAddedInFavorites = false;
    public showSlideOutMenu = false;
    private isCallBackFromSignalR = false;
    private isComponentDestroyed = false;
    public sponsors = [];

    public onPlaceBid(selectedPackage, biddingType) {
        let trackingLabel = this.getTrackEventsLabel(biddingType);
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, trackingLabel);
        this.packageBiddingService.package = selectedPackage;
        this.packageBiddingService.biddingType = biddingType;
        return this.modal.open(PackageBiddingComponent, overlayConfigFactory({dialogClass: 'modal-search'}, BSModalContext));
    };

    private getTrackEventsLabel(biddingType): string {
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BID) {
            return appConstants.EVENT_LABELS.DETAIL_BID;
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BID_MORE) {
            return appConstants.EVENT_LABELS.DETAIL_BID_MORE;
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BUY) {
            return appConstants.EVENT_LABELS.DETAIL_BUY;
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BUY_MULTISALE) {
            return appConstants.EVENT_LABELS.DETAIL_BUY_MULTI;
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.DONATE) {
            return appConstants.EVENT_LABELS.DETAIL_DONATE;
        }
    };

    public onSelectRelatedPackage(relatedpackage) {
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.DETAIL_RELATED_PACKAGE);
        let relatedPackageId = relatedpackage.ID;
        this.packageBrowseService.getPackageByPackageId(this.biddingAppService.projectPrefix, relatedPackageId).subscribe(
            res => {
                this.ngOnInit();
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
        this.router.navigateByUrl('bidding/package-browse/package/' + relatedpackage.ID);
    };

    private navigateToPackageSlideView() {
        if (this.isAppealPackage) {
            this.biddingAppService.navigateToPackageBrowseView();
            this.biddingAppService.isNavigateToHome = true;
            setTimeout(() => {this.biddingAppService.onScrollDown()}, 100);
            return;
        }
        this.router.navigateByUrl('bidding/package-browse/slide-view/' + this.package.ID);
    };

    private getRoutedPackage() {
        let packageId = +this.activatedRoute.snapshot.params['id'];
        let loginURL = this.biddingAppService.setLoginURL(packageId);
        this.biddingAppService.setLoginURLByURL(loginURL);
        this.isAppealPackage = (packageId === this.biddingAppService.projectInfo.appeal_package);
        if (this.isAppealPackage) {
            // spinner called before the api call for Appeal package detail view
            this.appService.setBusy();
            this.getAppealPackage();
        } else {
            this.getPackageByPackageId(packageId);
            this.getAppealPackage();
        }

        // To prevent setDetailViewActive being set to true even after the component Destroyed
        if (this.isComponentDestroyed) {
            return;
        };
        this.packageBrowseService.setDetailViewActive(true);
    };

    private getSponsors() {
        this.sponsors = this.biddingAppService.sponsors;
    };

    private getAppealPackage() {
        this.packageBrowseService.getAppealPackage(this.biddingAppService.projectPrefix).subscribe(
            res => {
                if (this.isAppealPackage) {
                    this.cbsGetPackageByPackageId(res);
                } else {
                    this.appealPackage = res.plain();
                }
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                if (this.isAppealPackage) {
                    this.appService.resetBusy();
                }
            }
        );
    };

    private getPackageByPackageId(packageId) {
        if (!this.isCallBackFromSignalR) {
            this.appService.setBusy();
        };
        this.packageBrowseService.getPackageByPackageId(this.biddingAppService.projectPrefix, packageId).subscribe(
            res => {
                this.cbsGetPackageByPackageId(res);
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    public onSelectAppealAmount(appealAmount) {
        let trackingLabel = (appealAmount) ? appConstants.EVENT_LABELS.DETAIL_APPEAL_DONATE :
                                             appConstants.EVENT_LABELS.DETAIL_APPEAL_DONATE_CUSTOM;
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, trackingLabel);
        this.packageBiddingService.biddingType = biddingAppConstants.BIDDING_TYPES.APPEAL_DONATE;
        this.packageBiddingService.appealAmount = appealAmount;
        return this.modal.open(PackageBiddingComponent, overlayConfigFactory({dialogClass: 'modal-search'}, BSModalContext));
    };

    private cbsGetPackageByPackageId(res) {
        this.package = res.plain();
        let url = window.location.href;
        this.biddingAppService.setPageTitleByPage(url, this.package);
        this.startUpdateClosingTimer();
        if (!this.isAppealPackage && !this.isCallBackFromSignalR) {
            this.getRelatedPackages();
        } else {
            if (this.package.appeal_logo_path) {
                this.package.imglink.push(this.package.appeal_logo_path);
            }
            if (this.package.appealgoal) {
                this.progressGraphicHeight = (this.package.totalraised / this.package.appealgoal) * 100;
            }
        }
        this.isCallBackFromSignalR = false;
        this.getPackageBiddingHistory();
        this.biddingAppService.setIsAppealPackage(true);
    };

    private startUpdateClosingTimer() {
        setInterval(() => { this.updateClosingTime(); }, 1000);
    };

    private updateClosingTime() {
        this.packageBrowseService.hasClosingTimeStarted(this.package);
        if (!this.package.hasClosingTimeEnded) {
            this.packageBrowseService.calculateClosingTime(this.package);
        }
    };

    private getRelatedPackages() {
        let packageId = this.package.ID;
        let relatedPackageIds = sessionStorage.getItem(packageId.toString());
        this.packageBrowseService.getRelatedPackages(this.biddingAppService.projectPrefix, packageId, relatedPackageIds).subscribe(
            res => {
                this.cbsGetRelatedPackages(res, relatedPackageIds, packageId);
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private cbsGetRelatedPackages(res, relatedPackageIds, selectedPackageId) {
        this.relatedPackages = res.plain();
        if (this.relatedPackages.length == 1) {
            return;
        }
        let latestRelatedPackagesIds = new Array();
        this.relatedPackages.forEach((packageObj) => {
            latestRelatedPackagesIds.push(packageObj.ID);
        });
        let isExistingPackageId = false;
        let arrayOfRelatedPackageIds = new Array();
        if (relatedPackageIds) {
            arrayOfRelatedPackageIds = relatedPackageIds.split(',');
            latestRelatedPackagesIds.some(function(packageId) {
                let packgeIdIndex = arrayOfRelatedPackageIds.indexOf(packageId.toString());
                if (packgeIdIndex > -1) {
                    sessionStorage.removeItem(selectedPackageId.toString());
                    sessionStorage.setItem(selectedPackageId.toString(), latestRelatedPackagesIds.join());
                    isExistingPackageId = true;
                    return isExistingPackageId;
                }
            });
        }
        if (!isExistingPackageId) {
            sessionStorage.removeItem(selectedPackageId.toString());
            sessionStorage.setItem(selectedPackageId.toString(), arrayOfRelatedPackageIds.concat(latestRelatedPackagesIds).join());
        }
    };

    private listenEvents() {
        this.packageBrowseService.isPackageUpdated.subscribe((updatedPackage) => {
            this.updateCurrentPackage(updatedPackage);
            this.updateRelatedPackages(updatedPackage);
        });

        this.biddingAppService.isLoggedInUser.subscribe(isLoggedInUser => {
            this.bidderInfo = this.slideOutMenuService.bidderInfo;
        });

        this.biddingAppService.isSponsorsReceived.subscribe(isSponsorsReceived => {
            this.getSponsors();
        });

        this.bidderInfo = this.slideOutMenuService.bidderInfo;
    };

    private updateCurrentPackage(updatedPackage) {
        if (updatedPackage.ID !== this.package.ID) {
            return;
        }
        this.packageBrowseService.routedPackage = updatedPackage;
        this.isCallBackFromSignalR = true;
        this.getRoutedPackage();
    }

    private updateRelatedPackages(updatedPackage) {
        let updatedPackageId = updatedPackage.ID;
        let updatedRelatedPackageIndex = _.findIndex(this.relatedPackages, {'ID': updatedPackageId});
        if ( updatedRelatedPackageIndex > -1 ) {
            this.relatedPackages[updatedRelatedPackageIndex] = updatedPackage;
        }
    }

    private getPackageBiddingHistory() {
        this.packageBrowseService.getPackageBiddingHistory(this.biddingAppService.projectPrefix, this.package.ID).subscribe(
            res => {
                this.cbsGetPackageBiddingHistory(res.plain());
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    private cbsGetPackageBiddingHistory(packageBiddingHistory) {
        this.packageBiddingHistory = packageBiddingHistory;
    };

    private getProjectInfo() {
        this.projectInfo = this.biddingAppService.projectInfo;
    };

    public onToggleFavorite(selectedPackage) {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.DETAIL_ADD_FAVU);
        let packageId = selectedPackage.ID;
        this.isAddedInFavorites = !selectedPackage.isFavorite;
        this.packageBrowseService.toggleFavorites(this.biddingAppService.projectPrefix, packageId, this.isAddedInFavorites).subscribe(
            res => {
                selectedPackage.isFavorite = this.isAddedInFavorites;
            },
            err => {
                this.isAddedInFavorites = !this.isAddedInFavorites;
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    private connectSignalR() {
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatedBiddingHistory').subscribe((biddingInfo: any) => {
                if (this.biddingAppService.projectPrefix === biddingInfo.prefix &&
                    this.package.ID === biddingInfo.packageid) {
                    this.packageBiddingHistory = biddingInfo.biddinghistory;
                }
            });
        });
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatedAppealDonationPackages').subscribe((updatedAppealPackagePrefix) => {
                if (this.biddingAppService.projectPrefix === updatedAppealPackagePrefix) {
                    this.getAppealPackage();
                }
            });
        });
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatedCountTime').subscribe((prefix) => {
                if (prefix === this.biddingAppService.projectPrefix) {
                    this.getAppealPackage();
                }
            });
        });
    };

    public onDonateLabel(selectedPackage) {
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.DETAIL_APPEAL_PACKAGE);
        let url = window.location.href
        this.biddingAppService.setPageTitleByPage(url, this.appealPackage);
        this.router.navigateByUrl('bidding/package-browse/package/' + selectedPackage.ID);
        if (this.router.url.match('/package/')) {
           setTimeout(() => {location.reload(); }, 300);
        }
    };

    private trackEvents(eventCategory, eventAction, eventLabel) {
        this.appService.trackEvents(eventCategory, eventAction, eventLabel);
    };

    ngOnInit() {
        // this.appService.setIsLoggedInUser();
        this.getRoutedPackage();
        this.getProjectInfo();
        this.getSponsors();
        this.listenEvents();
        this.connectSignalR();
        window.scrollTo(0, 0);
    };

    ngOnDestroy() {
        this.isComponentDestroyed = true;
        this.packageBrowseService.setDetailViewActive(false);
        window.scrollTo(0, 0);
        if (this.projectInfo.appeal_only) {
            this.router.navigateByUrl('bidding/package-browse/package' + this.package.ID);
        }
    };
}
