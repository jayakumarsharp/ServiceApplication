import { Component, OnInit, ViewChild, Input, OnChanges } from '@angular/core';
import { KSSwiperContainer, KSSwiperSlide } from 'angular2-swiper';

import { PackageBrowseService } from '../../package-browse.service';

@Component({
    selector: 'package-image-carousel',
    templateUrl: 'package-image-carousel.component.html'
})
export class PackageImageCarouselComponent implements OnInit, OnChanges {

    @ViewChild(KSSwiperContainer) swiperContainer : KSSwiperContainer;

    @Input() private packageImage: any[];
    @Input() private packageStatus;
    @Input() private packageItemtype;

    public showSwiper: boolean = true;

    public swiperOptions = {
        slidesPerView: 1,
        loop: true,
        spaceBetween: 0,
        keyboardControl: true,
        initialSlide: 0
    };
    public thumbSwiperOptions = {
        slidesPerView: 4,
        loop: true,
        spaceBetween: 20,
        breakpoints : {
            1280: {
                slidesPerView: 3.3,
                spaceBetween: 10,
            },
            700: {
                slidesPerView: 4.7,
                spaceBetween: 20,
            }
        }        
    };

    private highlightedThumbnail : number = 0;

    public onMoveNextImage(index) {
        this.swiperContainer.swiper.slideNext();
        this.highlightedThumbnail = index + 1;
    };

    public onMovePrevImage(index) {
        this.swiperContainer.swiper.slidePrev();
        this.highlightedThumbnail = index - 1;
    };

    public onSelectImageInThumbnailView(index) {
        this.highlightedThumbnail = index;
        this.swiperContainer.swiper.slideTo(index + 1);
    };

    public getThumbnailImageWidth() {
        let imagesCount = this.packageImage.length;
        let horizontalPackageImages = (window.innerWidth > 800) ? Math.round(imagesCount / 2) : imagesCount;
        let thumbnailImageWidth = (document.getElementsByClassName('item-image-thumbnail')[0]) ?
                                            document.getElementsByClassName('item-image-thumbnail')[0]['offsetWidth'] : 200;
        let width = horizontalPackageImages * thumbnailImageWidth;
        width =  width + (imagesCount * 20); /* 20 is the marigin between thumbnail imags */
        return width;
    };

    public reInitializeSwiper() {
        this.showSwiper = false;
        setTimeout(() => {
            this.showSwiper = true;
        }, 1000);
    };

    ngOnInit() {
        if (this.packageImage.length === 1) {
            this.swiperOptions.loop = false;
        }
    };

    ngOnChanges() {
        this.reInitializeSwiper();
    };
}
