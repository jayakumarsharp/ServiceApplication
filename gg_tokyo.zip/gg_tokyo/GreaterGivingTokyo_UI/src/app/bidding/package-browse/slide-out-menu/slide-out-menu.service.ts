import { Restangular } from 'ng2-restangular';
import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class SlideOutMenuService {

    constructor(private restangular: Restangular) {};

    public bidderInfo;

    public showSlideViewChange = new EventEmitter<boolean>();
    public isfavoritesFiltered = new EventEmitter<boolean>();

    public showSlideViewChanged(isShowSlideView: boolean) {
        this.showSlideViewChange.emit(isShowSlideView);
    };

    public displayFavoritesPackages(isfavoritesFiltered: boolean) {
        this.isfavoritesFiltered.emit(isfavoritesFiltered);
    };

    public getFilteredPackagesByPackageType(prefix, packageFilerType, pageNo, size) {
        let queryParams = {};
        queryParams['prefix'] = prefix;
        queryParams['pageNo'] = pageNo;
        queryParams['size'] = size;
        queryParams['packageFilterType'] = packageFilerType;
        return this.restangular.all('/GetPackages').get(queryParams);
    };

    public getPackagesByCategory(prefix, packageFilerType, pageNo, size) {
        let queryParams = {};
        queryParams['prefix'] = prefix;
        queryParams['pageNo'] = pageNo;
        queryParams['size'] = size;
        queryParams['categoryName'] = packageFilerType;
        return this.restangular.all('/GetPackagesByCategory').getList(queryParams);
    };

    public getFavoritesPackages(prefix, pageNo, size) {
        let queryParams = {};
        queryParams['prefix'] = prefix;
        queryParams['pageNo'] = pageNo;
        queryParams['size'] = size;
        return this.restangular.oneUrl('/GetFavoritePackagesByBidder').get(queryParams);
    };
}
