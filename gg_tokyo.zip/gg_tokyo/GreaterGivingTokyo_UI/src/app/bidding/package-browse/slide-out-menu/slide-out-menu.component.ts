import { Component, OnInit } from '@angular/core';
import { ToasterService } from 'angular2-toaster';
import { Router } from '@angular/router';

import { appConstants } from './../../../app.const';
import { AppService } from '../../../app.service';
import { BiddingAppService } from '../../bidding-app.service';
import { biddingErrorConstants } from '../../bidding-app.error.const';
import { SlideOutMenuService } from './slide-out-menu.service';
import { PackageBrowseService } from '../package-browse.service';
import { biddingAppConstants } from '../../bidding-app.const';

@Component({
    selector: 'slide-out-menu',
    templateUrl: 'slide-out-menu.component.html',
})

export class SlideOutMenuComponent implements OnInit {

    constructor(private toasterService: ToasterService,
                private appService: AppService,
                private biddingAppService: BiddingAppService,
                private router: Router,
                private slideOutMenuService: SlideOutMenuService,
                private packageBrowseService: PackageBrowseService) { };

    public packageTypes: any[];
    public categoryTypes: any[];
    public bidderInfo;
    public gutterVspace: number = 0;
    public appealPackage;
    public loginURL: string;

    public showSlideOutMenu: boolean;
    public isLoggedInUser: boolean = false;

    private getPackageTypesByProject() {
        this.biddingAppService.getPackageTypesByProject(this.biddingAppService.projectPrefix).subscribe(
            res => {
                this.packageTypes = res.plain();
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED)
            }
        );
    };

    private getCategoryTypesByProject() {
        this.biddingAppService.getCategoryTypesByProject(this.biddingAppService.projectPrefix).subscribe(
            res => {
                this.categoryTypes = res.plain();
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED)
            }
        );
    };

    private onSelectPackageType(packageType) {
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.SLIDE_OUT_ACT_NOW_FILTER);
        this.biddingAppService.isOutbidTab = false; //not to show outbid item in package type
        this.packageBrowseService.isFavorite = false; //not to perform favorites action in package type
        this.packageBrowseService.categoryOrPackageType = packageType;
        this.biddingAppService.setTitle(this.biddingAppService.projectInfo.Organization + ' | ' + this.packageBrowseService.categoryOrPackageType + ' | Greater Giving Online Bidding');
        this.getFilteredPackagesByPackageType(packageType);
        this.packageBrowseService.hideBidsFilter();
    };

    private getFilteredPackagesByPackageType(packageType) {
        this.appService.setBusy();
        this.slideOutMenuService.showSlideViewChanged(false);
        biddingAppConstants.PAGE_NO = 1;
        this.packageBrowseService.getPackages(this.biddingAppService.projectPrefix, packageType, biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
            res => {
                this.cbsGetPackagesByPackageType(res.plain());
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        )
    }; 

    private onPackageFilterByBids() {
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.SLIDE_OUT_BIDS_FILTER);
        this.biddingAppService.navigateToPackageBrowseView();
        this.biddingAppService.setTitle(this.biddingAppService.projectInfo.Organization + ' | My Bids | Greater Giving Online Bidding');
        setTimeout(() => {this.biddingAppService.onScrollDown()}, 100);
        this.packageBrowseService.searchedIndex = null; //not to show the search item name in the bids
        this.packageBrowseService.categoryOrPackageType = null; //not to show the category or package type name in the bids
        this.packageBrowseService.isFavorite = false; // not to perform favorites actions in bids
        this.packageBrowseService.isBidsFilterActive = true;
        setTimeout(() => {this.biddingAppService.setIsBidsFilterSelected(true)}, 200);
        this.slideOutMenuService.showSlideViewChanged(false);
    };

    private cbsGetPackagesByPackageType(filteredPackages) {
        this.biddingAppService.navigateToPackageBrowseView();
        setTimeout(() => {this.biddingAppService.onScrollDown()}, 100);
        this.packageBrowseService.packages = filteredPackages;
        this.packageBrowseService.searchedIndex = undefined;
        this.packageBrowseService.isBidsFilterActive = false;
        this.biddingAppService.setIsCategoryOrPackageTypeSelected(true);
    }; 

    private onPackageFilterByCategory(category) {
        this.appService.setBusy();
        this.slideOutMenuService.showSlideViewChanged(false);
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.SLIDE_OUT_CATEGORY_FILTER);
        this.biddingAppService.isOutbidTab = false; // not to show outbid tab in category type
        this.packageBrowseService.isFavorite = false; // not to perform favorite action in category type
        this.packageBrowseService.hideBidsFilter();
        this.packageBrowseService.isBidsFilterActive = false;
        this.packageBrowseService.categoryOrPackageType = category;
        this.biddingAppService.setTitle(this.biddingAppService.projectInfo.Organization + ' | ' + this.packageBrowseService.categoryOrPackageType + ' | Greater Giving Online Bidding');
        biddingAppConstants.PAGE_NO = 1;
        this.slideOutMenuService.getPackagesByCategory(this.biddingAppService.projectPrefix, category, biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
            res => {
                this.cbsgetPackagesByCategory(res.plain());
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED)
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private onPackageFilterByAllCategory() {
        this.appService.setBusy();
        this.slideOutMenuService.showSlideViewChanged(false);
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.SLIDE_OUT_CATEGORY_FILTER);
        this.packageBrowseService.isFavorite = false; // not to perform favorite action in category type
        this.packageBrowseService.hideBidsFilter();
        this.packageBrowseService.categoryOrPackageType = 'All';
        this.biddingAppService.isOutbidTab = false; // not to show outbid tab in category type
        this.packageBrowseService.isBidsFilterActive = false;
        biddingAppConstants.PAGE_NO = 1;
        this.packageBrowseService.getPackages(this.biddingAppService.projectPrefix, 'All', biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
            res => {
                this.cbsgetPackagesByCategory(res.plain());
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    public onStartBidding() {
        this.appService.setBusy();
    }

    private cbsgetPackagesByCategory(packagesByCategory) {
        this.biddingAppService.navigateToPackageBrowseView();
        setTimeout(() => {this.biddingAppService.onScrollDown()}, 100);
        this.packageBrowseService.packages = packagesByCategory;
        this.biddingAppService.setTitle(this.biddingAppService.projectInfo.Organization + ' | ' + this.packageBrowseService.categoryOrPackageType + ' | Greater Giving Online Bidding');
        this.packageBrowseService.searchedIndex = undefined;
        setTimeout(() => {this.biddingAppService.setIsCategoryOrPackageTypeSelected(true); }, 200);
    };

    public onLogOut() {
        this.appService.setBusy();
        sessionStorage.removeItem(biddingAppConstants.SESSION_STORAGE_KEYS.BIDDER_KEY);
        sessionStorage.removeItem(biddingAppConstants.SESSION_STORAGE_KEYS.TOKEN);
        this.bidderInfo = {};
        this.slideOutMenuService.bidderInfo = undefined;
        this.setGutterVspace();
        this.isLoggedInUser = false;
        this.biddingAppService.setIsLoggedInUser(false);
        this.slideOutMenuService.showSlideViewChanged(false);
        setTimeout(() => {this.appService.resetBusy()}, 1000);
    };

    private listenEvents() {
        this.slideOutMenuService.showSlideViewChange.subscribe(isSlideOutShow => {
            this.showSlideOutMenu = isSlideOutShow;
        });
        this.packageBrowseService.isAppealPackageReceived.subscribe(appealPackage => {
            this.appealPackage = this.packageBrowseService.appealPackage;
        });
        this.biddingAppService.loginURL.subscribe(loginURL => {
            this.loginURL = loginURL;
        });
    };

    private getBidderInfo() {
        this.biddingAppService.isLoggedInUser.subscribe((isLoggedInUser) => {
            this.isLoggedInUser = isLoggedInUser;
            this.bidderInfo = this.slideOutMenuService.bidderInfo;
        })
    };

    private setGutterVspace() {
        this.gutterVspace = (this.bidderInfo) ? 530 : 402;
    };

    public onFilterFavorites() {
        this.slideOutMenuService.showSlideViewChanged(false);
        this.appService.setBusy();
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.SLIDE_OUT_FAVU_FILTER);
        this.biddingAppService.navigateToPackageBrowseView();
        this.biddingAppService.setTitle(this.biddingAppService.projectInfo.Organization + ' | Favorites | Greater Giving Online Bidding');
        setTimeout(() => { this.biddingAppService.onScrollDown(); }, 100);
        this.packageBrowseService.searchedIndex = undefined;
        this.packageBrowseService.categoryOrPackageType = undefined;
        this.packageBrowseService.isBidsFilterActive = false;
        this.biddingAppService.isOutbidTab = false;
        biddingAppConstants.PAGE_NO = 1;
        this.slideOutMenuService.getFavoritesPackages(this.biddingAppService.projectPrefix,biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
            res => {
                this.cbsOnFilterFavorites(res);
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private cbsOnFilterFavorites(res) {
        this.packageBrowseService.packages = res.plain();
        this.packageBrowseService.isFavorite = true;
        this.slideOutMenuService.displayFavoritesPackages(true);
        this.biddingAppService.navigateToPackageBrowseView();
        this.packageBrowseService.packages = res.plain();
        setTimeout(() => {this.biddingAppService.setIsCategoryOrPackageTypeSelected(true);}, 200);
    };

    public getAppealPackage() {
        this.packageBrowseService.getAppealPackage(this.biddingAppService.projectPrefix).subscribe(
            res => {
                this.appealPackage = res.plain();
                this.packageBrowseService.appealPackage = this.appealPackage;
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    public onDonateLabel(selectedPackage) {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.SLIDE_OUT_APPEAL_PACKAGE);
        this.router.navigateByUrl('bidding/package-browse/package/' + selectedPackage.ID);
        if (this.router.url.match('/package/')) {
            setTimeout(() => {location.reload()}, 300);
        }
        this.slideOutMenuService.showSlideViewChanged(false);
    };

    private trackEvents(eventCategory, eventAction, eventLabel) {
        this.appService.trackEvents(eventCategory, eventAction, eventLabel);
    };

    private getLoginUrl() {
        this.loginURL = this.biddingAppService.loginUrl;
    }

    ngOnInit() {
        this.getLoginUrl();
        this.getBidderInfo();
        this.getPackageTypesByProject();
        this.getCategoryTypesByProject();
        this.listenEvents();
        this.getAppealPackage();
    };
}
