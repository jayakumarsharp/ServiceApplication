import { SignalRModule, SignalRConfiguration } from 'ng2-signalr';

import {appConfig} from '../../../app.config';

export function signalRConfig(): SignalRConfiguration {
    let config = new SignalRConfiguration();
    config.hubName = appConfig.PACKAGE_SIGNALR_HUB;
    config.url = appConfig.BIDDING_BASE_URL + appConfig.PACKAGE_SIGNALR_URL;
    config.logging = false;
    return config;
}
