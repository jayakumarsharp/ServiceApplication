import { Component, OnInit, NgZone, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { KSSwiperContainer } from 'angular2-swiper';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { DialogRef } from 'angular2-modal';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import * as _ from 'lodash';

import { AppService } from '../../../app.service';
import { appConstants } from '../../../app.const';
import { CurrencyFilter } from './../../../common/currency-filter';
import { biddingErrorConstants } from '../../bidding-app.error.const';
import { BiddingAppService } from '../../bidding-app.service';
import { biddingAppConstants } from '../../bidding-app.const';
import { PackageBrowseService } from '../package-browse.service';
import { SlideOutMenuService } from '../slide-out-menu/slide-out-menu.service';
import { PackageBiddingComponent } from '../package-bidding/package-bidding.component';
import { PackageBiddingService } from '../package-bidding/package-bidding.service';

@Component({
    selector: 'slide-view',
    host: {
        '(document:click)': 'onCloseSlideView($event)',
    },
    templateUrl: 'package-browse-slides.component.html',
})

export class PackageBrowseSlidesComponent implements OnInit, AfterViewInit {

    @ViewChild(KSSwiperContainer) swiperContainer: KSSwiperContainer;

    constructor(private router: Router,
                private activatedRoute: ActivatedRoute,
                private modal: Modal,
                private overlay: Overlay,
                private dialog: DialogRef<any>,
                private ngZone: NgZone,
                private appService: AppService,
                private biddingAppService: BiddingAppService,
                private toasterService: ToasterService,
                private currencyFilter: CurrencyFilter,
                private packageBrowseService: PackageBrowseService,
                private slideOutMenuService: SlideOutMenuService,
                private packageBiddingService: PackageBiddingService
                ) {}

    public biddingAppConstants = biddingAppConstants;
    public packages: any[];
    public bidderInfo;
    public isAddedInFavorites;
    public showLoader: boolean;

    public setBusy() {
        this.showLoader = true;
    };

    public resetBusy() {
        this.showLoader = false;
    };

    public swiperOptions = {
            slidesPerView: 3.3,
            loop: true,
            spaceBetween: 20,
            keyboardControl: true,
            centeredSlides: true,
            initialSlide: 0,
            breakpoints : {
                1200: {
                    slidesPerView: 2.8,
                    spaceBetween: 20,
                },
                880: {
                    slidesPerView: 1.8,
                    spaceBetween: 20,
                },
                700: {
                    slidesPerView: 1.15,
                    spaceBetween: 10,
                }
            }
    };

    public onPlaceBid(selectedPackage, biddingType) {
        let trackingLabel = this.getTrackEventsLabel(biddingType);
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, trackingLabel);
        this.packageBiddingService.package = selectedPackage;
        this.packageBiddingService.biddingType = biddingType;
        this.packageBiddingService.bidAmount = selectedPackage.minimumbid;
        return this.modal.open(PackageBiddingComponent, overlayConfigFactory({dialogClass: 'modal-search'}, BSModalContext));
    };

    private getTrackEventsLabel(biddingType): string {
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BID) {
            return appConstants.EVENT_LABELS.SLIDE_BID;
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BID_MORE) {
            return appConstants.EVENT_LABELS.SLIDE_BID_MORE;
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BUY) {
            return appConstants.EVENT_LABELS.SLIDE_BUY;
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BUY_MULTISALE) {
            return appConstants.EVENT_LABELS.SLIDE_BUY_MULTI;
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.DONATE) {
            return appConstants.EVENT_LABELS.SLIDE_DONATE;
        }
    };

    public onMoveNextPackages() {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.SLIDE_NEXT_PACKAGE);
        this.swiperContainer.swiper.slideNext();
    };

    public onMovePrevPackages() {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.SLIDE_PREV_PACKAGE);
        this.swiperContainer.swiper.slidePrev();
    };

    public onCloseSlideView(event) {
        if (event.target.className === "modal fade in" ||
            event.target.id === "slides-container" ||
            event.target.id === "back-button" ||
            event.target.id === "slideViewBack" ||
            event.target.id === "back-button-label") {
            this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.SLIDE_CLOSE);
            this.dialog.close();
            this.router.navigateByUrl('/bidding/package-browse');
        } else {
            // Fix for Mozilla for detail button click not working
            if (event.target.id === "slideViewToDetailView") {
                this.dialog.close();
                let currentPackage = this.getSlideCenterPackage();
                this.router.navigateByUrl('bidding/package-browse/package/' + currentPackage.ID);
            }
        }
    };

    public getSlideCenterPackage() {
        if (!this.swiperOptions.loop) {
            return this.packages[this.swiperContainer.swiper.activeIndex];
        }
        if (this.swiperContainer.options.slidesPerView === 1.15) {
            return this.packages[this.swiperContainer.swiper.activeIndex - 1];
        } else if (this.swiperContainer.options.slidesPerView === 1.8) {
            return this.packages[this.swiperContainer.swiper.activeIndex - 1];
        } else if (this.swiperContainer.options.slidesPerView === 2.8) {
            return this.packages[this.swiperContainer.swiper.activeIndex - 2];
        } else if (this.swiperContainer.options.slidesPerView === 3.3) {
            return this.packages[this.swiperContainer.swiper.activeIndex - 3];
        }
    };

    public onSelectPackageDetail(selectedPackage) {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.SLIDE_DETAIL);
        let currentPackage = selectedPackage;
        if (!currentPackage) {
            currentPackage = this.getSlideCenterPackage();
        }
        let url = window.location.href;
        this.biddingAppService.setPageTitleByPage(url, currentPackage);
        this.dialog.close();
        this.router.navigateByUrl('bidding/package-browse/package/' + currentPackage.ID);
    };

    public setSildeView() {
        let winh = window.innerHeight;
        let sh = document.querySelector('.slides').clientHeight;
        let x = (winh - sh) / 2;
        let slide = <HTMLScriptElement>document.querySelector('.slides');
        slide.style.marginTop  = x + 'px';
    };

    public onResize(event) {
        this.setSildeView();
    };

    private getPackages() {
        this.packages = Object.assign([], this.packageBrowseService.slideViewPackages);
        if (this.packages.length < 4) {
            this.swiperOptions.loop = false;
        }
        let selectedPackageNumber = this.packageBrowseService.selectedPackageForSlideView;
        let selectedPackageIndex = _.findIndex(this.packages, {'ID': selectedPackageNumber});
        // setting a selected package in center of slide view
        this.swiperOptions.initialSlide = selectedPackageIndex;
    };

    private startUpdateClosingTimer() {
        setInterval(() => {this.updateClosingTime(); }, 1000);
    };

    private updateClosingTime() {
       this.packages.forEach(packageObj => {
           this.packageBrowseService.hasClosingTimeStarted(packageObj);
           if (!packageObj.hasClosingTimeEnded) {
               this.packageBrowseService.calculateClosingTime(packageObj);
           }
        });
    };

    private listenEvents() {
        this.packageBrowseService.isPackageUpdated.subscribe(updatedPackage => {
            let updatedPackgeIndex = _.findIndex(this.packages, {'ID': updatedPackage.ID});
            if (updatedPackgeIndex > -1) {
                this.packages[updatedPackgeIndex] = updatedPackage;
            }
        });
        this.bidderInfo = this.slideOutMenuService.bidderInfo;
    };

    public onToggleFavorite(selectedPackage, index) {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.SLIDE_ADD_FAVU);
        let packageId = selectedPackage.ID;
        this.isAddedInFavorites = !selectedPackage.isFavorite;
        //   this.swiperContainer.swiper.detachEvents(true);
        this.packageBrowseService.toggleFavorites(this.biddingAppService.projectPrefix, packageId, this.isAddedInFavorites).subscribe(
            res => {
                selectedPackage.isFavorite = this.isAddedInFavorites;
                if (this.packageBrowseService.isFavorite) {
                        this.swiperContainer.swiper.removeSlide(index);
                }
                if (this.packageBrowseService.packages.length === 1 && !selectedPackage.isFavorite) {
                    this.backNavigation();
                }
            },
            err => {
                this.isAddedInFavorites = !this.isAddedInFavorites;
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
         );
    };

    public backNavigation() {
        this.dialog.close();
        this.router.navigateByUrl('bidding/package-browse');
    }

    private trackEvents(eventCategory, eventAction, eventLabel) {
        this.appService.trackEvents(eventCategory, eventAction, eventLabel);
    };

    ngAfterViewInit() {
        this.setSildeView();
        setTimeout(() => {
            this.resetBusy();
        }, 1000)
    };

    ngOnInit() {
        this.setBusy();
        this.getPackages();
        this.listenEvents();
        this.startUpdateClosingTimer();
    };
}
