import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { PackageBrowseSlidesComponent } from './package-browse-slides.component';
import { PackageBrowseService } from '../package-browse.service';

@Component({
  selector: 'slides-container',
  templateUrl: './package-browse-slides-container.component.html',
})

export class PackageBrowseSlidesContainerComponent implements OnInit {

    constructor (private router: Router,
                 private activatedRoute: ActivatedRoute,
                 private packageBrowseService :PackageBrowseService,
                 private modal: Modal) {}

    public openPackageBrowseSlideModalDialog() {
        this.modal.open(PackageBrowseSlidesComponent, overlayConfigFactory({dialogClass: 'modal-slide'}, BSModalContext));
    };

    public getSelectedPackageIdFromRoute() {
        this.packageBrowseService.selectedPackageForSlideView = +this.activatedRoute.snapshot.params['id'];
    };

    ngOnInit() {
        this.getSelectedPackageIdFromRoute();
        this.openPackageBrowseSlideModalDialog();
    };

    ngOnDestroy() {
        this.packageBrowseService.setSlideViewInactive(false);
    };
}
