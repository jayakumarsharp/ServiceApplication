import { Component, OnInit, NgZone, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { SignalR} from 'ng2-signalr';
import * as _ from 'lodash';
import * as $ from 'jquery';

import { biddingErrorConstants } from '../bidding-app.error.const';
import { CurrencyFilter } from './../../common/currency-filter';
import { AppService } from '../../app.service';
import { appConstants } from '../../app.const';
import { biddingAppConstants } from '../bidding-app.const';
import { Utils } from '../common/utils';
import { BiddingAppService } from '../bidding-app.service';
import { PackageBrowseSlidesComponent } from './package-slides/package-browse-slides.component';
import { PackageBrowseService } from './package-browse.service';
import { SlideOutMenuService } from './slide-out-menu/slide-out-menu.service';
import { ErrorHandlerService } from '../error-handler/error-handler.service';

@Component({
    selector: 'package-browse',
    templateUrl: 'package-browse.component.html',
    providers: [Modal]
})

export class PackageBrowseComponent implements OnInit {

    constructor(private route: ActivatedRoute,
                private router: Router,
                private overlay: Overlay,
                private signalR: SignalR,
                private vcRef: ViewContainerRef,
                private modal: Modal,
                private ngZone: NgZone,
                private toasterService: ToasterService,
                private utils: Utils,
                private appService: AppService,
                private biddingAppService: BiddingAppService,
                private currencyFilter: CurrencyFilter,
                private packageBrowseService: PackageBrowseService,
                private slideOutMenuService: SlideOutMenuService,
                private errorHandlerService: ErrorHandlerService) {
                }

    public biddingAppConstants = biddingAppConstants;
    public parentPackage;
    public subPackages: any[];
    public showLoader = false;
    public projectInfo = {
       officialTime : ''
    };
    public searchedIndex;
    public categoryOrPackageType;
    public packageFilerType;
    public bidderInfo;
    public bidFilters;
    public selectedBidIndex: number = 0;
    public isAddedInFavorites;
    public isLoggedInUser: boolean = false;
    public bidFilterType: string;
    public bidFilterTitle: string;
    public appealPackage = {
        ID: 0,
        itemnumber: 0,
        itemname: ''
    };
    public title: string = this.biddingAppService.projectInfo.Organization + '| Greater Giving Online Bidding';

    public isDetailViewActive: boolean = false;

    public getLatestPackages() {
        this.showLoader = true;
        sessionStorage.setItem(biddingAppConstants.SESSION_STORAGE_KEYS.SELECTED_PACKAGE_PAGE, biddingAppConstants.PAGE_NO.toString());
        biddingAppConstants.PAGE_NO ++;
        if (this.searchedIndex) {
            this.getPackagesBySearchedIndex(this.searchedIndex);
            return;
        };
        if (this.packageBrowseService.isBidsFilterActive) {
            this.getPackagesByBidFilterActive();
            return;
        };
        this.packageFilerType = (!this.packageBrowseService.categoryOrPackageType && !this.searchedIndex) ? 'All' : this.packageBrowseService.categoryOrPackageType ;
        if (!this.packageFilerType) {
            this.showLoader = false;
            return;
        };
        if (!this.packageBrowseService.isFavorite) {
            this.getPackagesByFavorite();
            return;
        }
        this.slideOutMenuService.getFavoritesPackages(this.biddingAppService.projectPrefix, biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
            res => {
                this.cbsGetLatestPackages(res)
            },
            err => {
                this.cbfGetLatestPackages();
            }
        );
    };

    public flooringGivenValue(number: number) {
        return this.utils.flooringOf(number);
    };

    public onSelectPackage(selectedPackage: any, isFromParentPackage: Boolean) {
        // setting selected package number in cookie inorder to handle referesh from slide view pop up
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.BROWSE_PACKAGE_SELECT);
        sessionStorage.setItem(biddingAppConstants.SESSION_STORAGE_KEYS.SELECTED_PACKAGE_PAGE, (biddingAppConstants.PAGE_NO).toString());
        this.packageBrowseService.slideViewPackages = this.packageBrowseService.packages;
        this.router.navigateByUrl('/bidding/package-browse/slide-view/' + selectedPackage.ID);
    };

    public getPackagesByScrollEnd() {
        let previousWindowBottom: number = 0;
        window.onscroll = () => {
            let windowHeight = 'innerHeight' in window ? window.innerHeight : document.documentElement.offsetHeight;
            let body = document.body,
            html = document.documentElement;
            let docHeight = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight);
            let windowBottom = windowHeight + window.pageYOffset;
            if (windowBottom >= docHeight && previousWindowBottom !== windowBottom && !this.isDetailViewActive) {
                previousWindowBottom = windowBottom;
                this.ngZone.run(() => {
                    this.getLatestPackages();
                });
            }
        };
    };

    public getPackages() {
        this.setPackges(false);
    };

    public setPackges(isCallBackFromSignalR) {
        let packages = this.packageBrowseService.packages;
        this.checkPackagesHasOutbid(packages);
        this.searchedIndex = this.packageBrowseService.searchedIndex;
        this.categoryOrPackageType = this.packageBrowseService.categoryOrPackageType;
        if (packages.length < -1) {
            this.subPackages = [];
            return;
        }
        let packagesCopy = Object.assign([], packages);
        this.subPackages = packagesCopy;
        // open slide view if cookie contains selected package number inorder to handle referesh
        if (!isCallBackFromSignalR) {
            // setting a selected package in center of slide view
            this.packageBrowseService.slideViewPackages = this.packageBrowseService.packages;
        }
    };

    public onSelectAppealPackage(selectedPackageId) {
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.BROWSE_APPEAL_PACKAGE_SELECT);
        let url = window.location.href
        this.biddingAppService.setPageTitleByPage(url, this.appealPackage);
        this.router.navigateByUrl('bidding/package-browse/package/' + selectedPackageId);
        if (this.router.url.match('/package/')) {
               setTimeout(() => {location.reload()}, 300);
        }
    };

    private connectSignalR() {
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatePackages').subscribe((updatedPackageId) => {
                let isFavoritesFiltered = this.packageBrowseService.isFavorite;
                this.packageBrowseService.getPackageByPackageId(this.biddingAppService.projectPrefix, updatedPackageId).subscribe(
                    res => {
                        let updatedPackage = res.plain();
                        //checking whether it is favorite or not in order to update the package
                        if (isFavoritesFiltered) {
                            if (!updatedPackage.isFavorite) {
                                let selectedPackageId =  _.findIndex(this.packageBrowseService.packages, {'ID': updatedPackage.ID });
                                this.packageBrowseService.packages.splice(selectedPackageId, 1);
                                this.setPackagesBySignalR();
                                return;
                            }
                        }
                        this.updatePackageBySignalR(updatedPackage);
                    }
                );
            });
        });

        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdatedCountTime').subscribe((prefix) => {
                if (prefix === this.biddingAppService.projectPrefix) {
                    this.getPackages();
                }
            });
        });
    };

    private setPackagesBySignalR() {
        this.setPackges(true);
    };

    private updatePackageBySignalR(updatedPackage) {
        let updatedPackageId = updatedPackage.ID;
        let hasUpdatedPackage = false;
        let updatedSubPackageIndex = _.findIndex(this.subPackages, {'ID': updatedPackageId});
        if (updatedSubPackageIndex < 0) { return; }
        this.subPackages[updatedSubPackageIndex] = updatedPackage;
        hasUpdatedPackage = true;
        this.updateSubPackageByBidsFilter();
        if (!hasUpdatedPackage) { return; }
        let updatedPackageIndex = _.findIndex(this.packageBrowseService.packages, {'ID': updatedPackageId});
        this.packageBrowseService.packages[updatedPackageIndex] = updatedPackage;
        this.packageBrowseService.packageUpdated(updatedPackage);
        let updatedPackageIndexforOutbid = _.findIndex(this.packageBrowseService.packages, {'Status': biddingAppConstants.BIDS_FILTER.OUTBID});
        this.biddingAppService.showOutbidNotification = (updatedPackageIndexforOutbid > -1);
    };

    public getPackagesByBidStatus(bidFilterType: string, bidFilterLink: string) {
        this.appService.setBusy();
        this.trackEvents(appConstants.EVENT_CATEGORY.LINK, appConstants.EVENT_ACTION.SELECT, appConstants.EVENT_LABELS.BROWSE_BIDS_FILTER);
        this.bidFilterTitle = bidFilterLink;
        this.packageBrowseService.getPackagesByBidStatus(this.biddingAppService.projectPrefix, bidFilterType, 1).subscribe(
            res => {
                this.cbsGetPackagesByBidStatus(res, bidFilterType);
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private updateSubPackageByBidsFilter() {
        if (this.packageBrowseService.isBidsFilterActive &&
           ((this.bidFilterType === this.biddingAppConstants.BIDS_FILTER.WINNING) ||
            (this.bidFilterType === this.biddingAppConstants.BIDS_FILTER.OUTBID))) {
             let indexToBeSpliced: number = _.findIndex(this.subPackages,
                                                        { 'Status': (this.biddingAppService.isOutbidTab) ? this.biddingAppConstants.BIDS_FILTER.WINNING : 
                                                                                                           this.biddingAppConstants.BIDS_FILTER.OUTBID });
             if (indexToBeSpliced > -1) {
                 this.subPackages.splice(indexToBeSpliced, 1);
             }
        }
    };

    public checkPackagesHasOutbid(packages) {
        if (this.biddingAppService.showOutbidNotification) {
            return;
        }
        let outbidPackageIndex = _.findIndex(packages, {'Status': biddingAppConstants.BIDS_FILTER.OUTBID});
        this.biddingAppService.showOutbidNotification = (outbidPackageIndex > -1);
    };

    public cbsGetPackagesByBidStatus(filteredPackages, bidFilterType) {
        this.bidFilterType = bidFilterType;
        this.biddingAppService.isOutbidTab = (this.bidFilterType === biddingAppConstants.BIDS_FILTER.OUTBID);
        let bidsFilteredPackages = filteredPackages.plain();
        this.packageBrowseService.packages = bidsFilteredPackages;
        this.subPackages = bidsFilteredPackages;
    };

    public listenEvents() {
        this.biddingAppService.isCategoryOrPackageTypeSelected.subscribe(isCategoryOrPackageTypeSelected => {
            this.getPackages();
        });
        this.biddingAppService.isBidsFilterSelected.subscribe( isBidsFilterSelected => {
            this.getPackagesByBidStatus(biddingAppConstants.BIDS_FILTER.ALL, biddingAppConstants.BIDS_FILTER_TITLE.ALL);
        });
        this.packageBrowseService.isDetailViewActive.subscribe(value => {
            this.isDetailViewActive = value;
        });
        this.slideOutMenuService.isfavoritesFiltered.subscribe(value => {
            this.getPackages();
        });
        this.biddingAppService.isLoggedInUser.subscribe(isLoggedInUser => {
            this.bidderInfo = this.slideOutMenuService.bidderInfo;
            this.isLoggedInUser = isLoggedInUser;
        });
        this.biddingAppService.isOutbidNotificationSelected.subscribe(isOutbidNotificationSelected => {
            this.getPackagesByBidStatus(biddingAppConstants.BIDS_FILTER.OUTBID, biddingAppConstants.BIDS_FILTER_TITLE.OUTBID);
        });
    };

    public getAppealPackage() {
        this.packageBrowseService.getAppealPackage(this.biddingAppService.projectPrefix).subscribe(
            res => {
                this.cbsGetAppealPackage(res);
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    private cbsGetAppealPackage(res) {
        this.appealPackage = res.plain();
        this.packageBrowseService.appealPackage = this.appealPackage;
    };

    private getProjectInfo() {
        this.projectInfo = this.biddingAppService.projectInfo;
    };

    private getBidderInfo() {
        this.bidderInfo = this.slideOutMenuService.bidderInfo;
    };

    private cbsGetLatestPackages(res) {
        let latestPackages = res.plain();
        this.showLoader = false;
        if (latestPackages.length < 1) {
            biddingAppConstants.PAGE_NO --;
            return;
        }
        this.checkPackagesHasOutbid(latestPackages);
        this.subPackages = this.subPackages.concat(latestPackages);
        // concatenating the latestPackages with packages in packageBrowseService for slide view
        this.packageBrowseService.packages = this.packageBrowseService.packages.concat(latestPackages);
    };

    private getSelectedPackageSet(packages) {
        let selectedPackgePage = +sessionStorage.getItem(biddingAppConstants.SESSION_STORAGE_KEYS.SELECTED_PACKAGE_PAGE);
        let packageFilerType = (this.packageBrowseService.categoryOrPackageType) ? this.packageBrowseService.categoryOrPackageType : 'All';
        this.packageBrowseService.getPackages(this.biddingAppService.projectPrefix, packageFilerType, selectedPackgePage, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
            res => {
                this.packageBrowseService.slideViewPackages = packages.concat(res.plain());
                return this.modal.open(PackageBrowseSlidesComponent, overlayConfigFactory({dialogClass: 'modal-slide'}, BSModalContext));
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    public onToggleFavorite(selectedPackage) {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.BROWSE_ADD_FAVU);
        let packageId = selectedPackage.ID;
        this.isAddedInFavorites = !selectedPackage.isFavorite;
        this.packageBrowseService.toggleFavorites(this.biddingAppService.projectPrefix, packageId, this.isAddedInFavorites).subscribe(
            res => {
                selectedPackage.isFavorite = this.isAddedInFavorites;
            },
            err => {
                this.isAddedInFavorites = !this.isAddedInFavorites;
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    private setSponsorsBannerFixedByJquery() {
        $(window).scroll(function(){
            var sticky = $('.sticky'),
            scroll = $(window).scrollTop();
            if ($(window).scrollTop() >= $(window).height() - 110) {
                sticky.addClass('fixed');
            } else {
                sticky.removeClass('fixed');
            };
        });
    };

    private getPackagesBySearchedIndex(searchedIndex) {
        this.packageBrowseService.getPackagesBySearchIndex(this.biddingAppService.projectPrefix, biddingAppConstants.PAGE_NO, this.searchedIndex)
            .subscribe(
                res => {
                    this.cbsGetLatestPackages(res);
                },
                err => {
                    this.cbfGetLatestPackages();
                }
        );
    };

    private getPackagesByBidFilterActive() {
        this.packageBrowseService.getPackagesByBidStatus(this.biddingAppService.projectPrefix, this.bidFilterType, biddingAppConstants.PAGE_NO).subscribe(
            res => {
                this.cbsGetLatestPackages(res);
            },
            err => {
                this.cbfGetLatestPackages();
            }
        );
    };

    private getPackagesByFavorite() {
        this.packageBrowseService.getPackages(this.biddingAppService.projectPrefix, this.packageFilerType, biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
              res => {
                  this.cbsGetLatestPackages(res);
              },
              err => {
                  this.cbfGetLatestPackages();
              }
        );
    };

    private cbfGetLatestPackages() {
        biddingAppConstants.PAGE_NO - 1;
        this.showLoader = false;
        // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
    };

    private trackEvents(eventCategory, eventAction, eventLabel) {
        this.appService.trackEvents(eventCategory, eventAction, eventLabel);
    };

    ngOnInit() {
        this.getProjectInfo();
        this.getAppealPackage();
        this.getBidderInfo();
        this.getPackages();
        this.setSponsorsBannerFixedByJquery();
        this.connectSignalR();
        this.listenEvents();
        this.getPackagesByScrollEnd();
    };
}
