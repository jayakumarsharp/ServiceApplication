import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule, Title } from '@angular/platform-browser';
import { RouterModule} from '@angular/router';
import { KSSwiperModule} from'angular2-swiper';
import { ModalModule } from 'angular2-modal';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
import { FormsModule, Validators } from '@angular/forms';
import { SignalRModule, SignalRConfiguration } from 'ng2-signalr';

import { appRoutes } from '../../app.routing';
import { Utils } from '../common/utils';
import { AppCommonModule } from './../../common/common-module';
import { CurrencyFilter } from './../../common/currency-filter';
import { PackageStatusIndicatorDirective } from '../common/package-status-indicator.directive';
import { NumberOnlyDirective } from '../common/number-only.directive';
import { EllipseDirective } from '../common/ellipse.directive';

import { PackagesResolver } from './packages.resolver';
import { PackageBrowseSlidesComponent } from './package-slides/package-browse-slides.component';
import { PackageBrowseComponent } from './package-browse.component';
import { PackageBrowseService } from './package-browse.service';
import { PackageDetailComponent } from './package-detail/package-detail.component';
import { PackageBiddingComponent } from './package-bidding/package-bidding.component';
import { SharedModule } from '../shared/shared.module';
import { SponsorsLogoComponent } from '../shared/sponsors-logo/sponsors-logo.component';
import { SpinnerLoaderComponent } from '../../common/spinner-loader/spinner-loader.component';
import { SpinnerControllerComponent } from './package-bidding/spinner-controller/spinner-controller.component';
import { SpinnerControllerService } from './package-bidding/spinner-controller/spinner-controller.service';
import { PackageBiddingService } from './package-bidding/package-bidding.service';
import { PackageImageCarouselComponent } from './package-detail/package-image-carousel/package-image-carousel.component';
import { PackageBrowseSlidesContainerComponent } from './package-slides/package-browse-slides-container.component';
import { signalRConfig } from './package.signalR.config';

@NgModule({
    declarations: [
        PackageStatusIndicatorDirective,
        NumberOnlyDirective,
        EllipseDirective,
        PackageBrowseComponent,
        PackageDetailComponent,
        PackageImageCarouselComponent,
        PackageBrowseSlidesComponent,
        PackageBrowseSlidesContainerComponent,
        PackageBiddingComponent,
        SpinnerControllerComponent,
    ],
    imports: [
        BrowserModule,
        RouterModule.forChild(appRoutes),
        KSSwiperModule,
        CommonModule,
        AppCommonModule,
        SharedModule,
        ModalModule.forRoot(),
        SignalRModule.forRoot(signalRConfig),
        BootstrapModalModule,
        FormsModule
    ],
    providers: [
        Utils,
        CurrencyFilter,
        PackagesResolver,
        PackageBrowseService,
        PackageBiddingService,
        SponsorsLogoComponent,
        SpinnerLoaderComponent,
        SpinnerControllerService,
        Title,
    ],
    entryComponents: [PackageBiddingComponent, PackageBrowseSlidesComponent]
})
export class PackageBrowseModule { }
