import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { DialogRef } from 'angular2-modal';
import { ToasterService } from 'angular2-toaster';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import {KSSwiperContainer, KSSwiperSlide} from 'angular2-swiper';

import { biddingAppConstants } from './../../../bidding-app.const';
import { biddingErrorConstants } from './../../../bidding-app.error.const';
import { BiddingAppService } from './../../../bidding-app.service';
import { PackageBiddingService } from '../package-bidding.service';
import { SpinnerControllerService } from './spinner-controller.service';

@Component({
  selector: 'spinner-controller',
  templateUrl: './spinner-controller.component.html'
})
export class SpinnerControllerComponent implements OnInit {

      constructor(private dialog: DialogRef<any>,
                  private modal: Modal,
                  private overlay: Overlay,
                  private toasterService: ToasterService,
                  private packageBiddingService: PackageBiddingService,
                  private spinnerControllerService: SpinnerControllerService,
                  private appService: BiddingAppService) {}

    @ViewChild(KSSwiperContainer) swiperContainer: KSSwiperContainer;

    @Input() public package;
    @Input() public biddingType;

    public page: number = 1;
    public size: number = 45;
    public amounts = [];
    public activeIndex: number = 0;
    public label: String;
    private previousIndex: number = 0;

    public swiperOptions = {
            initialSlide: 0,
            slidesPerView: 5.5,
            speed: 0,
            watchSlidesProgress: true,  
            spaceBetween: 2,
            direction: 'vertical',
            updateOnImagesReady: true,
            keyboardControl: true,
            observer: true,
            centeredSlides: true,
    };

    public showSuccessMsg = false;
    public showErrMsg = false;
    public showOutBidMsg = false;

    public onNextAmounts(isFromCallBack: Boolean) {
        if (this.page < 0) {
            return;
        }
        if (!isFromCallBack) {
            this.swiperContainer.swiper.slideNext('', 0);
        }
        let activeIndex = this.swiperContainer.swiper.activeIndex;
        if (activeIndex === this.amounts.length - 1) {
            this.page = 1;
        }
        this.spinnerControllerService.activeBidAmount = this.amounts[activeIndex];
        this.activeIndex = activeIndex;

    };

    public onPreviousAmounts(isFromCallBack: Boolean) {
        this.page++;
        let activeIndex = (!isFromCallBack) ? this.swiperContainer.swiper.activeIndex - 1 : this.swiperContainer.swiper.activeIndex;
        if (activeIndex < this.swiperOptions.slidesPerView) {
            if (this.packageBiddingService.biddingType === biddingAppConstants.BIDDING_TYPES.BID_MORE) {
                this.setBidMoreAmounts();
            } else {
                this.setDonationAmounts();
            }
            this.setActiveIndexByUpdatedAmount(); // work around: amounts are not updating immeditaly
        } else {
            this.activeIndex = activeIndex;
            if (!isFromCallBack) {
                this.swiperContainer.swiper.slideTo(activeIndex, '', false);
            }
            this.spinnerControllerService.activeBidAmount = this.amounts[activeIndex];
        }
    };

    private setActiveIndexByUpdatedAmount() {
        let activeIndex = (this.swiperContainer.swiper.activeIndex - 2) + this.size;
        this.activeIndex = activeIndex;
        this.swiperContainer.swiper.slideTo(activeIndex, '', false);
        this.onNextAmounts(false);
        this.spinnerControllerService.activeBidAmount = this.amounts[activeIndex];
    };

    private setBidMoreAmounts() {
        let incrementAmount = (this.package.isBid) ? this.package.CurrentHighBid : this.package.startingbid;
        let minimumBidAmount = this.package.minimumbid;
        let previousAmount = 0;
        let amounts = [];
        if (this.page > 1) {
            previousAmount = this.amounts[0];
        }
        for (let i = 0; i < this.size; i ++) {
            previousAmount = (previousAmount > 0) ? previousAmount : incrementAmount;
            let amount = previousAmount + minimumBidAmount;
            amounts.push(amount);
            previousAmount = amount;
        }
        this.setAmounts(amounts);
    };

    private setDonationAmounts() {
        let buyNowAmount = this.package.buynow;
        let previousAmount = 0;
        if (this.page > 1) {
            previousAmount = this.amounts[0];
        }
        let amounts = [];
        for (let i = 1; i <= this.size; i ++) {
            previousAmount = previousAmount + buyNowAmount;
            amounts.push(previousAmount);
        }
        this.setAmounts(amounts);
    };

    private setAmounts(amounts) {
        this.amounts = amounts.reverse().concat(this.amounts);
        if (this.page === 1) {
            let amountsLength = this.size - 1;
            this.activeIndex = amountsLength;
            this.swiperOptions.initialSlide = amountsLength;
            this.spinnerControllerService.activeBidAmount = this.amounts[this.activeIndex];
        } else {
            this.swiperContainer.swiper.update(true);  // reinitialize swiper after adding amounts
            this.swiperOptions.initialSlide = (this.swiperContainer.swiper.activeIndex - 2) + this.size;;
        }
    };

    private swiperListener() {
        setTimeout(() => {
            this.setPreviousIndex();
            this.swiperContainer.swiper.on('touchEnd', () => {
                this.afterSwipeEnd();
            });
            this.swiperContainer.swiper.on('keyPress', () =>{
                this.afterSwipeEnd();
            });
        }, 10);
    };

    private afterSwipeEnd() {
        if (this.previousIndex === this.swiperContainer.swiper.activeIndex) {
            return;
        } else if (this.previousIndex > this.swiperContainer.swiper.activeIndex) {
            this.onPreviousAmounts(true);
        } else {
            this.onNextAmounts(true);
        }
        this.previousIndex = this.swiperContainer.swiper.activeIndex;
    };

    private setAmountsAndLabel() {
        let biddingType = this.packageBiddingService.biddingType;
        if (biddingType === biddingAppConstants.BIDDING_TYPES.BID_MORE) {
            this.label = 'Bid Amount';
            this.setBidMoreAmounts();
        }
        if (biddingType === biddingAppConstants.BIDDING_TYPES.DONATE) {
            this.label = 'Donation Amount';
            this.setDonationAmounts();
        }
    };

    public setPreviousIndex() {
        this.previousIndex = this.swiperContainer.swiper.activeIndex;
    };

    ngOnInit() {
        this.setAmountsAndLabel();
        this.swiperListener();
    };
}
