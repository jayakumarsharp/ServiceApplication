import { Component, OnInit } from '@angular/core';
import { DialogRef } from 'angular2-modal';
import { ToasterService } from 'angular2-toaster';
import { FormsModule } from '@angular/forms';

import { biddingAppConstants } from '../../bidding-app.const';
import { biddingErrorConstants } from '../../bidding-app.error.const';
import { BiddingAppService } from './../../bidding-app.service';
import { PackageBiddingService } from './package-bidding.service';
import { PackageBrowseService } from '../package-browse.service';
import { SpinnerControllerService } from './spinner-controller/spinner-controller.service';

@Component({
    selector: 'app-package-bidding',
    host: {
      '(document:click)': 'onClose($event)',
    },
    templateUrl: './package-bidding.component.html',
})
export class PackageBiddingComponent implements OnInit {

    constructor(private dialog: DialogRef<any>,
                private toasterService: ToasterService,
                private packageBrowseService: PackageBrowseService,
                private packageBiddingService: PackageBiddingService,
                private biddingAppService: BiddingAppService,
                private spinnerControllerService: SpinnerControllerService) { }

    public biddingAppConstants = biddingAppConstants;
    public package;
    public bidAmount;
    public biddingType;
    public page: number = 1;
    public size: number = 10;
    public appealDonateAmount = '';
    public bidMoreAmounts = [];
    public buyMultisaleAmounts = [];
    public displayedBuyMultisaleQuantityWithAmounts = [];
    public maxQuantitiesReached: boolean;
    public quantityPriceSet = {
        quantity: 0,
        price: 0
    };

    public allowMaxBidding = false;
    public showSuccessMsg = false;
    public showErrMsg = false;
    public showOutBidMsg = false;
    public isToPlaceMaxBid = false;
    public showConfimation = false;
    public isButtonClicked = false;

    public onCancel() {
        this.dialog.close();
    };

    public onClose(event) {
        // closes the popup on outside click of the dialog box
        if (event.target.className === "modal-search") {
            this.dialog.close();
        }
    };

    public onPlaceBid() {
        this.setButton();
        if (this.showErrMsg || this.showSuccessMsg || this.showOutBidMsg) {
            this.onCancel();
            return;
        }
        this.packageBiddingService.placeBid(this.biddingAppService.projectPrefix, this.package.ID, this.bidAmount).subscribe(
            res => {
                let response = res.plain();
                if (response.message === 'Success') {
                    this.showSuccessMsg = true;
                }
                if (response.message === 'OutBided') {
                    this.showOutBidMsg = true;
                }
                if (response.message === 'Failure') {
                    this.showErrMsg = true;
                }
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            },
            () => {
                this.resetButton();
            }
        );
    };

    public onBuyPackage(amount) {
        this.setButton();
        if (this.showErrMsg || this.showSuccessMsg) {
            this.onCancel();
            return;
        }
        this.packageBiddingService.buyPackage(this.biddingAppService.projectPrefix, this.package.ID).subscribe(
            res => {
                let response = res.plain();
                if (response.message === 'Success') {
                    this.showSuccessMsg = true;
                }
                if (response.message === 'Failure') {
                    this.showErrMsg = true;
                }
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            },
            () => {
                this.resetButton();
            }
        );
    };

    public setAppealDonateAmount(appealDonationAmount) {
        this.appealDonateAmount = appealDonationAmount;
    }
    
    public onPlaceBidMore(isToPlaceMaxBid) {
        if (!isToPlaceMaxBid) {
            this.isToPlaceMaxBid = false;
        }
        this.showConfimation = true;
        this.bidAmount = this.spinnerControllerService.activeBidAmount;
    };

    public onSetMaxBid() {
        this.isToPlaceMaxBid = true;
        this.onPlaceBidMore(this.isToPlaceMaxBid);
    };

    public onSelectPurchaseQuantity(quantityPriceSet) {
        this.showConfimation = true;
        this.quantityPriceSet = quantityPriceSet;
    };

    public onConfirmedPlaceBid() {
        this.setButton();
        if (this.showSuccessMsg || this.showErrMsg || this.showOutBidMsg) {
            this.onCancel();
            return;
        }
        this.bidAmount = this.spinnerControllerService.activeBidAmount;
        if (this.isToPlaceMaxBid) {
            this.placeMaxBid();
        } else {
            this.placeBidMore();
        }
    };

    private placeBidMore() {
        this.packageBiddingService.placeBidMore(this.biddingAppService.projectPrefix, this.package.ID, this.bidAmount).subscribe(
            res => {
                let response = res.plain();
                if (response.message === 'Success') {
                    this.showSuccessMsg = true;
                }
                if (response.message === 'OutBided') {
                    this.showOutBidMsg = true;
                }
                if (response.message === 'Failure') {
                    this.showErrMsg = true;
                }
                this.showConfimation = false;
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
                this.showConfimation = false;
            },
            () => {
                this.resetButton();
            }
        );
    };

    private placeMaxBid() {
        this.packageBiddingService.setMaxBid(this.biddingAppService.projectPrefix, this.package.ID, this.bidAmount).subscribe(
            res => {
                let response = res.plain();
                if (response.message === 'Success') {
                    this.showSuccessMsg = true;
                }
                if (response.message === 'OutBided') {
                    this.showOutBidMsg = true;
                }
                if (response.message === 'Failure') {
                    this.showErrMsg = true;
                }
                this.showConfimation = false;
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
                this.showConfimation = false;
            },
            () => {
                this.resetButton();
            }
        );
    };

    public onBuyMultisale() {
        this.setButton();
        this.packageBiddingService.buyMultisale(this.biddingAppService.projectPrefix, this.package.ID, this.quantityPriceSet.quantity).subscribe(
            res => {
                let response = res.plain();
                if (response.message === 'Success') {
                    this.showSuccessMsg = true;
                }
                if (response.message === 'Failure') {
                    this.showErrMsg = true;
                }
            },
            err => {
            //   this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            },
            () => {
                this.resetButton();
            }
        )
    };

    public showAppealDonateConfimation() {
        if (this.showSuccessMsg || this.showErrMsg) {
            this.onCancel();
            return;
        }
        this.showConfimation = true;
    };

    public onAppealDonate() {
        this.setButton();
        this.packageBiddingService.onAppealDonate(this.biddingAppService.projectPrefix, +this.appealDonateAmount).subscribe(
            res => {
                let response = res.plain();
                if (response.message === 'Success') {
                    this.showSuccessMsg = true;
                    this.showConfimation = false;
                }
            },
            err => {
            //   this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
              this.showConfimation = false;
            },
            () => {
                this.resetButton();
            }
        )
    };

    public onDonateAmount() {
        if (!this.showConfimation) {
            this.showConfimation = true;
            this.bidAmount =  this.spinnerControllerService.activeBidAmount;
            return;
        }
        this.setButton();
        this.packageBiddingService.onDonateAmount(this.biddingAppService.projectPrefix, this.package.ID, this.bidAmount).subscribe(
            res => {
                let response = res.plain();
                if (response.message === 'Success') {
                    this.showSuccessMsg = true;
                    this.showConfimation = false;
                }
            },
            err => {
                //  this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
                this.showConfimation = false;
            },
            () => {
                this.resetButton();
            }
        );
    };

    public onNextBuyMultisaleAmounts() {
        this.page++;
        let buyMultisaleEndIndex = (this.page * this.size) - 1;
        if (this.buyMultisaleAmounts[buyMultisaleEndIndex]) {
            this.setDisplayedBuyMultisaleQuantityWithAmounts();
        } else {
            this.setBuyMultisaleQuantityWithAmounts();
        }
    };

    public onPreviousMultisaleAmounts() {
        this.page--;
        this.maxQuantitiesReached = false;
        this.setDisplayedBuyMultisaleQuantityWithAmounts();
    };

    private setBuyMultisaleQuantityWithAmounts() {
        let previousPurchaseQuantity = this.buyMultisaleAmounts[this.buyMultisaleAmounts.length - 1];
        previousPurchaseQuantity = (previousPurchaseQuantity) ? previousPurchaseQuantity.quantity : 0;
        for (let i = 0; i < this.size; i++) {
            let quantityPriceSet = {
                quantity: 0,
                price: 0
            };
            previousPurchaseQuantity = previousPurchaseQuantity + 1;
            quantityPriceSet.quantity = previousPurchaseQuantity;
            if (this.package.maxavailable !== null && (quantityPriceSet.quantity > this.package.qtyremaining)) {
                this.maxQuantitiesReached = true;
                break;
            }
            quantityPriceSet.price = quantityPriceSet.quantity * this.package.buynow;
            this.buyMultisaleAmounts.push(quantityPriceSet);
            if (this.package.maxavailable !== null && (quantityPriceSet.quantity >= this.package.qtyremaining)) {
                this.maxQuantitiesReached = true;
            }
        }
        this.setDisplayedBuyMultisaleQuantityWithAmounts();
    };

    public setDisplayedBuyMultisaleQuantityWithAmounts() {
        let copyOfBuyMultisaleQuantityWithAmounts = Object.assign([], this.buyMultisaleAmounts);
        let spliceEndIndex = (this.page * this.size);
        let spliceStartingIndex = (this.page > 1) ? (spliceEndIndex - this.size) : 0;
        this.displayedBuyMultisaleQuantityWithAmounts = [];
        this.displayedBuyMultisaleQuantityWithAmounts = copyOfBuyMultisaleQuantityWithAmounts.slice(spliceStartingIndex, spliceEndIndex);
    };

    private getBidAmount() {
        if (biddingAppConstants.BIDDING_TYPES.BID === this.biddingType) {
            this.bidAmount = (this.package.isBid) ? (this.package.CurrentHighBid + this.package.minimumbid) : this.package.startingbid;
            return;
        }
        if (biddingAppConstants.BIDDING_TYPES.BUY === this.biddingType) {
            this.bidAmount = this.package.buynow;
            return;
        }
        if (biddingAppConstants.BIDDING_TYPES.BUY_MULTISALE === this.biddingType) {
            this.setBuyMultisaleQuantityWithAmounts();
        }
        if (biddingAppConstants.BIDDING_TYPES.APPEAL_DONATE === this.biddingType) {
            if (this.packageBiddingService.appealAmount) {
                this.showConfimation = true;
                this.appealDonateAmount = this.packageBiddingService.appealAmount;
            }
        }
    };

    private listenEvents() {
        this.packageBrowseService.isSlideViewActive.subscribe(value => {
            this.dialog.close();
        });
        this.biddingAppService.isProjectUpdated.subscribe(isProjectUpdated => {
            this.getProjectDetails();
        });
    };

    private setButton() {
        this.isButtonClicked = true;
    };

    private resetButton() {
        this.isButtonClicked = false;
    };

    private getProjectDetails() {
        this.allowMaxBidding = this.biddingAppService.projectInfo.allowMaxBidding;
    };

    ngOnInit() {
        this.package = this.packageBiddingService.package;
        this.biddingType = this.packageBiddingService.biddingType;
        this.allowMaxBidding = this.biddingAppService.projectInfo.allowMaxBidding;
        this.listenEvents();
        this.getBidAmount();
    };
}
