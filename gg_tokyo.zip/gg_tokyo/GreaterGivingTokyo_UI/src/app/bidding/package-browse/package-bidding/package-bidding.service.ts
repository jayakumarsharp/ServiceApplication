import { Injectable } from '@angular/core';
import { Restangular } from 'ng2-restangular';

@Injectable()
export class PackageBiddingService {

    constructor(private restangular: Restangular) { }

    public package;
    public bidAmount;
    public biddingType;
    public appealAmount;

    public placeBid(projectShortName, packageId, bidAmount) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageId'] = packageId;
        queryParams['amount'] = bidAmount;
        return this.restangular.oneUrl('/AddBid').post(undefined, undefined, queryParams);
    };

    public onAppealDonate(projectShortName, donationAmount) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['donationAmount'] = donationAmount;
        return this.restangular.oneUrl('/BuyAppealDonationPackage').post(undefined, undefined, queryParams);
    }

    public buyPackage(projectShortName, packageId) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageId'] = packageId;
        return this.restangular.oneUrl('/BuyRegularPackage').post(undefined, undefined, queryParams);
    };

    public placeBidMore(projectShortName, packageId, bidAmount) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageId'] = packageId;
        queryParams['amount'] = bidAmount;
        return this.restangular.oneUrl('/BidMore').post(undefined, undefined, queryParams);
    };

    public onDonateAmount(projectShortName, packageId, bidAmount) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageId'] = packageId;
        queryParams['amount'] = bidAmount;
        return this.restangular.oneUrl('/BuyDonationPackage').post(undefined, undefined, queryParams);
    };

    public buyMultisale(projectShortName, packageId, quantity) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageId'] = packageId;
        queryParams['quantity'] = quantity;
        return this.restangular.oneUrl('/BuyMultiSalePackages').post(undefined, undefined, queryParams);
    };
    public setMaxBid(projectShortName, packageId, bidAmount) {
        let queryParams = {};
        queryParams['prefix'] = projectShortName;
        queryParams['packageId'] = packageId;
        queryParams['amount'] = bidAmount;
        return this.restangular.oneUrl('/SetMaxBid').post(undefined, undefined, queryParams);
    };
}
