import { Injectable } from '@angular/core';
import { Resolve, Router, ActivatedRouteSnapshot } from '@angular/router';
import { ToasterService } from 'angular2-toaster';

import { BiddingAppService } from './../bidding-app.service';
import { PackageBrowseService } from './package-browse.service';
import { biddingErrorConstants } from '../bidding-app.error.const';
import { biddingAppConstants } from '../bidding-app.const';

@Injectable()
export class PackagesResolver implements Resolve<any> {

    constructor(private router: Router,
                private toasterService: ToasterService,
                private packageBrowseService: PackageBrowseService,
                private appService: BiddingAppService) { }

    resolve(): Promise<boolean> {
        return new Promise((resolve, reject) => {
            if (this.packageBrowseService.searchedIndex || this.packageBrowseService.packages) {
                 resolve();
                 return;
            }
            let projectPrefix = this.appService.projectPrefix;
            this.packageBrowseService.getPackages(projectPrefix, 'All', biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
                res => {
                    this.packageBrowseService.packages = res.plain();
                    resolve();
                },
                err => {
                    // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
                    reject(err);
                }
            );
        });
    };
}
