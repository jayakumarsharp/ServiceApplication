import { Component } from '@angular/core';
import { ToasterService } from 'angular2-toaster';
import { DialogRef } from 'angular2-modal';
import { Router, ActivatedRoute } from '@angular/router';

import { biddingAppConstants } from '../../bidding-app.const';
import { BiddingAppService } from '../../bidding-app.service';
import { AppService } from '../../../app.service';
import { PackageBrowseService } from '../package-browse.service';

@Component({
    templateUrl: 'package-search.component.html',
})

export class PackageSearchComponent {

    private searchIndex: string = '';

    constructor(private toasterService: ToasterService,
                private router: Router,
                private activatedRoute: ActivatedRoute,
                private dialog: DialogRef<any>,
                private appService: AppService,
                private packageBrowseService: PackageBrowseService,
                private biddingAppService: BiddingAppService
               ) { }

    public onSearchPackage() {
        this.appService.setBusy();
        this.biddingAppService.isOutbidTab = false;
        this.packageBrowseService.isFavorite = false;
        biddingAppConstants.PAGE_NO = 1;
        this.packageBrowseService.getPackagesBySearchIndex(this.biddingAppService.projectPrefix, biddingAppConstants.PAGE_NO, this.searchIndex).subscribe(
                res => {
                    this.cbsGetPackagesBySearchIndex(res.plain());
                },
                err => {
                    // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
                }, () => {
                    this.appService.resetBusy();
                }
        );
        this.dialog.close();
    };

    public onCancel() {
        this.dialog.close();
    };

    public cbsGetPackagesBySearchIndex(searchedPackages) {
        this.packageBrowseService.searchedIndex = this.searchIndex;
        this.packageBrowseService.hideBidsFilter();
        this.biddingAppService.setTitle(this.biddingAppService.projectInfo.Organization + ' | ' + this.packageBrowseService.searchedIndex + ' | Greater Giving Online Bidding');
        this.packageBrowseService.categoryOrPackageType = undefined;
        if (!searchedPackages.length) {
            this.router.navigateByUrl('bidding/no-package-found');
            return;
        }
        if (searchedPackages.length === 1) {
            let searchedPackageId = searchedPackages[0].ID;
            this.router.navigateByUrl('bidding/package-browse/package/' + searchedPackageId);
            if (this.router.url.match('/package/')) {
               setTimeout(() => {location.reload()}, 300);
            }
        } else if (this.router.url.match('/package/') ||
                   this.router.url.match('/terms-conditions') ||
                   this.router.url.match('/take-tour') ||
                   this.router.url.match('/learn-more') ||
                   this.router.url.match('/no-package-found')) {
            this.packageBrowseService.packages = searchedPackages;
            this.router.navigateByUrl('bidding/package-browse');
            this.biddingAppService.setIsCategoryOrPackageTypeSelected(true);
        } else {
            this.packageBrowseService.packages = searchedPackages;
            this.biddingAppService.setIsCategoryOrPackageTypeSelected(true);
        }
        setTimeout(() => { this.biddingAppService.onScrollDown(); }, 100);
    };
}
