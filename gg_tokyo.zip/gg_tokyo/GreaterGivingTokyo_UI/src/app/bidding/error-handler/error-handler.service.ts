import { Restangular } from 'ng2-restangular';
import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class ErrorHandlerService {

    constructor(private restangular: Restangular) {};

    public errorMessage: string;

    public hasError = new EventEmitter<boolean>();

    public setHasError(hasError) {
        this.hasError.emit(hasError);
    };
}
