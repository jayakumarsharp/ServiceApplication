import { Component, OnInit } from '@angular/core';
import { ErrorHandlerService } from './error-handler.service';

@Component({
  templateUrl: './error-handler.component.html',
})

export class ErrorHandlerComponent implements OnInit {

    constructor (private errorHandlerService: ErrorHandlerService) {}

    public errorMessage;

    ngOnInit() {
        this.errorMessage = this.errorHandlerService.errorMessage;
        this.errorHandlerService.setHasError(true);
        this.errorHandlerService.errorMessage = null;
    };
}
