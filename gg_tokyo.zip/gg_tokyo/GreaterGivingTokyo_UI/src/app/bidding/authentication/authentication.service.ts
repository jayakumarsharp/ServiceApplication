import { Injectable } from '@angular/core';
import { Restangular } from 'ng2-restangular';

@Injectable()
export class AuthenticationService {

constructor(private restangular: Restangular) { }

    public getAuthenticationTokenByBidderKey(bidderKey) {
        let queryParams = {};
        queryParams['onlineBidderKey'] = bidderKey;
        let headers = {'authenticationURL': true};
        return  this.restangular.oneUrl('/Login').get(queryParams, headers);
    };

    public getBidderByBidderKey(bidderKey) {
        let queryParams = {};
        queryParams['bidderKey'] = bidderKey;
        return  this.restangular.oneUrl('/GetBidderByBidderKey').get(queryParams);
    };
}
