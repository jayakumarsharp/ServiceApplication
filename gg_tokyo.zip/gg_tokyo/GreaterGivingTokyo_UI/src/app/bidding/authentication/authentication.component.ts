import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit} from '@angular/core';
import { ToasterService } from 'angular2-toaster';

import { Utils } from '../common/utils';
import { biddingAppConstants } from '../bidding-app.const';
import { biddingErrorConstants } from '../bidding-app.error.const';
import { BiddingAppService } from '../bidding-app.service';
import { AppService } from '../../app.service';
import { AuthenticationService } from './authentication.service';
import { SlideOutMenuService } from '../package-browse/slide-out-menu/slide-out-menu.service';
import { ErrorHandlerService } from '../error-handler/error-handler.service';

@Component({
    template: '<div>Loading...</div>'
})

export class BiddingAuthComponent implements OnInit {

    constructor(private router: Router,
                private toasterService: ToasterService,
                private biddingAppService: BiddingAppService,
                private appService: AppService,
                private activatedRoute: ActivatedRoute,
                private utils: Utils,
                private authenticationService: AuthenticationService,
                private errorHandlerService: ErrorHandlerService,
                private slideOutMenuService: SlideOutMenuService) {}


    public packageId: number;

    private getBidderKey() {
        if (!this.appService.isSessionStorageAccessible) {
            this.router.navigateByUrl('bidding/error');
            return;
        }
        let url = window.location.href;
        let bidderKeyEndIndex = url.length;
        if (url.indexOf('?') > 0) {
            bidderKeyEndIndex = url.indexOf('?');
        }
        let prefix = url.slice(url.indexOf('//') + 2, url.indexOf('.'));
        let bidderKey = this.activatedRoute.snapshot.params['id'] ?
                        this.activatedRoute.snapshot.params['id'] : this.activatedRoute.snapshot.queryParams['BK'];
        sessionStorage.clear();
        
        this.getAuthenticationTokenByBidderKey(bidderKey);
        this.packageId = +this.activatedRoute.snapshot.queryParams['packageId'];
    };

    private routeToPackgeBrowse() {
        //When navigating from supporter greater giving URL navigate to package browse/package detail based on packageId
        if (this.utils.contains(this.router.url, '/b/')) {
            if (this.packageId) {
                this.router.navigateByUrl('bidding/package-browse/package/' + this.packageId);
            } else {
                this.router.navigateByUrl('bidding/package-browse');
            }
        }
    };

    private getAuthenticationTokenByBidderKey(bidderKey: string) {
        this.authenticationService.getAuthenticationTokenByBidderKey(bidderKey).subscribe(
            res => {
                sessionStorage.setItem(biddingAppConstants.SESSION_STORAGE_KEYS.BIDDER_KEY, bidderKey);
                sessionStorage.setItem(biddingAppConstants.SESSION_STORAGE_KEYS.TOKEN, res.plain().BidderToken);
                this.getBidderByBidderKey(bidderKey);
            },
            err => {
                this.errorHandlerService.errorMessage = biddingErrorConstants.BIDDER_KEY_NOT_FOUND;
                this.router.navigateByUrl('bidding/error');
            }
        );
    };

    public getBidderByBidderKey(bidderKey) {
        let token = sessionStorage.getItem(biddingAppConstants.SESSION_STORAGE_KEYS.TOKEN);
        this.authenticationService.getBidderByBidderKey(bidderKey).subscribe(
            res => {
                let bidderInfo = res.plain();
                let url = window.location.href;
                let prefix = url.slice(url.indexOf('//') + 2, url.indexOf('.'));
                if (this.utils.contains(url, bidderInfo.Prefix.toLowerCase())) { 
                    this.router.navigateByUrl('bidding/error');
                    return;
                }
                this.slideOutMenuService.bidderInfo = bidderInfo;
                this.biddingAppService.projectPrefix = this.slideOutMenuService.bidderInfo.Prefix;
                sessionStorage.setItem(biddingAppConstants.SESSION_STORAGE_KEYS.PREFIX, this.biddingAppService.projectPrefix);
                this.biddingAppService.setIsLoggedInUser(true);
                this.routeToPackgeBrowse();
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }
        );
    };

    ngOnInit() {
        this.getBidderKey();
    };
}
