import { Component, OnInit } from '@angular/core';
import { BiddingAppService } from './../bidding-app.service';
import { PackageBrowseService } from '../package-browse/package-browse.service';
import { PackageSearchComponent } from '../package-browse/package-search/package-search.component';
import { appConstants } from '../../app.const';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AppService } from '../../app.service';

@Component({
    templateUrl: './no-package-found.component.html', 
    providers: [Modal] 
})

export class NoPackageFoundComponent implements OnInit {
    constructor(private appService: AppService, 
                private packageBrowseService: PackageBrowseService,
                private biddingAppService: BiddingAppService,
                private modal:Modal) { }

    private trackEvents(eventCategory, eventAction, eventLabel) {
        this.appService.trackEvents(eventCategory, eventAction, eventLabel);
    };

    public onNavigateToPackageSearch() {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.HEADER_PACKAGE_SEARCH);
        return this.modal.open(PackageSearchComponent, overlayConfigFactory({dialogClass: 'modal-search'}, BSModalContext));
    };

    ngOnInit() { };
} 
