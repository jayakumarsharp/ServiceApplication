import { Component, OnInit } from '@angular/core';
import { ToasterService } from 'angular2-toaster';
import { ActivatedRoute, Router } from '@angular/router';

import { BiddingAppService } from '../bidding-app.service';
import { biddingAppConstants } from '../bidding-app.const';
import { biddingErrorConstants } from '../bidding-app.error.const';
import { ErrorHandlerService } from '../error-handler/error-handler.service';

@Component({
    template: '<div style="margin-top: 150px;">Loading...</div>'
})
export class ProjectInfoComponent implements OnInit {

    constructor(private toasterService: ToasterService,
                private appService: BiddingAppService,
                private activatedRoute: ActivatedRoute,
                private errorHandlerService: ErrorHandlerService,
                private router: Router) { };

    public projectKey;

    public getProjectByProjectKey() {
        this.getProjectKeyFromQueryParams();
        this.appService.getProjectByProjectKey(this.projectKey).subscribe(
            res => {
                let projectInfo = res.plain();
                if (!projectInfo.slug || projectInfo.slug === '') {
                    this.errorHandlerService.errorMessage = biddingErrorConstants.PROJECT_ID_NOT_FOUND;
                    this.router.navigateByUrl('bidding/error');
                    return;
                }
                sessionStorage.setItem(biddingAppConstants.SESSION_STORAGE_KEYS.PREFIX, projectInfo.slug);
                this.appService.projectInfo = projectInfo;
                this.appService.projectPrefix = projectInfo.slug;
                this.router.navigate(['bidding/package-browse']);
            },
            err => {
                // this.toasterService.pop('error', errorConstants.CONNECTION_REFUSED);
            }
         );
    };

    public getProjectKeyFromQueryParams() {
        this.projectKey = this.activatedRoute.snapshot.queryParams['PK'];
        let loginURL = this.activatedRoute.snapshot.queryParams['LoginUrl'];
        loginURL = loginURL + '/Login?AT=8&PK=' + this.projectKey;
        this.appService.setLoginURLByURL(loginURL);
    };

    ngOnInit() {
        this.getProjectByProjectKey();
    };
}
