export const biddingErrorConstants = {
    CONNECTION_REFUSED: 'Connection Refused',
    BIDDER_KEY_NOT_FOUND: 'Bidder key not found',
    PROJECT_ID_NOT_FOUND: 'Project Id not found',
    SESSION_STORAGE_NOT_SUPPORTED: 'Disable Privacy Mode in your browser to use Online Bidding'
}
