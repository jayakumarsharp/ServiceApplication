import { Directive, Output, EventEmitter, ElementRef, HostListener } from '@angular/core';

@Directive({ selector: '[number-only]' })

export class NumberOnlyDirective  {

    @Output()
    public sendValidatedAmount: EventEmitter<string> = new EventEmitter();

    constructor(private elementRef: ElementRef) {}

    @HostListener('input', ['$event']) handleKeyPressEvent(keyPress) {
        let event = <KeyboardEvent> keyPress;
        this.elementRef.nativeElement.value = (<HTMLInputElement>event.currentTarget).value.replace(/[^0-9]/g, '');
        this.sendValidatedAmount.emit(this.elementRef.nativeElement.value);
    }
}
