import { Directive, Input, ElementRef, Renderer} from '@angular/core';

@Directive({ selector: '[ellipse]'})
export class EllipseDirective {

    constructor(private elementRef: ElementRef,
                private renderer: Renderer) {}

    @Input()
    public isParentPackage: boolean;

    @Input()
    public isSlideViewPackage: boolean;

    @Input() set ellipse (packageName: string) {
        let spliceIndex = (window.innerWidth > 350) ? 25 : 17;

        if (this.isParentPackage && packageName.length > 46) {
            packageName = packageName.slice(0, 46);
            this.addEllipse(packageName);
            return;
        }

        if (this.isSlideViewPackage && packageName.length > 36) {
            packageName = packageName.slice(0, 36);
            this.addEllipse(packageName);
            return;
        }

        if (packageName.length > spliceIndex) { 
            packageName = packageName.slice(0, spliceIndex);
            this.addEllipse(packageName);
            return;
        }

        this.renderer.setElementProperty(this.elementRef.nativeElement, 'innerText', packageName);
    }

    public addEllipse(packageName) {
        let words: string[] = packageName.split(" ");
        words.pop();
        packageName = words.join(" ");
        packageName = packageName + "...";
        this.renderer.setElementProperty(this.elementRef.nativeElement, 'innerText', packageName);
    }
}
