import { Directive, ElementRef, Renderer, Attribute, Input, OnInit } from '@angular/core';

import { biddingAppConstants } from './../bidding-app.const';

@Directive({ selector: '[dynamic-height]' })
export class DynamicWindowHeightDirective implements OnInit{

    constructor(private elementRef: ElementRef,
                private renderer: Renderer) {}

    @Input() public gutterVspace: number;

    private setContentHeight() {
        this.gutterVspace = (sessionStorage.getItem(biddingAppConstants.SESSION_STORAGE_KEYS.BIDDER_KEY)) ? 530 : 410;
        const height = window.innerHeight - this.gutterVspace;
        this.renderer.setElementStyle(this.elementRef.nativeElement, 'max-height', height.toString() + 'px');
        this.renderer.setElementStyle(this.elementRef.nativeElement, 'overflow-y', 'auto');
    };

    private onWindowResize() {
        window.onresize = this.setContentHeight;
    };

    ngOnInit() {
        this.setContentHeight();
        this.onWindowResize();
    };
}