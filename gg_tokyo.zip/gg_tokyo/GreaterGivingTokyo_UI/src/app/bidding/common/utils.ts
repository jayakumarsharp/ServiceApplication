import { Injectable } from '@angular/core';
import * as _ from 'lodash';

import { biddingAppConstants } from './../bidding-app.const';

@Injectable()
export class Utils {

    constructor() { }

    public flooringOf(number: number) {
        return Math.floor(number);
    };

    public contains(value: string, pattern: string) {
        return  _.includes(value, pattern);
    };

    public getFilteredSponsors(sponsorList, projectInfo, noOfSponsorsToBeDisplayed) {
        let sponsors = sponsorList;
        sponsors = _.filter(sponsors, function(sponsor) {return sponsor.imgpath !== null;});
        let previousShowedSponsorIds = new Array();
        let previousShowedSponsorIdsStr = sessionStorage.getItem(biddingAppConstants.SESSION_STORAGE_KEYS.PREVIOUSLY_SHOWNED_SPONSOR_IDS);
        if (previousShowedSponsorIdsStr) {
            previousShowedSponsorIds = previousShowedSponsorIdsStr.split(',');
        }
        return this.setSponsors(sponsors, previousShowedSponsorIds, projectInfo, noOfSponsorsToBeDisplayed);
    };

    private setSponsors(sponsors, previousShowedSponsorIds, projectInfo, noOfSponsorsToBeDisplayed) {
        let filteredSponsors = [];
        let spliceStartIndex = 0; // default splice start and end index
        let spliceEndIndexDiff = 0;
        let sponsorsLength = sponsors.length;
        let noOfSponsors = this.setNoOfImagesToBeDisplayed(projectInfo, noOfSponsorsToBeDisplayed);


        let spliceEndIndex = (sponsorsLength > noOfSponsors) ? noOfSponsors : sponsorsLength;
        if (previousShowedSponsorIds.length) {
            let previousShowedSponsorsLastId = +previousShowedSponsorIds[previousShowedSponsorIds.length - 1];
            spliceStartIndex = _.findIndex(sponsors, {'ID': previousShowedSponsorsLastId});
            spliceStartIndex ++;
        }
        spliceEndIndexDiff = (spliceStartIndex + spliceEndIndex) - sponsorsLength - 1;
        if (projectInfo.logo_path) {
            filteredSponsors.push({imgpath: projectInfo.logo_path});
        }
        filteredSponsors.push(sponsors.splice(spliceStartIndex, spliceEndIndex));
        filteredSponsors = _.flatten(filteredSponsors);

        if (spliceEndIndexDiff > 0) {
            for (let i = 0; i <= spliceEndIndexDiff; i++) {
                filteredSponsors.push(sponsors[i]);
            }
        }
        previousShowedSponsorIds = [];
        filteredSponsors.forEach((sponsor) => { previousShowedSponsorIds.push(sponsor.ID);});
        sessionStorage.removeItem(biddingAppConstants.SESSION_STORAGE_KEYS.PREVIOUSLY_SHOWNED_SPONSOR_IDS);
        sessionStorage.setItem(biddingAppConstants.SESSION_STORAGE_KEYS.PREVIOUSLY_SHOWNED_SPONSOR_IDS, previousShowedSponsorIds.toString());
        return filteredSponsors;
    };

    private setNoOfImagesToBeDisplayed(projectInfo, noOfSponsorsToBeDisplayed) {
        let windowWidth = window.screen.availWidth;
        switch (true) {
            case (windowWidth < 417):
              noOfSponsorsToBeDisplayed = 2;
              break;
            case (windowWidth < 550):
              noOfSponsorsToBeDisplayed = 3;
              break;
            case (windowWidth < 670):
              noOfSponsorsToBeDisplayed = 4;
              break;
            case (windowWidth < 785):
              noOfSponsorsToBeDisplayed = 5;
              break;
            case (windowWidth < 1050):
              noOfSponsorsToBeDisplayed = 6;
              break;
        }
        return noOfSponsorsToBeDisplayed = (!projectInfo.logo_path) ? noOfSponsorsToBeDisplayed : noOfSponsorsToBeDisplayed - 1;
    };
}
