import { Directive, ElementRef, Renderer, Attribute, Input, OnInit, OnChanges } from '@angular/core';
import * as _ from 'lodash';

import { biddingAppConstants } from './../bidding-app.const';

@Directive({ selector: '[status-indicator]'})
export class PackageStatusIndicatorDirective implements OnInit, OnChanges{

    constructor(private elementRef: ElementRef,
                private renderer: Renderer) {}

    @Input() public packageStatus;
    @Input() public packageType;

    public setStatusIndicator() {
        if (this.packageType.toLowerCase() === biddingAppConstants.PACKAGE_TYPE.APPEAL) {
              return;
        };
        // remove all previous package status indicator classes
        let statusIndicatorClasses = Object.keys(biddingAppConstants.PACKAGE_STATUS_WITH_INDICATOR_CLASSES).map(key =>
                                                  biddingAppConstants.PACKAGE_STATUS_WITH_INDICATOR_CLASSES[key]);
        statusIndicatorClasses.forEach(statusIndicatorClass => {
          this.renderer.setElementClass(this.elementRef.nativeElement, statusIndicatorClass, false);
        });

        let classForStatus = (this.packageType.toLowerCase() !== biddingAppConstants.PACKAGE_TYPE.PREVIEW) ? biddingAppConstants.PACKAGE_STATUS_WITH_INDICATOR_CLASSES[this.packageStatus.toLowerCase()] :
                                                             biddingAppConstants.PACKAGE_STATUS_WITH_INDICATOR_CLASSES[this.packageType.toLowerCase()];
        this.renderer.setElementClass(this.elementRef.nativeElement, classForStatus, true);
    };
 
    ngOnInit() {
        this.setStatusIndicator();
    };

    ngOnChanges() {
        this.setStatusIndicator();
    };
}
