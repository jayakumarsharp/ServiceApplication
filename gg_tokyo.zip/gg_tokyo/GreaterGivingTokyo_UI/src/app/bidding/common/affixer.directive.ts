import { Directive, ElementRef, Renderer, Attribute, Input, OnInit } from '@angular/core';

@Directive({ selector: '[affixer]',
            host: {'(window:scroll)': 'onScroll()'}
 })
export class AffixerDirective{

    constructor(private elementRef: ElementRef,
                private renderer: Renderer) {}

    @Input() affixClass: string;
    @Input() affixOffsetTop: number;
    private setAffixerTop() {
    };

    onScroll() {
        this.setAffixerTop();
    };
}
