import { BrowserModule, Title } from '@angular/platform-browser';
import { Location, LocationStrategy, PathLocationStrategy, HashLocationStrategy } from '@angular/common';
import { NgModule } from '@angular/core';
import { HttpModule, JsonpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { ToasterModule } from 'angular2-toaster';
import { KSSwiperModule } from 'angular2-swiper';
import { FormsModule } from '@angular/forms';

import { Utils } from './common/utils';
import { BiddingAppComponent } from './bidding-app.component';
import { PackageBrowseModule } from './package-browse/package-browse.module';
import { appRoutes } from '../app.routing';
import { BiddingAppResolver } from './bidding-app.resolver';
import { AffixerDirective } from './common/affixer.directive';
import { DynamicWindowHeightDirective } from './common/dynamic-window-height.directive';
import { PackageSearchComponent } from './package-browse/package-search/package-search.component';
import { SharedModule } from './shared/shared.module';
import { SponsorsLogoComponent } from './shared/sponsors-logo/sponsors-logo.component';
import { BiddingAppService } from './bidding-app.service';
import { NoPackageFoundComponent } from './no-package-found/no-package-found.component';
import { BiddingAuthComponent } from './authentication/authentication.component';
import { AuthenticationService } from './authentication/authentication.service';
import { TermsAndConditionsComponent } from './terms-conditions/terms-conditions.component';
import { TakeTourComponent } from './take-tour/take-tour.component';
import { LearnMoreComponent } from './learn-more/learn-more.component';
import { ErrorHandlerComponent } from './error-handler/error-handler.component';
import { ProjectInfoComponent } from './project-info/project-info.component';
import { SlideOutMenuService } from './package-browse/slide-out-menu/slide-out-menu.service';
import { SlideOutMenuComponent } from './package-browse/slide-out-menu/slide-out-menu.component';
import { ErrorHandlerService } from './error-handler/error-handler.service';

@NgModule({
    declarations: [
        BiddingAppComponent,
        LearnMoreComponent,
        TakeTourComponent,
        BiddingAuthComponent,
        SlideOutMenuComponent,
        DynamicWindowHeightDirective,
        PackageSearchComponent,
        ProjectInfoComponent,
        NoPackageFoundComponent,
        TermsAndConditionsComponent,
        ErrorHandlerComponent,
        AffixerDirective,
    ],
    imports: [
        BrowserModule,
        FormsModule,
        SharedModule,
        HttpModule,
        JsonpModule,
        RouterModule.forRoot(appRoutes),
        ToasterModule,
        KSSwiperModule,
        PackageBrowseModule,
    ],
    providers: [
        BiddingAppResolver,
        BiddingAppService,
        Utils,
        SlideOutMenuService,
        AuthenticationService,
        BiddingAuthComponent,
        SponsorsLogoComponent,
        ErrorHandlerService,
        Title,
    ],
    entryComponents: [PackageSearchComponent]
})
export class BiddingAppModule { }
