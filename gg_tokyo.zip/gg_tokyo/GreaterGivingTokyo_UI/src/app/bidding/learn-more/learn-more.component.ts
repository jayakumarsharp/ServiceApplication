import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: './learn-more.component.html',
})

export class LearnMoreComponent { 

    ngOnInit() {
        window.scroll(0,0);
    }
}
