import { BrowserModule, Title } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { SponsorsLogoComponent } from './sponsors-logo/sponsors-logo.component';
import { SponsorsService } from './sponsors-logo/sponsors.service';

@NgModule({

    declarations: [
        SponsorsLogoComponent
    ],
    imports: [
        CommonModule,
        BrowserModule,
    ],
    providers: [
        SponsorsService,
        Title,
    ],
    exports: [SponsorsLogoComponent]
})
export class SharedModule { }
