import { Injectable } from '@angular/core';
import {Restangular} from 'ng2-restangular';

@Injectable()
export class SponsorsService {

    constructor(private restangualr: Restangular) { }

    public getSponsors(prefix: string) {
        let queryParams = {'prefix': prefix};
        return this.restangualr.oneUrl('/GetSponsorImagesByPrefix').get(queryParams);
    };
}
