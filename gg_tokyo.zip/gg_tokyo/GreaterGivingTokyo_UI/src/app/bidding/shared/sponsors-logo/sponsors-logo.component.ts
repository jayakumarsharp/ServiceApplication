import { Component, Input } from '@angular/core';

@Component({
  selector: 'sponsors-logo',
  templateUrl: './sponsors-logo.component.html',
})
export class SponsorsLogoComponent {

    constructor() { }

    @Input()
    public sponsors = [];
}
