import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ToasterService, ToasterConfig} from 'angular2-toaster';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { SignalR} from 'ng2-signalr';
import * as _ from 'lodash';

import { biddingAppConstants } from './bidding-app.const';
import { biddingErrorConstants } from './bidding-app.error.const';
import { AppService } from '../app.service';
import { appConstants } from '../app.const';
import { BiddingAppService } from './bidding-app.service';
import { SponsorsService } from './shared/sponsors-logo/sponsors.service';
import { BiddingAuthComponent } from './authentication/authentication.component';
import { ErrorHandlerService } from './error-handler/error-handler.service';
import { SlideOutMenuService } from './package-browse/slide-out-menu/slide-out-menu.service';
import { PackageBrowseService } from './package-browse/package-browse.service';
import { PackageSearchComponent } from './package-browse/package-search/package-search.component';
import { Utils } from './common/utils';

@Component({
  selector: 'bidding-root',
  templateUrl: './bidding-app.html',
  styleUrls: ['../../assets/css/font.css', '../../assets/css/swiper.css', '../../assets/css/toaster.css']
})

export class BiddingAppComponent implements OnInit {

    constructor(private router: Router,
                private modal: Modal,
                private overlay: Overlay,
                private signalR: SignalR,
                private toasterService: ToasterService,
                private vcRef: ViewContainerRef,
                private appService: AppService,
                private biddingAppService: BiddingAppService,
                private errorHandlerService: ErrorHandlerService,
                private biddingAuthComponent: BiddingAuthComponent,
                private packageBrowseService: PackageBrowseService,
                private slideOutMenuService: SlideOutMenuService,
                private sponsorsService: SponsorsService,
                private utils: Utils) {
                    overlay.defaultViewContainer = vcRef;
                }

    // toaster configurations
    public toasterconfig : ToasterConfig =
        new ToasterConfig({
        showCloseButton: true,
        tapToDismiss: false,
        timeout: 5000,
    });

    public projectInfo = {
        officialTime : '',
        timezone: '',
        appeal_package : 0,
        allowMaxBidding: false,
        logo_path: '',
        projectKey: 0
    };

    public bidderInfo;
    public loginURL: string;
    public sponsors = [];

    public showSlideOutMenu = false;
    public isDetailViewActive = false;
    public isLoggedInUser = false;
    public hasError = false;
    public isAppealPackage: boolean;

    public onScrollDown() {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.MARQUEE_PULL_DOWN);
        this.biddingAppService.onScrollDown();
    };

    public onSelectOutbidNotification() {
        this.packageBrowseService.isFavorite = false;
        this.packageBrowseService.searchedIndex = null;
        this.packageBrowseService.categoryOrPackageType = null;
        this.packageBrowseService.isBidsFilterActive = true;
        this.biddingAppService.setIsOutbidNotificationSelected(true);
        this.biddingAppService.setTitle(this.biddingAppService.projectInfo.Organization + ' | OutBid | Greater Giving Online Bidding');
    };

    public onNavigateToTermsAndConditions() {
        this.router.navigateByUrl('bidding/terms-conditions');
    };

    public onNavigateToTakeTour() {
        this.router.navigateByUrl('bidding/take-tour');
    };

    public onSlideOutMenuToggle(isFromSlideOoutMenuIcon) {
        if (!isFromSlideOoutMenuIcon && !this.showSlideOutMenu) {
            return;
        }
        this.showSlideOutMenu = !this.showSlideOutMenu;
        // this.slideOutMenuService.showSlideViewChanged(this.showSlideOutMenu);
    };

    public onStartBidding() {
        this.appService.setBusy();
    };

    public onOpenSearchModel() {
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.HEADER_PACKAGE_SEARCH);
        return this.modal.open(PackageSearchComponent, overlayConfigFactory({dialogClass: 'modal-search'}, BSModalContext));
    };

    public onNavigateToHome() {
        this.slideOutMenuService.showSlideViewChanged(false);
        this.appService.setBusy();
        this.biddingAppService.isNavigateToHome = true;
        this.packageBrowseService.isFavorite = false; // not to perform favorite action in category type
        this.packageBrowseService.hideBidsFilter();
        this.packageBrowseService.categoryOrPackageType = undefined; // not to show the label for the packages
        this.biddingAppService.isOutbidTab = false; // not to show outbid tab in category type
        this.packageBrowseService.isBidsFilterActive = false;
        biddingAppConstants.PAGE_NO = 1;
        this.packageBrowseService.getPackages(this.biddingAppService.projectPrefix, 'All', biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
            res => {
                this.cbsgetPackagesByCategory(res.plain());
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private cbsgetPackagesByCategory(packagesByCategory) {
       this.biddingAppService.navigateToPackageBrowseView();
       setTimeout(() => {this.biddingAppService.onScrollDown()}, 100);
       this.packageBrowseService.packages = packagesByCategory;
       this.packageBrowseService.searchedIndex = undefined;
       setTimeout(() => {this.biddingAppService.setIsCategoryOrPackageTypeSelected(true); }, 200);
   };

    public listenEvents() {
        this.packageBrowseService.isDetailViewActive.subscribe(value => this.isDetailViewActive = value);
        this.biddingAppService.isLoggedInUser.subscribe(value => {
            this.isLoggedInUser = value;
            this.bidderInfo = this.slideOutMenuService.bidderInfo;
        });
        this.biddingAppService.loginURL.subscribe(loginURL => {
            this.setLoginURL(loginURL);
        });
        this.errorHandlerService.hasError.subscribe(value => this.hasError = value);
        this.slideOutMenuService.showSlideViewChange.subscribe(isShowSlideView => this.showSlideOutMenu = isShowSlideView);
    }; 

    private getProject() {
        this.projectInfo = this.biddingAppService.projectInfo;
        this.setLoginURL('');
        this.checkAppealOnlyEvent(this.projectInfo);
    };

    private getSponsors() {
        this.sponsorsService.getSponsors(this.biddingAppService.projectPrefix).subscribe(
            res => {
                this.sponsors = this.utils.getFilteredSponsors(res.plain(), this.biddingAppService.projectInfo, biddingAppConstants.NO_OF_SPONSORS_TO_DISPLAY);
                this.biddingAppService.sponsors = this.sponsors;
                this.biddingAppService.setSponsorsReceived(true);
            },
            err => {

            }
        );
    };

    private checkAppealOnlyEvent(projectInfo) {
        if (projectInfo.appeal_only) {
            this.router.navigateByUrl('/bidding/package-browse/package/' + projectInfo.appeal_package);
        }
    };

    private getBidderInfoByBidderKey() {
        if (!this.bidderInfo && sessionStorage.getItem(biddingAppConstants.SESSION_STORAGE_KEYS.TOKEN)) {
            let bidderKey = sessionStorage.getItem(biddingAppConstants.SESSION_STORAGE_KEYS.BIDDER_KEY);
            this.biddingAuthComponent.getBidderByBidderKey(bidderKey);
        }
    }; 

    public onFilterFavorites() {
        this.appService.setBusy();
        this.trackEvents(appConstants.EVENT_CATEGORY.BUTTON, appConstants.EVENT_ACTION.CLICK, appConstants.EVENT_LABELS.HEADER_FAVU_FILTER);
        this.biddingAppService.setTitle(this.biddingAppService.projectInfo.Organization + ' | Favorites | Greater Giving Online Bidding');
        this.packageBrowseService.isBidsFilterActive = false;
        this.packageBrowseService.searchedIndex = undefined; //to hide the title of the search item when favorites is clicked
        this.packageBrowseService.categoryOrPackageType = undefined; //to hide the title of the category or package type item when favorites is clicked
        this.packageBrowseService.isBidsFilterActive = false; //to hide the bids title when favorites is clicked
        this.biddingAppService.isOutbidTab = false; //to hide outbid
        biddingAppConstants.PAGE_NO = 1;
        this.slideOutMenuService.getFavoritesPackages(this.biddingAppService.projectPrefix,biddingAppConstants.PAGE_NO, biddingAppConstants.RECORDS_PER_PAGE).subscribe(
            res => {
                this.cbsOnFilterFavorites(res);
            },
            err => {
                // this.toasterService.pop('error', biddingErrorConstants.CONNECTION_REFUSED);
            }, () => {
                this.appService.resetBusy();
            }
        );
    };

    private cbsOnFilterFavorites(res) {
        this.packageBrowseService.packages = res.plain();
        this.packageBrowseService.isFavorite = true;
        this.biddingAppService.navigateToPackageBrowseView();
        setTimeout(() => {this.biddingAppService.onScrollDown()}, 100);
        this.biddingAppService.setIsCategoryOrPackageTypeSelected(true);
        this.slideOutMenuService.showSlideViewChanged(false);
        if (this.router.url.match('/package/')) {
            this.router.navigateByUrl('/bidding/package-browse');
            setTimeout(() => {this.biddingAppService.onScrollDown()}, 100);
        }
    };

    private setLoginURL(loginURL) {
        if (loginURL) {
            this.loginURL = loginURL;
        } else {
            this.loginURL = this.biddingAppService.setLoginURL('');
            this.biddingAppService.loginUrl = this.loginURL;
        }
    };

    private watchRouting() {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.biddingAppService.setPageTitleByPage(event.url,[]);
            }
        });
    };

    private trackEvents(eventCategory, eventAction, eventLabel) {
        this.appService.trackEvents(eventCategory, eventAction, eventLabel);
    };

    private connectSignalR() {
        this.signalR.connect().then(res => {
            res.listenFor('DisplayUpdateProject').subscribe((prefix) => {
                if (prefix === this.biddingAppService.projectPrefix) {
                    this.getProjectDetails();
                }
            });
        });
    };

    private getProjectDetails() {
        this.biddingAppService.getProject(this.biddingAppService.projectPrefix).subscribe(
                res => {
                    this.biddingAppService.projectInfo = res.plain();
                    this.biddingAppService.setIsProjectUpdated();
                },
                err => {

                }, () => {

                }
            );
    };

    ngOnInit() {
        if (!this.appService.isSessionStorageAccessible ||
            !this.biddingAppService.projectInfo.slug ||
             this.biddingAppService.projectInfo.slug === '') {
            this.errorHandlerService.hasError.subscribe(value => this.hasError = value);
            this.router.navigateByUrl('bidding/error');
            return;
        }
        this.getBidderInfoByBidderKey();
        this.getProject();
        this.biddingAppService.startOfficialTimer();
        this.listenEvents();
        this.connectSignalR();
        this.watchRouting();
        this.getSponsors();
    };
}
