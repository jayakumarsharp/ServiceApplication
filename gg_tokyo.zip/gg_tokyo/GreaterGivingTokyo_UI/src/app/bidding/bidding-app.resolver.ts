import { Injectable } from '@angular/core';
import { Resolve, Router} from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import * as _ from 'lodash';

import { AppService } from '../app.service';
import { BiddingAppService } from './bidding-app.service';
import { biddingAppConstants } from './bidding-app.const';
import { biddingErrorConstants } from './bidding-app.error.const';
import { ErrorHandlerService } from './error-handler/error-handler.service';
import { Utils } from './common/utils';

@Injectable()
export class BiddingAppResolver implements Resolve<any> {

    constructor(private router: Router,
                private biddingAppService: BiddingAppService,
                private appService: AppService,
                private errorHandlerService: ErrorHandlerService,
                private utils: Utils) { }

    resolve(): Promise<boolean> {
        return new Promise((resolve, reject) => {
            if (!this.appService.isSessionStorageAccessible) {
                this.errorHandlerService.errorMessage = biddingErrorConstants.SESSION_STORAGE_NOT_SUPPORTED;
                resolve();
            }
            if (this.biddingAppService.projectInfo.prefix) {
                return true;
            }
            let prefix = this.biddingAppService.projectPrefix ? this.biddingAppService.projectPrefix :
                                                                sessionStorage.getItem(biddingAppConstants.SESSION_STORAGE_KEYS.PREFIX);
            if (!prefix) {
                let url = window.location.href;
                if (this.utils.contains(this.router.url, '/error')) {
                    return true;
                }
                prefix = url.slice(url.indexOf('//') + 2, url.indexOf('.'));
            }
            this.biddingAppService.projectPrefix = prefix;
            this.biddingAppService.getProject(prefix).subscribe(
                res => {
                    let projectInfo = res.plain();
                    sessionStorage.setItem(biddingAppConstants.SESSION_STORAGE_KEYS.PREFIX, prefix);
                    this.biddingAppService.projectInfo = projectInfo;
                    resolve();
                },
                err => {
                    this.errorHandlerService.errorMessage = biddingErrorConstants.PROJECT_ID_NOT_FOUND;
                    this.routeToErrorPage();
                }, () => {  // finally block
                    return true;
                }
            );
        });
    };

    private routeToErrorPage() {
        this.router.navigateByUrl('bidding/error');
    };
}
