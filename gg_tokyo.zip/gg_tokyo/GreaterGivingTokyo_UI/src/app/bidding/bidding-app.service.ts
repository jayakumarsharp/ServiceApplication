import {Restangular} from 'ng2-restangular';
import { Injectable, EventEmitter } from '@angular/core';
import { Title } from '@angular/platform-browser';
import * as moment from 'moment-timezone';
import { Router } from '@angular/router';
import * as $ from 'jquery';

import { Utils } from './common/utils';
import { AppService } from '../app.service';
import { biddingAppConstants } from './bidding-app.const';

@Injectable()
export class BiddingAppService {

    constructor(private restangular: Restangular,
                private router: Router,
                private utils: Utils,
                private appService: AppService,
                private titleService: Title) {};

    public projectInfo = {
        officialTime : '',
        timezone: '',
        appeal_package : 0,
        allowMaxBidding: false,
        appeal_only: '',
        logo_path: '',
        projectKey: 0,
        prefix: '',
        Organization: '',
        slug: ''
    };

    public sponsors;
    public projectPrefix: string;
    public loginURL = new EventEmitter<string>();
    public loginUrl: string;

    public isOutbidTab: boolean = false;
    public showOutbidNotification: boolean = false;
    public isLoggedInUser = new EventEmitter<boolean>();
    public isProjectUpdated = new EventEmitter<boolean>();
    public isOutbidNotificationSelected = new EventEmitter<boolean>();
    public isAppealPackage = new EventEmitter<boolean>();
    public isBidsFilterSelected =  new EventEmitter<boolean>();
    public isCategoryOrPackageTypeSelected = new EventEmitter<boolean>();
    public isSponsorsReceived = new EventEmitter<boolean>();
    public isNavigateToHome: boolean = false;

    public setLoginURLByURL(loginURL) {
        this.loginURL.emit(loginURL);
    };

    public setIsProjectUpdated() {
        this.isProjectUpdated.emit(true);
    };

    public setSponsorsReceived(isSponsorsReceived) {
        this.isSponsorsReceived.emit(isSponsorsReceived);
    };

    public setLoginURL(packageID) {
        let url = window.location.href;
        let loginUrlForDomain;
        if (this.utils.contains(url, 'dev.ggo.bid')) {
            loginUrlForDomain = biddingAppConstants.LOGIN_URL_FOR_DOMAINS.DEV;
        } else if (this.utils.contains(url, 'next.ggo.bid')) {
            loginUrlForDomain = biddingAppConstants.LOGIN_URL_FOR_DOMAINS.NEXT;
        } else if (this.utils.contains(url, 'preview.ggo.bid')) {
            loginUrlForDomain = biddingAppConstants.LOGIN_URL_FOR_DOMAINS.PREVIEW;
        } else if (this.utils.contains(url, 'stage.ggo.bid')) {
            loginUrlForDomain = biddingAppConstants.LOGIN_URL_FOR_DOMAINS.STAGE;
        } else if (!loginUrlForDomain) {
            loginUrlForDomain = biddingAppConstants.LOGIN_URL_FOR_DOMAINS.PROD;
        }
        let loginURL = 'https://' + loginUrlForDomain + '/Login?AT=8&PK=' + this.projectInfo.projectKey;

        if (packageID && this.utils.contains(url, '/package/')) {
            let returnURL = 'https://' + window.location.host + '/b/?packageId=' + packageID;
            loginURL = loginURL + '&ReturnUrl=' + encodeURIComponent(returnURL);
        }
        return loginURL;
    };

    public onScrollDown() {
        let sponorsBannerHeight = (this.projectInfo.logo_path || (this.sponsors && this.sponsors.length)) ? 100 : 115;
        if (this.isNavigateToHome) {
            let height = window.innerHeight - sponorsBannerHeight;
            $('html, body').animate({scrollTop: height},1000);
            this.isNavigateToHome = false;
            return;
        }
        window.scrollTo(0, window.innerHeight - sponorsBannerHeight);
    };

    public setIsBidsFilterSelected(isBidsFilterSelected) {
        this.isBidsFilterSelected.emit(true);
    };

    public setIsCategoryOrPackageTypeSelected(isCategoryOrPackageTypeSelected) {
        this.isCategoryOrPackageTypeSelected.emit(isCategoryOrPackageTypeSelected);
    };

    public getPackageTypesByProject(projectName) {
        let params = {'prefix': projectName};
        return this.restangular.oneUrl('/GetPackageTypesByProject').get(params);
    };

    public getCategoryTypesByProject(projectName) {
        let params = {'prefix': projectName};
        return this.restangular.oneUrl('/GetCategoryTypesByProject').get(params);
    };

    public getProject(projectPrefix) {
        let params = {'prefix': projectPrefix};
        return this.restangular.oneUrl('/GetProject').get(params);
    };

    public getProjectByProjectKey(projectKey) {
        let params = {'projectKey': projectKey};
        return this.restangular.oneUrl('/GetProjectByProjectKey').get(params);
    };

    public startOfficialTimer() {
        setInterval(() => {
            this.projectInfo.officialTime = this.appService.convertTimeByTimeZone(new Date(), this.projectInfo.timezone)
                                                           .format(biddingAppConstants.DATE_TIME_FORMATS.TIME_WITH_ZONE);
        }, 1000);
    };

    public setIsAppealPackage(isAppealPackage: boolean) {
        return this.isAppealPackage.emit(isAppealPackage);
    };

    public setIsLoggedInUser(isLoggedInUser: boolean) {
        return this.isLoggedInUser.emit(isLoggedInUser);
    };

    public navigateToPackageBrowseView() {
        if (this.router.url.match('/package/') ||
            this.router.url.match('/terms-conditions') ||
            this.router.url.match('/take-tour') ||
            this.router.url.match('/learn-more') ||
            this.router.url.match('no-package-found')) {
                this.router.navigateByUrl('/bidding/package-browse');
                this.setLoginURLByURL(this.setLoginURL(''));
        }
    };

    public setIsOutbidNotificationSelected(isOutbidNotificationSelected: boolean) {
       return this.isOutbidNotificationSelected.emit(isOutbidNotificationSelected);
    };

    public setTitle(title: string) {
        this.titleService.setTitle(title);
    };

    public setPageTitleByPage(url, detailViewPackage) {
        if (this.utils.contains(url, '/package-browse/package') || (this.utils.contains(url, '/package-browse/package') && (detailViewPackage.id === this.projectInfo.appeal_package))) {
            this.setTitle(this.projectInfo.Organization + ' | ' + detailViewPackage.itemnumber + ' | ' + detailViewPackage.itemname + ' | Greater Giving Online Bidding');
            return;
        }
        if (this.utils.contains(url, '/terms-conditions')) {
            this.setTitle(this.projectInfo.Organization  + ' | '  + 'Terms | Greater Giving Online Bidding');
        }
        if (this.utils.contains(url, '/learn-more')) {
            this.setTitle(this.projectInfo.Organization  + ' | '  + 'Learn More | Greater Giving Online Bidding');
        }
        if (this.utils.contains(url, '/take-tour')) {
            this.setTitle(this.projectInfo.Organization  + ' | '  + 'Tour | Greater Giving Online Bidding');
        }
        if (this.utils.contains(url, '/error')) {
            this.setTitle('404 Not Found | Greater Giving Online Bidding')
            return;
        }
        if (this.utils.contains(url, '/package-browse')) {
            this.setTitle(this.projectInfo.Organization + ' | Greater Giving Online Bidding');
            return;
        }
    };
}
