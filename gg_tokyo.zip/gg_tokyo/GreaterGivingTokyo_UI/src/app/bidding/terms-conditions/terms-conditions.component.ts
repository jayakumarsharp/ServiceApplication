import { Component, OnInit } from '@angular/core';

import { BiddingAppService } from './../bidding-app.service';
import { PackageBrowseService } from '../package-browse/package-browse.service';

@Component({
  selector: 'app-terms-conditions',
  templateUrl: './terms-conditions.component.html',
})
export class TermsAndConditionsComponent implements OnInit {

    constructor(private biddingAppService: BiddingAppService) { }

    public projectInfo;

    private getProjectInfo() {
        this.projectInfo = this.biddingAppService.projectInfo;
    };

    public listenEvents() {
        this.biddingAppService.isProjectUpdated.subscribe(isProjectUpdated => {
                this.getProjectInfo();
            }
        );
    };

    ngOnInit() {
      this.getProjectInfo();
      this.listenEvents();
    };
}
