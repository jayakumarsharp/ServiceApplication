import { Component } from '@angular/core';

import { PackageBrowseService } from '../package-browse/package-browse.service';
import { BiddingAppService } from '../bidding-app.service';
import { AppService } from '../../app.service';
import { biddingAppConstants } from '../bidding-app.const';

@Component({
    templateUrl: './take-tour.component.html',
})

export class TakeTourComponent{

    constructor(private packageBrowseService: PackageBrowseService,
                private appService: AppService,
                private biddingAppService: BiddingAppService) { }

    public onNavigateToHome() {
        this.appService.setBusy();
        this.biddingAppService.navigateToPackageBrowseView();
        setTimeout(() => {this.biddingAppService.onScrollDown()}, 100);
        setTimeout(() => {this.appService.resetBusy()}, 500);
    };
}

