export const biddingAppConstants = {
    SESSION_STORAGE_KEYS: {
        BIDDER_KEY: 'bidderKey',
        TOKEN: 'token',
        SELECTED_PACKAGE_ID_DETAIL: 'selectedPackaageIdForDetail',
        SELECTED_PACKAGE_PAGE: 'selectedPackagePage',
        PREFIX: 'prefix',
        LOGIN_URL: 'bidderLoginURL',
        PREVIOUSLY_SHOWNED_SPONSOR_IDS: 'previousShowedSponsorIds',
        SHOW_SPONSER: 'showSponser',
        SPONSER_UPDATE: 'sponserUpdate',
        COLOR: 'color',
        THEME: 'theme',
        DONATION_GOAL: 'donationGoal',
        METAPHOR: 'metaphor',
        SHOW_METAPHOR: 'showMetaphor',
        SHOW_DONORS: 'showDonors',
        SHOW_DONATION_AMOUNT: 'showDonationAmount'
    },

    RECORDS_PER_PAGE: 50,
    PAGE_NO: 1,
    NO_OF_SPONSORS_TO_DISPLAY: 9,

    BIDS_FILTER: {
        ALL: 'All',
        WINNING: 'Winning',
        OUTBID: 'Out Bid',
    },

    BIDS_FILTER_TITLE: {
        ALL: 'All Bids',
        WINNING: 'Currently Winning Bids',
        OUTBID: 'Currently Outbid',
    },


    PACKAGE_TYPE: {
       REGULAR: 'regular',
       MULTISALE: 'givers',
       APPEAL:   'appeal',
       DONATION: 'donation',
       PREVIEW:  'live'
    },

    PACKAGE_STATUS: {
        ALL: 'All',
        OPENING: 'Opening',
        WON: 'Won',
        WINNING: 'Winning',
        OUTBID: 'Out Bid',
        SOLD: 'Sold',
        CLOSED: 'Closed'
    },

    BIDDING_TYPES: {
        BID: 'Next increment Bid',
        BUY: 'Buy Now',
        BID_MORE: 'Bid More',
        DONATE: 'Donate Now',
        BUY_MULTISALE: 'Buy Multisale',
        APPEAL_DONATE: 'Appeal donote'
    },

    PACKAGE_STATUS_WITH_INDICATOR_CLASSES: {
        'live': 'preview',
        'opening': 'opening',
        'sold': 'sold',
        'won': 'won',
        'out bid': 'outbid',
        'winning': 'winning',
        'closed': 'closed'
    },

    DATE_TIME_FORMATS: {
        DEFAULT_TIME:  '00:00:00',
        TIME_WITH_ZONE: 'hh:mm:ss A z',
        DATE_TIME_WITH_ZONE: 'ddd hh:mm A z MM/DD/YY'
    },

    LOGIN_URL_FOR_DOMAINS: {
        DEV: 'supporter.future.greatergiving.com',
        NEXT : 'supporter.next.greatergiving.com',
        PREVIEW : 'supporter.preview.greatergiving.com',
        STAGE : 'supporter.stage.greatergiving.com',
        PROD : 'supporter.greatergiving.com'
    }
};
