import { Routes } from '@angular/router';

import { BiddingAppComponent } from './bidding/bidding-app.component';
import { BiddingAppResolver } from './bidding/bidding-app.resolver';
import { BiddingAuthComponent } from './bidding/authentication/authentication.component';
import { LearnMoreComponent } from './bidding/learn-more/learn-more.component';
import { TermsAndConditionsComponent } from './bidding/terms-conditions/terms-conditions.component';
import { TakeTourComponent } from './bidding/take-tour/take-tour.component';
import { ErrorHandlerComponent } from './bidding/error-handler/error-handler.component';
import { ProjectInfoComponent } from './bidding/project-info/project-info.component';
import { PackageBrowseComponent } from './bidding/package-browse/package-browse.component';
import { PackagesResolver } from './bidding/package-browse/packages.resolver';
import { PackageBrowseSlidesComponent } from './bidding/package-browse/package-slides/package-browse-slides.component';
import { PackageDetailComponent } from './bidding/package-browse/package-detail/package-detail.component';
import { AdminComponent } from './ggo-admin/admin/admin.component';
import { AdminLogoutComponent } from './ggo-admin/admin/logout/logout.component';
import { ReportComponent } from './ggo-admin/admin/report/report.component';
import { AdminAuthComponent } from './ggo-admin/admin/authentication/authentication.component';
import { HomeComponent } from './ggo-admin/admin/home/home.component';
import { PackagesComponent } from './ggo-admin/admin/all-packages/packages.component';
import { BiddersComponent } from './ggo-admin/admin/all-bidders/all-bidders.component';
import { AppealBoardComponent } from './ggo-admin/appeal-board/appeal-board.component';
import { LeaderBoardComponent } from './ggo-admin/leader-board/leader-board.component';
import { CountdownBoardComponent } from './ggo-admin/count_down-board/count_down-board.component';
import { BidderDetailComponent } from './ggo-admin/admin/bidder-detail/bidder-detail.component';
import { PackageInfoComponent } from './ggo-admin/admin/package-info/package-info.component';
import { SendEmailMessageComponent } from './ggo-admin/admin/send-email/send-email-message.component';
import { SendSmsMessageComponent } from './ggo-admin/admin/send-sms/send-sms-message.component';
import { NoPackageFoundComponent } from './bidding/no-package-found/no-package-found.component';
import { PackageBrowseSlidesContainerComponent } from './bidding/package-browse/package-slides/package-browse-slides-container.component';


export const appRoutes: Routes = [
    /* Bidding Application Routings **/
    { path: '', redirectTo: '/bidding/package-browse', pathMatch: 'full' },
    { path: 'bidding', component: BiddingAppComponent, resolve: { appResolver: BiddingAppResolver},
      children: [
        { path: 'package-browse', component: PackageBrowseComponent, resolve: { packageResolver: PackagesResolver},
          children: [
            { path: 'slide-view/:id', component: PackageBrowseSlidesContainerComponent },
            { path: 'package/:id', component: PackageDetailComponent }
          ]
        },
        { path: 'learn-more', component: LearnMoreComponent },
        { path: 'no-package-found' , component: NoPackageFoundComponent },
        { path: 'terms-conditions', component: TermsAndConditionsComponent },
        { path: 'take-tour', component: TakeTourComponent },
        { path: 'error', component: ErrorHandlerComponent },
      ]
    },
    { path: 'b/:id', component: BiddingAuthComponent },
    { path: 'p/', component: ProjectInfoComponent },

    /* GGO Admin Pages Routings **/
    { path: 'admin', component: AdminComponent,
        children: [
            { path: 'home', component: HomeComponent },
            { path: 'packages', component: PackagesComponent },
            { path: 'bidders', component: BiddersComponent },
            { path: 'bidder-detail/:id', component: BidderDetailComponent },
            { path: 'package-info/:id', component: PackageInfoComponent },
            { path: 'send-email', component: SendEmailMessageComponent },
            { path: 'send-sms', component: SendSmsMessageComponent }
        ]
    },
    { path: 'report', component: ReportComponent },
    { path: 'logout', component: AdminLogoutComponent },
    { path: 'ad/:id', component: AdminAuthComponent },
    { path: 'appeal-board', component: AppealBoardComponent },
    { path: 'leader-board', component: LeaderBoardComponent },
    { path: 'countdown-board', component: CountdownBoardComponent },
    { path: '**', redirectTo: 'bidding/error' }
];
