import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { APP_BASE_HREF } from '@angular/common';
import { RestangularModule } from 'ng2-restangular';

import { MainAppComponent } from './app.component';
import { appRoutes } from './app.routing';
import { restangularConfig } from './app.rest-angular';
import { AppService } from './app.service';
import { BiddingAppModule } from './bidding/bidding-app.module';
import { GGOAdminModule } from './ggo-admin/ggo-admin.module';
import { SharedModule } from './bidding/shared/shared.module';
import { AppCommonModule } from './common/common-module';
import { SpinnerLoaderComponent } from './common/spinner-loader/spinner-loader.component';

@NgModule({
    declarations: [
        MainAppComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        RouterModule,
        RouterModule.forRoot(appRoutes, {useHash: false}),
        RestangularModule.forRoot(restangularConfig),
        BiddingAppModule,
        GGOAdminModule,
        SharedModule,
        AppCommonModule
    ],
    providers: [
        {
            provide: APP_BASE_HREF,
            useValue: '/'
        },
        Title,
        AppService,
        SpinnerLoaderComponent
    ],
    bootstrap: [
        MainAppComponent
    ],
    entryComponents: []
})
export class AppModule { }
