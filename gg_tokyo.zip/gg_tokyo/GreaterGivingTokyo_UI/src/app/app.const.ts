export const appConstants = {

    GOOGLE_TRACKING_IDS: {
        DEV: 'UA-104765693-5',
        NEXT: 'UA-104765693-4',
        PREVIEW: 'UA-104765693-3',
        STAGE: 'UA-104765693-2',
        PROD: 'UA-104765693-1',
        RELEASE: 'UA-104765693-6',
    },

    EVENT_CATEGORY: {
        BUTTON: 'Button',
        LINK: 'Link',
        LIST: 'List'
    },

    EVENT_ACTION: {
        CLICK: 'Click',
        SELECT: 'Select'
    },

    EVENT_LABELS: {
        /* slide view**/
        SLIDE_OUT_FAVU_FILTER: 'Slide-out-menu | Favourites Filter',
        SLIDE_OUT_BIDS_FILTER: 'Slide-out-menu | Bids Filter',
        SLIDE_OUT_APPEAL_PACKAGE: 'Slide-out-menu | Appeal Package',
        SLIDE_OUT_ACT_NOW_FILTER: 'Slide-out-menu | Act Now Filter',
        SLIDE_OUT_CATEGORY_FILTER: 'Slide-out-menu | Category Filter',
        /* app header**/
        HEADER_FAVU_FILTER: 'Header | Favourites Filter',
        HEADER_PACKAGE_SEARCH: 'Package Search',
        /* package browse view**/
        MARQUEE_PULL_DOWN: 'Marquee | Pull Down icon',
        BROWSE_PACKAGE_SELECT: 'Browse-view | Package Select',
        BROWSE_BIDS_FILTER: 'Browse-view | Bids Filter',
        BROWSE_ADD_FAVU: 'Browse-view | Add to Favourites',
        BROWSE_APPEAL_PACKAGE_SELECT: 'Browse-view | Appeal Package',
        /* package slide view**/
        SLIDE_PREV_PACKAGE: 'Slide-view | Previous Packages',
        SLIDE_NEXT_PACKAGE: 'Slide-view | Next Packages',
        SLIDE_CLOSE: 'Slide-view | Close',
        SLIDE_DETAIL: 'Slide-view | Detail Package',
        SLIDE_ADD_FAVU: 'Slide-view | Add to Favourites',
        SLIDE_BID: 'Slide-view | Bid',
        SLIDE_BID_MORE: 'Slide-view | Bid More',
        SLIDE_BID_MORE_PLACE_BID: 'Slide-view | Bid More | Place Bid',
        SLIDE_BID_MORE_MAX_BID: 'Slide-view | Bid More | Set Max Bid',
        SLIDE_BUY: 'Slide-view | Buy Package',
        SLIDE_BUY_MULTI: 'Slide-view | Buy Multi Sale Package',
        SLIDE_DONATE: 'Slide-view | Donate',
        /* package slide view**/
        DETAIL_ADD_FAVU: 'Detail-view | Add to Favourites',
        DETAIL_BID: 'Detail-view | Bid',
        DETAIL_BID_MORE: 'Detail-view | Bid More',
        DETAIL_BID_MORE_PLACE_BID: 'Detail-view | Bid More Place Bid',
        DETAIL_BID_MORE_MAX_BID: 'Detail-view | Bid More Set Max Bid',
        DETAIL_BUY: 'Detail-view | Buy Package',
        DETAIL_BUY_MULTI: 'Detail-view | Buy Sale Package',
        DETAIL_DONATE: 'Detail-view | Donate',
        DETAIL_APPEAL_DONATE: 'Detail-view | Appeal Package Donate',
        DETAIL_APPEAL_DONATE_CUSTOM: 'Detail-view | Appeal Donate | Custom Amount',
        DETAIL_RELATED_ADD_FAVU: 'Detail-view | Related Package Add to Favourites',
        DETAIL_RELATED_PACKAGE: 'Detail-view | Related Package',
        DETAIL_APPEAL_PACKAGE: 'Detail-view | Appeal Package',
    }
};
