import { ggoAdminConstants } from './ggo-admin/ggo-admin.const';
import {appConfig} from '../app.config';
import { biddingAppConstants } from './bidding/bidding-app.const';

export function restangularConfig(RestangularProvider) {

	RestangularProvider.setFullRequestInterceptor(function(element, operation, route, url, headers, params) {
		let URL: string;
		let token: string; 
		if (headers.authenticationURL) {
			URL = appConfig.AUTH_BASE_URL + appConfig.AUTH_URL;
		} else {
			if (headers.adminURL) {
				token = sessionStorage.getItem(ggoAdminConstants.SESSION_STORAGE_KEYS.ADMIN_TOKEN);
				URL = appConfig.BIDDING_BASE_URL + appConfig.ADMIN_URL;
			} else {
				token = sessionStorage.getItem(biddingAppConstants.SESSION_STORAGE_KEYS.TOKEN);
				URL = token ? appConfig.BIDDER_URL : appConfig.VISITOR_URL;
				URL = appConfig.BIDDING_BASE_URL + URL;
			}
		}
		RestangularProvider.setBaseUrl(URL);

		if (headers.authenticationURL || token) {
			RestangularProvider.setDefaultHeaders({'Authorization': 'TokyoScheme ' +  token});
			headers = '';
		}
	});
}
