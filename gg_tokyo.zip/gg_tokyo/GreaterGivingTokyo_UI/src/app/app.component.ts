import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd} from '@angular/router';
import { Title } from '@angular/platform-browser';

import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
})

export class MainAppComponent implements OnInit {

    constructor(public router: Router,
                public appService: AppService) {}

    private trackingPage() {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                // ga('set', 'page', event.url);
                this.appService.trackPages(event.url);
            }
        });
    };

    ngOnInit() {
        this.trackingPage();
        this.appService.isSessionStorageAccessible = this.appService.isStorageSupported();
    };
}
