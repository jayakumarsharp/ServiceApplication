var gulp = require('gulp');
gutil = require('gulp-util');
var concat = require('gulp-concat');
var minify = require('gulp-minify');
var uglify = require('gulp-uglify');
var ngAnnotate = require('gulp-ng-annotate');
var plumber = require('gulp-plumber');
var bytediff = require('gulp-bytediff');
var rename = require('gulp-rename');

gulp.task('build', function () {
	return gulp.src('js/**/*.js')
		.pipe(plumber())
		.pipe(concat('all.js'))
		.pipe(bytediff.start())
		.pipe(uglify({
			mangle: true
		}))
		.pipe(bytediff.stop())
		.pipe(rename('app.min.js'))
		.pipe(plumber.stop())
		.pipe(gulp.dest('dist/'));
});