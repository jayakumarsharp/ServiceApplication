app.factory('httpService', ['$http', function ($http) {

    var httpOpservice = {};

    var config = {
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    };
    httpOpservice.httpRequest = function (type, val, object) {
        if (type == 'GET') {
            return $http.get(val).then(testSuccess).catch(testError);
        } else if (type == "POST") {
            var a = JSON.stringify(object);
            var req = {
                method: 'POST',
                url: val,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: object
            }

            return $http(req).then(testSuccess).catch(testError);


            //return $http.post(val, object).then(testSuccess).catch(testError);
        }


        function testSuccess(response) {
            return response.data;
        }

        function testError(error) {
            return error;
        }

    };

    return httpOpservice;
}]);