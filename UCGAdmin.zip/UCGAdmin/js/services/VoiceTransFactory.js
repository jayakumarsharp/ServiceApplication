'use strict'
var host = config.hostPath;
var url = "";


app.factory('voiceTransFactory', ['$http', '$window', function ($http, $window) {
    return {

        GetBatchName: function () {
            url = host + 'VoiceTranscription/GetBatchName';
            return $http.get(url);
        },
        GetVoiceConfig: function () {
            url = host + 'VoiceTranscription/GetVoiceConfig';
            return $http.get(url);
        },

        CreateVoiceConfig: function (CreateVoiceConfigReq) {
            url = host + 'VoiceTranscription/CreateVoiceConfig'
            return $http.post(url, CreateVoiceConfigReq);
        },
        UpdateVoiceConfig: function (UpdateVoiceConfigReq) {
            url = host + 'VoiceTranscription/UpdateVoiceConfig/'
            return $http.post(url, UpdateVoiceConfigReq);
        },
        GetLanguageFormat: function () {
            url = host + 'MasterData/GetAllLanguage';
            return $http.get(url);
        },
        GetCompletedUserRequest: function (UserRequestData) {
            url = host + 'VoiceTranscription/GetCompletedUserRequest';
            return $http.post(url,UserRequestData);
        },


        DeleteVoiceConfig: function (ID) {
            url = host + 'VoiceTranscription/DeleteVoiceConfig/' + ID;
            return $http.post(url);
        },
        GetSchedularData: function () {
            url = host + 'VoiceTranscription/GetSchedularData';
            return $http.get(url);
        },
        UpdateSchedularData: function (UpdateSchedularDataReq) {
            url = host + 'VoiceTranscription/UpdateSchedularData/'
            return $http.post(url, UpdateSchedularDataReq);
        },
        UpdateVoiceConfigEnableDisable: function (UpdateVoiceConfigEnableDisableReq) {
            url = host + 'VoiceTranscription/UpdateVoiceTransEnableDisable/'
            return $http.post(url, UpdateVoiceConfigEnableDisableReq);
        },
        UploadManualEngUpload: function (uploadjsonfileReq) {
            url = host + 'VoiceTranscription/PostEnglishManualFile/'
            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadjsonfileReq
            });
        },
        UploadManualHinUpload: function (uploadjsonfileReq) {
            url = host + 'VoiceTranscription/PostHindiManualFile/'
            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadjsonfileReq
            });
        },

        GetVoiceResponseStatus: function (ResponseData) {
            url = host + 'VoiceTranscription/GetVoiceResponseStatus'
            return $http.post(url, ResponseData);
        },

        GetVoiceReportStatus: function (VoiceReportData) {
            url = host + 'VoiceTranscription/GetVoiceReportStatus'
            return $http.post(url, VoiceReportData);
        },
        DownLoadZipFile: function (ReferenceCode) {
            url = host + 'VoiceTranscription/DownLoadZipFile?FileName=' + ReferenceCode;
            //var s= $http.get(url);
            $window.open(url);
        },
        DownLoadFile: function (ReferenceCode) {
            url = host + 'VoiceTranscription/DownLoadFile?FileName=' + ReferenceCode + '.txt';
            //var s= $http.get(url);
            $window.open(url);
        },
        DownloadMultipeFile: function (VoiceReportData) {
            url = host + 'VoiceTranscription/DownloadMultipleFile'
            return $http.post(url, VoiceReportData);
        },

        ReadFile: function (filename) {
            url = host + 'VoiceTranscription/ReadFile?FileName=' + filename + '.txt';
            return $http.get(url);
        },
    }
}]);