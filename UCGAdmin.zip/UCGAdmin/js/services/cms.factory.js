﻿(function () {
    'use strict';

    app.factory('UCGService', UCGService);

    UCGService.$inject = ['httpService', '$http', 'appFactory'];
    
    //var baseURL = 'http://52.221.86.121/ucg/api/'
    // var baseURL = 'http://52.221.86.121/api/'
    
    var baseURL = config.CMS_BASE_URL;

    function UCGService(httpService, $http) {
        return UCGService = {
            getCustomerDetails: getCustomerDetails,
            getTicketHistory: getTicketHistory,
            getDepartmentlist: getDepartmentlist,
            getDistrictList: getDistrictList,
            getDepartmentUser: getDepartmentUser, //--Changed 28 Nov 2017
            getDivisionlist: getDivisionlist,
            getPancheyatList: getPancheyatList,
            getBlockList: getBlockList,
            getProblemType: getProblemType,
            createNewTicket: createNewTicket,
            getRejectedTicket: getRejectedTicket,
            getEscalationMatrix: getEscalationMatrix,
            assignTicket: assignTicket,
            assignTicketByL2: assignTicketByL2,
            searchTicket: searchTicket,
            getUserBySSOID: getUserBySSOID,
            getCompletedTickets: getCompletedTickets,
            createCMSUser: createCMSUser,
            getAllCMSUser: getAllCMSUser,
            updateCMSUser: updateCMSUser,
            reassignRejectedTickets: reassignRejectedTickets,
            updateStatus: updateStatus,
            downloadFile: downloadFile,
            createEscalationMatrix: createEscalationMatrix,
            deleteEscalationMatrix: deleteEscalationMatrix,
            deleteUserMapping: deleteUserMapping,
            getTicketFiles: getTicketFiles,
            updateEscalationMatrix: updateEscalationMatrix,
            deleteFile: deleteFile,
            getVillageList: getVillageList,
            uploadFiles: uploadFiles,
            myticket: myticket,
            updateTicket: updateTicket,
            userticket:userticket,
            getAssignTicket: getAssignTicket,
            getOpenTickets: getOpenTickets,
            updateUserTicket: updateUserTicket,
            validateSSOId: validateSSOId,//---change_06122017
            // Navil L3 Dashboard Tickets Changes Start
            getL3DashboardTickets: getL3DashboardTickets,
            getL2DashboardTickets: getL2DashboardTickets,
            getL3DashboardDetails: getL3DashboardDetails,
            getL2DashboardDetails: getL2DashboardDetails
            // Navil L3 Dashboard Tickets Changes End
        };

        // Navil L3 Dashboard Tickets Changes Start
        function getL3DashboardDetails(DeptID, callback){
            var url = baseURL + 'UCGTicket/GetL3DashBoardInDetail?DeptID=' + DeptID;
            // var url = "data/getL3DeptTickets.json";
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        // Navil L3 Dashboard Tickets Changes Start
        function getL2DashboardDetails(DeptID, callback){
            var url = baseURL + 'UCGTicket/GetL2DashBoardInDetail?DeptID=' + DeptID;
            // var url = "data/getL3DeptTickets.json";
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        function getL3DashboardTickets(callback) {
            var url = baseURL + 'UCGTicket/GetL3DashBoard';
            // var url = "data/getL3DashboardTickets.json";
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });

        }

        function uploadFiles(formData) {
            url = baseURL + 'UCGTicket/UploadTicketFiles'
            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                isContentType: true,
                transformRequest: angular.identity,
                data: formData
            });
        }

        function getL2DashboardTickets(deptId, callback) {
            var url = baseURL + 'UCGTicket/GetL2DashBoard?deptID=' + deptId;
            // var url = "data/getL3DashboardTickets.json";
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });

        }
        function downloadFile(fileName, origFileName, callback) {
            var url = baseURL + 'UCGTicket/DownLoadFile?FileName=' + fileName + '&origFileName=' + origFileName;
            window.open(url);
            // var url = "data/getL3DashboardTickets.json";
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });

        }
        function deleteFile(id, callback) {
            var url = baseURL + 'UCGTicket/DeleteFile?id=' + id;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });

        }
        // Navil L3 Dashboard Tickets Changes End
        function getAssignTicket(sso, callback) {
            var url = baseURL + 'UCGTicket/GetOpenTicketsForL2?UserSSOID=' + sso;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });

        };

        function getUserBySSOID(ssoID, callback){
            var url = baseURL + 'UCGTicket/GetUserMappingBySSOID?ssoID=' + ssoID;
            // var url = "data/getL3DeptTickets.json";
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        };
        function getCompletedTickets(deptID, level, callback){
            var url = baseURL + 'UCGTicket/GetCompletedTickets?deptID=' + deptID + '&level=' + level;
            // var url = "data/getL3DeptTickets.json";
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        };
        function myticket(sso,callback) {
            var url = baseURL + 'UCGTicket/GetMyTicketDetails?UserSSOID='+sso;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        function userticket(sso, callback) {
            var url = baseURL + 'UCGTicket/GetUserTcketsQueue?UserSSOID=' + sso;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        } 
        function createNewTicket(payload, callback) {
            var url = baseURL + 'UCGTicket/InsertCustomerAndDetails';

            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });

        }
        function getRejectedTicket(departmentID, userLevel, callback) {
            var url = baseURL + 'UCGTicket/GetRejectedTickets?deptID=' + departmentID + '&level=' + userLevel;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                //{"Status":200,"RejectedTicketDetails":[{"TicketID":21,"Customername":"firstname lastname ","ProblemTypeName":"problem type1","DepartmentName":"depp1","ReasonForContact":"DF","CreatedBY":" ","CreatedON":"2017-11-06T18:30:00","Status":"Rejected ","Remarks":"DC"},{"TicketID":22,"Customername":"firstname lastname ","ProblemTypeName":"problem type1","DepartmentName":"depp1","ReasonForContact":"DF","CreatedBY":" ","CreatedON":"2017-11-06T18:30:00","Status":"Rejected ","Remarks":"DC"},{"TicketID":23,"Customername":"firstname lastname ","ProblemTypeName":"problem type1","DepartmentName":"depp1","ReasonForContact":"DF","CreatedBY":" ","CreatedON":"2017-11-06T18:30:00","Status":"Rejected ","Remarks":"DC"},{"TicketID":24,"Customername":"firstname lastname ","ProblemTypeName":"problem type1","DepartmentName":"depp1","ReasonForContact":"sfvZx","CreatedBY":" ","CreatedON":"2017-11-14T18:30:00","Status":"Rejected ","Remarks":"zc"},{"TicketID":25,"Customername":"firstname lastname ","ProblemTypeName":"problem type1","DepartmentName":"depp1","ReasonForContact":"uho;","CreatedBY":" ","CreatedON":"2017-11-21T18:30:00","Status":"Rejected ","Remarks":"mvb"},{"TicketID":26,"Customername":"firstname lastname ","ProblemTypeName":"problem type1","DepartmentName":"depp1","ReasonForContact":"reason","CreatedBY":" ","CreatedON":"2017-11-05T18:30:00","Status":"Rejected ","Remarks":"rem"},{"TicketID":27,"Customername":"firstname lastname ","ProblemTypeName":"Server issue","DepartmentName":"IT dept","ReasonForContact":"server connection error","CreatedBY":" ","CreatedON":"2017-11-13T18:30:00","Status":"Rejected ","Remarks":"it rem"},{"TicketID":28,"Customername":"firstname lastname ","ProblemTypeName":"problem type1","DepartmentName":"depp1","ReasonForContact":"reson","CreatedBY":" ","CreatedON":"2017-11-13T18:30:00","Status":"Rejected ","Remarks":"rem"},{"TicketID":29,"Customername":"firstname lastname ","ProblemTypeName":"Server issue","DepartmentName":"IT dept","ReasonForContact":"new issue","CreatedBY":" ","CreatedON":"2017-11-13T18:30:00","Status":"Rejected ","Remarks":""}]}
            });
        }
    
        function createCMSUser(userData, callback) {
            url = baseURL + 'UCGTicket/CreateCMSUser';
            httpService.httpRequest('POST', url, userData).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }
        function updateCMSUser(userData, callback) {
            url = baseURL + 'UCGTicket/UpdateCMSUser';
            httpService.httpRequest('POST', url, userData).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }
        function deleteUserMapping(userMappingID, isL1User, callback) {
            url = baseURL + 'UCGTicket/DeleteUserMapping?userMappingID=' + userMappingID + '&isL1User=' + isL1User;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        function createEscalationMatrix(payload, callback) {
            url = baseURL + 'UCGTicket/CreateEsclationMatrix';
            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }
        function updateEscalationMatrix(payload, callback) {
            url = baseURL + 'UCGTicket/UpdateEsclationMatrix';
            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
            });
        }
        function deleteEscalationMatrix(esclationID, callback) {
            url = baseURL + 'UCGTicket/DeleteEscalation?esclationID=' + esclationID;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        function getProblemType(deptId, callback) {
            var url = baseURL + 'UCGTicket/ProblemTypeLookup?deptId=' + deptId;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }
        function getDepartmentlist(callback) {
            var url = baseURL + 'UCGTicket/DepartmentLookup';
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        function getEscalationMatrix(callback) {
            var url = baseURL + 'UCGTicket/GetEsclationMatrix';
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        
        function getDepartmentUser(departmentID,callback) { //---Changed 28 Nov 2017
            var url = baseURL + 'UCGTicket/GetL1UsersbyDepartment?DeptID=' + departmentID;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        function getDistrictList(divisionId, callback) {
            var url = baseURL + 'UCGTicket/DistrictLookup?DivisionID=' + divisionId;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }

        function getDivisionlist(callback) {
            var url = baseURL + 'UCGTicket/DivisionLookup';
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }

        function getPancheyatList(blockId, callback) {
            var url = baseURL + 'UCGTicket/PanchayatLookup?BlockID=' + blockId;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }

        function getVillageList(pancheyatId, callback) {
            var url = baseURL + 'UCGTicket/VillageLookup?PanchayatID=' + pancheyatId;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }

        function getBlockList(districtId, callback) {
            var url = baseURL + 'UCGTicket/BlockLookup?DistrictID=' + districtId;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }
        function getAllCMSUser(userLevel, callback) {
            var url = baseURL + 'UCGTicket/GetAllUserMapping?level=' + userLevel;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }


        function getCustomerDetails(phoneNumber, callback) {
            var url = baseURL + 'UCGTicket/GetCallingCustomerDetailsForCall?CallingPhone=' + phoneNumber;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                //callback({ "Status": 200, "CustomerDetail": { "CustomerID": 1, "FirstName": "Test ", "LastName": "Test ", "DivisionName": "Test ", "DistrictName": "Tst " }, "CustomerTicketDetails": [{ "TicketID": 1, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "testing", "status": "Open " }, { "TicketID": 2, "CreatedON": "2017-11-09T00:00:00", "ProblemTypeName": "1", "DepartmentName": "1", "ReasonForContact": "test1", "status": "Completed " }] });
            });
        }

        function getTicketHistory(ticketID, callback) {
            var url = baseURL + 'UCGTicket/GetTicketDetailsHistoryByTicketID?TicketNumber=' + ticketID;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                // callback({ "Status": 200, "TicketDetails": { "ProblemType": "Prob Type", "Department": "Dept" }, "TicketHistory": [{ "Status": "Open", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergise", "Remarks": "Test Remark 1" }, { "Status": "WIP", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergise", "Remarks": "Test Remark 2" }, { "Status": "closed", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergiseia", "Remarks": "Test Remark 3" }] });
            });
        }

        function getTicketFiles(ticketID, callback) {
            var url = baseURL + 'UCGTicket/GetTicketFiles?ticketId=' + ticketID;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                // callback({ "Status": 200, "TicketDetails": { "ProblemType": "Prob Type", "Department": "Dept" }, "TicketHistory": [{ "Status": "Open", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergise", "Remarks": "Test Remark 1" }, { "Status": "WIP", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergise", "Remarks": "Test Remark 2" }, { "Status": "closed", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergiseia", "Remarks": "Test Remark 3" }] });
            });
        }

        function getOpenTickets(deptId, callback) {
            var url = baseURL + 'UCGTicket/GetOpenTicketsForDept?DeptID=' + deptId;
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
                // callback({ "Status": 200, "TicketDetails": { "ProblemType": "Prob Type", "Department": "Dept" }, "TicketHistory": [{ "Status": "Open", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergise", "Remarks": "Test Remark 1" }, { "Status": "WIP", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergise", "Remarks": "Test Remark 2" }, { "Status": "closed", "ActionDate": "2017-11-09T00:00:00", "ActionBy": "Vergiseia", "Remarks": "Test Remark 3" }] });
            });
        }

        function assignTicket(payload, callback) {
            var url = baseURL + 'UCGTicket/AssignTicketCrateadByL1';
            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
            });
        }

        function assignTicketByL2(payload, callback) {
            var url = baseURL + 'UCGTicket/AssignTicketByL2';
            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
            });
        }
        function reassignRejectedTickets(payload, callback) {
            var url = baseURL + 'UCGTicket/AssignTicket';
            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
            });
        }
        function updateTicket(payload, callback) {
            var url = baseURL + 'UCGTicket/UpdateTicket';
            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
            });
        }
        
        function updateUserTicket(payload, callback) {
            var url = baseURL + 'UCGTicket/UpdateTicketStatus';
            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
            });
        }

        function updateStatus(payload, callback) {
            var url = baseURL + 'UCGTicket/UpdateTicketStatus';
            httpService.httpRequest('POST', url, payload).then(function (data) {
                callback(data);
            });
        }


        function searchTicket(searchTicketID, searchRPhone, callback) {
            var url = baseURL;

            if (searchTicketID != '' && searchTicketID != undefined) {
                url = url + 'UCGTicket/GetTicketDetailsByTicketID?TicketNumber=' + searchTicketID;
            }
            else if (searchRPhone != '' && searchRPhone != undefined) {
                url = url + 'UCGTicket/GetTicketDetailsByRegisteredPhone?RegisterdPhone=' + searchRPhone;
            }
            httpService.httpRequest('GET', url).then(function (data) {
                callback(data);
            });
        }
        
        //change_06122017
        function validateSSOId(ssoId,callback) {
            //call the webservice to validate the sso id
            callback({"SSOID":"MUTHU.SERVION","aadhaarId":"","bhamashahId":null,"bhamashahMemberId":null,"displayName":"RAJAVEL.SERVION@RAJASTHAN.GOV.IN","dateOfBirth":"","gender":"MALE","mobile":"9940099121","telephoneNumber":null,"mailPersonal":null,"postalAddress":null,"postalCode":null,"l":"JAIPUR","st":"RAJASTHAN","jpegPhoto":null,"designation":"SRTM","department":"INFORMATION PUBLIC RELATIONS","mailOfficial":"","employeeNumber":null,"departmentId":"102"});
            //callback({"SSOID":null,"aadhaarId":"","bhamashahId":null,"bhamashahMemberId":null,"displayName":"RAJAVEL.SERVION@RAJASTHAN.GOV.IN","dateOfBirth":"","gender":"MALE","mobile":"9940099121","telephoneNumber":null,"mailPersonal":null,"postalAddress":null,"postalCode":null,"l":"JAIPUR","st":"RAJASTHAN","jpegPhoto":null,"designation":"SRTM","department":"INFORMATION PUBLIC RELATIONS","mailOfficial":"","employeeNumber":null,"departmentId":"102"});
        }

        var errCallBack = function(data) {
            appFactory.showError();
            appFactory.HideLoader();
        };

    }
})();