angular
  .module('adminApp')
  .factory('ReportsFactory', ReportsFactory);

ReportsFactory.$inject = ['$http','$window'];

function ReportsFactory($http,$window) {

  var host = config.hostPath;
    var url = "";
    var service = {
      getATRReports: getATRReports,
      getATRCampaignReports: getATRCampaignReports,
      getMCReport: getMCReport,
      getSurveyResReport: getSurveyResReport,
      getSurQueswiseReport: getSurQueswiseReport,
      getUMReport: getUMReport,
      getOBOutcomeReport: getOBOutcomeReport,
      getOBCampaignReport: getOBCampaignReport,
      getCallAbandonReport: getCallAbandonReport,
      getVCReport: getVCReport,
      getSSReport: getSSReport,
      getallsurvey: getallsurvey,
      getSurveyDetail: getSurveyDetail,
      getSurveyOutcomeReport: getSurveyOutcomeReport,
      getSurveyCampaignReport: getSurveyCampaignReport,
      getSurveySummaryReport: getSurveySummaryReport,
      getVoiceCampaignList: getVoiceCampaignList,
      getdeptVoiceCampaignList: getdeptVoiceCampaignList,
      getdeptSurveyCampaignList: getdeptSurveyCampaignList,
      getcampaigndetail: getcampaigndetail,
      getSurveyCampaignList: getSurveyCampaignList,
      getsurveyspecificquestionList: getsurveyspecificquestionList,
	  getVoiceCampaignByDateList: getVoiceCampaignByDateList,
      getSurveyCampaignByDateList: getSurveyCampaignByDateList,
      getallsurveywithoutDepId: getallsurveywithoutDepId,
      //getsurveyspecificoptionList: getsurveyspecificoptionList,
      getalldepartment: getalldepartment,
      getalloutcome: getalloutcome,
      getTransServiceReport: getTransServiceReport,
      getTicketCHReport: getTicketCHReport,
      getCBRReport: getCBRReport,
      getIBReports:getIBReports,
      GetAllAgent:GetAllAgent,
      GetAllSkillGroup:GetAllSkillGroup,
      getUserOfflineReport:getUserOfflineReport,
      DownLoadFile:DownLoadFile

    };

    return service;

  function DownLoadFile(ReferenceID) {
      url = host + 'Reports/DownLoadFile?fileName=' + ReferenceID;
      //var s= $http.get(url);
      $window.open(url);
   
  }
  function runOffline() {
    url = host + 'Reports/runOffline';
    return $http.get(url);
  }

  function GetAllAgent() {
    url = host + 'Reports/GetAllAgent';
    return $http.get(url);
  }

  function GetAllSkillGroup() {
    url = host + 'Reports/GetAllSkillGroup';
    return $http.get(url);
  }

  function getATRReports(getATRReportsData) {
    url = host + 'Reports/GetATRReports';
    return $http.post(url, getATRReportsData);
  }

  function getATRCampaignReports(getATRCampaignReportsData) {
    url = host + 'Reports/GetATRCampaignReports';
    return $http.post(url, getATRCampaignReportsData);
  }

  function getMCReport(getMCReportData) {
    url = host + 'Reports/GetMCReport';
    return $http.post(url, getMCReportData);
  }

  function getSurveyResReport(getSurveyResReportData) {
    url = host + 'Reports/GetSurveyresponsesummaryReport';
    return $http.post(url, getSurveyResReportData);
  }

  function getSurQueswiseReport(getSurQueswiseReportData) {
    url = host + 'Reports/GetSurQueswiseReport';
    return $http.post(url, getSurQueswiseReportData);
  }

  function getUMReport(getUMReportData) {
    url = host + 'Reports/GetUMPermissionReport';
    return $http.post(url, getUMReportData);
  }

  function getOBOutcomeReport(getOutcomeReportData) {
    url = host + 'Reports/GetOBOutcomeReport';
    return $http.post(url, getOutcomeReportData);
  }

  function getOBCampaignReport(getCampaignReportData) {
    url = host + 'Reports/GetOBCampaignReport';
    return $http.post(url, getCampaignReportData);
  }

  function getCallAbandonReport(getCallAbanReportData) {
    url = host + 'Reports/GetCallAbandonedReport';
    return $http.post(url, getCallAbanReportData);
  }
   function getSSReport(getSurveySummaryReport) {
    url = host + 'Reports/GetSurveySummarydetailReport';
    return $http.post(url, getSurveySummaryReport);
  }
   function getVCReport(getVoiceSummaryReport) {
    url = host + 'Reports/GetVoiceSummaryReport';
    return $http.post(url, getVoiceSummaryReport);
  }
  function getSurveyDetail(SurveyDetails) {
    url = host + 'Reports/GetSurveyDetailedReport';
    return $http.post(url,SurveyDetails);
  }
  function getSurveyOutcomeReport(getSurOutcomeReportData) {
    url = host + 'Reports/GetSurveyOutcomeReport';
    return $http.post(url, getSurOutcomeReportData);
  }
   function getVoiceCampaignByDateList(CampaignByDateReq) {
    url = host + 'Reports/GetVoiceCampaignByDate';
    return $http.post(url, CampaignByDateReq);
  }
  function getSurveyCampaignByDateList(SurveyCampaignByDateReq) {
    url = host + 'Reports/GetSurveyCampaignByDate';
    return $http.post(url, SurveyCampaignByDateReq);
  }

  function getSurveyCampaignReport(getSurCampReportData) {
    url = host + 'Reports/GeSurveyCampaignReport';
    return $http.post(url, getSurCampReportData);
  }

  function getSurveySummaryReport(getSurSummaryReportData) {
    url = host + 'Reports/GetSurveySummaryReport';
    return $http.post(url, getSurSummaryReportData);
  }

  function getdeptVoiceCampaignList(depId) {
    url = host + 'CampaignVoice/GetAllcampaignList?departmentID=' +depId;
    return $http.get(url);
  }
  function getdeptSurveyCampaignList(depId) {
    url = host + 'Survey/GetAllSurveyCampaignList?departmentID=' +depId;
    return $http.get(url);
  }
  function getsurveyspecificquestionList(surveyID) {
    url = host + 'Survey/GetSurveySpecificQuestion?surveyID=' +surveyID;
    return $http.get(url);
  }
  //  function getsurveyspecificoptionList(surveyID,SurveyQuestion) {
  //   url = host + 'Survey/GetSurveySpecificOption?surveyID=' + surveyID + '&SurveyQuestion=' + SurveyQuestion;
  //   return $http.get(url);
  // }
  function getallsurvey(depId) {
    url = host + 'Survey/GetAllSurvey?departmentID=' +depId;
    return $http.get(url);
  }
  function getallsurveywithoutDepId(depId) {
    url = host + 'Survey/GetAllSurveywithoutDepId';
    return $http.get(url);
  }
  function getcampaigndetail(CampaignDataDetails) {
    url = host + 'CampaignVoice/GetCampaignDataDetails';
    return $http.post(url,CampaignDataDetails);
  }

  function getSurveyCampaignList() {
    url = host + 'Survey/GetAllSurveyCampaignList?departmentID=-1';
    return $http.get(url);
  }
  function getVoiceCampaignList() {
    url = host + 'CampaignVoice/GetAllcampaignList?departmentID=-1';
    return $http.get(url);
  }
   function getalldepartment() {
    url = host + 'UserManagement/GetAllDepartment';
    return $http.get(url);
  }
  function getalloutcome() {
    url = host + 'Reports/GetOutcomeDetails';
    return $http.get(url);
  }
  function getTransServiceReport(getTSReportData) {
    url = host + 'Reports/GetTranscriptionService';
    return $http.post(url, getTSReportData);
  }
  function getUserOfflineReport() {
    url = host + 'Reports/GetUserOfflineReport';
    return $http.get(url);
  }

  function getTicketCHReport(getTCHReportData) {
    url = host + 'Reports/GetTicketCreateionDetails';
    return $http.post(url, getTCHReportData);
  }

    function getCBRReport(getCBRReport){
      url = host+'Reports/GetFinesseCallBackRequest';
      return $http.post(url, getCBRReport);
    }

    function getIBReports(reportName,getInboundReportData) {

    switch (reportName) {
      case "Number of calls – Inbound":
        url = host + 'Reports/GetNoOfInboundCalls';
        return $http.post(url, getInboundReportData);
        break;
      case "Number of calls – Outbound":
        url = host + 'Reports/GetNoOfOutboundCalls';
        return $http.post(url, getInboundReportData);
        break;
      case "Number of Calls":
        url = host + 'Reports/GetNoOfCalls';
        return $http.post(url, getInboundReportData);
        break;
      case "Queue analysis":
        url = host + 'Reports/GetQueueAnalysis';
        return $http.post(url, getInboundReportData);
        break;
      case "Outbound Calls":
        url = host + 'Reports/GetIBOutboundCalls';
        return $http.post(url, getInboundReportData);
        break;
      case "Agent Summary Report":
        url = host + 'Reports/GetIBAgentSummary';
        return $http.post(url, getInboundReportData);
        break;
      case "Agent Detailed Report":
        url = host + 'Reports/GetIBAgentDetail';
        return $http.post(url, getInboundReportData);
        break;
        case "Call Detailed Report":
        url = host + 'Reports/GetIBCallDetail';
        return $http.post(url, getInboundReportData);
        break;
    }


  }


}