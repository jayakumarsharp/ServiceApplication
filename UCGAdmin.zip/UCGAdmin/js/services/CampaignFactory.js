'use strict'
var host = config.hostPath;
var url = "";

app.factory('campaignFactory', ['$http', 'appFactory', function ($http, appFactory) {
    return {
        GETCampaignInfo: function (campaignName, departmentID) {
            url = host + 'CampaignVoice/GETCampaignInfo?campaignName=' + campaignName + '&departmentID=' + departmentID;
            return $http.get(url);
        },
        GetAllVoiceUploadFilter: function (FilterDates) {
            url = host + 'CampaignVoice/GetAllVoiceUploadFilter';
            return $http.post(url, FilterDates);
        },
        
        UpdateApprovalStatus: function (msgcampaign) {
            url = host + 'CampaignVoice/UpdateVoicecampApprovalStatus/'
            return $http.post(url, msgcampaign);
        },
        GetAllCampaignList: function (departmentName) {
            url = host + 'CampaignVoice/GetAllcampaignList?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetCampaignList: function (CampaignListData) {
            url = host + 'CampaignVoice/GetCampaignList';
            return $http.post(url, CampaignListData);
        },
        GetActiveCampaignList: function (departmentName) {
            url = host + 'CampaignVoice/GetAllcampaignList?departmentID=' + departmentName + "&IsActive=1";
            return $http.get(url);
        },
        GetAllUploadList: function (departmentName) {
            url = host + 'CampaignVoice/GetAllUploadList?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetDetailedCampaignInfo: function (campaignDetails) {
            url = host + 'CampaignVoice/GetDetailedCampaignInfo?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetDetailUploadStatus: function (campaignDetails) {
            url = host + 'CampaignVoice/GetDetailUploadStatus?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetDetailedCampaignReport: function (campaignDetails) {
            url = host + 'CampaignVoice/GetDetailedCampaignReport?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetAllCampaignbyDept: function (departmentName) {
            url = host + 'CampaignVoice/GetCampaignByDepartment?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetCiscoCampaignbyDept: function (departmentName) {
            url = host + 'CampaignVoice/GetCiscoCampaignByDepartmentID?departmentID=' + departmentName;
            return $http.get(url);
        },
        CreateVoiceCampaign: function (campaign) {
            url = host + 'CampaignVoice/MakeVoiceCampaignCreateRequest/'
            return $http.post(url, campaign);
        },  
        ModifyVoiceCampaign: function (campaign) {
            url = host + 'CampaignVoice/MakeVoiceCampaignEditRequest/'
            return $http.post(url, campaign);
        },
        UpdateUploadContactFile: function (msgcampaign) {
            url = host + 'CampaignVoice/UpdateUploadContactFile/'
            return $http.post(url, msgcampaign);
        },
        DoCampaignAction: function (actionCampaigns) {
            url = host + 'CampaignVoice/DoCampaignAction/'
            return $http.post(url, actionCampaigns);
        },
        GetDNCCount:function(){
            url=host+'CampaignVoice/GetAllDNCContactCount/'
            return $http.get(url)
        },
        UploadContactFile: function (uploadVoiceCampaignReq) {
            url = host + 'CampaignVoice/PostFile/'

            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadVoiceCampaignReq
            });
        },
        UploadAudioFile: function (uploadAudiofileReq) {
            url = host + 'CampaignVoice/PostAudioFile/';
            var headers = config.headers || {};

            var ssoToken, ssoId, ssoDtls;
            ssoToken = sessionStorage.getItem('SSOToken');
            ssoId = sessionStorage.getItem('SSOId');


            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadAudiofileReq
            });
        },
        UploadAddDNCFile: function (uploadDncfileReq) {
            url = host + 'CampaignVoice/PostAddDNCFile/'
            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadDncfileReq
            });
        },

        UploadRemoveDNCFile: function (uploadDncfileReq) {
            url = host + 'CampaignVoice/PostRemoveDNCFile/'
            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadDncfileReq
            });
        },

        AddDNCContact: function (postdata) {
            url = host + 'CampaignVoice/AddDNCContact/';
            return $http.post(url, postdata);
        },
        SearchDNCContact: function (dncsearchcontact) {
            url = host + 'CampaignVoice/SearchDNCContact?mobileNo=' + dncsearchcontact;
            return $http.get(url);
        },
        GetAllContactData: function (AllContactdata) {
            url = host + 'CampaignVoice/GetAllContactData'
            return $http.post(url, AllContactdata);
        },
      
      UpdateMobileno: function (updatedmobileno) {
            url = host + 'CampaignVoice/UpdateMobileno/'
            return $http.post(url, updatedmobileno);
        },
      DeleteMobileno: function (mobileno) {
            url = host + 'CampaignVoice/DeleteMobileno?mobileno=' + mobileno;
            return $http.get(url);
        },
       
        validateCampaign: function (action, campaignObj, campaigns) {
            var errMsg = '';
            if (action === 'ADD') {
                errMsg = appFactory.validateDates(campaignObj.startDate, campaignObj.endDate);
            } else {
                var startDateObj = moment(campaignObj.startDate);
                var createdStartDateObj = moment(campaignObj.createdStartDate);
                var endDateObj = moment(campaignObj.endDate);
                var createdEndDateObj = moment(campaignObj.createdEndDate);
                if ((endDateObj.diff(createdEndDateObj) !== 0) && (startDateObj.diff(createdStartDateObj) === 0)) {
                    errMsg = appFactory.validateCampaignDates(campaignObj.createdStartDateObj, campaignObj.endDate);
                } else {
                    errMsg = appFactory.validateCampaignDates(campaignObj.startDate, campaignObj.endDate);
                }
               // return errMsg;
            }
            if ((appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) && !campaignObj.department && action === 'ADD') {
              // errMsg = "Please select a department";
              errMsg= 1;
            }
            if (!campaignObj.noOfTries) {
              //  errMsg = "No of tries should not be empty";
                errMsg= 1;
            }
            if (campaignObj.DayNumber.length == 0) {
              // errMsg = "Working days are not selected";
               errMsg= 1;
            }
            if (!campaignObj.campaignName && action === 'ADD') {
              // errMsg = "CampaignName should not be empty";
               errMsg= 1;
            } else if (campaignObj.campaignName && action === 'ADD') {
                if (campaigns.length > 0) {
                    var iscampaignNameExist = false;
                    campaigns.forEach(function (data) {
                        if (data.CampaignId && (data.CampaignId.toUpperCase() === campaignObj.campaignName.toUpperCase())) {
                            iscampaignNameExist = true;
                        }
                    });
                    if (iscampaignNameExist) {
                        //errMsg = "CampaignName already exist";
                        errMsg= 2;
                    }
                }
            }
            return errMsg;
        }
    }
}]);