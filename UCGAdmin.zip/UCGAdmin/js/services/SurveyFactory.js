'use strict'
var host = config.hostPath;
var url = "";
app.factory('surveyFactory', ['$http', function ($http) {
    return {
        GetAllQuestionSetbyId: function (id) {
            url = host + 'Survey/GetAllQuestionSetbyId?id=' + id;
            return $http.get(url);
        },
        PostSurveyAudioFile: function (uploadAudiofileReq) {
            url = host + 'Survey/PostSurveyAudioFile/'
            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadAudiofileReq
            });
        },
        // Survey campaign management
        GetAllCampaignList: function (departmentName) {
            url = host + 'Survey/GetAllcampaignList?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetAllUploadList: function (departmentName) {
            url = host + 'Survey/GetAllUploadList?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetDetailedCampaignInfo: function (campaignDetails) {
            url = host + 'Survey/GetDetailedCampaignInfo?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetDetailUploadStatus: function (campaignDetails) {
            url = host + 'Survey/GetDetailUploadStatus?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetDetailedCampaignReport: function (campaignDetails) {
            url = host + 'Survey/GetDetailedCampaignReport?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetAllCampaignbyDept: function (departmentName) {
            url = host + 'Survey/GetCampaignByDepartment?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetCiscoCampaignbyDept: function (departmentName) {
            url = host + 'Survey/GetCiscoCampaignByDepartmentID?departmentID=' + departmentName;
            return $http.get(url);
        },
        CreateVoiceCampaign: function (campaign) {
            url = host + 'Survey/MakeVoiceCampaignCreateRequest/'
            return $http.post(url, campaign);
        },
        ModifyVoiceCampaign: function (campaign) {
            url = host + 'Survey/MakeVoiceCampaignEditRequest/'
            return $http.post(url, campaign);
        },
        UpdateUploadContactFile: function (msgcampaign) {
            url = host + 'Survey/UpdateUploadContactFile/'
            return $http.post(url, msgcampaign);
        },
        DoCampaignAction: function (actionCampaigns) {
            url = host + 'Survey/DoCampaignAction/'
            return $http.post(url, actionCampaigns);
        },
        // Survey campaign management
        GetAllSSOUsers: function (condition) {
            url = host + 'UserManagement/GetAllAdUsers?filterCond=' + condition;
            return $http.get(url);
        },
        GetAllAssignedUser: function () {
            url = host + 'UserManagement/GetAllAdUsers?filterCond=' + condition;
            return $http.get(url);
        },

        CreateUserProfile: function (user) {
            url = host + 'UserManagement/'
            return $http.get(url, user);
        },
        GetUserByID: function () {
            url = host + 'UserManagement/'
            return $http.get(url);
        },
        GetAllQuestionType: function () {
            url = host + 'Survey/GetAllQuestionType'
            return $http.get(url);
        },
        GetSurveyNamesByType: function (qTypeId) {
            url = host + 'Survey/GetSurveyNamesByType?qTypeID=' + qTypeId;
            return $http.get(url);
        },
        GetAllQuestion: function () {
            url = host + 'Survey/GetAllQuestions'
            return $http.get(url);
        },
        DeleteQuestion: function (Id) {
            url = host + 'Survey/DeleteQuestion?ID=' + Id;
            return $http.get(url);
        },
        GetAllLanguage: function () {
            url = host + 'Survey/GetAllLanguage'
            return $http.get(url);
        },
        CreateQuestions: function (user) {
            url = host + 'Survey/CreateQuestions'
            return $http.post(url, user);
        },
        UpdateQuestion: function (user) {
            url = host + 'Survey/UpdateQuestion'
            return $http.post(url, user);
        },
        GetAllQuestionSet: function () {
            url = host + 'Survey/GetAllQuestionSet'
            return $http.get(url);
        },
        GetAllQuestionOptions: function () {
            url = host + 'Survey/GetAllQuestionOptions'
            return $http.get(url);
        },
        Create_Options: function (user) {
            url = host + 'Survey/Create_Options'
            return $http.post(url, user);
        },
        CreateQuestionSet: function (user) {
            url = host + 'Survey/CreateQuestionSet'
            return $http.post(url, user);
        },
        CreateSurveySetting: function (user) {
            url = host + 'Survey/CreateSurveySetting'
            return $http.post(url, user);
        },
        UpdateQuestionSet: function (user) {
            url = host + 'Survey/UpdateQuestionSet'
            return $http.post(url, user);
        },
        UpdateRetrySurveyCampaign: function (user) {
            url = host + 'Survey/UpdateRetrySurveyCampaign'
            return $http.post(url, user);
        },
        GetAllSubjectiveSurvey: function (filterData) {
            url = host + 'Survey/GetAllSubjectiveSurvey/'
            return $http.post(url, filterData);
        },
        AssignSurSubjective: function (surData) {
            var defer = $q.defer();
            $http.post(host + 'Survey/AssignSurSubjective', surData, {
                    "loading": true
                })
                .then(function (success) {
                    defer.resolve(success);
                    console.log("data2", success.data);
                }, function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        },
        submitQuestionSurvey: function (questions) {
            url = host + 'Survey/UpdateMannualCallResponse'
            return $http.post(url, questions);
        },
        getAllSamples: function (departmentID) {
            url = host + 'Survey/GetAllSample';
            return $http.post(url, departmentID);
        },
        postSampleData: function (sampleData, cbsPostSampleData, cbfPostSampleData) {
            url = host + 'Survey/PostSampleData'
            return $http.post(url, sampleData).then(cbsPostSampleData, cbfPostSampleData);
        },
        GetLCMCampaignInfo: function (campaignname) {
            url = host + 'Survey/GetLCMCampaignInfo?campaignID=' + campaignname;
            return $http.get(url);
        },
        GetAllSurveyFailedContacts: function () {
            url = host + 'Survey/GetAllSurveyFailedContacts'
            return $http.get(url);
        },
        GetCloneSurvey: function (surveyid) {
            url = host + 'Survey/GetCloneSurvey?surveyId=' + surveyid
            return $http.get(url);
        },
    }
}]);