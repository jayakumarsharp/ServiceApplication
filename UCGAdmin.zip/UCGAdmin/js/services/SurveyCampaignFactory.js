'use strict'
var host = config.hostPath;
var url = "";

app.factory('surveyCampFactory', ['$http', function ($http) {
    return {
        GetCampaignAssociation: function (campaginId) {
            url = host + 'Survey/GetCampaignAssociation?campaginId=' + campaginId;
            return $http.get(url);
        },
        GetMyManualContact: function (data) {
            url = host + 'Survey/GetMyManualContact/';
            return $http.post(url, data);
        },
        GETCampaignInfo: function (campaignName, departmentID) {
            url = host + 'Survey/GETCampaignInfo?campaignName=' + campaignName + '&departmentID=' + departmentID;
            return $http.get(url);
        },

        GetAllSurveyApprovalFilter: function (FilterDates) {
            url = host + 'Survey/GetAllSurveyScheduleFilter';
            return $http.post(url, FilterDates);
        },
        GetAllSurveyApproval: function (departmentName) {
            url = host + 'Survey/GetAllSurveySchedule';
            return $http.get(url);
        },
        UpdateApprovalStatus: function (msgcampaign) {
            url = host + 'Survey/UpdateApprovalStatus/'
            return $http.post(url, msgcampaign);
        },
        UpdateRejectStatus: function (msgcampaign) {
            url = host + 'Survey/UpdateRejectStatus/'
            return $http.post(url, msgcampaign);
        },
        GetAllSurveyCampaignList: function (departmentName) {
            url = host + 'Survey/GetAllSurveyCampaignList?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetCampaignList: function (CampaignListData) {
            url = host + 'Survey/GetCampaignList';
            return $http.post(url, CampaignListData);
        },
        GetAllUploadList: function (departmentName) {
            url = host + 'Survey/GetAllUploadList?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetDetailedCampaignInfo: function (campaignDetails) {
            url = host + 'Survey/GetDetailedCampaignInfo?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetDetailUploadStatus: function (campaignDetails) {
            url = host + 'Survey/GetDetailUploadStatus?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetDetailedCampaignReport: function (campaignDetails) {
            url = host + 'Survey/GetDetailedCampaignReport?campaignName=' + campaignDetails.campaignName + '&departmentID=' + campaignDetails.departmentID;
            return $http.get(url);
        },
        GetAllCampaignbyDept: function (departmentName) {
            url = host + 'Survey/GetCampaignByDepartment?departmentID=' + departmentName;
            return $http.get(url);
        },
        GetCiscoCampaignbyDept: function (departmentName) {
            url = host + 'Survey/GetCiscoCampaignByDepartmentID?departmentID=' + departmentName;
            return $http.get(url);
        },
        CreateSurveyCampaign: function (campaign) {
            url = host + 'Survey/MakeSurveyCampaignCreateRequest/'
            return $http.post(url, campaign);
        },
        ModifySurveyCampaign: function (campaign) {
            url = host + 'Survey/MakeSurveyCampaignEditRequest/'
            return $http.post(url, campaign);
        },
        CreateSample: function (msgcampaign) {
            url = host + 'Survey/CreateSample/'
            return $http.post(url, msgcampaign);
        },
        DoCampaignAction: function (actionCampaigns) {
            url = host + 'Survey/DoCampaignAction/'
            return $http.post(url, actionCampaigns);
        },
        UploadContactFile: function (uploadVoiceCampaignReq) {
            url = host + 'Survey/PostFile/'

            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadVoiceCampaignReq
            });
        },
        getDepartmentTypes: function () {
            url = host + 'Survey/DEPARTMENTTYPE';
            return $http.get(url);
        },
        getDepartmentByType: function (deptTypeId) {
            url = host + 'Survey/GETDEPARTMENT?depType=' + deptTypeId;
            return $http.get(url);
        },
        getDivions: function () {
            url = host + 'Survey/GETRSDIVISION';
            return $http.get(url);
        },
        getDistrictByDivision: function (divisionId) {
            url = host + 'Survey/GETRSDISTRICTS?dIVISION_ID=' + divisionId;
            return $http.get(url);
        },
        getPanchayatByDistrict: function (districtId) {
            url = host + 'Survey/GETPANCHAYATSAMITI?dISTRICT_ID=' + districtId;
            return $http.get(url);
        },
        getGramPanchayatByPanchayat: function (panchayatId) {
            url = host + 'Survey/GETGRAMPANCHAYAT?pANCHAYATSAMITI_ID=' + panchayatId;
            return $http.get(url);
        },
        getVillageByGramPanchayat: function (gramPanchayatId) {
            url = host + 'Survey/GETVILLAGE?PANCHAYATID=' + gramPanchayatId;
            return $http.get(url);
        },
        getLCMCampaignInfo: function (campaignID) {
            url = host + 'Survey/GetLCMCampaignInfo?campaignID=' + campaignID;
            return $http.get(url);
        },
        getComplaintsByDepartment: function (deptTypeId) {
            url = host + 'Survey/GETCOMPLAINTYPE?depID=' + deptTypeId;
            return $http.get(url);
        },
        searchRajasthanSampakDB: function (sampleSearch) {
            url = host + 'Survey/PostSampleData'
            return $http.post(url, sampleSearch);
        },
        createSampleSetting: function (sampleSetting) {
            url = host + 'Survey/CreateSurveySetting'
            return $http.post(url, sampleSetting);
        },
        /*for Manual calling controller **/
        getManualCallContacts: function (criteria) {
            url = host + 'Survey/GETManualCallContact'
            return $http.post(url, criteria);
        },
        assignManualCalls: function (manualCallData) {
            url = host + 'Survey/AssignManualCalls'
            return $http.post(url, manualCallData);
        },
        getAssignedManualCallContacts: function (criteria) {
            url = host + 'Survey/GetMyManualContact'
            return $http.post(url, criteria);
        },
        GetManualContact: function (guid) {
            url = host + 'Survey/GetManualContact?contactGUID=' + guid;
            return $http.get(url);
        },

    }
}]);