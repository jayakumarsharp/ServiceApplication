'use strict'
var host = config.hostPath;
var url = "";

app.factory('rightsFactory', ['$http', function ($http) {
    return {
        GetAllRights: function () {
            url = host + 'UserManagement/GetAllRights';
            return $http.get(url);
        }
    }
}]);