'use strict'
var host = config.hostPath;
var url = "";

app.factory('rightsGroupFactory', ['$http', function ($http) {
    return {

    }
}]);