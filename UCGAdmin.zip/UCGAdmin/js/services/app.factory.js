app.factory('appFactory', ['$http', '$q', 'toaster', '$rootScope', '$uibModal', function ($http, $q, toaster, $rootScope, $uibModal) {

    var origGridData = [];
    var searchableFields = [];
    var sessionSSOId = '';
    var sessionSSOMenu = '';

    var isLocalEnv = true;
    var appService = {};
    var confirmCallBacks = {
        no : {},
        yes : {}
    }
    appService.userObj = {
        departmentId: '',
        SSOID: 'test'
    };
    appService.rights = {
        type: ''
    };
    appService.permissions = {};

    var ssoId = '{"sAMAccountName":"ESANCHAR2.TEST","Roles":["MIS","AWS","MDCM","SMS","USSD","CRM","REALITYCHECK","OBD","INB","PROFILE5","PROFILE4","PROFILE3","PROFILE2","PROFILE1","CONFIGURATION","OUTBOUND","INBOUND","SUPERADMIN","ADMIN","RUMAP"]}';
    var ssoMenu = '[{"Rights":[{"RoleName":"Dashboard","RightName":null,"RightOrder":null,"RightUrl":null,"View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"Dashboard","RoleOrder":1,"RoleUrl":"/dashboard","RoleIcon":"fa fa-bar-chart","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"User Management","RightName":"Manage Profile","RightOrder":1,"RightUrl":"/user/profile","View":true,"Add":true,"Modify":true,"Delete":true}],"RoleName":"User Management","RoleOrder":2,"RoleUrl":null,"RoleIcon":"fa fa-users","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Campaign Management","RightName":"Manage Campaign","RightOrder":1,"RightUrl":"/campaign/campindex","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Campaign Management","RightName":"Manage DNC List","RightOrder":2,"RightUrl":"/campaign/dncList","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Campaign Management","RightName":"Report","RightOrder":3,"RightUrl":"/campaign/campaignReport","View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"Campaign Management","RoleOrder":3,"RoleUrl":null,"RoleIcon":"fa fa-bullhorn","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"RealityCheck Management","RightName":"Manage Questions","RightOrder":3,"RightUrl":"/survey/question","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"RealityCheck Management","RightName":"Manage Question Sets","RightOrder":4,"RightUrl":"/survey/questionset","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"RealityCheck Management","RightName":"Manage RealityCheck Campaigns","RightOrder":6,"RightUrl":"/survey/campaign","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"RealityCheck Management","RightName":"RealityCheck Approval","RightOrder":7,"RightUrl":"/survey/approval","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"RealityCheck Management","RightName":"Manual Calling","RightOrder":9,"RightUrl":"/survey/manual-calling","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"RealityCheck Management","RightName":"My Manual Call","RightOrder":10,"RightUrl":"/survey/my-manual-call","View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"RealityCheck Management","RoleOrder":4,"RoleUrl":"/survey","RoleIcon":"fa fa-area-chart","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Case Management","RightName":null,"RightOrder":null,"RightUrl":null,"View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"Case Management","RoleOrder":5,"RoleUrl":"/cms","RoleIcon":"fa fa-file-text-o","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Missed Call Management","RightName":"Assign Missed Calls","RightOrder":1,"RightUrl":"/missedcall/assigncalls","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Missed Call Management","RightName":"My Assigned calls","RightOrder":1,"RightUrl":"/missedcall/assignedcalls","View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"Missed Call Management","RoleOrder":6,"RoleUrl":null,"RoleIcon":"fa fa-phone-square","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"USSD Management","RightName":"USSD Configuration","RightOrder":1,"RightUrl":"/ussd/ussdconfig","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"USSD Management","RightName":"USSD Upload","RightOrder":2,"RightUrl":"/ussd/ussdupload","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"USSD Management","RightName":"USSD Contact","RightOrder":3,"RightUrl":"/ussd/ussdcontact","View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"USSD Management","RoleOrder":7,"RoleUrl":"/ussd","RoleIcon":"fa fa-list-ol","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"SMS Management","RightName":"SMS Configuration","RightOrder":1,"RightUrl":"/sms/smsconfig","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"SMS Management","RightName":"SMS Upload","RightOrder":2,"RightUrl":"/sms/smsupload","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"SMS Management","RightName":"SMS Contact","RightOrder":3,"RightUrl":"/sms/smscontact","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"SMS Management","RightName":"Survey CallOutcome","RightOrder":9,"RightUrl":"/reports/surveyoutcomereport","View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"SMS Management","RoleOrder":8,"RoleUrl":"/sms","RoleIcon":"fa fa-commenting","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"IVR Call Management","RightName":null,"RightOrder":null,"RightUrl":null,"View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"IVR Call Management","RoleOrder":9,"RoleUrl":"/ivr","RoleIcon":"fa fa-fax","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Finesse Agent Desktop","RightName":null,"RightOrder":null,"RightUrl":null,"View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"Finesse Agent Desktop","RoleOrder":10,"RoleUrl":"/finesse","RoleIcon":"fa fa-desktop","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Master Data","RightName":null,"RightOrder":null,"RightUrl":null,"View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"Master Data","RoleOrder":12,"RoleUrl":"/masterdata","RoleIcon":"fa fa-database","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Voice Transcription","RightName":"Voice Dashboard","RightOrder":1,"RightUrl":"/voicetrans/voicedashboard","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Voice Transcription","RightName":"Voice Schedule","RightOrder":2,"RightUrl":"/voicetrans/schedule","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Voice Transcription","RightName":"Voice Configuration","RightOrder":3,"RightUrl":"/voicetrans/configuration","View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"Voice Transcription","RoleOrder":13,"RoleUrl":null,"RoleIcon":"fa fa-microphone","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Reports","RightName":"Audit Trail","RightOrder":1,"RightUrl":"/reports/atrreports","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Missedcall ViewPending","RightOrder":2,"RightUrl":"/reports/mcreport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Survey Response Percentage","RightOrder":3,"RightUrl":"/reports/surveyresponsereport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"SMS Contact","RightOrder":3,"RightUrl":"/sms/smscontact","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Survey Questionwise Details","RightOrder":4,"RightUrl":"/reports/surveyqueswisereport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"User Management Additional Permission","RightOrder":5,"RightUrl":"/reports/umreport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Outbound CallOutcome","RightOrder":6,"RightUrl":"/reports/calloutcomereport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Outbound Campaign Detail","RightOrder":7,"RightUrl":"/reports/campaigndetailreport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Call Abandoned Percentage","RightOrder":8,"RightUrl":"/reports/callabandonedreport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Survey CallOutcome","RightOrder":9,"RightUrl":"/reports/surveyoutcomereport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Survey Campaign Detail","RightOrder":10,"RightUrl":"/reports/surveycampaignreport","View":null,"Add":null,"Modify":null,"Delete":null},{"RoleName":"Reports","RightName":"Survey Summary","RightOrder":11,"RightUrl":"/reports/surveysummaryreport","View":null,"Add":null,"Modify":null,"Delete":null}],"RoleName":"Reports","RoleOrder":14,"RoleUrl":null,"RoleIcon":"fa fa-files-o","View":false,"Add":false,"Modify":false,"Delete":false}]';
    var SSOUserDetails  = '{"SSOID":"ESANCHAR2.TEST","aadhaarId":"560809512543","bhamashahId":null,"bhamashahMemberId":null,"displayName":"ESANCHAR2 TEST","dateOfBirth":"29/05/1984","gender":"MALE","mobile":"9840966707","telephoneNumber":null,"mailPersonal":"karthi.vasudev@gmail.com","postalAddress":"305, Tower 17, Skycity, Apartment, Vanagaram Main Road, ,, Adayalampattu","postalCode":"600095","l":"TIRUVALLUR","st":"TAMIL NADU","jpegPhoto":null,"designation":"ESANCHAR2 ADMIN","department":"INFORMATION TECHNOLOGY COMMUNICATION (DOIT)","mailOfficial":"","employeeNumber":null,"departmentId":"103"}';
    // sessionStorage.setItem('SSOUserDetails', SSOUserDetails);

    // sessionStorage.setItem('SSOId', ssoId);
    // sessionStorage.setItem('SSOMenu',ssoMenu);
    // sessionStorage.setItem('SSOUserDetails',SSOUserDetails);


    // var ssoId = '{"sAMAccountName":"SWAMINATHAN.SERVION","Roles":["INBOUND"]}';
    // var ssoMenu = '[{"Rights":[{"RoleName":"User Management","RightName":"Manage Profile","RightOrder":1,"RightUrl":"/user/profile","View":true,"Add":true,"Modify":true,"Delete":false}],"RoleName":"User Management","RoleOrder":2,"RoleUrl":null,"RoleIcon":"fa fa-users","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Campaign Management","RightName":"Manage Campaign","RightOrder":1,"RightUrl":"/campaign/campindex","View":true,"Add":false,"Modify":true,"Delete":false}],"RoleName":"Campaign Management","RoleOrder":3,"RoleUrl":null,"RoleIcon":"fa fa-bullhorn","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"IVR Call Management","RightName":null,"RightOrder":null,"RightUrl":null,"View":true,"Add":false,"Modify":false,"Delete":false}],"RoleName":"IVR Call Management","RoleOrder":9,"RoleUrl":"/ivr","RoleIcon":"fa fa-fax","View":false,"Add":false,"Modify":false,"Delete":false},{"Rights":[{"RoleName":"Finesse Agent Desktop","RightName":null,"RightOrder":null,"RightUrl":null,"View":true,"Add":false,"Modify":false,"Delete":false}],"RoleName":"Finesse Agent Desktop","RoleOrder":10,"RoleUrl":"/finesse","RoleIcon":"fa fa-desktop","View":false,"Add":false,"Modify":false,"Delete":false}]';

    appService.setRoleSpecficRights = function () {
        sessionSSOId = sessionStorage.getItem('SSOId');
        if (!sessionSSOId) {
            return;
        }
        sessionSSOId = JSON.parse(sessionSSOId);
        if (sessionSSOId.Roles && sessionSSOId.Roles.length) {
            if (sessionSSOId.Roles.indexOf(appConst.RIGHTS_TYPES.SUPER_ADMIN) > -1) {
                appService.rights.type = appConst.RIGHTS_TYPES.SUPER_ADMIN;
            }
        }
        appService.setMenuSpecificRights();
        if (!isLocalEnv) {
            setUserDetails();
        }
    };

    appService.setMenuSpecificRights = function () {
        sessionSSOMenu = sessionStorage.getItem('SSOMenu');
        if (sessionSSOMenu) {
            sessionSSOMenu = JSON.parse(sessionSSOMenu);
        }
        if (sessionSSOMenu.length < 1) {
            return;
        }
        var superAdminPermissions = {
            'Add': true,
            'Delete': true,
            'Modify': true,
            'View': true
        };
        var isSuperAdmin = (appService.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN);
        sessionSSOMenu.forEach(function (mainMenu) {
            if (!mainMenu.Rights.length) {
                return;
            }
            if (mainMenu.Rights[0].RightName) {
                mainMenu.Rights.forEach(function (subMenu) {
                    var subMenuActionNames = subMenu.RoleName + ':' + subMenu.RightName.replace(/\n|\r/g, "");
                    var permission = (isSuperAdmin) ? superAdminPermissions : subMenu;
                    appService.permissions[subMenuActionNames] = permission;
                });
            } else {
                mainMenu.Rights = [];
                var subMenuActionNames = mainMenu.RoleName + ':';
                var permission = (isSuperAdmin) ? superAdminPermissions : mainMenu;
                appService.permissions[subMenuActionNames] = permission;
            }
        });
    };

    var setUserDetails = function () {
        appService.userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    };

    appService.showError = function (msg) {
        $rootScope.ErrorMessage = msg;
        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'confirmError.html',
            controller: 'ModalInstanceCtrl',
            windowClass: 'Custom-Modal-Size',

        });
        //toaster.pop({ type: 'error', body: msg });
    };

    appService.showConFirm = function (yesCallBack, noCallBack) {
        confirmCallBacks.yes = yesCallBack;
        confirmCallBacks.no = noCallBack;
        $('#appConfirmClose').modal('show');
    };

    appService.yesConfirm = function () {
        confirmCallBacks.yes();
    };

    appService.noConFirm = function (yesCallBack, noCallBack) {
        confirmCallBacks.no();
    };

    appService.getDepartmentFromRole = function(roleObj, isReturnInt) {
        var parsedRole = JSON.parse(roleObj);
        if (!parsedRole.ApplicationRoles.length) {
            return null;
        }
        var departmentId = parsedRole.ApplicationRoles[0];
        if (+departmentId != departmentId && departmentId.length < 7) {
            return null;
        }
        departmentId = (isReturnInt) ? +departmentId : departmentId;
        return departmentId;
    };


    appService.showToasterErr = function (msg) {
        toaster.pop({
            type: 'error',
            body: msg
        });
    };


    appService.showSuccess = function (msg) {
        toaster.pop({
            type: 'success',
            body: msg
        });
    };

    appService.showWarning = function (msg) {
        toaster.pop({
            type: 'warning',
            body: msg
        });
    };


    appService.ShowLoader = function () {
        angular.element(document.querySelector('#loader')).removeClass('hide');
    };


    appService.HideLoader = function () {
        angular.element(document.querySelector('#loader')).addClass('hide');
    };


    appService.getDataBySearchIndex = function (searchIndex) {
        var gridDataCopy = angular.copy(origGridData);
        var filteredData = [];
        if (searchIndex) {
            gridDataCopy.forEach(function (data) {
                var isMatched = false;
                searchableFields.forEach(function (field) {
                    if (data[field] && data[field].toString().toLowerCase().indexOf(searchIndex.toLowerCase()) > -1) {
                        isMatched = true;
                    }
                });
                if (isMatched) {
                    filteredData.push(data);
                }
            });
            return filteredData;
        } else {
            return gridDataCopy;
        }
    };


    appService.getSearchableFields = function (gridConfig) {
        searchableFields = [];
        /* using copyData to handle searching in main grid view, after searching something in pop up grid**/
        origGridData = (gridConfig.copyData) ? gridConfig.copyData : gridConfig.data;
        gridConfig.columnDefs.forEach(function (columnDef) {
            if (columnDef.isSearchable) {
                searchableFields.push(columnDef.field);
            }
        });
    };

    appService.csvParser = function(fileData) {
        if (!fileData) {
            return new Array();
        }
        var responseArray = fileData.split(/\r\n|\n/);
        var headers = responseArray.splice(0, 1)[0].split(',');
        var parsedData = [];
        if (responseArray && responseArray.length < 1) {
            return new Array();
        }
        responseArray.forEach(function(data) {
            if (!data) {return;}
            var dataObj = data.split(',');
            var parsedObj = {};
            headers.forEach(function(header, index) {
                parsedObj[header] = dataObj[index];
            });
            parsedData.push(parsedObj);
        });
        return parsedData;
    };

    appService.clearFileModel = function () {
        angular.element("input[type='file']").val(null);
    };

    appService.validateDates = function (startDate, endDate) {
        var errMsg = '';
        var currenDate = moment(moment().format('MM-DD-YYYY'));
        // var currenDate = moment(new Date());

        if (!startDate && !isValidDate(startDate)) {
            errMsg = "Please select valid start date";
        } else {
            var startDateObj = moment(moment(startDate).format('MM-DD-YYYY'));
            if (startDateObj.diff(currenDate) < 0) {
                errMsg = "Start date cannot be less than current date";
            }
        }
        if (!endDate && !isValidDate(endDate)) {
            errMsg = "Please select valid end date";
        } else {
            var endDateObj = moment(endDate);
            var startDate = moment(startDate);
            if (endDateObj.diff(startDate) < 0) {
                errMsg = "End date cannot be less than Start date";
            }
        }
        return errMsg;
    };


    appService.validateReportDates = function (startDate, endDate) {
        var errMsg = '';
        var currenDate = moment(moment().format('MM-DD-YYYY'));

        if (!startDate && !isValidDate(startDate)) {
            errMsg = 'Please select valid Start Date';
        } else {
            var startDateObj = moment(moment(startDate).format('MM-DD-YYYY'));
            if (startDateObj.diff(endDate) > 0) {
                errMsg = 'Start Date cannot be greater than End Date';
            }
        }
        if (!endDate && !inValidDate(endDate)) {
            errMsg = 'Please select valid End Date';
        } else {
            var endDateObj = moment(endDate);
            var startDate = moment(startDate);
            if (endDateObj.diff(startDate) < 0) {
                errMsg = 'End date cannot be less than Start Date';
            }
        }
        return errMsg;
    }

    appService.validateCampaignDates = function (startDate, endDate) {
        var errMsg = '';
        var currentDate = moment(moment().format('MM-DD-YYYY'));
        var endDateObj = moment(endDate);
        var startDate = moment(startDate);

        if (!startDate && !isValidDate(startDate)) {
            errMsg = 'Please select valid Start Date';
        }
        if (!endDate && !inValidDate(endDate)) {
            errMsg = 'Please select valid End Date';
        } else if (endDateObj.diff(currentDate) < 0) {
            errMsg = 'End date cannot be less than Current Date';
        } else if (endDateObj.diff(startDate) < 0) {
            errMsg = 'End date cannot be less than Start Date';
        }

        return errMsg;
    }

    appService.isGreaterThanCurentDates = function (startDate, endDate) {
        var errMsg = '';
        var currenDate = moment(moment().format('MM-DD-YYYY'));

        if (!startDate && !isValidDate(startDate)) {
            errMsg = "Please select valid start date";
        } else {
            var startDateObj = moment(moment(startDate).format('MM-DD-YYYY'));
            if (startDateObj.diff(currenDate) > 0) {
                errMsg = "Start date should be less than current date";
            }
        }
        if (!endDate && !isValidDate(endDate)) {
            errMsg = "Please select valid end date";
        } else {
            var endDateObj = moment(endDate);
            var startDate = moment(startDate);
            if (endDateObj.diff(currenDate) > 0) {
                errMsg = "End date should be less than current date";
            }
        }
        return errMsg;
    };

    appService.isWithInDate = function (origDate, updatedDate, isEndDate) {
        var origDateObj = moment(moment(origDate).format('MM-DD-YYYY'));
        if (!updatedDate && !isValidDate(updatedDate)) {
            return false;
        } else {
            var updatedDateObj = moment(moment(updatedDate).format('MM-DD-YYYY'));
            if (!isEndDate) {
                if (updatedDateObj.diff(origDateObj) < 0) {
                    return false;
                }
            } else {
                if (updatedDateObj.diff(origDateObj) > 0) {
                    return false;
                }
            }
        }
        return true;
    };

    appService.isValidStartAndEndDate = function (startDate, endDate) {
        var startDate = moment(moment(startDate).format('MM-DD-YYYY'));
        if (!startDate && !isValidDate(startDate)) {
            return false;
        } else {
            var endDate = moment(moment(endDate).format('MM-DD-YYYY'));
            if (endDate.diff(startDate) < 0 || startDate.diff(endDate) > 0) {
                return false;
            }
        }
        return true;
    };

    var isValidDate = function (date) {
        return moment(date, "DD/MM/YYYY HH:mm", true).isValid();
    };

    return appService;
}]);