'use strict'

var host = config.hostPath;
var url = "";

app.factory('userFactory', ['$http', function ($http) {
    return {
        GetAllSSOUsers: function (condition) {
            url = host + 'UserManagement/GetAllAdUsers?filterCond=' + condition;
            return $http.get(url);
        },
        GetAllAssignedUser: function () {
            url = host + 'UserManagement/GetAllAdUsers?filterCond=' + condition;
            return $http.get(url);
        },
        GetAllProfile: function () {
            url = host + 'UserManagement/GetAllProfile'
            return $http.get(url);
        },
        CreateUserProfile: function (user) {
            url = host + 'UserManagement/'
            return $http.get(url, user);
        },
        GetUserByID: function () {
            url = host + 'UserManagement/'
            return $http.get(url);
        },
        ModifyUser: function (user) {
            url = host + 'UserManagement/'
            return $http.post(url, user);
        }
    }
}]);