  angular
    .module('adminApp')
    .factory('exportFactory', exportFactory);

  exportFactory.$inject = [];

  function exportFactory() {

    var service = {
      getExcel: getExcel
    };

    return service;

    function getExcel(tempData, fileName, sheetName) {

      var headers = [];
      var gridData = [];

      angular.forEach(tempData[0], function (value, key) {
          headers.push(value.text);
      });

      for (var i = 1; i < tempData.length; i++) {
          var temp = {}
          for (var j = 0; j < headers.length; j++) {
              temp[headers[j]] = tempData[i][j];
          }
          gridData.push(temp);
      }

      var workSheet = XLSX.utils.json_to_sheet(gridData);
      var workBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workBook, workSheet, sheetName);
      var workBookOut = XLSX.write(workBook, {
        bookType: 'xlsx',
        type: 'binary'
      });

      function s2ab(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
      };

      saveAs(new Blob([s2ab(workBookOut)], {
        type: "application/octet-stream"
      }), fileName);
    };
  };