app.factory('voiceBioMetricFactory', ['$http', 'appFactory', function ($http, appFactory) {

    var host = config.hostPath;
    var configSetName = 'Hindi';
    var voiceTagName  = 'IVR';
    var factory = {};

    factory.parsedReportsData = [];
    factory.reportTypes = {
        ENROLL :  {
            DISPLAY: 'Enrollment',
            API: 'Enrollment_Report'
        },
        VOICE_PRINT : {
            DISPLAY: 'Voice Print Lock',
            API: 'Voice_Lock_Report'  
        },
        VERIFICATION : {
            DISPLAY: 'Verification Report',
            API: 'Verification_Report'
        },
        MOST_SUCCES : {
            DISPLAY: 'MostSuccessReport',
            API: 'Most_Success_Report'
        },
        LEST_SUCCES : {
            DISPLAY: 'LeastSuccessReport',
            API: 'Least_Success_Report'
        },
        // SCOPE_LIST : {
        //     DISPLAY: 'ScopeList',
        //     API: 'Scope_List'
        // }
    };

    factory.cbsGetReports = '';
    factory.getReportsPath =  function(querparms, cbsGetReports) {
        factory.cbsGetReports = cbsGetReports;
        var bodyParams = {
            reportType: querparms.type.API,
            querParams: [
                { Name: 'Start_date', Value : querparms.startDate },
                { Name: 'End_date', Value : querparms.endDate },
                { Name : 'scope__id', Value : '108086391056901929' }
            ],
            timeOffset : -5.3,
            maxResults : 0,
            configSetName: configSetName
        }
        bodyParams.querParams = JSON.stringify(bodyParams.querParams)
        url = host + 'VocalPassword/GetReportsPath';
        $http.post(url, bodyParams).then(cbsGetReportsPath, cbfGetReports);
    };
    
    factory.getReports = function() {
        url = host + 'VocalPassword/GetAllAgent';
        return $http.get(url);
    };
    
    factory.lock =  function(params, cbsLock) {
        var bodyParams = {
            sessionID : params.sessionId,
            speakerId: params.speakerId,
            voiceTagName: voiceTagName,
            reason: params.reason,
            configSetName: configSetName,
        }
        url = host + 'VocalPassword/LockVoicePrint';
        return $http.post(url, bodyParams);
    };

    factory.unLock =  function(params) {
        var bodyParams = {
            sessionID : params.sessionId,
            speakerId: params.speakerId,
            voiceTagName: voiceTagName,
            configSetName: configSetName,
        }
        url = host + 'VocalPassword/UnLockVoicePrint';
        return $http.post(url, bodyParams);
    };

    factory.startSession = function() {
        var bodyParams = {
            configSetName: configSetName,
            externalSessionId: 0
        };
        url = host + 'VocalPassword/StartSession';
        return $http.post(url, bodyParams);
    };
    factory.endSession = function(sessionID) {
        var bodyParams = {
            configSetName: configSetName,
            sessionID: sessionID
        };
        url = host + 'VocalPassword/EndSession';
        return $http.post(url, bodyParams);
    };

    factory.endSession = function(sessionId) {
        var bodyParams = {
            configSetName: configSetName,
            externalSessionId: 0
        };
        url = host + 'VocalPassword/GetATRCampaignReports';
        $http.post(url, getATRCampaignReportsData)
    }; 

    var cbsGetReportsPath = function(res) {
        if (!res || !res.data) {
            //cbfGetReports();
            return;
        }
        var bodyParams = {
            filePath : res.data
        }
        url = host + 'VocalPassword/GetReportsFile';
        $http.post(url, bodyParams).then(cbsGetReportsFile);
    };

    var cbsGetReportsFile = function(res) {
        if (res && res.data === 'Failure') {
           // cbfGetReports();
            return;
        }
        if (!res.data.length) {
            appFactory.showToasterErr('No Records Found');
            return;
        }
        var parsedData = appFactory.csvParser(res.data);
        /* call Back should called after returning parsed data**/
        factory.parsedReportsData = [];
        factory.parsedReportsData = parsedData;
        setTimeout(function() {factory.cbsGetReports()});
        return parsedData;
    };

    var cbfGetReports = function(res) {
        appFactory.HideLoader();
        appFactory.showError('Error while fetching the data');
    };

    return factory;
}]);