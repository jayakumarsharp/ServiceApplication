'use strict'
var host = config.hostPath;
var url = "";

app.factory('roleFactory', ['$http', function ($http) {
    return {
        GetAllRoles: function () {
            url = host + 'UserManagement/GetAllRoles';
            return $http.get(url);
        }
    }
}]);