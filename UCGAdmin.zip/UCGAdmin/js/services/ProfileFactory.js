'use strict'

var host = config.hostPath;
var url = "";

app.factory('profileFactory', ['$http', function ($http) {
    return {
        GetAllPermission: function () {
            url = host + 'UserManagement/GetAllRoleRights';
            return $http.get(url);
        },
        GetAllProfile: function () {
            url = host + 'UserManagement/GetAllProfile';
            return $http.get(url);
        },
        GetAllDepartment: function () {
            url = host + 'UserManagement/GetAllDepartment';
            return $http.get(url);
        },
        CreateProfile: function (profile) {
            url = host + 'UserManagement/CreateProfilePermisionMapping';
            return $http.post(url, profile);
        },
        GetProfileByID: function (id) {
            url = host + 'UserManagement/GetProfileByID?profileID=' + id;
            return $http.get(url);
        },
        ModifyProfile: function (profile) {
            url = host + 'UserManagement/UpdateProfilePermisionMapping';
            return $http.post(url, profile);
        },
        DeleteProfile: function (name, ssoid) {
            url = host + 'UserManagement/DeleteProfilebyName?profileName=' + name + '&SSOID=' + ssoid;
            return $http.get(url);
        },


        GetUserProfileByID: function (profileName) {
            url = host + 'UserManagement/GetUserProfileByID?profileName=' + profileName;
            return $http.get(url);
        },
        CreateAdditionalUserPermission: function (permission) {
            url = host + 'UserManagement/CreateAdditionalUserPermission'
            return $http.post(url, permission);
        },
        GetAdditionalPermission: function (profileName, ssoId) {
            url = host + 'UserManagement/GetAdditionalPermission?profileName=' + profileName + '&sSOId=' + ssoId;
            return $http.get(url);
        },
        UpdateAddtionalUserPermission: function (permission) {
            url = host + 'UserManagement/UpdateAddtionalUserPermission'
            return $http.post(url, permission);
        },
        DeleteAddtionalPermission: function (ssoId) {
            url = host + 'UserManagement/DeleteAddtionalPermission?SSOId=' + ssoId;
            return $http.get(url);
        },
        GetAllAdditionalPermission: function () {
            url = host + 'UserManagement/GetAllAdditionalPermission';
            return $http.get(url);
        },
        GetSSOUserRoles: function (ssoId) {
            url = host + 'SSO/GetSSOUserRoles?ssoid=' + ssoId;
            return $http.get(url);
        },
        GetSSOUserDetails: function (ssoId) {
            url = host + 'SSO/GetSSOUserDetails?ssoid=' + ssoId;
            return $http.get(url);
        },
        GetDashboardInfo : function(){
            url = host + 'Dashboard/getinfo?departmentID=' + -1;
            return $http.get(url);
        }


    }
}]);