'use strict'
var host = config.hostPath;
var url = "";
app.factory('missCall', ['$http', '$q', function ($http, $q) {

    return {
        dept: function () {
            var defer = $q.defer();
            $http.get(host + 'MissedCall/GetAllMissedCallDepartment', {
                "loading": true
            })
                .then(function (success) {
                    defer.resolve(success);
                }, function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        },
        GetAllDepartment: function () {
            url = host + 'UserManagement/GetAllDepartment';
            return $http.get(url);
        },
        GetMCDepartmentNumber: function () {
            url = host + 'MasterData/GetMCDepartmentNumber';
            return $http.get(url);
        },

        getFinesseAgentsByDept: function (deptID) {
            console.log("deptID", deptID);
            var defer = $q.defer();
            $http.get(host + 'MissedCall/getFinesseAgentsByDept?deptId=' + deptID, {
                "loading": true
            })
                .then(function (success) {
                    defer.resolve(success);
                    console.log("data2 contact", success.data);
                }, function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        },


        contact: function (filterData) {
            var defer = $q.defer();
            $http.post(host + 'MissedCall/GetAllOpenMissedCallContact', filterData, {
                "loading": true
            })
                .then(function (success) {
                    defer.resolve(success);
                    console.log("data2 contact", success.data);
                }, function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        },

        GetAllAssignedMC: function (filterData) {
            var defer = $q.defer();
            $http.post(host + 'MissedCall/GetAllAssignedMC', filterData, {
                "loading": true
            })
                .then(function (success) {
                    defer.resolve(success);
                    console.log("data2 contact", success.data);
                }, function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        },

        UpdateMCstatus: function (filterData) {
            var defer = $q.defer();
            $http.post(host + 'MissedCall/UpdateMCstatus', filterData, {
                "loading": true
            })
                .then(function (success) {
                    defer.resolve(success);
                    console.log("updated data", success.data);
                }, function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        },


        finesseAgents: function (filterData) {
            var defer = $q.defer();
            $http.post(host + 'MissedCall/GetAllFinesseAgents', {
                "loading": true
            })
                .then(function (success) {
                    defer.resolve(success);
                    console.log("data2 finesseAgents", success.data);
                }, function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        },

        AssignMissedCalls: function (missCallData) {
            var defer = $q.defer();
            $http.post(host + 'MissedCall/AssignMissedCalls', missCallData, {
                "loading": true
            })
                .then(function (success) {
                    defer.resolve(success);
                    console.log(" data1 AssignMissedCalls", success.data);
                }, function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        },

        GetAllMissedCallDepartment: function () {
            var url = host + 'MissedCall/GetAllMissedCallDepartment';
            return $http.get(url);
        },

        GetMissedCallHistory: function (id) {
            var url = host + 'MissedCall/GetMissedCallHistory?updateID=' + id;
            return $http.get(url);
        }

    }


}]);