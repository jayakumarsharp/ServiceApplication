'use strict'
var host = config.hostPath;
var url = "";

app.factory('masterDataFactory', ['$http', function ($http) {
    return {

        GetSmsCode: function () {
            url = host + 'MasterData/GetSmsCode';
            return $http.get(url);
        },
        GetUssdCode: function () {
            url = host + 'MasterData/GetUssdCode';
            return $http.get(url);
        },
        GetDepartmentName: function () {
            url = host + 'MasterData/GetDepartmentName';
            return $http.get(url);
        },
        GetApplicationName: function () {
            url = host + 'MasterData/GetApplicationName';
            return $http.get(url);
        },
        GetCampaignThreshold: function (obj) {
            url = host + 'MasterData/GetCampaignThreshold';
            return $http.post(url,obj);
        },
        GetLanguageFormat: function () {
            url = host + 'MasterData/GetAllLanguage';
            return $http.get(url);
        },
        GetNuanceServerData: function () {
            url = host + 'MasterData/GetNuanceConfig';
            return $http.get(url);
        },

        GetThreshold: function (type) {
            url = host + 'MasterData/GetThreshold/?type=' + type;
            return $http.get(url);
        },
        GetDepartmentEmailConfig: function (type) {
            url = host + 'MasterData/GetDepartmentEmailConfig';
            return $http.get(url);
        },
        GetSMTPConfig: function (type) {
            url = host + 'MasterData/GetEmailSMTPConfig';
            return $http.get(url);
        },
        GetEmailTemplate: function (type) {
            url = host + 'MasterData/GetEmailTemplate';
            return $http.get(url);
        },
        GetEmailPlaceHolder: function (type) {
            url = host + 'MasterData/GetEmailPlaceHolder';
            return $http.get(url);
        },
        GetMCDepartmentNumber: function () {
            url = host + 'MasterData/GetMCDepartmentNumber';
            return $http.get(url);
        },
        GetFinesseAgent: function () {
            url = host + 'MasterData/GetFinesseAgent';
            return $http.get(url);
        },
        GetFinesseFAQs: function () {
            url = host + 'MasterData/GetFinesseFAQs';
            return $http.get(url);
        },
        GetTickerMessage: function () {
            url = host + 'MasterData/GetTickerMessage';
            return $http.get(url);
        },
        GetServIntuitusers: function () {
            url = host + 'MasterData/GetServIntuitusers';
            return $http.get(url);
        },
        GetInvalidWords: function () {
            url = host + 'MasterData/GetAllInvalidWords?langID=-1';
            return $http.get(url);
        },

        GetAllIPWhitListing: function () {
            url = host + 'MasterData/GetAllIPWhitListing';
            return $http.get(url);
        },
        GetSMSTemplate: function () {
            url = host + 'MasterData/GetSmsTemplate';
            return $http.get(url);
        },
        CreateSMSTemplate: function (CreateSMSTemplateReq) {
            url = host + 'MasterData/CreateSMSTemplate/'
            return $http.post(url, CreateSMSTemplateReq);
        },
        UpdateSMSTemplate:function (UpdateSMSTemplateReq) {
            url = host + 'MasterData/UpdateSMSTemplate/'
            return $http.post(url, UpdateSMSTemplateReq);
        },
        DeleteSMSTemplate: function (DeleteSMSTemplateReq) {
            url = host + 'MasterData/DeleteSMSTemplate/'
            return $http.post(url, DeleteSMSTemplateReq);
        },
        GetCMS: function () {
            url = host + 'MasterData/GetCMS';
            return $http.get(url);
        },

        DeleteInvalidWord: function (id) {
            url = host + 'MasterData/DeleteInvalidWord?Id=' + id;
            return $http.get(url);
        },

        GetSSOIDByDepartment: function (departmentName) {
            url = host + 'MasterData/GetSSOIDbyDepartment/?departmentName=' + departmentName;
            return $http.post(url);
        },
        CreateCMS: function (CMSdata) {
            url = host + 'MasterData/CreateCMS';
            return $http.post(url, CMSdata);
        },
        ModifyCMS: function (CMSdata) {
            url = host + 'MasterData/ModifyCMS';
            return $http.post(url, CMSdata);
        },
        DeleteCMS: function (CMSdata) {
            url = host + 'MasterData/DeleteCMS';
            return $http.post(url, CMSdata);
        },
        CreateIPWhiteListing: function (CreateIPWhitListingReq) {
            url = host + 'MasterData/CreateIPWhiteListing';
            return $http.post(url, CreateIPWhitListingReq);
        },

        CreateSmsCode: function (CreateSmsCodeReq) {
            url = host + 'MasterData/CreateSmsCode/'
            return $http.post(url, CreateSmsCodeReq);
        },
        CreateUssdCode: function (CreateUssdCodeReq) {
            url = host + 'MasterData/CreateUssdCode/'
            return $http.post(url, CreateUssdCodeReq);
        },
        CreateNuanceConfig: function (CreateNuanceConfigReq) {
            url = host + 'MasterData/CreateNuanceConfig/'
            return $http.post(url, CreateNuanceConfigReq);
        },
        CreateThreshold: function (CreateThresholdReq) {
            url = host + 'MasterData/CreateThreshold/'
            return $http.post(url, CreateThresholdReq);
        },
        CreateEmailTemplate: function (CreateEmailTemplateReq) {
            url = host + 'MasterData/CreateEmailTemplate/'
            return $http.post(url, CreateEmailTemplateReq);
        },
        CreateDepartment: function (CreateDepartmentReq) {
            url = host + 'MasterData/CreateDepartment/'
            return $http.post(url, CreateDepartmentReq);
        },
        CreateDepartmentEmailConfig: function (CreateDepartmentEmailConfigReq) {
            url = host + 'MasterData/CreateDepartmentEmailConfig/'
            return $http.post(url, CreateDepartmentEmailConfigReq);
        },
        CreateEmailPlaceHolder: function (CreateEmailPlaceHolderReq) {
            url = host + 'MasterData/CreateEmailPlaceHolder/'
            return $http.post(url, CreateEmailPlaceHolderReq);
        },

        CreateMCDepartmentNumber: function (CreateMCDepartmentNumberReq) {
            url = host + 'MasterData/CreateMCDepartmentNumber/'
            return $http.post(url, CreateMCDepartmentNumberReq);
        },
        CreateFinesseAgent: function (CreateFinesseAgentReq) {
            url = host + 'MasterData/CreateFinesseAgent/'
            return $http.post(url, CreateFinesseAgentReq);
        },
        CreateFinesseFAQs: function (CreateFinesseFAQsReq) {
            url = host + 'MasterData/CreateFinesseFAQs/'
            return $http.post(url, CreateFinesseFAQsReq);
        },
        CreateTickerMessage: function (CreateTickerMessageReq) {
            url = host + 'MasterData/CreateTickerMessage/'
            return $http.post(url, CreateTickerMessageReq);
        },
        CreateCampaignThreshold: function (CampaignThresholdReq) {
            url = host + 'MasterData/CreateCampaignThreshold/'
            return $http.post(url, CampaignThresholdReq);
        },
        CreateServIntuitusers: function (CreateTickerMessageReq) {
            url = host + 'MasterData/CreateServIntuitusers/'
            return $http.post(url, CreateTickerMessageReq);
        },
        UpdateThreshold: function (UpdateThresholdReq) {
            url = host + 'MasterData/UpdateThreshold/'
            return $http.post(url, UpdateThresholdReq);
        },
        UpdateSmsCode: function (UpdateSmsCodeReq) {
            url = host + 'MasterData/UpdateSmsCode/'
            return $http.post(url, UpdateSmsCodeReq);
        },
        UpdateUssdCode: function (UpdateUssdCodeReq) {
            url = host + 'MasterData/UpdateUssdCode/'
            return $http.post(url, UpdateUssdCodeReq);
        },
        UpdateNuanceConfig: function (UpdateNuanceConfigReq) {
            url = host + 'MasterData/UpdateNuanceConfig/'
            return $http.post(url, UpdateNuanceConfigReq);
        },
        UpdateDepartment: function (UpdateDepartmentReq) {
            url = host + 'MasterData/UpdateDepartment/'
            return $http.post(url, UpdateDepartmentReq);
        },
        UpdateIPWhitelisting: function (UpdateIPWhitelistingReq) {
            url = host + 'MasterData/UpdateIPWhitelisting/'
            return $http.post(url, UpdateIPWhitelistingReq);
        },
        UpdateDepartmentEmailConfig: function (UpdateDepartmentEmailConfigReq) {
            url = host + 'MasterData/UpdateDepartmentEmailConfig/'
            return $http.post(url, UpdateDepartmentEmailConfigReq);
        },
        UpdateEmailSMTPConfig: function (UpdateEmailSMTPConfigReq) {
            url = host + 'MasterData/UpdateEmailSMTPConfig/'
            return $http.post(url, UpdateEmailSMTPConfigReq);
        },
        UpdateEmailTemplate: function (UpdateEmailTemplateReq) {
            url = host + 'MasterData/UpdateEmailTemplate/'
            return $http.post(url, UpdateEmailTemplateReq);
        },
        UpdateEmailPlaceHolder: function (UpdateEmailPlaceHolderReq) {
            url = host + 'MasterData/UpdateEmailPlaceHolder/'
            return $http.post(url, UpdateEmailPlaceHolderReq);
        },
        UpdateMCDepartmentNumber: function (UpdateMCDepartmentNumberReq) {
            url = host + 'MasterData/UpdateMCDepartmentNumber/'
            return $http.post(url, UpdateMCDepartmentNumberReq);
        },
        UpdateFinesseFAQs: function (UpdateFinesseFAQsReq) {
            url = host + 'MasterData/UpdateFinesseFAQs/'
            return $http.post(url, UpdateFinesseFAQsReq);
        },
        UpdateTickerMessage: function (UpdateTickerMessageReq) {
            url = host + 'MasterData/UpdateTickerMessage/'
            return $http.post(url, UpdateTickerMessageReq);
        },
        UpdateCampaignThreshold: function (UpdateCampaignThresholdReq) {
            url = host + 'MasterData/UpdateCampaignThreshold/'
            return $http.post(url, UpdateCampaignThresholdReq);
        },
        UpdateServIntuituser: function (UpdateTickerMessageReq) {
            url = host + 'MasterData/UpdateServIntuituser/'
            return $http.post(url, UpdateTickerMessageReq);
        },


        DeleteEmailTemplate: function (DeleteEmailTemplateReq) {
            url = host + 'MasterData/DeleteEmailTemplate/'
            return $http.post(url, DeleteEmailTemplateReq);
        },


        DeleteDepartment: function (DeleteDepartmentReq) {
            url = host + 'MasterData/DeleteDepartment/'
            return $http.post(url, DeleteDepartmentReq);
        },
        DeleteNuanceConfig: function (DeleteNuanceConfigReq) {
            url = host + 'MasterData/DeleteNuanceConfig/'
            return $http.post(url, DeleteNuanceConfigReq);
        },
        DeleteDepartmentEmailConfig: function (DeleteDepartmentEmailConfigReq) {
            url = host + 'MasterData/DeleteDepartmentEmailConfig/'
            return $http.post(url, DeleteDepartmentEmailConfigReq);
        },
        DeleteEmailPlaceHolder: function (DeleteEmailPlaceHolderReq) {
            url = host + 'MasterData/DeleteEmailPlaceHolder/'
            return $http.post(url, DeleteEmailPlaceHolderReq);
        },
        DeleteMCDepartmentNumber: function (DeleteMCDepartmentNumberReq) {
            url = host + 'MasterData/DeleteMCDepartmentNumber/'
            return $http.post(url, DeleteMCDepartmentNumberReq);
        },
        DeleteFinesseAgent: function (DeleteFinesseAgentReq) {
            url = host + 'MasterData/DeleteFinesseAgent/'
            return $http.post(url, DeleteFinesseAgentReq);
        },
        DeleteFinesseFAQs: function (DeleteFinesseFAQsReq) {
            url = host + 'MasterData/DeleteFinesseFAQs/'
            return $http.post(url, DeleteFinesseFAQsReq);
        },
        DeleteTickerMessage: function (DeleteTickerMessageReq) {
            url = host + 'MasterData/DeleteTickerMessage/'
            return $http.post(url, DeleteTickerMessageReq);
        },
        DeleteCampaignThreshold: function (DeleteCampaignThresholdReq) {
            url = host + 'MasterData/DeleteCampaignThreshold/'
            return $http.post(url, DeleteCampaignThresholdReq);
        },
        DeleteUssdCode: function (ID) {
            url = host + 'MasterData/DeleteUSSDCode/' + ID;
            return $http.post(url);
        },

        DeleteSmsCode: function (ID) {
            url = host + 'MasterData/DeleteSmsCode/' + ID;
            return $http.post(url);
        },
        DeleteThreshold: function (ID) {
            url = host + 'MasterData/DeleteThreshold/' + ID;
            return $http.post(url);
        },
        DeleteIPWhitelisting: function (ID) {
            url = host + 'MasterData/DeleteIPWhitelisting/' + ID;
            return $http.post(url);
        },
        SendEmail: function (SendEmailReq) {
            url = host + 'MasterData/SendEmail/'
            return $http.post(url, SendEmailReq);
        },
        CreateInvalidWord: function (newWords) {
            url = host + 'MasterData/CreateInvalidWord/'
            return $http.post(url, newWords);
        },

        UpdateInvalidWord: function (updatedWords) {
            url = host + 'MasterData/UpdateInvalidWord/'
            return $http.post(url, updatedWords);
        },

        ImportQuestion: function (uploadfileReq) {
            url = host + 'MasterData/PostFile/'
            return $http({
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity,
                data: uploadfileReq
            });
        },



    }
}]);