'use strict'

var host = config.hostPath;
var url = "";

app.factory('applicationFactory', ['$http', function ($http) {
    return {
        routeSerIntuit: function (intuitObj) {
            url = host + 'AppIntegration/InsertTokenToServintuit';
            return $http.post(url, intuitObj);
        }
    }
}]);