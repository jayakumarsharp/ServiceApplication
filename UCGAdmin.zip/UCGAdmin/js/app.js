var app = angular.module('adminApp', ['ngRoute', 'ngTouch', 'ui.grid',
    'ui.grid.pagination', 'ui.grid.autoResize', 'ui.grid.resizeColumns', 'ngAnimate', 'ngMaterial',
    'md-steppers', 'ui.bootstrap', 'ui.bootstrap.datetimepicker', 'ui.bootstrap.tpls', 'ui.bootstrap.collapse',
    'dndLists',
    'toaster', 'ui.grid.exporter', 'ui.grid.selection', 'ngTagsInput', 'ngSanitize', 'ngMessages',
    'rzModule', 'ngCookies', 'ng-mfb', 'ui.select', 'ui.grid.edit', 'ui.grid.cellNav','ui.grid.autoFitColumns'
]);

app.config(['$routeProvider', '$locationProvider', '$httpProvider', '$provide',
    function ($routeProvider, $locationProvider, $httpProvider, $provide) {

        $httpProvider.interceptors.push('authInterceptor');
        //initialize get if not there
        if (!$httpProvider.defaults.headers.get) {
            $httpProvider.defaults.headers.get = {};
        }
        //disable IE ajax request caching
        $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
        $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
        $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';

        $routeProvider
            //Home Routing
            .when('/', {
                controller: '',
                templateUrl: 'views/index.html'
            })

            //Dashboard Routing
            .when('/dashboard', {
                controller: 'DashboardController',
                templateUrl: 'views/dashboard.html'
            })

            //Campaign Routing
            .when('/campaign/campindex', {
                controller: 'CampaignController',
                templateUrl: 'views/campaign/campindex.html'
                
            })
            .when('/campaign/dncList', {
                controller: 'DNCController',
                templateUrl: 'views/campaign/dncList.html',
                controllerAs: 'vm'
            })
            .when('/campaign/campaignReport', {
                controller: 'CampaignViewController',
                templateUrl: 'views/campaign/campaignView.html'
            })
            .when('/survey/surveyretry', {
                controller:   'SurveyCampaignRetryController',
                templateUrl:   'views/survey/SurveyRetry.html'
            })
             .when('/campaign/OutboundDetailedReport', {
                templateUrl: 'views/campaign/OutboundDetailedReport.html',
                controller: 'CampaignDetailController',
                controllerAs: 'vm'
            })
             .when('/campaign/VoiceSummaryReport', {
                templateUrl: 'views/campaign/VoiceSummaryReport.html',
                controller: 'VoiceSummaryController',
                controllerAs: 'vm'
            })

            //Survey Routing
            .when('/survey/question', {
                controller: 'SurveyQuestionController',
                templateUrl: 'views/survey/SurveyQuestion.html'
            })
            .when('/survey/questionset', {
                controller: 'SurveyQuestionSetController',
                templateUrl: 'views/survey/SurveyQuestionSet.html'
            })
            .when('/survey/campaign', {
                controller: 'SurveyCampaignController',
                templateUrl: 'views/survey/SurveyCampaign.html',
                controllerAs: 'vm'
            })
            .when('/survey/sample', {
                controller: 'SurveySampleController',
                templateUrl: 'views/survey/SurveySamples.html'
            })
            .when('/survey/approval', {
                controller: 'SurveyApprovalController',
                templateUrl: 'views/survey/SurveyApproval.html'
            })
            .when('/survey/review', {
                controller: 'SurveySampleController',
                templateUrl: 'views/survey/SurveySamples.html'
            })
            .when('/survey/manual-calling', {
                controller: 'ManualCallingController',
                templateUrl: 'views/survey/manual-calling.html',
                controllerAs: 'manualCall',
            })
            .when('/survey/my-manual-call', {
                controller: 'MyManualCallController',
                templateUrl: 'views/survey/my-manual-call.html',
                controllerAs: 'myManualCall',
            })
            .when('/survey/reports', {
                controller: 'SurveySampleController',
                templateUrl: 'views/survey/detailsCampaignInfo.html'
            })
            .when('/survey/surveyretry', {
                controller: 'SurveyCampaignRetryController',
                templateUrl: 'views/survey/SurveyRetry.html'
            })
            .when('/survey/SurveydetailSummaryReport', {
                templateUrl: 'views/survey/SurveydetailSummaryReport.html',
                controller: 'SurveydetailSummaryController',
                controllerAs: 'vm'
            })

            //Case Management System Routing
            .when("/cms/create", {
                controller: 'CMSController',
                templateUrl: "views/cms/create.htm",
                controllerAs: 'ucg',
            })
            .when("/cms/myticket", {
                controller: 'CMSController',
                templateUrl: "views/cms/myticket.htm",
                controllerAs: 'ucg',
            })
            .when("/cms/assignticket", {
                controller: 'CMSController',
                templateUrl: "views/cms/assignTicket.htm",
                controllerAs: 'ucg',
            })
            .when("/cms/userticket", {
                controller: 'CMSController',
                templateUrl: "views/cms/userticket.htm",
                controllerAs: 'ucg',
            })
            .when("/cms/dashboard", { // Navil L3 Dashboard Tickets Changes Start
                controller: 'CMSController',
                controllerAs: 'ucg',
                templateUrl: "views/cms/l3TicketDashboard.htm"
            })
            .when("/cms/dashboard-detail/:deptId/:filter", {
                controller: 'CMSController',
                controllerAs: 'ucg',
                templateUrl: "views/cms/l3DashboardDetails.htm" // Navil L3 Dashboard Tickets Changes End  
            })
            .when("/cms/reject", {
                controller: 'CMSController',
                controllerAs: 'ucg',
                templateUrl: "views/cms/reject.htm"
            })
            .when("/cms/open-tickets", {
                controller: 'CMSController',
                controllerAs: 'ucg',
                templateUrl: "views/cms/open-tickets.htm"
            })
            .when("/cms/completed-tickets", {
                controller: 'CMSController',
                controllerAs: 'ucg',
                templateUrl: "views/cms/completed-tickets.html"
            })

            //Missed Call Routing
            .when('assigncall', {
                controller: 'assignCallController',
                templateUrl: 'views/missedcall/index.html'
            })

            //USSD Routing
            .when('/ussd/ussdConfig', {
                controller: '',
                templateUrl: 'views/ussd/ussdConfig.html'
            })
            .when('/ussd/ussdUpload', {
                controller: 'USSDController',
                templateUrl: 'views/ussd/ussdUpload.html'
            })
            .when('/ussd/ussdContact', {
                controller: 'USSDController',
                templateUrl: 'views/ussd/ussdContact.html'
            })

            //SMS Routing
            .when('/sms/smsConfig', {
                controller: '',
                templateUrl: 'views/sms/smsConfig.html'
            })
            .when('/sms/smsUpload', {
                controller: 'SMSController',
                templateUrl: 'views/sms/smsUpload.html'
            })
            .when('/sms/smsContact', {
                controller: 'SMSController',
                templateUrl: 'views/sms/smsContact.html'
            })

            //IVR Call Management Routing
            // .when('/ivr', {
            //     controller: 'IVRController',
            //     templateUrl: 'views/ivr/index.html'
            // })

            //Finesse Agent Desktop Routing
            .when('/finesse', {
                controller: 'FinesseController',
                templateUrl: 'views/finesse/index.html'
            })

            // Monitor Routing
            // .when('/monitor', {
            //     controller: 'MonitorController',
            //     templateUrl: 'views/monitor/index.html'
            // })
            
            .when('/voice-biometric', {
                controller: 'VoiceBiometricContoller',
                controllerAs: 'vm',
                templateUrl: 'views/voice-biometric/voice-biometric.html'
            })

            //Master Data Routing
            .when('/masterdata', {
                controller: 'MasterDataController',
                templateUrl: 'views/masterdata/masterpage.html'
            })
            .when('/masterdata/smsthreshold', {
                controller: 'SmsthreholdController',

                templateUrl: 'views/masterdata/smsthreshold.html'
            })
            .when('/masterdata/smscode', {
                controller: 'SmsCodeController',
                templateUrl: 'views/masterdata/smscode.html'
            })
            .when('/masterdata/ussdcode', {
                controller: 'UssdCodeController',
                templateUrl: 'views/masterdata/ussdcode.html'
            })
            .when('/masterdata/ussdthreshold', {
                controller: 'UssdThresholdController',

                templateUrl: 'views/masterdata/ussdthreshold.html'
            })
            .when('/masterdata/globalCampaignRuntime', {
                controller: 'GlobalCampaignRuntimeController',

                templateUrl: 'views/masterdata/globalCampaignRuntime.html'
            })
            .when('/masterdata/ipWhitelisting', {
                controller: 'ipWhitelistingController',
                templateUrl: 'views/masterdata/ipWhitelisting.html'
            })
            .when('/masterdata/department', {
                controller: 'masterDepartmentController',
                templateUrl: 'views/masterdata/department.html'
            })
            .when('/masterdata/nuanceServerConfiguration', {
                controller: 'NuanceServerConfigController',
                templateUrl: 'views/masterdata/nuanceServerConfiguration.html'
            })
            .when('/masterdata/emailManagementConfiguration', {
                controller: 'EmailManagementController',
                templateUrl: 'views/masterdata/emailManagementConfiguration.html',
                controllerAs: 'vm'
            })
            .when('/masterdata/cms', {
                controller: 'MasterDataCMSController',
                templateUrl: 'views/masterdata/cms.html',
                controllerAs: 'vm'
            })

            .when('/masterdata/MCDepartment', {
                controller: 'MCDepartmentNumber',
                templateUrl: 'views/masterdata/MCDepartment.html',
                controllerAs: 'vm'
            })
            .when('/masterdata/finesseAgent', {
                controller: 'MasterFinesseAgent',
                templateUrl: 'views/masterdata/finesseAgent.html',
                controllerAs: 'vm'
            })
            .when('/masterdata/FineseeFAQConfig', {
                controller: 'MasterFinesseFAQ',
                templateUrl: 'views/masterdata/fineseeFAQConfig.html',
                controllerAs: 'vm'
            })
            .when('/masterdata/TickerMessage', {
                controller: 'MasterTickerMessage',
                templateUrl: 'views/masterdata/TickerMessage.html',
                controllerAs: 'vm'
            })
            .when('/masterdata/TextFilter', {
                controller: 'TextFilterController',
                templateUrl: 'views/masterdata/textFilter.html',
                controllerAs: 'vm'
            })
            .when('/masterdata/smsTemplate', {
                controller: 'masterSmsTemplate',
                templateUrl: 'views/masterdata/smstemplate.html',
                controllerAs: 'vm'
            })
            .when('/masterdata/masterCampaignConfig', {
                controller: 'masterCampaignConfig',
                templateUrl: 'views/masterdata/masterCampaignConfig.html',
               
            })
            .when('/masterdata/questionImport', {
                controller: 'questionImportController',
                templateUrl: 'views/masterdata/questionImport.html',
               
            })
            

            //Voice Transcription Routing
            .when('/voicetranscription/voicedashboard', {
                controller: 'transcriptionReportController',
                templateUrl: 'views/voicetranscription/transcriptionReport.html',
                controllerAs: 'vm'
            })
            .when('/voicetranscription/Download', {
                controller: 'voiceTransDownloadController',
                templateUrl: 'views/voicetranscription/download.html',
            })
            .when('/voicetranscription/schedule', {
                controller: 'VoicetranscriptionController',
                templateUrl: 'views/voicetranscription/schedule.html'
            })
            .when('/voicetranscription/configuration', {
                controller: 'voiceConfigController',
                templateUrl: 'views/voicetranscription/configuration.html'
            })
            .when('/voicetranscription/manualupload', {
                controller: 'VoicetranscriptionController',
                templateUrl: 'views/voicetranscription/manualupload.html',
                controllerAs: 'vm'
            })
            .when('/voicetranscription/VoiceReport', {
                controller: 'VoiceReportsController',
                templateUrl: 'views/voicetranscription/VoiceReport.html',
                controllerAs: 'vm'
            })
            .when('/voicetranscription/voiceDownload', {
                controller: 'voiceTransDownloadController',
                templateUrl: 'views/voicetranscription/Download.html'
            })

            //User Management Routing   
            .when('/user', {
                controller: 'UserController',
                templateUrl: 'views/user/index.html'
            })
            .when('/user/manage', {
                controller: 'UserController',
                templateUrl: 'views/user/user.html'
            })
            .when('/user/profile', {
                controller: 'ProfileController',
                templateUrl: 'views/user/profile.html'
            })
            .when('/user/rightsGroup', {
                controller: 'RightsGroupController',
                templateUrl: 'views/user/rightsGroup.html'
            })
            .when('/user/roles', {
                controller: 'RoleController',
                templateUrl: 'views/user/role.html'
            })
            .when('/user/rights', {
                controller: 'RightsController',
                templateUrl: 'views/user/rights.html'
            })
            .when('/user/reports', {
                controller: 'UserReportController',
                templateUrl: 'views/user/reports.html'
            })

            //Missed Call Routing
            .when('/missedcall/assigncalls', {
                controller: 'assignCallController',
                templateUrl: 'views/missedcall/assigncalls.html'
            })
            .when('/missedcall/assignedcalls', {
                controller: 'callAssignedController',
                templateUrl: 'views/missedcall/callAssigned.html'
            })

            //Reports
            .when('/reports/voice-biometric', {
                templateUrl: 'views/reports/voice.biometric.reports.html',
                controller: 'VoiceBiometricReportsContoller',
                controllerAs: 'vm'
            })
            .when('/reports/atrreports', {
                templateUrl: 'views/reports/auditTrialReports.html',
                controller: 'ATRReportsController',
                controllerAs: 'vm'
            })
            .when('/reports/atrreportscampaign', {
                templateUrl: 'views/reports/auditTrailCampaignReports.html',
                controller: 'ATRCampaignReportsController',
                controllerAs: 'vm'
            })
            .when('/reports/mcreport', {
                templateUrl: 'views/reports/missedCallReports.html',
                controller: 'MCReportController',
                controllerAs: 'vm'
            })
            .when('/reports/surveyresponsereport', {
                templateUrl: 'views/reports/surveyResponseReport.html',
                controller: 'SurveyResponseController',
                controllerAs: 'vm'
            })
           
            .when('/reports/surveyqueswisereport', {
                templateUrl: 'views/reports/surveyQueswiseReport.html',
                controller: 'SurveyQueswiseController',
                controllerAs: 'vm'
            })
            .when('/reports/umreport', {
                templateUrl: 'views/reports/userManagementReports.html',
                controller: 'UMReportsController',
                controllerAs: 'vm'
            })
            .when('/reports/calloutcomereport', {
                templateUrl: 'views/reports/outboundCallOutcomeReport.html',
                controller: 'OBOutcomeController',
                controllerAs: 'vm'
            })
            .when('/reports/campaigndetailreport', {
                templateUrl: 'views/reports/outboundCampDetailReport.html',
                controller: 'OBCampaignController',
                controllerAs: 'vm'
            })
            .when('/reports/callabandonedreport', {
                templateUrl: 'views/reports/callabandonedReport.html',
                controller: 'CallAbandonedController',
                controllerAs: 'vm'
            })
            .when('/reports/surveyoutcomereport', {
                templateUrl: 'views/reports/surveyCallOutcomeReport.html',
                controller: 'SurveyOutcomeController',
                controllerAs: 'vm'
            })
            .when('/reports/surveycampaignreport', {
                templateUrl: 'views/reports/surveyCampDetailReport.html',
                controller: 'SurveyCampaignRptController',
                controllerAs: 'vm'
            })
            .when('/reports/surveysummaryreport', {
                templateUrl: 'views/reports/surveySummaryReport.html',
                controller: 'SurveySummaryController',
                controllerAs: 'vm'
            })
            .when('/reports/transcriptionservicereport', {
                templateUrl: 'views/reports/transcriptionServiceReport.html',
                controller: 'TSReportController',
                controllerAs: 'vm'
            })
            .when('/reports/ticketcreationhistoryreport', {
                templateUrl: 'views/reports/ticketCHistoryReport.html',
                controller: 'TCHReportController',
                controllerAs: 'vm'
            })
            .when('/reports/finessecallbackreport', {
                templateUrl: 'views/reports/finesseCallBackRequestReport.html',
                controller: 'FinesseCallBackReportController',
                controllerAs: 'vm'
            })
            .when('/reports/inboundreport', {
                templateUrl: 'views/reports/inboundReport.html',
                controller: 'InboundReportController',
                controllerAs: 'vm'
            })
            .when('/reports/offlinereport', {
                templateUrl: 'views/reports/offlineReport.html',
                controller: 'offlineReportController',
                controllerAs: 'vm'
            })


            //Application Integration Routing
            .when('/integrate/intuit', {
                templateUrl: 'views/apps/servintuit.html',
                controller: 'servintuitController'
            }) 
            .when('/integrate/care', {
                templateUrl: 'views/apps/servcare.html',
                controller: 'servcareController'
            })

            .otherwise({
                redirectTo: '/'
            });

        $locationProvider.html5Mode(true);
    }

]);

app.factory('authInterceptor', ['$location', '$q', '$window', function ($location, $q, $window) {
    return {
        request: function (config) {
            if (config.url.match(/UCGTicket/g)) {
                config.headers = {
                    // 'Access-Control-Allow-Origin': '*',
                    // 'Accept': 'application/json',
                    // 'Content-Type': 'application/json'
                }
                if (!config.isContentType) {
                    config.headers['Content-Type'] = 'application/json';
                }
                // config.headers['Content-Type'] = 'multipart/form-data';
                return config;
            }
            config.headers = config.headers || {};

            var ssoToken, ssoId, ssoDtls;
            ssoToken = sessionStorage.getItem('SSOToken');
            ssoId = sessionStorage.getItem('SSOId');

            if (ssoToken) {
                config.headers['SSOToken'] = ssoToken;
            }
            if (ssoId) {
                ssoDtls = JSON.parse(ssoId);
                if (ssoDtls.sAMAccountName) {
                    config.headers['SSOID'] = ssoDtls.sAMAccountName;
                }
            }
            
            var currentPath = window.location.href;
            var indexVal = currentPath.split('/',4).join('/').length;
            var currentUrl = currentPath.substring(indexVal,currentPath.length);

            config.headers['WindowUrl']= currentUrl;


            //->Commented for testing
            // var sessionTime = new Date(sessionStorage.getItem('SessionTime'));
            // var startDate = moment(sessionTime);
            // var endDate = moment(new Date());

            // var dateDiffMin = endDate.diff(startDate, 'minutes');

            // if (dateDiffMin >= 2 && dateDiffMin <= 4) {// >= 13 and <= 15
            //     sessionStorage.setItem('SessionTime', new Date());
            //     sessionService.IncreaseSession(ssoToken);
                
            // }
            // else if (dateDiffMin > 4) { // > 15

            //     sessionStorage.removeItem('SSOToken');
            //     sessionStorage.removeItem('SSOId');
            //     sessionStorage.removeItem('SSOUserDetails');
            //     document.cookie = "SSOkey" + '=;  path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';

            //     // alert('Application Session Expired');
            //     window.open(backtoSSoUrl,'_self');
            //     // sessionService.RemoveSession(ssoToken);
              
            // }

            // config.headers.Authorization = 'Bearer ' + UserInfo.token;
            // if (config.method == 'GET' && config.url.indexOf('uib') == -1 && config.url.indexOf('myPopoverTemplate') == -1 && config.url.indexOf('popover') == -1) {
            //     var separator = config.url.indexOf('?') === -1 ? '?' : '&';
            //     config.url = config.url + separator + 'noCache=' + new Date().getTime();
            // }

            return config;
        },
        requestError: function (config) {
            return config;
        },
        response: function (res) {
            return res;
        },
        responseError: function (res) {

            //-> Commented for testing
            // if (res.status) {
            //     // if(res.status == '400'){
            //     //     alert('Session Expired');
            //     // }else if(res.status == '401'){
            //     //     alert('Invalid Token');
            //     // }else if(res.status == '500'){
            //     //     alert('Technical Failure');
            //     // }else if(res.status == '502'){
            //     //     alert('Unauthorized - Access');
            //     // }

            //     if(res.status == '400' || res.status == '401' || res.status == '502'){
            //         sessionStorage.removeItem('SSOToken');
            //         sessionStorage.removeItem('SSOId');
            //         sessionStorage.removeItem('SSOUserDetails');
            //         document.cookie = "SSOkey" + '=;  path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            //         window.open(backtoSSoUrl,'_self');
            //     }
                
            // }

            return res;
        }
    };
}])

app.factory('_', ['$window', function ($window) {
    return $window._; // assumes underscore has already been loaded on the page
}]);


app.controller('ModalInstanceCtrl', ['$uibModal', '$scope', '$rootScope', '$uibModalInstance', '$timeout', '$interval', '$window', function ($uibModal, $scope, $rootScope, $uibModalInstance, $timeout, $interval, $window) {
    $rootScope.popupcancel = function () {
        $uibModalInstance.close('cancel');
    };
}]);