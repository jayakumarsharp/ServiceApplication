app.directive('validNumber', function () {
    return {
        require: '?ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return;
            }

            ngModelCtrl.$parsers.push(function (val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }

                var clean = val.replace(/[^-0-9\+]/g, '');
                var negativeCheck = clean.split('-');
                var decimalCheck = clean.split('.');

                if (!angular.isUndefined(negativeCheck[1])) {
                    negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                    clean = negativeCheck[0] + '-' + negativeCheck[1];
                    if (negativeCheck[0].length > 0) {
                        clean = negativeCheck[0];
                    }

                }

                /* commented to avoid .
                if(!angular.isUndefined(decimalCheck[1])) {
                    decimalCheck[1] = decimalCheck[1].slice(0,2);
                    clean =decimalCheck[0] + '.' + decimalCheck[1];
                }*/

                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render();
                }
                return clean;
            });

            element.bind('keypress', function (event) {
                if (event.keyCode === 32) {
                    event.preventDefault();
                }
            });
        }
    };
});


app.directive('allowPattern', [allowPatternDirective]);

function allowPatternDirective() {
    return {
        restrict: "A",
        compile: function (tElement, tAttrs) {
            return function (scope, element, attrs) {
                // I handle key events
                element.bind("keypress", function (event) {
                    var keyCode = event.which || event.keyCode; // I safely get the keyCode pressed from the event.
                    var keyCodeChar = String.fromCharCode(keyCode); // I determine the char from the keyCode.

                    // If the keyCode char does not match the allowed Regex Pattern, then don't allow the input into the field.
                    if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
                        event.preventDefault();
                        return false;
                    }

                });
            };
        }
    };
}


app.directive('noSpecialChar', function() {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function(scope, element, attrs, modelCtrl) {
        modelCtrl.$parsers.push(function(inputValue) {
          if (inputValue == undefined)
            return ''
          cleanInputValue = inputValue.replace(/[^\w\s]/gi, ''); 
          cleanInputValueBySpaces = inputValue.replace(/\S/gi,'');
          if ((cleanInputValue != inputValue) && (cleanInputValueBySpaces != inputValue)) {
            modelCtrl.$setViewValue(cleanInputValue);
            modelCtrl.$render();
          }
          return cleanInputValue;
        });
      }
    }
  })

  /// for restricting whitespace
  .directive('restrictField', function () {
    return {
        restrict: 'AE',
        scope: {
            restrictField: '='
        },
        link: function (scope) {
          // this will match spaces, tabs, line feeds etc
          // you can change this regex as you want
          var regex = /\s/g;

          scope.$watch('restrictField', function (newValue, oldValue) {
              if (newValue != oldValue && regex.test(newValue)) {
                scope.restrictField = newValue.replace(regex, '');
              }
          });
        }
    };
  })


app.directive('validateEmail', function () {
    var EMAIL_REGEXP = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
    return {
        link: function (scope, elm) {
            elm.on("keyup", function () {
                var isMatchRegex = EMAIL_REGEXP.test(elm.val());
                if (isMatchRegex && elm.hasClass('warning') || elm.val() == '') {
                    elm.removeClass('warning');
                } else if (isMatchRegex == false && !elm.hasClass('warning')) {
                    elm.addClass('warning');
                }
            });
        }
    }
});

app.filter('dateFormat', function($filter)
{
 return function(input)
 {
  if(input == null){ return ""; } 
 
  var _date = $filter('date')(new Date(input), 'dd-MM-yyyy HH:mm:ss');
 
  return _date.toUpperCase();

 };
});
app.filter('unique', function() {
    return function (arr, field) {
        return _.uniq(arr, function(a) { return a[field]; });
    };
});

app.directive('myDirective', function () {
    function link(scope, elem, attrs, ngModel) {
        ngModel.$parsers.push(function (viewValue) {
            var reg = /^[^`~!@#$%\^&*()_+={}|[\]\\:';"<>?,./1-9]*$/;
            // if view values matches regexp, update model value
            if (viewValue.match(reg)) {
                return viewValue;
            }
            // keep the model value as it is
            var transformedValue = ngModel.$modelValue;
            ngModel.$setViewValue(transformedValue);
            ngModel.$render();
            return transformedValue;
        });
    }

    return {
        restrict: 'A',
        require: 'ngModel',
        link: link
    };
});

app.directive('uppercased', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (input) {
                return input ? input.toUpperCase() : "";
            });
            element.css("text-transform", "uppercase");
        }
    }
});

//it allows all special characters
app.directive('allowOnlyNumbers', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                var $input = $(this);
                var value = $input.val();
                value = value.replace(/[^0-9]/g, '')
                $input.val(value);
                if (event.which == 64 || event.which == 16) {
                    // to allow numbers  
                    return false;
                } else if (event.which >= 48 && event.which <= 57) {
                    // to allow numbers  
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // to allow numpad number  
                    return true;
                } else if ([8, 13, 27, 37, 38, 39, 40].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  
                    return true;
                } else {
                    event.preventDefault();
                    // to stop others  
                    //alert("Sorry Only Numbers Allowed");  
                    return false;
                }
            });
        }
    }
});

app.directive('mobileNumbers', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                var $input = $(this);
                var value = $input.val();
                value = value.replace(/[^+,0-9]/g, '')
                
                $input.val(value);
                var isShiftKey = event.shiftKey;
                if (isShiftKey && (event.which==187 && (!value.length || value.length === 0))){
                    return true;
                }
                if (isShiftKey) {
                    return false;
                }
                if (event.which == 64 || event.which == 16) {
                    // to allow numbers  
                    return false;
                } else if (event.which >= 48 && event.which <= 57) {
                    // to allow numbers  
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // to allow numpad number  
                    return true;
                } else if ([8, 13, 27, 37, 38, 39, 40].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  
                    return true;
                } 
                else {
                    event.preventDefault();
                    // to stop others  
                    //alert("Sorry Only Numbers Allowed");  
                    return false;
                }
            });
        }
    }
});


app.directive("limitTo", [function() {
    return {
        restrict: "A",
        link: function(scope, elem, attrs) {
            var limit = parseInt(attrs.limitTo);
            angular.element(elem).on("keypress", function(e) {
                if (this.value.length == limit) e.preventDefault();
            });
        }
    }
}]);

app.directive('alphawithspace', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (inputValue) {
                if (inputValue == undefined)
                    return ''
                cleanInputValue = inputValue.replace(/[^a-zA-Z ]/g, '');
                if (cleanInputValue != inputValue) {
                    modelCtrl.$setViewValue(cleanInputValue);
                    modelCtrl.$render();
                }
                return cleanInputValue;
            });
        }
    }
});

app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.directive("ckEditor", ["$timeout", function ($timeout) {
    return {
        require: '?ngModel',
        link: function ($scope, element, attr, ngModelCtrl) {
            var editor = CKEDITOR.replace(element[0]);
            console.log(element[0], editor);

            editor.on("change", function () {
                $timeout(function () {
                    ngModelCtrl.$setViewValue(editor.getData());
                });
            });

            ngModelCtrl.$render = function (value) {
                editor.setData(ngModelCtrl.$modelValue);
            };
        }
    };
}]);


// app.filter('getObj', [
//     function() {
//         return function(input,val) {
//             var r,i;
//             for(i; i<input.length;i++) {
//                 if (input[i].CampaignName === val) {
//                    r = input[i];
//                    break;
//                 }
//             };
//             return r;
//         };
//     }
// ]);

 app.filter('sumByKey', function() {
        return function(data, key) {
            if (typeof(data) === 'undefined' || typeof(key) === 'undefined') {
                return 0;
            }
 
            var sum = 0;
            for (var i = data.length - 1; i >= 0; i--) {
                sum += parseInt(data[i][key]);
            }
 
            return sum;
        };
    });
    
app.filter('propsFilter', function() {
    return function(items, props) {
      var out = [];
  
      if (angular.isArray(items)) {
        items.forEach(function(item) {
          var itemMatches = false;
  
          var keys = Object.keys(props);
          for (var i = 0; i < keys.length; i++) {
            var prop = keys[i];
            var text = props[prop].toLowerCase();
            if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
              itemMatches = true;
              break;
            }
          }
  
          if (itemMatches) {
            out.push(item);
          }
        });
      } else {
        // Let the output be the input untouched
        out = items;
      }
  
      return out;
    }
  });
  
app.filter('getObj', function () {
    return function (inputValue, CampaignList) {
        var r, i;
        for (var i = 0; i < CampaignList.length; i++) {
            if (CampaignList[i].CampaignName == inputValue) {
                return CampaignList[i].CampaignName;
            }
        }
        return 1;
    };
});

app.filter('getCampStatus', function () {
    return function (inputValue, CampaignList) {
        var r, i;
        for (var i = 0; i < CampaignList.length; i++) {
            if (CampaignList[i].CampaignName == inputValue) {
                return CampaignList[i].UploadStatus;
            }
        }
        return 1;
    };
});

app.filter('validfile', function () {

    return function (inputfile, format) {
        // var validFormats = ['xls', 'xlsx','csv','txt'];
        var value = inputfile;
        var ext = value.substring(value.lastIndexOf('.') + 1).toLowerCase();
        return format.indexOf(ext) !== -1;
    }

});

app.filter('unique', function () {
    return function (input, key) {
        var unique = {};
        var uniqueList = [];
        for (var i = 0; i < input.length; i++) {
            if (typeof unique[input[i][key]] == "undefined") {
                unique[input[i][key]] = "";
                uniqueList.push(input[i]);
            }
        }
        return uniqueList;
    };
});


app.directive('checkFileSize', function () {
    return {
        link: function (scope, elem, attr, ctrl) {
            function bindEvent(element, type, handler) {
                if (element.addEventListener) {
                    element.addEventListener(type, handler, false);
                } else {
                    element.attachEvent('on' + type, handler);
                }
            }

            bindEvent(elem[0], 'change', function () {
                var fileName = this.files[0].name;
                var fileExtension = fileName.split('.').pop();
                var fileSize = this.files[0].size
                //alert('File size:' + this.files[0].size);

                switch (fileExtension) {
                    case 'txt': case 'xls': case 'xlsx': case 'csv':
                        // $('#divFiles').text('Image file, with an extension ' + fileExtension);
                        break;
                    // case 'html': case 'htm':
                    //      $('#divFiles').text('The file type is: ' + fileExtension);
                    // case 'pdf':
                    //      $('#divFiles').text('The file type is: ' + fileExtension);
                    //     break;
                    default:
                        // $('#divFiles').text('File type: Invalid File type');
                        alert('Invalid file type. Please select valid file');
                }
            });
        }
    }
});




app.directive('multiselect', function () {
    return {
        restrict: 'E',
        scope: {
            msModel: '=',
            msOptions: '=',
            msConfig: '=',
            msChange: '&'
        },
        replace: true,
        controller: ['$scope',
            function ($scope) {
                /* -------------------------------- *
                 *      Configuration defaults      *
                 * -------------------------------- */
                $scope.config = $scope.msConfig;
                if (typeof ($scope.config) === 'undefined') {
                    $scope.config = {};
                }
                if (typeof ($scope.config.itemTemplate) === 'undefined') {
                    $scope.config.itemTemplate = function (elem) {
                        return elem;
                    };
                }
                if (typeof ($scope.config.labelTemplate) === 'undefined') {
                    $scope.config.labelTemplate = function (elem) {
                        return elem;
                    };
                }
                if (typeof ($scope.config.modelFormat) === 'undefined') {
                    $scope.config.modelFormat = function (elem) {
                        return elem;
                    };
                }
                $scope.$watch('msOptions', function () {
                    _filterOptions();
                });

                

                /* -------------------------------- *
                 *          Multiselect setup       *
                 * -------------------------------- */
                if ($scope.msModel === null || typeof ($scope.msModel) === 'undefined') {
                    $scope.msModel = [];
                }
                if ($scope.msOptions === null || typeof ($scope.msOptions) === 'undefined') {
                    $scope.msOptions = [];
                }

                $scope.multiselect = {
                    filter: '',
                    filtered: [],
                    options: $scope.msOptions,
                    displayDropdown: true,
                    deleteSelected: function (index) {
                        var oldVal = angular.copy($scope.msModel);

                        if ($scope.msModel[index].name == 'ALL') {

                            for (var i = ($scope.msModel.length - 1); i < ($scope.msModel.length); i--) {
                                $scope.msModel.splice(i, 1);
                                if ($scope.msModel.length == 0) {
                                    i = $scope.msModel.length + 2;
                                }
                            }
                        }
                        else {
                            $scope.msModel.splice(index, 1);
                        }

                        $scope.msChange({
                            newVal: $scope.msModel,
                            oldVal: oldVal
                        });

                        _filterOptions();
                    },
                    selectElement: function (index) {

                        var oldVal = angular.copy($scope.msModel);

                        if ($scope.multiselect.filtered[index].name == 'ALL') {
                            for (var i = 0; i < $scope.multiselect.filtered.length; i++) {
                                $scope.msModel.push($scope.multiselect.filtered[i]);
                            }

                        }
                        else {
                            $scope.msModel.push($scope.multiselect.filtered[index]);
                        }


                        $scope.msChange({
                            newVal: $scope.msModel,
                            oldVal: oldVal
                        });

                        $scope.multiselect.filter = '';

                        _filterOptions();
                    },
                    focusFilter: function () {
                        $scope.multiselect.currentElement = 0;
                        if ($scope.config.hideOnBlur) {
                            $scope.multiselect.displayDropdown = true;
                        }
                    },
                    blurFilter: function () {
                        $scope.multiselect.currentElement = null;
                        if ($scope.config.hideOnBlur) {
                            $scope.multiselect.displayDropdown = false;
                        }
                    },
                    currentElement: null
                };

                if ($scope.config.hideOnBlur) {
                    $scope.multiselect.displayDropdown = false;
                }

                /* -------------------------------- *
                 *           Helper methods         *
                 * -------------------------------- */

                var _filterOptions = function () {
                    if ($scope.msModel === null) {
                        $scope.multiselect.options = $scope.msOptions;
                        return;
                    }
                    // else if($scope.msModel!=null && $scope.msModel.length>0)
                    // {
                    //    if($scope.msModel[0].name=='ALL')
                    //     {
                    //         $scope.multiselect.options = $scope.msOptions.filter(function(each){
                    //             return $scope.msModel=$scope.multiselect.options;
                    //         });

                    //     }
                    // }

                    $scope.multiselect.options = $scope.msOptions.filter(function (each) {
                        return $scope.msModel.indexOf(each) < 0;
                    });
                };
            }
        ],
        link: function (scope, element, attrs) {
            element.on('keydown', function (e) {
                var code = e.keyCode || e.which;
                switch (code) {
                    case 40: // Down arrow
                        scope.$apply(function () {
                            scope.multiselect.currentElement++;
                            if (scope.multiselect.currentElement >= scope.multiselect.filtered.length) {
                                scope.multiselect.currentElement = 0;
                            }
                        });
                        break;
                    case 38: // Up arrow
                        scope.$apply(function () {
                            scope.multiselect.currentElement--;
                            if (scope.multiselect.currentElement < 0) {
                                scope.multiselect.currentElement = scope.multiselect.filtered.length - 1;
                            }
                        });
                        break;
                    case 13: // Enter
                        scope.$apply(function () {
                            scope.multiselect.selectElement(scope.multiselect.currentElement);
                        });
                        break;
                    default:
                        scope.$apply(function () {
                            scope.multiselect.currentElement = 0;
                        });
                }
            });
        },
        template: function (elem, attrs) {
            var template = $(elem).find('template');
            return '<div class="multiselect" id="multi_popover">' +
                '   <div class="multiselect-labels">' +
                '       <span class="label label-default multiselect-labels-lg" ng-repeat="element in msModel">' +
                '           <span ng-bind-html="config.labelTemplate(element)"></span>' +
                '           <a href="" ng-click="$event.preventDefault(); multiselect.deleteSelected($index)" title="Remove element">' +
                '               <i class="fa fa-times"></i>' +
                '           </a>' +
                '       </span>' +
                '   </div>' +
                '   <input ng-show="multiselect.options.length > 0" placeholder="' + attrs.placeholder + '" type="text" class="form-control" ng-model="multiselect.filter" ng-focus="multiselect.focusFilter()" ng-blur="multiselect.blurFilter()" />' +
                '   <div ng-show="msModel.length < multiselect.options.length && multiselect.options.length === 0 && !multiselect.options.$resolved"><em>Loading...</em></div>' +
                '   <ul id="agent_dropdown" class="dropdown-menu" role="menu" ng-show="multiselect.displayDropdown && multiselect.options.length > 0">' +
                '       <li ng-repeat="element in multiselect.filtered = (multiselect.options | filter:multiselect.filter) track by $index" role="presentation" ng-class="{active: $index == multiselect.currentElement}">' +
                '           <a href="" role="menuitem" ng-click="$event.preventDefault(); multiselect.selectElement($index)" ng-bind-html="config.itemTemplate(element)"></a>' +
                '       </li>' +
                '   </ul>' +
                '</div>';
        }
    };
});


app.directive('myText', ['$rootScope', function($rootScope) {
    return {
    require: '?ngModel',
      link: function(scope, element, attrs, ngModelCtrl) {
        $rootScope.$on('add', function(e, val,id) {
          var domElement = element[0];
  
          if (domElement.id ==id) {
            if (document.selection) {
                domElement.focus();
                var sel = document.selection.createRange();
                sel.text = val;
                domElement.focus();
              } else if (domElement.selectionStart || domElement.selectionStart === 0) {
                var startPos = domElement.selectionStart;
                var endPos = domElement.selectionEnd;
                var scrollTop = domElement.scrollTop;
                domElement.value = domElement.value.substring(0, startPos)  + val + domElement.value.substring(endPos, domElement.value.length);
                domElement.focus();
                ngModelCtrl.$setViewValue(domElement.value);
                ngModelCtrl.$render();
                domElement.selectionStart = startPos + val.length;
                domElement.selectionEnd = startPos + val.length;
                domElement.scrollTop = scrollTop;
                return domElement.value;
              } else {
                domElement.value += val;
                domElement.focus();
              }
      
          }
          
        });
      }
    }
  }]);

  app.directive('onlyNumber', function() {
    return {
        require: '?ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text, element) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');
                    if (transformedInput === text)  {
                        var maxValue = ngModelCtrl.$$attr.maxValue;
                        if (Number(maxValue) < Number(transformedInput)) {
                            transformedInput = maxValue;
                        } else if (Number(transformedInput) < "0") {
                            transformedInput = "0";
                        }
                    }
                    var numberStr = Number(transformedInput).toString().trim();
                    ngModelCtrl.$setViewValue(numberStr);
                    ngModelCtrl.$render();
                    return transformedInput;
                }
                return undefined;
            }
            if (ngModelCtrl) {
                ngModelCtrl.$parsers.push(fromUser);            
            }
        }
    };
  })


/*end directives*/