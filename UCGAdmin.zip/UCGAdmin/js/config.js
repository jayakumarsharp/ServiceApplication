var config = config || {};

//API Url

<<<<<<< .mine
config.hostPath = 'http:///172.22.216.128/ucgApi_uat/api/';
// config.hostPath = 'http://172.22.216.145/ucgapi/api/';
config.hostPath = 'http://localhost/RISL_WEBAPI/api/';
||||||| .r1958
config.hostPath = 'http:///172.22.216.128/ucgApi_uat/api/';
// config.hostPath = 'http://172.22.216.145/ucgapi/api/';
// config.hostPath = 'http://localhost/RISL_WEBAPI/api/';
=======
//config.hostPath = 'http:///172.22.216.128/ucgApi_uat/api/';
//config.hostPath = 'http://172.22.216.145/ucgapi/api/';
config.hostPath = 'http://localhost/RISL_WEBAPI/api/';
>>>>>>> .r2082

// config.CMS_BASE_URL = 'http://172.22.216.128/ucgCms_uat/api/';
config.CMS_BASE_URL = 'http://172.22.216.145/ucgCmsApi/api/';
// config.CMS_BASE_URL = 'http://localhost:50669/api/';


//Voice Transcription Configuration - Folder
config.VoiceTransManaulProcessIP = '172.22.216.157';
config.VoiceDestinationSystem = '172.22.216.157';
config.VoiceDestinationDirectory = 'E:\\Serviont\\Nuance';

config.LINK_APP_URL = {
    SERVINTUIT : 'http://rmp-escr-sql054.rajasthan.gov.in:2050/ServIntuitUI/index.html',
    SERVCARE : '',
    FINESSE : 'https://dcfinpub1.rajasthan.gov.in:8445/',
    SAS : 'https://campaign.rajasthan.gov.in/SASRajSso/sasLogin',
    // SAS_UCG : 'http://localhost/ucgAdmin_uat/survey/campaign'
    SAS_UCG : 'http://rms-escr-win001.rajasthan.gov.in/ucgAdmin_uat/survey/campaign'
}