// var app = angular.module('adminApp', []);

// app.constant('appConst', {
    
//     RIGHTS_TYPES : {
//         SUPER_ADMIN : 'SUPERADMIN',
//     },

// });



var appConst = {
    RIGHTS_TYPES : {
         SUPER_ADMIN : 'SUPERADMIN',
    },
    MENUS : {
        DSBD : 'Dashboard:',
        USR_MGNT : {
            MGNT_PROF : 'User Management:Roles and Users'
        },
        CAMP_MGNT :{
            MGNT_CAMP : 'Outbound Voice Calling:Manage Campaign',
            DNC_MNG : 'Outbound Voice:Manage DNC List',
            RPT : 'Outbound Voice:Report'
        },
        RCHK_MGMT : {
            MGMT_QUES : 'RealityCheck Management:Manage Questions',
            MGMT_QUES_SET :'RealityCheck Management:Manage Survey',
            MGMT_RCHK_CAMP : 'RealityCheck Management:RealityCheck Campaigns',
            RCHK_APVL : 'RealityCheck Management:RealityCheck Approval',
            MNL_CALL : 'RealityCheck Management:Manual Calling',
            MY_MNL_CALL : 'RealityCheck Management:My Manual Call'
        },
        CMS : {
            MY_TICK: 'Case Management:My Tickets',
            CREATE_TICK: 'Case Management:Create Ticket',
            ASSIGN_TICK: 'Case Management:Assign Ticket',
            INBOX: 'Case Management:Inbox',
            REJECT: 'Case Management:Rejected Tickets',
            COMPLETE: 'Case Management:Completed Tickets',
        },
        MSD_CALL : {
            ASN_MSD_CALL : 'Missed Call Management:Assign Missed Calls',
            MY_ASN_CALL : 'Missed Call Management:My Assigned calls'
        },
        USSD_MGMT : {
            USSD_CNFG : 'USSD Management:USSD Configuration',
            USSD_UPLD : 'USSD Management:USSD Upload',
            USSD_CNT : 'USSD Management:USSD Contact'
        },
        SMS_MGMT : {
            SMS_CNFG : 'SMS Management:SMS Configuration',
            SMS_UPLD : 'SMS Management:SMS Upload',
            SMS_CNT : 'SMS Management:SMS Contact',
            SMS_CALL_OTME : 'SMS Management:Survey CallOutcome'
        },
        VCE_BIO : 'Voice Biometric:' ,
        IVR : 'IVR Call Management:',
        FAD : 'Finesse Agent Desktop:',
        MSTR_DATA : 'Master Data:',
        VCE_TRAN : {
            VCE_DSBD : 'Voice Transcription:Voice Dashboard',
            VCE_SCHD : 'Voice Transcription:Voice Schedule',
            VCE_CNFG : 'Voice Transcription:Voice Configuration'
        }
    },
    LINK_APP_R_NAME : {
        SERVINTUIT : 'SERVINTUIT ',
        SERVCARE : 'SERVCARE '
    },
    LINK_APP_URL:{
        SERVINTUIT : 'http://rmp-escr-sql054.rajasthan.gov.in:2050/ServIntuitUI/index.html',
        SERVCARE : '',
        FINESSE : 'https://dcfinpub1.rajasthan.gov.in:8445/'
    }

};