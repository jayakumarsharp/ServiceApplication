app.controller('EmailSurveyController', ['$scope', '$rootScope', 'appFactory', 'surveyFactory', function ($scope, $rootScope, appFactory, surveyFactory) {

    emailSurvey = this;
    emailSurvey.surveyId = '';
    emailSurvey.contactGUID = '';
    emailSurvey.currentQuestion = {};
    $('.modal-dialog .card').resizable().draggable();
    var getQuestionSet = function () {
        surveyFactory.GetAllQuestionSetbyId(emailSurvey.surveyId).then(function (data) {
            if (data.data && data.data.length) {
                questionSet = data.data[0];
                cbsGetQuestionSet();
            } else {
                toaster.pop({
                    type: "error",
                    body: "Error while fetching the data"
                });
            }
        });
    };

    var cbsGetQuestionSet = function () {
        questionSet.contactGUID = emailSurvey.contactGUID;
        if (!questionSet.IVRData) {
            toaster.pop({
                type: "warning",
                body: 'Survey not available'
            });
            return;
        }
        questionSet.IVRData = JSON.parse(questionSet.IVRData);
        initiateSurvey();
        document.getElementById('surveyNext').value = "Next";
        document.getElementById('surveyNext').style.backgroundColor = "##5cb85c";
        document.getElementById('surveyNext').style.borderColor = "#4cae4";
        $('#commentModal').modal('show');
    };

    var initiateSurvey = function () {
        var flowName = 'StartFlowNode';
        angular.forEach(questionSet.IVRData.Nodes, function (value, key) {
            if (value.NodeId === flowName) {
                // $scope.startNodeId = value.childnodes[0].NextNodeId;
                if (value.childnodes.length) {
                    nodeIdQueue = angular.copy(value.childnodes);
                }
            }
        });
        var firstItem = nodeIdQueue.shift();
        emailSurvey.currentQuestion = getQuestionByNodeId(firstItem.NextNodeId);
    };

    emailSurvey.getNextQuestion = function () {
        var ques = emailSurvey.currentQuestion;
        var answer = {
            NodeId: ques.NodeId,
            Question: ques.Question,
            SelectedOption: emailSurvey.Selected.Option
        }
        emailSurvey.AnswerSet.push(answer);
        emailSurvey.Selected = {};
        if (!nodeIdQueue.length) {
            completeSurvey();
            return;
        }
        var firstItem = nodeIdQueue.shift();
        emailSurvey.currentQuestion = getQuestionByNodeId(firstItem.NextNodeId);
        if (!nodeIdQueue.length) {
            document.getElementById('surveyNext').value = "Finish";
            document.getElementById('surveyNext').style.backgroundColor = "blue";
        }
    };

    var completeSurvey = function () {
        var anwseredQuesSet = {
            EmailGUID: questionSet.ContactGUID,
            JSONData: JSON.stringify(emailSurvey.AnswerSet)
        }
        surveyFactory.submitQuestionSurvey(anwseredQuesSet).then(function (data) {
            if (data.data) {
                toaster.pop({
                    type: "success",
                    body: 'Survey completed successfully'
                });
                emailSurvey.onSerachCallContacts();
                $('#commentModal').modal('hide');
                emailSurvey.AnswerSet = [];
                questionSet = [];
            } else {
                toaster.pop({
                    type: "error",
                    body: 'Error while updating survey'
                });
            }
        });
    }

    var getQuestionByNodeId = function (nodeID) {
        var question;
        angular.forEach(questionSet.IVRData.Nodes, function (value, key) {
            if (value.NodeId === nodeID) {
                question = value;
                if (!value.childnodes.length) {
                    return;
                }
                value.childnodes.reverse();
                value.childnodes.forEach(function (childNode) {
                    nodeIdQueue.unshift(childNode);
                });
                return;
            }
        });
        return question;
    };

    var getSurveyId = function () {
        emailSurvey.surveyId = 10;
        emailSurvey.contactGUID = "eb27ccee-efea-4e5b-a256-8efbf7790752";
        getQuestionSet();
    };

    var init = function () {
        getSurveyId();
    };

    init();

}])