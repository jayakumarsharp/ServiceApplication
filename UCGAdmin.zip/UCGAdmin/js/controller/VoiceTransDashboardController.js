app.controller('VoiceTransDashboardController', ['$scope', '$rootScope', 'appFactory', 'voiceTransFactory', 'toaster', '$timeout', function ($scope, $rootScope, appFactory, voiceTransFactory, toaster, $timeout) {

  var vm = this;
  $scope.flaghide=true;
  vm.gridVoiceDashboard = {
    paginationPageSizes: [10, 20, 30],
    paginationPageSize: 10,
    enableColumnMenus: false,
    enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
    enableVerticalScrollbar: 1,

    columnDefs: [{
        name: 'S.No',
        width: '10%',
        enableSorting: false,
        enableFiltering: false,
        cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
      },
      {
        name: 'Date',
        field: 'RequestDateTime',
		cellTooltip: true,
        cellFilter: 'date:\'dd-MM-yy\''
      },
      {
        name: 'File Format',
		cellTooltip: true,
        field: 'FileFormat'
      },
      {
        name: 'Success',
		cellTooltip: true,
        field: 'SuccessCount'
      },
      {
        name: 'Failure',
		cellTooltip: true,
        field: 'FailureCount'
      },
      {
        name: 'Waiting',
		cellTooltip: true,
        field: 'WaitingCount'
      },
      {
        name: 'Total',
		cellTooltip: true,
        field: 'TotalCount'
      },
      {
        name: 'Completed(%)',
		cellTooltip: true,
        cellTemplate: '<span title="{{row.entity.SuccessCount/row.entity.TotalCount*100|number:2}}%">{{row.entity.SuccessCount/row.entity.TotalCount*100|number:2}}%<span>'
      }
      // {name:'Percentage',cellTemplate:'<div class="progress"><div class="progress-bar" role="progressbar" aria-valuenow={{row.entity.SuccessCount/row.entity.FailureCount*100}} aria-valuemin="0" aria-valuemax="100" style="width:70%"><span class="sr-only">70% Complete</span></div></div>'}


    ],
    //  onRegisterApi: function (gridApi) {
    //   vm.gridApi = gridApi;
    // },
  };


  // $scope.gridVoiceDashboard.data = [
  //     { 'Date': '10-10-2017', 'Total': '100', 'SuccessCount': 50, 'FailureCount': 50, 'AwaitingCount': '30' },
  //     { 'Date': '10-10-2017', 'Total': '100', 'SuccessCount':60, 'FailureCount': 80, 'AwaitingCount': '30' },
  //     { 'Date': '10-10-2017', 'Total': '100', 'SuccessCount': 10, 'FailureCount': 20, 'AwaitingCount': '70' },

  // ];

  vm.open = {};
  var d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() -1);

  vm.range = {
    startDate: d,
    endDate: new Date()
  };

  vm.openCalendar = function (e, date) {
    vm.open[date] = !vm.open[date];
    e.preventDefault();
    e.stopPropagation();
    vm.open[date] = true;
  };
  vm.onSearchReports = function () {

    if (!validation()) {
      return;
    }

    getVoiceResponseStatus('default');
  };

  function validation() {
    var isValid = true;

    if (vm.range.startDate == undefined || !vm.range.startDate) {
      toaster.pop({
        type: "error",
        body: "Please enter valid Start date time"
      });
      isValid = false;
    }
    if (vm.range.endDate == undefined || !vm.range.endDate) {
      toaster.pop({
        type: "error",
        body: "Please enter valid End date time"
      });
      isValid = false;
    }
    var errMsg = appFactory.validateReportDates(vm.range.startDate, vm.range.endDate);
    if (errMsg) {
      toaster.pop({
        type: "error",
        body: errMsg
      });
      return false;
    }

    return isValid;
  };

  function getVoiceResponseStatus(Loadtype) {

    vm.GetVoiceResponseStatus = {};
    if (Loadtype == 'onload') {
      var d = new Date();
      d.setDate(d.getDate() - 1);
      vm.GetVoiceResponseStatus.fromDate = moment(d).format('YYYY-MM-DD HH:mm:ss');
      //moment().format('YYYY/MM/DD HH:mm:ss');
      vm.GetVoiceResponseStatus.todate = moment(new Date()).format('YYYY-MM-DD HH:mm:ss');
      //moment().format('YYYY/MM/DD HH:mm:ss');
    } else {
      vm.GetVoiceResponseStatus.fromDate = moment(vm.range.startDate).format('YYYY-MM-DD HH:mm:ss');
      vm.GetVoiceResponseStatus.todate = moment(vm.range.endDate).format('YYYY-MM-DD HH:mm:ss');
    }
   appFactory.ShowLoader();
    voiceTransFactory.GetVoiceResponseStatus(vm.GetVoiceResponseStatus).then(
      function success(data) {
        //console.log(data.data)
      appFactory.HideLoader();

        vm.gridVoiceDashboard.data = data.data;

        if (!vm.gridVoiceDashboard.data.length) {
          $scope.flaghide=false;

          //appFactory.showError("No data available")
         //toaster.pop({
           //  type: "error", 
            // body:"No data available" 
            // });
        }else{
          $scope.flaghide=true;
        }
      },
      function error(data) {
        appFactory.HideLoader();
        toaster.pop({
          type: "error",
          body: "Error while retrieving Voice ReportStatus"
        });
      }
    );
  };


  getVoiceResponseStatus('onload');


}]);