    app.controller('DashboardController', ['$scope', '$rootScope','profileFactory','toaster', function ($scope, $rootScope,profileFactory,toaster) {
    var dashboardData = [];
    var cmsData = [];

    Chart.defaults.global.defaultFontFamily = "'Roboto', 'Helvetica Neue', 'Helvetica', 'Arial', sans-serif";
    Chart.defaults.global.legend.position = 'bottom';
    Chart.defaults.global.legend.labels.usePointStyle = false;
    Chart.defaults.global.legend.labels.boxWidth = 5;
    Chart.defaults.global.legend.labels.boxHeight = 5;
    Chart.defaults.global.tooltips.backgroundColor = '#000';
    
    var isArray = Array.isArray ?
        function (obj) {
          return Array.isArray(obj);
        } :
        function (obj) {
          return Object.prototype.toString.call(obj) === '[object Array]';
        };

    getValueAtIndexOrDefault = (value, index, defaultValue) => {
        if (value === undefined || value === null) {
          return defaultValue;
        }
    
        if (isArray(value)) {
          return index < value.length ? value[index] : defaultValue;
        }
    
        return value;
      };


      $scope.DashSurvey = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [
        { name: 'Department Name', field: 'DepartmentName', isSearchable: true, cellTooltip: true,width:'35%' },
        {
            name: 'Mode', field: 'SurveyMode', cellTooltip: true,width:'17%'
        },
        { name: 'Name', field: 'SurveyName',cellTooltip: true,width:'17%' },
        { name: 'Assigned', field: 'Total Assigned',cellTooltip: true,width:'17%'},
        { name: 'Called', field: 'TotalCalled',cellTooltip: true,width:'15%' },
         
        ]
    };

    function dashboardInfo() {        
        profileFactory.GetDashboardInfo().then(
           function success(response) {
            dashboardData = response.data;
            $scope.cmsData = dashboardData.cmsInfo[0];
            $scope.dashCounts = dashboardData.CampaignCount[0];
            $scope.voiceData = dashboardData.voiceTransInfo;
            $scope.DashSurvey.data = dashboardData.OtherSurveyModeInfo;
            $scope.SurveyInfo = dashboardData.OtherSurveyModeInfo;
            $scope.MissedCallInfo = dashboardData.missedCallInfo;
            $scope.finesseInfo = dashboardData.finesseInfo[0];
            $scope.voiceCampInfo = dashboardData.voiceCampaignInfo;
            charts();
             if (!dashboardData) {
               toaster.pop({
                 type: "error",
                 body: "No data available"
               });
             }
           },
           function error(response) {
             toaster.pop({
               type: "error",
               body: "Error while retreiving Dashboard Data"
             });
           }
         );
    };
 
   function charts(){
    $scope.DepartmentID = $scope.SurveyInfo[0];
    $scope.MissCallDepartment = $scope.MissedCallInfo[0] ;
    $scope.VoiceCampId = $scope.voiceCampInfo[0] ;

    $scope.Missedcall($scope.MissCallDepartment);
    $scope.survey($scope.DepartmentID);  
    $scope.voiceCamp($scope.VoiceCampId);
    
    if($scope.cmsData){
    var ctx = document.getElementById("cmsInfo").getContext("2d");
    var myChart = new Chart(ctx, {
  
        type: 'doughnut',
        data: { 
        datasets: [{
            data: [$scope.cmsData.Closed, $scope.cmsData.Open, $scope.cmsData.Rejected, $scope.cmsData.Total , $scope.cmsData.WIP],
            backgroundColor: [
                '#36a2eb',                
                '#9966ff',
                '#4bc0c0',              
                '#ff9f40',
                '#ff6384'

            ],           
           
        }],
        
        // These labels appear in the legend and in the tooltips when hovering different arcs
        labels: [
            'Closed',
            'Open',
            'Rejected',
            'Total',
            'WIP'
        ]
    },
    options: {
        legend: {
            padding: 2,
            display: true,
            position: 'bottom',
            fullWidth: true,
     
   
        }
    }

    });
}

if($scope.voiceData.length){

    var ctx = document.getElementById("voiceTransEnglish").getContext("2d");
    ctx.height = 50;
    var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: { 
        datasets: [{
            data: [$scope.voiceData[0].Failure, $scope.voiceData[0].Success, $scope.voiceData[0].Waiting],
            // data: [20,40,40],
            backgroundColor: [
                '#FF6384',
                '#36A2EB',
                '#FFCD56', 
              ],
            // borderColor: [
            //     'rgba(255,99,132,1)',
            //     'rgba(54, 162, 235, 1)',
            //     'rgba(255, 206, 86, 1)',               
          
                
            // ],
            borderWidth: 1
        }],
        cutoutPercentage: 50,   
        // These labels appear in the legend and in the tooltips when hovering different arcs
        labels: [
            'Failure',
            'Success',
            'Waiting',         
        ]
    },

    });




    var ctx = document.getElementById("voiceTransHindi").getContext("2d");
    ctx.height = 50;
    var myChart = new Chart(ctx, {
        type: 'pie',
        data: { 
        datasets: [{    
            data: [$scope.voiceData[0].Failure, $scope.voiceData[0].Success, $scope.voiceData[0].Waiting],
            // data: [20,40,40],
            backgroundColor: [
                '#4bc0c0',
                '#9966ff',
                '#ff9f40',  
            ],

        }],
        cutoutPercentage: 50,   
        // These labels appear in the legend and in the tooltips when hovering different arcs
        labels: [
            'Failure',
            'Success',
            'Waiting',         
        ]
    },

    });
}

    // Finness Chart
 if($scope.finesseInfo){
      var ctx = document.getElementById("FinesseChart");
      ctx.height = 95;
      var myChart = new Chart(ctx, {
          type: 'bar',         
          data: {
            labels: ["","","","","" ],
            //   datasets: [{
            //         labels: ["Total Agents","Available Agents","Ready","Talking","NotReady" ],
                    
            //       data: [$scope.finesseInfo.TotalAgents, $scope.finesseInfo.AvailableAgents,$scope.finesseInfo.Ready, $scope.finesseInfo.Talking,$scope.finesseInfo.NotReady],
            //       backgroundColor: [
            //         'rgba(255,99,132,1)',
            //         'rgba(54, 162, 235, 1)',
            //         'rgba(255, 206, 86, 1)',
            //         'rgba(75, 192, 192, 1)',
            //         'rgba(153, 102, 255, 1)',
            //         'rgba(255, 159, 64, 1)'
            //       ],            
            //   }],

              datasets: [{
                label: 'Total Agents',
                backgroundColor: "#ff6384",
                data: [$scope.finesseInfo.TotalAgents]
              }, {
                label: 'Available Agents',
                backgroundColor: "#36a2eb",
                data: [$scope.finesseInfo.AvailableAgents]
              }, {
                label: 'Ready',
                backgroundColor: "#ffce56",
                data: [$scope.finesseInfo.Ready]
              }, {
                label: 'Talking',
                backgroundColor: "#4bc0c0",
                data: [$scope.finesseInfo.Talking]
              }, {
                label: 'NotReady',
                backgroundColor: "#9966ff",
                data: [$scope.finesseInfo.NotReady]
              }]
          },
          options: {
              legend: {
                  display: true,
                  position: 'bottom',

              },
              scales: {
                xAxes: [{
                    categoryPercentage: 1,
                    barThickness: 40,  
                }],
                  yAxes: [{
                    categoryPercentage: 1,
                    afterFit: function(scaleInstance) {
                        scaleInstance.height = 370; // sets the width to 100px
                      },
                      barThickness: 40,   
                      ticks: {
                          beginAtZero:true
                      }
                  }]
              }
          }
      });
   }

   }



$scope.survDeptObj = [];
$scope.survey = function(Department){ 

    if($scope.SurveyInfo.length){    
        var surName = _.findWhere($scope.SurveyInfo, {
            SurveyName: Department.SurveyName
        })
        $scope.survDeptObj = _.where($scope.SurveyInfo,{
            SurveyName: surName.SurveyName
        })        
         var emailTotal,emailCalled,manualTotal,manualCalled,ivrTotal,ivrCalled;   
         $scope.survDeptObj.forEach(function(element) {
             if(element.SurveyMode == "EmailCall"){
               emailTotal = element.TotalAssigned;
                emailCalled = element.TotalCalled;
             }
             if(element.SurveyMode == "ManualCall"){
               manualTotal = element.TotalAssigned;
               manualCalled = element.TotalCalled;
             }
             if(element.SurveyMode == "IVRCall"){
               ivrTotal = element.TotalAssigned;
               ivrCalled = element.TotalCalled;
             }
         }, this);
    
        var barOptions_stacked = {
            legend: {
                display: true,
                position: 'top',               
                fontSize: 5,
                labels:{
                    boxWidth: 5,
                }
            },
            tooltips: {
                enabled: true
                
            },
            hover :{
                animationDuration:0
            },
            title: {
                display: false,
                text: 'Department based inforation'
            },
            scales: {
                xAxes: [{
             barThickness: 10,    
                    ticks: {
                        beginAtZero:true,                
                    },
                      afterFit: function(scaleInstance) {
                            scaleInstance.height = 360; // sets the width to 100px
                          },
                  
                    scaleLabel:{
                        display:false
                    },
                    gridLines: {
                    }, 
                    stacked: false
                }],
                yAxes: [{         
                     barThickness: 20,    
                    stacked: false
                }]
            },      
          
            pointLabelFontFamily : "Quadon Extra Bold",
            scaleFontFamily : "Quadon Extra Bold",
        };

        
        var ctx = document.getElementById("surveyChart2");
 
        var myChart = new Chart(ctx, {
            type: 'horizontalBar',
            legend: {
                fontSize: 10
            },
            data: {
                labels: [
                    "Email",
                    "Manual",
                    "IVR"
                ],
                
                datasets: [{
                    label: 'Total',
                    data: [emailTotal,manualTotal,ivrTotal],
                    backgroundColor: ["rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)","rgba(255, 159, 64, 1)"],
                    hoverBackgroundColor: "rgba(255, 159, 64, 1)"
                },
                {
                    label: 'Called',
                    data: [emailCalled,manualCalled,ivrCalled],
                    backgroundColor: ["rgba(75, 192, 192, 1)","rgba(75, 192, 192, 1)","rgba(75, 192, 192, 1)"],
                    hoverBackgroundColor: "rgba(75, 192, 192, 1)"
                }]
            },
            options: barOptions_stacked,
        });
    }
}
//    Missedcall chart
// if($scope.MissedCallInfo){
   $scope.Missedcall = function(DepartmentID){     
        var deptID = _.findWhere($scope.MissedCallInfo, {
            DepartmentId: DepartmentID.DepartmentId
        })
        $scope.MCDept = _.where($scope.MissedCallInfo,{
            DepartmentId: deptID.DepartmentId
        })
        var assigned,unAssigned,closed;
        $scope.MCDept.forEach(function(element){
            if(element.Status =="Assigned"){
            assigned = element.TotalCount;
            }
            if(element.Status =="Unassigned"){
            unAssigned = element.TotalCount;
            }
            if(element.Status =="Closed"){
                closed = element.TotalCount;
            }
        })

        
    var ctx = document.getElementById("missedCallChart").getContext("2d");

    var myChart = new Chart(ctx, {
        type: 'pie',
        data: { 
        datasets: [{
             data: [assigned, unAssigned,closed],          
            backgroundColor: [
                '#FF6384',
                '#36A2EB',
                '#FFCD56',   
            ],

        }],
        cutoutPercentage: 50,   
        // These labels appear in the legend and in the tooltips when hovering different arcs
        labels: [
            'Assigned',
            'Unassigned',
            'Closed', 
              
        ]
    },
   
          

    });

        
       
    }
// }

    // Voice campaign

    $scope.voiceCamp = function(CampIdObj){ 
        var CampID = _.findWhere($scope.voiceCampInfo, {
            CampaignId: CampIdObj.CampaignId
        })
        var camp_voice_obj = _.where($scope.voiceCampInfo,{
            CampaignId : CampID.CampaignId
        })
         $scope.voice_campInfo = camp_voice_obj;

        var TotalDialed,TotalSuccess,TotalAbandoned,TotalFailed;
        $scope.voice_campInfo.forEach(function(item){
            TotalDialed = item.TotalDialed;
            TotalSuccess = item.TotalSuccess;
            TotalAbandoned = item.TotalAbandoned;
            TotalFailed = item.TotalFailed;
        })

    var ctx = document.getElementById("voiceCampChart").getContext("2d");
    ctx.width = 250;
    var myChart = new Chart(ctx, {
        type: 'pie',
        data: { 
        datasets: [{
             data: [TotalDialed, TotalSuccess,TotalAbandoned,TotalFailed],          
            backgroundColor: [
                '#FF6384',
                '#36A2EB',
                '#FFCD56',   
            ],

        }],
        cutoutPercentage: 50,   
        // These labels appear in the legend and in the tooltips when hovering different arcs
        labels: [
            'Total Dialed',
            'Total Success',
            'Total Abandoned', 
            'Total Failed'        
        ]
    },
   
          

    });
    }




      var init = function () {
        dashboardInfo();  
         
      }
      init();

      

}])