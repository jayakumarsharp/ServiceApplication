
app.controller('EmailManagementController', EmailManagementController);

EmailManagementController.$inject = ['masterDataFactory', 'toaster', '$rootScope', '$scope', '$sce'];

function EmailManagementController(masterDataFactory, toaster, $rootScope, $scope, $sce) {

    var vm = this;
    $scope.y = true;
    vm.FlagTemp = false;
    vm.FlagContent = false;
    vm.form = {};
    vm.formlist = {};
    vm.formlistEmail = {};
    vm.ConfigEdit = {};
    vm.EmailEdit = {};
    vm.SMTPConfigData = {};
    vm.filterTerm;
    vm.formPHolder = {};
    vm.IsselectedUsers = false;
    vm.wordCheck = true;
    vm.wordCheckUpdate = true;

    $('.modal-dialog .card').resizable().draggable();
    //multiselect field methods
    vm.multiselect = {
        selected: [],
        options: [],
        config: {
            hideOnBlur: false,
            showSelected: false,
            itemTemplate: function (item) {
                return $sce.trustAsHtml(item.name);
            },
            labelTemplate: function (item) {
                return $sce.trustAsHtml(item.name);
            }
        }
    };
    
    vm.assignUsers = function () {
        vm.assignedUsers = [];
        vm.assignedUserID = [];
        //vm.nameList={};
        var msUsers = vm.multiselect.selected;
        if (msUsers.length == 0 || msUsers == "") {
            vm.assignedUsers = null;
            vm.IsselectedUsers = false;
        }
        for (var index = 0; index < msUsers.length; index++) {
            console.log("msUsers", msUsers[index]);
            if (msUsers[index].name != 'ALL') {
                vm.assignedUsers.push(msUsers[index].name);
                vm.assignedUserID.push(msUsers[index].id);
                vm.IsselectedUsers = true;
            }

        }


    }
    vm.displayUsers = function () {
        return vm.multiselect.selected.map(function (each) {
            return each.name;
        }).join(', ');
    };
    vm.clearUsers = function () {
        vm.multiselect = {
            selected: [],
            options: [],
            config: {
                hideOnBlur: false,
                showSelected: false,
                itemTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                },
                labelTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                }
            }
        };
        vm.binddata();
    }
    vm.clearPopup = function () {
        //debugger;
        vm.multiselect = {

            options: [],
            config: {
                hideOnBlur: false,
                showSelected: false,
                itemTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                },
                labelTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                }
            }
        };
    }

    //mockdata for multiselect list
    vm.mockdata = [{ Id: 1, AgentName: "prabu", AgentID: "ALL", Department: "computer", email: "prabu.ramu@servion.com", name: "prabu", test: "testing email", Signature: "Admin" },
    { Id: 2, AgentName: "Person2", AgentID: "ALL", Department: "computer", email: "rajavel@servion.com", name: "Rajavel", test: "testing email masterdata", Signature: "Manager" }
    ];

    vm.mockdata.splice(0, 0, { Id: 0, AgentName: "ALL", AgentID: "ALL", Department: "" });

    vm.binddata = function () {

        //   console.log("data", success.data);
        //  vm.multiselect.options = vm.mockdata.AgentName;
        vm.multiselect.options = vm.mockdata.map(function (item) {
            console.log("item", item);
            return {
                name: item.AgentName,
                id: item.Id
            };
        });
    }
    vm.binddata();

    //send email 
    vm.sendEmail = function () {
        if (vm.IsselectedUsers == false) {
            toaster.pop({ type: "error", body: "Please select names to send email" });
        }
        else {

            var i = 0;
            vm.finalList = {};


            angular.forEach(vm.assignedUserID, function (userID) {
                angular.forEach(vm.mockdata, function (obj) {
                    if (obj.Id == userID) {
                        vm.finalList[i] = obj;
                        i++;
                    }

                });
            });
            // console.log("emaillist",vm.finalList);
            var i = 0;
            vm.emailList = {};
            angular.forEach(vm.finalList, function (obj) {
                vm.emailList[i] = {};
                var str = vm.emailContent.Subject;
                var str2 = vm.emailContent.MessageText;
                var z;
                angular.forEach(vm.keywords, function (placeholder) {
                    var x = "{{" + placeholder + "}}";
                    for (z in obj) {
                        if (z == placeholder) {
                            var y = obj[z];
                        }
                    }
                    if (typeof y == 'undefined') {
                        y = '****';
                    }
                    str = str.replace(x, y);
                    str2 = str2.replace(x, y);
                });
                vm.emailList[i].Subject = str;
                vm.emailList[i].messageBody = str2;
                vm.emailList[i].To = obj.email;


                i++;
                console.log("emaillist", vm.finalList);

            });

            console.log("emaillisssst", vm.emailList);
            var iobj = {};

            iobj.config = vm.SMTPConfigData;
            iobj.emailList = vm.emailList;
            masterDataFactory.SendEmail(iobj).then(function (data) {

                if (data.data == "Success") {
                    vm.clearUsers();
                    var xyz;
                    vm.GetTempName(xyz);

                    $('#assignEmailModal').modal('hide');
                    toaster.pop({ type: "Success", body: "Mail sent  successfully" });

                }
                else {
                    vm.clearUsers();
                    toaster.pop({ type: "error", body: "Error while sending" });

                }
            });
        }
    }


    //Grid Specification for department
    vm.gridOption = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [
            { displayName: 'Department',cellTooltip: true, field: 'DepartmentName' },
            { displayName: 'Email',cellTooltip: true, field: 'Email' },
            { displayName: 'Password',cellTooltip: true, field: 'PassWord', visible: false },

            { name: 'Options', enableSorting: false, enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }


        ],
    }
    //grid specification for placeholder
    vm.gridPlaceholder = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [
            { name: 'S.No', width: '10%',enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },

            { displayName: 'Department',cellTooltip: true, field: 'DepartmentName' },
            { displayName: 'Placeholder',cellTooltip: true, field: 'PlaceholderName' },
            // { displayName: 'Password', field: 'PassWord', visible: false },

            { name: 'Options', enableSorting: false, enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showEditPHolder(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.vm.showDeletePlaceholder(row.entity)"><span class="fa fa-trash-o"></span></a>' }


        ],
    }

    //grid specification for templates
    vm.gridTemplate = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        enableFiltering: true,
        columnDefs: [
            { name: 'S.No', width: '10%', enableSorting: false,enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            { displayName: 'Department', cellTooltip: true,field: 'DepartmentName' },
            { displayName: 'TemplateName',cellTooltip: true,field: 'TemplateName', enableFiltering: false },
            { displayName: 'TemplateSubject',cellTooltip: true, field: 'Subject', visible: false },
            //   { displayName: 'ID', field: 'ID',visible:false},
            //  { displayName: 'test', field: 'gender', cellFilter: 'mapGender' },
            { displayName: 'Templatebody', field: 'MessageText', visible: false },
            { name: 'Options', enableSorting: false, enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showEmailEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.vm.showEmailDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }


        ],
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
            // $scope.gridApi.grid.registerRowsProcessor( $scope.singleFilter, 200 );
        }
    }

    //filter template based on department 

    vm.filterGrid = function (value) {
        // console.log(value);
        var filtervalue = '';
        angular.forEach(vm.DepartmentDropDownValue, function (dep) {

            if (dep.ID == value) {
                filtervalue = dep.DepartmentName
            }


        });
        // value='Computer';
        $scope.gridApi.grid.columns[1].filters[0].term = filtervalue;
    };





    //Data binding to Grid
    vm.GetDepartmentEmailConfig = function () {

        masterDataFactory.GetDepartmentEmailConfig().then(
            function success(response) {


                vm.gridOption.data = response.data;
                // vm.gridPlaceholder.data = response.data;
            },
            function error(data) {

            }
        )
    }
    vm.GetDepartmentEmailConfig();

    //Data binding to Grid
    vm.GetEmailTemplate = function () {

        masterDataFactory.GetEmailTemplate().then(
            function success(response) {


                vm.gridTemplate.data = response.data;
                vm.EmailContent = response.data;
            },
            function error(data) {

            }
        )
    }
    vm.GetEmailTemplate();
    //data binding to Grid
    vm.GetEmailPlaceHolder = function () {

        masterDataFactory.GetEmailPlaceHolder().then(
            function success(response) {


                vm.gridPlaceholder.data = response.data;
                vm.DataList = response.data;
            },
            function error(data) {

            }
        )
    }
    vm.GetEmailPlaceHolder();
    //Data Binding to Department Dropdown
    vm.GetDepartmentName = function () {

        masterDataFactory.GetDepartmentName().then(
            function success(data) {

                // console.log("editSMS",data);
                vm.DepartmentDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }
    vm.GetDepartmentName();
    vm.abusiveWords = [];
    vm.GetAbusiveWords = function () {
        masterDataFactory.GetInvalidWords().then(
            function success(response) {
                //  console.log("edit", data);
                vm.abusiveWords = response.data;
            },
            function error(response) {
                toaster.pop({
                    type: "error",
                    body: "Error occured while retreiving the data"
                });

            }
        )
    }
    vm.GetAbusiveWords();

    //password hide show functions
    vm.inputType = 'password';
    vm.hideShowPassword = function () {
        if (vm.inputType == 'password')
            vm.inputType = 'text';
        else
            vm.inputType = 'password';
    };

    //email delete functionality
    vm.showEmailDelete = function (getRowData) {
        vm.CodeID = getRowData.Id;
        vm.EditView = true;
        $('#confirmModalEmailTemp').modal('show');
    }


    //Delete functionality
    //confirmModalEmailPlace
    vm.showDelete = function (getRowData) {
        vm.CodeID = getRowData.ID;
        vm.EditView = true;
        $('#confirmModalEmail').modal('show');
    }
    vm.DeleteEmailTemplate = function () {
        var EmailDel = {};
        EmailDel.ID = vm.CodeID;
        EmailDel.updatedBy = 'Admin';
        masterDataFactory.DeleteEmailTemplate(EmailDel).then(function (data) {
            // console.log(data);
            // console.log(data.data);

            if (data.data == "Success") {
                vm.GetEmailTemplate();

                $('#confirmModalEmailTemp').modal('hide');
                toaster.pop({ type: "Success", body: "Deleted successfully" });

            }
            else {
                vm.GetEmailTemplate();
                toaster.pop({ type: "error", body: "Error while creating", toasterId: 1 });

            }
        });
    }

    vm.Delete = function () {
        var DeleteDepartmentEmailConfig = {};
        DeleteDepartmentEmailConfig.ID = vm.CodeID;
        DeleteDepartmentEmailConfig.updatedBy = 'Admin';
        masterDataFactory.DeleteDepartmentEmailConfig(DeleteDepartmentEmailConfig).then(function (data) {
            console.log(data);
            console.log(data.data);

            if (data.data == "Success") {
                vm.GetDepartmentEmailConfig();

                $('#confirmModalEmail').modal('hide');
                toaster.pop({ type: "Success", body: "Deleted successfully" });

            }
            else {
                vm.GetDepartmentEmailConfig();
                toaster.pop({ type: "error", body: "Error while creating", toasterId: 1 });

            }
        });
    }
    //Add functionality
    vm.showAdd = function () {
        //console.log("hi");
        vm.Formlist = {};
        vm.form.SmtpConfig.$setPristine();

        $('#AddSmtpConfig').modal('show');

    }
    vm.CreateEmailSmtpConfig = function () {


        var ConfigAdd = {};


        ConfigAdd.CreatedBy = 'Admin';
        ConfigAdd.DepartmentID = vm.Formlist.DepartmentID;
        ConfigAdd.ApplicationID = vm.Formlist.ApplicationID;
        ConfigAdd.Email = vm.Formlist.Email;
        ConfigAdd.PassWord = vm.Formlist.PassWord;


        masterDataFactory.CreateDepartmentEmailConfig(ConfigAdd).then(function (data) {
            console.log(data);
            console.log(data.data);

            if (data.data == "Success") {
                vm.GetDepartmentEmailConfig();
                $('#AddSmtpConfig').modal('hide');
                vm.Formlist = {};
                vm.form.SmtpConfig.$setPristine();
                toaster.pop({ type: "Success", body: "Created successfully" });

            }
            else {
                vm.GetDepartmentEmailConfig();
                toaster.pop({ type: "error", body: "some Error  occured while creating" });

            }
        });

    }

    //Update functionality
    vm.showEdit = function (getRowData) {
        vm.ConfigEdit.DepartmentID = getRowData.DepartmentID;
        vm.ConfigEdit.ID = getRowData.ID;
        vm.ConfigEdit.Email = getRowData.Email;
        vm.ConfigEdit.PassWord = getRowData.PassWord;


        vm.EditView = true;
        $('#ModifySmtpConfig').modal('show');
    }

    vm.UpdateEmailSmtpConfig = function () {

        var ConfigUpdate = {};

        ConfigUpdate.UpdatedBy = 'Admin';
        ConfigUpdate.DepartmentID = vm.ConfigEdit.DepartmentID;
        ConfigUpdate.ID = vm.ConfigEdit.ID;
        ConfigUpdate.Email = vm.ConfigEdit.Email;
        ConfigUpdate.PassWord = vm.ConfigEdit.PassWord;


        masterDataFactory.UpdateDepartmentEmailConfig(ConfigUpdate).then(function (data) {

            if (data.data == "Success") {
                vm.GetDepartmentEmailConfig();
                $('#ModifySmtpConfig').modal('hide');
                toaster.pop({ type: "Success", body: "updated successfully" });

            }
            else {
                vm.GetDepartmentEmailConfig();
                toaster.pop({ type: "error", body: "Error while updating" });

            }
        });

    }


    //Smtpconfig Data retreive
    vm.GetSMTPConfig = function () {

        masterDataFactory.GetSMTPConfig().then(
            function success(response) {

                if (response.data[0]) {
                    vm.SMTPConfigData = response.data[0];
                    vm.SMTPConfigData.FlagDisable = true;
                    vm.SMTPConfigData.ButtonLabel = 'Edit';
                }
                else {
                    vm.SMTPConfigData.FlagDisable = false;
                    vm.SMTPConfigData.ButtonLabel = 'create';
                }

            },
            function error(data) {
                toaster.pop({ type: "error", body: "some error occured while getting smtp config detail" });

            }
        )
    }
    vm.GetSMTPConfig();
    //Update Smtp config 
    vm.updateSMTPConfig = function () {

        if (vm.SMTPConfigData.ButtonLabel == 'Edit') {
            vm.SMTPConfigData.FlagDisable = false;
            vm.SMTPConfigData.ButtonLabel = 'update';
        }


        else {

            var ConfigSMTPUpdate = {};
            ConfigSMTPUpdate.ServerIP = vm.SMTPConfigData.ServerIP;
            ConfigSMTPUpdate.Port = vm.SMTPConfigData.Port;
            ConfigSMTPUpdate.PassWord = vm.SMTPConfigData.PassWord;
            ConfigSMTPUpdate.FromEmail = vm.SMTPConfigData.EmailAddress;
            ConfigSMTPUpdate.IsSecured = vm.SMTPConfigData.IsSecured;
            ConfigSMTPUpdate.updatedBy = 'Admin';
            ConfigSMTPUpdate.SMTPConfigID = vm.SMTPConfigData.SMTPConfigID;

            masterDataFactory.UpdateEmailSMTPConfig(ConfigSMTPUpdate).then(function (data) {

                if (data.data == "Success") {
                    vm.SMTPConfigData.FlagDisable = true;
                    vm.SMTPConfigData.ButtonLabel = 'Edit';
                    toaster.pop({ type: "Success", body: "updated successfully" });

                }
                else {

                    toaster.pop({ type: "error", body: "Error while updating" });

                }
            });
        }




    }



    //displaying placeholder based on department in create/update template

    vm.Listfilter = function (value) {
        // console.log(value);
        // var filtervalue = '';
        if (typeof value == 'undefined' || value == 0) {
            vm.formlistEmail = {};
            // vm.formlistEmail.Subject='';
            vm.keywords = [];
        }
        else {
            var i = 0;
            vm.keywords = [];
            vm.formlistEmail.MessageText = '';
            vm.formlistEmail.Subject = '';
            angular.forEach(vm.DataList, function (obt) {

                if (obt.DepartmentID == value) {
                    vm.keywords[i] = obt.PlaceholderName;
                    i++;
                }

            });
        }


    }

    //resetting value while switching tabs
    vm.setDefault = function () {
        vm.formlistEmail = {};
        vm.wordCheck = true;
        vm.form.EmailTemp.$setPristine();
        //vm.formlistEmail.Subject='';
        vm.Listfilter(0);
    }
    vm.setDefaultEmailSend = function () {
        var xyz;
        vm.GetTempName(xyz);
    }



    //Adding placeholder text to body/messagetext 
    vm.add = function (key) {
        vm.someInput = '<<' + key + '>>';
        vm.items = [];
        if (vm.FlagA == true) {
            vm.id = 'emailSubject';
        } else if (vm.FlagB == true) {
            vm.id = 'emailMessage';
        } else {
            vm.id = '';

        }
        vm.items.push(vm.someInput);
        $rootScope.$broadcast('add', vm.someInput, vm.id);
    }

    //create email template
    vm.CreateEmailTemplate = function () {

        vm.wordCheck = true;
        var words = vm.formlistEmail.MessageText + " " + vm.formlistEmail.Subject;
        var arr = words.split(" ");
        vm.wrongWords = [];
        vm.words=[];
        arr.forEach(function (value, key) {
            vm.abusiveWords.forEach(function (data) {
                var dbword = data.InvalidWord.toLowerCase();
                var enteredWord = value.toLowerCase();
                if (enteredWord == dbword) {
                    vm.wordCheck = false;
                    vm.words.push(value);
                }
            })
        })
        vm.wrongWords=_.uniq(vm.words);

        if (vm.wordCheck) {
            var TempAdd = {};
            TempAdd.CreatedBy = 'Admin';
            TempAdd.DepartmentID = vm.formlistEmail.DepartmentID;
            TempAdd.TemplateName = vm.formlistEmail.TemplateName;
            TempAdd.Subject = vm.formlistEmail.Subject;
            TempAdd.MessageText = vm.formlistEmail.MessageText;
            masterDataFactory.CreateEmailTemplate(TempAdd).then(function (data) {
                // console.log(data);
                //console.log(data.data);

                if (data.data == "Success") {
                    vm.GetEmailTemplate();
                    // $('#AddSmtpConfig').modal('hide');
                    vm.formlistEmail = {};
                    vm.form.EmailTemp.$setPristine();
                    toaster.pop({ type: "Success", body: "Created successfully" });

                }
                else {
                    vm.GetEmailTemplate();
                    toaster.pop({ type: "error", body: "some Error  occured while creating" });

                }
            });
        }



    }
    //update email template
    vm.showEmailEdit = function (getRowData) {
        //console.log("hi");
        vm.Formlist = {};
        vm.form.SmtpConfig.$setPristine();
        vm.EmailEdit.DepartmentID = getRowData.DepartmentID;
        vm.EmailEdit.TemplateName = getRowData.TemplateName;
        vm.EmailEdit.Subject = getRowData.Subject;
        vm.EmailEdit.MessageText = getRowData.MessageText;
        vm.EmailEdit.Id = getRowData.Id;
        vm.Listfilter(getRowData.DepartmentID);
        vm.wordCheckUpdate = true;

        $('#modifyEmailTemplate').modal('show');

    }
    vm.UpdateEmailTemplate = function () {

        vm.wordCheckUpdate = true;
        var words =vm.EmailEdit.MessageText + " " + vm.EmailEdit.Subject;
        var arr = words.split(" ");
        vm.wrongWordsUpdate = [];
        vm.wrongwordup=[];
        arr.forEach(function (value, key) {
            vm.abusiveWords.forEach(function (data) {
                var dbword = data.InvalidWord.toLowerCase();
                var enteredWord = value.toLowerCase();
                if (enteredWord == dbword) {
                    vm.wordCheckUpdate = false;
                    vm.wrongwordup.push(value);
                }
            })
        })
        vm.wrongWordsUpdate =_.uniq(vm.wrongwordup);

        if(vm.wordCheckUpdate){
            var EmailUpdate = {};
            
                    EmailUpdate.UpdatedBy = 'Admin';
                    EmailUpdate.DepartmentID = vm.EmailEdit.DepartmentID;
                    EmailUpdate.TemplateName = vm.EmailEdit.TemplateName;
                    EmailUpdate.Subject = vm.EmailEdit.Subject;
                    EmailUpdate.MessageText = vm.EmailEdit.MessageText;
                    EmailUpdate.Id = vm.EmailEdit.Id;
            
            
            
                    masterDataFactory.UpdateEmailTemplate(EmailUpdate).then(function (data) {
            
                        if (data.data == "Success") {
                            vm.GetEmailTemplate();
                            $('#modifyEmailTemplate').modal('hide');
                            toaster.pop({ type: "Success", body: "updated successfully" });
            
                        }
                        else {
                            vm.GetEmailTemplate();
                            toaster.pop({ type: "error", body: "Error while updating" });
            
                        }
                    });
            
        }
       
    }
    //create placeholder
    vm.showPlaceholderAdd = function () {
        //console.log("hi");
        vm.formPHolder = {};
        vm.form.PHolder.$setPristine();

        $('#AddPlaceholder').modal('show');

    }

    vm.CreateEmailPlaceHolder = function () {

        var PlaceholderAdd = {};


        PlaceholderAdd.CreatedBy = 'Admin';
        PlaceholderAdd.DepartmentID = vm.formPHolder.DepartmentID;
        PlaceholderAdd.PlaceholderName = vm.formPHolder.PlaceholderName;



        masterDataFactory.CreateEmailPlaceHolder(PlaceholderAdd).then(function (data) {
            // console.log(data);
            //console.log(data.data);

            if (data.data == "Success") {
                vm.GetEmailPlaceHolder();
                $('#AddPlaceholder').modal('hide');
                vm.formPHolder = {};
                vm.form.PHolder.$setPristine();
                toaster.pop({ type: "Success", body: "Created successfully" });

            }
            else {
                vm.GetEmailPlaceHolder();
                toaster.pop({ type: "error", body: "some Error  occured while creating" });

            }
        });

    }

    //update placeholder
    vm.showEditPHolder = function (getRowData) {

        vm.PlaceEdit = {};

        vm.PlaceEdit.DepartmentID = getRowData.DepartmentID;
        vm.PlaceEdit.PlaceholderName = getRowData.PlaceholderName;
        vm.PlaceEdit.ID = getRowData.ID;
        $('#ModifyPlaceholder').modal('show');

    }

    vm.UpdateEmailPlaceHolder = function () {

        var PlaceUpdate = {};

        PlaceUpdate.UpdatedBy = 'Admin';
        PlaceUpdate.DepartmentID = vm.PlaceEdit.DepartmentID;
        PlaceUpdate.PlaceholderName = vm.PlaceEdit.PlaceholderName;
        PlaceUpdate.ID = vm.PlaceEdit.ID;




        masterDataFactory.UpdateEmailPlaceHolder(PlaceUpdate).then(function (data) {

            if (data.data == "Success") {
                vm.GetEmailPlaceHolder();
                $('#ModifyPlaceholder').modal('hide');
                toaster.pop({ type: "Success", body: "updated successfully" });

            }
            else {
                vm.GetEmailPlaceHolder();
                toaster.pop({ type: "error", body: "Error while updating" });

            }
        });

    }

    //confirmModalEmailPlace
    vm.showDeletePlaceholder = function (getRowData) {
        vm.CodeID = getRowData.ID;
        vm.EditView = true;
        $('#confirmModalEmailPlace').modal('show');
    }
    vm.DeleteEmailPlaceHolder = function () {
        var PlaceDel = {};
        PlaceDel.ID = vm.CodeID;
        PlaceDel.updatedBy = 'Admin';
        masterDataFactory.DeleteEmailPlaceHolder(PlaceDel).then(function (data) {
            // console.log(data);
            // console.log(data.data);

            if (data.data == "Success") {
                vm.GetEmailPlaceHolder();

                $('#confirmModalEmailPlace').modal('hide');
                toaster.pop({ type: "Success", body: "Deleted successfully" });

            }
            else {
                vm.GetEmailPlaceHolder();
                toaster.pop({ type: "error", body: "Error while creating", toasterId: 1 });

            }
        });
    }

    //filtering template name based on department
    vm.GetTempName = function (value) {
        vm.Listfilter(value);
        if (typeof value == 'undefined') {
            vm.FlagTemp = false;
            vm.FlagContent = false;
        }
        else {
            vm.filterContent = {};
            var i = 0;
            angular.forEach(vm.EmailContent, function (obj) {

                if (obj.DepartmentID == value) {
                    vm.filterContent[i] = obj;
                    vm.FlagTemp = true;
                    i++;
                }

            });
        }


    }

    //filtering email body && message text based on template name
    vm.GetEmailContent = function (value) {

        if (typeof value == 'undefined') {
            vm.FlagContent = false;
        }
        else {
            vm.emailContent = {};
            vm.FlagContent = true;
            //var i=0;
            angular.forEach(vm.filterContent, function (obj) {

                if (obj.Id == value) {
                    vm.emailContent = obj;
                    // i++;
                }
            });
        }


    }

}
