app.controller('NuanceServerConfigController', function ($scope, $rootScope, masterDataFactory, toaster) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
   // $rootScope.departmentName = userObj.departmentId;
    $rootScope.departmentName = "103";
    $scope.smsCodeEdit = [];
    $scope.Formlist = {};
    $scope.form = {};
    $scope.SmsCode = {};
    $scope.NaunceServerAdd = {};

    $scope.gridNuanceServerData = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [
            { name: 'S.No', width: '10%',enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            { name: 'FileFormat',cellTooltip: true, field: 'FileFormat' },
            { name: 'RequestURL',cellTooltip: true, field: 'RequestUrl' },
            { name: 'Options',  enableSorting: false,enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }
        ],
    };




    $scope.GetNuanceServerData = function () {

        masterDataFactory.GetNuanceServerData().then(
            function success(response) {
                //  console.log("edit", data);
                $scope.gridNuanceServerData.data = response.data;

            },
            function error(response) {
                toaster.pop({ type: "error", body: "Error occured while retreiving the Nuance server data" });

            }
        )
    }
    $scope.GetNuanceServerData();

    $scope.GetLanguageFormat = function () {
        masterDataFactory.GetLanguageFormat().then(
            function success(data) {

                // console.log("editSMS",data);
                $scope.DepartmentDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }
    $scope.GetLanguageFormat();



    $scope.showAdd = function () {
        $scope.Formlist = {};
        $scope.form.NuanceServerAdd.RequestUrl.$error.validationError = false;
        $scope.form.NuanceServerAdd.$setPristine();
        $('#addNuanceServer').modal('show');

    }


    $scope.CreateNuanceServer = function () {
        // $scope.validateserver($scope.Formlist.RequestUrl);

        $scope.form.NuanceServerAdd.RequestUrl.$error.validationError = false;
        angular.forEach($scope.gridNuanceServerData.data, function (rowdata) {
            if (rowdata.RequestUrl == $scope.Formlist.RequestUrl) {
                $scope.form.NuanceServerAdd.RequestUrl.$error.validationError = true;
            }

        });

        if ($scope.form.NuanceServerAdd.RequestUrl.$error.validationError == false) {



            // $scope.SmsCodeAdd.ThresholdType = 2;
            $scope.NaunceServerAdd.UpdatedBy = userObj.SSOID;
            $scope.NaunceServerAdd.FileFormat = $scope.Formlist.FileFormat;
            $scope.NaunceServerAdd.RequestUrl = $scope.Formlist.RequestUrl;
            masterDataFactory.CreateNuanceConfig($scope.NaunceServerAdd).then(function (data) {
                if (data.data == "Success") {
                    $scope.GetNuanceServerData();
                    $('#addNuanceServer').modal('hide');
                    $scope.Formlist = {};
                    $scope.form.NuanceServerAdd.$setPristine();
                    toaster.pop({ type: "Success", body: "Server Created successfully" });

                }
                else {
                    $scope.GetNuanceServerData();
                    toaster.pop({ type: "error", body: "Error while creating Server" });

                }
            });
        }



    }

    $scope.showEdit = function (getRowData) {
        $scope.NaunceServerEdit = {};
        // console.log("edit2", getRowData);
        $scope.NaunceServerEdit.FileFormat = getRowData.FileFormat;
        $scope.NaunceServerEdit.RequestUrl = getRowData.RequestUrl;
        $scope.Urlvalidate = getRowData.RequestUrl;
        

        $scope.NaunceServerEdit.Id = getRowData.Id;
        $scope.form.NuanceServerModify.RequestUrl.$error.validationError = false;
        //console.log("hello");
        $scope.EditView = true;
        $('#modifyNuanceServer').modal('show');
    }

    $scope.UpdateNuanceServer = function () {


        $scope.form.NuanceServerModify.RequestUrl.$error.validationError = false;
        if ($scope.Urlvalidate != $scope.NaunceServerEdit.RequestUrl) {
            angular.forEach($scope.gridNuanceServerData.data, function (rowdata) {

                if (rowdata.RequestUrl == $scope.NaunceServerEdit.RequestUrl) {

                    $scope.form.NuanceServerModify.RequestUrl.$error.validationError = true;

                }
            }

            );
        }

        if ($scope.form.NuanceServerModify.RequestUrl.$error.validationError == false) {
            $scope.NaunceServerUpdate = {};

            $scope.NaunceServerUpdate.UpdatedBy = userObj.SSOID;

            $scope.NaunceServerUpdate.FileFormat = $scope.NaunceServerEdit.FileFormat;
            $scope.NaunceServerUpdate.RequestUrl = $scope.NaunceServerEdit.RequestUrl;
            $scope.NaunceServerUpdate.Id = $scope.NaunceServerEdit.Id;


            masterDataFactory.UpdateNuanceConfig($scope.NaunceServerUpdate).then(function (data) {



                if (data.data == "Success") {
                    $scope.GetNuanceServerData();

                    $('#modifyNuanceServer').modal('hide');
                    toaster.pop({ type: "Success", body: "Modified successfully" });

                }
                else {
                    $scope.GetNuanceServerData();
                    toaster.pop({ type: "error", body: "Error while Modifying Nuance server data" });

                }
            });
        }

    }
    //Delete functionality
    $scope.showDelete = function (getRowData) {
        //$scope.ussdCodeDelete = {};

        $scope.CodeID = getRowData.Id;
        $scope.EditView = true;
        
        $('#confirmModal').modal('show');
    }

    $scope.Delete = function () {
        $scope.NuanceServerDelete = {};
        // var Id = $scope.CodeID;
        $scope.NuanceServerDelete.Id = $scope.CodeID;
        $scope.NuanceServerDelete.UpdatedBy = userObj.SSOID;

        masterDataFactory.DeleteNuanceConfig($scope.NuanceServerDelete).then(function (data) {
            // 
            // 

            if (data.data == "Success") {
                $scope.GetNuanceServerData();

                $('#confirmModal').modal('hide');
                toaster.pop({ type: "Success", body: "Naunce server removed successfully" });

            }
            else {
                $scope.GetNuanceServerData();

            }
        });

    }



});