app.controller('LayoutController', ['$scope', '$rootScope', '$timeout', '$location', '$http', 'appFactory', '$compile', function ($scope, $rootScope, $timeout, $location, $http, appFactory, $compile) {

    $scope.AppName = '/ucgAdmin_uat';
    $scope.SSOToken = '';
    $scope.rights = {
        type: ''
    };
    $scope.SSOID = '';
    $scope.UserDepartment = '';
    $scope.Roles = [];
    $scope.IsSuperAdmin = false;
    $scope.NavMenus = [];
    $scope.DepartmentRoleId = '';
    $scope.ApiUrl = config.hostPath;

    $scope.LogoutUrl = "http://ssotest.rajasthan.gov.in";
    $scope.BackToSSO = "http://ssotest.rajasthan.gov.in/SSO";

    $scope.Urls = {
        LoggingUrl: $scope.ApiUrl + 'UserManagement/LogUCGActions',
        SSOIDUrl: $scope.ApiUrl + 'SSO/GetSSOID',
        GetUserDetail: $scope.ApiUrl + 'SSO/GetSSOUserDetails',
        GetAllMenus: $scope.ApiUrl + 'UserManagement/GetAllMenus',
        GetMenuByProfile: $scope.ApiUrl + 'UserManagement/GetMenusByProfile',
        GetDepartmentById: $scope.ApiUrl + 'UserManagement/GetDepartmentById'
    }

    $scope.checkCookie = function () {

        var SSOKey = "SSOkey";
        var value;
        if (document.cookie == false) {
            //alert("No Cookie.");
            window.location.href = $scope.LogoutUrl;

        } else if (document.cookie.indexOf("SSOkey") >= 0) {
            //alert("You have Cookie.");
            //alert(document.cookie.indexOf("SSOkey").value);
            var allcookies = document.cookie;
            //alert("All Cookies : " + allcookies );

            // Get all the cookies pairs in an array
            cookiearray = allcookies.split(';');

            // Now take key value pair out of this array
            for (var i = 0; i < cookiearray.length; i++) {
                name = cookiearray[i].split('=')[0];

                if (name.trim() == SSOKey) {
                    value = cookiearray[i].substr(cookiearray[i].indexOf("=") + 1, cookiearray[i].length);
                    //value = cookiearray[i].split('=')[1];
                    // alert("Key is : " + name + " and Value is : " + value);
                    value = decodeURIComponent(value);
                    console.log(value);
                }
            }

            var sessionSSOToken = sessionStorage.getItem('SSOToken');
            var sessionSSOId = sessionStorage.getItem('SSOId');
            var sessionUsrDtls = sessionStorage.getItem('SSOUserDetails');

            if (value != '' && value != null) { //To check value from api is null or empty
                if ((sessionSSOToken == null || sessionSSOToken == '') &&
                    (sessionSSOId == null || sessionSSOId == '') &&
                    (sessionUsrDtls == null || sessionUsrDtls == '')) {
                    // angular.element(document.getElementById('LayoutPage')).scope().SetSSOTokenValue(value);
                    $scope.SetSSOTokenValue(value);
                }
            } else {
                console.log('Invalid Cookie');
                window.location.href = $scope.LogoutUrl;
            }
        } else {
            window.location.href = $scope.LogoutUrl;
        }

    }

    $scope.RefreshMenu = function () {
        $scope.selectedRoleName = "User Management ";
        sessionStorage.setItem('SSOMenu', JSON.stringify($scope.NavMenus));
        setRoleSpecficRights();
        var strNav = "<ul class=\'list-unstyled\'>";
        var menuArray = $scope.NavMenus;
        menuArray.forEach(function (elm) {
            var rightVal = elm.Rights[0].RightName;
            if (elm.Rights[0].RightName == null) {
                strNav += "<li ng-class=\"{\'active\' :\'" + elm.RoleName.trim() + "\'==selectedRoleName } \"> <a ng-click=changeRolename($event)  href=\'" + $scope.AppName + elm.RoleUrl + "\'><i class=\'" + elm.RoleIcon + " menu-list-icon\'></i>" + elm.RoleName + "</a></li>"
            } else {
                strNav += "<li ng-class=\"{\'active\' :\'" + elm.RoleName.trim() + "\'==selectedRoleName }\"><a  ng-click=changeRolename($event)  data-target=\'#navId" + elm.RoleOrder + "\'  aria-expanded=\'false\' data-toggle=\'collapse\'> <i class=\'" + elm.RoleIcon + " menu-list-icon\'></i>" + elm.RoleName + " </a>";
                strNav += "<ul id='navId" + elm.RoleOrder + "\' class='collapse list-unstyled'>";
                elm.Rights.forEach(function (relm) {
                    strNav += "<li ng-class=\"{\'active\' :\'" + relm.RightName.trim() + "\'==selectedRoleName }\"><a  ng-click=changeRolename($event) href=\'" + $scope.AppName + relm.RightUrl + "\'><i class=\'fa fa-angle-double-right\'></i>" + relm.RightName + "</a></li>";
                })
                strNav += "</ul></li>";
            }
        });

        strNav += "</ul>";
        var myEl = angular.element(document.querySelector('#sideNav'));
        var compiledata = $compile(strNav)($scope);
        $timeout(function () {
            $scope.$apply();
            myEl.append(compiledata);
        }, 20)

    };

    $scope.changeRolename = function (event) {
        $scope.selectedRoleName = event.currentTarget.innerText.trim();
    }



    $scope.LoadMenu = function () {
        //;
        var data, IsSuperAdmin, CurrentRole = '';
        if (sessionStorage.getItem('SSOId')) {
            data = JSON.parse(sessionStorage.getItem('SSOId'));
            if (data) {
                if (data.Roles) {
                    for (i = data.Roles.length - 1; i >= 0; i--) {
                        if (data.Roles[i] == 'SUPERADMIN') {
                            IsSuperAdmin = true;
                            $scope.IsSuperAdmin = true;
                        }
                        if (data.Roles[i] != 'USER' && data.Roles[i] != 'SUPERADMIN' && data.Roles[i] != 'ADMIN' && data.Roles[i] != 'RUMAP') {
                            // CurrentRole = data.Roles[i];
                            CurrentRole += data.Roles[i] + ',';
                        }
                    }
                }
            }
        }


        if (IsSuperAdmin) {
            // ;
            var url = $scope.Urls.GetAllMenus;
            $http.get(url).then(
                function success(data) {
                    // ;
                    $scope.NavMenus = data.data;
                    $scope.RefreshMenu();
                },
                function error(data) {
                    //;

                }
            )
        } else if (CurrentRole) {
            //;
            var url = $scope.Urls.GetMenuByProfile + '?profileName=' + CurrentRole + '&ssoId=' + $scope.SSOID;
            $http.get(url).then(
                function success(data) {
                    //;
                    $scope.NavMenus = data.data;
                    $scope.RefreshMenu();
                },
                function error(data) {
                    //;

                }
            )
        }
    };

    $scope.SetSSOIdFromSession = function () {
        //;
        $scope.Roles = [];
        if ($scope.SSOID == null || $scope.SSOID == '') {
            var data;
            if (sessionStorage.getItem('SSOId')) {
                data = JSON.parse(sessionStorage.getItem('SSOId'));
            }
            if (data) {
                $scope.SSOID = data.sAMAccountName;
                if (data.Roles) {
                    for (i = data.Roles.length - 1; i >= 0; i--) {
                        if (data.Roles[i] != 'USER' && data.Roles[i] != 'SUPERADMIN' && data.Roles[i] != 'ADMIN' && data.Roles[i] != 'RUMAP') {
                            $scope.Roles.push({
                                'name': data.Roles[i]
                            });
                        }
                    }
                }
            }
        }
        $scope.LoadMenu();
    }

    $scope.setRoleFromSession = function () {
        //;
        $scope.Roles = [];
        var data;
        if (sessionStorage.getItem('SSOId')) {
            data = JSON.parse(sessionStorage.getItem('SSOId'));
        }
        if (data) {
            if (data.Roles) {
                for (i = data.Roles.length - 1; i >= 0; i--) {
                    if (data.Roles[i] != 'USER' && data.Roles[i] != 'SUPERADMIN' && data.Roles[i] != 'ADMIN' && data.Roles[i] != 'RUMAP') {
                        $scope.Roles.push({
                            'name': data.Roles[i]
                        });
                    }
                }
            }
        }
    }

    $scope.SetSSOTokenFromSession = function () {
        //;
        if ($scope.SSOToken == null || $scope.SSOToken == '') {
            if (sessionStorage.getItem('SSOToken')) {
                $scope.SSOToken = sessionStorage.getItem('SSOToken');
            }
        }
    }

    $scope.SetDepartmentFromSession = function () {

        var isSuperAdmin = false, departmentId;

        if ($scope.UserDepartment == null || $scope.UserDepartment == '') {

            var sessionSSOId = sessionStorage.getItem('SSOId');
            sessionSSOId = JSON.parse(sessionSSOId);

            if (sessionSSOId.Roles && sessionSSOId.Roles.length) {

                if (sessionSSOId.Roles.indexOf(appConst.RIGHTS_TYPES.SUPER_ADMIN) > -1) {
                    isSuperAdmin = true;
                    departmentId = 5800002;
                }

                if (!isSuperAdmin) {
                    for (i = 0; i < sessionSSOId.Roles.length; i++) {
                        if (/^\d+$/.test(sessionSSOId.Roles[i])) {
                            if (sessionSSOId.Roles[i].length == 7) {
                                departmentId = sessionSSOId.Roles[i];
                            }
                        }
                    }
                }
            }

            var url = $scope.Urls.GetDepartmentById + '?id=' + departmentId;
            $http.get(url).then(
                function success(response) {
                    $scope.UserDepartment = response.data[0].DepartmentName;
                },
                function error(response) {

                }
            );

            // var data;
            // if (sessionStorage.getItem('SSOUserDetails')) {
            //     data = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
            // }
            // if (data) {
            //     $scope.UserDepartment = data.department;
            // }

        }
    }

    $scope.SetSSOTokenValue = function (token) {
        
        console.log(token);
        $scope.SSOToken = token;
        sessionStorage.setItem('SSOToken', token);
        $scope.GetSSOID(sessionStorage.getItem('SSOToken'));
        $scope.SetSSOTokenFromSession();
    }


    $scope.LogUCGActions = function (ssoid) {
        //;
        var url = $scope.Urls.LoggingUrl;
        var data = {
            'SSOID': ssoid,
            'UserAction': 'LOGIN'
        };
        $http.post(url, data).then(
            function success(data) {
                //;

            },
            function error(data) {
                //;

            }
        )
    }


    $scope.GetSSOID = function (token) {
        //;
        var url = $scope.Urls.SSOIDUrl + '?token=' + token;
        //alert(url);
        $http.get(url).then(
            function success(data) {
                
                console.log(JSON.parse(data.data));
                //data.data = "{"sAMAccountName":"ESANCHAR2.TEST","Roles":["PROFILE5","PROFILE4","PROFILE3","PROFILE2","PROFILE1","CONFIGURATION","OUTBOUND","INBOUND","SUPERADMIN","ADMIN","RUMAP"]}"
                var parsedData = JSON.parse(data.data);
                var isSuperUserCheck = false;

                for (i = 0; i < parsedData.Roles.length; i++) {
                    if(parsedData.Roles[i] == 'SUPERADMIN' || parsedData.Roles[i] == 'SUPER'){
                        isSuperUserCheck = true;
                    }
                    if (/^\d+$/.test(parsedData.Roles[i])) {
                        if (parsedData.Roles[i].length == 7) {
                            $scope.DepartmentRoleId = parsedData.Roles[i];
                        }
                    }
                }
                if (!$scope.DepartmentRoleId) {
                    alert('Hi ' + parsedData.sAMAccountName + ' - You Dont have Permission to access this application');
                    window.location.href = $scope.BackToSSO;
                }
                
                // if(isSuperUserCheck){
                //     parsedData.Roles.push('SUPERADMIN');
                // }

                sessionStorage.setItem('SSOId', data.data);

                $scope.SSOID = parsedData.sAMAccountName;
                $scope.SetSSOIdFromSession();
                $scope.setRoleFromSession();
                $scope.LogUCGActions(parsedData.sAMAccountName);
                $scope.GetUserDetails(parsedData.sAMAccountName);
            },
            function error(data) {
                //;

            }
        )
    }

    $scope.GetUserDetails = function (ssoid) {

        var url = $scope.Urls.GetUserDetail + '?ssoid=' + ssoid;
        $http.get(url).then(
            function success(data) {
                var userObj = JSON.parse(data.data);
                userObj.departmentId = $scope.DepartmentRoleId;
                //data.data = {"SSOID":"ESANCHAR2.TEST","aadhaarId":"560809512543","bhamashahId":null,"bhamashahMemberId":null,"displayName":"ESANCHAR2 TEST","dateOfBirth":"29/05/1984","gender":"MALE","mobile":"9840966707","telephoneNumber":null,"mailPersonal":"karthi.vasudev@gmail.com","postalAddress":"305, Tower 17, Skycity, Apartment, Vanagaram Main Road, ,, Adayalampattu","postalCode":"600095","l":"TIRUVALLUR","st":"TAMIL NADU","jpegPhoto":null,"designation":"ESANCHAR2 ADMIN","department":"INFORMATION TECHNOLOGY COMMUNICATION (DOIT)","mailOfficial":"","employeeNumber":null,"departmentId":"103"};
                // sessionStorage.setItem('SSOUserDetails', data.data);
                sessionStorage.setItem('SSOUserDetails', JSON.stringify(userObj));
                $scope.SetDepartmentFromSession();
            },
            function error(data) {
                //;

            }
        )
    }
    //$scope.GetUserDetails($scope.SSOToken);


    $scope.LoadMenuByProfile = function (profilename) {
        //;
        var url = $scope.Urls.GetMenuByProfile + '?profileName=' + profilename + '&ssoId=' + $scope.SSOID;
        $http.get(url).then(
            function success(data) {
                //;
                $scope.NavMenus = data.data;
                $scope.RefreshMenu();
            },
            function error(data) {
                //;

            }
        )
    };

    var setRoleSpecficRights = function () {
        appFactory.setRoleSpecficRights();
    };
    $scope.layoutdata = {
        TicketMessage: 'w.e.f. 01 March, 2017, it would be mandatory for all govt. employees to have either AADHAAR or BHAMASHAH ID updated in SSO profile.'
    };
    $scope.GetTickermessage = function () {
        url = config.hostPath + 'MasterData/GetActiveTickerMessage';
        $http.get(url).then(
            function success(data) {
                $scope.Tickerdata = data.data;
                var strmsg = '';
                angular.forEach($scope.Tickerdata, function (rowdata) {
                    strmsg = strmsg + " " + rowdata.TickerMessage;
                });
                $timeout(function () {
                    $scope.$apply(function () {
                        $scope.layoutdata.TicketMessage = strmsg;
                    });
                }, 100);
            },
            function error(data) { }
        )

    }
    $scope.GetTickermessage();


    //$scope.TicketMessage = 'w.e.f. 01 March, 2017, it would be mandatory for all govt. employees to have either AADHAAR or BHAMASHAH ID updated in SSO profile.';


    $scope.toggleNav = function () {
        $(".content-inner").toggleClass("toggle-small");

        $(this).toggleClass('active');

        $('.side-navbar').toggleClass('shrinked');
        $('.content-inner').toggleClass('active');
        if ($(window).outerWidth() > 1183) {
            if ($('#toggle-btn').hasClass('active')) {
                $('.navbar-header .brand-small').hide();
                $('.navbar-header .brand-big').show();
            } else {
                $('.navbar-header .brand-small').show();
                $('.navbar-header .brand-big').hide();
            }
        }

        if ($(window).outerWidth() < 1183) {
            $('.navbar-header .brand-small').show();
        }
    }

    $scope.changeTheme = function (colorCode) {
        // $('nav.navbar').addClass(colorCode);
        // $('.dashboard-counts form .card-header').addClass(colorCode);
        // $('.mdcard-header').addClass(colorCode);
        // $('nav.custom-bottom-nav').addClass(colorCode);
        var styleList = 'color1 color2 color3 color4 color5 color6 color7 color8 color9 color10';
        // var btnStyleList = 'btn-color1 btn-color2 btn-color3 btn-color4 btn-color5 btn-color6 btn-color7 btn-color8 btn-color9 btn-color10'
        $('nav.side-navbar ul a').hover(function () {
            $(this).removeClass(styleList);
            $(this).toggleClass(colorCode);
        })

        $('nav.side-navbar ul a').mouseleave(function () {
            $(this).removeClass(styleList);
        })

        $('#userOptions .dropdown-menu a').hover(function () {
            $(this).removeClass(styleList);
            $(this).toggleClass(colorCode);
        })
        $('.btn-primary').hover(function () {
            $(this).removeClass(styleList);
            $(this).toggleClass(colorCode);
        })
        $('.btn-success').hover(function () {
            $(this).removeClass(styleList);
            $(this).toggleClass(colorCode);
        })

        $('#userOptions .dropdown-menu a').mouseleave(function () {
            $(this).removeClass(styleList);
        })

        $('nav.navbar').removeClass(styleList);
        $('.dashboard-counts form .card-header').removeClass(styleList);
        $('.mdcard-header').removeClass(styleList);
        $('nav.custom-bottom-nav').removeClass(styleList);
        // $('.btn-primary').removeClass(btnStyleList);
        // $('.btn-success').removeClass(btnStyleList);

        // $('nav.side-navbar ul li.active').removeClass(styleList);

        $('nav.navbar').toggleClass(colorCode);
        $('.dashboard-counts form .card-header').toggleClass(colorCode);
        $('.mdcard-header').toggleClass(colorCode);
        $('nav.custom-bottom-nav').toggleClass(colorCode);

        // if(colorCode = 'color1'){
        //     $('.btn-primary').toggleClass(btn-color1);
        //     $('.btn-success').toggleClass(btn-color1);
        // }

        // // $('nav.side-navbar ul li.active').toggleClass(colorCode);
    }

    var init = function () {
        // $scope.checkCookie();
        // $scope.SetSSOIdFromSession();
        // $scope.SetSSOTokenFromSession();
        // $scope.SetDepartmentFromSession();
        setRoleSpecficRights();
    };

    init();

}]);