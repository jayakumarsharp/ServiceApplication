app.controller('MasterFinesseFAQ', MasterFinesseFAQController);

MasterFinesseFAQController.$inject = ['masterDataFactory', 'toaster', '$rootScope'];

function MasterFinesseFAQController(masterDataFactory, toaster, $rootScope) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    //    if(!userObj.departmentId){
    // $rootScope.departmentName = "103";
    // userObj.SSOID="admin";
    //    }else{
    //  //   $rootScope.departmentName = userObj.departmentId;
    //    }

    // $rootScope.departmentName = "103";
    $rootScope.departmentName = userObj.departmentId;




    var vm = this;
    vm.form = {};
    vm.Formlist = {};
    vm.FormEdit = {};

    vm.gridFinesseFAQ = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                enableFiltering: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'DepartmentName',
                field: 'DepartmentName',
				cellTooltip: true
            },
            {
                name: 'Question',
                field: 'Question',
				cellTooltip: true
            },
            {
                name: 'Answer',
                field: 'Answer',
				cellTooltip: true
            },
            {
                name: 'Options', enableSorting: false,
                enableFiltering: false,
                width: '10%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
            }

            //  { name: 'Options', enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }

        ],
    };


    vm.showAdd = function () {

        vm.Formlist = {};
        // vm.flagA = false;
        vm.form.FinesseFAQ.Question.$error.validationError = false;
        vm.form.FinesseFAQ.$setPristine();

        $('#AddFinesseFAQ').modal('show');

    }


    vm.GetFinesseFAQs = function () {


        masterDataFactory.GetFinesseFAQs().then(
            function success(response) {
                vm.gridFinesseFAQ.data = response.data;
            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while getting department dropdown"
                });

            }
        )
    }
    vm.GetFinesseFAQs();

    vm.GetDepartmentName = function () {

        masterDataFactory.GetDepartmentName().then(
            function success(data) {

                // console.log("editSMS",data);
                vm.DepartmentDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }
    vm.GetDepartmentName();



    vm.CreateFinesseFAQs = function () {

        vm.form.FinesseFAQ.Question.$error.validationError = false;
        angular.forEach(vm.gridFinesseFAQ.data, function (rowdata) {
            if (rowdata.Question == vm.Formlist.Question) {
                vm.form.FinesseFAQ.Question.$error.validationError = true;
            }

        });

        if (vm.form.FinesseFAQ.Question.$error.validationError == false) {

            var AddFinesseFAQ = {};
            AddFinesseFAQ.Question = vm.Formlist.Question;
            AddFinesseFAQ.Answer = vm.Formlist.Answer;
            AddFinesseFAQ.DepartmentID = vm.Formlist.DepartmentID;
            //AddFinesseFAQ.CreatedBy = userObj.SSOID;
            AddFinesseFAQ.CreatedBy = "admin";

            masterDataFactory.CreateFinesseFAQs(AddFinesseFAQ).then(
                function success(data) {
                    vm.GetFinesseFAQs();
                    $('#AddFinesseFAQ').modal('hide');
                    toaster.pop({
                        type: "success",
                        body: "Added Successfully"
                    });

                },
                function error(data) {
                    toaster.pop({
                        type: "error",
                        body: "Error while Adding Agent"
                    });

                }
            );
        }
    }

    vm.showDelete = function (getRowData) {

        vm.Formlist.ID = getRowData.ID;

        $('#confirmModalFinesseFAQ').modal('show');
    }

    vm.Delete = function () {
        var DelFinesseFAQ = {};
        DelFinesseFAQ.ID = vm.Formlist.ID;
        DelFinesseFAQ.ModifiedBy = userObj.SSOID;
        masterDataFactory.DeleteFinesseFAQs(DelFinesseFAQ).then(
            function success(data) {
                vm.GetFinesseFAQs();
                $('#confirmModalFinesseFAQ').modal('hide');
                toaster.pop({
                    type: "success",
                    body: "Deleted Successfully"
                });

            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while Deleting agent"
                });

            }
        );


    }

    vm.showEdit = function (getRowData) {



        vm.FormEdit.ID = getRowData.ID;
        vm.FormEdit.Question = getRowData.Question;
        vm.FormEdit.DepartmentID = getRowData.DepartmentID;
        vm.validQuestion = getRowData.Question;
        vm.FormEdit.Answer = getRowData.Answer;
        vm.form.FinesseFAQEdit.Question.$error.validationError = false;
        //vm.EditView = true;
        $('#UpdateFinesseFAQ').modal('show');
    }

    vm.UpdateFinesseFAQs = function () {

        if (vm.validQuestion != vm.FormEdit.Question) {
            vm.form.FinesseFAQEdit.Question.$error.validationError = false;
            angular.forEach(vm.gridFinesseFAQ.data, function (rowdata) {
                if (rowdata.Question == vm.FormEdit.Question) {
                    vm.form.FinesseFAQEdit.Question.$error.validationError = true;
                }
            });
        }

        if (vm.form.FinesseFAQEdit.Question.$error.validationError == false) {



            var UpdateFinesseFAQ = {};

            //  UpdateFinesseFAQ.ModifiedBy = userObj.SSOID;
            UpdateFinesseFAQ.ModifiedBy = "admin";

            UpdateFinesseFAQ.ID = vm.FormEdit.ID;
            UpdateFinesseFAQ.Question = vm.FormEdit.Question;
            UpdateFinesseFAQ.DepartmentID = vm.FormEdit.DepartmentID;


            UpdateFinesseFAQ.Answer = vm.FormEdit.Answer;


            masterDataFactory.UpdateFinesseFAQs(UpdateFinesseFAQ).then(function (data) {

                if (data.data == "Success") {
                    vm.GetFinesseFAQs();
                    $('#UpdateFinesseFAQ').modal('hide');
                    toaster.pop({
                        type: "Success",
                        body: "updated successfully"
                    });

                } else {
                    vm.GetDepartmentEmailConfig();
                    toaster.pop({
                        type: "error",
                        body: "Error while updating"
                    });

                }
            });

        }

    }


}