    app.controller('MasterTickerMessage', MasterTickerMessageController);

    MasterTickerMessageController.$inject = ['masterDataFactory', 'toaster', '$rootScope', 'appFactory'];

    function MasterTickerMessageController(masterDataFactory, toaster, $rootScope, appFactory) {
        var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
        $rootScope.departmentName = userObj.departmentId;
    //     $rootScope.departmentName = "103";
    //     var userObj = {
    //     SSOID: ''
    // }
        var vm = this;
        // vm.validateError = false;
        // vm.DeleteFlag = false;
        // vm.ButtonLabel = "Create";
        // vm.flagA = false;
        vm.form = {};
        // vm.form.DepModify={};
        // vm.form.DepModify.DepNumber.$error.validationError = false;
        vm.FormEdit = {};
        vm.gridTickerMessage = {
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1,
            columnDefs: [{
                    name: 'S.No',
                    enableSorting: false,
                    width: '10%',
                    enableFiltering: false,
                    cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
                },
                {
                    name: 'Message',
                    field: 'TickerMessage',
                    cellTooltip: true
                },
                {
                    name: 'CreatedDate',
                    field: 'StartDate',
					cellTooltip: true,
                    cellFilter: 'date:\'dd-MM-yy HH:mm\''
                },
                {
                    name: 'ExpiryDate',
                    field: 'ExpiryDate',
					cellTooltip: true,
                    cellFilter: 'date:\'dd-MM-yy HH:mm\''
                },

                {
                    name: 'Options', enableSorting: false,
                    enableFiltering: false,
                    width: '10%',
                    cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
                }

                //  { name: 'Options', enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }

            ],
        };
        vm.ms = {
            startDate: new Date(),
            endDate: '',
            endDateUpdate: '',
            startDateUpdate: '',
        }

        vm.open = {
            startDate: false,
            endDate: false,
            endDateUpdate: false,
            startDateUpdate: false,

        }
        vm.openCalendar = function (e, date) {
            e.preventDefault();
            e.stopPropagation();

            vm.open[date] = true;
        };




        vm.GetTickerMessage = function () {

            masterDataFactory.GetTickerMessage().then(
                function success(data) {
                    vm.gridTickerMessage.data = data.data;
                },
                function error(data) {
                    toaster.pop({
                        type: "error",
                        body: "Error while retreiving ticker message"
                    });

                }
            );
        }
        vm.GetTickerMessage();
        vm.showAdd = function () {

            vm.TickerMessage = '';
            vm.ms.endDate = '';
            vm.ms.startDate = new Date();
            // vm.flagA = false;
            vm.form.TickerMaster.$setPristine();

            $('#AddTickermessage').modal('show');

        }


        vm.CreateTickermessage = function () {
            var validation = '';
            validation = appFactory.validateDates(vm.ms.startDate, vm.ms.endDate);
            if (validation) {
                toaster.pop({
                    type: "error",
                    body: validation
                });
            }
            else {
                var addTickermessage = {};
                addTickermessage.Tickermessage = vm.TickerMessage;
                addTickermessage.StartDate = moment(moment(vm.ms.startDate).format('MM-DD-YYYY HH:MM'));
                addTickermessage.ExpiryDate = moment(moment(vm.ms.endDate).format('MM-DD-YYYY HH:MM'));
                addTickermessage.CreatedBy = userObj.SSOID;

                masterDataFactory.CreateTickerMessage(addTickermessage).then(
                    function success(data) {
                        vm.GetTickerMessage();
                        $('#AddTickermessage').modal('hide');
                        toaster.pop({
                            type: "success",
                            body: "Added Successfully"
                        });

                    },
                    function error(data) {
                        toaster.pop({
                            type: "error",
                            body: "Error while Adding Agent"
                        });

                    }
                );

            }


        }
        vm.showDelete = function (getRowData) {

            vm.ID = getRowData.ID;

            $('#confirmModalTicker').modal('show');
        }

        vm.Delete = function () {
            var delTicker = {};
            delTicker.ID = vm.ID;
            delTicker.UpdatedBy = userObj.SSOID;
            masterDataFactory.DeleteTickerMessage(delTicker).then(
                function success(data) {
                    vm.GetTickerMessage();
                    $('#confirmModalTicker').modal('hide');
                    toaster.pop({
                        type: "success",
                        body: "Deleted Successfully"
                    });

                },
                function error(data) {
                    toaster.pop({
                        type: "error",
                        body: "Error while Deleting TickerMessage"
                    });

                }
            );


        }

        vm.showEdit = function (getRowData) {
            var dateStart;
            var dateEnd;
            vm.FormEdit.ID = getRowData.ID;
            vm.FormEdit.TickerMessage = getRowData.TickerMessage;
            dateStart = getRowData.StartDate;
            dateEnd = getRowData.ExpiryDate;
            
            vm.ms.startDateUpdate = new Date(dateStart);
            vm.FormEdit.Startdate=vm.ms.startDateUpdate;
            vm.ms.endDateUpdate = new Date(dateEnd);
            $('#updateTickermessage').modal('show');
        }

        vm.UpdateTickerMessage = function () {

            var validation = '';
            if(vm.ms.startDateUpdate== vm.FormEdit.Startdate){
                var dateToValidate=vm.ms.startDate;
            }else{
                dateToValidate=vm.ms.startDateUpdate;
            }
            validation = appFactory.validateDates(dateToValidate, vm.ms.endDateUpdate);
            if (validation) {
                toaster.pop({
                    type: "error",
                    body: validation
                });
            }     


            else {
                var UpdateTickerMessage = {};

                UpdateTickerMessage.UpdatedBy = userObj.SSOID;

                UpdateTickerMessage.ID = vm.FormEdit.ID;
                UpdateTickerMessage.StartDate = moment(moment(vm.ms.startDateUpdate).format('MM-DD-YYYY HH:MM'));
                UpdateTickerMessage.ExpiryDate = moment(moment(vm.ms.endDateUpdate).format('MM-DD-YYYY HH:MM'));;
                UpdateTickerMessage.Tickermessage = vm.FormEdit.TickerMessage;



                masterDataFactory.UpdateTickerMessage(UpdateTickerMessage).then(function (data) {

                    if (data.data == "Success") {
                        vm.GetTickerMessage();
                        $('#updateTickermessage').modal('hide');
                        toaster.pop({
                            type: "Success",
                            body: "updated successfully"
                        });

                    } else {
                        vm.GetTickerMessage();
                        toaster.pop({
                            type: "error",
                            body: "Error while updating"
                        });

                    }
                });
            }

        }
    }