app.controller('IVRController', ['$scope', '$rootScope', '$http',function($scope, $rootScope, $http) {

}])