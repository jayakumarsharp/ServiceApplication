app.controller('callAssignedController', ['$scope', '$sce', '$rootScope', '$q', '$timeout', 'appFactory', 'toaster', 'missCall', 'uiGridConstants', 'uiGridExporterConstants', function ($scope, $sce, $rootScope, $q, $timeout, appFactory, toaster, missCall, uiGridConstants, uiGridExporterConstants) {

    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
   
    $scope.status = ["Assigned", "In Progress", "Closed"];
    //$scope.users = ["User 1 ", "User 2", "User 3", "User 4", "User 5", "User 6"];
    $scope.updateAssignedRecord = {};
    $scope.showDatePopup = [];
    $scope.showDatePopup.push({
        opened: false
    });
    $scope.showDatePopup.push({
        opened: false
    });
    $rootScope.selectedGridData = [];
    $scope.assignedUsers = [];
    $scope.finesseUsers = [];
    $scope.misscalldata = [];
    $scope.permissions = appFactory.permissions[appConst.MENUS.MSD_CALL.MY_ASN_CALL];
    $scope.isValid = false;
    $scope.IsexportDisable = true;
    $rootScope.IsselectedGrid = false;
    $scope.IsselectedUsers = false;
    $scope.isgridShow = false;
    $scope.isDisableUserBtn = true;
    $scope.tab = 1;

    $scope.multiselect = {
        selected: [],
        options: [],
        config: {
            hideOnBlur: false,
            showSelected: false,
            itemTemplate: function (item) {
                return $sce.trustAsHtml(item.name);
            },
            labelTemplate: function (item) {
                return $sce.trustAsHtml(item.name);
            }
        }
    };

    $('.modal-dialog .card').resizable().draggable();
    $scope.displayUsers = function () {
        return $scope.multiselect.selected.map(function (each) {
            return each.name;
        }).join(', ');
    };

    $scope.checkStatus = function (statusTerm) {
        if (statusTerm == 'Unassigned') {
            $scope.isDisableUserBtn = false;
        } else {
            $scope.isDisableUserBtn = true;
        }

    };

    $scope.ms = {
        startDate: new Date(),
        endDate: new Date()
    }
    $scope.ms.startDate.setDate($scope.ms.startDate.getDate() - 7);

    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        $scope.open = {};
        e.preventDefault();
        e.stopPropagation();

        $scope.open[date] = true;
    };



    $scope.myAssignedCallgrid = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableColumnResizing: true,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;

        },
        columnDefs: [

            { name: 'mobileNo', field: 'ContactNo', cellTooltip: true, enableFiltering: false },
            { name: 'date & time', field: 'CreatedDate', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
            { name: 'status', width: '25%',cellTooltip: true, field: 'Status' },
            {
                name: 'Update Comments', width: '25%',
                cellTemplate: '<div class="click-to-update"><div ><span ng-if="grid.appScope.permissions.Modify" class="fa fa-pencil-square-o" ng-click="grid.appScope.showCommentsPopup(row.entity)"> </span><span ng-if="!grid.appScope.permissions.Modify" class="fa fa-pencil-square-o" style="color:#666; cursor: not-allowed;" > </span></div></div>'
            }
        ]
    };



    $scope.myAssignedCallCommentsGrid = {
        paginationPageSizes: [5, 10, 20],
        paginationPageSize: 5,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableColumnResizing: true,
        columnDefs: [
            { name: 'Comment By', field: 'AgentName', enableFiltering: false, cellTooltip: true },
            { name: 'Agent Comment', field: 'AgentComment', enableFiltering: false, cellTooltip: true },
            { name: 'Date & Time', field: 'AgentUpdatedDate', cellFilter: 'date:\'dd-MM-yy HH:mm\'', cellTooltip: true },
            { name: 'Status', width: '25%', field: 'Status', cellTooltip: true }
        ]
    };


    $scope.onViewPermission = function (tab) {
        appFactory.ShowLoader();
        $scope.searchIndex = '';
        $scope.tab = tab;
        $timeout(function () {
            appFactory.HideLoader();
        }, 500)
    };


    $scope.loadGridData = function () {
        $scope.myAssignedCallgrid.columnDefs = $scope.myAssignedCallgrid.columnDefs;
    }


    $rootScope.contactRecords = function (status) {

        $scope.misscalldata = null;
        $scope.IsexportDisable = true;
        $scope.ms.Status = "Assigned";

        $scope.loadGridData();

        var filterData = {
            "ContactNo": "ALL",
            "AgentName": userObj.SSOID,
            "FromDate": moment($scope.ms.startDate).add(-7, 'days').format('YYYY-MM-DD HH:mm:ss'),
            "ToDate": moment($scope.ms.endDate).format('YYYY-MM-DD HH:mm:ss'),
            // "DepartmentNumber": $scope.ms.term
        };


        appFactory.ShowLoader();
        missCall.GetAllAssignedMC(filterData)
            .then(function (success) {
                $scope.misscalldata = success.data;
                if ($scope.misscalldata != null && $scope.misscalldata.length > 0) {
                    $scope.IsexportDisable = false;
                    $scope.isgridShow = true;
                    $scope.myAssignedCallgrid.data = $scope.misscalldata;
                    appFactory.HideLoader();

                } else {
                    appFactory.HideLoader();
                    $scope.IsexportDisable = true;
                    $scope.isgridShow = false;
                    $scope.misscalldata.length = 0;
                    $scope.myAssignedCallgrid.data = null;
                }


                if (($scope.misscalldata != null && $scope.misscalldata.length > 0) && ($scope.ms.statusTerm == 'Unassigned')) {
                    $scope.isDisableUserBtn = false;
                } else {
                    $scope.isDisableUserBtn = true;
                }

                console.log("data", success.data);
            }, function (error) {
                //alert("contacterror");
            });
    }
    $rootScope.contactRecords("Unassigned");

    $scope.contactRecordsSubmit = function () {

        IsValidInputs();
        if ($scope.isValid == true) {
            var filterData = {
                "ContactNo": $scope.ms.mobileNum,
                "AgentName": userObj.SSOID,
                "FromDate": moment($scope.ms.startDate).format('YYYY-MM-DD HH:mm:ss'),
                "ToDate": moment($scope.ms.endDate).format('YYYY-MM-DD HH:mm:ss'),
                // "DepartmentNumber": $scope.ms.term
            };
            if ($scope.ms.mobileNum == "" || $scope.ms.mobileNum == undefined) {
                filterData.ContactNo = 'ALL';
            }
            appFactory.ShowLoader();
            missCall.GetAllAssignedMC(filterData)
                .then(function (success) {
                    appFactory.HideLoader();
                    $scope.misscalldata = success.data;

                    if ($scope.misscalldata != null && $scope.misscalldata.length > 0) {
                        $scope.IsexportDisable = false;
                        $scope.isgridShow = true;
                        $scope.myAssignedCallgrid.data = $scope.misscalldata;
                    } else {
                        $scope.IsexportDisable = true;
                        $scope.isgridShow = false;
                        $scope.misscalldata.length = 0;
                        $scope.myAssignedCallgrid.data = null;
                        toaster.pop({
                            type: "error",
                            body: "No record found",
                            toasterId: 1
                        });

                    }

                    if (($scope.misscalldata != null && $scope.misscalldata.length > 0) && ($scope.ms.statusTerm == 'Unassigned')) {
                        $scope.isDisableUserBtn = false;
                    } else {
                        $scope.isDisableUserBtn = true;
                    }

                }, function (error) {
                    appFactory.HideLoader();
                });
        } else {
            $scope.IsexportDisable = true;
            $scope.misscalldata.length = 0;
            $scope.myAssignedCallgrid.data = null;
            $scope.isgridShow = false;
        }

    }

    $scope.showCommentsPopup = function (rowdata) {
        $scope.updateinfo = {}
        $scope.updateinfo.Status = "Assigned";
        $scope.updateAssignedRecord.AgentName = rowdata.AgentName;
        $scope.updateAssignedRecord.updateId = rowdata.ID;
        $scope.updateinfo.mobileNum = rowdata.ContactNo;
        // $('#commentModal').modal('show');

        missCall.GetMissedCallHistory(rowdata.ID).then(
            function (response) {
                // console.log(response.data);
                $scope.myAssignedCallCommentsGrid.data = response.data;
                $('#commentModal').modal('show');
            },
           
        )
    }

    $scope.updateComments = function (getrowdata) {
        console.log("getrowdata", getrowdata);
        if (getrowdata.Status == "Assigned") {
            toaster.pop({
                type: "error",
                body: "Status cannot be in Assigned state during update"
            });
        } else {

            console.log("getrowdata", getrowdata);
            // if ($scope.isValid == true) {
            var updatedData = {
                "AgentName": $scope.updateAssignedRecord.AgentName,
                "updateId": $scope.updateAssignedRecord.updateId,
                "Status": getrowdata.Status,
                "description": getrowdata.AgentComment

            };
            console.log("updatedData", updatedData);
            missCall.UpdateMCstatus(updatedData)
                .then(function (success) {
                    $scope.contactRecordsSubmit();
                    toaster.pop({
                        type: "success",
                        body: "Record Saved Successfully"
                    });
                    $('#commentModal').modal('hide');
                }, function (error) {

                    alert("contacterror");
                });
            // }
        }

    }





    $scope.downloadCSV = function () {
        if ($scope.IsexportDisable == false) {
            if ($scope.myAssignedCallgrid.data != null && $scope.myAssignedCallgrid.data.length > 0) {
                $scope.gridApi.exporter.csvExport(uiGridExporterConstants.VISIBLE, uiGridExporterConstants.ALL);
            }
        }


    };

    $scope.assignUsers = function () {
        $scope.assignedUsers = [];
        var msUsers = $scope.multiselect.selected;
        if (msUsers.length == 0 || msUsers == "") {
            $scope.assignedUsers = null;
            $scope.IsselectedUsers = false;
        }
        for (index = 0; index < msUsers.length; index++) {
            console.log("msUsers", msUsers[index]);
            if (msUsers[index].name != 'ALL') {
                $scope.assignedUsers.push(msUsers[index].name);
                $scope.IsselectedUsers = true;
            }

        }

    }

    $rootScope.finesseAgents = function () {
        missCall.finesseAgents()
            .then(function (success) {

                $scope.finesseUsers = success.data;

                success.data.splice(0, 0, {
                    Id: 0,
                    AgentName: "Agent_1",
                    AgentID: "12345",
                    Department: ""
                });
                console.log("data", success.data);

                $scope.multiselect.options = success.data.map(function (item) {
                    console.log("item", item);
                    return {
                        name: item.AgentName,
                        id: item.Id
                    };
                });

                console.log("$scope.multiselect.options", $scope.multiselect.options);
            }, function (error) {
                //alert("error");
            });
    }
    $rootScope.finesseAgents();

    $scope.AssignMCData = function () {
        if ($rootScope.IsselectedGrid == false) {
            toaster.pop({
                type: "error",
                body: "Please select contacts to assign"
            });
        } else if ($scope.IsselectedUsers == false) {
            toaster.pop({
                type: "error",
                body: "Please select users to assign"
            });
        } else {
            if ($rootScope.selectedGridData != null && $rootScope.selectedGridData.length > 0 &&
                $scope.assignedUsers != null && $scope.assignedUsers.length > 0) {

                if ($scope.selectedGridData.length < $scope.assignedUsers.length) {
                    toaster.pop({
                        type: "success",
                        body: "Selected contacts should not be greater than selected users",
                        toasterId: 1
                    });
                } else {
                    var mcData = {
                        "Status": "Assigned",
                        "assignedContacts": $rootScope.selectedGridData,
                        "assignedAgents": $scope.assignedUsers,

                    };

                    missCall.AssignMissedCalls(mcData)
                        .then(function (success) {
                            if (success.data != 0) {
                                toaster.pop({
                                    type: "error",
                                    body: "Selected contacts successfully assigned to selected users",
                                    toasterId: 1
                                });
                                $scope.multiselect.selected = [];
                                $rootScope.IsselectedGrid = false;
                                $scope.IsselectedUsers = false;

                                $rootScope.contactRecords("Unassigned");
                                $rootScope.finesseAgents();


                            }

                        }, function (error) {
                            console.log("error", error);
                            toaster.pop({
                                type: "error",
                                body: "Error while assigning users",
                                toasterId: 1
                            });
                            $rootScope.IsselectedGrid = false;
                            $scope.IsselectedUsers = false;

                        });


                }

            }

        }

    }


    // Validations

    // $scope.showModal=function()
    // {
    //     $('#assignUserModal').modal('show');
    //     var data=$rootScope.selectedGridData;
    //     var result=$rootScope.IsselectedGrid ;
    // }
    $scope.formatString = function (format) {
        var day = parseInt(format.substring(0, 2));
        var month = parseInt(format.substring(3, 5));
        var year = parseInt(format.substring(6, 10));
        var date = new Date(year, month - 1, day);
        return date;
    }

    $scope.clearUsers = function () {
        $scope.multiselect = {
            selected: [],
            options: [],
            config: {
                hideOnBlur: false,
                showSelected: false,
                itemTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                },
                labelTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                }
            }
        };
        // $rootScope.contactRecords("Unassigned");
        $rootScope.finesseAgents();
    }

    var IsValidInputs = function () {
        $scope.isValid = false;
        var now = new Date();
        var currentDate = new Date(now);
        var startDate = new Date($scope.ms.startDate);
        var endDate = new Date($scope.ms.endDate);

        // var output = (datetwo - dateone) / 1000 / 60 / 60 / 24;
        $scope.currentStDayDiff = Math.round((startDate - currentDate) / 1000 / 60 / 60 / 24);
        $scope.currentEnDayDiff = Math.round((endDate - currentDate) / 1000 / 60 / 60 / 24);
        $scope.stendDayDifference = Math.round((startDate - endDate) / 1000 / 60 / 60 / 24);
        var timediffinseconds = moment(currentDate, "DD/MM/YYYY HH:mm:ss").diff(moment(startDate, "DD/MM/YYYY HH:mm:ss"));

        // var currentDate = moment(now).format('DD/MM/YYYY HH:mm');
        // var startDate = moment($scope.ms.startDate).format('DD/MM/YYYY HH:mm');
        // var endDate = moment($scope.ms.endDate).format('DD/MM/YYYY HH:mm');

        // var curdate = new Date($scope.formatString(currentDate));
        // var stdate = new Date($scope.formatString(startDate));
        // var enddate = new Date($scope.formatString(endDate));


        // var stendtimeDiff = Math.abs(enddate.getTime() - stdate.getTime());
        // $scope.stendDayDifference = Math.ceil(stendtimeDiff / (1000 * 3600 * 24));




        // var curtsttimeDiff = Math.abs(stdate.getTime() - curdate.getTime());
        // $scope.currentStDayDiff = Math.ceil(curtsttimeDiff / (1000 * 3600 * 24));

        // var curtendtimeDiff = Math.abs(enddate.getTime() - curdate.getTime());
        // $scope.currentEnDayDiff = Math.ceil(curtendtimeDiff / (1000 * 3600 * 24));






        // if ($scope.ms.statusTerm == undefined || $scope.ms.statusTerm == null) {
        //     toaster.pop({ type: "error", body: "Select valid status" });
        //     $scope.isValid = false;
        //     return;
        // }

        if ($scope.ms.startDate == null && (!moment(startDate, "DD-MM-YY HH:mm", true).isValid())) {
            toaster.pop({
                type: "error",
                body: "Please enter valid Start date time"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.ms.endDate == null && (!moment(endDate, "DD-MM-YY HH:mm", true).isValid())) {
            toaster.pop({
                type: "error",
                body: "Please enter valid End date time"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.currentStDayDiff > 0) {

            toaster.pop({
                type: "error",
                body: "Start date should not be greater than current date"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.currentEnDayDiff > 0) {

            toaster.pop({
                type: "error",
                body: "End date should not be greater than current date"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.stendDayDifference > 0) {

            toaster.pop({
                type: "error",
                body: "Start date should not be greater than end date"
            });
            $scope.isValid = false;
            return;
        }

        $scope.isValid = true;
    }


}]);