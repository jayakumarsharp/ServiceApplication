app.controller('RightsController', ['$scope', '$rootScope', 'rightsFactory', 'uiGridConstants', function ($scope, $rootScope, rightsFactory, uiGridConstants) {

    $scope.EditView = true;

    // $scope.rightsData = [
    //     { 'RoleID': 'R001', 'RoleName': 'User Management', 'RightsID': 'R01', 'RightsName': 'Manage User', 'IsActive': true },
    //     { 'RoleID': 'R001', 'RoleName': 'User Management', 'RightsID': 'R01', 'RightsName': 'Manage Profile', 'IsActive': true },
    //     { 'RoleID': 'R001', 'RoleName': 'User Management', 'RightsID': 'R01', 'RightsName': 'Role Management', 'IsActive': true },
    //     { 'RoleID': 'R001', 'RoleName': 'User Management', 'RightsID': 'R01', 'RightsName': 'Right Management', 'IsActive': true },
    //     { 'RoleID': 'R002', 'RoleName': 'Campaign Management', 'RightsID': 'R01', 'RightsName': 'Campaign Configuration', 'IsActive': true },
    //     { 'RoleID': 'R002', 'RoleName': 'Campaign Management', 'RightsID': 'R01', 'RightsName': 'Contact Upload', 'IsActive': true },
    //     { 'RoleID': 'R003', 'RoleName': 'Survey Management', 'RightsID': 'R01', 'RightsName': 'Create Survey', 'IsActive': true },
    //     { 'RoleID': 'R004', 'RoleName': 'Case Management', 'RightsID': 'R01', 'RightsName': 'Create Ticket', 'IsActive': true },
    //     { 'RoleID': 'R005', 'RoleName': 'Missed Call Management', 'RightsID': 'R01', 'RightsName': 'Manage MissedCall', 'IsActive': true },
    //     { 'RoleID': 'R006', 'RoleName': 'USSD Management', 'RightsID': 'R01', 'RightsName': 'Create USSD', 'IsActive': true },
    //     { 'RoleID': 'R007', 'RoleName': 'SMS Management', 'RightsID': 'R01', 'RightsName': 'Create SMS', 'IsActive': true },
    //     { 'RoleID': 'R008', 'RoleName': 'IVR Call Management', 'RightsID': 'R01', 'RightsName': 'Manage IVR Flow', 'IsActive': true },
    //     { 'RoleID': 'R009', 'RoleName': 'Finesse Agent Desktop', 'RightsID': 'R01', 'RightsName': 'Finesse', 'IsActive': true },
    //     { 'RoleID': 'R010', 'RoleName': 'Monitoring', 'RightsID': 'R01', 'RightsName': 'Server Monitoring', 'IsActive': true },
    //     { 'RoleID': 'R011', 'RoleName': 'Master Data', 'RightsID': 'R01', 'RightsName': 'Configuration', 'IsActive': true }
    // ];

    $scope.highlightFilteredHeader = function (row, rowRenderIndex, col, colRenderIndex) {
        if (col.filters[0].term) {
            return 'header-filtered';
        } else {
            return '';
        }
    };

    $scope.RightsGrid = {
        enableColumnResizing: true,
        enableFiltering: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                enableFiltering: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            // { name: 'Rights Id', field: 'RightsID' },
            {
                name: 'Role Id',
                field: 'RoleId'
            },
            {
                name: 'Role Name',
                field: 'RoleName'
            },
            {
                name: 'Rights Id',
                field: 'RightId'
            },
            {
                name: 'Rights Name',
                field: 'RightName'
            },
            {
                name: 'IsActive',
                field: 'IsActive',
                filter: {
                    term: 'true',
                    type: uiGridConstants.filter.SELECT,
                    selectOptions: [{
                        value: 'true',
                        label: 'true'
                    }, {
                        value: 'false',
                        label: 'false'
                    }]
                }
            }
            // { name: 'Options', width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.showView(row.entity)"><span class="fa fa-eye"></span></a> | <a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity.UserId)"><span class="fa fa-trash-o"></span></a>' },
        ]
    };

    $scope.RightsGrid.data = $scope.rightsData;

    $scope.showAdd = function () {
        $('#addRights').modal('show');
    }

    $scope.showView = function () {
        $scope.EditView = false;
        $('#modifyRights').modal('show');
    }

    $scope.showEdit = function () {
        $scope.EditView = true;
        $('#modifyRights').modal('show');
    }

    $scope.showDelete = function () {
        $('#confirmModal').modal('show');
    }

    $scope.GetAllRights = function () {

        rightsFactory.GetAllRights().then(
            function success(data) {

                $scope.RightsGrid.data = data.data;
            },
            function error(data) {

            }
        )
    }

    $scope.GetAllRights();

}]);