    app.controller('MCDepartmentNumber', MCDepartmentNumberController);

    MCDepartmentNumberController.$inject = ['masterDataFactory', 'toaster', '$rootScope'];

    function MCDepartmentNumberController(masterDataFactory, toaster, $rootScope) {
        var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
        //$rootScope.departmentName = userObj.departmentId;
        $rootScope.departmentName = "103";
        var vm = this;
        vm.validateError = false;
        vm.DeleteFlag = false;
        vm.ButtonLabel = "Create";
        vm.flagA = false;
        vm.form = {};
        // vm.form.DepModify={};
        // vm.form.DepModify.DepNumber.$error.validationError = false;
        vm.gridMCDepNumber = {
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1,
            columnDefs: [{
                    name: 'S.No',
                    width: '10%',
                    enableSorting: false,
                    enableFiltering: false,
                    cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
                },
                {
                    name: 'DepartmentName',
                    field: 'DepartmentName',
					cellTooltip: true
                },
                {
                    name: 'DepartmentNumber',
                    field: 'DepartmentNumber',
					cellTooltip: true
                },
                // { name: 'Options', enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }

                //  { name: 'Options', enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }

            ],
        };
        vm.GetDepartmentName = function () {

            masterDataFactory.GetDepartmentName().then(
                function success(data) {
                    // console.log("DDDATA", data);

                    vm.DepartmentDropDownValue = data.data;

                },
                function error(data) {
                    toaster.pop({
                        type: "error",
                        body: "Error while getting department dropdown"
                    });

                }
            )
        }
        vm.GetDepartmentName();

        vm.GetMCDepartmentNumber = function () {

            masterDataFactory.GetMCDepartmentNumber().then(
                function success(data) {

                    //console.log("editSMS", data);
                    vm.DepartmentNumberList = data.data;
                    vm.gridMCDepNumber.data = data.data;
                },
                function error(data) {
                    toaster.pop({
                        type: "error",
                        body: "Error while getting department number"
                    });

                }
            );
        }
        vm.GetMCDepartmentNumber();

        vm.validMcDepartmentNumber = function (value) {
            vm.form.DepModify.DepNumber.$error.validationError = false;

            angular.forEach(vm.DepartmentNumberList, function (obj) {

                if (obj.DepartmentNumber == value) {
                    vm.form.DepModify.DepNumber.$error.validationError = true;
                }

            });
        }

        vm.GetDepartmentNumber = function (value) {
            if (typeof value == 'undefined') {
                vm.flagA = false;
                vm.form.DepModify.DepNumber.$error.validationError = false;
                // vm.FlagContent = false;
            } else {
                vm.DepartmentNumber = '';
                vm.form.DepModify.DepNumber.$error.validationError = false;
                vm.DeleteFlag = false;
                vm.flagA = true;
                angular.forEach(vm.DepartmentNumberList, function (obj) {

                    if (obj.DepartmentName == value) {
                        vm.DepartmentNumber = obj.DepartmentNumber;
                        vm.ButtonLabel = "Update";
                        //vm.flagA = true;
                        vm.DeleteFlag = true;
                        vm.ID = obj.ID;
                    }

                });
                if (!vm.DepartmentNumber) {
                    vm.DepartmentNumber = '';
                    vm.ButtonLabel = "Create";
                    vm.form.DepModify.$setPristine();
                    vm.DeleteFlag = false;
                }
            }
        }

        vm.DeleteDepartmentNumber = function (value) {
            var DepartmentNumberDelete = {};
            DepartmentNumberDelete.ID = vm.ID;
            DepartmentNumberDelete.UpdatedBy = userObj.SSOID;

            masterDataFactory.DeleteMCDepartmentNumber(DepartmentNumberDelete).then(
                function success(data) {
                    vm.GetMCDepartmentNumber();
                    var xyz;
                    vm.GetDepartmentNumber(xyz);
                    vm.DepartmentName = "";
                    vm.DepartmentNumber = "";
                    vm.flagA = false;
                    toaster.pop({
                        type: "success",
                        body: "Deleted Successfully"
                    });

                },
                function error(data) {
                    toaster.pop({
                        type: "error",
                        body: "Error while deleting department number"
                    });

                }
            );

        }

        vm.CreateDepartmentNumber = function () {
            vm.validMcDepartmentNumber(vm.DepartmentNumber);

            if (!vm.form.DepModify.DepNumber.$error.validationError) {
                if (vm.ButtonLabel == "Create") {
                    var DepNumAdd = {};
                    DepNumAdd.DepartmentName = vm.DepartmentName;
                    DepNumAdd.DepartmentNumber = vm.DepartmentNumber;
                    //                    DepNumAdd.CreatedBy = userObj.SSOID;

                    DepNumAdd.CreatedBy = 'Admin';
                    masterDataFactory.CreateMCDepartmentNumber(DepNumAdd).then(
                        function success(data) {
                            vm.GetMCDepartmentNumber();
                            var xyz;
                            vm.GetDepartmentNumber(xyz);
                            vm.DepartmentName = "";
                            vm.DepartmentNumber = "";
                            vm.flagA = false;
                            toaster.pop({
                                type: "success",
                                body: "Added Successfully"
                            });

                        },
                        function error(data) {
                            toaster.pop({
                                type: "error",
                                body: "Error while Adding department number"
                            });

                        }
                    );

                } else {
                    var depNumUpdate = {};
                    depNumUpdate.DepartmentName = vm.DepartmentName;
                    depNumUpdate.DepartmentNumber = vm.DepartmentNumber;
                    depNumUpdate.UpdatedBy = vm.UpdatedBy;
                    depNumUpdate.ID = vm.ID;
                    masterDataFactory.UpdateMCDepartmentNumber(depNumUpdate).then(
                        function success(data) {
                            vm.GetMCDepartmentNumber();
                            vm.flagA = false;
                            var xyz;
                            vm.GetDepartmentNumber(xyz);
                            vm.DepartmentName = "";
                            vm.DepartmentNumber = "";
                            toaster.pop({
                                type: "success",
                                body: "updated Successfully"
                            });

                        },
                        function error(data) {
                            toaster.pop({
                                type: "error",
                                body: "Error while updating department number"
                            });

                        }
                    );



                }
            }

        }


    }