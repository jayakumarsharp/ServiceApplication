app.controller('ProfileController', ['$scope', '$rootScope', '$timeout', 'appFactory', 'profileFactory', 'uiGridConstants', function ($scope, $rootScope, $timeout, appFactory, profileFactory, uiGridConstants) {
    
        $scope.profileInfo = {};
        $scope.profileInfo.ID = '';
        $scope.ProfileName = '';
        $scope.SSOID = '';
        $scope.tab;
        $scope.popupSearchIndex = '';
        $scope.searchIndex = '';
        $scope.Departments = [];
        $scope.Roles = [];
        $scope.EditView = true;
        $scope.Action = '';
        $scope.Department = {};
    
        $scope.permissions = appFactory.permissions[appConst.MENUS.USR_MGNT.MGNT_PROF];
        // $scope.permissions = { 'Add': true, 'View' : true,  'Modify': true, 'Delete': true };
        $scope.deleteItem = '';
    
        $scope.highlightFilteredHeader = function (row, rowRenderIndex, col, colRenderIndex) {
            if (col.filters[0].term) {
                return 'header-filtered';
            } else {
                return '';
            }
        };
    
    
        $scope.ProfileGrid = {
            enableColumnResizing: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            columnDefs: [{
                name: 'S.No', width: '10%', enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Profile', width: '25%', field: 'Name', isSearchable: true, cellTooltip: true,  headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Description', width: '50%', field: 'DepartmentName', isSearchable: true, cellTooltip: true,  headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Options', width: '15%', enableSorting: false,
                cellTemplate: '<a href="#" ng-if="grid.appScope.permissions.View" ng-click="grid.appScope.showView(row.entity)"><span class="fa fa-eye"></span></a>' +
                    '<span  ng-if="!grid.appScope.permissions.View" class="fa fa-eye" style="color:#666; cursor: not-allowed;" ></span>' +
                    ' | <a href="#" ng-if="grid.appScope.permissions.Modify" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a>' +
                    '<span ng-if="!grid.appScope.permissions.Modify" class="fa fa-pencil" style="color:#666; cursor: not-allowed;" ></span>' +
                    ' | <a href="#" ng-if="grid.appScope.permissions.Delete" ng-click="grid.appScope.showDelete(row.entity.Name)"><span class="fa fa-trash-o"></span></a>' +
                    '<span ng-if="!grid.appScope.permissions.Delete" class="fa fa-trash-o" style="color:#666; cursor: not-allowed;" ></span>'
            },
            ]
        };

        $scope.ProfileGrid.onRegisterApi = function (profileGridApi) {
            $scope.profileGridApi = profileGridApi;
        };
    
        $scope.hasPermission = function (access) {
            appFactory.permissions[appConst.MENUS.USR_MGNT.MGNT_PROF][access]
        };
    
        $scope.SelectAllPermission = false;
        $scope.PermissionGrid = {
            enableColumnResizing: true,
            enableFiltering: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            columnDefs: [{
                name: 'S.No', width: '10%', enableFiltering: false, enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            // { name: 'ID', field: 'ID' },
            {
                name: 'Role Name', width: '25%', field: 'RoleName', cellTooltip: true,
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Right Name', width: '25%', field: 'RightName', cellTooltip: true,
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'All', enableFiltering: false,
                cellTemplate: '<input type="checkbox" name="selectAll" value="true" ng-model="row.entity.selectAll" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'SelectAll\')" />'
            },
            {
                name: 'View', enableFiltering: false,
                cellTemplate: '<div ng-if="row.entity.CanHaveView"><input type="checkbox" name="selectView" ng-disabled="!grid.appScope.EditView" value="true" ng-model="row.entity.View"  ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'View\')" /></div>'
            },
            {
                name: 'Add', enableFiltering: false,
                cellTemplate: '<div ng-if="row.entity.CanHaveAdd"><input type="checkbox" name="selectAdd" ng-disabled="!grid.appScope.EditView" value="true" ng-model="row.entity.Add" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'Add\')" /></div>'
            },
            {
                name: 'Modify', enableFiltering: false,
                cellTemplate: '<div ng-if="row.entity.CanHaveModify"><input type="checkbox" name="selectModify" ng-disabled="!grid.appScope.EditView" value="true" ng-model="row.entity.Modify" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'Modify\')" /></div>'
            },
            {
                name: 'Delete', enableFiltering: false,
                cellTemplate: '<div ng-if="row.entity.CanHaveDelete"><input type="checkbox" name="selectDelete" ng-disabled="!grid.appScope.EditView" value="true" ng-model="row.entity.Delete" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'Delete\')" /></div>'
            }
            ]
        };
    
        $scope.PermissionGrid.onRegisterApi = function (permissionGridApi) {
            $scope.permissionGridApi = permissionGridApi;
        };
    
        // $scope.PermissionGrid.data = $scope.permissionData;
    
        $scope.SetCheckboxPermission = function (rowObj, ctrl) {
    
            if (ctrl == 'SelectAll' && rowObj.selectAll == false) {
                rowObj.View = false;
                rowObj.Add = false;
                rowObj.Modify = false;
                rowObj.Delete = false;
                return rowObj;
            }
            if (ctrl == 'SelectAll' && rowObj.selectAll == true) {
                rowObj.View = true;
                rowObj.Add = true;
                rowObj.Modify = true;
                rowObj.Delete = true;
                return rowObj;
            }
            if (ctrl == 'Add' && rowObj.View != true) {
                rowObj.View = true;
            }
            if (ctrl == 'Modify' && rowObj.View != true) {
                rowObj.View = true;
            }
            if (ctrl == 'Delete' && rowObj.View != true) {
                rowObj.View = true;
            }
            if (ctrl == 'View' && (rowObj.View != true)) {
                rowObj.selectAll = false;
                rowObj.Add = false;
                rowObj.Modify = false;
                rowObj.Delete = false;
                return rowObj;
            }
            if (rowObj.Add == true && rowObj.Modify == true && rowObj.Delete == true) {
                rowObj.View = true;
                rowObj.selectAll = true;
                return rowObj;
            }
            // if (rowObj.Add == false && rowObj.Modify == false && rowObj.Delete == false) {
            //     rowObj.View = false; rowObj.selectAll = false; return rowObj;
            // }
            return rowObj;
        }
    
        $scope.showAdd = function () {
            $scope.Action = 'Add';
            $scope.profileInfo = {};
            $scope.EditView = true;
           
            $scope.Department.DepartmentName = '';    
            $scope.Department = {};   
           
        getDepartments();
            clearPopUpSearch();
            $scope.permissionGridApi.grid.clearAllFilters(undefined, true, undefined);
            $scope.GetRolesFromSession();
            $scope.GetAllPermission();
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
    
            })
    
            $('#addProfile').modal('show');
        }
    
        $scope.showView = function (profile) {
            $scope.Action = 'View';
            clearPopUpSearch();
            $scope.profileInfo = {};
            $scope.EditView = false;
            $scope.profileInfo.Profile = profile.Name;
            $scope.profileInfo.ID = profile.ID;
            $scope.permissionGridApi.grid.clearAllFilters(undefined, true, undefined);
    
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
    
            })
    
            $('#modifyProfile').modal('show');
        }
    
        $scope.showEdit = function (profile) {
            $scope.Action = 'Edit';
            clearPopUpSearch();
            $scope.profileInfo = {};
            $scope.EditView = true;
          
            $scope.profileInfo.Profile = profile.Name;
            // $scope.profileInfo.Department = profile.DepartmentID;
            // $scope.profileInfo.IsActive = profile.ISActive;
            $scope.profileInfo.ID = profile.ID;
            $scope.permissionGridApi.grid.clearAllFilters(undefined, true, undefined);
           
            $scope.GetProfileByID(profile.ID)
    
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
    
            })
    
            $('#modifyProfile').modal('show');
        }
    
        $scope.showDelete = function (profileName) {
            $scope.Action = 'DeleteProfile';
            $scope.deleteItem = profileName;
            $scope.ProfileName = profileName;
    
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
    
            })
    
            $('#confirmModal').modal('show');
        }
    
        $scope.delete = function () {
    
    
            if ($scope.Action == 'DeleteProfile') {
                profileFactory.DeleteProfile($scope.deleteItem, $scope.SSOID).then(
                    function success(data) {
                        $scope.GetAllProfile();
                        $('#confirmModal').modal('hide');
                        appFactory.showSuccess('Profile Deleted Successfully');
                    },
                    function error(data) {
                        $('#confirmModal').modal('hide');
                        appFactory.showError('Server Unavailable');
                    }
                )
            } else if ($scope.Action == 'DeletePermission') {
                profileFactory.DeleteAddtionalPermission($scope.deleteItem).then(
                    function success(data) {
                        $scope.GetAllAdditionalPermission();
                        $('#confirmModal').modal('hide');
                        appFactory.showSuccess('Additional Permission Deleted Successfully');
                    },
                    function error(data) {
                        $('#confirmModal').modal('hide');
                        appFactory.showError('Server Unavailable');
                    }
                )
            }
        }
    
        $scope.GetAllPermission = function () {
            profileFactory.GetAllPermission().then(
                function success(data) {
                    $scope.PermissionGrid.data = data.data;
                },
                function error(data) {
                    appFactory.showError('Server Unavailable.');
                }
            )
        }
    
        var getDepartments = function () {
            profileFactory.GetAllDepartment().then(
                function success(data) {
                    $scope.Departments = data.data;
                    $scope.withoutdata = _.findWhere($scope.Departments, {
                        DepartmentName: "Generic"
                    })
    
                    $scope.Departments = _.without($scope.Departments, $scope.withoutdata)
                },
                function error(data) { }
            );
        };
        getDepartments();
    
        $scope.selectRole = function(dept){
            // console.log(dept);
            $scope.Department= dept;
            $scope.profileInfo.Profile = '';
    
            angular.forEach($scope.Roles,function(value){
                if(value.ID == dept.ID){
                    $scope.profileInfo.Profile = dept.ID;
                }
            });        
        }

        var setRoles = function (roles, existingRoles){
            var propName = ['ID'];

            $scope.Roles = roles.filter(function (o1) {
                // filter out (!) items in result2
                return !existingRoles.some(function (o2) {
                    return o1.name === o2.Name; // assumes unique id
                });
            }).map(function (o) {
                // use reduce to make objects with only the required properties
                // and map to apply this to the filtered array as a whole
                return propName.reduce(function (newo, name) {
                    // 
                    newo[name] = o[name];
                    return newo;
                }, {});
            });
        }
    
        $scope.GetRolesFromSession = function () {

            var data;
            $scope.Roles = [];
            var profileList = $scope.ProfileGrid.data;

            if (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) {
                if ($scope.Departments && $scope.Departments.length > 0) setRoles($scope.Departments, profileList);
            }
            else {

                if (sessionStorage.getItem('SSOId')) {
                    data = JSON.parse(sessionStorage.getItem('SSOId'));
                }
                if (data) {
                    for (i = data.Roles.length - 1; i >= 0; i--) {
                        if (data.Roles[i] != 'USER' && data.Roles[i] != 'SUPERADMIN' &&
                            data.Roles[i] != 'ADMIN' && data.Roles[i] != 'RUMAP' &&
                            !data.Roles[i].startsWith(appConst.LINK_APP_R_NAME.SERVINTUIT)
                            //  && !(/^\d+$/.test(data.Roles[i]))
                        ) {
                            $scope.Roles.push({ 'ID': data.Roles[i] });
                        }
                    }
                    if ($scope.Roles && $scope.Roles.length > 0) setRoles($scope.Roles, profileList);
                }

            }
        }
    
    
        $scope.GetAllProfile = function () {
            // 
            profileFactory.GetAllProfile().then(
                function success(data) {
                    // 
                    $scope.ProfileGrid.data = data.data;
                    $scope.ProfileGrid.copyData = data.data;
                    getSearchableFields($scope.ProfileGrid);
                },
                function error(data) {
                    appFactory.showError('Server Unavailable.');
                }
            )
        }
        $scope.GetAllProfile();
    
        $scope.FormSubmit = function (profileInfo) {
            if ($scope.Action == 'Add')
                $scope.CreateProfile(profileInfo);
            else if ($scope.Action == 'Edit')
                $scope.UpdateProfile(profileInfo);
            else if ($scope.Action == 'AddPermission')
                $scope.CreateAdditionalPermission(profileInfo);
            else if ($scope.Action == 'EditPermission')
                $scope.UpdateAdditionalPermission(profileInfo);
        }
    
        $scope.CreateProfile = function (profile) {
            var data = {};
            data.name = profile.Profile;
            // data.departmentID = profile.Department;
            // data.IsActive = profile.IsActive;
            var permissionIdDataObj =
                data.ProfilePermisionMappingList = $scope.PermissionGrid.data;
            data.ProfilePermisionMappingList.forEach(function (v) {
                delete v.$$hashKey;
                delete v.CanHaveAdd;
                delete v.CanHaveDelete;
                delete v.CanHaveModify;
                delete v.CanHaveView;
                delete v.ID;
                delete v.RightName;
                delete v.RoleName;
                delete v.selectAll;
            });
    
            profileFactory.CreateProfile(data).then(
                function success(data) {
                    $('#addProfile').modal('hide');
                    $scope.GetAllProfile();
                    appFactory.showSuccess('Profile Created Successfully');
                },
                function error(data) {
                    appFactory.showError('Server Unavailable.');
                }
            )
        }
    
        $scope.GetProfileByID = function (id) {
            profileFactory.GetProfileByID(id).then(
                function success(data) {
                    $scope.PermissionGrid.data = data.data;
                },
                function error(data) {
                    appFactory.showError('Server Unavailable.');
                }
            )
        }
    
        $scope.UpdateProfile = function (profile) {
    
            var data = {};
            data.name = profile.Profile;
            // data.departmentID = profile.Department;
            data.id = $scope.profileInfo.ID;
            // data.IsActive = profile.IsActive;
            data.ProfilePermisionMappingList = $scope.PermissionGrid.data;
            data.ProfilePermisionMappingList.forEach(function (v) {
                delete v.$$hashKey;
                delete v.CanHaveAdd;
                delete v.CanHaveDelete;
                delete v.CanHaveModify;
                delete v.CanHaveView;
                delete v.ID;
                delete v.RightName;
                delete v.RoleName;
                delete v.selectAll;
            });
    
    
            console.log(JSON.stringify(data));
    
            profileFactory.ModifyProfile(data).then(
                function success(data) {
                    $('#modifyProfile').modal('hide');
                    $scope.GetAllProfile();
                    appFactory.showSuccess('Profile Modified Successfully');
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            )
        }
    
        ///----------- Scripts for Additional User Permission Creation -----
    
        $scope.UserRoles = [];
        $scope.SSOStatus = '';
        $scope.addit = {};
    
        $scope.AdditProfileGrid = {
            enableColumnResizing: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            columnDefs: [{
                name: 'S.No', width: '10%', enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'SSO Id', displayName: 'SSO Id', field: 'SSOId', cellTooltip: true, isSearchable: true,
                cellTemplate: '<div title="{{row.entity.SSOId}}">{{row.entity.SSOId}}</div>',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Department Code', displayName: 'Department Code', field: 'DeptId', cellTooltip: true, isSearchable: true,
                // cellTemplate: '<div title="{{row.entity.SSOId}}">{{row.entity.SSOId}}</div>',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Department Name', displayName: 'Department Name', field: 'DepartmentName', cellTooltip: true, isSearchable: true,
                // cellTemplate: '<div title="{{row.entity.SSOId}}">{{row.entity.SSOId}}</div>',
                headerCellClass: $scope.highlightFilteredHeader
            },            
            {
                name: 'Options', width: '20%', enableSorting: false,
                cellTemplate: '<a href="#" ng-if="grid.appScope.permissions.View" ng-click="grid.appScope.showAdditionalViewPopup(row.entity)"><span class="fa fa-eye"></span></a>' +
                    '<span ng-if="!grid.appScope.permissions.View" class="fa fa-eye" style="color:#666; cursor: not-allowed;" ></span>' +
                    ' | <a href="#" ng-if="grid.appScope.permissions.Modify" ng-click="grid.appScope.showAdditionalEditPopup(row.entity)"><span class="fa fa-pencil"></span></a>' +
                    '<span ng-if="!grid.appScope.permissions.Modify" class="fa fa-pencil" style="color:#666; cursor: not-allowed;" ></span>' +
                    ' | <a href="#" ng-if="grid.appScope.permissions.Delete" ng-click="grid.appScope.showAdditionalDeletePopup(row.entity.SSOId)"><span class="fa fa-trash-o"></span></a>' +
                    '<span ng-if="!grid.appScope.permissions.Delete" class="fa fa-trash-o" style="color:#666; cursor: not-allowed;"  ></span>'
            },
            ]
        };
    
        $scope.AdditProfileGrid.onRegisterApi = function (additProfileGridApi) {
            $scope.additProfileGridApi = additProfileGridApi;
        };
    
        $scope.onViewPermission = function (tab) {
            appFactory.ShowLoader();
            $scope.searchIndex = '';
            $scope.tab = tab;
            if (tab == 1) {
                $scope.GetAllProfile();
    
            } else {
                $scope.GetAllAdditionalPermission();
            }
            $timeout(function () {
                appFactory.HideLoader();
            }, 500)
        };
    
        $scope.GetAllAdditionalPermission = function () {
            profileFactory.GetAllAdditionalPermission().then(
                function success(data) {
                    $scope.AdditProfileGrid.data = data.data;
                    /*  using copyData to handle searching in main grid view, after searching something in pop up grid**/
                    $scope.AdditProfileGrid.copyData = data.data;
                    getSearchableFields($scope.AdditProfileGrid);
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            )
        };
    
        $scope.showAdditionalAddPopup = function () {
            $scope.Action = 'AddPermission';
            clearPopUpSearch();
            $scope.EditView = true;
            $scope.addit = {};
            $scope.SSOStatus = '';
            $('#SSOStatus').removeClass('Valid Invalid');
            $scope.additPermissionGridApi.grid.clearAllFilters(undefined, true, undefined);
            // $scope.UserRoles = [];
            // $scope.AdditionalPermissionGrid.data = [];
            $scope.GetPermissionFromProfile();
    
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
    
            })
    
            $('#additionalPermission').modal('show');
        }
    
        $scope.showAdditionalEditPopup = function (data) {
            clearPopUpSearch();
            $scope.Action = 'EditPermission';
            $scope.EditView = true;
            $scope.addit = {};
            $scope.addit.SSOId = data.SSOId;
            $scope.SSOStatus = 'Valid';
            $('#SSOStatus').removeClass('Valid Invalid');
            $scope.additPermissionGridApi.grid.clearAllFilters(undefined, true, undefined);
            // $scope.UserRoles = [];
            // $scope.AdditionalPermissionGrid.data = [];
            $scope.validateSSO(data.SSOId);
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
    
            })
    
            $('#additionalPermission').modal('show');
        }
    
        $scope.showAdditionalViewPopup = function (data) {
            clearPopUpSearch();
            $scope.Action = 'ViewPermission';
            $scope.EditView = false;
            $scope.addit = {};
            $scope.addit.SSOId = data.SSOId;
            $scope.SSOStatus = '';
            $('#SSOStatus').removeClass('Valid Invalid');
            $scope.additPermissionGridApi.grid.clearAllFilters(undefined, true, undefined);
            // $scope.UserRoles = [];
            // $scope.AdditionalPermissionGrid.data = [];
            $scope.validateSSO(data.SSOId);
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
    
            })
    
            $('#additionalPermission').modal('show');
        }
    
        $scope.showAdditionalDeletePopup = function (ssoId) {
    
            $scope.Action = 'DeletePermission';
            $scope.deleteItem = ssoId;
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
    
            })
    
            $('#confirmModal').modal('show');
        }
    
        $scope.setUserRoles = function (data) {
    
            $scope.UserRoles = [];
    
            if (data != null && data != undefined && data != 'null') {
                var userDetails = JSON.parse(data);
    
                $scope.SSOStatus = 'Valid';
                $('#SSOStatus').removeClass('Valid Invalid');
                $('#SSOStatus').addClass('Valid');
                $scope.profilesName = '';
    
                if (userDetails) {
                    userDetails.ApplicationRoles.forEach(function (ele) {
    
                        if (ele != 'USER' && ele != 'SUPERADMIN' && ele != 'ADMIN' && ele != 'RUMAP') {
                            $scope.UserRoles.push({
                                'name': ele
                            });
                            $scope.profilesName += ele + ',';
                        }                       
                    })
                    if ($scope.Action == 'AddPermission') {
                        $scope.GetPermissionFromProfile($scope.profilesName);
                    } else if ($scope.Action == 'EditPermission' || $scope.Action == 'ViewPermission') {
                        $scope.GetPermissionFromAdditional($scope.profilesName);
                    }
                }
            } else {
                $scope.SSOStatus = 'Invalid';
                $('#SSOStatus').removeClass('Valid Invalid');
                $('#SSOStatus').addClass('Invalid');
                $scope.AdditionalPermissionGrid.data = [];
                $scope.UserRoles = [];
            }
        }
    
        $scope.GetSSOUserRoles = function (ssoId) {
            profileFactory.GetSSOUserRoles(ssoId).then(
                function success(data) {
    
                    $scope.setUserRoles(data.data);
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            )
        };
    
        $scope.validateSSO = function (ssoId) {
            if ($scope.Action == 'AddPermission') {
                var availableSSOId = [];
                var isAvailable = false;
                availableSSOId = $scope.AdditProfileGrid.data;
                availableSSOId.forEach(function (ele) {
                    // 
                    if (ele.SSOId == ssoId) {
                        isAvailable = true;
                    }
                });
    
                if (isAvailable) {
                    $scope.SSOStatus = 'Already Available';
                    $('#SSOStatus').removeClass('Valid Invalid');
                    $('#SSOStatus').addClass('Invalid');
                    $scope.AdditionalPermissionGrid.data = [];
                } else {
                    $scope.GetSSOUserRoles(ssoId);
                }
            } else {
                $scope.GetSSOUserRoles(ssoId);
            }
        }
    
    
        $scope.AdditionalPermissionGrid = {
            enableColumnResizing: true,
            enableFiltering: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            columnDefs: [{
                name: 'S.No', enableSorting: false, width: '10%', enableFiltering: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Role Name', width: '25%', field: 'RoleName', cellTooltip: true,
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Right Name', width: '25%', field: 'RightName', cellTooltip: true,
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'All', enableFiltering: false,
                cellTemplate: '<input type="checkbox" name="selectAll" value="true" ng-model="row.entity.selectAll"  ng-disabled="row.entity.IsViewChecked" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'SelectAll\')" />'
            },
            {
                name: 'View', enableFiltering: false,
                cellTemplate: '<div ng-if="row.entity.CanHaveView"><input type="checkbox" name="selectView" ng-disabled="row.entity.IsViewChecked" ng-model="row.entity.View" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'View\')" /></div>'
            },
            {
                name: 'Add', enableFiltering: false,
                cellTemplate: '<div ng-if="row.entity.CanHaveAdd"><input type="checkbox" name="selectAdd" ng-disabled="row.entity.IsAddChecked" ng-model="row.entity.Add" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'Add\')"  /></div>'
            },
            {
                name: 'Modify', enableFiltering: false,
                cellTemplate: '<div ng-if="row.entity.CanHaveModify"><input type="checkbox" name="selectModify" ng-disabled="row.entity.IsModifyChecked" ng-model="row.entity.Modify" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'Modify\')" /></div>'
            },
            {
                name: 'Delete', enableFiltering: false,
                cellTemplate: '<div ng-if="row.entity.CanHaveDelete"><input  type="checkbox" name="selectDelete" ng-disabled="row.entity.IsDeleteChecked" ng-model="row.entity.Delete" ng-change="grid.appScope.SetCheckboxPermission(row.entity,\'Delete\')"  /></div>'
            }
            ]
        };
    
        $scope.AdditionalPermissionGrid.onRegisterApi = function (additPermissionGridApi) {
            $scope.additPermissionGridApi = additPermissionGridApi;
        };
    
        $scope.LoadPermission = function (role) {
            if ($scope.Action == 'AddPermission')
                $scope.GetPermissionFromProfile();
            else if (($scope.Action == 'EditPermission') || ($scope.Action == 'ViewPermission') || ($scope.Action == 'DeletePermission'))
                $scope.GetPermissionFromAdditional(role);
        }
    
        $scope.GetPermissionFromProfile = function (profileName) {
            profileFactory.GetUserProfileByID(profileName).then(
                function success(data) {
                    $scope.AdditionalPermissionGrid.data = data.data;
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            )
        }
    
        $scope.GetPermissionFromAdditional = function (role) {
    
            profileFactory.GetAdditionalPermission(role, $scope.addit.SSOId).then(
                function success(data) {
                    $scope.AdditionalPermissionGrid.data = data.data;
    
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            )
        }
    
    
        $scope.CreateAdditionalPermission = function (permission) {
    
            profileFactory.GetSSOUserRoles(permission.SSOId).then(
                function success(data) {

                    var jsonData = JSON.parse(data.data);
                    var userDept =  '';

                    for(i = 0 ; i<jsonData.ApplicationRoles.length; i++){
                        if(/^\d+$/.test(jsonData.ApplicationRoles[i])&& jsonData.ApplicationRoles[i].length == 7){
                            userDept = parseInt(jsonData.ApplicationRoles[i]);
                        }
                    }
    
                    // $scope.setUserRoles(data.data);
                    if (data.data != null && data.data != undefined && data.data != 'null') {
                        var value = {};
                        // data.ProfileName = permission.Role;
                        value.SSOId = permission.SSOId;
                        value.DeptId = userDept;
                        value.ProfilePermisionMappingList = $scope.AdditionalPermissionGrid.data;
                        value.ProfilePermisionMappingList.forEach(function (v) {
                            delete v.$$hashKey;
                            delete v.CanHaveAdd;
                            delete v.CanHaveDelete;
                            delete v.CanHaveModify;
                            delete v.CanHaveView;
                            delete v.IsAddChecked;
                            delete v.IsDeleteChecked;
                            delete v.IsModifyChecked;
                            delete v.IsViewChecked;
                            delete v.ID;
                            // delete v.ProfileId;
                            delete v.RightName;
                            delete v.RoleName;
                            delete v.selectAll;
                        });
    
                        profileFactory.CreateAdditionalUserPermission(value).then(
                            function success(data) {
                                $scope.GetAllAdditionalPermission();
                                $('#additionalPermission').modal('hide');
                                appFactory.showSuccess('Additional Permission Created Successfully');
                            },
                            function error(data) {
                                appFactory.showError('Server Unavailable');
                            }
                        )
    
                    } else {
                        $scope.SSOStatus = 'Invalid SSOId';
                        $('#SSOStatus').removeClass('Valid Invalid');
                        $('#SSOStatus').addClass('Invalid');
                        $scope.AdditionalPermissionGrid.data = [];
                    }
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            )
    
    
        }
    
        $scope.UpdateAdditionalPermission = function (permission) {
    
            var data = {};
            // data.ProfileName = permission.Role;
            data.SSOId = permission.SSOId;
            data.ProfilePermisionMappingList = $scope.AdditionalPermissionGrid.data;
            data.ProfilePermisionMappingList.forEach(function (v) {
                delete v.$$hashKey;
                delete v.CanHaveAdd;
                delete v.CanHaveDelete;
                delete v.CanHaveModify;
                delete v.CanHaveView;
                delete v.IsAddChecked;
                delete v.IsDeleteChecked;
                delete v.IsModifyChecked;
                delete v.IsViewChecked;
                delete v.ID;
                // delete v.ProfileId;
                delete v.RightName;
                delete v.RoleName;
                delete v.selectAll;
            });
    
            profileFactory.UpdateAddtionalUserPermission(data).then(
                function success(data) {
                    $scope.GetAllAdditionalPermission();
                    $('#additionalPermission').modal('hide');
                    appFactory.showSuccess('Additional Permission Modified Successfully');
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            )
        };
    
        $scope.onCloseModal = function () {
     
            if ($scope.Action === 'Add' || $scope.Action === 'Edit' || $scope.Action === 'View') {
                $('#modifyProfile').modal('hide');
                getSearchableFields($scope.ProfileGrid);
            } else if ($scope.Action == 'AddPermission' || $scope.Action == 'EditPermission' || $scope.Action === 'ViewPermission') {
                $('#additionalPermission').modal('hide');
                getSearchableFields($scope.AdditProfileGrid);
            }
            $scope.Action = '';
            clearPopUpSearch();
            // $scope.onTypeSearchValues(); 
        };
    
        $scope.onTypeSearchValues = function (searchIndex) {
            var searchIndex = (searchIndex !== undefined) ? searchIndex : $scope.searchIndex;
            var filteredData = appFactory.getDataBySearchIndex(searchIndex);
            if ($scope.tab === 1) {
                $scope.ProfileGrid.data = filteredData;
                return;
            }
            if ($scope.tab === 2) {
                $scope.AdditProfileGrid.data = filteredData;
                return;
            } else {
    
            }
        };
        var clearPopUpSearch = function () {
            $scope.popupSearchIndex = '';
           
        };
    
        var getSearchableFields = function (gridConfig) {
            clearPopUpSearch();
            appFactory.getSearchableFields(gridConfig);
        };
    
        var init = function () {
            // $scope.ProfileGrid.onRegisterApi = function (profileGridApi) {
            //     $scope.profileGridApi = profileGridApi;
            // };
    
            // setInterval(function () {
            //     $scope.profileGridApi.core.notifyDataChange(uiGridConstants.dataChange.ALL);
            // });
        }
    }]);