app.controller('ipWhitelistingController', function ($scope, $window, masterDataFactory, toaster,$rootScope) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
 // $rootScope.departmentName = userObj.departmentId;
   $rootScope.departmentName = "103";
   var userObj = {
            SSOID: ''
        }

    $scope.Formlist = {};
   
    $scope.systems = {};
    $scope.form={};
//Grid Specification
    $scope.gridIPWhitelisting = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [
            { name: 'S.No', width: '10%',enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            { name: 'DepartmentName',cellTooltip: true, field: 'DepartmentName' },
            { name: 'ApplicationName',cellTooltip: true, field: 'ApplicationUse' },
            { name: 'IPAddress',cellTooltip: true, field: 'IPAddress' },
            { name: 'Description',cellTooltip: true, field: 'Description' },
            { name: 'UserName',cellTooltip: true, field: 'UserName' },
            { name: 'Password',cellTooltip: true, field: 'Password', visible:false },
            { name: 'Options', enableSorting: false, enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }
        ],
    };
//Data binding to Dropdowns
    $scope.GetApplicationName = function () {
       
        masterDataFactory.GetApplicationName().then(
            function success(data) {
               
                $scope.ApplicationUseDropDownValue = data.data;
            },
            function error(data) {
               
            }
        )
    }

    $scope.GetApplicationName();
    $scope.GetDepartmentName = function () {
       
        masterDataFactory.GetDepartmentName().then(
            function success(data) {
               
                $scope.DepartmentDropDownValue = data.data;
            },
            function error(data) {
               
            }
        )
    }
    $scope.GetDepartmentName();

 
//Data binding to Grid
    $scope.GetIPWhitelisting = function () {
        
        masterDataFactory.GetAllIPWhitListing().then(
            function success(data) {
                
                $scope.gridIPWhitelisting.data = data.data;
            },
            function error(data) {
                
            }
        )
    }

    $scope.GetIPWhitelisting();

    $scope.inputType = 'password';
    $scope.hideShowPassword = function(){
    if ($scope.inputType == 'password')
    $scope.inputType = 'text';
    else
    $scope.inputType = 'password';
    };
   
   //Add functinality
    $scope.showAdd = function () {
        $scope.Formlist = {};
        $scope.form.IPWhitelist.$setPristine();
        $('#AddIPWhitelisting').modal('show');
        
    }
    $scope.Add = function () {
        var IpWhitelistingAdd = {};
        IpWhitelistingAdd.DepartmentID = $scope.Formlist.DepartmentID.ID;
        IpWhitelistingAdd.ApplicationID = $scope.Formlist.ApplicationID.ID;
        IpWhitelistingAdd.IPAddress = $scope.Formlist.IPAddress;
        IpWhitelistingAdd.Description = $scope.Formlist.Description;
        IpWhitelistingAdd.UserName = $scope.Formlist.UserName;
        IpWhitelistingAdd.Password = $scope.Formlist.Password;
        IpWhitelistingAdd.CreatedBy = userObj.SSOID;
        var flag = 1;
        // calling API to create new IPwhitelisting
        if (flag == 1) {
            masterDataFactory.CreateIPWhiteListing(IpWhitelistingAdd).then(function (data) {
               
                
                

                if (data.data == "Success") {
                    $('#AddIPWhitelisting').modal('hide');
                    $scope.GetIPWhitelisting();
                    $scope.Formlist = {};
                    $scope.form.IPWhitelist.$setPristine();
                    toaster.pop({ type: "success", body: "IPAdded successfully" });
                    //Updating the table data       



                }
                else {
                    $scope.GetIPWhitelisting();

                    toaster.pop({ type: "error", body: "Error while creating Whitelisting" });

                }




            });
        }

    }
    //Update functionality
    $scope.showEdit = function (getRowData) {
        $scope.IPWhitelistEdit = {};
     
        $scope.IPWhitelistEdit.ApplicationID = getRowData.ApplicationID; 
        $scope.IPWhitelistEdit.IPAddress = getRowData.IPAddress;
        $scope.IPWhitelistEdit.Description = getRowData.Description;
        $scope.IPWhitelistEdit.UserName = getRowData.UserName;
        $scope.IPWhitelistEdit.Password = getRowData.Password;
        $scope.IPWhitelistEdit.IPID = getRowData.IPID;

        $scope.IPWhitelistEdit.DepartmentID = {
            ID:getRowData.DepartmentID,
            DepartmentName:getRowData.DepartmentName
        }
        $scope.EditView = true;
        $('#modifyIPWhitelisting').modal('show');
    }
    

    $scope.UpdateIPWhitelisting = function () {
        $scope.IPWhitelistUpdate = {};

        $scope.IPWhitelistUpdate.UpdatedBy = userObj.SSOID;

        $scope.IPWhitelistUpdate.DepartmentID = $scope.IPWhitelistEdit.DepartmentID;
        $scope.IPWhitelistUpdate.ApplicationID = $scope.IPWhitelistEdit.ApplicationID;
        $scope.IPWhitelistUpdate.IPAddress = $scope.IPWhitelistEdit.IPAddress;
        $scope.IPWhitelistUpdate.Description = $scope.IPWhitelistEdit.Description;
        $scope.IPWhitelistUpdate.UserName = $scope.IPWhitelistEdit.UserName;
        $scope.IPWhitelistUpdate.Password = $scope.IPWhitelistEdit.Password;
        $scope.IPWhitelistUpdate.IPID = $scope.IPWhitelistEdit.IPID;

        masterDataFactory.UpdateIPWhitelisting($scope.IPWhitelistUpdate).then(function (data) {
            
            

            if (data.data == "Success") {
                $scope.GetIPWhitelisting();

                $('#modifyIPWhitelisting').modal('hide');
                toaster.pop({ type: "Success", body: "IP Whitelisting Modified successfully" });

            }
            else {
                $scope.GetSmsCode();
                toaster.pop({ type: "error", body: "Error while Modifying IP Whitelisting" });

            }
        });


    }
    //Delete functionality
    $scope.showDelete = function (getRowData) {

        $scope.CodeID = getRowData.IPID;
        $scope.EditView = true;
        $('#confirmModal').modal('show');
    }

    $scope.Delete = function (index) {
        var IPID = $scope.CodeID;


        masterDataFactory.DeleteIPWhitelisting(IPID).then(function (data) {
            
            

            if (data.data == "Success") {
                $('#confirmModal').modal('hide');
                toaster.pop({ type: "success", body: "IP removed sucessfuly", toasterId: 63 });
                $scope.GetIPWhitelisting();


            }
            else {
                $scope.GetIPWhitelisting();
                toaster.pop({ type: "error", body: "Error while removing Whitelisting", toasterId: 63 });

            }

        });


    }


});