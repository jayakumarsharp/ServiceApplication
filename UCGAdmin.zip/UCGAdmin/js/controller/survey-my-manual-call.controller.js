app.controller('MyManualCallController', ['$scope', '$rootScope', 'surveyFactory', 'appFactory', 'surveyCampFactory', 'uiGridExporterConstants', 'toaster', function ($scope, $rootScope, surveyFactory, appFactory, surveyCampFactory, uiGridExporterConstants, toaster) {
    
    
        var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
        $rootScope.departmentName = userObj.departmentId;
        myManualCall = this;
        myManualCall.departmentName = userObj.departmentId;
        myManualCall.permissions = appFactory.permissions[appConst.MENUS.RCHK_MGMT.MY_MNL_CALL];
        myManualCall.permissions = {};
        myManualCall.permissions.Modify = true;
        myManualCall.agentName = userObj.SSOID;
        // myManualCall.departmentName = '103';
        // myManualCall.agentName = 'esanchar2.test'; 
        myManualCall.thankYou = false;
        myManualCall.radioFlag = false;
        myManualCall.surveyClose = false;
        $scope.surveyCompleted = false;
        myManualCall.surveyStatus = "I";
        myManualCall.selectedContactsId = [];
        myManualCall.AnswerSet = [];
        myManualCall.Selected = {};
        myManualCall.currentQuestion = {};
        myManualCall.questionStack = [];
        myManualCall.filter = {
                phoneNo: '',
                startDate: '',
                endDate: ''
            },
            myManualCall.gridConfig = {
                paginationPageSizes: [10, 20, 30],
                paginationPageSize: 10,
                enableColumnMenus: false,
                enableHorizontalScrollbar: 1,
                enableVerticalScrollbar: 1,
                data: [],
                columnDefs: [{
                        name: 'Mobile Number',
                        field: 'MOBILE_NO',
                        cellTooltip: true
                    },
                    {
                        name: 'Citizen Name',
                        field: 'CITIZEN_NAME',
                        cellTooltip: true
                    },
                    {
                        name: 'Email',
                        field: 'EMAIL',
                        cellTooltip: true
                    },
                    {
                        name: 'Sample Name',
                        field: 'SampleName',
                        cellTooltip: true
                    },
                    {
                        name: 'Call attemps',
                        field: 'NoOfAutomatedIVRCallCount',
                        cellTooltip: true
                    },
                    {
                        name: 'Survey',
                        width: '25%',
                        cellTemplate: '<div class="click-to-update"> <div>' +
                            '<span class="fa fa-pencil-square-o" ng-click="grid.appScope.myManualCall.showCommentsPopup(row.entity)"> </span>' +
                            '</div></div>'
                    },
                ],
                multiSelect: true,
                onRegisterApi: function (gridApi) {
                    myManualCall.gridApi = gridApi;
                },
            };
    
        var nodeIdQueue = [];
        var questionSet = {};
    
        $('.modal-dialog .card').resizable().draggable();
    
        /* for calender open and close **/
        myManualCall.open = {
            startDate: false,
            endDate: false
        };
    
        myManualCall.openCalendar = function (e, date) {
            e.preventDefault();
            e.stopPropagation();
            myManualCall.open[date] = true;
        };
    
        var onLoadsearch = function () {
            var filter = myManualCall.filter;
            var criteria = {
                fromDate: moment(filter.startDate).format('YYYY-MM-DD HH:mm:ss'),
                toDate: moment(filter.endDate).format('YYYY-MM-DD HH:mm:ss'),
                //     contactNo: (filter.mobileNo) ? filter.mobileNo : 'All',
                user: myManualCall.agentName,
            };
            surveyCampFactory.GetMyManualContact(criteria).then(function (data) {
                appFactory.ShowLoader();
                if (data.data) {
                    myManualCall.gridConfig.data = data.data;
                    appFactory.HideLoader();
                } else {
                    appFactory.HideLoader();
                }
            });
        };
    
        myManualCall.onSearchCallContacts = function () {
            var filter = myManualCall.filter;
            var criteria = {
                fromDate: moment(filter.startDate).format('YYYY-MM-DD HH:mm:ss'),
                toDate: moment(filter.endDate).format('YYYY-MM-DD HH:mm:ss'),
                //     contactNo: (filter.mobileNo) ? filter.mobileNo : 'All',
                user: myManualCall.agentName,
                //status :
    
                //myManualCall.departmentName,
            };
            surveyCampFactory.GetMyManualContact(criteria).then(function (data) {
                if (data.data) {
                    myManualCall.gridConfig.data = data.data;
                } else {
    
                }
            });
        };
    
        myManualCall.onExportData = function () {
            if (myManualCall.gridConfig.data != null && myManualCall.gridConfig.data.length > 0) {
                myManualCall.gridApi.exporter.csvExport(uiGridExporterConstants.VISIBLE, uiGridExporterConstants.ALL);
            }
        };
    
        var setStartAndEndDate = function (obj) {
            var starttime = new Date();
            starttime.setDate(starttime.getDate() - 7);
            starttime.setHours(9);
            starttime.setMinutes(0);
            var endtime = new Date();
            endtime.setHours(23);
            endtime.setMinutes(0);
            obj.startDate = starttime;
            obj.endDate = endtime;
        };
        myManualCall.Id = '';
        myManualCall.showCommentsPopup = function (rowData) {
            myManualCall.Id = rowData.ID;
           
            // questionSet.IVRData = rowData.IVRData;
            // cbsGetQuestionSet(rowData.ContactGUID);
            getQuestionSet(rowData.ContactGUID);
    
        };
    
        var getQuestionSet = function (ContactGUID) {
            // ContactGUID = 'f71bd671-89cd-4a11-bb7f-b3f494799779';
           
            surveyCampFactory.GetManualContact(ContactGUID).then(function (data) {
    
                if (data.data && data.data.length) {
                    questionSet = data.data[0];
                    cbsGetQuestionSet(ContactGUID);
                } else {
                    toaster.pop({
                        type: "error",
                        body: "Error while fetching the data"
                    });
                }
            });
        };
    
        var cbsGetQuestionSet = function (ContactGUID) {
            questionSet.ContactGUID = ContactGUID;
            if (!questionSet.IVRData) {
                toaster.pop({
                    type: "warning",
                    body: 'Survey not available'
                });
                return;
            }
            questionSet.IVRData = JSON.parse(questionSet.IVRData);
            initiateSurvey();
            // document.getElementById('surveyNext').value = "Next";
            // document.getElementById('surveyNext').style.backgroundColor = "##5cb85c";
            // document.getElementById('surveyNext').style.borderColor = "#4cae4";
            $('#commentModal').modal('show');
        };
    
        var initiateSurvey = function () {
            var flowName = 'StartFlowNode';
            angular.forEach(questionSet.IVRData.Nodes, function (value, key) {
                if (value.NodeId === flowName) {
                    // myManualCall.startNodeId = value.childnodes[0].NextNodeId;
                    if (value.childnodes.length) {
                        nodeIdQueue = angular.copy(value.childnodes);
                    }
                }
            });
            var firstItem = nodeIdQueue.shift();
            myManualCall.currentQuestion = getQuestionByNodeId(firstItem.NextNodeId);
    
            if (myManualCall.currentQuestion) {
                myManualCall.surveyStatus = "I";
            }
        };
    
    
        myManualCall.selectedRadioOption = function (seletecedChoiceIndex) {
            myManualCall.radioFlag = true;
            myManualCall.currentQuestion.choices.forEach(function (selectedradio, index) {
                selectedradio.isSelected = false;
                if (index === seletecedChoiceIndex) {
                    selectedradio.isSelected = "true";
                }
            })
        }
    
    
        myManualCall.getNextQuestion = function () {
            myManualCall.surveyStatus = "M";
            var ques = myManualCall.currentQuestion;
            var answer = {
                NodeId: ques.nodeId,
                Question: ques.ques,
                SelectedOption: []
            }
            if (ques.type == "Subjective") {
                answer.SelectedOption = myManualCall.Selected.Option;
            }
    
            ques.choices.forEach(function (selectedchild) {
                if (selectedchild.isSelected == "true") {
                    answer.SelectedOption.push(selectedchild);
                    answer.SelectedOption = answer.SelectedOption[0].NodeValue;
                    selectedchild.childnodes.reverse();
                    selectedchild.childnodes.forEach(function (childNode) {
                        nodeIdQueue.unshift(childNode);
                    });
                }
            })
            myManualCall.AnswerSet.push(answer);
            myManualCall.Selected = {};
            var firstItem = nodeIdQueue.shift();
            if (firstItem)
                myManualCall.currentQuestion = getQuestionByNodeId(firstItem.NextNodeId);
    
            //  if (!nodeIdQueue.length) {
            if (!firstItem || !myManualCall.currentQuestion.ques) {
                document.getElementById('survey-next').value = "Finish";
                document.getElementById('survey-next').style.backgroundColor = "blue";
                myManualCall.surveyStatus = "C";
                $scope.surveyCompleted = true;
                completeSurvey();
                return;
            }
        };
    
        var completeSurvey = function () {
            if (!myManualCall.currentQuestion.ques) {
                myManualCall.surveyStatus = "C";
            }
            var anwseredQuesSet = {
                updateID: myManualCall.Id,
                emailGUID: questionSet.ContactGUID,
                jSONData: JSON.stringify(myManualCall.AnswerSet),
                SurveyStatus: myManualCall.surveyStatus,
            }
    
    
            surveyFactory.submitQuestionSurvey(anwseredQuesSet).then(function (data) {
                if (data.data) {
                    toaster.pop({
                        type: "success",
                        body: 'Survey completed successfully'
                    });
                    myManualCall.Id = '';
                    myManualCall.onSearchCallContacts();
                    $scope.surveyCompleted = false;
                    $('#commentModal').modal('hide');
                    myManualCall.AnswerSet = [];
                    questionSet = [];
                } else {
                    toaster.pop({
                        type: "error",
                        body: 'Error while updating survey'
                    });
                }
            });
        }
    
        myManualCall.closeSurvey = function () {
            myManualCall.surveyClose = true;
            completeSurvey();
        }
    
    
        var getQuestionByNodeId = function (nodeID) {
            myManualCall.radioFlag = false;
            var question = {
                ques: '',
                type: '',
                nodeId: '',
                choices: []
            };
            angular.forEach(questionSet.IVRData.Nodes, function (value, key) {
                if (value.NodeId === nodeID) {
                    // if (!value.childnodes.length) {
                    //     return;
                    // }              
                    if (value.NodeType == 'Question') {
                        question.ques = value.Question;
                    }
                    question.nodeId = value.NodeId;
                    question.type = value.InputType;
    
                    if (value.InputType == 'Objective') {
                        value.childnodes.forEach(function (childNode) {
                            questionSet.IVRData.Nodes.forEach(function (listnode) {
                                if (listnode.NodeId == childNode.NextNodeId) {
                                    listnode.isSelected = false;
                                    question.choices.push(listnode);
                                    nodeIdQueue.unshift(listnode);
                                }
                            })
    
                        })
                    }
                    if (value.InputType == 'Subjective' || value.InputType == 'Option') {
                        value.childnodes.reverse();
                        value.childnodes.forEach(function (childNode) {
                            nodeIdQueue.unshift(childNode);
                        });
                        return;
                    }
                }
            });
            return question;
        };
    
        var init = function () {
    
            setStartAndEndDate(myManualCall.filter);
            onLoadsearch();
        };
    
        init();
    }]);