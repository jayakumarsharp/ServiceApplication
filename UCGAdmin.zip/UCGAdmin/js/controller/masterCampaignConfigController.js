app.controller('masterCampaignConfig', function ($scope, $rootScope, masterDataFactory, toaster) {

    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
  // $rootScope.departmentName = userObj.departmentId;
       var userObj = {
         SSOID: 'admin'
     };
   $rootScope.departmentName = "103";
    $scope.Formlist = {};
    $scope.Formedit = {};
    $scope.form = {};
    $scope.thresholdEdit = {};
    //Grid Specification
    $scope.gridThreshold = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
            name: 'S.No',
            width: '10%',
            enableSorting: false,
            enableFiltering: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
        },
               {
            name: 'DepartmentName',
            field: 'DepartmentName',
            cellTooltip: true
        },
        {
            name: 'Application',
            field: 'Application',
            cellTemplate: "<span> {{row.entity.Application==1?'Campaign':'Survey'}}<span>",
            cellTooltip: true
        },
        {
            name: 'Comments',
            field: 'Comments',
            cellTooltip: true
        },
         {
            name: 'ThresholdLimit',
            field: 'ThresholdLimit',
            cellTooltip: true
        },
        // {
        //     name: 'Options', enableSorting: false,
        //     enableFiltering: false,
        //     width: '10%',
        //     cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
        // }
        ],
    };

    $scope.GetCampaignConfig = function () {
        $scope.obj={};
        $scope.obj.departmentID=89;
        $scope.obj.application=1;
        masterDataFactory.GetCampaignThreshold($scope.obj).then(
            function success(data) {
                $scope.gridThreshold.data = data.data;
            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while retreiving Department"
                });
            }
        )
    }
    $scope.GetCampaignConfig();

    // //Get Department name
    $scope.GetDepartmentName = function () {

        masterDataFactory.GetDepartmentName().then(
            function success(data) {
                $scope.Departments = data.data;
                // $scope.gridDepartment.data = data.data;
                $scope.withoutdata = _.findWhere($scope.Departments, {
                    DepartmentName: "Generic"
                })

                $scope.Departments = _.without($scope.Departments, $scope.withoutdata)
                $scope.DepartmentDropDownValue = $scope.Departments;
            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while retreiving Department"
                });
            }
        )
    }
    $scope.GetDepartmentName();

    $scope.ApplicationDropDownValue = [{
        ID: 1,
        ApplicationName: 'Campaign'
    },
    {
        ID: 2,
        ApplicationName: 'Survey'
    }
];






    // //Add functionality

    $scope.showAdd = function () {
                 $scope.Formlist = {};   
         $scope.form.Campthreshold.$setPristine();
        $('#AddCampaignthreshold').modal('show');
    }
    $scope.CreateCampthreshold = function () {
            $scope.thresholdAdd = {};
            $scope.thresholdAdd.createdBy = userObj.SSOID;
            $scope.thresholdAdd.departmentID = $scope.Formlist.SelecedDep;
            $scope.thresholdAdd.application = $scope.Formlist.Application;
            $scope.thresholdAdd.comments = $scope.Formlist.comments;
            $scope.thresholdAdd.thresholdLimit= $scope.Formlist.ThresholdLimit;

            masterDataFactory.CreateCampaignThreshold($scope.thresholdAdd).then(function (data) {



                if (data.data == "Success") {
                    $scope.GetCampaignConfig();
                    $scope.Formlist = {};
                    $('#AddCampaignthreshold').modal('hide');
                    //$scope.form.DepartmentMaster.$setPristine();

                    toaster.pop({
                        type: "Success",
                        body: "Created successfully"
                    });

                } else {
                    $scope.GetCampaignConfig();
                    toaster.pop({
                        type: "error",
                        body: "Error while Adding Creating Campaign Threshold"
                    });

                }
            });
        

    }
    
    $scope.showEdit = function (getRowData) {
       
        $scope.thresholdEdit.departmentID = getRowData.DepartmentID;
        $scope.thresholdEdit.Application = getRowData.Application;
        $scope.thresholdEdit.comments = getRowData.Comments;
        $scope.thresholdEdit.thresholdLimit = getRowData.ThresholdLimit;
        $('#modifyCampaignthreshold').modal('show');
    }



    $scope.UpdateCampThreshold = function () {

       
            $scope.Update = {};
            $scope.Update.updatedBy = userObj.SSOID;
            $scope.Update.departmentID =  $scope.thresholdEdit.departmentID;
            $scope.Update.application = $scope.thresholdEdit.Application;
            $scope.Update.comments = $scope.thresholdEdit.comments;
            $scope.Update.thresholdLimit =  $scope.thresholdEdit.thresholdLimit;

            masterDataFactory.UpdateCampaignThreshold($scope.Update).then(function (data) {



                if (data.data == "Success") {
                    $scope.GetCampaignConfig();

                    $('#modifyCampaignthreshold').modal('hide');
                    toaster.pop({
                        type: "Success",
                        body: "updated successfully"
                    });

                } else {
                    $scope.GetCampaignConfig();
                    toaster.pop({
                        type: "error",
                        body: "Error while creating updating Campaign threshold"
                    });

                }
            });
        

    }
    //Delete Department
    $scope.showDelete = function (getRowData) {

        $scope.CodeID = getRowData.DepartmentID;
        $scope.CodeApp= getRowData.Application;
        $scope.EditView = true;
        $('#confirmModalCampThres').modal('show');
    }

    $scope.Delete = function () {
        $scope.Delete = {};
        $scope.Delete.DepartmentID = $scope.CodeID;
        $scope.Delete.Application = $scope.CodeApp;
        $scope.Delete.updatedBy = userObj.SSOID;
        masterDataFactory.DeleteCampaignThreshold($scope.Delete).then(function (data) {
            if (data.data == "Success") {
                $scope.GetCampaignConfig();
                $('#confirmModalCampThres').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "Deleted successfully"
                });


            } else {
                $scope.GetCampaignConfig();
                toaster.pop({
                    type: "error",
                    body: "Error while creating deleting Campaign Threshold"
                });
            }
        });

    }



});