app.controller('DNCController', ['$scope', '$rootScope','uiGridExporterConstants','uiGridExporterService','exportFactory', '$q', 'appFactory', '$timeout', '$http', '$filter', 'toaster', 'campaignFactory', function ($scope, $rootScope,uiGridExporterConstants,uiGridExporterService,exportFactory, $q, appFactory, $timeout, $http, $filter, toaster, campaignFactory) {
    // Global variable declarations
    var vm = this;
    $scope.dnc = {};
    $scope.form={};
    $scope.isValid = false;
    $scope.dncSearchedData = [];
    $scope.isshowgrid = false;
    $scope.DNCAdd={};
  

    //

    $scope.permissions = appFactory.permissions[appConst.MENUS.CAMP_MGNT.MGNT_CAMP];
    // ***** Private Methods ***** //

    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId;
    //$rootScope.departmentName = "103";
      //  var userObj = {
       //   SSOID: 'admin'
      //};
  // $rootScope.departmentName ="8";
    

    $scope.getdncValue = function (dnccbSelected) {
        $scope.dnc.SelectedDnc = dnccbSelected;
    }

    vm.dncContactGrid = {
        enableRowSelection: true,
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1,
        enableVerticalScrollbar: 1,

        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableFiltering: false,
               // cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
                cellTemplate: '<span class="ui-grid-cell-contents" ng-bind="{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}"><span>'
               
            },
            {
                name: 'Mobile No',
                field: 'DNCVALUE',
                cellTooltip: true

            },
            {
                name:'SourceType',
                field:'SourceType',
                cellTooltip: true
            },
            {
                name:'FileName',
                field:'OriginalFileName',
                cellTooltip: true
            },
            {
                name:'Comment',
                field:'Comment',
                cellTooltip: true
            },
            {
                name:'Added Date',
                field:'StartDate',
                cellFilter: 'date:\'dd-MM-yy HH:mm\'',
                cellTooltip: true
            },
                 {
                name: 'Options', enableSorting: false,
                enableFiltering: false,
                width: '30%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
                
             //   cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
            }

        ],
      exporterHeaderFilterUseName: function (displayName) {
      return 'col: ' + name;
    },
    exporterCsvFilename: 'exportedData.xlsx',
    exporterPdfFilename: 'pdfFileFormat.pdf',
    exporterPdfDefaultStyle: {
      fontSize: 10
    },
    exporterPdfTableStyle: {
      margin: [0, 30, 0, 15]
    },
    exporterPdfTableHeaderStyle: {
      fontSize: 10,
      bold: true,
      italics: true,
      color: 'red'
    },
    exporterPdfHeader: {
      margin: [2, 14, 0, 0],
      text: 'DNC List',
      style: 'headerStyle',
      alignment: 'center'
    },
     
    exporterPdfFooter: function (currentPage, pageCount) {
      return {
        text: currentPage.toString() + ' of ' + pageCount.toString(),
        style: 'footerStyle'
      };
    },
    exporterPdfCustomFormatter: function (docDefinition) {
      docDefinition.styles.headerStyle = {
        fontSize: 22,
        bold: true,
        alignment: 'left'
      };
      docDefinition.styles.footerStyle = {
        fontSize: 10,
        bold: true,
        alignment: 'center'
      };
      return docDefinition;
    },
    exporterPdfOrientation: 'landscape',
    exporterPdfPageSize: 'A4',
    exporterPdfMaxGridWidth: 720,
    exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
    onRegisterApi: function (gridApi) {
      vm.gridApi = gridApi;
    }
      };


    $('.modal-dialog .card').resizable().draggable();
    $scope.UploadDNC = function () {
        IsValidFile();
        if ($scope.isValid == true) {
            var formData = new FormData();

            formData.append("dncAction", angular.toJson($scope.dnc.SelectedDnc));
            formData.append("uploadedBy", angular.toJson(userObj.SSOID));
            formData.append("comments", $scope.dnccomments);

            formData.append("dncFile", $scope.dncuploadfile);

            if ($scope.dnc.SelectedDnc == "Add") {
                campaignFactory.UploadAddDNCFile(formData, $scope.dnc.SelectedDnc).then(function (data) {
                    //
                    if (data.data.Message === 'Success') {
                        toaster.pop({
                            type: "success",
                            body: "Dnc file successfully uploaded to add",
                            bodyOutputType: 'trustedHtml'
                        });
                        $scope.GetDNCCount();
                        $scope.dnccomments = '';
                        $scope.dncvar='';
                        $scope.reset();
                    } else {
                        toaster.pop({
                            type: "error",
                            body: "Error while uploading dnc file to add",
                            bodyOutputType: 'trustedHtml'
                        });
                    }
                });
            } else if ($scope.dnc.SelectedDnc == "Remove") {
                campaignFactory.UploadRemoveDNCFile(formData, $scope.dnc.SelectedDnc).then(function (data) {
                    //

                    if (data.data.Message === 'Success') {
                        toaster.pop({
                            type: "success",
                            body: "Dnc file successfully uploaded to remove",
                            bodyOutputType: 'trustedHtml'
                        });
                         $scope.dnccomments = '';
                         $scope.dncvar='';
                         $scope.reset();
                    } else {
                        toaster.pop({
                            type: "error",
                            body: "Error while uploading dnc file to remove",
                            bodyOutputType: 'trustedHtml'
                        });
                    }
                });
            }

        }

    }
    $scope.reset = function () {
        angular.element("input[type='file']").val(null);
    };
    $scope.AddDNC = function () {
        if (!$scope.dncaddMobileno || !$scope.comments) {
            toaster.pop({
                type: "error",
                body: "Mobile no and comments should not be empty",
                bodyOutputType: 'trustedHtml'
            });
        } else {

            var jsonobj = {
                mobileNo: $scope.dncaddMobileno,
                comments: $scope.comments
            }
            
            campaignFactory.AddDNCContact(jsonobj).then(function (data) {
                if (data.data === '50020') {
                    toaster.pop({
                        type: "success",
                        body: "Dnc contact added successfully",
                        bodyOutputType: 'trustedHtml'
                    });
                    
                    $scope.dncaddMobileno = '';
                    $scope.comments = '';
                    $scope.GetDNCCount();
                    $scope.DNCAdd.$setPristine();
                } else {
                    toaster.pop({
                        type: "error",
                        body: "Error while adding contact to dnc",
                        bodyOutputType: 'trustedHtml'
                    });
                }
            });

        }

    }
    vm.open = {};
    var d = new Date();
    d.setHours(0, 0, 0, 0);

    vm.range = {
        startDate: d,
        endDate: new Date()
    };

    vm.openCalendar = function (e, date) {
        vm.open[date] = !vm.open[date];
        e.preventDefault();
        e.stopPropagation();
        vm.open[date] = true;
    };
    
    vm.exportExcel = function () {
     var exportColumnHeaders = uiGridExporterService.getColumnHeaders(vm.gridApi.grid, uiGridExporterConstants.ALL);
    var exportData = uiGridExporterService.getData(vm.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
    var docDefinition = uiGridExporterService.prepareAsPdf(vm.gridApi.grid, exportColumnHeaders, exportData);
    var tableData = docDefinition.content[0].table.body;
   
   // vm.excelData = JSON.parse(angular.toJson(vm.reportsGrid.data));
    exportFactory.getExcel(tableData, 'DNCList_' +moment(new Date().getTime()).format('YYYY/MM/DD HH:mm:ss') + '.xlsx');
  };
   vm.exportPDF = function () {
    var exportColumnHeaders = uiGridExporterService.getColumnHeaders(vm.gridApi.grid, uiGridExporterConstants.ALL);
    var exportData = uiGridExporterService.getData(vm.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
    var docDefinition = uiGridExporterService.prepareAsPdf(vm.gridApi.grid, exportColumnHeaders, exportData);
    if (uiGridExporterService.isIE() || (navigator.appVersion && navigator.appVersion.indexOf("Edge") !== -1)) {
      uiGridExporterService.downloadPDF("DNCList.pdf", docDefinition);
    } else {
      pdfMake.createPdf(docDefinition).download("DNCList.pdf");
    }
  };

    $scope.dncSearchGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [
            // {
            //     name: 'S.No',
            //     enableSorting: false,
            //     cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            // },
            // { name: 'Campaign Group', field: 'CampaignGroup' },
            {
                name: 'Mobile No',
                field: 'DNCVALUE'
            },
            {
                name:'SourceType',
                field:'SourceType'
            },
            {
                name:'FileName',
                field:'OriginalFileName'
            },
            {
                name:'Comment',
                field:'Comment'
            },
            {
                name:'Added Date',
                field:'StartDate'
            },
            
        ]
    };

    $scope.SearchDNC = function () {
        if ($scope.dncsearchmobile != "" && $scope.dncsearchmobile != null && $scope.dncsearchmobile != undefined) {
            campaignFactory.SearchDNCContact($scope.dncsearchmobile).then(function (data) {
                //


                if (data.data != null) {
                   
                    
                  //  $scope.dncSearchedData = JSON.parse(data.data);
                    $scope.dncSearchGrid.data = data.data;
                    if(!$scope.dncSearchGrid.data.length){
                        toaster.pop({
                            type: "error",
                            body: "No data available"
                          });                        
                    }
                    $scope.isshowgrid = true;
                  //  $scope.dncsearchmobile = '';

                } else {
                    $scope.isshowgrid = false;
                    toaster.pop({
                        type: "error",
                        body: "Error while fecting data",
                        bodyOutputType: 'trustedHtml'
                    });
                  //  $scope.dncSearchedData = '';
                    $scope.dncSearchGrid.data = '';
                }
            });
        } else {
            toaster.pop({
                type: "error",
                body: "Mobile no should not be empty",
                bodyOutputType: 'trustedHtml'
            });
        }

    }
  
    $scope.clearSearch = function () {
        appFactory.ShowLoader();
        $timeout(function () {
            appFactory.HideLoader();
        }, 300)
        $scope.isshowgrid = false;
        $scope.dncSearchedData = null;
        $scope.dncSearchGrid.data = [];
        $scope.dncsearchmobile = '';
    }
    vm.onSearchContactGrid = function () {

        if (!validation()) {
            return;
        }
        getallcontactdata();
    };
    vm.onSearchContactGrid();

    function validation() {
        var isValid = true;

        if (vm.range.startDate == undefined || !vm.range.startDate) {
            toaster.pop({
                type: "error",
                body: "Please enter valid Start date time"
            });
            isValid = false;
        }
        if (vm.range.endDate == undefined || !vm.range.endDate) {
            toaster.pop({
                type: "error",
                body: "Please enter valid End date time"
            });
            isValid = false;
        }
        var errMsg = appFactory.validateReportDates(vm.range.startDate, vm.range.endDate);
        if (errMsg) {
            toaster.pop({
                type: "error",
                body: errMsg
            });
            return false;
        }

        return isValid;
    };

    function getallcontactdata() {
        vm.GetAllContactData = {};
        vm.GetAllContactData.fromDate = moment(vm.range.startDate).format('YYYY-MM-DD HH:mm:ss');
        vm.GetAllContactData.toDate = moment(vm.range.endDate).format('YYYY-MM-DD HH:mm:ss');
        appFactory.ShowLoader();
        campaignFactory.GetAllContactData(vm.GetAllContactData).then(
            function success(data) {
                appFactory.HideLoader();
                vm.dncContactGrid.data = data.data;
                if (!vm.dncContactGrid.data.length) {
                   // toaster.pop({
                      //  type: "error",
                      //  body: "No data available"
                    //});
                }
            },
            function error(data) {
                appFactory.HideLoader();
                toaster.pop({
                    type: "error",
                    body: "Error while retrieving AllContactData"
                });
            }
        );
    };


    $scope.showEdit = function (getRowData) {
        $scope.MobileNoEdit = {};
        $scope.oldMobileno = getRowData.DNCVALUE;
        $scope.MobileNoEdit.Mobileno = getRowData.DNCVALUE;
        $scope.form.mobilenoModify.Mobileno.$error.validationerror=false;
        $scope.EditView = true;
        $('#modifydnccontact').modal('show');
    }

    $scope.UpdateMobileno = function () {

        $scope.mobilenoUpdate = {};
        $scope.mobilenoUpdate.mobileNo = $scope.MobileNoEdit.Mobileno;
        var postdata = {
            oldvalue: $scope.oldMobileno,
            newvalue: $scope.MobileNoEdit.Mobileno
        };
        campaignFactory.UpdateMobileno(postdata).then(function (data) {
            if (data.data == "Success") {
                getallcontactdata();
                $('#modifydnccontact').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "modified successfully"
                });
            } else {
                getallcontactdata();
                toaster.pop({
                    type: "error",
                    body: "Error while Modifying Mobile No"
                });

            }
        });


    }

    $scope.GetDNCCount=function(){
        $scope.TotalDNCCount=0;
        campaignFactory.GetDNCCount().then(function(data){
            $scope.TotalDNCCount=data.data;
        })


    }
    $scope.GetDNCCount();
    $scope.showDelete = function (getRowData) {
        $scope.Mobileno = getRowData.DNCVALUE;
        $scope.EditView = true;
        $('#confirmModal').modal('show');
    }

    $scope.Delete = function () {
        $scope.MobileNoDelete = {};
        $scope.MobileNoDelete.mobileNo = $scope.Mobileno;
        campaignFactory.DeleteMobileno($scope.MobileNoDelete.mobileNo).then(function (data) {
           
            if (data.data == "Success") {
                getallcontactdata();
                $scope.GetDNCCount();
                $('#confirmModal').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "The Mobile No has been deleted successfully"
                });

            } else {
                getallcontactdata();
            }
        });

    }



    $scope.DownloadDncTemplate = function (downPath) {
        $scope.csv_link = downPath;
    }
    // ***** End Private Methods *****//

    // ***** Validation Methods *****//
    var IsValidFile = function () {
        $scope.isValid = '';
        if ($scope.dncvar == undefined || $scope.dncvar == null) {
            toaster.pop({
                type: "error",
                body: "Please select valid option",
                bodyOutputType: 'trustedHtml'
            });
            $scope.isValid = false;
        } else if (!$scope.dnccomments) {
            toaster.pop({
                type: "error",
                body: "Please enter comments",
                bodyOutputType: 'trustedHtml'
            });
        } else if ($scope.dncuploadfile == undefined || $scope.dncuploadfile == null || $scope.dncuploadfile.name == null) {
            toaster.pop({
                type: "error",
                body: "Please select valid file to upload",
                bodyOutputType: 'trustedHtml'
            });
            $scope.isValid = false;
        } else if ($scope.dncuploadfile.name != null) {
            // var validFormats = ['xls', 'xlsx','csv','txt'];
            var validFormats = ['csv'];
            var output = $filter('validfile')($scope.dncuploadfile.name, validFormats);
            if (output == false) {
                toaster.pop({
                    type: "error",
                    body: "File format should be csv",
                    bodyOutputType: 'trustedHtml'
                });
                $scope.isValid = false;
            } else {
                $scope.isValid = true;
            }
        } else {
            $scope.isValid = true;
        }
    }

}]);