app.controller('UssdThresholdController', ['$scope', '$rootScope', 'masterDataFactory', 'toaster', function ($scope, $rootScope, masterDataFactory, toaster) {
    $scope.Formlist = {};
    $scope.thresholdedit = {};
    $scope.form = {};
    // $scope.SelecedAppUse='';
    $scope.gridUssdOptions = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
                name: 'Department',
                field: 'DepartmentName'
            },
            {
                name: 'ApplicationUse',
                field: 'ApplicationUse'
            },

            {
                name: 'ThresholdLimitDaily',
                field: 'ThresholdLimitDaily'
            },
            {
                name: 'ThresholdLimitMonthly',
                field: 'ThresholdLimitMonthly'
            },
            {
                name: 'ThresholdLimitYearly',
                field: 'ThresholdLimitYearly'
            },

            //  { name: 'Options', enableFiltering: false, width: '10%', cellTemplate: ' <a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity.UserId)"><span class="fa fa-trash-o"></span></a>'}
            {
                name: 'Options',
                enableSorting: false,
                enableFiltering: false,
                width: '10%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
            }
        ],
    };

    var ThresholdType = 2;
    $scope.GetThreshold = function (ThresholdType) {

        masterDataFactory.GetThreshold(ThresholdType).then(
            function success(data) {

                console.log("editUSSD", data);
                $scope.gridUssdOptions.data = data.data;
            },
            function error(data) {

            }
        )
    }
    $scope.GetThreshold(ThresholdType);
    //$scope.gridUssdOptions.data = $scope.UssdDataDetail;
    //DropDown values
    $scope.GetApplicationName = function () {

        masterDataFactory.GetApplicationName().then(
            function success(data) {

                // console.log("editSMS",data);
                $scope.ApplicationUseDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }

    $scope.GetApplicationName();
    $scope.GetDepartmentName = function () {

        masterDataFactory.GetDepartmentName().then(
            function success(data) {

                // console.log("editSMS",data);
                $scope.DepartmentDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }
    $scope.GetDepartmentName();

    //  $scope.DepartmentValue = ["R001", "R002", "R003", "R004", "R005"];
    // $scope.ApplicationUseDropDownValue = ["SMS", "SMS1", "SMS2", "SMS3", "SMS4"];
    // console.log("hello",ApplicationUseDropDownValue);
    $scope.ThresholdLimit = [100, 200, 300, 400, 500];
    $scope.FrequencyType = ["Daily", "Monthly", "Yearly"];

    $scope.showAdd = function () {
        $scope.Formlist = {};
        $scope.form.ussdthreshold.$setPristine();
        $('#AddUssdCode').modal('show');
    }



    $scope.CreateUSSDCodes = function () {

        $scope.ThresholdAdd = {};

        $scope.ThresholdAdd.ThresholdType = 2;
        $scope.ThresholdAdd.UpdatedBy = 'Admin';

        $scope.ThresholdAdd.DepartmentID = $scope.Formlist.SelecedDep;
        $scope.ThresholdAdd.ApplicationID = $scope.Formlist.SelecedAppUse;
        $scope.ThresholdAdd.ThresholdLimitDaily = $scope.Formlist.ThresholdLimitDaily;
        $scope.ThresholdAdd.ThresholdLimitMonthly = $scope.Formlist.ThresholdLimitMonthly;
        $scope.ThresholdAdd.ThresholdLimitYearly = $scope.Formlist.ThresholdLimitYearly;

        masterDataFactory.CreateThreshold($scope.ThresholdAdd).then(function (data) {



            if (data.data == "Success") {
                $scope.GetThreshold(ThresholdType);

                $('#AddUssdCode').modal('hide');
                $scope.Formlist = {};
                $scope.form.ussdthreshold.$setPristine();
                toaster.pop({
                    type: "Success",
                    body: "USSD threshold limit added successfully"
                });

            } else {
                $scope.GetThreshold(ThresholdType);
                toaster.pop({
                    type: "error",
                    body: "Error while adding USSD Threshold limit"
                });

            }
        });

    }
    $scope.showEdit = function (getrowdata) {
        //$scope.thresholdedit = {};
        $scope.thresholdedit.departmentName = getrowdata.DepartmentID;
        console.log("edit", getrowdata);
        $scope.thresholdedit.ApplicationUse = getrowdata.ApplicationID;
        $scope.thresholdedit.thresholdLimitDaily = getrowdata.ThresholdLimitDaily;
        $scope.thresholdedit.thresholdLimitYearly = getrowdata.ThresholdLimitYearly;
        $scope.thresholdedit.thresholdLimitMonthly = getrowdata.ThresholdLimitMonthly;
        $scope.thresholdedit.ThresholdId = getrowdata.ThresholdId;
        $scope.EditView = true;
        $('#modifyUssdCode').modal('show');
    }

    $scope.UpdateUSSDCodes = function () {

        $scope.ThresholdUpdate = {};

        $scope.ThresholdUpdate.ThresholdType = 2;
        $scope.ThresholdUpdate.UpdatedBy = 'Admin';

        //  $scope.ThresholdUpdate.DepartmentID = $scope.thresholdedit.departmentName;
        $scope.ThresholdUpdate.ApplicationID = $scope.thresholdedit.ApplicationUse;
        $scope.ThresholdUpdate.ThresholdLimitDaily = $scope.thresholdedit.thresholdLimitDaily;
        $scope.ThresholdUpdate.ThresholdLimitMonthly = $scope.thresholdedit.thresholdLimitMonthly;
        $scope.ThresholdUpdate.ThresholdLimitYearly = $scope.thresholdedit.thresholdLimitYearly;
        $scope.ThresholdUpdate.ThresholdId = $scope.thresholdedit.ThresholdId;

        masterDataFactory.UpdateThreshold($scope.ThresholdUpdate).then(function (data) {



            if (data.data == "Success") {
                $scope.GetThreshold($scope.ThresholdUpdate.ThresholdType);

                $('#modifyUssdCode').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "USSD threshold limit updated successfully"
                });

            } else {
                $scope.GetThreshold($scope.ThresholdUpdate.ThresholdType);
                toaster.pop({
                    type: "error",
                    body: "Error while updating USSD Threshold limit"
                });

            }
        });

    }

    //Delete functionality
    $scope.showDelete = function (getRowData) {
        //$scope.ussdCodeDelete = {};

        $scope.CodeID = getRowData.ThresholdId;
        $scope.EditView = true;
        $('#confirmModal').modal('show');
    }

    $scope.Delete = function () {
        // $scope.ussdCodeDelete = {};
        var CodeID = $scope.CodeID;
        masterDataFactory.DeleteThreshold(CodeID).then(function (data) {



            if (data.data == "Success") {
                $scope.GetThreshold(ThresholdType);

                $('#confirmModal').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "USSD threshold limit deleted successfully"
                });

            } else {
                $scope.GetThreshold(ThresholdType);
                toaster.pop({
                    type: "error",
                    body: "Error while deleting USSD Threshold limit",
                    toasterId: 1
                });

            }
        });

    }

}]);