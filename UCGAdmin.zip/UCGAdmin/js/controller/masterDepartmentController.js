app.controller('masterDepartmentController', function ($scope, $rootScope, masterDataFactory, toaster) {

    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId;
    //  $rootScope.departmentName = "103";
    $scope.departmentEdit = [];
    $scope.Formlist = {};
    $scope.Formedit = {};
    $scope.form = {};
    //Grid Specification
    $scope.gridDepartment = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
            name: 'S.No',
            width: '10%',
            enableSorting: false,
            enableFiltering: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
        },
        {
            name: 'DepartmentId',
            field: 'ID',
			cellTooltip: true
            //  visible: false
        },
        {
            name: 'DepartmentName',
            field: 'DepartmentName',
			cellTooltip: true
        },
        {
            name: 'DepartmentCode',
            field: 'DepartmentCode',
			cellTooltip: true
        },
        {
            name: 'Options', enableSorting: false,
            enableFiltering: false,
            width: '10%',
            cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
        }
        ],
    };

    //Get Department name
    $scope.GetDepartmentName = function () {

        masterDataFactory.GetDepartmentName().then(
            function success(data) {
                $scope.Departments = data.data;
                // $scope.gridDepartment.data = data.data;
                $scope.withoutdata = _.findWhere($scope.Departments, {
                    DepartmentName: "Generic"
                })

                $scope.Departments = _.without($scope.Departments, $scope.withoutdata)
                $scope.gridDepartment.data = $scope.Departments;
            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while retreiving Department"
                });
            }
        )
    }
    $scope.GetDepartmentName();


    //Add functionality

    $scope.showAdd = function () {
        $scope.DepartmentMaster = {};
        $scope.Formlist = {};
        $scope.form.DepartmentMaster.DepartmentId.$error.validationError = false;
        $scope.form.DepartmentMaster.$setPristine();
        $('#AddDepartment').modal('show');
        document.getElementById("DepartmentMaster").reset();

    }
    $scope.CreateDepartment = function () {
        $scope.form.DepartmentMaster.DepartmentId.$error.validationError = false;
        angular.forEach($scope.gridDepartment.data, function (rowdata) {
            if (rowdata.ID == $scope.Formlist.DepartmentId) {
                $scope.form.DepartmentMaster.DepartmentId.$error.validationError = true;
            }

        });

        if ($scope.form.DepartmentMaster.DepartmentId.$error.validationError == false) {



            $scope.DepartmentAdd = {};

            $scope.DepartmentAdd.CreatedBy = userObj.SSOID;
            $scope.DepartmentAdd.DepartmentName = $scope.Formlist.DepartmentName;
            $scope.DepartmentAdd.DepartmentCode = $scope.Formlist.DepartmentCode;
            $scope.DepartmentAdd.DepartmentId = $scope.Formlist.DepartmentId;

            masterDataFactory.CreateDepartment($scope.DepartmentAdd).then(function (data) {



                if (data.data == "Success") {
                    $scope.GetDepartmentName();
                    $scope.Formlist = {};
                    $('#AddDepartment').modal('hide');
                    $scope.form.DepartmentMaster.$setPristine();

                    toaster.pop({
                        type: "Success",
                        body: "Department Created successfully"
                    });

                } else {
                    $scope.GetDepartmentName();
                    toaster.pop({
                        type: "error",
                        body: "Error while Adding Department"
                    });

                }
            });
        }

    }
    //update department
    $scope.showEdit = function (getRowData) {
        $scope.departmentEdit = {};

        $scope.departmentEdit.DepartmentName = getRowData.DepartmentName;
        $scope.departmentEdit.DepartmentCode = getRowData.DepartmentCode;
        $scope.departmentEdit.ID = getRowData.ID;
        $scope.ValidationCheck = getRowData.ID;
        $scope.departmentEdit.DepartmentId = getRowData.depid;
        $scope.form.DepartmentMaster.DepartmentId.$error.validationError = false;
        $scope.EditView = true;
        $('#modifyDepartment').modal('show');
    }



    $scope.UpdateDepartment = function () {

        $scope.form.DepartmentMaster.DepartmentId.$error.validationError = false;
        if ($scope.ValidationCheck != $scope.departmentEdit.ID) {
            angular.forEach($scope.gridDepartment.data, function (rowdata) {
                if (rowdata.ID == $scope.departmentEdit.ID) {
                    $scope.form.DepartmentMaster.DepartmentId.$error.validationError = true;
                }

            });
        }
        if ($scope.form.DepartmentMaster.DepartmentId.$error.validationError == false) {
            $scope.DepartmentUpdate = {};
            $scope.DepartmentUpdate.ModifiedBy = userObj.SSOID;
            $scope.DepartmentUpdate.DepartmentID = $scope.departmentEdit.ID;
            $scope.DepartmentUpdate.DepartmentName = $scope.departmentEdit.DepartmentName;
            $scope.DepartmentUpdate.DepartmentCode = $scope.departmentEdit.DepartmentCode;
            $scope.DepartmentUpdate.DepID = $scope.departmentEdit.DepartmentId;

            masterDataFactory.UpdateDepartment($scope.DepartmentUpdate).then(function (data) {



                if (data.data == "Success") {
                    $scope.GetDepartmentName();

                    $('#modifyDepartment').modal('hide');
                    toaster.pop({
                        type: "Success",
                        body: "Department updated successfully"
                    });

                } else {
                    $scope.GetDepartmentName();
                    toaster.pop({
                        type: "error",
                        body: "Error while creating updating department"
                    });

                }
            });
        }

    }
    //Delete Department
    $scope.showDelete = function (getRowData) {

        $scope.CodeID = getRowData.ID;
        $scope.EditView = true;
        $('#confirmModal').modal('show');
    }


    $scope.Delete = function () {
        $scope.DepartmentDelete = {};
        $scope.DepartmentDelete.DepartmentID = $scope.CodeID;
        $scope.DepartmentDelete.ModifiedBy = userObj.SSOID;
        masterDataFactory.DeleteDepartment($scope.DepartmentDelete).then(function (data) {



            if (data.data == "Success") {
                $scope.GetDepartmentName();
                $('#confirmModal').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "Department Deleted successfully"
                });


            } else {
                $scope.GetDepartmentName();
                toaster.pop({
                    type: "error",
                    body: "Error while creating updating department"
                });
            }
        });

    }



});