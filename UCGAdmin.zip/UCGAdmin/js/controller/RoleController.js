app.controller('RoleController', ['$scope', '$rootScope', 'roleFactory', 'uiGridConstants', function ($scope, $rootScope, roleFactory, uiGridConstants) {

    // $scope.roleData = [
    //     { 'RoleID': 'R001', 'RoleName': 'User Management', 'IsActive': true },
    //     { 'RoleID': 'R002', 'RoleName': 'Campaign Management', 'IsActive': true },
    //     { 'RoleID': 'R003', 'RoleName': 'Survey Management', 'IsActive': true },
    //     { 'RoleID': 'R004', 'RoleName': 'Case Management', 'IsActive': true },
    //     { 'RoleID': 'R005', 'RoleName': 'Missed Call Management', 'IsActive': true },
    //     { 'RoleID': 'R006', 'RoleName': 'USSD Management', 'IsActive': true },
    //     { 'RoleID': 'R007', 'RoleName': 'SMS Management', 'IsActive': true },
    //     { 'RoleID': 'R008', 'RoleName': 'IVR Call Management', 'IsActive': true },
    //     { 'RoleID': 'R009', 'RoleName': 'Finesse Agent Desktop', 'IsActive': true },
    //     { 'RoleID': 'R010', 'RoleName': 'Monitoring', 'IsActive': true },
    //     { 'RoleID': 'R011', 'RoleName': 'Master Data', 'IsActive': true },
    // ];

    $scope.highlightFilteredHeader = function (row, rowRenderIndex, col, colRenderIndex) {
        if (col.filters[0].term) {
            return 'header-filtered';
        } else {
            return '';
        }
    };

    $scope.RolesGrid = {
        enableColumnResizing: true,
        enableFiltering: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                enableFiltering: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            // { name: 'Role Id', field: 'ID' },
            {
                name: 'Role ID',
                field: 'RoleId',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Role Name',
                field: 'RoleName',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'IsActive',
                field: 'IsActive',
                filter: {
                    term: 'true',
                    type: uiGridConstants.filter.SELECT,
                    selectOptions: [{
                        value: 'true',
                        label: 'true'
                    }, {
                        value: 'false',
                        label: 'false'
                    }]
                }
            }
            // { name: 'Options', width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.showView(row.entity)"><span class="fa fa-eye"></span></a> | <a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity.UserId)"><span class="fa fa-trash-o"></span></a>' },
        ]
    };

    // $scope.RolesGrid.data = $scope.roleData;

    $scope.GetAllRoles = function () {

        roleFactory.GetAllRoles().then(
            function success(data) {

                $scope.RolesGrid.data = data.data;
            },
            function error(data) {

            }
        )
    }

    $scope.GetAllRoles();

}]);