app.controller('SurveyApprovalController', ['$scope', '$rootScope', '$q', '$timeout', '$filter', 'toaster', 'surveyCampFactory', 'surveyFactory', '$compile', '_', 'appFactory', function ($scope, $rootScope, $q, $timeout, $filter, toaster, surveyCampFactory, surveyFactory, $compile, _, appFactory) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
   $rootScope.departmentName = userObj.departmentId;
    $scope.iseditable=false;
  //  $rootScope.departmentName = "103";
    // Global variable declarations
    $scope.Pendingresultdata = [];
    $('.modal-dialog .card').resizable().draggable();
    //$scope.permissions = appFactory.permissions[appConst.MENUS.RCHK_MGMT.RCHK_APVL];
    var newdate = new Date();
    newdate.setDate(newdate.getDate() - 30);
    $scope.ms = {
        startDate: newdate,
        // startDate: setImmediate(, 
        endDate: new Date()
    }

  
    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        e.preventDefault();
        e.stopPropagation();
        $scope.open = {};
        $scope.open[date] = true;
    };

    $scope.FilterData = function () {
        $scope.FilterDates = {};
        $scope.FilterDates.FromDate = moment($scope.ms.startDate).format('YYYY-MM-DD  00:00:00');
        $scope.FilterDates.EndDate = moment($scope.ms.endDate).format('YYYY-MM-DD 23:59:59');
        surveyCampFactory.GetAllSurveyApprovalFilter($scope.FilterDates).then(function (data) {
            if (1) {
                $scope.Pendingresultdata = data.data;
            } else {
                $scope.Pendingresultdata = _.filter(data.data, function (item) {
                    return item.depid == $rootScope.departmentName;
                });
            }
            $scope.Pendingresultdata = $scope.Pendingresultdata;
            $scope.GetAlldata($scope.currentwindow);
        });


        // $scope.FilterDates.FromDate= moment($scope.ms.startDate).add(-3, 'days').format('YYYY-MM-DD HH:mm:ss');
        //$scope.FilterDates.EndDate =moment($scope.ms.endDate).add(30, 'days').format('YYYY-MM-DD HH:mm:ss');
    }

    $scope.FilterData();

    // ***** Start of Campaign Index funcationality ***** //
    $scope.searchIndex = "";
    $scope.currentwindow = 1;
    $scope.PendingContactDetailsGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '6%',
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Id',
                field: 'Id',
                visible: false
            },
            {
                name: 'Department',
                field: 'DepartmentName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Campaign',
                field: 'DisplayCampaignName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Sample Name',
                field: 'SampleName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'QuestionSet Name',
                field: 'QuestionSetName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Question Type',
                field: 'QuestionType',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Language',
                field: 'Language',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Sample Name',
                field: 'SampleName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'QuestionSet Name',
                field: 'QuestionSetName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Question Type',
                field: 'QuestionType',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Language',
                field: 'Language',
                isSearchable: true,
                cellTooltip: true
            },
            // {
            //     name: 'Campaign CreatedBy',
            //     field: 'UpdatedBy',
            //     cellTooltip: true
            // },

            {
                name: 'Campaign CreatedBy',
                field: 'CreatedBy',
                cellTooltip: true
            },

             {
                 name: 'CreatedTime',
                field: 'CreatedTime',
                 cellTooltip: true,
                 cellFilter: 'date:\'dd/MM/yyyy HH:mm\''
             },
            {
                name: 'Action',
                enableSorting: false,
                width: '10%',
                cellTemplate: '<a ng-click="grid.appScope.getdatabyid(row.entity)"><span class="fa fa-eye"></span></a>'
            },
        ]
    };

    $scope.onTypeSearchValues = function () {
        var filteredData = appFactory.getDataBySearchIndex($scope.searchIndex);
        $scope.PendingContactDetailsGrid.data = filteredData;
    };

    var getSearchableFields = function () {
        appFactory.getSearchableFields($scope.PendingContactDetailsGrid);
    };
    $scope.PendingContactDetailsGrid.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
    };
    $scope.Approve = function (row) {
        if (row.Comments) {
            var pendingdata = {
                id: row.Id,
                surveyID:row.surveyID,
                approvedBy: userObj.SSOID,
                Comments: row.Comments
            };
            surveyCampFactory.UpdateApprovalStatus(pendingdata).then(function (data) {
                $scope.FilterData();
                $('#viewcalltree').modal('hide');
                appFactory.showSuccess('Survey approved successfully');

            });
        } else
            appFactory.showWarning('Please enter comments');
    }
    $scope.Reject = function (row) {
        if (row.Comments) {
            var pendingdata = {
                id: row.Id,
                approvedBy: userObj.SSOID,
                Comments: row.Comments
            };
            surveyCampFactory.UpdateRejectStatus(pendingdata).then(function (data) {
                $scope.FilterData();
                $('#viewcalltree').modal('hide');
                appFactory.showSuccess('Survey rejected successfully');
            });
        } else
            appFactory.showWarning('Please enter comments');
    }

    $scope.refresh = function () {
        $scope.searchIndex = "";
        $scope.FilterData();
    }

    // $scope.GetAllSurveyApproval = function () {
    //     surveyCampFactory.GetAllSurveyApproval().then(function (data) {
    //         if ($scope.isSuperIdmin) {
    //             $scope.Pendingresultdata = data.data;
    //         } else {
    //             $scope.Pendingresultdata = _.filter(data.data, function (item) {
    //                 return item.depid == $rootScope.departmentName;
    //             });
    //         }
    //         $scope.Pendingresultdata = $scope.Pendingresultdata;
    //         $scope.GetAlldata($scope.currentwindow);
    //     });
    // }

    $scope.selectedtab = 0;

    $scope.getdatabyid = function (item) {
        $scope.selectedtab = 0;
        surveyFactory.GetAllQuestionSetbyId(item.QuestiontypeID).then(function (data) {
            var result = data.data;
            $scope.item = result[0];
            $scope.item.Id = item.Id;
            $scope.item.Language = item.Language;
            $scope.item.IsAutomatedIVR = item.IsAutomatedIVR;
            $scope.item.IsManualCalling = item.IsManualCalling;
            $scope.item.IsEmailSurvey = item.IsEmailSurvey;
            $scope.item.SampleName = item.SampleName;
            $scope.item.SMSIntimateText = item.SMSIntimateText;
            $scope.item.SMSAcknowledgeText = item.SMSAcknowledgeText;
            $scope.item.TotalRecords = item.TotalRecords;
            $scope.item.DayIntervalBetweenEmailAttempts = item.DayIntervalBetweenEmailAttempts;
            $scope.item.HoursIntervalBetweenEmailAttempts = item.HoursIntervalBetweenEmailAttempts;
            $scope.item.DayIntervalBetweenManualAttempts = item.DayIntervalBetweenManualAttempts;
            $scope.item.NoOfManualCallCount = item.NoOfManualCallCount;
            $scope.item.Comments = item.Comments;
            $scope.item.ActionTakenDateTime = item.ActionTakenDateTime;
            $scope.item.ActionTakenby = item.ActionTakenby;
            $scope.item.CampaignCreatedDate = moment(item.CreatedTime).format('DD/MM/YYYY HH:mm');
            $scope.item.IsApproved = item.IsApproved;
            $scope.item.IsRejected = item.IsRejected;
            $scope.item.surveyID=item.surveyID;

            $scope.item.IsLCMEndDayReached =item.IsLCMEndDayReached;
            $scope.item.SurveyActive =item.SurveyActive;
            $scope.Expiredflag=false;
            if(item.IsLCMEndDayReached || item.SurveyActive ){
                $scope.Expiredflag=true;
            }
           

            setTimeout(function () {
                changeCallFlow(result[0]);
                //CallTree.saveCallTree();
            }, 500);
            if ($scope.item.PhraseType == "WAV") {
                $scope.item.ThanksMessage = $scope.item.ThanksMessage.split(':')[1];
                $scope.item.WelcomeMessage = $scope.item.WelcomeMessage.split(':')[1];
            }
            $scope.item.SurveyEndTime = moment(item.SurveyEndTime).format('DD/MM/YYYY HH:mm');
            $scope.item.SurveyStartTime = moment(item.SurveyStartTime).format('DD/MM/YYYY HH:mm');
            $scope.item.CampaignName = item.CampaignName;
            $scope.Qinfo = {
                TotalQuestions: $scope.item.NoOfQuestions
            };
            $scope.item.CreatedBy = item.CreatedBy;
            $scope.item.UpdatedTime = moment(item.CreatedTime).format('DD/MM/YYYY HH:mm');

            surveyFactory.GetLCMCampaignInfo(item.CampaignName).then(function (lcmdata) {
                $('.modal-dialog').resizable().draggable({
                    containment: ".page-content"
                });
                $('.modal').on('hidden.bs.modal', function (e) {
                    $('.modal-dialog .card').css({ top: 0, left: 0 });
                    $scope.validateOnSubmit    = false;
                })

                if (lcmdata.data.CreateCampaign) {
                    $scope.item.CampaignStartTime = moment(lcmdata.data.CreateCampaign.StartDate).format('DD/MM/YYYY HH:mm');
                    $scope.item.CampaignEndTime = moment(lcmdata.data.CreateCampaign.EndDate).format('DD/MM/YYYY HH:mm');
                }
                var endDate = moment(new Date());
                var dateDiffMin = endDate.diff($scope.item.CampaignEndTime, 'days');
                if ($scope.showpending) {
                    var currentDate = moment();
                    var endDateObj = moment(item.SurveyEndTime);
                    var endDateObjcamp=moment(lcmdata.data.CreateCampaign.EndDate);
                    if (endDateObj.diff(currentDate) < 0) {
                        appFactory.showWarning('Survey date expired');
                    } else if(endDateObjcamp.diff(currentDate)<0){
                        appFactory.showWarning('campaign date expired');
                    }else{
                        $('#viewcalltree').modal('show');
                    }
                } else
          
                    $('#viewcalltree').modal('show');
            });
        });
    }
    $scope.CampExp =false;
   
    $scope.getExpiredData=function(){
        $scope.GetAlldata( $scope.currentwindow);
    }
    $scope.GetAlldata = function (type) {
        $scope.showpending = false;
        $scope.showapproved = false;
        $scope.showrejected = false;
        
        // if(!$scope.CampExp && $scope.SurveyExp){
        //     var pendingdata = _.filter($scope.Pendingresultdata, function (item) {
        //         return (item.IsApproved == null && item.IsRejected == null  && item.SurveyActive!=0  ) || (item.IsApproved == false && item.IsRejected == false  && item.SurveyActive!=0);
        //     });
           
        // } else if($scope.CampExp && !$scope.SurveyExp){
        //     var pendingdata = _.filter($scope.Pendingresultdata, function (item) {
        //         return (item.IsApproved == null && item.IsRejected == null && item.IsLCMEndDayReached) || (item.IsApproved == false && item.IsRejected == false && item.IsLCMEndDayReached);
        //     });
           
        // }
        // else if($scope.CampExp && $scope.SurveyExp){
        //     var pendingdata = _.filter($scope.Pendingresultdata, function (item) {
        //         return (item.IsApproved == null && item.IsRejected == null) || (item.IsApproved == false && item.IsRejected == false);
        //     });
           
        // }else{
        //     var pendingdata = _.filter($scope.Pendingresultdata, function (item) {
        //         return (item.IsApproved == null && item.IsRejected == null && !item.IsLCMEndDayReached && item.SurveyActive==0  ) || (item.IsApproved == false && item.IsRejected == false && !item.IsLCMEndDayReached && item.SurveyActive==0);
        //     });
           
        // }

        if($scope.CampExp){
            var pendingdata = _.filter($scope.Pendingresultdata, function (item) {
                return (item.IsApproved == null && item.IsRejected == null) || (item.IsApproved == false && item.IsRejected == false);
            });
           
        } else {
            var pendingdata = _.filter($scope.Pendingresultdata, function (item) {
                return (item.IsApproved == null && item.IsRejected == null && !item.IsLCMEndDayReached && item.SurveyActive==0  ) || (item.IsApproved == false && item.IsRejected == false && !item.IsLCMEndDayReached && item.SurveyActive==0);
            });
           
        }

        var approveddata = _.filter($scope.Pendingresultdata, function (item) {
            return (item.IsApproved == true);
        });
        
        var rejectdata = _.filter($scope.Pendingresultdata, function (item) {
            return (item.IsRejected == true);
        });

       
        $scope.pendingdatacount = pendingdata.length;

       
        $scope.approveddatacount = approveddata.length;


        $scope.rejectdatacount = rejectdata.length;
        var data = [];
        if (type == 1) {
            data = pendingdata;
            $scope.showpending = true;
        } else if (type == 2) {
            data = approveddata;
            $scope.showapproved = true;
        } else if (type == 3) {
            data = rejectdata;
            $scope.showrejected = true;
        }
        $scope.PendingContactDetailsGrid.data = data;
        $scope.gridApi.grid.modifyRows(data);
        getSearchableFields();
        $scope.gridApi.core.refresh();
        $scope.currentwindow = type;
    }


    // $scope.changeCallFlow = function (currFlow) {
    //     flowDataStore = [];
    //     $('#tab-1').remove();
    //     if (currFlow.QuestionSetName != "--Select--") {
    //         if (currFlow.JSONData != '') {
    //             flowDataStore.push({
    //                 callTree: {},
    //                 FlowName: currFlow.QuestionSetName
    //             });
    //             flowDataStore[0].callTree = $.parseJSON(currFlow.JSONData);
    //         }
    //         $("div#tabs").append("<div class='calltreeContainer container' style='background: #fff; width: 100%!important;' id='tab-1'/>");
    //         if (currFlow.JSONData != '')
    //             CallTree.loadMultipleFlows();
    //         CallTree.createContainers(currFlow);
    //     }
    //     // triggerpageevent(0);
    // }

    $scope.Edit = function (rowdata) {
        $scope.ismainactive = false;
        $scope.item = rowdata;
        $timeout(function () {
            $scope.redraw = false;
            changeCallFlow(rowdata);
        }, 500);
    }


    $scope.showrowdata = function (type) {
        $scope.showobjective = false;
        if (type == 1) {
            $scope.QuestionsetInfo = {
                questiontypeId: "1",
                IsActive: "true",
                phraseType: "TTS",
                inputMode: "VOICE"
            };
            $scope.showobjective = true;
        } else if (type == 2) {
            $scope.QuestionsetInfo.inputMode = "";
            $scope.QuestionsetInfo.phraseType = "";

        } else if (type == 3) {
            $scope.QuestionsetInfo.inputMode = "";
            $scope.QuestionsetInfo.phraseType = "";
        }

    }

    $scope.changeMode = function (type) {
        if (type == "Thanks") {
            var r = confirm("Do you really want to add thanks node");
            if (r == true) {
                //CallTree.deleteNode($(event.currentTarget).parent());
            }
        }

    }

    $scope.Redesign = function (event) {
        CallTree.getquestionoptioncount();
    }


    $scope.ZoomIn = function () {
        $scope.zoom = $scope.zoom + 0.3;
        var transformOrigin = [0.5, 0.5];

        var el = jsPlumb.getContainer();
        var p = ["webkit", "moz", "ms", "o"],
            s = "scale(" + $scope.zoom + ")",
            oString = (transformOrigin[0] * 100) + "% " + (transformOrigin[1] * 100) + "%";

        for (var i = 0; i < p.length; i++) {
            el.style[p[i] + "Transform"] = s;
            el.style[p[i] + "TransformOrigin"] = oString;
        }

        el.style["transform"] = s;
        el.style["transformOrigin"] = oString;


        ZoomProcess($scope.zoom);
        jsPlumb.setZoom($scope.zoom);
        $timeout(function () {
            triggerpageevent(1);
            jsPlumb.repaintEverything();
        }, 1000)
    }

    $scope.ZoomOut = function () {
        if ($scope.zoom > 0)
            $scope.zoom = $scope.zoom - 0.3;
        if ($scope.zoom > 0) {
            var transformOrigin = [0.5, 0.5];
            var el = jsPlumb.getContainer();
            var p = ["webkit", "moz", "ms", "o"],
                s = "scale(" + $scope.zoom + ")",
                oString = (transformOrigin[0] * 100) + "% " + (transformOrigin[1] * 100) + "%";
            for (var i = 0; i < p.length; i++) {
                el.style[p[i] + "Transform"] = s;
                el.style[p[i] + "TransformOrigin"] = oString;
            }
            el.style["transform"] = s;
            el.style["transformOrigin"] = oString;
            $timeout(function () {
                //ZoomProcess($scope.zoom)
                triggerpageevent(1);
                jsPlumb.repaintEverything();
            }, 1000)
            jsPlumb.setZoom($scope.zoom);
        }
    }

    $scope.canceledit = function () {
        if ($scope.item.QuestionType == "Objective")
            $('#Fields-RuleNewField').modal('hide');
        else
            $('#Fields-RuleNewField1').modal('hide');
        // if ($scope.Config.ObjQuestion.ID == undefined)
        //     CallTree.deleteNodeManual(current_config_nodeID[0].id);
        // else
        //     $scope.UpdateNodedata('', '');
    }

    $scope.ismainactive = true;

    $scope.ConfirmNodeType = function (type) {
        $('#confirmtype').modal('hide');
        $('#Fields-RuleNewField1').modal('show');
        createObjectivequestion();
    }
    $scope.cancelconfirm = function () {
        $scope.currentquestiontype = 'Subjective';
        $('#confirmtype').modal('hide');

    }

    $scope.addnode = function (event) {
        $scope.ThanksType = "Question";
        current_config_nodeID = $(event.currentTarget).parent(); //angular bridge
        var countcheck = getChildNode(current_config_nodeID[0].id);
        // if (current_config_nodeID[0].id != 'StartFlowNode' && countcheck.length >= 1) {
        //     toaster.pop({
        //         type: "warning",
        //         body: "Only one question allowed for option ",
        //         bodyOutputType: 'trustedHtml'
        //     });
        // } else
        $scope.currentquestiontype = 'Subjective';
        if ($scope.item.QuestionType == "Mixed") {
            $('#confirmtype').modal('show');
        } else if ($scope.item.QuestionType == "Subjective") {
            $('#Fields-RuleNewField1').modal('show');
            createObjectivequestion();
        } else {
            $('#Fields-RuleNewField').modal('show');
            createObjectivequestion();
        }

    }

    $scope.editnode = function (event) {
        $scope.showaddoptions = false;
        current_config_nodeID = $(event.currentTarget).parent(); //angular bridge
        $scope.optionname = "";
        $scope.OptionVarients = "";
        $scope.optionDTMF = "";
        angular.element(document.querySelector('#loader')).removeClass('hide');

        if ($scope.item.QuestionType == "Objective")
            $('#Fields-RuleNewField').modal('show');
        else
            $('#Fields-RuleNewField1').modal('show');
        var scope = angular.element(document.getElementById('addQuestions')).scope();
        $('#moduleConfigurationDiv').css('width', '94%');
        var node = current_config_nodeID,
            moduleConfigurationDiv = $('#moduleConfigurationDiv');
        var featureName = node.attr('data-node-name');
        var parsingdata = node.attr('data-node-json');
        var nodeattributes = {}
        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '') {
            nodeattributes = $.parseJSON(parsingdata);
            $scope.ThanksType = nodeattributes.NodeType;
        }
        if ($scope.item.QuestionType != "Objective")
            $scope.currentquestiontype = nodeattributes.InputType;

        $timeout(function () {
            // $scope.refreshSlider();
            angular.element(document.querySelector('#loader')).addClass('hide');
        }, 1000);
        $scope.rowdata = getChildNode(current_config_nodeID[0].id);
        $scope.Config = {
            Nodename: featureName,
            ObjQuestion: nodeattributes.ObjQuestion,
            QuestionType: nodeattributes.QuestionType,
            InputType: nodeattributes.InputType,
            childnodes: nodeattributes.childnodes,
            OptionVarients: nodeattributes.OptionVarients,
            NodeType: nodeattributes.NodeType
        };
        if (nodeattributes.QuestionType == "WAV") {
            $scope.Config.FileName = nodeattributes.Nodename.split(':')[1];
            $scope.Config.PromptFilename = nodeattributes.Nodename;
        }
    }
    $scope.UpdateNodedata = function (event, dataConfig) {
        var nodename = "";
        if ($scope.Config.QuestionType != "WAV") {
            if ($scope.Config.ObjQuestion != undefined && $scope.Config.ObjQuestion != '') {
                $("#" + current_config_nodeID[0].id + " .nodeName").text($scope.Config.ObjQuestion)
                $("#" + current_config_nodeID[0].id + " .nodeName").attr('title', $scope.Config.ObjQuestion);
                $("#" + current_config_nodeID[0].id).attr("data-node-name", $scope.Config.ObjQuestion);
                //nodename = $.parseJSON($scope.Config.ObjQuestion).Question;
                nodename = $scope.Config.ObjQuestion;
            } else {
                $("#" + current_config_nodeID[0].id).find(".nodeName").text("Question");
                $("#" + current_config_nodeID[0].id).attr("data-node-name", "Question");
                nodename = "Question";
            }

            var isexist = !!_.where($scope.Questions, {
                Question: $scope.Config.ObjQuestion
            }).length;
            if (!isexist) {
                if ($scope.ThanksType != "Thanks") {
                    var QuestionInfo = {
                        departmentId: $rootScope.departmentName,
                        Question: $scope.Config.ObjQuestion,
                        QuestionType: "Specific",
                    }
                    surveyFactory.CreateQuestions(QuestionInfo).then(
                        function success(data) {
                            $scope.GetAllQuestion();
                        },
                        function error(data) {}
                    );
                }
            }
        } else {
            nodename = $scope.Config.PromptFilename;
            $("#" + current_config_nodeID[0].id + " .nodeName").text($scope.Config.FileName)
            $("#" + current_config_nodeID[0].id + " .nodeName").attr('title', $scope.Config.FileName);
            $("#" + current_config_nodeID[0].id).attr("data-node-name", $scope.Config.PromptFilename);
            //nodename = $.parseJSON($scope.Config.ObjQuestion).Question;
            //nodename = $scope.Config.PromptFilename;
            //$scope.Config.FileName = orginalmessage;
        }
        var nodeattributes = {
            InputType: $scope.Config.InputType,
            Nodename: nodename,
            ObjQuestion: $scope.Config.ObjQuestion,
            QuestionType: $scope.Config.QuestionType,
            //OptionVarients: $scope.Config.OptionVarients,
            NodeType: $scope.Config.NodeType,
            childnodes: getChildNode(current_config_nodeID[0].id)
        };
        if ($scope.ThanksType == "Thanks") {
            nodeattributes.NodeType = "Thanks";
            $("#" + current_config_nodeID[0].id).attr("data-node-OptionVarients", "Thanks");
            nodeattributes.childnodes = "";
        }
        if ($scope.item.QuestionType != "Objective")
            nodeattributes.InputType = $scope.currentquestiontype;
        $("#" + current_config_nodeID[0].id).attr("data-node-json", JSON.stringify(nodeattributes));
        if ($scope.item.QuestionType == "Objective")
            $('#Fields-RuleNewField').modal('hide');
        else
            $('#Fields-RuleNewField1').modal('hide');
    }
    $scope.deletenode = function (event) {
        var r = confirm("Do you really want to delete!!");
        if (r == true) {
            CallTree.deleteNode($(event.currentTarget).parent());
        }
    }
    $scope.saveQuestionset = function () {
        CallTree.saveCallTree();
        // jsPlumb.doWhileSuspended(function () {
        //     var connections = CallTree.tabInstances["drawing"].getConnections({
        //         source: 'StartFlowNode'
        //     });
        //     for (var i = 0, j = connections.length; i < j; i++) {
        //         jsPlumb.connect(connections[i]);
        //     }
        // }, true);
    }
    $scope.UploadFile = function () {
        var formData = new FormData();
        formData.append("uploadID", angular.toJson($scope.item.ID));
        //   formData.append("uploadedBy", userObj.SSOID);
        formData.append("SurveyFile", $scope.surveyuploadfile);
        surveyFactory.PostSurveyAudioFile(formData).then(function (data) {
            var orginalmessage = data.data.Message;
            var splitdata = orginalmessage.split(':');
            $scope.Config.PromptFilename = orginalmessage;
            $scope.Config.FileName = splitdata[1];
        });
    }

    $scope.WelcomeUploadFile = function (type) {
        var formData = new FormData();
        formData.append("uploadID", 1);
        //   formData.append("uploadedBy", userObj.SSOID);
        if (type == 1) {
            formData.append("SurveyFile", $scope.Welcomeuploadfile);
        } else
            formData.append("SurveyFile", $scope.Thanksuploadfile);

        surveyFactory.PostSurveyAudioFile(formData).then(function (data) {
            var orginalmessage = data.data.Message;
            var splitdata = orginalmessage.split(':');
            if (type == 2) {
                $scope.QuestionsetInfo.ThanksMessage = orginalmessage;
                $scope.Thanks = splitdata[1];
            } else {
                $scope.QuestionsetInfo.WelcomeMessage = orginalmessage;
                $scope.Welcome = splitdata[1];
            }
        });
    }

    //add option for question
    $scope.addoptions = function (event) {
        if ($scope.item.InputMode == "VOICE") {
            if ($scope.optionname.trim() != "" && $scope.OptionVarients.trim() != "") {
                addoptiontotree($scope.OptionVarients);
            } else
                toaster.pop({
                    type: "error",
                    body: "Please ensure valid option and optionvarients are entered",
                    bodyOutputType: 'trustedHtml'
                });
        } else if ($scope.item.InputMode == "DTMF") {
            if ($scope.optionname.trim() != "" && $scope.optionDTMF != "" && $scope.optionDTMF <= 9 && $scope.optionDTMF >= 0) {
                var isexist = !!_.where($scope.rowdata, {
                    OptionVarients: $scope.optionDTMF.toString()
                }).length;
                if (!isexist) {
                    addoptiontotree($scope.optionDTMF);
                    $scope.optionDTMF = "";
                } else {
                    // var max = _.max($scope.rowdata, function (o) {
                    //     return parseInt(o.OptionVarients);
                    // });
                    toaster.pop({
                        type: 'warning',
                        body: "Option DTMF values should be unique",
                        bodyOutputType: 'trustedHtml'
                    });
                    $scope.optionDTMF = "";
                }

            } else
                toaster.pop({
                    type: "error",
                    body: "Please ensure valid option and DTMF values are entered",
                    bodyOutputType: 'trustedHtml'
                });

        } else {
            if ($scope.optionname.trim() != "") {
                addoptiontotree('');
            } else
                toaster.pop({
                    type: "error",
                    body: "Please ensure option and optionvarients are entered",
                    bodyOutputType: 'trustedHtml'
                });
        }

    }
    //add option for question


    $scope.showAddoptions = function () {
        $scope.showaddoptions = true;
    }
    $scope.typeaheadOnSelectFunction = function () {
        var isexist = !!_.where($scope.Optionlist, {
            OptionValue: $scope.optionname
        }).length;
        if (isexist) {
            varfinddata = _.where($scope.Optionlist, {
                OptionValue: $scope.optionname
            });

            $scope.OptionVarients = varfinddata[0].OptionVarients;
        }
    }

    $scope.deletenodeoptions = function (nodeid) {
        $scope.rowdata = _.without($scope.rowdata, _.findWhere($scope.rowdata, {
            targetId: nodeid.targetId
        }))
        if (nodeid.targetId)
            CallTree.deleteNodeManual(nodeid.targetId);
    }



    $scope.MakeContainerFullScreen = function (state, setstate) {
        angular.element(document.querySelector('#loader')).removeClass('hide');
        $scope.DefautState = !state;
        if ($scope.DefautState && setstate != "Y") {
            document.getElementsByClassName('side-navbar')[0].style.display = "none";
            document.getElementsByClassName('header')[0].style.display = "none";
            $('#contentpage').css('width', '100%');
            $('#contentpage').removeClass('content-inner');
        } else {
            $scope.DefautState = false;
            document.getElementsByClassName('side-navbar')[0].style.display = "block";
            document.getElementsByClassName('header')[0].style.display = "block";
            $('#contentpage').addClass('content-inner');
        }
        $timeout(function () {
            angular.element(document.querySelector('#loader')).addClass('hide');
        }, 500)
    };



    // //// jspdf
    // var form = $('#tabs'), cache_width = form.width(), a4 = [595.28, 841.89]; // for a4 size paper width and height

    // $scope.ExportToPdf = function () {
    //     createPDF();
    // }

    // //create pdf
    // function createPDF() {
    //     getCanvas().then(function (canvas) {
    //         var
    //             img = canvas.toDataURL("image/png"),
    //             doc = new jsPDF({
    //                 unit: 'px',
    //                 format: 'a4'
    //             });
    //         doc.addImage(img, 'JPEG', 20, 20);
    //         doc.save('techumber-html-to-pdf.pdf');
    //         form.width(cache_width);
    //     });
    // }

    // // create canvas object
    // function getCanvas() {
    //     form.width((a4[0] * 1.33333) - 80).css('max-width', 'none');
    //     return html2canvas(form, {
    //         imageTimeout: 2000,
    //         removeContainer: true
    //     });
    // }


    // html2pdf JS
    $scope.ExportToPdf = function () {
        var printContents = document.getElementById("drawing").innerHTML;
        var originalContents = document.body.innerHTML;
        var popupWin = window.open('', '_blank', 'width=300,height=300');
        popupWin.document.open()
        var label = '<div class="row" ><div class="col-md-12"><label class="col-md-6" >Welcome Message : </label><label class="col-md-6">' + $scope.item.WelcomeMessage + '</label> <br /> <label class="col-md-6">Thanks Message : </label><label class="col-md-6">' + $scope.item.ThanksMessage + '</label><br/><br/><br/><br/></div>';

        popupWin.document.write('<html> <base href="/ucgAdmin/" /> <head><title>' + $scope.item.QuestionSetName + '</title><link rel="stylesheet" type="text/css" href="chart/css/internal.css"  /><link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"   /><link rel="stylesheet" type="text/css" href="fonts/Roboto.css"   /><link href="chart/css/custom.css" rel="stylesheet"   /><link href="chart/css/mfb.css" rel="stylesheet"   /><link href="css/slider.css" rel="stylesheet"   />   <link rel="stylesheet" href="css/bootstrap3.min.css" /> </head> <body onload="window.print()">' + label + '<div class="col-md-12">' + printContents + '</div></div><script>setTimeout(function(){window.print();window.close();},1000);</script><script src="chart/lib/jquery-1.9.0.js"></script>        <script src="chart/js/jquery.form.js"></script>        <script src="chart/lib/jquery-ui-1.9.2-min.js"></script>        <script src="chart/lib/jquery.jsPlumb-1.7.5-min.js"></script>        <script src="chart/js/session_data.js"></script>        <script src="chart/js/bootstrap.min.js"></script><script src="chart/angular_content/global_constants.js"></script></body></html>');


        /*   html2canvas($("#"+CallTree.currentTabID), {
onrendered: function(canvas) {
theCanvas = canvas;
document.body.appendChild(canvas);

// Convert and download as image 
Canvas2Image.saveAsPNG(canvas); 
//$("#img-out").append(canvas);
// Clean up 
//document.body.removeChild(canvas);
}
}); */

        // var element = document.getElementById('tabs');
        // html2pdf(element, {
        //     margin: 1,
        //     filename: 'myfile.pdf',
        //     image: {
        //         type: 'png',
        //         quality: 1.0
        //     },
        //     enableLinks: true,
        //     html2canvas: {
        //         dpi: 1350,
        //         letterRendering: true
        //     },
        //     jsPDF: {
        //         unit: 'pt',
        //         format: 'letter',
        //         orientation: 'l'
        //     }
        // });

    }



    //// Pdfmake JS
    // $scope.ExportToPdf = function () {

    //     html2canvas(document.getElementById('tabs'), {
    //         onrendered: function (canvas) {
    //             var data = canvas.toDataURL("image/png");
    //             var docDefinition = {
    //                 content: [{
    //                     image: data,
    //                     width: 500,
    //                 }]
    //             };
    //             // open the PDF in a new window
    //             pdfMake.createPdf(docDefinition).open();

    //             // print the PDF
    //             // pdfMake.createPdf(docDefinition).print();

    //             // download the PDF
    //             // pdfMake.createPdf(docDefinition).download('optionalName.pdf');

    //             // pdfMake.createPdf(docDefinition).download("test.pdf");
    //         }
    //     });
    // }



    //****************** */
    // page events end
    //****************** */

    //****************** */
    // functional operations
    //****************** */

    function validatequestionset() {
        if (!$scope.QuestionsetInfo.QuestionsetName) {
            toaster.pop({
                type: "warning",
                body: "please enter survey name",
                bodyOutputType: 'trustedHtml'
            });
            return false;
        } else if (!$scope.QuestionsetInfo.departmentId) {
            toaster.pop({
                type: "warning",
                body: "please select department",
                bodyOutputType: 'trustedHtml'
            });
            return false;
        } else if (!$scope.QuestionsetInfo.languageId) {
            toaster.pop({
                type: "warning",
                body: "please select language",
                bodyOutputType: 'trustedHtml'
            });
            return false;
        } else if ($scope.QuestionsetInfo.questiontypeId == 1) {
            if (!$scope.QuestionsetInfo.inputMode) {
                toaster.pop({
                    type: "warning",
                    body: "please select input mode",
                    bodyOutputType: 'trustedHtml'
                });
                return false;
            }
            if (!$scope.QuestionsetInfo.phraseType) {
                toaster.pop({
                    type: "warning",
                    body: "please select phrase type",
                    bodyOutputType: 'trustedHtml'
                });
                return false;
            } else {
                if (!$scope.QuestionsetInfo.WelcomeMessage) {
                    toaster.pop({
                        type: "warning",
                        body: "please enter Welcome Message",
                        bodyOutputType: 'trustedHtml'
                    });
                    return false;
                } else if (!$scope.QuestionsetInfo.ThanksMessage) {
                    toaster.pop({
                        type: "warning",
                        body: "please enter Thanks Message",
                        bodyOutputType: 'trustedHtml'
                    });
                    return false;
                }
            }
        }
        return true;
    }

    (function () {
        Array.prototype.last = function () {
            return this[this.length - 1];
        };
        Array.prototype.lastIdx = function () {
            return this.length - 1;
        };
        jsPlumb.ready(function () {
            CallTree = {
                sourceEndpoint: {
                    endpoint: "Dot",
                    paintStyle: {
                        strokeStyle: "#544e4e",
                        fillStyle: "transparent",
                        radius: 6,
                        lineWidth: 3
                    },
                    maxConnections: -1,
                    isSource: true,
                    connector: ["Flowchart", {
                        stub: [40, 60],
                        gap: 10,
                        cornerRadius: 3,
                        alwaysRespectStubs: false,
                    }],
                    connectorStyle: {
                        lineWidth: 2,
                        strokeStyle: "#544e4e",
                        joinstyle: "round"
                    },
                    hoverPaintStyle: {
                        fillStyle: "#544e4e",
                        strokeStyle: "#544e4e"
                    },
                    connectorHoverStyle: {
                        lineWidth: 3,
                        strokeStyle: "#544e4e"
                    },
                    dragOptions: {}
                },
                targetEndpoint: {
                    endpoint: "Dot",
                    paintStyle: {
                        fillStyle: "#544e4e",
                        radius: 8
                    },
                    hoverPaintStyle: {
                        fillStyle: "#544e4e",
                        strokeStyle: "#544e4e"
                    },
                    maxConnections: 9,
                    dropOptions: {
                        hoverClass: "hover",
                        activeClass: "active"
                    },
                    isTarget: true,
                },
                mainMenu: {},
                flowsContext: {},
                connectorNames: {},
                //entryConnectPoints: {},
                init: function (source) {
                    var that = this;
                    this.tabInstances = {};
                    this.loadModules();
                },
                loadMultipleFlows: function () {
                    var that = this;
                    for (var f = 0; f < flowDataStore.length; f++) {
                        var flowName = flowDataStore[f].flowName;
                        if (typeof flowDataStore[f].callTree != 'object' && flowDataStore[f].callTree != undefined && flowDataStore[f].callTree != '')
                            flowDataStore[f].callTree = $.parseJSON(flowDataStore[f].callTree);
                    }
                },
                createContainers: function (flowName) {
                    jsPlumb.reset();
                    jsPlumb.setContainer("drawing");
                    $scope.zoom = 0.6;
                    $scope.ZoomIn();
                    var that = this;
                    that.tabInstances = {};
                    var currFlow = flowName.QuestionSetName;
                    that.initTabSettings('drawing');
                    var isexist = !!_.where(flowDataStore, {
                        FlowName: flowName.QuestionSetName
                    }).length;
                    if (isexist) {
                        var seldata = _.where(flowDataStore, {
                            FlowName: flowName.QuestionSetName
                        });

                        that.loadCallTree(seldata[0].callTree.nodes);

                    } else {
                        if ($scope.redraw) {
                            flowDataStore.push({
                                callTree: {
                                    nodes: $scope.Redrawcalltree
                                },
                                FlowName: $scope.item.QuestionSetName
                            });
                            that.loadCallTree($scope.Redrawcalltree);

                        } else {
                            that.tabInstances = {};
                            that.initTabSettings('drawing');
                            var startNodeTopPosition = 1,
                                startNodeLeftPosition = 250;
                            var node = "";
                            var node = that.createNode({
                                id: 'StartFlowNode',
                                type: 'entryConnector',
                                value: 'Question Root',
                                NodeType: 'Option',
                                OptionVarients: '',
                            });
                            $compile(node)($scope);
                            $('#' + 'drawing').append(node);
                            that.tabInstances['drawing'].draggable(node);
                            flowDataStore.push({
                                "flowName": flowName.QuestionSetName,
                                "callTree": {
                                    "flowName": flowName.QuestionSetName,
                                    "nodes": [{
                                        "id": "StartFlowNode",
                                        "name": "StartFlowNode",
                                        "NodeType": 'Option',
                                        "type": "entryConnector",
                                        "nodeOptions": {},
                                        "element": {
                                            "id": "StartFlowNode",
                                            "left": startNodeLeftPosition,
                                            "position": startNodeTopPosition + ":" + startNodeLeftPosition,
                                            "sourceAnchor": "",
                                            "targetAnchor": "",
                                            "top": startNodeTopPosition
                                        }
                                    }],
                                }
                            });
                            node.css({
                                top: startNodeTopPosition,
                                left: startNodeLeftPosition
                            });
                            node.attr('data-node-position', startNodeTopPosition + ":" + startNodeLeftPosition);
                            node.attr('data-node-OptionVarients', '');
                            $(node).draggable({
                                stop: function (e, ui) {
                                    node.attr('data-node-position', ui.position.top + ":" + ui.position.left);
                                }
                            });

                            that.addEndPoints(node.attr('id'), node.attr('data-node-type'), that.tabInstances['drawing']);
                        }
                    }

                },
                initTabSettings: function (tabID) {
                    var that = this;
                    var tabInstance = jsPlumb.getInstance({
                        DragOptions: {
                            cursor: "pointer",
                            zIndex: 2000
                        },
                        Container: tabID,
                    });
                    tabInstance.bind("dblclick", function (connInfo) {
                        var r = confirm("Do you really want to delete!!");
                        if (r == true) {
                            var nodeId = connInfo.endpoints[1].getUuid();
                            tabInstance.detach(connInfo);
                        }
                    }); //here pharase ll be there additional
                    that.tabInstances["drawing"] = tabInstance;
                },
                loadModules: function (thisTabId) {
                    var that = this;
                    $('#modulesContainer .drag').each(function () {
                        $(this).draggable({
                            revert: 'invalid',
                            helper: 'clone',
                            connectToSortable: '.calltree',
                            tolerance: 'intersect'
                        });
                    });
                },
                createnodemanual: function (Source, type, OptionVarients) {
                    that = this;
                    var pos = Source.attributes['data-node-position'].nodeValue.split(':');
                    console.log(pos);
                    var child = getChildNode(Source.id);
                    var plusleftvalue = 0,
                        plustopvalue = 0;
                    if (type == "Option") {
                        if (child.length % 2 == 0) {
                            plusleftvalue = parseInt(pos[1]) - 100;
                            if (child.length == 0)
                                plustopvalue = parseInt(pos[0]) + 120;
                            else
                                plustopvalue = parseInt(pos[0]) + (120 * (child.length / 2 + 1));
                        } else {
                            plusleftvalue = parseInt(pos[1]) + 100;
                            if (child.length == 1)
                                plustopvalue = parseInt(pos[0]) + 120;
                            else
                                plustopvalue = parseInt(pos[0]) + (120 * Math.floor(child.length / 2 + 1));
                        }
                    } else {
                        plusleftvalue = parseInt(pos[1]);
                        plustopvalue = parseInt(pos[0]) + 120;
                    }
                    var nodeText = $scope.optionname,
                        nodeTopPosition = plustopvalue,
                        nodeLeftPosition = plusleftvalue;
                    // nodeTopPosition = parseInt(pos[0]) + 100,
                    // nodeLeftPosition = parseInt(pos[1]) + 100;

                    var node = that.createNode({
                        type: 'feature',
                        value: nodeText,
                        NodeType: type,
                        OptionVarients: OptionVarients,
                    });
                    $compile(node)($scope);
                    node.attr('data-node-position', nodeTopPosition + ":" + nodeLeftPosition);
                    nodeattributes = {
                        Nodename: '',
                        ObjQuestion: '',
                        QuestionType: 'TTS',
                        NodeType: type,
                        OptionVarients: OptionVarients,
                        InputType: 'Custom',
                        childnodes: '',
                        PromptFilename: '',
                        FileName: ''
                    }
                    node.attr("data-node-json", JSON.stringify(nodeattributes));
                    node.attr("data-node-OptionVarients", nodeattributes.OptionVarients);
                    document.getElementById("drawing").appendChild(node[0]);
                    node.css({
                        top: nodeTopPosition,
                        left: nodeLeftPosition
                    });
                    that.tabInstances["drawing"].draggable(node);
                    $(node).draggable({
                        stop: function (e, ui) {
                            node.attr('data-node-position', ui.position.top + ":" + ui.position.left);
                        }
                    });
                    that.addEndPoints(node.attr('id'), 'feature', that.tabInstances["drawing"]);
                    that.tabInstances["drawing"].connect({
                        uuids: ["endPoint-" + Source.id + "Bottom",
                            "endPoint-" + node.attr('id') + "Top"
                        ],
                    });
                    return node;
                },
                generateUniqueId: function (prefix) {
                    function rand() {
                        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
                    }
                    return prefix + '_' + rand() + rand() + '-' + rand() + '-' + rand();
                },
                addEndPoint: function (plumbInstance, nodeId, sourceAnchors, targetAnchors, nodeType) {
                    var sourceEndPoint = this.sourceEndpoint,
                        targetEndpoint = this.targetEndpoint;
                    if (typeof sourceAnchors == 'object') {
                        for (var i = 0; i < sourceAnchors.length; i++) {
                            var sourceUUID = 'endPoint-' + nodeId + sourceAnchors[i];
                            plumbInstance.addEndpoint(nodeId, sourceEndPoint, {
                                anchor: sourceAnchors[i],
                                uuid: sourceUUID,
                                connectionsDetachable: true,
                            });
                        }
                    }
                    if (typeof targetAnchors == 'object') {
                        for (var j = 0; j < targetAnchors.length; j++) {
                            var targetUUID = 'endPoint-' + nodeId + targetAnchors[j];
                            plumbInstance.addEndpoint(nodeId, targetEndpoint, {
                                anchor: targetAnchors[j],
                                uuid: targetUUID
                            });
                        }
                    }
                },
                addEndPoints: function (nodeId, nodeType, plumbInstance) {
                    if (nodeType === 'StartFlowNode' || nodeType === 'entryConnector') {
                        this.addEndPoint(plumbInstance, nodeId, ['Bottom'], [], nodeType);
                    } else {
                        this.addEndPoint(plumbInstance, nodeId, ['Bottom'], ['Top'], nodeType);
                    }
                },
                createNode: function (nodeData) {
                    var nodeId = nodeData.id || this.generateUniqueId(nodeData.type),
                    node = $('<div ng-class="{\'notallowededit\': !iseditable }">'),
                        deleteIcon = $('<div class="deleteIconClick deleteIcon"> <i class="fa fa-trash-o" aria-hidden="true"></i>'),
                        nodeName = $('<p class="nodeName" style="word-wrap: break-word;">'),
                        EditIcon, ruleConfigIcon, CopyIcon = $('<div class="copyIcon" > <i class="fa fa-files-o" aria-hidden="true"></i>'),
                        PasteIcon = $('<div class="pasteIcon" ng-show="IscopyBuffer" > <i class="fa fa-clipboard" aria-hidden="true"></i>');
                    node.attr('id', nodeId);
                    node.addClass('draggableNode');
                    node.attr('data-node-type', nodeData.type);
                    node.attr('data-node-name', nodeData.value);
                    node.attr('data-node-OptionVarients', nodeData.OptionVarients);
                    node.addClass(nodeData.NodeType);
                    nodeName.text(nodeData.value);
                    nodeName.attr("title", nodeData.value);
                    EditIcon = $('<div id="FF_' + nodeId + '"  class="AddruleConfigIcon ruleConfigIcon"  title=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>');
                    ruleConfigIcon = $('<div id="R_' + nodeId + '"  class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>');
                    if (nodeId == "StartFlowNode") {
                        node.addClass('entryConnector');
                        node.append('<div class="questionIcon"> <i  class="fa fa-question" aria-hidden="true"></i>');
                        node.append(nodeName);
                        node.append(ruleConfigIcon); // add icon question
                        node.append(PasteIcon);
                    } else if (nodeData.NodeType == "Option") {
                        node.append(nodeName);
                        node.append(ruleConfigIcon); // add icon question
                        node.append(PasteIcon);
                    } else if (nodeData.NodeType == "Question" || nodeData.NodeType == "Thanks") {
                        node.append(nodeName);
                        node.append(EditIcon); //// add icon option
                        if ($scope.item.QuestionType == "Objective")
                            node.append('<div class="questionIcon questiontop"> <i class="fa fa-question" aria-hidden="true"></i>');
                        else if ($scope.item.QuestionType == "Subjective")
                            node.append($('<div id="R_' + nodeId + '"  class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>'));
                        else if ($scope.item.QuestionType == "Mixed") {
                            if ($scope.currentquestiontype == "Subjective")
                                node.append($('<div id="R_' + nodeId + '" class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>'));
                            else
                                node.append('<div class="questionIcon questiontop"> <i class="fa fa-question" aria-hidden="true"></i>');
                        }
                        node.append(deleteIcon);
                        node.append(CopyIcon);

                    }
                    return node;
                },
                isNullOrEmpty: function (data) {
                    if (data === undefined || data === null || data === "") {
                        return true;
                    }
                    return false;
                },
                saveCallTree: function () {
                    var callTreeObj = {
                            "flowName": $scope.item.QuestionSetName,
                            "calltree": ""
                        },
                        calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    function getNextNodes(sourceId, nodeId, connection, legIdx) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;
                        if ($('#' + nodeId).attr('data-node-type') == 'feature') {
                            if ($('#' + sourceId).attr('data-node-type') == 'menu' || $('#' + sourceId).attr('data-node-type') == 'feature' || $('#' + sourceId).attr('data-node-type') == 'StartFlowNode' || $('#' + sourceId).attr('data-node-type') == 'entryConnector') {
                                if (connection != null) {
                                    targetAnchorId = connection.endpoints[1].getUuid();
                                    nodes.push({ // Create link node
                                        "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                        "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                        "type": "link",
                                        "element": {},
                                    });
                                }
                            }
                        } else {
                            if (connection != undefined) {
                                targetAnchorId = connection.endpoints[1].getUuid();
                                nodes.push({
                                    "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                    "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                    "type": "link",
                                    "element": {},
                                });
                            }
                        }
                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                "position": $('#' + nodeId).attr("data-node-position"),
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove')
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], null);
                                }
                            }
                            // i=0;
                        }
                    }
                    var tempEntryConnectorList = $(".calltree").find(".entryConnector"); // save StartFlowNode point
                    for (var i = 0; i < tempEntryConnectorList.length; i++) {
                        flowDataStore[0].mainMenu = tempEntryConnectorList[i].id;
                        getNextNodes(null, tempEntryConnectorList[i].id);

                    }
                    flowDataStore[0].callTree = calltree;
                    var postData = {
                        "flowName": '',
                        "callTree": {},
                    };
                    converttoIVR(flowDataStore[0].callTree, flowDataStore[0].mainMenu);

                },
                loadCallTree: function (nodesObj) {

                    $scope.AvailableNodeids = [];
                    if ($scope.redraw)
                        nodesObj = $scope.Redrawcalltree;
                    var rootnode = _.where(nodesObj, {
                        type: "entryConnector"
                    });

                    function getNextNodes(node) {
                        for (var t = 0; t < node.nodeOptions.childnodes.length; t++) {
                            var childnode = _.where(nodesObj, {
                                id: node.nodeOptions.childnodes[t].targetId
                            });
                            var isexist = !!_.where($scope.AvailableNodeids, {
                                Id: node.nodeOptions.childnodes[t].targetId
                            }).length;
                            if (isexist > 0) {
                                console.log('Already node detected stop');
                                this.CallTree.tabInstances["drawing"].connect({
                                    uuids: ["endPoint-" + node.id + "Bottom",
                                        "endPoint-" + childnode[0].element.id + "Top"
                                    ],
                                });
                                return;
                            } else {
                                $scope.AvailableNodeids.push({
                                    Id: childnode[0].id
                                });
                                this.CallTree.loadtree(childnode[0]);
                                getNextNodes(childnode[0]);
                            }
                        }
                        // i = 0;
                    }
                    $scope.AvailableNodeids.push({
                        Id: rootnode[0].id
                    });
                    this.loadtree(rootnode[0]);
                    getNextNodes(rootnode[0]);
                },
                loadtree: function (nodeObj) {
                    var that = this;
                    var nodePosition = nodeObj.element.position.split(":");
                    var nodeText = nodeObj.name;
                    if (nodeObj.type == "entryConnector") {
                        nodeText = CallTree.connectorNames[nodeObj.id] || "Question Root";
                    }

                    if (nodeObj.nodeOptions.QuestionType == "WAV") {
                        nodeText = nodeObj.nodeOptions.Nodename.split(':')[1];
                    }
                    $scope.currentquestiontype = nodeObj.nodeOptions.InputType;
                    newNode = that.createNode({
                        id: nodeObj.id,
                        type: nodeObj.type,
                        value: nodeText,
                        NodeType: nodeObj.nodeOptions.NodeType,
                        OptionVarients: nodeObj.nodeOptions.OptionVarients,
                    });
                    $('#drawing').append(newNode);
                    $compile(newNode)($scope);
                    newNode.css({
                        top: parseInt(nodePosition[0]),
                        left: parseInt(nodePosition[1])
                    });
                    newNode.attr("data-node-position", nodeObj.element.position);
                    newNode.attr("data-node-json", JSON.stringify(nodeObj.nodeOptions));
                    that.tabInstances["drawing"].draggable(newNode);
                    that.addEndPoints(nodeObj.id, nodeObj.type, that.tabInstances["drawing"]);
                    $(newNode).draggable({
                        stop: function (e, ui) {
                            console.log(e);
                            console.log(ui);
                            console.log(ui.position.top + ':' + ui.position.left);
                            var position = ui.position.top + ":" + ui.position.left;
                            $(e.target).attr({
                                "data-node-position": position
                            });
                        }
                    });
                    if (nodeObj.type == "entryConnector" && nodeObj.element.sourceAnchor == '' && nodeObj.element.targetAnchor != '') {
                        that.tabInstances["drawing"].connect({
                            uuids: ["endPoint-" + nodeObj.id + "Bottom",
                                nodeObj.element.targetAnchor
                            ],
                        });
                    } else if (nodeObj.element.sourceAnchor != '' || nodeObj.element.targetAnchor != '') {
                        that.tabInstances["drawing"].connect({
                            uuids: [nodeObj.element.sourceAnchor,
                                nodeObj.element.targetAnchor
                            ],
                        });
                    }
                },
                deleteNode: function (node) {
                    var nodeId = $(node).attr('id');
                    this.removeAllchildnode(nodeId);
                },
                deleteNodeManual: function (nodeId) {
                    this.removeAllchildnode(nodeId);
                },
                removeAllchildnode: function (nodeId) {
                    function getNextNodes(nodeId) {
                        var connections = this.CallTree.tabInstances["drawing"].getConnections({
                            source: nodeId
                        });
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove');
                            console.log(nodeId);
                            this.CallTree.deleteNodeGeneric(nodeId);
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    getNextNodes(connections[i].targetId);
                                }
                            }
                            console.log(nodeId);
                            this.CallTree.deleteNodeGeneric(nodeId);
                            i = 0;
                        }
                    }
                    getNextNodes(nodeId);
                },
                getAllchildnode: function (node) {
                    var calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    function getNextNodes(sourceId, nodeId, connection, legIdx) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;

                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                "position": $('#' + nodeId).attr("data-node-position"),
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove')
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], null);
                                }
                            }
                            // i=0;
                        }
                    }
                    calltree.Copyroot = node.id;
                    getNextNodes(null, node.id);
                    $scope.CopyNodedata = calltree;
                    console.log($scope.CopyNodedata)

                },
                getquestionoptioncount: function () {
                    var callTreeObj = {
                            "flowName": $scope.item.QuestionSetName,
                            "calltree": ""
                        },
                        calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    var setcurentblock = true;
                    var arrayleveljson = [];
                    var instances = this.tabInstances,
                        source, target, sourceId, targetId;
                    var loopval = 0;

                    function getNextNodes(sourceId, nodeId, connection, loopvalue) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;
                        if ($('#' + nodeId).attr('data-node-type') == 'feature') {
                            if ($('#' + sourceId).attr('data-node-type') == 'menu' || $('#' + sourceId).attr('data-node-type') == 'feature' || $('#' + sourceId).attr('data-node-type') == 'StartFlowNode' || $('#' + sourceId).attr('data-node-type') == 'entryConnector') {
                                if (connection != null) {
                                    targetAnchorId = connection.endpoints[1].getUuid();
                                    nodes.push({ // Create link node
                                        "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                        "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                        "type": "link",
                                        "element": {},
                                    });
                                }
                            }
                        } else {
                            if (connection != undefined) {
                                targetAnchorId = connection.endpoints[1].getUuid();
                                nodes.push({
                                    "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                    "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                    "type": "link",
                                    "element": {},
                                });
                            }
                        }
                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        var poscalc = "20:160"
                        if (nodeId != "StartFlowNode")
                            poscalc = (loopvalue - 1) * 180 + ':' + (arrayleveljson[loopvalue - 1].question + arrayleveljson[loopvalue - 1].option) * 150;
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                // "position": $('#' + nodeId).attr("data-node-position"),
                                "position": poscalc,
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                            //"level": loopvalue - 1 + ':' + (arrayleveljson[loopvalue - 1].question + arrayleveljson[loopvalue - 1].option)
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove');
                            --loopval;
                            return;
                        } else {
                            setcurentblock = true;
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    if (setcurentblock) {
                                        var isexist = !!_.where(arrayleveljson, {
                                            level: loopvalue
                                        }).length;

                                        if (!isexist) {
                                            arrayleveljson.push({
                                                level: loopvalue,
                                                question: 0,
                                                option: 0
                                            });
                                        }
                                        if ($.parseJSON($('#' + connections[i].targetId).attr("data-node-json")).NodeType == "Question")
                                            arrayleveljson[loopvalue].question++;
                                        else
                                            arrayleveljson[loopvalue].option++;
                                        setcurentblock = false;
                                    } else {
                                        if ($.parseJSON($('#' + connections[i].targetId).attr("data-node-json")).NodeType == "Question")
                                            arrayleveljson[loopvalue].question++;
                                        else
                                            arrayleveljson[loopvalue].option++;
                                    }
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], ++loopval);
                                }
                                --loopval;
                            }
                        }
                    }
                    arrayleveljson.push({
                        level: loopval,
                        question: 0,
                        option: 1
                    });

                    getNextNodes(null, 'StartFlowNode', null, ++loopval);
                    console.log('nodes');
                    console.log(arrayleveljson);
                    console.log(calltree.nodes);
                    $scope.Redrawcalltree = calltree.nodes;
                    //Redraw
                    $scope.redraw = true;
                    //this.loadCallTree(calltree.nodes);
                    changeCallFlow($scope.item);
                },
                deleteNodeGeneric: function (sourceId) {
                    this.tabInstances["drawing"].detachAllConnections(sourceId);
                    this.tabInstances["drawing"].removeAllEndpoints(sourceId);
                    delete this.connectorNames[sourceId];
                    $('#' + sourceId).remove();
                },
            };

            CallTree.init();
        });


    })(); //Jquery library ending here

    function createObjectivequestion() {
        angular.element(document.querySelector('#loader')).removeClass('hide');
        $scope.optionname = "Question ";
        var node = CallTree.createnodemanual(current_config_nodeID[0], 'Question', "");
        current_config_nodeID = node;
        $scope.optionname = "";
        var scope = angular.element(document.getElementById('addQuestions')).scope();
        $('#moduleConfigurationDiv').css('width', '94%');
        var node = current_config_nodeID,
            moduleConfigurationDiv = $('#moduleConfigurationDiv');
        var featureName = node.attr('data-node-name');
        var parsingdata = node.attr('data-node-json');

        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
            nodeattributes = $.parseJSON(parsingdata);

        $timeout(function () {
            // $scope.refreshSlider();
            angular.element(document.querySelector('#loader')).addClass('hide');
            $scope.$apply(function () {
                $scope.rowdata = getChildNode(current_config_nodeID[0].id);

                $scope.Config = {
                    Nodename: featureName,
                    ObjQuestion: nodeattributes.ObjQuestion,
                    QuestionType: nodeattributes.QuestionType,
                    InputType: nodeattributes.InputType,
                    childnodes: nodeattributes.childnodes,
                    OptionVarients: nodeattributes.OptionVarients,
                    NodeType: nodeattributes.NodeType,
                };

            })
        }, 1000);
    }

    function addoptiontotree(value) {
        var isexist = !!_.where($scope.Optionlist, {
            OptionValue: $scope.optionname
        }).length;
        if (!isexist) {
            var json = {
                option: $scope.optionname,
                OptionVarients: $scope.OptionVarients
            }
            surveyFactory.Create_Options(json)
                .then(function (success) {
                    console.log(success);
                    $scope.GetAllQuestionOptions();
                });
        }
        var cnode = CallTree.createnodemanual(current_config_nodeID[0], 'Option', value);
        $scope.rowdata.push({
            TargetValue: $scope.optionname,
            OptionVarients: value,
            targetId: cnode[0].id,
        });
        $scope.optionname = "";
        $scope.OptionVarients = "";
        return cnode;
    }


    function getChildNode(nodeid) {
        var constructjson = [];
        var connections = CallTree.tabInstances["drawing"].getConnections({
            source: nodeid
        });
        for (var i = 0; i < connections.length; i++)
            constructjson.push({
                targetId: connections[i].targetId,
                TargetValue: $('#' + connections[i].targetId).attr('data-node-name'),
                OptionVarients: $('#' + connections[i].targetId).attr('data-node-OptionVarients')
            })
        return constructjson;
    }

    function changeCallFlow(currFlow) {
        flowDataStore = [];
        $('#drawing').remove();
        if (currFlow.QuestionSetName != "--Select--") {
            if (currFlow.JSONData != '') {
                flowDataStore.push({
                    callTree: {},
                    FlowName: currFlow.QuestionSetName
                });
                flowDataStore[0].callTree = $.parseJSON(currFlow.JSONData);
            }
            $("div#tabs").append("<div class='container calltree' style='background: #fff;' id='drawing'/>");
            if (currFlow.JSONData != '')
                CallTree.loadMultipleFlows();
            CallTree.createContainers(currFlow);
        }
        triggerpageevent(0);
    }


    function converttoIVR(inputdata, mainmenu) {
        $scope.Qinfo = {
            TotalQuestions: 0,
            Questions: ''
        };
        var IVRdata = {
            mainMenu: mainmenu,
            Nodes: []
        };
        var filtered = _.filter(inputdata.nodes, function (node) {
            return node.type != "link";
        });
        for (var j = 0; j < filtered.length; j++) {
            var processjson = {
                childnodes: []
            };
            processjson.NodeId = filtered[j].id;
            processjson.NodeValue = filtered[j].name;
            if (processjson.NodeId != "StartFlowNode") {
                processjson.NodeType = filtered[j].nodeOptions.NodeType;
                if ($scope.item.QuestionType != "Objective") {
                    processjson.NodeValue = processjson.NodeValue;
                } else {

                    if (filtered[j].nodeOptions.NodeType == "Option") {
                        if ($scope.item.InputMode == "VOICE")
                            processjson.NodeValue += '-' + filtered[j].nodeOptions.OptionVarients;
                        else
                            processjson.NodeValue = filtered[j].nodeOptions.OptionVarients + '/' + processjson.NodeValue;
                    }
                }
            }
            if (filtered[j].nodeOptions.QuestionType != undefined) {
                processjson.Question = filtered[j].nodeOptions.ObjQuestion;
                if (filtered[j].nodeOptions.QuestionType == 'WAV')
                    processjson.Question = filtered[j].nodeOptions.Nodename;
                processjson.QuestionType = filtered[j].nodeOptions.QuestionType;
                processjson.InputType = filtered[j].nodeOptions.InputType;
            }
            var childNodes = getChildNode(processjson.NodeId);
            if ($scope.item.QuestionType == "Objective") {
                if (filtered[j].nodeOptions.NodeType == "Question" && childNodes.length <= 0) {
                    toaster.pop({
                        type: 'warning',
                        body: "Survey question " + processjson.Question + "must have option",
                        bodyOutputType: 'trustedHtml'
                    });
                    return "";
                } else if (filtered[j].nodeOptions.NodeType == "Question") {
                    $scope.Qinfo.TotalQuestions++;
                }
            }
            if (childNodes.length > 0) {
                var questionReadoutconstruct = "";
                if ($scope.item.InputMode == "VOICE") {
                    if ($scope.item.LanguageID == 1)
                        questionReadoutconstruct = " Please say ";
                    else
                        questionReadoutconstruct = " कृपया कहे ";
                }
                for (var k = 0; k < childNodes.length; k++) {
                    var nodevarient = "";
                    var convertoptionvarient = childNodes[k].OptionVarients == undefined ? "" : childNodes[k].OptionVarients;

                    if ($scope.item.QuestionType == "Objective") {
                        if ($scope.item.InputMode == "VOICE") {
                            nodevarient = childNodes[k].TargetValue + '-' + convertoptionvarient;
                            if (convertoptionvarient != "Thanks") {
                                if ($scope.item.LanguageID == 1) {
                                    if (k === childNodes.length - 1)
                                        questionReadoutconstruct += childNodes[k].TargetValue;
                                    else
                                        questionReadoutconstruct += childNodes[k].TargetValue + " or ";
                                } else {
                                    var optionvarientfirstvalue = convertoptionvarient.split(',');
                                    if (k === childNodes.length - 1)
                                        questionReadoutconstruct += " " + optionvarientfirstvalue[0];
                                    else
                                        questionReadoutconstruct += " " + optionvarientfirstvalue[0] + " या ";
                                }
                            }
                        } else {
                            if (convertoptionvarient != "Thanks") {
                                if ($scope.item.LanguageID == 1) {
                                    if (k === childNodes.length - 1)
                                        questionReadoutconstruct += " Press " + convertoptionvarient + " for " + childNodes[k].TargetValue;
                                    else
                                        questionReadoutconstruct += " Press " + convertoptionvarient + " for " + childNodes[k].TargetValue; //+ " or ";
                                } else {
                                    if (k === childNodes.length - 1)

                                        questionReadoutconstruct += childNodes[k].TargetValue + " के लिए " + convertoptionvarient + "  दबाएं ";
                                    else
                                        questionReadoutconstruct += " " + childNodes[k].TargetValue + " के लिए " + convertoptionvarient + "  दबाएं"; // या";
                                }
                            }
                            nodevarient = convertoptionvarient + "/" + childNodes[k].TargetValue;
                        }
                    }
                    if ($scope.item.QuestionType != "Objective") {
                        nodevarient = childNodes[k].TargetValue;
                    }
                    processjson.childnodes.push({
                        'NextNodeId': childNodes[k].targetId,
                        'NextNodeValue': nodevarient
                    });
                }
                if ($scope.item.QuestionType != "Objective") {
                    if (childNodes.length == 1 && processjson.NodeType == "Question")
                        processjson.InputType = "Subjective";
                    if (childNodes.length > 1 && processjson.NodeType == "Question")
                        processjson.InputType = "Objective";
                    if (processjson.NodeType == "Option")
                        processjson.InputType = "Option";
                }
                if (processjson.NodeId != "StartFlowNode")
                    processjson.Question = processjson.Question + questionReadoutconstruct;
            }
            if ($scope.item.QuestionType != "Objective") {
                if (childNodes.length == 0 && processjson.NodeType == "Question")
                    processjson.InputType = "Subjective";
                if (processjson.NodeType == "Option")
                    processjson.InputType = "Option";
            }

            IVRdata.Nodes.push(processjson);
        }
        return IVRdata;
    }



    function ZoomProcess(zoomvalue) {
        $("#drawing").css({
            "-webkit-transform": "scale(" + zoomvalue + ")",
            "-moz-transform": "scale(" + zoomvalue + ")",
            "-ms-transform": "scale(" + zoomvalue + ")",
            "-o-transform": "scale(" + zoomvalue + ")",
            "transform": "scale(" + zoomvalue + ")"
        });
    }

    function triggerpageevent(val) {
        $(window).resize(function () {
            //$('#mainContainer').height($(window).height() - 100);
            $('#drawing').height($(window).height() - 120);
            // $('.calltreeContainer').height($(window).height() - (200));
            //$('#featureConfig, .ruleConfig').height($(window).height() - 190);
        });
        $(window).trigger('resize');
    }
    $scope.isSuperIdmin = false;

    $scope.checkifsuperadmin = function () {
        if (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) {
            $scope.isSuperIdmin = true;
        } else
            $scope.isSuperIdmin = false;

        $scope.FilterData();

    }
    $scope.checkifsuperadmin();

}]);