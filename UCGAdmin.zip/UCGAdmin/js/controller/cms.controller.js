app.controller('CMSController', function ($scope, $filter, $location, $routeParams, appFactory, profileFactory, uiGridConstants, httpService, UCGService) {
    var ucgObject = this;
    $('.modal-dialog .card').resizable().draggable();
    /* constants declaration **/
    ucgObject.SEARCH = {
        INBOX: 'inbox',
        MY_TICK: 'my tickets',
        ASSIGN: 'assign tickets',
        DASH: 'dash board',
        ALLTICK: 'All Ticket dash board',
        REJECT: 'reject tickets',
        OPEN: 'open tickets',
        COMPLETE: 'completed tickets' 
    }
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));

    $scope.createForm;
    $scope.myTickpermission = appFactory.permissions[appConst.MENUS.CMS.MY_TICK];
    $scope.createTickpermission = appFactory.permissions[appConst.MENUS.CMS.CREATE_TICK];
    $scope.assignTickpermission = appFactory.permissions[appConst.MENUS.CMS.ASSIGN_TICK];
    $scope.updateTickpermission = appFactory.permissions[appConst.MENUS.CMS.INBOX];
    $scope.rejectTickpermission = appFactory.permissions[appConst.MENUS.CMS.REJECT];
    $scope.completeTickpermission = appFactory.permissions[appConst.MENUS.CMS.COMPLETE];
    ucgObject.isCreateFormSubmitted = false;
    ucgObject.DataForNewTicket = { "CallingPhone": "", "RegisteredPhone": "", "Firstname": "", "LastName": "", "DOB": "", "Gender": "", "EmailId": "", "SSONO": "", "DivisionID": "", "DistrictID": "", "BlockID": "", "PanchayatID": "", "WardNumber": "", "Village": "", "Pincode": "", "CreatedOn": "", "CreatedBy": "", "ProblemTypeID": "", "DepartmentID": "", "isCreatedInFinesse": 0, "AssignedSSO": "", "IsAutoAssignedToSSO": 0, "ReasonForContact": "", "Status": "", "Remarks": "", "AssignedToSSOOn": "" };
    ucgObject.assignData = { "TicketID": 0, "DepartmentID": 0, "DepartmentUser": "", "Remarks": "", "LastModifiedOn": $filter('date')(new Date(), 'MM-dd-yyyy'), "LastModifiedBy": "currentUser" };
    ucgObject.updateData = { "TicketID": 0, "Status": "", "Remarks": "", "LastModifiedOn": $filter('date')(new Date(), 'MM-dd-yyyy'), "LastModifiedBy": "currentUser" };
    ucgObject.selectedUpdateData = { "currentStatus": '', "problemType": "", "department": ""};
    ucgObject.DepartmentList = [];
    ucgObject.DivisionList = [];
    ucgObject.DepartmentUserList = [];//---Changed 28 Nov 2017
    ucgObject.DistrictList = [];
    ucgObject.PanchayatList = [];
    ucgObject.BlockList = [];
    ucgObject.VillageList = [];
    // ucgObject.DataForNewTicket.SSONO = userObj.SSOID;
    ucgObject.ProblemType = [];
    ucgObject.myTicketData = [];
    ucgObject.userTicketData = [];
    ucgObject.assignTicketData = [];
    ucgObject.searchIndex = '';
    ucgObject.detailUpdateTicket = {};
    ucgObject.ticketFiles = [];
    ucgObject.dashboardFilter = {};
    ucgObject.closeTicket = '';
    ucgObject.TicketHistory = [];
    ucgObject.manualuploadfiles = {};
    ucgObject.filesToUpload = {
        size : 0,
        files: []
    };
    ucgObject.getDivisionList = getDivisionList;
    ucgObject.getDistrictList = getDistrictList;
    ucgObject.getPancheyatList = getPancheyatList;
    ucgObject.onSelectDepartment = onSelectDepartment;
    ucgObject.getBlockList = getBlockList;
    ucgObject.onUpdateTicketDetails = onUpdateTicketDetails;
    ucgObject.getDepartmentUser = getDepartmentUser;//---Changed 28 Nov 2017
    ucgObject.getVillageList = getVillageList;
    ucgObject.getProblemType = getProblemType;
    ucgObject.onClearTicketData = onClearTicketData;
    ucgObject.getDepartmentlist = getDepartmentlist;
    ucgObject.openCalendarDob = openCalendarDob;
    ucgObject.onCloseTicket = onCloseTicket;
    ucgObject.loadOpenTickets = loadOpenTickets;
    // ucgObject.ValidateSize = ValidateSize;
    ucgObject.openCalendarDate = openCalendarDate;
    ucgObject.getCompletedTickets = getCompletedTickets;
    ucgObject.onFilterAllTickets = onFilterAllTickets;
    ucgObject.onTypeSearchValues = onTypeSearchValues;
    ucgObject.onClearFilter = onClearFilter;
    ucgObject.createNewTicket = createNewTicket;
    ucgObject.onDeleteFile = onDeleteFile;
    ucgObject.loadAssignTicket = loadAssignTicket;
    ucgObject.onFilterInboxTickets = onFilterInboxTickets;
    ucgObject.loadMyTicket = loadMyTicket;
    ucgObject.loadUserTicket = loadUserTicket;
    ucgObject.assignTicket = assignTicket;
    ucgObject.onFilterMyTickets = onFilterMyTickets;
    ucgObject.onFilterTickets = onFilterTickets;
    ucgObject.onUploadFiles = onUploadFiles;
    ucgObject.onRefreshPage = onRefreshPage;
    ucgObject.assignTicketByL2User = assignTicketByL2User;
    ucgObject.validateDeptUser = validateDeptUser;
    ucgObject.updateUserTicket = updateUserTicket,
    ucgObject.onShowFilterPopup = onShowFilterPopup,
    ucgObject.onDownloadFile = onDownloadFile,
    ucgObject.loadL3DashboardTicket = loadL3DashboardTicket,
    ucgObject.reassignRejectedTickets = reassignRejectedTickets,
    ucgObject.onNavigateToDashboard = onNavigateToDashboard,
    ucgObject.loadL3TicketDeptTicket = loadL3TicketDeptTicket,
    ucgObject.getRejectedTicket = getRejectedTicket,
    ucgObject.calculateRemainingCharacter = calculateRemainingCharacter,
    ucgObject.SelectedTicketID = 0;
    ucgObject.myTicketOpen = 0;
    ucgObject.myTicketClosed = 0;
    ucgObject.myTicketCount =0;
    ucgObject.myTicketWIP = 0;
    ucgObject.userTicketOpen = 0;
    ucgObject.userTicketWIP = 0;
    ucgObject.userTicketClosed = 0;
    ucgObject.userTicketCount = 0;
    ucgObject.userTicketCompleted= 0;
    ucgObject.departName = '';
    ucgObject.userLevel = 0;
    ucgObject.isOpenDob = false;
    ucgObject.isOpenDate = false;
    //--change_06122017
    $scope.messageTextAlert = "";
    $scope.showMessageAlert = false;
    // Navil L3 Dashboard Tickets Changes Start
    ucgObject.loadL3DashboardTicket = loadL3DashboardTicket;
    ucgObject.l3DashboardTicketGridFormat = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        isValidUser: true,
        columnDefs: [
            { name: 'DepartmentName', isSearchable: true, field: 'DepartmentName' },
            { name: 'TotalTickets', isSearchable: true, cellTemplate: '<a href="#" ng-click="grid.appScope.viewL3DepartmentDetails($event,row.entity.DepartmentID,\'TotalTickets\');"> <span style="cursor: pointer" >{{COL_FIELD}}</span> </a>' },
            { name: 'Assigned To Dept', isSearchable: true,  cellTemplate: '<a href="#" ng-click="grid.appScope.viewL3DepartmentDetails($event,row.entity.DepartmentID,\'AssignedtoDept\');"><span style="cursor: pointer" >{{row.entity.AssignedtoDept}}</span> </a>' },
            { name: 'L1Tickets', isSearchable: true,  cellTemplate: '<a href="#" ng-click="grid.appScope.viewL3DepartmentDetails($event,row.entity.DepartmentID,\'L1Tickets\');"><span style="cursor: pointer" >{{COL_FIELD}}</span> </a>' },
            { name: 'EscalatedL2', isSearchable: true,  cellTemplate: '<a href="#" ng-click="grid.appScope.viewL3DepartmentDetails($event,row.entity.DepartmentID,\'EscalatedtoL2\');"><span style="cursor: pointer" >{{COL_FIELD}}</span></a>' },
            { name: 'EscalatedL3', isSearchable: true,  cellTemplate: '<a href="#" ng-click="grid.appScope.viewL3DepartmentDetails($event,row.entity.DepartmentID,\'EscalatedtoL3\');"> <span style="cursor: pointer" >{{COL_FIELD}}</span></a>' }
        ]
    };
    ucgObject.filterL3DeptTicket = filterL3DeptTicket;
    ucgObject.l3DeptTicketData = [];
    ucgObject.filterBy = "";
    ucgObject.l3FilterValue = "";
    ucgObject.loadL3DeptTicketGridFormat = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [
            { name: 'TicketId', field: 'TicketID', isSearchable: true, cellTooltip: true },
            { name: 'RegisteredPhone', field: 'RegisteredPhone', isSearchable: true, cellTooltip: true },
            { name: 'CreatedBy', field: 'AgentId', isSearchable: true, cellTooltip: true },
            { name: 'CreatedDate', field: 'CreatedDate', cellFilter: 'date:\'dd-MM-yy HH:mm\'', cellTooltip: true },
            { name: 'LastModifiedBy', field: 'LastModifiedBy', isSearchable: true, cellTooltip: true },
            { name: 'LastModifiedDate', field: 'LastModifiedOn', cellFilter: 'date:\'dd-MM-yy HH:mm\'', cellTooltip: true },
            { name: 'AssignedTo', field: 'AssignedSSO', isSearchable: true, cellTooltip: true },
            { name: 'Status', field: 'Status', isSearchable: true, cellTooltip: true },
            { name: 'Action',enableSorting: false,
            cellTemplate: '<a href="#" class="history-icon" ng-click="grid.appScope.myticketHistory($event, row.entity.TicketID,COL_FIELD)"><span class="fa fa-history" title="Ticket Histroy"></span></a>' +
            '| <a href="#" class="assign-icon" ng-click="grid.appScope.showDetailUpdateTicket(row.entity)"><span class="fa fa-user-plus" title="Update Ticket"></span></a>'
            }
        ]
    };
    ucgObject.loadL3DeptTicketByType = loadL3DeptTicketByType;
    // Navil L3 Dashboard Tickets Changes End
    ucgObject.ticketGridFormat = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        columnDefs: [
            { name: 'TicketId', field: 'TicketID', isSearchable: true,cellTooltip: true  },
            { name: 'CreatedOn', field: 'CreatedOn', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'',cellTooltip: true },
            { name: 'ProblemType', field: 'ProblemTypename', cellTooltip: true, isSearchable: true },
            { name: 'ReasonForContact', isSearchable: true, field: 'ReasonForContact', cellTooltip: true },
            { name: 'Department User', isSearchable: true,  field: 'assignedSSO', cellTooltip: true },//---Changed 28 Nov 2017
            { name: 'LastModifiedOn', field: 'LastModifiedOn', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'' },//---Changed 28 Nov 2017
            { name: 'LastAction', isSearchable: true,  field: 'LastAction', cellTooltip: true },//---Changed 28 Nov 2017
            { name: 'Status', isSearchable: true, field: 'Status', cellTooltip: true },
            { name: 'Action',enableSorting: false,
              cellTemplate: '<a href="#" class="history-icon" ng-click="grid.appScope.myticketHistory($event, row.entity.TicketID,COL_FIELD)"><span class="fa fa-history" title="Ticket Histroy"></span></a>'
            }
        ]
    };
    ucgObject.assignTicketGridFormat = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        columnDefs: [
                { name: 'TicketId', isSearchable: true, field: 'TicketID', cellTooltip: true },
                { name: 'CreatedOn', field: 'CreatedOn', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true },
                { name: 'ProblemType', isSearchable: true, field: 'ProblemTypeName', cellTooltip: true },
                { name: 'ReasonForContact', isSearchable: true,  field: 'ReasonForContact', cellTooltip: true },
                { name: 'Status', isSearchable: true, field: 'Status', cellTooltip: true },
                { name: 'Action',
                  cellTemplate: '<a href="#" class="history-icon" ng-click="grid.appScope.myticketHistory($event, row.entity.TicketID,COL_FIELD)"><span class="fa fa-history" title="Ticket Histroy"></span></a>' +
                                '| <a href="#" ng-if="grid.appScope.assignTickpermission.Modify" class="assign-icon" data-toggle="modal" data-target="#ucg-assign-popup" ng-disabled="row.entity.Status.toLowerCase().indexOf(grid.appScope.ticketStstus) == -1" ng-click="grid.appScope.assignTicketByL2(row.entity)"><span class="fa fa-user-plus" title="Assign Ticket"></span></a>' +
                                '<span ng-if="!grid.appScope.assignTickpermission.Modify" class="fa fa-user-plus" title="Assign Ticket" disabled></span>'
                }
            ]
        };
    
    ucgObject.columns=[
            { name: 'S.No', width: '5%', enableSorting: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            { name: 'TicketId', isSearchable: true, field: 'TicketID', cellTooltip: true },
            { name: 'RegisteredPhone', isSearchable: true,  field: 'RegisteredPhone', cellTooltip: true },
            { name: 'AgentId', isSearchable: true,  field: 'AgentID', cellTooltip: true },
            { name: 'CreatedDate', field: 'CreatedDate', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true},
            { name: 'Last Action', field: 'LastAction', isSearchable: true, cellTooltip: true},
            { name: 'Last Action On', field: 'LastModifiedOn', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true},
            { name: 'Last Action By', isSearchable: true,  field: 'L1User', cellTooltip: true },
            { name: 'Pending With', isSearchable: true,  field: 'L2User', cellTooltip: true },
            { name: 'Attachments Count', isSearchable: true,
                cellTemplate: '<a href="#" ng-if="grid.appScope.updateTickpermission.Modify" class="files-count" ng-click="grid.appScope.showFileUpload(row.entity.TicketID, true, true)">{{row.entity.FilesCount}}</a>'+
                              '<span ng-if="!grid.appScope.updateTickpermission.Modify" class="files-count" disabled> {{row.Entity.FilesCount}}</span>'
                ,cellTooltip: true },
            { name: 'Status', isSearchable: true, field: 'Status', cellTooltip: true  },
            { name: 'Action', width: '10%',
              cellTemplate: '<a href="#" class="history-icon" ng-click="grid.appScope.myticketHistory($event, row.entity.TicketID,COL_FIELD)"><span class="fa fa-history" title="Ticket Histroy"></span></a>' +
                            '| <a href="#" ng-if="grid.appScope.updateTickpermission.Modify" class="assign-icon" data-toggle="modal" data-target="#ucg-update-popup" ng-click="grid.appScope.updateTicket(row.entity, true)"><span class="fa fa-pencil-square-o" title="Update Ticket"></span></a>' +
                            '<span ng-if="!grid.appScope.updateTickpermission.Modify" class="fa fa-pencil-square-o" title="Update Ticket" disabled></span>'
                            // '| <a href="#" ng-if="grid.appScope.updateTickpermission.Modify" class="assign-icon" ng-click="grid.appScope.showFileUpload(row.entity)"><span class="fa fa-upload" title="File Upload"></span></a>' +
                            // '<span ng-if="!grid.appScope.updateTickpermission.Modify" class="fa fa-upload" title="File Upload" disabled></span>'
            }
        ]
        ucgObject.columnsTemplate = [
            { name: 'TicketId', isSearchable: true,  field: 'TicketID', cellTooltip: true  },
            { name: 'RegisteredPhone', isSearchable: true,  field: 'RegisteredPhone', cellTooltip: true },
            { name: 'AgentId', isSearchable: true, field: 'AgentID', cellTooltip: true },
            { name: 'CreatedDate', field: 'CreatedDate', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true  },
            { name: 'Actioned By', isSearchable: true,  field: 'L1User', cellTooltip: true },
            { name: 'Escalated To', isSearchable: true,  field: 'L2User', cellTooltip: true },
            { name: 'Status', isSearchable: true,  field: 'Status', cellTooltip: true  },
            { name: 'Action',
              cellTemplate: '<a href="#" class="history-icon" ng-click="grid.appScope.myticketHistory($event, row.entity.TicketID,COL_FIELD)"><span class="fa fa-history" title="Ticket Histroy"></span></a>' +
                            '| <a href="#" ng-if="grid.appScope.updateTickpermission.Modify" class="assign-icon" data-toggle="modal" data-target="#ucg-update-popup" ng-click="grid.appScope.updateTicket($event, row.entity.TicketID,row.entity.Status)"><span class="fa fa-pencil-square-o" title="Update Ticket"></span></a>' +
                            '<span ng-if="!grid.appScope.updateTickpermission.Modify" class="fa fa-pencil-square-o" title="Update Ticket" disabled></span>'
            }
        ];

        ucgObject.completedGridFormat = {
            enableColumnResizing: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            columnDefs: [
              { name: 'TicketId', isSearchable: true, field: 'TicketID', cellTooltip: true  },
              { name: 'CreatedBy', isSearchable: true, field: 'CreatedBy', cellTooltip: true },//--change_05122017
              { name: 'CreatedDate', field: 'CreatedON', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true  },
              { name: 'ProblemType', isSearchable: true, field: 'ProblemTypeName', cellTooltip: true },
              { name: 'Department', isSearchable: true, field: 'DepartmentName', cellTooltip: true },
              { name: 'ReasonForContact', isSearchable: true, field: 'ReasonForContact', cellTooltip: true },
              { name: 'LastModifiedOn', field: 'LastModifiedOn', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true  },//---Changed 28 Nov 2017
              { name: 'LastAction', isSearchable: true,  field: 'LastAction', cellTooltip: true },//---Changed 28 Nov 2017
              { name: 'Status', isSearchable: true, field: 'Status', cellTooltip: true  },
              { name: 'Action',
                cellTemplate: '<a href="#" class="history-icon" ng-click="grid.appScope.myticketHistory($event, row.entity.TicketID,COL_FIELD)"><span class="fa fa-history" title="Ticket Histroy"></span></a>' + 
                             '| <a href="#" data-toggle="modal" class="assign-icon"  data-target="#edit-popup" ng-if="grid.appScope.completeTickpermission.Modify" ng-click="grid.appScope.completeEdit(row.entity)"><span class="fa fa-pencil-square-o" title="Edit Ticket"></span></a>' + 
                             '<span ng-if="!grid.appScope.completeTickpermission.Modify" class="edit-hide-icon fa fa-pencil-square-o" style="font-size:16px" title="Edit Ticket"></span>'
              }
            ]
        };
    ucgObject.userTicketGridFormat= {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        columnDefs: ucgObject.columns,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }
    };
    ucgObject.rejectTicketGridFormat = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        isValidUser : true,
        columnDefs: [
          { name: 'TicketId', isSearchable: true, field: 'TicketID', cellTooltip: true  },
          { name: 'CustomerName', isSearchable: true,  field: 'Customername', cellTooltip: true },
          { name: 'CreatedBy', isSearchable: true,  field: 'CreatedBy', cellTooltip: true },//--change_05122017
          { name: 'CreatedDate', field: 'CreatedON', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true  },
          { name: 'ProblemType', isSearchable: true,  field: 'ProblemTypeName', cellTooltip: true  },
          { name: 'Department', isSearchable: true,  field: 'DepartmentName', cellTooltip: true  },
          { name: 'LastModifiedOn', field: 'LastModifiedOn', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true  },//---Changed 28 Nov 2017
         { name: 'LastAction', isSearchable: true,  field: 'LastAction', cellTooltip: true },//---Changed 28 Nov 2017
          { name: 'ReasonForContact', isSearchable: true,  field: 'ReasonForContact', cellTooltip: true },
          { name: 'Action',
            cellTemplate: '<a href="#" data-toggle="modal" class="history-icon" data-target="#history-popup" ng-click="grid.appScope.myticketHistory($event, row.entity.TicketID,COL_FIELD)"><span class="fa fa-history" title="Ticket Histroy"></span></a>' +
                          '| <a href="#" ng-if="grid.appScope.rejectTickpermission.Modify" class="assign-icon" data-toggle="modal" data-target="#ucg-assign-popup" ng-click="grid.appScope.assign(row.entity)"><span class="fa fa-user" title="Assign Ticket"></span></a>' +
                          '<span ng-if="!grid.appScope.rejectTickpermission.Modify" class="fa fa-user-plus" title="Assign Ticket" disabled></span>'
          }
        ]
    };

    ucgObject.openTicketsGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        columnDefs: [
          { name: 'TicketId', isSearchable: true, field: 'TicketID', cellTooltip: true  },
          { name: 'Department', isSearchable: true, field: 'DepartmentName', cellTooltip: true  },
          { name: 'Created By', isSearchable: true, field: 'CreatedBy', cellTooltip: true  },
          { name: 'Assigned SSO', isSearchable: true, field: 'AssignedSSO', cellTooltip: true  },
          { name: 'Status', isSearchable: true, field: 'Status', cellTooltip: true },
          { name: 'ProblemType', isSearchable: true, field: 'ProblemTypeName', cellTooltip: true  },
          { name: 'Reason For Contact', isSearchable: true, field: 'ReasonForContact', cellTooltip: true },
        //   { name: 'Created By', field: 'CreatedBy', cellTooltip: true },
          { name: 'Created Date', field: 'CreatedOn', cellFilter: 'date:\'dd/MM/yyyy HH:mm\'', cellTooltip: true  },
          { name: 'History',enableSorting: false,
              cellTemplate: '<a href="#" class="history-icon" ng-click="grid.appScope.myticketHistory($event, row.entity.TicketID,COL_FIELD)"><span class="fa fa-history" title="Ticket Histroy"></span></a>'
            }
        ]
    };
    $scope.ticketStstus = 'open';

    $scope.assignTicket = function (event, ticketID, data) {
        //cmsObject.assignData = { "TicketID": 0, "ProblemTypeID": 0, "DepartmentID": 0, "DepartmentUser": "", "Remarks": "", "LastModifiedOn": $filter('date')(new Date(), 'MM-dd-yyyy'), "LastModifiedBy": "currentUser" };
        ucgObject.assignData.TicketID = ticketID;
        for (var i = 0; i < ucgObject.ticketGridFormat.data.length; i++) {
            if (ucgObject.ticketGridFormat.data[i].TicketID == ticketID) {
                ucgObject.assignData.DepartmentID = ucgObject.ticketGridFormat.data[i].DepartmentID;
                ucgObject.assignData.DepartmentName = getDeparmetById(ucgObject.ticketGridFormat.data[i].DepartmentID).DepartmentName;
                ucgObject.assignData.ProblemTypeName = ucgObject.ticketGridFormat.data[i].ProblemTypename;
                ucgObject.assignData.DepartmentUser = '';
                ucgObject.assignData.Remarks = '';
                getDepartmentUser('assign');//---Changed 28 Nov 2017
                break;
            }
        }
    }

    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        e.preventDefault();
        e.stopPropagation();
        $scope.open = {};
        $scope.open[date] = true;
    };

    var getDeparmetById = function(deptID) {
        var deptObj = {};
        ucgObject.DepartmentList.forEach(dept => {
            if (dept.DepartmentID === deptID) {
                deptObj = dept;
            }
        })
        return deptObj;
    };
    var getProblemTypeById = function(problemTypeId) {
        var problemObj = {};
        ucgObject.ProblemType.forEach(problem => {
            if (problem.ProblemTypeID === problemTypeId) {
                problemObj = problem;
            }
        })
        return problemObj;
    };
    // switch flag
    $scope.switchBool = function (value) {
        $scope[value] = !$scope[value];
    };

    $scope.showDetailUpdateTicket = function(row) {
        ucgObject.detailUpdateTicket = {};
        // $scope.action = 'TICKET';
        ucgObject.detailUpdateTicket = angular.copy(row);
        ucgObject.filesToUpload.ticketId = ucgObject.detailUpdateTicket.TicketID;
        getTicketFiles(ucgObject.detailUpdateTicket.TicketID);
        ucgObject.detailUpdateTicket.Department = getDeparmetById(ucgObject.detailUpdateTicket.DepartmentID);
        ucgObject.detailUpdateTicket.AssignedSSO = ucgObject.detailUpdateTicket.AssignedSSO.trim();
        ucgObject.getProblemType(ucgObject.detailUpdateTicket.DepartmentID, cbShowDetailUpdateTicket);
        ucgObject.detailUpdateTicket.Status = row.Status.trim();
        if (ucgObject.detailUpdateTicket.ProblemTypename) {
            ucgObject.detailUpdateTicket.ProblemTypename = ucgObject.detailUpdateTicket.ProblemTypename.trim();
        }
    };

    var cbShowDetailUpdateTicket = function() {
        $scope.showMessageAlert = false;
        $('#detail-update-popup').modal('show');
        ucgObject.detailUpdateTicket.ProblemType = getProblemTypeById(ucgObject.detailUpdateTicket.ProblemTypeID);
    }

    function onUpdateTicketDetails() {
        var udpatedTicket = {
            TicketID: ucgObject.detailUpdateTicket.TicketID,
            ProblemTypeID : ucgObject.detailUpdateTicket.ProblemType.ProblemTypeID,
            ProblemTypeName : ucgObject.detailUpdateTicket.NewProblemType,
            DepartmentID : ucgObject.detailUpdateTicket.Department.DepartmentID,
            DepartmentUser : ucgObject.detailUpdateTicket.AssignedSSO,
            Remarks : ucgObject.detailUpdateTicket.Remarks,
            Status : (ucgObject.detailUpdateTicket.Status === 'Closed') ? 'Closed' : ucgObject.detailUpdateTicket.updatedStatus,
            LastModifiedBy : ucgObject.ssoId,
            LastModifiedOn : moment().format('YYYY-MM-DD HH:mm:ss'),
        }
        appFactory.ShowLoader();
        if (udpatedTicket.Status === 'Closed') {
            updateCompletedTicketDetails(udpatedTicket);
        } else {
            updateTicketDetails(udpatedTicket);
        }
    };

    var cbsUpdateTicketDetails = function(res) {
        if (res == 200) {
            ucgObject.detailUpdateTicket = {};
            appFactory.HideLoader();
            appFactory.showSuccess('Ticket updated sucessfully');
            $('#detail-update-popup').modal('hide');
            ucgObject.loadL3TicketDeptTicket();
        }
        else {
            appFactory.HideLoader();
            appFactory.showError('Error occured: Server unreachable.');
        }
    };

    var updateTicketDetails = function(payload) {
        UCGService.updateTicket(payload, cbsUpdateTicketDetails);
    };

    var updateCompletedTicketDetails = function(payload) {
        UCGService.updateUserTicket(payload, cbsUpdateTicketDetails);
    };

    $scope.assignTicketByL2 = function (row) {
        //cmsObject.assignData = { "TicketID": 0, "ProblemTypeID": 0, "DepartmentID": 0, "DepartmentUser": "", "Remarks": "", "LastModifiedOn": $filter('date')(new Date(), 'MM-dd-yyyy'), "LastModifiedBy": "currentUser" };
        ucgObject.assignData.TicketID = row.TicketID;
        ucgObject.assignData.DepartmentID = row.DepartmentID;
        ucgObject.assignData.ProblemTypeName = row.ProblemTypeName;
        ucgObject.assignData.DepartmentName = getDeparmetById(row.DepartmentID).DepartmentName;
        ucgObject.assignData.DepartmentUser = '';
        ucgObject.assignData.Remarks = '';
        getDepartmentUser('assign');//---Changed 28 Nov 2017
    }

    $scope.completeEdit = function(rowData) {
        ucgObject.closeTicket = {
            TicketID: rowData.TicketID,
            problemType: rowData.ProblemTypeName,
            DepartmentName: rowData.DepartmentName,
            DepartmentID: rowData.DepartmentID,
            ProblemTypeID: rowData.ProblemTypeID
        }
        // ucgObject.closeTicket = closeTicketObj;
    };

    function onCloseTicket() {
        ucgObject.closeTicket.LastModifiedBy = ucgObject.ssoId;//---Changed 28 Nov 2017
        ucgObject.closeTicket.LastModifiedOn = moment().format('YYYY-MM-DD HH:mm:ss');
        UCGService.updateUserTicket(ucgObject.closeTicket, function (data) {
            if (data == 200) {
                appFactory.showSuccess('Ticket update sucessful.');
                getCompletedTickets();
            }
            else {
                appFactory.showError('Error occured: Server unreachable.');
            }

        });

    } 

    var getOpenTicketByDepartment = function(departmentId) {
        UCGService.getOpenTickets(departmentId, function (data) {
            if (data && data.Status == 200) {
                ucgObject.openTicketsGrid.data = data.OpenTicketDetail;
                getSearchableFields(ucgObject.openTicketsGrid);
                appFactory.HideLoader();
            }
            else {
                errCallBack();
            }
        });
    };

    function loadOpenTickets() {
        appFactory.ShowLoader();
        UCGService.getUserBySSOID(userObj.SSOID,
            function (data) {
                var departmentID = userObj.departmentId;
                if (data && data.length) {
                    var user = data[0];
                    if (user.Level === 3) {
                        departmentID = -1 ;
                    }
                }
                getOpenTicketByDepartment(departmentID);
            },
            function () {
                errCallBack();
            }
        );
        
    };

    $scope.updateTicket = function (row) {
        // $scope.action = 'TICKET';
        ucgObject.updateData.TicketID = row.TicketID;
        ucgObject.selectedUpdateData.currentStatus = row.Status;
        ucgObject.selectedUpdateData.problemType = row.ProblemTypename;
        ucgObject.selectedUpdateData.DepartmentName = row.DepartmentName;
        //ucgObject.updateData.DepartmentUser = '';
        ucgObject.updateData.Remarks = '';
        ucgObject.updateData.Status = '';
        $scope.showFileUpload(row.TicketID, true);
    }
    function onClearTicketData() {
        ucgObject.DataForNewTicket = { "CallingPhone": "", "RegisteredPhone": "", "Firstname": "", "LastName": "", "DOB": "", "Gender": "", "EmailId": "", "SSONO": "", "DivisionID": "", "DistrictID": "", "BlockID": "", "PanchayatID": "", "WardNumber": "", "Village": "", "Pincode": "", "CreatedOn": "", "CreatedBy": "", "ProblemTypeID": "", "DepartmentID": "", "isCreatedInFinesse": 0, "AssignedSSO": "", "IsAutoAssignedToSSO": 0, "ReasonForContact": "", "Status": "", "Remarks": "", "AssignedToSSOOn": "" };
        ucgObject.DataForNewTicket.SSONO = userObj.SSOID;
    };
    function updateUserTicket() {
        ucgObject.updateData.LastModifiedBy = ucgObject.ssoId;//---Changed 28 Nov 2017
        ucgObject.updateData.LastModifiedOn = moment().format('YYYY-MM-DD HH:mm:ss');
        UCGService.updateUserTicket(ucgObject.updateData, function (data) {
            if (data == 200) {
                appFactory.showSuccess('Ticket update sucessful.');
                loadUserTicket();
            }
            else {
                // appFactory.showError('Error occured: Server unreachable.');
            }

        });

    }

    
    function assignTicket() {
        ucgObject.assignData.LastModifiedBy = ucgObject.ssoId;//---Changed 28 Nov 2017
        ucgObject.assignData.LastModifiedOn = moment().format('YYYY-MM-DD HH:mm:ss');
        UCGService.assignTicket(ucgObject.assignData, function (data) {
            if (data == 200) {
                appFactory.showSuccess('Ticket assignment sucessful.');
                loadMyTicket();
            }
            else {
            }

        });
    }

    function assignTicketByL2User() {
        ucgObject.assignData.LastModifiedBy = ucgObject.ssoId;//---Changed 28 Nov 2017
        ucgObject.assignData.LastModifiedOn = moment().format('YYYY-MM-DD HH:mm:ss');
        UCGService.assignTicketByL2(ucgObject.assignData, function (data) {
            if (data == 200) {
                appFactory.showSuccess('Ticket assignment sucessful.');
                loadAssignTicket();
            }
            else {
                appFactory.showError('Error occured: Server unreachable.');
            }

        });
    }


    $scope.myticketHistory = function (event, ticketID, data) {
        appFactory.ShowLoader();
        ucgObject.SelectedTicketID = ticketID;
        // $scope.action = 'HISTORY';
        $scope.showFileUpload(ticketID, true);
        UCGService.getTicketHistory(ticketID, function (data) {
            if (data.Status == 200) {
                ucgObject.TicketHistory = data;
                appFactory.HideLoader();
                $('#history-popup').modal('show');
            }
            else {
                errCallBack();
            }
        });

    }
    function calculateRemainingCharacter() {
        var remarksCount = (ucgObject.DataForNewTicket.Remarks) ?
                            1000 - ucgObject.DataForNewTicket.Remarks.length : 1000;
        ucgObject.DataForNewTicket.remarksRemainingCount = remarksCount;
    };

    // Navil L3 Dashboard Tickets Changes Start
    function loadL3DashboardTicket() {
        appFactory.ShowLoader();
        validateUser();
    };

    var validateUser = function() {
        UCGService.getUserBySSOID(userObj.SSOID,
            function (data) {
                if (data && data.length) {
                    var user = data[0];
                    if (user.Level === 2) {
                        getDashboardForL2User();
                        ucgObject.l3DashboardTicketGridFormat.isValidUser = true;
                    } else if (user.Level === 3) {
                        getDashboardForL3User();
                        ucgObject.l3DashboardTicketGridFormat.isValidUser = true;
                    } else {
                        ucgObject.l3DashboardTicketGridFormat.isValidUser = false;
                        appFactory.HideLoader();
                    }
                } else {
                    ucgObject.l3DashboardTicketGridFormat.isValidUser = false;
                    appFactory.HideLoader();
                }
            },
            function () {
                errCallBack();
            }
        );
    };

    var getDashboardForL3User = function() {
        ucgObject.l3DashboardTicketGridFormat.data = [];
        UCGService.getL3DashboardTickets(function (data) {
            if (data && data.Status == 200) {
                ucgObject.l3DashboardTicketGridFormat.data = data.L3DashBoard;
                getSearchableFields(ucgObject.l3DashboardTicketGridFormat);
                appFactory.HideLoader();
            }
            else {
                errCallBack();
            }
        });
    };

    var getDashboardForL2User = function() {
        ucgObject.l3DashboardTicketGridFormat.data = [];
        UCGService.getL2DashboardTickets(userObj.departmentId, function (data) {
            if (data && data.Status == 200) {
                ucgObject.l3DashboardTicketGridFormat.data = data.L2DashBoard;
                getSearchableFields(ucgObject.l3DashboardTicketGridFormat);
                appFactory.HideLoader();
            }
            else {
                errCallBack();
            }
        });
    };

    $scope.viewL3DepartmentDetails = function (event, departmentId, filter) {
        if(departmentId !="" && filter !=""){
            $location.path('/cms/dashboard-detail/'+departmentId+'/'+filter);    
        }
    }
    function loadL3DeptTicketByType($event,type) {
        ucgObject.loadL3DeptTicketGridFormat.data = [];
        elem = angular.element($event.currentTarget);
        elem.addClass('active');
        ucgObject.filterBy = type;
        ucgObject.l3FilterValue = "";
        filterL3Tickets(type);
        $scope.gridApi1.grid.refresh();
    }

    var getL3UserTickets = function() {
        ucgObject.loadL3DeptTicketGridFormat.data = [];
        ucgObject.filterBy = $routeParams.filter;
        var deptID = $routeParams.deptId;
        UCGService.getL3DashboardDetails(deptID,function (data) {
            if (data && data.Status == 200) {
                ucgObject.l3DeptTicketData = data.L3DashBoardInDetail;
                ucgObject.loadL3DeptTicketGridFormat.data = ucgObject.l3DeptTicketData;
                filterL3Tickets($routeParams.filter);
                appFactory.HideLoader();
            }
            else {
                errCallBack();
            }
        });
    };

    
    var getL2UserTickets = function() {
        ucgObject.loadL3DeptTicketGridFormat.data = [];
        ucgObject.filterBy = $routeParams.filter;
        UCGService.getL2DashboardDetails(userObj.departmentId,function (data) {
            if (data && data.Status == 200) {
                ucgObject.l3DeptTicketData = data.L2DashBoardInDetail;
                ucgObject.loadL3DeptTicketGridFormat.data = ucgObject.l3DeptTicketData;
                getSearchableFields(ucgObject.loadL3DeptTicketGridFormat);
                filterL3Tickets($routeParams.filter);
                appFactory.HideLoader();
            }
            else {
                errCallBack();
            }
        });
    };

    function loadL3TicketDeptTicket() {
        appFactory.ShowLoader();
        getDepartmentlist(cbsLoadL3Tickets);
    };

    var cbsLoadL3Tickets = function() {
        ucgObject.departName = getDeparmetById(Number($routeParams.deptId)).DepartmentName;
        UCGService.getUserBySSOID(userObj.SSOID,
            function (data) {
                if (data && data.length) {
                    var user = data[0];
                    if (user.Level === 2) {
                        getL2UserTickets();
                    } else if (user.Level === 3) {
                        getL3UserTickets();
                    }
                    ucgObject.departName = getDeparmetById(Number($routeParams.deptId)).DepartmentName;
                } else {
                    ucgObject.loadL3DeptTicketGridFormat.isValidUser = false;
                    appFactory.HideLoader();
                }
            },
            function () {
                errCallBack();
            }
        );
    }

    var validateDepartmentHead = function() {
        UCGService.getUserBySSOID(userObj.SSOID,
            function (data) {
                if (data && data.length) {
                    var user = data[0];
                    if (user.Level === 2 || user.Level === 3) {
                        getRejectedTickets(user.Level);
                        ucgObject.rejectTicketGridFormat.isValidUser = true;
                    } else {
                        ucgObject.rejectTicketGridFormat.isValidUser = false;
                        appFactory.HideLoader();
                    }
                } else {
                    ucgObject.rejectTicketGridFormat.isValidUser = false;
                    appFactory.HideLoader();
                }
            },
            function () {
                alert('Error occured: Server unreachable.');
            }
        );
    };

    var getRejectedTickets = function(level) {
        UCGService.getRejectedTicket(userObj.departmentId, level,  function (data) {
            if (data && data.Status == 200) {
                ucgObject.rejectTicketGridFormat.data = data.RejectedTicketDetails;
                getSearchableFields(ucgObject.rejectTicketGridFormat);
                appFactory.HideLoader();
            } else {
                errCallBack();
            }
 
        });
    };

    function getRejectedTicket() {
        appFactory.ShowLoader();
        validateDepartmentHead();
    }

    $scope.assign = function (rowData) {
        ucgObject.assignData = {};
        ucgObject.assignData.TicketID = rowData.TicketID;
        ucgObject.assignData.DepartmentID = rowData.DepartmentID;
        ucgObject.assignData.DepartmentName = rowData.DepartmentName;
        ucgObject.assignData.ProblemTypeName = rowData.ProblemTypeName;
        ucgObject.assignData.DepartmentUser = '';
        ucgObject.assignData.Remarks = '';
        $scope.showMessageAlert = false;
        $scope.messageTextAlert = '';
    };

    function reassignRejectedTickets() {
        ucgObject.assignData.LastModifiedBy = ucgObject.ssoId;//---Changed 28 Nov 2017
        ucgObject.assignData.LastModifiedOn = moment().format('YYYY-MM-DD HH:mm:ss');
        UCGService.reassignRejectedTickets(ucgObject.assignData, function (data) {
            if (data == 200) {
                appFactory.showSuccess('Ticket Assigned Succssfully');
                getRejectedTicket();
            }
            else {
                appFactory.showError('Error occured: Server unreachable.');
            }

        });
    };


    function filterL3Tickets(filterBy){
        ucgObject.loadL3DeptTicketGridFormat.summary = {};
        if(filterBy !="TotalTickets"){
            ucgObject.loadL3DeptTicketGridFormat.data = $filter('filter')(ucgObject.l3DeptTicketData, {TicketType: filterBy});
        } else {
            ucgObject.loadL3DeptTicketGridFormat.data = ucgObject.l3DeptTicketData;
        }
        ucgObject.loadL3DeptTicketGridFormat.origFilteredTickets = ucgObject.loadL3DeptTicketGridFormat.data;
        getSearchableFields(ucgObject.loadL3DeptTicketGridFormat);
        ucgObject.loadL3DeptTicketGridFormat.origData = ucgObject.loadL3DeptTicketGridFormat.origFilteredTickets;
        getSummaryOfL3Tickets();
    }

    var getSummaryOfL3Tickets = function() {
        var summary = {
            open: 0,
            closed: 0,
            rejected: 0,
            wip: 0,
            completed: 0,
            rejected: 0,
            total: 0,
        }
        if (ucgObject.loadL3DeptTicketGridFormat.data && ucgObject.loadL3DeptTicketGridFormat.data.length) {
            ucgObject.loadL3DeptTicketGridFormat.data.forEach(function(ticket) {
                var status = ticket.Status.trim().toLowerCase();
                summary[status] = summary[status] + 1;
            });
            summary.total =  ucgObject.loadL3DeptTicketGridFormat.data.length;
        }
        ucgObject.loadL3DeptTicketGridFormat.summary = summary;
    };

    function filterL3DeptTicket() {
        $scope.gridApi1.grid.refresh();
    }
    $scope.l3RowFilter = function( renderableRows ){
        var matcher = new RegExp(ucgObject.l3FilterValue);
        renderableRows.forEach( function( row ) {
          var match = false;
          [ 'TicketID', 'RegisteredPhone', 'AgentId', 'Status' ].forEach(function( field ){
            if ( String(row.entity[field]).match(matcher) ){
              match = true;
            }
          });
          if ( !match ){
            row.visible = false;
          }
        });
        return renderableRows;
    };
    // Navil L3 Dashboard Tickets Changes End
    function onShowFilterPopup() {
        $('#filter-popup').modal('show');
    };

    $scope.showFileUpload = function(ticketID, isOnlyDownload, showPopUp) {
        ucgObject.filesToUpload.ticketId = ticketID;
        ucgObject.filesToUpload.isOnlyDownload = isOnlyDownload;
        getTicketFiles(ticketID, showPopUp);
        // $('#file-upload-popup').modal('show');
    };

    var getTicketFiles = function(ticketId, showPopUp) {
        appFactory.ShowLoader();
        UCGService.getTicketFiles(ticketId, function (data) {
            if (data) {
                ucgObject.ticketFiles = data;
                if (showPopUp) {
                    $('#file-upload-popup').modal('show');
                }
                appFactory.HideLoader();
            }
            else {
                errCallBack();
                // appFactory.showError('Error occured: Server unreachable.');
            }
        });
    };

    var isValidFileFormats = function() {
        var fileNames = _.map(ucgObject.filesToUpload.files, function(key) {
                            if (key.name) {return key.name;}
                        });
        var validFormats = ['xls', 'xlsx', 'csv', 'txt', 'pdf', 'wav','jpg'];
        var isValidFileFormat = true;
        fileNames.forEach(function(fileName) {
            var isValidFormat = $filter('validfile')(fileName, validFormats);
            if (!isValidFormat) {
                isValidFileFormat = false;
            }
        });
        return isValidFileFormat;
    };

    var invalidFileFormts = function() {
        appFactory.showToasterErr('Invalid File Formats');
        ucgObject.manualuploadfiles = {};
        ucgObject.filesToUpload.size = 0;
        ucgObject.filesToUpload.files = [];
        ucgObject.filesToUpload.hasInvalidFiles = true;
        $('#file-upload').val('');
    };

    function onUploadFiles(hideToaster) {
        if (!ucgObject.filesToUpload.files.length) {
            appFactory.showToasterErr('Please select files to upload');
            return;
        }
        ucgObject.filesToUpload.hasInvalidFiles = false;
        var isValidFileFormat = isValidFileFormats();
        if (!isValidFileFormat) {
            invalidFileFormts();
            return;
        }
        appFactory.ShowLoader();
        var formData = new FormData();
        formData.append("uploadedBy",userObj.SSOID);
        formData.append("ticketId", ucgObject.filesToUpload.ticketId);
        ucgObject.filesToUpload.files.forEach(function(file) {
            formData.append("manualUpload", file);
        });
        UCGService.uploadFiles(formData).then(function (data) {
            if (data && data.data.Message === 'Success') {
                if (!hideToaster) {
                    appFactory.showSuccess('Files successfully uploaded');
                }
                $('#file-upload').val('');
                ucgObject.filesToUpload.size = 0;
                ucgObject.filesToUpload.files = [];
                ucgObject.manualuploadfiles = {};
                getTicketFiles(ucgObject.filesToUpload.ticketId);
                ucgObject.loadUserTicket();
                appFactory.HideLoader();
            } else {
                appFactory.showToasterErr('Error occured: Server unreachable');
                appFactory.HideLoader();
            }
        });
    };

    function onDownloadFile(file) {
        var origFileName = file.OrginalFileName;
        // var fileName = origFileName.slice(0, origFileName.indexOf('(')).trim();
        // fileName = fileName + origFileName.slice(origFileName.indexOf('.'), origFileName.length);
        UCGService.downloadFile(file.FileName, origFileName);
    };

    function onDeleteFile(file) {
        UCGService.deleteFile(file.ID, function (data) {
            if (data === 'Success') {
                appFactory.showSuccess('Files Deleted Successfully');
                getTicketFiles(ucgObject.filesToUpload.ticketId);
                ucgObject.loadUserTicket();
            } else {
                appFactory.showToasterErr('Error while Deleting');
            }
        })
    };

    function onClearFilter(isInbox) {
        ucgObject.dashboardFilter = {};
        filterTicketsByFilter(isInbox);
    };
    var filterTicketsByFilter = function(isInbox) {
        ucgObject.searchIndex = '';
        var origData = (!isInbox) ? angular.copy(ucgObject.loadL3DeptTicketGridFormat.origFilteredTickets) :
                                    angular.copy(ucgObject.userTicketGridFormat.filteredData);
        var filteredData = filterTickets(origData);
        if (isInbox) {
            ucgObject.userTicketGridFormat.data = filteredData;
        } else {
            ucgObject.loadL3DeptTicketGridFormat.data = filteredData;
        }
    }
    function onFilterTickets(isInbox) {
        filterTicketsByFilter(isInbox);
    };

    $scope.validateFile = function validateFile(fiels) {
        var fiels = angular.copy({}, fiels);
        if (!fiels || !fiels.length) {
            return;
        }
        var addedFilesSize = 0;
        var isFileAlreatExist = false;
        var addedFilesNames = [];
        if (ucgObject.filesToUpload.files.length) {
            addedFilesNames = _.map(ucgObject.filesToUpload.files, function(key) {
                if (key.name) {
                    return key.name;
                }
            });
            // addedFilesNames = _.map(ucgObject.filesToUpload.files, 'name');
        }
        if (ucgObject.ticketFiles.length) {
            uploadedFileNames = _.map(ucgObject.ticketFiles, function(key) {
                if (key.OrginalFileName) {
                    return key.OrginalFileName;
                }
            });
            // var uploadedFileNames = _.map(ucgObject.ticketFiles, 'OrginalFileName');
            addedFilesNames.push(uploadedFileNames);
        }
        _.forEach(fiels, function(addedFile) {
            addedFilesSize = addedFilesSize + addedFile.size;
            if (addedFilesNames && addedFilesNames.length) {
                var addedFileindex = _.indexOf(addedFilesNames, addedFile.name);
                if (addedFileindex > -1) {
                    isFileAlreatExist = true;
                }
            };
        });
        addedFilesSize = addedFilesSize + ucgObject.filesToUpload.size; 
        var fileSize = addedFilesSize / 1024 / 1024// in MB
        if ((fileSize > 150) || isFileAlreatExist) {
            var errMsg = (!isFileAlreatExist) ? 'File size exceeds 150 MB' : 'File already added'
            appFactory.showToasterErr(errMsg);
            $('#file-upload').val('');
            ucgObject.manualuploadfiles = {};
            return;
        }
        ucgObject.filesToUpload.size = addedFilesSize;
        _.forEach(fiels, function(addedFile) {
            var addedFileName = addedFile.name.replace(' ', '');
            if (addedFileName.indexOf('(') > -1 && addedFileName.indexOf(')') > -1) {
                var extension = addedFileName.split('.')[1];
                addedFileName = addedFileName.slice(0, addedFileName.indexOf('(')) + '.' + extension; 
            }
            var modifiedFile = new File([addedFile], addedFileName, {type:addedFile.type});
            ucgObject.filesToUpload.files.push(modifiedFile);
        })
    };

    var filterTickets = function(origData) {
        var filteredTickets = [];
        var filter = ucgObject.dashboardFilter;
        if (_.isEmpty(filter)) {
            return origData;
        }
        origData.forEach(function(ticket) {
            var isMatched = false;
            if (filter.ticketId) {
                isMatched = isMatched | (ticket.TicketID.toString().trim().toLowerCase().indexOf(filter.ticketId.toLowerCase()) > -1);
            } else if (filter.phone) {
                isMatched = isMatched | (ticket.RegisteredPhone.toString().trim().toLowerCase().indexOf(filter.phone.toLowerCase()) > -1);
            } else if (filter.agentId) {
                isMatched = isMatched | (ticket.AgentId.toString().trim().toLowerCase().indexOf(filter.agentId.toLowerCase()) > -1);
            } else if (filter.status) {
                isMatched = isMatched | (ticket.Status.toString().trim().toLowerCase().indexOf(filter.status.toLowerCase()) > -1);
            } else if (filter.createdDate) {
                isMatched = isMatched | (moment(moment(ticket.CreatedDate).format('MM-DD-YY')).isSame(moment(filter.createdDate)));
            } else if (filter.lastModifiedDate) {
                isMatched = isMatched | (moment(moment(ticket.LastModifiedOn).format('MM-DD-YY')).isSame(moment(filter.lastModifiedDate))); 
            }
            if (isMatched) {
                filteredTickets.push(ticket);
            }
        });
        return filteredTickets;
    }; 
    
    function loadAssignTicket() {
        appFactory.ShowLoader();
        ucgObject.ticketGridFormat.data = [];

        UCGService.getAssignTicket(ucgObject.ssoId, function (data) {
            if (data && data.Status == 200) {
                ucgObject.assignTicketData = data;
                ucgObject.assignTicketGridFormat.data = ucgObject.assignTicketData.OpenTicketDetail;
                getSearchableFields(ucgObject.assignTicketGridFormat);
                appFactory.HideLoader();
            }
            else {
                appFactory.HideLoader();
            }
        });

    }

    function onNavigateToDashboard() {
        $location.path('/cms/dashboard');    
    };



    function loadMyTicket() {
        appFactory.ShowLoader();
        ucgObject.ticketGridFormat.data = [];
        ucgObject.myTicketOpen = 0;
        ucgObject.myTicketClosed = 0;
        ucgObject.myTicketCount = 0;
        ucgObject.myTicketWIP = 0;
        ucgObject.myTicketRejected = 0;

        UCGService.myticket(ucgObject.ssoId,function (data) {
            if (data && data.Status == 200) {
                ucgObject.myTicketData = data;
                for (var i = 0; i < ucgObject.myTicketData.MyTicketDashboard.length; i++) {
                    if (ucgObject.myTicketData.MyTicketDashboard[i].status.toLowerCase().indexOf('open')>-1) {
                        ucgObject.myTicketOpen = ucgObject.myTicketData.MyTicketDashboard[i].TicketCount;
                    } 
                    else if (ucgObject.myTicketData.MyTicketDashboard[i].status.toLowerCase().indexOf('wip')>-1) {
                        ucgObject.myTicketWIP = ucgObject.myTicketData.MyTicketDashboard[i].TicketCount;
                    } 
                    else if (ucgObject.myTicketData.MyTicketDashboard[i].status.toLowerCase().indexOf('rejected')>-1) {
                        ucgObject.myTicketRejected = ucgObject.myTicketData.MyTicketDashboard[i].TicketCount;
                    } 
                    else if (ucgObject.myTicketData.MyTicketDashboard[i].status.toLowerCase().indexOf('close')>-1) {
                        ucgObject.myTicketClosed = ucgObject.myTicketData.MyTicketDashboard[i].TicketCount;
                    } 
                    ucgObject.myTicketCount = ucgObject.myTicketData.MyTicketDetail.length;
                    
                }
                ucgObject.ticketGridFormat.data = ucgObject.myTicketData.MyTicketDetail;
                ucgObject.ticketGridFormat.origData = ucgObject.myTicketData.MyTicketDetail;
                
                getSearchableFields(ucgObject.ticketGridFormat);
                appFactory.HideLoader();
            }
            else {
                errCallBack();
            }
        });

    }





    function loadUserTicket() {
        appFactory.ShowLoader();
        ucgObject.userTicketGridFormat.data = [];
        ucgObject.userTicketOpen = 0;
        ucgObject.userTicketClosed = 0;
        ucgObject.userTicketCount = 0;
        ucgObject.userTicketWIP = 0;
        ucgObject.userTicketCompleted = 0;
        UCGService.userticket(ucgObject.updatessoId, function (data) {
            if (data && data.Status == 200) {
                ucgObject.userTicketData = data;
                for (var i = 0; i < ucgObject.userTicketData.UserTcketsDashBoard.length; i++) {
                    if (ucgObject.userTicketData.UserTcketsDashBoard[i].status.toLowerCase().indexOf('open') > -1) {
                        ucgObject.userTicketOpen = ucgObject.userTicketData.UserTcketsDashBoard[i].TicketCount;
                    }
                    else if (ucgObject.userTicketData.UserTcketsDashBoard[i].status.toLowerCase().indexOf('complete') > -1) {
                        ucgObject.userTicketCompleted = ucgObject.userTicketData.UserTcketsDashBoard[i].TicketCount;
                    }
                    else if (ucgObject.userTicketData.UserTcketsDashBoard[i].status.toLowerCase().indexOf('close') > -1) {
                        ucgObject.userTicketClosed = ucgObject.userTicketData.UserTcketsDashBoard[i].TicketCount;
                    }
                    else if (ucgObject.userTicketData.UserTcketsDashBoard[i].status.toLowerCase().indexOf('wip') > -1) {
                        ucgObject.userTicketWIP = ucgObject.userTicketData.UserTcketsDashBoard[i].TicketCount;
                    }
                    ucgObject.userTicketCount = ucgObject.userTicketData.UserTcketsQueue.length;
                }
                if (ucgObject.userTicketCount>0) {
                    if (ucgObject.userTicketData.UserTcketsQueue[0].L2User && ucgObject.userTicketData.UserTcketsQueue[0].L2User.trim() == '') {
                        ucgObject.columns[5].visible = false;
                    }
                    else {
                        ucgObject.columns[5].visible = true;
                    }
                    if (ucgObject.userTicketData.UserTcketsQueue[0].L1User && ucgObject.userTicketData.UserTcketsQueue[0].L1User.trim() == '') {
                        ucgObject.columns[4].visible = false;
                    }
                    else {
                        ucgObject.columns[4].visible = true;
                    }
                    if ($scope.gridApi) {
                        $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
                    }
                }
                ucgObject.userTicketGridFormat.data = ucgObject.userTicketData.UserTcketsQueue;
                ucgObject.userTicketGridFormat.origData = ucgObject.userTicketData.UserTcketsQueue;
                ucgObject.userTicketGridFormat.filteredData = ucgObject.userTicketData.UserTcketsQueue;
                getSearchableFields(ucgObject.userTicketGridFormat);
                appFactory.HideLoader();
            } else {
                // appFactory.showError('Error occured: Server unreachable.');
                errCallBack();
            }
        });

    }

    
    var errCallBack = function(data) {
        appFactory.showError('Error occured: Server unreachable.');
        appFactory.HideLoader();
    };

    function onFilterInboxTickets(status) {
        var origData = angular.copy(ucgObject.userTicketGridFormat.origData);
        var filteredData = []
        if (status) {
            filteredData = _.filter(origData, function(ticket) { return (ticket.Status.trim() === status)});
        } else {
            filteredData = origData;
        }
        ucgObject.userTicketGridFormat.data = filteredData;
        ucgObject.userTicketGridFormat.filteredData = filteredData;
        getSearchableFields(ucgObject.userTicketGridFormat);
    };

    function onFilterMyTickets(status) {
        var origData = angular.copy(ucgObject.ticketGridFormat.origData);
        var filteredData = []
        if (status) {
            filteredData = _.filter(origData, function(ticket) { return (ticket.Status.trim() === status)});
        } else {
            filteredData = origData;
        }
        ucgObject.ticketGridFormat.data = filteredData;
        ucgObject.ticketGridFormat.filteredData = filteredData;
        getSearchableFields(ucgObject.ticketGridFormat);
    };

    function onFilterAllTickets(status) {
        var origData = angular.copy(ucgObject.loadL3DeptTicketGridFormat.origData);
        var filteredData = []
        if (status) {
            filteredData = _.filter(origData, function(ticket) { return (ticket.Status.trim() === status)});
        } else {
            filteredData = origData;
        }
        $scope.searchIndex = '';
        ucgObject.loadL3DeptTicketGridFormat.data = filteredData;
        ucgObject.loadL3DeptTicketGridFormat.filteredData = filteredData;
        // getSearchableFields(ucgObject.loadL3DeptTicketGridFormat);
    };

    function createNewTicket() {
        ucgObject.isCreateFormSubmitted = true;
        if ($scope.createForm.$invalid || !ucgObject.DataForNewTicket.Department || !ucgObject.DataForNewTicket.ProblemType) {
            appFactory.showError('Please resolve the erros');
            return;
        }
        if (ucgObject.filesToUpload.files.length) {
            var isValidFileFormat = isValidFileFormats();
            if (!isValidFileFormat) {
                invalidFileFormts();
                return;
            }
        }
        appFactory.ShowLoader();
        var newTicketObj = angular.copy(ucgObject.DataForNewTicket);
        newTicketObj.CallingPhone = newTicketObj.RegisteredPhone;
        newTicketObj.AssignedToSSOOn = moment().format('YYYY-MM-DD HH:mm:ss');
        newTicketObj.Status = 'Open';
        // newTicketObj.DOB = document.getElementById('dob').value; /* Used Juery date drop down selector for DOB**/
        newTicketObj.DOB = moment(newTicketObj.DOB).format('YYYY-MM-DD');
        newTicketObj.isCreatedInFinesse = "0";
        newTicketObj.CreatedBy = newTicketObj.SSONO;
        newTicketObj.CreatedOn = moment().format('YYYY-MM-DD HH:mm:ss'); //change_06122017
        // getting values from ui select 
        newTicketObj.ProblemTypeID = newTicketObj.ProblemType.ProblemTypeID;
        newTicketObj.ProblemType = newTicketObj.newProblemType;
        newTicketObj.DepartmentID = newTicketObj.Department.DepartmentID;
        newTicketObj.DivisionID = (newTicketObj.Division) ? newTicketObj.Division.DivisionID : 0;
        newTicketObj.DistrictID = (newTicketObj.District) ? newTicketObj.District.DistrictID : 0;
        newTicketObj.BlockID = (newTicketObj.Block) ? newTicketObj.Block.BlockID : 0;
        newTicketObj.PanchayatID = (newTicketObj.Panchayat) ? newTicketObj.Panchayat.PanchayatID : 0;
        newTicketObj.Village = (newTicketObj.Village) ? newTicketObj.Village.VillageID: 0;
        UCGService.createNewTicket(newTicketObj, function (data) {

            if (data && data.Status === 200) {
                var ticketID = data.TicketDetail[0];
                $scope.messageTextAlert = "Ticket created successfully and Ticket ID :" + ticketID;
                $scope.showMessageAlert = true;
                ucgObject.DataForNewTicket = {};
                ucgObject.DataForNewTicket.SSONO = ucgObject.ssoId;
                ucgObject.selectedDeptText_create = "";
                ucgObject.isCreateFormSubmitted = false;
                // document.getElementById('dob').value = '';/* Used Juery date drop down selector for DOB**/
                ucgObject.calculateRemainingCharacter();
                appFactory.HideLoader();
                if (ucgObject.filesToUpload.files.length) { 
                    ucgObject.filesToUpload.ticketId = ticketID;
                    onUploadFiles(true);
                }
                appFactory.showSuccess('Ticket Created Successfully');
                setTimeout(function() {
                    window.scrollTo(0, 1);
                }, 100);
            }
            else {
                // appFactory.showError('Error occured: Server unreachable.');
                errCallBack();
            }

        });
    }


    function openCalendarDob(e) {
        e.preventDefault();
        e.stopPropagation();

        ucgObject.isOpenDob = true;
    };
    function openCalendarDate(e) {
        e.preventDefault();
        e.stopPropagation();

        ucgObject.isOpenDate = true;
    };

    function getProblemType(departmentID, cbsGetProblemType) {
        if (!ucgObject.DataForNewTicket.DepartmentID && !departmentID) {return;}
        ucgObject.DataForNewTicket.ProblemTypeID = '';
        var deptID = (departmentID) ? departmentID : ucgObject.DataForNewTicket.DepartmentID;
        UCGService.getProblemType(deptID, function (data) {
            if (data.Status == 200) {
                ucgObject.ProblemType = data.ProblemTypeDetail;
                ucgObject.ProblemType.unshift({ProblemTypeID : -1, ProblemTypeName : 'New Problem'});
                if (cbsGetProblemType) {
                    cbsGetProblemType();
                }
            }
            else {
                appFactory.showError('Error occured: Server unreachable.');
            }
        });
    }
    function getDepartmentlist(cbsFunction) {
        UCGService.getDepartmentlist(function (data) {
            if (data && data.Status == 200) {
                ucgObject.DepartmentList = data.DepartmentDetail;
                if (cbsFunction) {
                    cbsFunction();
                }
            }
            else {
                errCallBack()
            }
        });
    };

    function onSelectDepartment(depdID) {
        ucgObject.getProblemType(depdID);
        // getDepartmentUser('create');
    };

    
    function getDepartmentUser(mode) {//---Changed 28 Nov 2017
        ucgObject.DepartmentUserList = [];
        if (mode=='assign' && ucgObject.assignData.DepartmentID!='') {
            UCGService.getDepartmentUser(ucgObject.assignData.DepartmentID, function (data) {
                if (data.Status == 200) {
                    ucgObject.DepartmentUserList = data.L1User;
                }
                else {
                    appFactory.showError('Error occured: Server unreachable.');
                }
            });
        }
        else if (mode == 'create' && ucgObject.DataForNewTicket.DepartmentID != '') {
            UCGService.getDepartmentUser(ucgObject.DataForNewTicket.DepartmentID, function (data) {
                if (data.Status == 200) {
                    ucgObject.DepartmentUserList = data.L1User;
                }
                else {
                    appFactory.showError('Error occured: Server unreachable.');
                }
            });
        }
    }//---Changed 28 Nov 2017

    function getDivisionList() {
        UCGService.getDivisionlist(function (data) {
            if (data.Status == 200) {
                ucgObject.DivisionList = data.DivisionDetail;
                //getDistrictList();
            }
            else {
                appFactory.showError('Error occured: Server unreachable.');
            }
        });
    }
    function getDistrictList() {
        if (ucgObject.DataForNewTicket.Division.DivisionID != null) {
            UCGService.getDistrictList(ucgObject.DataForNewTicket.Division.DivisionID, function (data) {
                if (data.Status == 200) {
                    ucgObject.DistrictList = data.DistrictDetail;
                }
                else {
                    appFactory.showError('Error occured: Server unreachable.');
                }
            });
        }
        else {
            ucgObject.DistrictList = [];
        }
    }



    function getBlockList() {
        if (ucgObject.DataForNewTicket.District.DistrictID != null) {
            UCGService.getBlockList(ucgObject.DataForNewTicket.District.DistrictID, function (data) {
                if (data.Status == 200) {
                    ucgObject.BlockList = data.BlockDetail;
                }
                else {
                    appFactory.showError('Error occured: Server unreachable.');
                }
            });
        }
        else {
            ucgObject.BlockList = [];
        }
    }
    function getPancheyatList() {
        if (ucgObject.DataForNewTicket.Block.BlockID != null) {
            UCGService.getPancheyatList(ucgObject.DataForNewTicket.Block.BlockID, function (data) {
                if (data.Status == 200) {
                    ucgObject.PanchayatList = data.PachayatDetail;
                }
                else {
                    appFactory.showError('Error occured: Server unreachable.');
                }
            });
        }
        else {
            ucgObject.PanchayatList = [];
        }
    }
    var getCompletedTicketsByUser = function(level) {
        UCGService.getCompletedTickets(userObj.departmentId, level,
            function(data) {
                if (data && data.Status) {
                    ucgObject.completedGridFormat.data = data.RejectedTicketDetails;
                    getSearchableFields(ucgObject.completedGridFormat);
                    appFactory.HideLoader();
                } else {
                    errCallBack();
                }
            })
    }

    function getCompletedTickets() {
        appFactory.ShowLoader();
        UCGService.getUserBySSOID(userObj.SSOID,
            function (data) {
                if (data && data.length) {
                    var user = data[0];
                    if (user.Level === 2 || user.Level === 3) {
                        getCompletedTicketsByUser(user.Level);
                        ucgObject.completedGridFormat.isValidUser = true;
                    } else {
                        ucgObject.completedGridFormat.isValidUser = false;
                        appFactory.HideLoader();
                    }
                } else {
                    ucgObject.completedGridFormat.isValidUser = false;
                    appFactory.HideLoader();
                }
            }
        );
    }

    function getVillageList() {
        if (ucgObject.DataForNewTicket.Panchayat.PanchayatID != null) {
            UCGService.getVillageList(ucgObject.DataForNewTicket.Panchayat.PanchayatID, function (data) {
                if (data.Status == 200) {
                    ucgObject.VillageList = data.VillageDetail;
                }
                else {
                    appFactory.showError('Error occured: Server unreachable.');
                }
            });
        }
        else {
            ucgObject.VillageList = [];
        }
    };

    //--change_03122017
    function validateDeptUser(deptUser, isCreate, isUpdate) {
        profileFactory.GetSSOUserRoles(deptUser).then(
            function success(data) {
                if (data.data && data.data !== 'null') {
                    var departmentId = appFactory.getDepartmentFromRole(data.data);
                    if (!departmentId) {
                        cbfValidateDeptUser(isCreate);
                        return;    
                    }
                    $scope.showMessageAlert = false;
                    $scope.messageTextAlert = '';                  
                    if (isUpdate) {
                        ucgObject.detailUpdateTicket.DepartmentID = departmentId;
                    } else {
                        ucgObject.DataForNewTicket.assignedSSODeptID = departmentId;
                        ucgObject.DataForNewTicket.DepartmentID = departmentId;
                        ucgObject.DataForNewTicket.Department = getDeparmetById(+departmentId);
                    }
                    ucgObject.getProblemType(departmentId); 
                } else {
                    cbfValidateDeptUser(isCreate);
                }
            }, function errr(data) {
                cbfValidateDeptUser(isCreate);
            }
        );
   };

   var cbfValidateDeptUser = function(isCreate) {
        var errMsge = "Invalid SSO Id";
        if (isCreate) {
            appFactory.showToasterErr(errMsge);
        } else {
            $scope.messageTextAlert = errMsge;
            $scope.showMessageAlert = true;
        }
        ucgObject.assignData.DepartmentUser = '';
        ucgObject.DataForNewTicket.AssignedSSO = '';
        // ucgObject.DataForNewTicket.SSONO = '';
   };

    if (!String.prototype.trim) {
        (function () {
            // Make sure we trim BOM and NBSP
            var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
            String.prototype.trim = function () {
                return this.replace(rtrim, '');
            };
        })();
    }

    function onTypeSearchValues(tabName) {
        var filteredData = appFactory.getDataBySearchIndex(ucgObject.searchIndex);
        if (tabName === ucgObject.SEARCH.INBOX) {
            ucgObject.userTicketGridFormat.data = filteredData;
        }
        if (tabName === ucgObject.SEARCH.MY_TICK) {
            ucgObject.ticketGridFormat.data = filteredData;
        }
        if (tabName === ucgObject.SEARCH.ASSIGN) {
            ucgObject.assignTicketGridFormat.data = filteredData;
        }
        if (tabName === ucgObject.SEARCH.DASH) {
            ucgObject.loadL3DeptTicketGridFormat.data = filteredData;
        }
        if (tabName === ucgObject.SEARCH.REJECT) {
            ucgObject.rejectTicketGridFormat.data = filteredData;
        }
        if (tabName === ucgObject.SEARCH.OPEN) {
            ucgObject.openTicketsGrid.data = filteredData;
        }
        if (tabName === ucgObject.SEARCH.COMPLETE) {
            ucgObject.completedGridFormat.data = filteredData;
        }
    };

    function onRefreshPage(tabName) {
        if (tabName === ucgObject.SEARCH.INBOX) {
            ucgObject.loadUserTicket();
        }
        if (tabName === ucgObject.SEARCH.MY_TICK) {
            ucgObject.loadMyTicket();
        }
        if (tabName === ucgObject.SEARCH.ALLTICK) {
            ucgObject.loadL3DashboardTicket();
        }
        if (tabName === ucgObject.SEARCH.DASH) {
            ucgObject.loadL3TicketDeptTicket();
        }
        if (tabName === ucgObject.SEARCH.OPEN) {
            ucgObject.loadOpenTickets();
        }
    };

    var getSearchableFields = function (gridConfig) {
        ucgObject.searchIndex = '';
        appFactory.getSearchableFields(gridConfig);
    };

    var setDOBDropDown = function() {
        $("#dob").dateDropdowns({
            submitFieldName: 'dob',
            maxAge: 100,
            minAge: 6,
            submitFormat: "dd-mm-yyyy"
        });
    };
    
    var init = function() {
        setDOBDropDown();
        /* for local */
        // $scope.myTickpermission =  {Modify: true};
        // $scope.createTickpermission =  {Modify: true};
        // $scope.assignTickpermission =  {Modify: true};
        // $scope.updateTickpermission =  {Modify: true};
        // $scope.rejectTickpermission =  {Modify: true};
        // $scope.completeTickpermission =  {Modify: true};
        // ucgObject.updatessoId = 'swaminathan.servion';
        // userObj = {
        //     departmentId : 5800096,
        //     SSOID: 'esanchar2.test'
        // };
        /** for other env */
        ucgObject.ssoId = userObj.SSOID;
        ucgObject.updatessoId = userObj.SSOID;

        ucgObject.DataForNewTicket.SSONO = ucgObject.ssoId;
        getDivisionList();
        getDepartmentlist();
        // loadL3DashboardTicket();
        // loadL3TicketDeptTicket();
    };
    
    init();

});