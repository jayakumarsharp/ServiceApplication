app.controller('SmsCodeController', ['$scope', '$rootScope', 'masterDataFactory', 'toaster', function ($scope, $rootScope, masterDataFactory, toaster) {
    $scope.smsCodeEdit = [];
    $scope.Formlist = {};
    $scope.form = {};
    $scope.SmsCode = {};

    $scope.gridSmsCodeOptions = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
                name: 'Department',
                field: 'DepartmentName'
            },
            {
                name: 'ApplicationUse',
                field: 'ApplicationUse'
            },

            {
                name: 'Type',
                field: 'CodeType'
            },
            {
                name: 'CodeName',
                field: 'CodeName'
            },
            {
                name: 'CodeDescription',
                field: 'CodeDescription'
            },

            {
                name: 'Options',
                enableSorting: false,
                enableFiltering: false,
                width: '10%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
            }
        ],

    };

    //dropdown values
    $scope.GetApplicationName = function () {

        masterDataFactory.GetApplicationName().then(
            function success(data) {

                // console.log("editSMS",data);
                $scope.ApplicationUseDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }

    $scope.GetApplicationName();
    $scope.GetDepartmentName = function () {

        masterDataFactory.GetDepartmentName().then(
            function success(data) {

                // console.log("editSMS",data);
                $scope.DepartmentDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }
    $scope.GetDepartmentName();
    //  $scope.DepartmentValue=["R001","R002","R003","R004","R005"];
    // $scope.ApplicationUseDropDownValue=["SMS","SURVEY","COMPAIGN"];
    $scope.Type = ["Short", "Long"];


    $scope.GetSmsCode = function () {

        masterDataFactory.GetSmsCode().then(
            function success(data) {

                console.log("edit", data);
                $scope.gridSmsCodeOptions.data = data.data;
            },
            function error(data) {

            }
        )
    }
    $scope.GetSmsCode();



    $scope.showAdd = function () {

        $scope.Formlist = {};
        $scope.form.SmsCode.$setPristine();

        $('#AddShortCode').modal('show');

    }


    $scope.CreateSmsCodes = function () {

        $scope.SmsCodeAdd = {};

        // $scope.SmsCodeAdd.ThresholdType = 2;
        $scope.SmsCodeAdd.UpdatedBy = 'Admin';

        $scope.SmsCodeAdd.DepartmentID = $scope.Formlist.DepartmentID;
        $scope.SmsCodeAdd.ApplicationID = $scope.Formlist.ApplicationID;
        $scope.SmsCodeAdd.CodeName = $scope.Formlist.CodeName;
        $scope.SmsCodeAdd.CodeDescription = $scope.Formlist.CodeDescription;
        $scope.SmsCodeAdd.CodeType = $scope.Formlist.CodeType;
        $scope.SmsCodeAdd.LastModifiedBy = '2017-10-13 17:47:33.460';

        masterDataFactory.CreateSmsCode($scope.SmsCodeAdd).then(function (data) {



            if (data.data == "Success") {
                $scope.GetSmsCode();
                $('#AddShortCode').modal('hide');
                $scope.Formlist = {};
                $scope.form.SmsCode.$setPristine();
                toaster.pop({
                    type: "Success",
                    body: "SMS Code Created successfully"
                });

            } else {
                $scope.GetSmsCode();
                toaster.pop({
                    type: "error",
                    body: "Error while creating SMS Code"
                });

            }
        });

    }

    $scope.showEdit = function (getRowData) {
        $scope.smsCodeEdit = {};
        // console.log("edit2", getRowData);
        $scope.smsCodeEdit.DepartmentID = getRowData.DepartmentID;
        $scope.smsCodeEdit.ApplicationID = getRowData.ApplicationID;
        $scope.smsCodeEdit.CodeType = getRowData.CodeType;
        $scope.smsCodeEdit.CodeName = getRowData.CodeName;
        $scope.smsCodeEdit.CodeDescription = getRowData.CodeDescription;
        $scope.smsCodeEdit.ShortCodeID = getRowData.ShortCodeID;

        //console.log("hello");
        $scope.EditView = true;
        $('#modifyShortCode').modal('show');
    }

    $scope.UpdateSmsCodes = function () {

        $scope.SmsCodeUpdate = {};

        $scope.SmsCodeUpdate.UpdatedBy = 'Admin';

        $scope.SmsCodeUpdate.DepartmentID = $scope.smsCodeEdit.DepartmentID;
        $scope.SmsCodeUpdate.ApplicationID = $scope.smsCodeEdit.ApplicationID;
        $scope.SmsCodeUpdate.CodeName = $scope.smsCodeEdit.CodeName;
        $scope.SmsCodeUpdate.CodeDescription = $scope.smsCodeEdit.CodeDescription;
        $scope.SmsCodeUpdate.CodeType = $scope.smsCodeEdit.CodeType;
        //  $scope.SmsCodeUpdate.LastModifiedBy = '2017-10-13 17:47:33.460';
        $scope.SmsCodeUpdate.ShortCodeID = $scope.smsCodeEdit.ShortCodeID;

        masterDataFactory.UpdateSmsCode($scope.SmsCodeUpdate).then(function (data) {



            if (data.data == "Success") {
                $scope.GetSmsCode();

                $('#modifyShortCode').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "SMS Code Modified successfully"
                });

            } else {
                $scope.GetSmsCode();
                toaster.pop({
                    type: "error",
                    body: "Error while Modifying SMS Code"
                });

            }
        });

    }
    //Delete functionality
    $scope.showDelete = function (getRowData) {
        //$scope.ussdCodeDelete = {};

        $scope.CodeID = getRowData.ShortCodeID;
        $scope.EditView = true;
        $('#confirmModal').modal('show');
    }

    $scope.Delete = function () {
        // $scope.ussdCodeDelete = {};
        var CodeID = $scope.CodeID;
        masterDataFactory.DeleteSmsCode(CodeID).then(function (data) {



            if (data.data == "Success") {
                $scope.GetSmsCode();

                $('#confirmModal').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "SMS Code Deleted successfully"
                });

            } else {
                $scope.GetSmsCode();
                //   toaster.pop({ type: "error", body: "Error while creating USSD Threshold", toasterId: 1 });

            }
        });

    }



}]);