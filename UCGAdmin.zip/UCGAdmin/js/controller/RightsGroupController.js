app.controller('RightsGroupController', ['$scope', '$rootScope', function ($scope, $rootScope) {

    $scope.EditView = true;

    $scope.rightsGroupData = [{
            'RightsGroupID': 'RG01',
            'RightsGroupName': 'Campaign Management - Admin',
            'IsActive': true
        },
        {
            'RightsGroupID': 'RG02',
            'RightsGroupName': 'User Management - Reports',
            'IsActive': true
        },
        {
            'RightsGroupID': 'RG03',
            'RightsGroupName': 'Survey Management - Admin',
            'IsActive': true
        },
    ];

    $scope.RightsGroupGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Rights Group Id',
                field: 'RightsGroupID'
            },
            {
                name: 'Rights Group Name',
                field: 'RightsGroupName'
            },
            {
                name: 'IsActive',
                field: 'IsActive'
            },
            {
                name: 'Options',
                enableSorting: false,
                width: '10%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.showView(row.entity)"><span class="fa fa-eye"></span></a> | <a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity.UserId)"><span class="fa fa-trash-o"></span></a>'
            },
        ]
    };

    $scope.RightsGroupGrid.data = $scope.rightsGroupData;

    $scope.showAdd = function () {
        $('#addRightsGroup').modal('show');
    }

    $scope.showView = function () {
        $scope.EditView = false;
        $('#modifyRightsGroup').modal('show');
    }

    $scope.showEdit = function () {
        $scope.EditView = true;
        $('#modifyRightsGroup').modal('show');
    }

    $scope.showDelete = function () {
        $('#confirmModal').modal('show');
    }


    //---Dual list control---//

    // init
    $scope.selectedA = [];
    $scope.selectedB = [];

    $scope.listA = [];
    $scope.listB = [];

    $scope.checkedA = false;
    $scope.checkedB = false;

    function reset() {
        $scope.selectedA = [];
        $scope.selectedB = [];
        //$scope.toggle = 0;
    }

    $scope.GetLists = function () {
        $scope.listA = [];
        $scope.listB = [];

        if ($scope.role != null) {
            console.log('role scope is not null');
            var unselectedRights = JSON.parse(JSON.stringify($scope.Rights));
            RoleFactory.GetRoleRightMapping($scope.role.id).success(function (data) {
                for (i = 0; i < data.length; i++) {
                    var rightName = $scope.GetRightName(data[i].RightID);
                    $scope.listB.push({
                        'RightID': data[i].RightID,
                        'RightName': rightName
                    });
                    var delId = arrayObjectIndexOf(unselectedRights, data[i].RightID);
                    unselectedRights.splice(delId, 1);
                }
            });
            $scope.listA = unselectedRights;
        } else {
            console.log('role scope is null');
            $scope.listA = JSON.parse(JSON.stringify($scope.Rights));
            console.log('list A count after: ' + $scope.listA.length);
            $scope.listB = [];
        }
    }

    function arrayObjectIndexOf(myArray, searchTerm) {
        for (var i = 0, len = myArray.length; i < len; i++) {
            if (myArray[i].RightID == searchTerm) {
                return i;
            }
        }
        return -1;
    }

    $scope.stateBChanged = function (isChecked, rightID) {
        if (isChecked == true) {
            $scope.selectedB.push(rightID);
        } else {
            var delId = arrayObjectIndexOf($scope.selectedB, rightID);
            $scope.selectedB.splice(delId, 1);
        }
    }
    $scope.stateAChanged = function (isChecked, rightID) {
        if (isChecked == true) {
            $scope.selectedA.push(rightID);
        } else {
            var delId = arrayObjectIndexOf($scope.selectedA, rightID);
            $scope.selectedA.splice(delId, 1);
        }
    }

    $scope.AlltoA = function () {
        if ($scope.selectedA.length == 0) {
            $scope.selectedB = [];
            angular.forEach($scope.listB, function (value, key) {
                $scope.selectedB.push(value.RightID);
            })
            $scope.bToA();
        }
    }

    $scope.AlltoB = function () {
        if ($scope.selectedB.length == 0) {
            $scope.selectedA = [];
            angular.forEach($scope.listA, function (value, key) {
                $scope.selectedA.push(value.RightID);
            })
            $scope.aToB();
        }
    }

    $scope.aToB = function () {
        console.log('a to b');
        if ($scope.selectedB.length == 0) {
            var items = JSON.parse(JSON.stringify($scope.Rights));
            for (var i = 0; i < $scope.selectedA.length; i++) {
                var moveId = arrayObjectIndexOf(items, $scope.selectedA[i]);
                $scope.listB.push(items[moveId]);
                var delId = arrayObjectIndexOf($scope.listA, $scope.selectedA[i]);
                $scope.listA.splice(delId, 1);
                console.log('list A count after: ' + $scope.listA.length);
                console.log('list B count after: ' + $scope.listB.length);
            }
            reset();
        }
    };

    $scope.bToA = function () {
        console.log('b to a');
        if ($scope.selectedA.length == 0) {
            for (var i = 0; i < $scope.selectedB.length; i++) {
                var moveId = arrayObjectIndexOf($scope.Rights, $scope.selectedB[i]);
                $scope.listA.push($scope.Rights[moveId]);
                var delId = arrayObjectIndexOf($scope.listB, $scope.selectedB[i]);
                $scope.listB.splice(delId, 1);
                console.log('list B count after: ' + $scope.listB.length);
                console.log('list A count after: ' + $scope.listA.length);
            }
            reset();
        }
    };

    //--- End of Dual List---//


}]);