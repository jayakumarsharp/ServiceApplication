app.controller('UserReportController', ['$scope', '$rootScope', function ($scope, $rootScope) {

    $scope.usrReportData = [{
            'ModifiedBy': 'Srini',
            'ModifiedOn': '17-08-2017  12:36:00 PM',
            'Entity': 'User Management',
            'ChangeType': 'Modify User'
        },
        {
            'ModifiedBy': 'John',
            'ModifiedOn': '17-08-2017  01:12:00 PM',
            'Entity': 'Rights Group Management',
            'ChangeType': 'Add Rights Group'
        },
        {
            'ModifiedBy': 'John',
            'ModifiedOn': '17-08-2017  01:13:00 PM',
            'Entity': 'Rights Group Management',
            'ChangeType': 'Delete Rights Group '
        },
        {
            'ModifiedBy': 'Dinesh',
            'ModifiedOn': '17-08-2017  01:12:00 PM',
            'Entity': 'Rights Management',
            'ChangeType': 'Add Rights'
        },
        {
            'ModifiedBy': 'John',
            'ModifiedOn': '17-08-2017  01:22:00 PM',
            'Entity': 'Rights Management',
            'ChangeType': ' Delete Rights'
        },
        {
            'ModifiedBy': 'Dinesh',
            'ModifiedOn': '17-08-2017  02:36:00 PM',
            'Entity': 'Rights Management',
            'ChangeType': ' Delete Rights'
        },
        {
            'ModifiedBy': 'Srini',
            'ModifiedOn': '17-08-2017  01:36:00 PM',
            'Entity': 'User Management',
            'ChangeType': 'Add User'
        },
    ];

    $scope.UserReportsGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Modified By',
                field: 'ModifiedBy'
            },
            {
                name: 'Modified On',
                field: 'ModifiedOn'
            },
            {
                name: 'Entity',
                field: 'Entity'
            },
            {
                name: 'Change Type',
                field: 'ChangeType'
            }
        ]
    };

    $scope.UserReportsGrid.data = $scope.usrReportData;



}]);