app.controller('masterSmsTemplate', masterSmsTemplateController);
masterSmsTemplateController.$inject = ['masterDataFactory', 'toaster', '$rootScope', 'appFactory', '$scope'];
function masterSmsTemplateController(masterDataFactory, toaster, $rootScope, appFactory, $scope) {
    var vm = this;
    vm.form = {};
    vm.formlistEmail = {};
    vm.formEdit = {};
    vm.formDelete = {};
    vm.wordCheck = true;
    vm.wordCheckUpdate = true;
    vm.gridSmsTemplate = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
            name: 'S.No',
            enableSorting: false,
            width: '10%',
            enableFiltering: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
        },
        {
            name: 'TemplateName',
            field: 'TemplateName',
            cellTooltip: true
        },
        {
            name: 'MessageText',
            field: 'MessageText',
            cellTooltip: true

        },


        {
            name: 'Options',
            enableFiltering: false, enableSorting: false,
            width: '10%',
            cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
        }

            //  { name: 'Options', enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }

        ],
    };

    vm.GetSMSTemplate = function () {

        masterDataFactory.GetSMSTemplate().then(
            function success(data) {
                vm.gridSmsTemplate.data = data.data;
            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while retreiving  sms Template"
                });

            }
        );
    }
    vm.GetSMSTemplate();

    vm.GetDepartmentName = function () {


        masterDataFactory.GetDepartmentName().then(
            function success(data) {

                // console.log("editSMS",data);
                vm.DepartmentDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }
    vm.GetDepartmentName();

    vm.abusiveWords = [];
    vm.GetAbusiveWords = function () {
        masterDataFactory.GetInvalidWords().then(
            function success(response) {
                //  console.log("edit", data);
                vm.abusiveWords = response.data;
            },
            function error(response) {
                toaster.pop({
                    type: "error",
                    body: "Error occured while retreiving the data"
                });

            }
        )
    }
    vm.GetAbusiveWords();

    vm.showAdd = function () {
        vm.formlistEmail = {};
        vm.wordCheck = true;
        vm.form.SMSTemplate.$setPristine();
        $('#AddSMSTemplate').modal('show');
    }
    vm.CreateSMSTemplate = function () {
        vm.wordCheck = true;
        var words = vm.formlistEmail.MessageText;
        var arr = words.split(" ");
        vm.wrongWords = [];
        vm.wrong=[];
        arr.forEach(function (value, key) {
            vm.abusiveWords.forEach(function (data) {
                var dbword = data.InvalidWord.toLowerCase();
                var enteredWord = value.toLowerCase();
                if (enteredWord == dbword) {
                    vm.wordCheck = false;
                    vm.wrong.push(value);
                }
            })
        })
        vm.wrongWords=_.uniq( vm.wrong);
        if (vm.wordCheck) {
            var CreateTemp = {};
            CreateTemp.DepartmentID = vm.formlistEmail.DepartmentID;
            CreateTemp.TemplateName = vm.formlistEmail.TemplateName;
            CreateTemp.MessageText = vm.formlistEmail.MessageText;
            CreateTemp.CreatedBy = 'Admin';
            masterDataFactory.CreateSMSTemplate(CreateTemp).then(function (data) {

                if (data.data == "Success") {
                    vm.GetSMSTemplate();
                    $('#AddSMSTemplate').modal('hide');
                    vm.formlistEmail = {};
                    vm.form.SMSTemplate.$setPristine();
                    toaster.pop({ type: "Success", body: "Created successfully" });

                }
                else {
                    vm.GetSMSTemplate();
                    toaster.pop({ type: "error", body: "some Error  occured while creating" });

                }
            });
        }

    }

    vm.showEdit = function (rowdata) {

        vm.formEdit.DepartmentID = rowdata.DepartmentId;
        vm.formEdit.TemplateName = rowdata.TemplateName;
        vm.formEdit.MessageText = rowdata.MessageText;
        vm.formEdit.ID = rowdata.ID;
        vm.wordCheckUpdate = true;
        $('#modifySMSTemplate').modal('show');

    }

    vm.UpdateSMSTemplate = function () {

        vm.wordCheckUpdate = true;
        var words = vm.formEdit.MessageText;
        var arr = words.split(" ");
        vm.wrongWordsUpdate = [];
        vm.wrongupd=[];
        arr.forEach(function (value, key) {
            vm.abusiveWords.forEach(function (data) {
                var dbword = data.InvalidWord.toLowerCase();
                var enteredWord = value.toLowerCase();
                if (enteredWord == dbword) {
                    vm.wordCheckUpdate = false;
                    vm.wrongupd.push(value);
                }
            })
        })
        vm.wrongWordsUpdate=_.uniq(vm.wrongupd);
        if (vm.wordCheckUpdate) {
            var updateSMS = {};
            updateSMS.DepartmentID = vm.formEdit.DepartmentID;
            updateSMS.TemplateName = vm.formEdit.TemplateName;
            updateSMS.MessageText = vm.formEdit.MessageText;
            updateSMS.UpdatedBy = 'Admin';
            updateSMS.ID = vm.formEdit.ID;
            masterDataFactory.UpdateSMSTemplate(updateSMS).then(function (data) {

                if (data.data == "Success") {
                    vm.GetSMSTemplate();
                    $('#modifySMSTemplate').modal('hide');
                    vm.formedit = {};
                    toaster.pop({ type: "Success", body: "Updated successfully" });

                }
                else {
                    vm.GetSMSTemplate();
                    toaster.pop({ type: "error", body: "some Error  occured while Updating" });

                }
            });
        }

    }

    vm.showDelete = function (rowdata) {
        vm.formDelete.ID = rowdata.ID;
        $('#confirmModalSMSTemp').modal('show');
    }
    vm.DeleteSMSTemplate = function () {
        var DelSMStemp = {};
        DelSMStemp.ID = vm.formDelete.ID;
        DelSMStemp.UpdatedBy = 'Admin';
        masterDataFactory.DeleteSMSTemplate(DelSMStemp).then(function (data) {

            if (data.data == "Success") {
                vm.GetSMSTemplate();
                $('#confirmModalSMSTemp').modal('hide');
                vm.formDelete = {};
                toaster.pop({ type: "Success", body: "Deleted successfully" });

            }
            else {
                vm.GetSMSTemplate();
                toaster.pop({ type: "error", body: "some Error  occured while Deleting" });

            }

        });

    }



}