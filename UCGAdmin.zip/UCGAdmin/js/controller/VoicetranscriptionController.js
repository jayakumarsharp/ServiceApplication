app.controller('VoicetranscriptionController', ['$scope', 'appFactory', '$window', 'voiceTransFactory', '$filter', 'toaster', '$rootScope', '$timeout', function ($scope, appFactory, $window, voiceTransFactory, $filter, toaster, $rootScope, $timeout) {
    $scope.Formlist = {};
    $scope.systems = {};
    $scope.Savetime = '00:00';
    $scope.ms = {};
    $scope.form = {};
    $scope.flagA = true;
    $scope.dnc = {};
    $scope.flagB = true;
    $scope.flagC = true;
    $scope.dnc.SelectedDnc = 'Hindi';
    $scope.Formlist.Sourcetype = "CAL";
    $scope.Formlist.VoiceManualSourceIP = config.VoiceTransManaulProcessIP;
    $scope.Formlist.DestinationDirectory = config.VoiceDestinationDirectory;
    $scope.Formlist.DestinationSystem = config.VoiceDestinationSystem;
    var vm = this;

    //  var stat;
    // $scope.permissions = appFactory.permissions[appConst.MENUS.CAMP_MGNT.MGNT_CAMP];

    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
 $rootScope.departmentName = userObj.departmentId;
    //   $rootScope.departmentName = 103;
    //  var userObj = {
    //      SSOID: 'admin'
    //  };

    $scope.gridVoiceConfig = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableColumnResizing: true,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
            name: 'S.No',
            width: '10%',
            enableSorting: false,
            enableFiltering: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
        },
        {
            name: 'SourceSystem',
            field: 'SourceSystem',
            cellTooltip: true
        },
        {
            name: 'SourceDirectory',
            field: 'SourceDirectory',
            cellTooltip: true
        },
        // {
        //    name: 'DestinationSystem',
        //    field: 'DestinationSystem',
        //    cellTooltip: true

        // },
        // {
        //    name: 'DestinationDirectory',
        //    field: 'DestinationDirectory',
        //    cellTooltip: true
        // },
        {
            name: 'Options',
            enableSorting: false,
            enableFiltering: false,
            width: '10%',
            cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
        }

        ],
    };

    // $scope.gridVoiceStatus = {
    //     paginationPageSizes: [10, 20, 30],
    //     paginationPageSize: 10,
    //     enableColumnMenus: false,
    //     enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
    //     enableVerticalScrollbar: 1,
    //     columnDefs: [
    //         { name: 'S.No', width: '10%', enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
    //         { name: 'StartDateTime', field: 'StartDateTime' },
    //         { name: 'EndDateTime', field: 'EndDateTime' },
    //         { name: 'No of Records', field: 'No of Records' },          
    //         { name: 'CompletedPercentage', field: 'CompletedPercentage' },
    //         { name: 'Username', field: 'Username' },

    //        // { name: 'Options', enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }

    //     ],
    // };
    // $scope.gridVoiceStatus.data={




    // };
    vm.open = {};

    $scope.range = {
        endDate: new Date()
    };

    vm.openCalendar = function (e, date) {
        vm.open[date] = !vm.open[date];
        e.preventDefault();
        e.stopPropagation();
        vm.open[date] = true;
    };
    $scope.gridVoiceConfig.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
    };

    $scope.gridVoiceConfigRefresh = function (data) {
        $scope.gridVoiceConfig.data = data;
        //  $scope.gridApi.grid.refresh();

    }
    //$scope.getFileDetails = function (e) {

    //  $scope.files = [];
    // $scope.$apply(function () {
    //  if (e.files.length > 50) {
    //  toaster.pop({
    //    type: "error",
    //  body: "Exceed maximum file count limit."
    //     });
    //   } else {
    // STORE THE FILE OBJECT IN AN ARRAY.
    //    $scope.flagA = false;
    //    for (var i = 0; i < e.files.length; i++) {
    //         $scope.files.push(e.files[i])
    //     }
    //    }

    //   });
    // };
    $scope.ValidateSize = function (file) {
        $scope.files = [];
        var size = 0;
        $scope.flagA = false;
        for (var i = 0; i < file.files.length; i++)
            size = size + file.files[i].size / 1024 / 1024;
        var FileSize = size // in MB
        if (FileSize > 150) {
            toaster.pop({
                type: "error",
                body: "File size exceeds 150 MB"
            });



            $(file).val('');
        }
        else {
            for (var i = 0; i < file.files.length; i++) {
                $scope.files.push(file.files[i])
            }
        }


    };



    $scope.GetVoiceConfigData = function () {

        voiceTransFactory.GetVoiceConfig().then(
            function success(data) {

                $scope.gridVoiceConfigRefresh(data.data);

            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while retrieving Voice ConfigData"
                });
            }
        )
    }
    $scope.GetVoiceConfigData();

    $scope.DepartmentDropDownValue = [{
        LanguageCode: 'ENG',
        Languge: 'English'
    },
    {
        LanguageCode: 'HIN',
        Languge: 'Hindi'
    }
    ];

    $scope.SourceType = [{
        Code: 'CAL',
        Name: 'calabrio'
    },
    {
        Code: 'MAN',
        Name: 'Manual'
    }
    ];

    $scope.Priority = [{
        Code: 2,
        Name: 'High'
    },
    {
        Code: 1,
        Name: 'Low'
    }
    ];

    $scope.showAdd = function () {
        //$scope.form.VoiceConfig.$setPristine();
   $scope.Formlist = {};
        $scope.flagB = true;
        $scope.Formlist.manualFolName = "temp";

        $scope.Formlist.Sourcetype = "CAL";

        $scope.DepartmentDropDownValue.forEach(function (value, key) {
            if (value.LanguageCode = 'HIN') {
                $scope.defLang = value;
            }
        });

        $scope.Formlist.FileFormat = $scope.defLang.LanguageCode;
        $scope.Formlist.Priority = 1;
        $scope.form.VoiceConfig.$setPristine();
        // For popup resize and draggable
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });          
        })
        $('#AddConfiguration').modal('show');

    }
    $scope.GetSchedularData = function () {
        voiceTransFactory.GetSchedularData().then(
            function success(data) {

                //   var scheduledTime= moment(data.data[0].ScheduleTime).format("HH:mm");
                if (data.data.length > 0) {
                    var scheduledTim = data.data[0].ScheduleTime;
                    var stat = moment(scheduledTim, 'HH:mm:ss').format('DD-MM-YYYY HH:MM:SS Z');
                    // var stat2= moment(stat, "YYYY-MM-DD  HH:mm:ss").format("HH:mm");
                }

                $scope.ms.startDate = new Date(stat);
                $scope.ms.startDate = new Date(stat);
                // moment("123", "hmm").format("HH:mm") === "01:23"

            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while retrieving VoiceScheduleData"
                });
            }
        )
    }
    // $scope.GetSchedularData();

    $scope.open = {
        startDate: new Date(),
        endDate: new Date()
    }
    $scope.ms = {
        startDate: new Date(),
        endDate: new Date()
    }
    $scope.EditTime = {
        startDate: new Date(),
        endDate: new Date()
    }
    $scope.timeOptions = {
        readonlyInput: false,
        showMeridian: false
    }
    $scope.openCalendar = function (e, date) {
        e.preventDefault();
        e.stopPropagation();
        $scope.open[date] = true;
    };
    $scope.AddSceduleTime = function () {
        var scheduletimeAdd = {};

        var Schedule = moment($scope.ms.startDate).format("HH:mm");
        scheduletimeAdd.scheduletime = Schedule;
        //var yy = $scope.ms.startDate.getTime();
        scheduletimeAdd.updatedBy = userObj.SSOID;

        voiceTransFactory.UpdateSchedularData(scheduletimeAdd).then(function (data) {



            if (data.data == "Success") {

                toaster.pop({
                    type: "success",
                    body: "Time saved successfully"
                });

            } else {
                toaster.pop({
                    type: "success",
                    body: "Time saved successfully"
                });
            }
        });

    }





    $scope.Add = function () {
        var VoiceConfigAdd = {};
        appFactory.ShowLoader();
     
        VoiceConfigAdd.SourceSystem = $scope.Formlist.SourceSystem;
        VoiceConfigAdd.SourceDirectory = $scope.Formlist.SourceDirectory;
        VoiceConfigAdd.Updatedby = userObj.SSOID;
        VoiceConfigAdd.ManualProcessIP = config.VoiceTransManaulProcessIP;
        VoiceConfigAdd.DestinationDirectory = config.VoiceDestinationDirectory;
        VoiceConfigAdd.DestinationSystem = config.VoiceDestinationSystem;
        VoiceConfigAdd.FileFormat = $scope.Formlist.FileFormat;
        VoiceConfigAdd.Sourcetype = $scope.Formlist.Sourcetype;
        VoiceConfigAdd.Priority = $scope.Formlist.Priority;
        VoiceConfigAdd.manualFolName = "";
        var startTime = moment($scope.ms.startDate).format("HH:mm");
        var endTime = moment($scope.ms.endDate).format("HH:mm");
        VoiceConfigAdd.startTime = startTime;
        VoiceConfigAdd.endTime = endTime;
        var valid = 1;
        var statDat = moment(startTime, 'hh:mm:ss')
        var endDate = moment(endTime, 'hh:mm:ss')
        if (statDat.diff(endDate) > 0) {
            valid = 0;
            toaster.pop({
                type: "error",
                body: "start Time Should be less than currentTime"
            });
        }


        if ($scope.Formlist.Sourcetype == "MAN") {
            var str = 'Common' + '\\' + VoiceConfigAdd.FileFormat + '\\' + $scope.Formlist.SourceDirectoryFol + '\\';
            VoiceConfigAdd.SourceDirectory = str;
            VoiceConfigAdd.SourceSystem = config.VoiceTransManaulProcessIP;
            VoiceConfigAdd.manualFolName = $scope.Formlist.SourceDirectoryFol;
        }
        if (valid) {
            voiceTransFactory.CreateVoiceConfig(VoiceConfigAdd).then(function (data) {
                if (data.data == "Success") {
                     appFactory.HideLoader();
                    $scope.GetVoiceConfigData();
                    $('#AddConfiguration').modal('hide');
                    $scope.Formlist = {};
                    $scope.Formlist.VoiceManualSourceIP = config.VoiceTransManaulProcessIP;
                    $scope.Formlist.DestinationDirectory = config.VoiceDestinationDirectory;
                    $scope.Formlist.DestinationSystem = config.VoiceDestinationSystem;
                    $scope.form.VoiceConfig.$setPristine();
                    toaster.pop({
                        type: "success",
                        body: "Added Successfully"
                    });

                } else {
                    $scope.GetVoiceConfigData();
                    if (data.data == "Failure") {
                         appFactory.HideLoader();
                        toaster.pop({
                            type: "error",
                            body: "Error while Adding Voice config"
                        });

                    } else {
                    
                   appFactory.HideLoader();
                  
                        toaster.pop({
                            type: "error",
                            body: data.data
                        });

                    }

                }


            });
        }


    }

    $scope.showEdit = function (getRowData) {
        $scope.VoiceConfigEdit = {};
        $scope.flagC = true;
        if (getRowData.sourceType == "MAN") {
            $scope.flagC = false;
        }
        $scope.VoiceConfigEdit.SourceSystem = getRowData.SourceSystem;
        $scope.VoiceConfigEdit.SourceDirectory = getRowData.SourceDirectory;
        $scope.VoiceConfigEdit.DestinationDirectory = getRowData.DestinationDirectory;
        $scope.VoiceConfigEdit.DestinationSystem = getRowData.DestinationSystem;
        $scope.VoiceConfigEdit.ShortCodeID = getRowData.ConfigID;
        $scope.VoiceConfigEdit.FileFormat = getRowData.FileFormat;
        $scope.VoiceConfigEdit.sourceType = getRowData.sourceType;
        $scope.VoiceConfigEdit.manualFolName = getRowData.ManualFolderName;
        $scope.VoiceConfigEdit.ManualProcessIP = getRowData.SourceSystem;
        $scope.VoiceConfigEdit.Priority = getRowData.priorityCheck;
        var scheduledTim = getRowData.startTime;
        var scheduledEndtime = getRowData.endTime;
        var stat = moment(scheduledTim, 'HH:mm:ss').format('DD-MMM-YYYY HH:mm:ss');
        $scope.EditTime.startDate = new Date(stat);
        var endtim = moment(scheduledEndtime, 'HH:mm:ss').format('DD-MMM-YYYY HH:mm:ss');
        $scope.EditTime.endDate = new Date(endtim);

        $scope.EditView = true;
         // For popup resize and draggable
         $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });          
        })
        $('#modifyConfiguration').modal('show');
    }

    $scope.UpdateVoiceConfig = function () {


        $scope.VoiceConfigUpdate = {};

        $scope.VoiceConfigUpdate.UpdatedBy = userObj.SSOID;

        $scope.VoiceConfigUpdate.SourceSystem = $scope.VoiceConfigEdit.SourceSystem;
        $scope.VoiceConfigUpdate.SourceDirectory = $scope.VoiceConfigEdit.SourceDirectory;
        $scope.VoiceConfigUpdate.DestinationSystem = $scope.VoiceConfigEdit.DestinationSystem;
        $scope.VoiceConfigUpdate.DestinationDirectory = $scope.VoiceConfigEdit.DestinationDirectory;
        $scope.VoiceConfigUpdate.ConfigID = $scope.VoiceConfigEdit.ShortCodeID;
        $scope.VoiceConfigUpdate.FileFormat = $scope.VoiceConfigEdit.FileFormat;
        $scope.VoiceConfigUpdate.sourceType = $scope.VoiceConfigEdit.sourceType;
        $scope.VoiceConfigUpdate.ManualProcessIP = $scope.VoiceConfigEdit.ManualProcessIP;
        $scope.VoiceConfigUpdate.Priority = $scope.VoiceConfigEdit.Priority;
        $scope.VoiceConfigUpdate.manualFolName = "";
        var startTime = moment($scope.EditTime.startDate).format("HH:mm");
        var endTime = moment($scope.EditTime.endDate).format("HH:mm");
        $scope.VoiceConfigUpdate.startTime = startTime;
        $scope.VoiceConfigUpdate.endTime = endTime;
        var statDat = moment(startTime, 'hh:mm:ss')
        var endDate = moment(endTime, 'hh:mm:ss')
        if (statDat.diff(endDate) > 0) {
            valid = 0;
            toaster.pop({
                type: "error",
                body: "start Time Should be less than currentTime"
            });
        }



        if ($scope.VoiceConfigEdit.sourceType == "MAN") {
            var str = 'Common' + '\\' + $scope.VoiceConfigUpdate.FileFormat + '\\' + $scope.VoiceConfigEdit.manualFolName;
            $scope.VoiceConfigUpdate.SourceDirectory = str;
            $scope.VoiceConfigUpdate.SourceSystem = config.VoiceTransManaulProcessIP;
            $scope.VoiceConfigUpdate.manualFolName = $scope.VoiceConfigEdit.manualFolName;

        }

        if (valid) {
            voiceTransFactory.UpdateVoiceConfig($scope.VoiceConfigUpdate).then(function (data) {

                //console.log("test",data.data);

                if (data.data == "Success") {
                    $scope.GetVoiceConfigData();

                    $('#modifyConfiguration').modal('hide');


                    toaster.pop({
                        type: "Success",
                        body: "Voice configuration Modified successfully"
                    });


                } else {
                    $scope.GetVoiceConfigData();
                    if (data.data == "Failure") {
                        toaster.pop({
                            type: "error",
                            body: "Error while updating"
                        });
                    } else {

                        toaster.pop({
                            type: "error",
                            body: data.data
                        });
                    }

                }
            });
        }




    }
    $scope.showDelete = function (getRowData) {
        //$scope.ussdCodeDelete = {};

        $scope.CodeID = getRowData.ConfigID;
        $scope.EditView = true;
        $('#confirmModal').modal('show');
    }


    $scope.Delete = function (index) {

        var ConfigID = $scope.CodeID;



        voiceTransFactory.DeleteVoiceConfig(ConfigID).then(function (data) {
            if (data.data == "Success") {
                $('#confirmModal').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "Voice configuration Deleted successfully"
                });
                //Updating the table data
                $scope.GetVoiceConfigData();


            } else {
                $scope.GetVoiceConfigData();
            }

        });
    }

    $scope.reset = function () {
        angular.element("input[type='file']").val(null);
    };

    $scope.getdncValue = function (dnccbSelected) {
        $scope.dnc.SelectedDnc = dnccbSelected;

    }
    $scope.manualcomments='';
    $scope.ManualUpload = function () {

        IsValidFile();
        if ($scope.isValid == true) {

            if(!$scope.BatchName){
                $scope.BatchMessage="Please enter BatchName";
            }else{
                voiceTransFactory.GetBatchName().then(
                    function success(data) {
        
                        $scope.BatchNameObj = data.data;
                        angular.forEach( $scope.BatchNameObj, function (rowdata) {
                            if (rowdata == $scope.BatchName) {
                                $scope.BatchMessage="Batch Name already exist. Please try different name"
                                $scope.isValid = false;
                                return;
                              
                            }
                        });

                        if(!$scope.BatchMessage){
                            var formData = new FormData();
                            formData.append("ManualAction", angular.toJson($scope.dnc.SelectedDnc));
                            formData.append("uploadedBy", userObj.SSOID);
                            formData.append("comments", $scope.manualcomments);
                            formData.append("BatchName", $scope.BatchName);
                            formData.append("processStartTime", moment($scope.range.endDate).format('YYYY-MM-DD HH:mm:ss'));
                            for (var i in $scope.files) {
                                formData.append("manualUpload", $scope.files[i]);
                            }
                            if ($scope.dnc.SelectedDnc == "Hindi") {
                                voiceTransFactory.UploadManualHinUpload(formData, $scope.dnc.SelectedDnc).then(function (data) {
                                    if (data.data.Message === 'Success') {
                                        toaster.pop({
                                            type: "success",
                                            body: "Manual file successfully uploaded",
                                            bodyOutputType: 'trustedHtml'
                                        });
                                        $scope.manualcomments = '';
                                        $scope.BatchName='';
                                        $scope.reset();
                                        $scope.flagA = true;
                                        $scope.dncvar = false;
                                    } else {
                                        toaster.pop({
                                            type: "error",
                                            body: "Error while manual uploading",
                                            bodyOutputType: 'trustedHtml'
                                        });
                                    }
                                });
                            }
                
                            if ($scope.dnc.SelectedDnc == "English") {
                                voiceTransFactory.UploadManualEngUpload(formData, $scope.dnc.SelectedDnc).then(function (data) {
                                    if (data.data.Message === 'Success') {
                
                                        toaster.pop({
                                            type: "success",
                                            body: "Manual file successfully uploaded",
                                            bodyOutputType: 'trustedHtml'
                                        });
                                        $scope.reset();
                                        $scope.manualcomments = '';
                                        $scope.BatchName='';
                                        $scope.dncvar = false;
                
                                    } else {
                                        toaster.pop({
                                            type: "error",
                                            body: "Error while manual uploading",
                                            bodyOutputType: 'trustedHtml'
                                        });
                                    }
                                });
                            }
                
                        }
        
                    },
                    function error(data) {
                        toaster.pop({
                            type: "error",
                            body: "Error while uploading"
                        });
                    }
                )
                
                // $scope.isValid = true;
                // return;
            }
          

        }
    }

    var IsValidFile = function () {
        $scope.isValid = '';
        $scope.Message='';
        $scope.BatchMessage='';
        var now = new Date();
        var currentDate = new Date(now);
        var startDate = new Date($scope.range.endDate);
        // var output = (datetwo - dateone) / 1000 / 60 / 60 / 24;
        $scope.currentStDayDiff = Math.round((startDate - currentDate) / 1000 / 60 / 60 / 24);
        if ($scope.currentStDayDiff < 0) {

            // toaster.pop({
            //     type: "error",
            //     body: "Process date should not be less than current date"
            // });
            $scope.Message="Process date should not be less than current date";
            $scope.isValid = false;
            return;
        }
        if ($scope.manualuploadfile == undefined || $scope.manualuploadfile == null || $scope.manualuploadfile.name == null) {
            // toaster.pop({
            //     type: "error",
            //     body: "Please select valid file to upload",
            //     bodyOutputType: 'trustedHtml'
            // });
            $scope.Message="Please select valid file to upload";
            $scope.isValid = false;
            return;
        }
        // else if (!$scope.manualcomments) {
        //     toaster.pop({
        //         type: "error",
        //         body: "Please enter comments",
        //         bodyOutputType: 'trustedHtml'
        //     });
        //     $scope.isValid = false;
        //     return;
        // }
        if ($scope.manualuploadfile.name != null) {
            var validFormats = ['wav'];
            var output = $filter('validfile')($scope.manualuploadfile.name, validFormats);
            if (output == false) {
                // toaster.pop({
                //     type: "error",
                //     body: "File format should be wav",
                //     bodyOutputType: 'trustedHtml'
                // });
                $scope.Message="File format should be wav";
                $scope.isValid = false;
                return;
            }
            //  else {
            //     $scope.isValid = true;
            //     return;
            // }
        } 
        // else {
        //     $scope.isValid = true;
        // }
        

        // if(!$scope.Message && !$scope.BatchMessage){
        //     $scope.isValid = true;
        //     return;
        // }
        
        }

    // $scope.GetBatchName = function () {
        
    //             voiceTransFactory.GetBatchName().then(
    //                 function success(data) {
        
    //                     $scope.BatchNameObj = data.data;
        
    //                 },
    //                 function error(data) {
    //                     toaster.pop({
    //                         type: "error",
    //                         body: "Error while retrieving Voice ConfigData"
    //                     });
    //                 }
    //             )
    //         }

    $scope.toggle = function (getData) {

        $scope.VoiceEnableDisable = {};

        $scope.VoiceEnableDisable.ConfigID = getData.ConfigID;
        $scope.VoiceEnableDisable.IsAvailable = !getData.IsAvailable;
        $scope.VoiceEnableDisable.UpdatedBy = userObj.SSOID;
        voiceTransFactory.UpdateVoiceConfigEnableDisable($scope.VoiceEnableDisable).then(function (response) {
            if (response.data == "Success") {
                $scope.updateVoiceIsAvailable($scope.VoiceEnableDisable);
            } else {
                $scope.GetVoiceConfigData();

            }


        });


    };
    $scope.updateVoiceIsAvailable = function (updatedVoiceObj) {
        $scope.gridVoiceConfig.data.forEach(function (config) {
            if (config.ConfigID === $scope.VoiceEnableDisable.ConfigID) {
                config.IsAvailable = $scope.VoiceEnableDisable.IsAvailable;
            }
        });
        if ($scope.VoiceEnableDisable.IsAvailable) {
            document.getElementById('enable-' + $scope.VoiceEnableDisable.ConfigID).disabled = false;
            document.getElementById('disable-' + $scope.VoiceEnableDisable.ConfigID).disabled = true;
            toaster.pop({
                type: "Success",
                body: "Disabled successfully"
            });

        } else {
            document.getElementById('enable-' + $scope.VoiceEnableDisable.ConfigID).disabled = true;
            document.getElementById('disable-' + $scope.VoiceEnableDisable.ConfigID).disabled = false;
            toaster.pop({
                type: "Success",
                body: "Enabled successfully"
            });

        }

    };

}]);