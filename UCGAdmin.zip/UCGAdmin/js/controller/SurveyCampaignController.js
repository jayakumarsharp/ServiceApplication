app.controller('SurveyCampaignController', ['$scope', '$rootScope', '$q', '$location', '$timeout', '$filter', 'toaster', 'appFactory', 'campaignFactory', 'surveyCampFactory', 'surveyFactory', 'profileFactory', function ($scope, $rootScope, $q, $location, $timeout, $filter, toaster, appFactory, campaignFactory, surveyCampFactory, surveyFactory, profileFactory) {
    
        var vm = this;
        /* constants declartions**/
        var vm = this;
        $scope.SAMPARK_GRIEVANCE_DB = {
            DEPT_TYPE: 'Department type',
            DEPT: 'Department',
            COMPLAINS: 'Work/service/scheme',
            DIVISION: 'Division',
            DISTRICT: 'District',
            PANCHAYAT: 'Panchayat samiti',
            GRAM_PANCHAYAT: 'Gram Panchayat',
            VILLAGE: 'Village'
        };
        $scope.searchIndex = '';
        $scope.surveyType = {
            SUBJECTIVE: 'Subjective',
            OBJECTIVE: 'Objective',
            MIXED: 'Mixed'
        };
        $scope.Obj = { poptab: 1 };
        $scope.appFactory = appFactory;
        $scope.appConst = appConst;
        $scope.permissions = $scope.appFactory.permissions[appConst.MENUS.RCHK_MGMT.MGMT_RCHK_CAMP];
        // $scope.permissions = {
        //     'Add': true,
        //     'Modify': true
        // };
        // Global variable declarations 
        $scope.surveyCampaigns = {};
        $scope.ressurveyCampaigns = {};
        $scope.detailsCampInfo = [];
        $scope.actionCampaigns = {};
        $scope.sampleSetting = {};
        $scope.campaignData = [];
        $rootScope.allCampaignList = [];
        $scope.resultdata = [];
        $scope.isValid = false;
        $scope.validateOnSubmit    = false;
        $scope.RajSamDB = {};
        $scope.selectedDays = [];
        $scope.inlineValidationMsg = '';
        $scope.validateOnSubmit  = false;
    
        var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
        $rootScope.departmentName = userObj.departmentId;
    
    
        // var userObj = {
        //     SSOID: ''
        // }
        // $rootScope.departmentName = 103;
        // ***** Start of Campaign Index funcationality ***** //
    
        $scope.surveyCampaigns.DayNumber = [];
        $scope.workDays = [{
            id: 1,
            name: 'M',
            fullName: 'Monday'
        },
        {
            id: 2,
            name: 'T',
            fullName: 'Tuesday'
        },
        {
            id: 3,
            name: 'W',
            fullName: 'Wednesday'
        },
        {
            id: 4,
            name: 'T',
            fullName: 'Thursday'
        },
        {
            id: 5,
            name: 'F',
            fullName: 'Friday'
        },
        {
            id: 6,
            name: 'S',
            fullName: 'Saturday'
        },
        {
            id: 7,
            name: 'S',
            fullName: 'Sunday'
        }
        ];
    
        $scope.AssociationContactDetailsGrid = {
            enableColumnResizing: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            columnDefs: [{
                name: 'S.No',
                width: '6%',
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
    
    
            {
                name: 'Campaign',
                field: 'CampaignName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Survey',
                field: 'QuestionSetName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Sample',
                field: 'SampleName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Total Contacts',
                field: 'TotalUploaded',
                cellTooltip: true
            },
            {
                name: 'Created Date',
                field: 'CreatedDate',
                isSearchable: true,
                cellTooltip: true,
                cellFilter: 'date:\'dd-MM-yy HH:mm\''
            },
    
            ]
        };
    
        $scope.AddworkingDay = function (dayID) {
            if (!$scope.surveyCampaigns.DayNumber) {
                $scope.surveyCampaigns.DayNumber = [];
            }
            var itemIndex = $scope.surveyCampaigns.DayNumber.indexOf(dayID);
            if (itemIndex < 0) {
                $scope.surveyCampaigns.DayNumber.push(dayID);
            } else {
                $scope.surveyCampaigns.DayNumber.splice(itemIndex, 1);
            }
        };
    
        function resetcalender() {
            var starttime = new Date();
            starttime.setHours(9);
            starttime.setMinutes(0);
            var endtime = new Date();
            endtime.setHours(18);
            endtime.setMinutes(0);
            $scope.surveyCampaigns = {
                startDate: starttime,
                endDate: endtime
            }
    
            $scope.workDays = [{
                id: 1,
                selected: true,
                name: 'M',
                fullName: 'Monday'
            },
            {
                id: 2,
                selected: true,
                name: 'T',
                fullName: 'Tuesday'
            },
            {
                id: 3,
                selected: true,
                name: 'W',
                fullName: 'Wednesday'
            },
            {
                id: 4,
                selected: true,
                name: 'T',
                fullName: 'Thursday'
            },
            {
                id: 5,
                selected: true,
                name: 'F',
                fullName: 'Friday'
            },
            {
                id: 6,
                selected: false,
                name: 'S',
                fullName: 'Saturday'
            },
            {
                id: 7,
                selected: false,
                name: 'S',
                fullName: 'Sunday'
            },
            ];
            $scope.surveyCampaigns.DayNumber = [1, 2, 3, 4, 5];
        }
    
        $scope.CampaignGrid = {
            enableColumnResizing: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            columnDefs: [{
                name: 'S.No',
                width: '6%',
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Campaign Name',
                field: 'CampaignId',
                isSearchable: true,
                cellTooltip: true,
                width: 200
            },
            {
                name: 'Department',
                field: 'departmentName', width: '20%',
                // cellTemplate: "<span> {{row.entity.LCMCampaignId.split('_')[0]}}</span>",
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Start Date',
                field: 'StartDate',
                cellTooltip: true,
                cellFilter: 'date:\'dd-MM-yy HH:mm\''
            },
            {
                name: 'End Date',
                field: 'EndDate',
                cellTooltip: true,
                cellFilter: 'date:\'dd-MM-yy HH:mm\''
            },
            {
                name: 'Status',
                field: 'CampaignLCMStatus',
                isSearchable: true,
                cellTooltip: true,
                //cellTemplate: "<span> {{row.entity.CampaignPercentage==0?'CREATED':row.entity.CampaignPercentage==100?'COMPLETED':row.entity.CampaignStatus}}<span>",
                //cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                 //   if (grid.getCellValue(row, col) == "CREATED") {
                  //      return 'Created';
                   // } else if (grid.getCellValue(row, col) == "EXECUTING") {
                   //     return 'Executing';
                  //  } else if (grid.getCellValue(row, col) == "STOPPED") {
                   //     return 'Stopped'
                   // }
               // }
    
    
            },
    
            {
                width: '5%',
                name: '%',
                field: 'CampaignPercentage',
                visible: false
            },
            {
                name: 'Options',
                enableSorting: false,
                width: '18%',
                cellTemplate: '<span>' +
                '<a href="#" ng-if="grid.appScope.permissions.Modify" class="action-status" ng-click="grid.appScope.showEdit(row.entity)"> <span class="fa fa-pencil" title="Edit Survey Campaign"></span> </a> <span ng-if="!grid.appScope.permissions.Modify" class="fa fa-pencil" style="color:#666; cursor: not-allowed;"  title="Edit Survey Campaign"></span>' +
                '| <a href="#" ng-if="grid.appScope.permissions.Delete && row.entity.CampaignStatus != \'EXECUTING\'" class="action-status" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o" title="Delete Survey Campaign"></span></a><span ng-if="!grid.appScope.permissions.Delete || row.entity.CampaignStatus === \'EXECUTING\'" class="fa fa-trash-o" style="color:#666; cursor: not-allowed;"  title="Delete Survey Campaign"></span>' +
                ' | <a href="#" class="action-status" ng-click="grid.appScope.showDetails(row.entity,1)"><span class="fa fa-eye" title="View Survey Campaign"></span></a> ' +
                '| <a href="#" class="action-status" ng-click="grid.appScope.showUpload(row.entity)"><span class="fa fa-upload" title="Upload"></span></a>' +
                '</span>'
            },
            {
                name: 'Actions',
                enableSorting: false,
                width: '13%',
                cellTemplate: '<span ng-if="grid.appScope.permissions.Modify">' +
                ' <a href="#" class="action-status"  ng-click="grid.appScope.showStart(row.entity)"  ng-disabled="row.entity.CampaignStatus === \'EXECUTING\'"><span class="fa fa-play-circle" title="Resume Campaign"></span></a>' +
                '| <a class="action-status ac-stop" href="#"  ng-click="grid.appScope.showStop(row.entity)" ng-disabled="(row.entity.CampaignStatus === \'STOPPED\' || row.entity.CampaignStatus === \'CREATED\')"><span class="fa fa-pause-circle" title="Pause Campaign"></span></a>' +
                '</span>' +
                '  <span ng-if="!grid.appScope.permissions.Modify">' +
                ' <span class="fa fa-play-circle" style="color:#666; cursor: not-allowed;"  title="Resume Campaign"></span>' +
                '| <span class="fa fa-pause-circle" style="color:#666; cursor: not-allowed;"  title="Pause Campaign"></span>' +
                '</span>'
            },
    
            ]
        };
    
        vm.open = {};
        var d = new Date();
        d.setHours(0, 0, 0, 0);
    
        vm.range = {
            startDate: d,
            endDate: new Date()
        };
    
        vm.openCalendar = function (e, date) {
            vm.open[date] = !vm.open[date];
            e.preventDefault();
            e.stopPropagation();
            vm.open={};
            vm.open[date] = true;
        };
    
    
        
    
        $scope.ActiveCampaignGrid = angular.copy($scope.CampaignGrid);
        $scope.ActiveCampaignGriddata = [];
        $scope.OtherCampaignGriddata = [];
    
        $scope.GetAllCampaignbyDept = function () {
            if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
                var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
                surveyCampFactory.GetAllCampaignbyDept(departmentName).then(function (data) {
                    if (data.data != null && data.data != undefined) {
                        $scope.resultdata = data.data;
    
                        _.find($scope.resultdata, function (item, index) {
                            if (item["CampaignStatus"] == "STOPPED") {
                                $scope.resultdata[index].CampaignStatus = 'PAUSED';
                            }
                        });
    
                        $scope.CampaignGrid.data = $scope.resultdata;
    
                        $scope.campaignData = data.data;
                        $timeout(function () {
                            $scope.OtherCampaignGriddata = $scope.resultdata;
                            console.log($scope.OtherCampaignGriddata);
    
                            if ($scope.tab == 1) {
                                $scope.ActiveCampaignGriddata = _.filter($scope.campaignData, function (resultItem) {
                                    return resultItem.CampaignStatus == "EXECUTING";
                                });
                                $scope.ActiveCampaignGrid.data = $scope.ActiveCampaignGriddata;
                                getSearchableFields($scope.ActiveCampaignGrid);
                            } else {
                                $scope.CampaignGrid.data = $scope.OtherCampaignGriddata;
                                getSearchableFields($scope.CampaignGrid);
                            }
    
                        }, 10);
                    } else {
                        $scope.resultdata = null;
                        $scope.CampaignGrid.data = [];
                        $scope.campaignData = null;
                    }
                });
            }
        }
        $scope.refresh = function () {
            $scope.searchIndex = '';
            $scope.GetAllCampaignbyDept();
        }
    
        $scope.GetAllSurveyCampaignList = function () {
            if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
                var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
                surveyCampFactory.GetAllSurveyCampaignList(departmentName).then(function (data) {
                    if (data.data != null && data.data != undefined) {
                        $rootScope.allCampaignList = data.data;
                    } else {
    
                        $rootScope.allCampaignList = null;
                    }
                });
            }
        }
    
        $scope.GetCiscoCampaignbyDept = function (departmentName) {
            if (departmentName != null && departmentName != undefined) {
    
                $scope.CiscoCampaign = {};
                surveyCampFactory.GetCiscoCampaignbyDept(departmentName).then(function (data) {
                    if (data.data != null && data.data != undefined) {
                        $scope.CiscoCampaign = data.data;
    
                    } else {
    
                        $scope.CiscoCampaign = null;
                    }
                });
            }
        }
       
        $scope.showDetails = function (getrowdata,tabId) {
            $scope.receivedRowdata = getrowdata;
            $scope.actionCampaigns = {};
            $scope.detailsCampInfo = [];
            $scope.actionCampaigns.departmentID = $rootScope.departmentName;
            $scope.actionCampaigns.campaignNameshow = getrowdata.CampaignId;
            $scope.actionCampaigns.campaignName = getrowdata.LCMCampaignId;
            // $scope.actionCampaigns.GroupName =getrowdata.CampaignGroup;
            $scope.actionCampaigns.GroupName = "Collections";
            $scope.Obj.poptab = tabId;
            $scope.AssociationContactDetailsGrid.data = [];
            $scope.GetCampaignAssociation(getrowdata.LCMCampaignId);    
            surveyCampFactory.GetDetailedCampaignInfo($scope.actionCampaigns).then(function (data) {
                if (data.statusText == 'OK') {    
                    $('.modal-dialog .card').resizable().draggable({
                        containment: ".page-content"
                    });
                    $('.modal').on('hidden.bs.modal', function (e) {
                        $('.modal-dialog .card').css({ top: 0, left: 0 });
                        $scope.validateOnSubmit    = false;
                    })
                    $('#detailsSurveyInfo').modal('show');
                    $scope.detailsCampInfo = data.data.campaignFullDetail.objContactDetails;
                    $scope.successCampCount=data.data.CampaignSuccessCount;
                    $scope.campDetails = data.data.campaignInfo[0];
                    $scope.ContactModeCount = data.data.ContactModeCount[0];
                    $scope.campaingSuccess = $scope.detailsCampInfo.TotalContacts == 0 ? 0 : (($scope.detailsCampInfo.CallsConnected / $scope.detailsCampInfo.TotalContacts) * 100)
                    console.log($scope.detailsCampInfo);
                    $scope.validateOnSubmit = false;
                    $scope.Obj.poptab;
                } else {
                    toaster.pop({
                        type: "error",
                        body: "Error while selecting campaign details"
                    });
    
                }
            });
    
        }
        $scope.refreshLivedata = function(tabNo){
            $scope.showDetails($scope.receivedRowdata,tabNo);
        }
    
        $scope.showStart = function (getrowdata) {
            $scope.actionCampaigns = {};
            $scope.actionCampaigns.department = $rootScope.departmentName;
            $scope.actionCampaigns.campaignID = getrowdata.CampaignId;
            $scope.actionCampaigns.status = "START";
            $scope.actionCampaigns.LCMcampaignID = getrowdata.LCMCampaignId;
            $scope.actionCampaigns.GroupName = getrowdata.CampaignGroup;
    
    
            surveyCampFactory.DoCampaignAction($scope.actionCampaigns).then(function (data) {    
    
                if (data.statusText == 'OK') {
                    $scope.GetAllCampaignbyDept();
                    //toaster.pop({ type: "success", body: "Campaign started successfully" });
    
                } else {
                    $scope.GetAllCampaignbyDept();
                    toaster.pop({
                        type: "error",
                        body: "Error while starting Campaign"
                    });
    
                }
            });
    
        }
    
        $scope.showFlush = function (getrowdata) {
            $scope.actionCampaigns = {};
            $scope.actionCampaigns.department = $rootScope.departmentName;
            $scope.actionCampaigns.campaignID = getrowdata.CampaignId;
            $scope.actionCampaigns.status = "FLUSH";
            $scope.actionCampaigns.campaignID = getrowdata.CampaignId;
            $scope.actionCampaigns.GroupName = getrowdata.CampaignGroup;
            $('#confirmFlush').modal('show');
    
        }
    
        $scope.showStop = function (getrowdata) {
            $scope.actionCampaigns = {};
            $scope.actionCampaigns.department = $rootScope.departmentName;
            $scope.actionCampaigns.campaignID = getrowdata.CampaignId;
            $scope.actionCampaigns.status = "STOP";
            $scope.actionCampaigns.GroupName = getrowdata.CampaignGroup;
            $scope.actionCampaigns.LCMcampaignID = getrowdata.LCMCampaignId;
            surveyCampFactory.DoCampaignAction($scope.actionCampaigns).then(function (data) {
    
    
    
                if (data.statusText == 'OK') {
                    $scope.GetAllCampaignbyDept();
                    //toaster.pop({ type: "success", body: "Campaign stopped successfully" });
    
                } else {
                    $scope.GetAllCampaignbyDept();
                    toaster.pop({
                        type: "error",
                        body: "Error while stopping Campaign"
                    });
    
                }
            });
    
        }
    
        $scope.showAdd = function () {
            $scope.surveyCampaigns = {};
            resetcalender();
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
                $scope.validateOnSubmit    = false;
            })
            $scope.surveyCampaigns.departmentName = $rootScope.departmentName;
            $scope.GetCiscoCampaignbyDept($rootScope.departmentName);
          
            $('#addSurvey').modal('show');
        }
    
        $scope.showEdit = function (getrowdata) {
            $scope.surveyCampaigns = {};
            surveyCampFactory.GETCampaignInfo(getrowdata.LCMCampaignId, $rootScope.departmentName).then(function (campdata) {
                if (campdata.data.campaignInfo.length < 1) {
                    return;
                }
                $scope.surveyCampaigns.description = campdata.data.campaignInfo[0].CampaignDescription;
                $scope.surveyCampaigns.createdStartDate = getrowdata.StartDate;
                $scope.surveyCampaigns.createdEndDate = getrowdata.EndDate;
                $scope.surveyCampaigns.UpdatedBy = campdata.data.campaignInfo[0].CreatedBy;
                $scope.surveyCampaigns.DayNumber = campdata.data.workingDay;
                if (campdata.data.campaignResponse.CreateCampaign.DialPlanRetries > 0) {
                    $scope.surveyCampaigns.noOfTries = (campdata.data.campaignResponse.CreateCampaign.DialPlanRetries).toString();
                }
    
                $scope.workDays = [{
                    id: 1,
                    selected: false,
                    name: 'M',
                    fullName: 'Monday'
                },
                {
                    id: 2,
                    selected: false,
                    name: 'T',
                    fullName: 'Tuesday'
                },
                {
                    id: 3,
                    selected: false,
                    name: 'W',
                    fullName: 'Wednesday'
                },
                {
                    id: 4,
                    selected: false,
                    name: 'T',
                    fullName: 'Thursday'
                },
                {
                    id: 5,
                    selected: false,
                    name: 'F',
                    fullName: 'Friday'
                },
                {
                    id: 6,
                    selected: false,
                    name: 'S',
                    fullName: 'Saturday'
                },
                {
                    id: 7,
                    selected: false,
                    name: 'S',
                    fullName: 'Sunday'
                },
                ];
    
    
                $scope.workDays.forEach(function (value, key) {
                    if (campdata.data.workingDay.length > 0) {
                        campdata.data.workingDay.forEach(function (dayID) {
                            if (value.id == dayID) {
                                value.selected = true;
                                // $scope.selectedDays.push(value);                      
                            } else {
                                // $scope.selectedDays.push(value);  
                            }
                        })
                    }
                });
    
    
                surveyCampFactory.GetCiscoCampaignbyDept($rootScope.departmentName).then(function (data) {
                    if (data.data != null && data.data != undefined) {
                        $scope.surveyCampaigns.departmentName = $rootScope.departmentName;
                        $scope.surveyCampaigns.campaignName = getrowdata.CampaignId;
                        $scope.surveyCampaigns.LCMcampaignID = getrowdata.LCMCampaignId;
                        $scope.surveyCampaigns.startDate = getrowdata.StartDate;
                        $scope.surveyCampaigns.endDate = getrowdata.EndDate;
                        $scope.surveyCampaigns.enableDisable = true;
                        $('.modal-dialog .card').resizable().draggable({
                            containment: ".page-content"
                        });
                        $('.modal').on('hidden.bs.modal', function (e) {
                            $('.modal-dialog .card').css({ top: 0, left: 0 });
                            $scope.validateOnSubmit    = false;
                        })
    
                        $('#modifySurvey').modal('show');
                    } else {
                        $scope.CiscoCampaign = null;
                    }
                });
            });
    
    
        }
    
        $scope.showDelete = function (getrowdata) {
            $scope.actionCampaigns = {};
            $scope.actionCampaigns.department = $rootScope.departmentName;
            $scope.actionCampaigns.LCMcampaignID = getrowdata.LCMCampaignId;
            $scope.actionCampaigns.campaignID = getrowdata.CampaignId;
            $scope.actionCampaigns.status = "DELETE";
            $scope.actionCampaigns.GroupName = getrowdata.CampaignGroup;
            $('#confirmDelete').modal('show');
        }
        /*  End of Campaign Index funcationality **/
    
        /* Start of Add Campaign funcationality **/
    
        $scope.surveyCampaigns = {
            startDate: new Date(),
            endDate: new Date()
        }
    
        $scope.open = {
            startDate: false,
            endDate: false
        }
        $scope.openCalendar = function (e, date) {
            e.preventDefault();
            e.stopPropagation();
            $scope.open = {};
            $scope.open[date] = true;
        };
    
        /* End Add Campaign funcationality **/
    
        /* Private Methods **/
        $scope.FlushSurveyCampaign = function () {
            if ($scope.actionCampaigns != null) {
                surveyCampFactory.DoCampaignAction($scope.actionCampaigns).then(function (data) {
    
    
    
                    if (data.data == 1) {
                        $scope.GetAllCampaignbyDept();
                        //toaster.pop({ type: "success", body: "Campaign flushed successfully" });
                        $('#confirmFlush').modal('hide');
                    } else {
                        $scope.GetAllCampaignbyDept();
                        toaster.pop({
                            type: "error",
                            body: "Error while flushing Campaign"
                        });
    
                    }
                });
            }
    
        }
    
        $scope.CreateSurveyCampaign = function (opt) {
            $scope.validateOnSubmit    = true;
            var startdate = moment($scope.surveyCampaigns.startDate).format("YYYY-MM-DD HH:mm:ss");
            var enddate = moment($scope.surveyCampaigns.endDate).format("YYYY-MM-DD HH:mm:ss");
    
            IsValidInputscampaign("ADD");
            // $scope.isValid = true;
            if ($scope.isValid == true) {
    
                $scope.surveyCampaignsList = {
                    createcampaign: {
                        "CampaignId": $scope.surveyCampaigns.campaignName,
                        "CreateUser": "1",
                        "CreateTime": $scope.surveyCampaigns.startDate,
                        "StartDate": startdate,
                        "EndDate": enddate,
                        "PaceMode": 8,
                        "TypeId": "CISCO",
                        "StartTime": startdate,
                        "EndTime": enddate,
                        "Description": $scope.surveyCampaigns.description,
                        "ZoneName": "(UTC+05:30) Chennai Kolkata Mumbai New Delhi",
                        "AutoStopDays": 0,
                        "DialPlanRetries": parseInt($scope.surveyCampaigns.noOfTries),
                        "OutcomeGroup": "",
                        "DialPlanName": "Default_Advanced_Strategy",
                        "FilePath": "",
                        "GroupName": '',
                        "CallGuide": 0,
                        "DayNames": "sat;sun",
                        "EnabledStateLaw": false,
                        "CloseGlobalRetry": false,
                        "DPRetriesType": "\u0000",
                        "IsCiscoGroup": true,
                        "RetainPCB": false,
                        "EnableChaining": false,
                        "CallStartegyType": 1,
                        "CycleRetryCount": 1,
                        "CycleRetryClose": true,
                        "CycleDays": 0,
                        "CycleHours": 0,
                        "CycleMinute": 0,
                        "IsCycleRetryEnabled": true,
                        "StateLawFollowType": "\u0000",
                        "DailyRetries": $scope.surveyCampaigns.noOfTries,
                        "TimeToLive": 365,
                        "TimezoneType": 0,
                        "SMSServerId": 0,
                        "EmailServerId": 0,
                        "Prefix": "",
                        "Suffix": "",
                        "EnableDNC": false,
                        "GlobalDNC": false,
                        "Callback": true,
                        "PCBRetries": 1,
                        "PCBOffsetDays": 0,
                        "PCBOffsetHours": 0,
                        "PCBOffsetMinute": 0,
                        "CallbackStrategy": "Default_Callback_Strategy",
                        "PreCallScript": false,
                        "CallbackStrategyType": "R",
                        "ResetGlobalRetries": false,
                        "PEWC": false,
                        "IsULCampaign": false,
                        "PostCallScript": false,
                        "PrecallScriptValue": 1,
                        "PostcallScriptValue": 0,
                        "EmailThreshold": 5,
                        "WindowGlobalRetry": false,
                        "WindowAttempts": 0,
                        "WindowDuration": 0,
                        "MultipleZipCode": false,
                        "ISMultipleZipCodeEnable": false,
                        "CampaignKey": 6,
                        "CampaignType": 1,
                        "DedicatedCampaignGroupType": 0,
                        "CampaignGroupType": 0
                    }
    
                }
                $scope.surveyCampaignsList.DayNumber = $scope.surveyCampaigns.DayNumber;
                $scope.surveyCampaignsList.uploadedBy = userObj.SSOID;
                $scope.surveyCampaignsList.description = $scope.surveyCampaigns.description;
                $scope.surveyCampaignsList.actionFlag = '1';
                $scope.surveyCampaignsList.campaignName = $scope.surveyCampaigns.campaignName;
                if (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) {
                    $scope.surveyCampaignsList.departmentName = $scope.surveyCampaigns.department.ID;
                } else {
                    $scope.surveyCampaignsList.departmentName = $rootScope.departmentName;
                }
    
                // $scope.surveyCampaigns.startDate = moment($scope.startDate).format('DD/MM/YYYY HH:mm');
                // $scope.surveyCampaigns.endDate = moment($scope.endDate).format('DD/MM/YYYY HH:mm');
    
                //alert(json2xml($scope.surveyCampaigns));
                surveyCampFactory.CreateSurveyCampaign($scope.surveyCampaignsList).then(function (data) {
    
    
    
                    if (data.data.statusMessage == "Success") {
    
                        $scope.GetAllCampaignbyDept();
                        $('#addSurvey').modal('hide');
                        if (opt == 2) {
                            $scope.showUpload(2);
                        } else {
                            $scope.surveyCampaigns = {};
                            $scope.onTabChange(1);
                        }
                        toaster.pop({
                            type: "success",
                            body: "Campaign created successfully"
                        });
                    } else {
                        $scope.GetAllCampaignbyDept();
                        toaster.pop({
                            type: "error",
                            body: "Error while creating Campaign"
                        });
    
                        $scope.surveyCampaigns = {};
                    }
                });
            }
    
    
        }
    
        $scope.ModifySurveyCampaign = function () {
            $scope.validateOnSubmit    = true;
            IsValidInputscampaign("MODIFY");
            if ($scope.isValid == true) {
    
                var startdate = moment($scope.surveyCampaigns.startDate).format("YYYY-MM-DD HH:mm:ss");
                var enddate = moment($scope.surveyCampaigns.endDate).format("YYYY-MM-DD HH:mm:ss");
    
                $scope.surveyCampaignsList = {
                    editCampaign: {
                        "CampaignId": $scope.surveyCampaigns.campaignName,
                        "CreateUser": "1",
                        "CreateTime": $scope.surveyCampaigns.startDate,
                        "StartDate": startdate,
                        "EndDate": enddate,
                        "PaceMode": 8,
                        "TypeId": "CISCO",
                        "StartTime": startdate,
                        "EndTime": enddate,
                        "Description": $scope.surveyCampaigns.description,
                        "ZoneName": "(UTC+05:30) Chennai Kolkata Mumbai New Delhi",
                        "AutoStopDays": 0,
                        "DialPlanRetries": parseInt($scope.surveyCampaigns.noOfTries),
                        "OutcomeGroup": "",
                        "DialPlanName": "Default_Advanced_Strategy",
                        "FilePath": "",
                        "GroupName": '',
                        "CallGuide": 0,
                        "DayNames": "sat;sun",
                        "EnabledStateLaw": false,
                        "CloseGlobalRetry": false,
                        "DPRetriesType": "\u0000",
                        "IsCiscoGroup": true,
                        "RetainPCB": false,
                        "EnableChaining": false,
                        "CallStartegyType": 1,
                        "CycleRetryCount": 1,
                        "CycleRetryClose": true,
                        "CycleDays": 0,
                        "CycleHours": 0,
                        "CycleMinute": 0,
                        "IsCycleRetryEnabled": true,
                        "StateLawFollowType": "\u0000",
                        "DailyRetries": $scope.surveyCampaigns.noOfTries,
                        "TimeToLive": 365,
                        "TimezoneType": 0,
                        "SMSServerId": 0,
                        "EmailServerId": 0,
                        "Prefix": "",
                        "Suffix": "",
                        "EnableDNC": false,
                        "GlobalDNC": false,
                        "Callback": true,
                        "PCBRetries": 1,
                        "PCBOffsetDays": 0,
                        "PCBOffsetHours": 0,
                        "PCBOffsetMinute": 0,
                        "CallbackStrategy": "Default_Callback_Strategy",
                        "PreCallScript": false,
                        "CallbackStrategyType": "R",
                        "ResetGlobalRetries": false,
                        "PEWC": false,
                        "IsULCampaign": false,
                        "PostCallScript": false,
                        "PrecallScriptValue": 1,
                        "PostcallScriptValue": 0,
                        "EmailThreshold": 5,
                        "WindowGlobalRetry": false,
                        "WindowAttempts": 0,
                        "WindowDuration": 0,
                        "MultipleZipCode": false,
                        "ISMultipleZipCodeEnable": false,
                        "CampaignKey": 6,
                        "CampaignType": 1,
                        "DedicatedCampaignGroupType": 0,
                        "CampaignGroupType": 0
                    }
    
                }
                $scope.surveyCampaignsList.DayNumber = $scope.surveyCampaigns.DayNumber;
                $scope.surveyCampaignsList.uploadedBy = userObj.SSOID;
                $scope.surveyCampaignsList.description = $scope.surveyCampaigns.description;
                $scope.surveyCampaignsList.actionFlag = '1';
                $scope.surveyCampaignsList.departmentName = $rootScope.departmentName;
                $scope.surveyCampaignsList.campaignName = $scope.surveyCampaigns.campaignName;
                $scope.surveyCampaignsList.campaignName = $scope.surveyCampaigns.LCMcampaignID;
                surveyCampFactory.ModifySurveyCampaign($scope.surveyCampaignsList).then(function (data) {
                    if (data.data == "50025") {
                        $scope.GetAllCampaignbyDept();
                        $('#modifySurvey').modal('hide');
                        toaster.pop({
                            type: "success",
                            body: "Campaign edited successfully"
                        });
    
                        $scope.surveyCampaigns = {};
                    } else {
                        $scope.GetAllCampaignbyDept();
                        toaster.pop({
                            type: "error",
                            body: "Error while editing Campaign"
                        });
    
                        $scope.surveyCampaigns = {};
                    }
                });
            }
    
        }
    
        $scope.DeleteSurveyCampaign = function () {
    
            if ($scope.actionCampaigns != null && $scope.actionCampaigns != undefined) {
                $scope.actionCampaigns.uploadedBy = userObj.SSOID;
                $scope.actionCampaigns.updateID = '';
                $scope.actionCampaigns.actionFlag = 'D';
                surveyCampFactory.DoCampaignAction($scope.actionCampaigns).then(function (data) {
    
    
                    if (data.data == '50014') {
                        $scope.GetAllCampaignbyDept();
                        // toaster.pop({ type: "success", body: "Campaign deleted successfully" });
                        $('#confirmDelete').modal('hide');
                    } else {
                        $scope.GetAllCampaignbyDept();
                        toaster.pop({
                            type: "error",
                            body: "Error while deleting Campaign"
                        });
                    }
                });
    
            }
        }
    
    
        var IsValidInputscampaign = function (action) {
            $scope.isValid = true;
            var errMsg = campaignFactory.validateCampaign(action, $scope.surveyCampaigns, $scope.campaignData);
            if (!errMsg) {
                $scope.isValid = true;
                $scope.iscampaignNameExist=false;
                $scope.Message='';
            } else {
                $scope.isValid = false;
                $scope.iscampaignNameExist=false;
                $scope.Message='';
                if(errMsg==2){
                    $scope.iscampaignNameExist=true;
                            }
                if(isNaN(errMsg)){
                    $scope.Message=errMsg;
                   
                }
                // toaster.pop({
                //     type: 'error',
                //     body: errMsg
                // });
            }
        }
    
        $scope.selectedStep = 0;
        $scope.stepProgress = 1;
        $scope.maxStep = 3;
        $scope.showBusyText = false;
        $scope.stepData = [{
            step: 1,
            completed: false,
            optional: false,
            data: {}
        },
        {
            step: 2,
            completed: false,
            optional: false,
            data: {}
        },
        {
            step: 3,
            completed: false,
            optional: false,
            data: {}
        },
    
        ];
        $scope.selectedoption = 'File';
        $scope.deptTypeList = [];
    
        var SELECTION_OPTIONS = {
            RAJS_SAMPARK: 'From Rajasthan Sampark',
            BHAMASHAH_DB: 'From Bamashah DataBase',
            EXT_FILE: 'From External Files'
        };
    
        $scope.setselectedoption = function (option) {
            $scope.validateOnSubmit = false;
            if (option === 'RajasthanSamparkDB') {
                $scope.getValues($scope.SAMPARK_GRIEVANCE_DB.DEPT_TYPE);
                $scope.getValues($scope.SAMPARK_GRIEVANCE_DB.DIVISION);
            }
            $scope.selectedoption = option;
        };
    
        $scope.onValuesEntered = function (selectionType) {
            switch (selectionType) {
                case ($scope.SAMPARK_GRIEVANCE_DB.DEPT_TYPE):
                    if ($scope.RajSamDBSet.deptType) {
                        return;
                    }
                    $scope.RajSamDBSet.dept = '';
                    $scope.RajSamDBSet.scheme = '';
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.DIVISION):
                    if ($scope.RajSamDBSet.division) {
                        return;
                    }
                    $scope.districtList = [];
                    $scope.panchayatList = [];
                    $scope.gramPanchayat = [];
                    $scope.villageList = [];
                    $scope.RajSamDBSet.district = '';
                    $scope.RajSamDBSet.panchayat = '';
                    $scope.RajSamDBSet.gramPanchayat = '';
                    $scope.RajSamDBSet.village = '';
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.DISTRICT):
                    if ($scope.RajSamDBSet.district) {
                        return;
                    }
                    $scope.panchayatList = [];
                    $scope.gramPanchayat = [];
                    $scope.villageList = [];
                    $scope.RajSamDBSet.panchayat = '';
                    $scope.RajSamDBSet.gramPanchayat = '';
                    $scope.RajSamDBSet.village = '';
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.PANCHAYAT):
                    if ($scope.RajSamDBSet.panchayat) {
                        return;
                    }
                    $scope.gramPanchayat = [];
                    $scope.villageList = [];
                    $scope.RajSamDBSet.gramPanchayat = '';
                    $scope.RajSamDBSet.village = '';
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.GRAM_PANCHAYAT):
                    if ($scope.RajSamDBSet.gramPanchayat) {
                        return;
                    }
                    $scope.RajSamDBSet.village = '';
                    $scope.villageList = [];
                    break;
                default:
                    break;
            }
        };
        $scope.getValues = function (selectionType) {
            switch (selectionType) {
                case ($scope.SAMPARK_GRIEVANCE_DB.DEPT_TYPE):
                    getDepartmentTypes();
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.DEPT):
                    getDepartmentByType();
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.COMPLAINS):
                    getComplaintsByDepartment();
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.DIVISION):
                    getDivisions();
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.DISTRICT):
                    getDistrictByDivision();
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.PANCHAYAT):
                    getPanchayatByDistrict();
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.GRAM_PANCHAYAT):
                    getGramPanchayatByPanchayat();
                    break;
                case ($scope.SAMPARK_GRIEVANCE_DB.VILLAGE):
                    getVillageByGramPanchayat();
                    break;
                default:
                    break;
            }
        };
    
        var getDepartmentTypes = function () {
            surveyCampFactory.getDepartmentTypes().then(function (data) {
                if (data.data !== null && data.data !== undefined) {
                    $scope.deptTypeList = data.data;
                }
            });
        };
    
        var getDivisions = function () {
            surveyCampFactory.getDivions().then(function (data) {
                if (data.data !== null && data.data !== undefined) {
                    $scope.divisionList = data.data;
                }
            });
        };
    
        var getDepartmentByType = function () {
            surveyCampFactory.getDepartmentByType($scope.RajSamDBSet.deptType.DEPT_TYPE_ID).then(function (data) {
                if (data.data !== null && data.data !== undefined) {
                    $scope.deptList = data.data;
                }
            });
        };
    
        var getComplaintsByDepartment = function () {
            surveyCampFactory.getComplaintsByDepartment($scope.RajSamDBSet.deptType.DEPT_TYPE_ID).then(function (data) {
                if (data.data !== null && data.data !== undefined) {
                    $scope.schemeList = data.data;
                }
            });
        };
    
        var getDistrictByDivision = function () {
            surveyCampFactory.getDistrictByDivision($scope.RajSamDBSet.division.DIVISION_ID).then(function (data) {
                if (data.data !== null && data.data !== undefined) {
                    $scope.districtList = data.data;
                }
            });
        };
    
        var getPanchayatByDistrict = function () {
            surveyCampFactory.getPanchayatByDistrict($scope.RajSamDBSet.district.DISTRICT_ID).then(function (data) {
                if (data.data !== null && data.data !== undefined) {
                    $scope.panchayatList = data.data;
                }
            });
        };
    
        var getGramPanchayatByPanchayat = function () {
            surveyCampFactory.getGramPanchayatByPanchayat($scope.RajSamDBSet.panchayat.LOC_ID).then(function (data) {
                if (data.data !== null && data.data !== undefined) {
                    $scope.gramPanchayatList = data.data;
                }
            });
        };
    
        var getVillageByGramPanchayat = function () {
            surveyCampFactory.getVillageByGramPanchayat($scope.RajSamDBSet.gramPanchayat.LOC_ID).then(function (data) {
                if (data.data !== null && data.data !== undefined) {
                    $scope.villageList = data.data;
                }
            });
        };
    
        $scope.UploadVoiceCampaignReq = {};
        $scope.UploadVoiceCampaignRes = [];
        $scope.uploadStatusInfo = [];
        $scope.UpdateUploadmsgReq = {};
        $scope.CampaignListByDept = {};
        $scope.resultdata = [];
    
    
        $scope.isfileupload = false;
        $scope.Isnotnull = false;
        $scope.isValid = true;
        $scope.isgridShow = false;
        $rootScope.isDemo = false;
    
        $rootScope.selectedCampaign = "";
    
    
        // ***** Start of Upload Contact funcationality ***** //
    
    
    
        $scope.ContactDetailsGrid = {
            enableColumnResizing: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Campaign Name',
                field: 'CampaignName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Sample Name',
                field: 'SampleName',
                isSearchable: true,
                cellTooltip: true
            },
    
            {
                name: 'File Name',
                field: 'FileName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Uploaded Date',
                field: 'UploadedDate',
                cellTooltip: true,
                cellFilter: 'date:\'dd-MM-yy HH:mm\''
            },
            {
                name: 'Total Records',
                field: 'TotalRecords',
                cellTooltip: true,
            },
    
            {
                name: 'Options',
                enableSorting: false,
                width: '10%',
                cellTemplate: '<a href="#" class="action-status" ng-click="grid.appScope.showUploadStatus(row.entity)"> <span class="fa fa-eye" title="View Status"></span></a>'
                // + ' | ' + '<a href="#" class="action-status" ng-click="grid.appScope.showUpload(row.entity)">'
                // + '<span class="fa fa-upload" title="Upload"></span></a>'
                // | <a href="#" class="action-status" ng-click="grid.appScope.showDemoTemplate(row.entity)"> <span class="fa fa-chevron-circle-right" title="Demo View"></span></a>'
            },
            ]
        };
    
    
    
        $scope.Samplegrid = {
            // enableCellEdit: false, // set all columns to non-editable unless otherwise specified; cellEditableCondition won't override that
            // enableCellEditOnFocus: true, // set any editable column to allow edit on focus
            enableRowSelection: true,
            // enableFiltering: true,
            enableColumnResizing: true,
            enableSelectAll: true,
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            // cellEditableCondition: function ($scope) {
            //     // put your enable-edit code here, using values from $scope.row.entity and/or $scope.col.colDef as you desire
            //     return true; // in this example, we'll only allow active rows to be edited
            // },
            columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                enableCellEdit: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Campaign Name',
                field: 'DisplayCampaignName',
                isSearchable: true,
                enableCellEdit: false,
                cellTooltip: true
            },
            {
                name: 'Sample Name',
                field: 'SampleName',
                isSearchable: true,
                enableCellEdit: false,
                cellTooltip: true
            },
    
            {
                name: 'File Name',
                field: 'FileName',
                isSearchable: true,
                cellTooltip: true,
                enableCellEdit: false,
            },
            {
                name: 'Uploaded Date',
                field: 'UploadedDate',
                cellTooltip: true,
                enableCellEdit: false,
                cellFilter: 'date:\'dd-MM-yy HH:mm\''
            },
            {
                name: 'Total Records',
                field: 'TotalRecords',
                cellTooltip: true,
                enableCellEdit: false
            },
            {
                name: 'Process Records',
                field: 'ProcessRecords',
                enableCellEdit: true,
                cellClass: 'Created'
            },
            {
                name: 'UploadedBy',
                cellTooltip: true,
                width: '10%',
                enableCellEdit: false
            },
            ]
    
        }
    
        $rootScope.selectedGridData = [];
    
        $scope.Samplegrid.onRegisterApi = function (gridApi) {
            $scope.gridApi = gridApi;
            if (gridApi.edit) {
                gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
                    if (newValue > rowEntity.TotalRecords) {
                        appFactory.showWarning("Process record count should not be greater than total records");
                        rowEntity.ProcessRecords = oldValue
                    }
                    if(newValue<=0){
                        appFactory.showWarning("Process record count should  be greater than zero");
                        rowEntity.ProcessRecords = oldValue
                    }
                    $scope.$apply();
                });
            }
            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                var msg = 'row selected on single' + row.isSelected;
                console.log(msg);
                if (row.isSelected == true) {
                    $rootScope.IsselectedGrid = true;
                    $rootScope.selectedGridData.push(row.entity);
                } else {
                    $rootScope.IsselectedGrid = false;
                    $rootScope.selectedGridData = _.without($rootScope.selectedGridData, _.findWhere($rootScope.selectedGridData, {
                        ID: row.entity.ID
                    }))
                }
            });
    
            gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
                var msg = 'row length:' + row.length;
                console.log(msg);
                if (row.length > 0) {
    
                    for (index = 0; index < row.length; index++) {
                        console.log(row[index]);
                        if (row[index].isSelected == true) {
                            $rootScope.IsselectedGrid = true;
                            $rootScope.selectedGridData.push(row[index].entity);
                        } else {
                            $rootScope.IsselectedGrid = false;
                            $rootScope.selectedGridData = [];
                        }
                    }
                }
                if ($rootScope.IsselectedGrid == false) {
                    $rootScope.selectedGridData = null;
                    $rootScope.selectedGridData = [];
                }
            });
    
        };
    
        $scope.GetAllcampaignList = function (isFromActiveCampaign) {
            if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
                var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
                surveyCampFactory.GetAllSurveyCampaignList(departmentName).then(function (data) {
                    if (data.data != null && data.data != undefined) {
                        $rootScope.allCampaignList = data.data;
                    } else {
                        $rootScope.allCampaignList = null;
                    }
                    if ($scope.updatecampaingnforupload) {
                        $scope.isfileupload = false;
                        $scope.isValid = true;
                        $('#uploadContacts').modal('show');
                        $scope.Selectedcampaignforuploaddata = _.filter($rootScope.allCampaignList, function (term) {
                            return term.CampaignName.toLowerCase() == $scope.surveyCampaigns.campaignName.toLowerCase();
                        });
                        if ($scope.Selectedcampaignforuploaddata.length) {
                            $scope.stepData[0].data.selectedcamp = $scope.Selectedcampaignforuploaddata[0];
                        }
                    }
                    if (!isFromActiveCampaign) {
                        $scope.voiceCampaignsName = "";
                    }
                    $scope.updatecampaingnforupload = false;
                });
            }
        }
    
        $scope.GetAllUploadList = function () {
            if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
                var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
                surveyCampFactory.GetAllUploadList(departmentName).then(function (data) {
    
                    if (data.data != null && data.data != undefined) {
                        // $scope.resultdata = _.filter(data.data, function (rowdata) {
                        //     return rowdata.IsDemo == false
                        // });
                        $scope.resultdata = data.data;
                        if ($scope.resultdata.length > 0) {
                            $scope.resultdata.forEach(function (data) {
                                if (data.DataSourceType == "MultiSource")
                                    data.FileName = 'Existing Sample File';
                                else if (data.DataSourceType == "RETRY")
                                    data.FileName = 'Retry';
                            });
                        }
                        $scope.ContactDetailsGrid.data = $scope.resultdata;
                        getSearchableFields($scope.ContactDetailsGrid);
                    } else {
                        $scope.resultdata = null;
                        $scope.ContactDetailsGrid.data = null;
                    }
                });
            }
    
        }
    
    
        $scope.GetSurveyNamesByType = function (typeId) {
            surveyFactory.GetSurveyNamesByType(typeId.ID).then(
                function success(data) {
                    $scope.SurveyNames = data.data;
                },
                function error(data) { }
            )
        }
    
        $scope.refreshupload = function () {
            $scope.GetAllUploadList();
        }
    
        $scope.updatecampaingnforupload = false;
        $scope.useoutscope = false;
        $scope.showUpload = function (opt) {
            $scope.isfileupload = false;
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
                $scope.validateOnSubmit    = false;
            })
            if (opt == 2) {
                $scope.updatecampaingnforupload = true;
                $scope.useoutscope = true;
                $scope.disableSurveyCampaign = true;
            } else {
                $scope.isValid = true;
                $('#uploadContacts').modal('show');
                $scope.disableSurveyCampaign = false;
                $scope.useoutscope = false;
            }
            $scope.clearcontrols();
            $rootScope.isDemo = false;
    
            if (opt) {
                if (opt.CampaignName) {
                    $scope.stepData[0].data.selectedcamp = { 'CampaignName': opt.CampaignName, 'ID': opt.SurveyCampaignID,'Department' :opt.department, };
                    // $scope.stepData[0].data.sampleName=opt.SampleName;
                  } else if (opt.CampaignId){
                    $scope.stepData[0].data.selectedcamp = { 'CampaignName': opt.CampaignId, 'ID': opt.campaignID, 'Department' :opt.department, 'LCMCampaignName': opt.LCMCampaignId }
                }
            }
            $scope.isExceedsMaxAvailableCount = false;
            $scope.isValid = true;
            $('#uploadContacts').modal('show');
    
        }
        $scope.showDemoTemplate = function (getrowdata) {
            $scope.clearcontrols();
            $rootScope.isDemo = true;
            $scope.stepData[0].data.selectedcamp = getrowdata.campaignName;
            // $scope.UploadVoiceCampaignRes.isdemo=true ;
            $scope.isValid = true;
            $('#uploadContacts').modal('show');
        }
    
        $scope.showUploadStatus = function (getrowdata) {
            $scope.uploadStatusInfo = [];
            $scope.actionCampaigns = {};
            $scope.actionCampaigns.departmentID = $rootScope.departmentName;
            $scope.actionCampaigns.campaignName = getrowdata.LCMCampaignID;
            $scope.actionCampaigns.GroupName = "Collections";
            surveyCampFactory.GetDetailUploadStatus($scope.actionCampaigns).then(function (data) {
                $scope.campaignName = getrowdata.CampaignName;
                $('#detailsContactInfo').modal('show');
                $scope.uploadStatusInfo = data.data;
            });
        }
    
        $scope.SurveyContactGrid = {
            paginationPageSizes: [10, 20, 30],
            paginationPageSize: 10,
            enableColumnMenus: false,
            enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
            enableRowSelection: true,
            enableSelectAll: true,
            multiSelct: true,
            enableColumnResizing: true,
        };
    
    
    
        /*** Step process ***/
    
        $scope.enableNextStep = function nextStep() {
            //do not exceed into max step
            if (!$scope.stepData[1].data) {
                return;
            }
            if ($scope.selectedStep >= $scope.maxStep) {
                return;
            }
            //do not increment $scope.stepProgress when submitting from previously completed step
            if ($scope.selectedStep === $scope.stepProgress - 1) {
                $scope.stepProgress = $scope.stepProgress + 1;
            }
            $scope.selectedStep = $scope.selectedStep + 1;
        }
    
        $scope.moveToPreviousStep = function moveToPreviousStep() {
            if ($scope.selectedoption === 'SAS') {
                $scope.stepProgress = 1;
                $scope.selectedStep = 1;
                return;
            }
            if ($scope.selectedStep > 0) {
                $scope.stepProgress = $scope.selectedStep;
                $scope.selectedStep = $scope.selectedStep - 1;
            }
        };
    
        var validateUploadContactFields = function () {
            var errMsg = ''
            if ($scope.selectedoption !== 'Sample') {
                if (!$scope.stepData[0].data.sampleName || !$scope.stepData[0].data.selectedcamp) {
                    errMsg = "Please enter sample name and campaign";
                }
            } else {
                if ($rootScope.selectedGridData.length <= 0) {
                    errMsg = "Please Select Exisiting sample name and value";
                }
            }
            if ($scope.selectedoption === 'File') {
                if (!$scope.stepData[0].data.mobileno) {
                    errMsg = "Mandatory fields need to be mapped";
                }
            }
            return errMsg;
        };
        
        $scope.submitCurrentStep = function submitCurrentStep(stepData, isSkip) {
            $scope.Ismultiplesampleselected = false;
            $scope.validateOnSubmit = true;
            $scope.showBusyText = true;
            var stepvalue = $scope.stepProgress;
            if (!$scope.stepData[0].data) {
                return;
            }
            if ($scope.stepData[1].data != null || $scope.stepData[2].data != null) {
                if (stepvalue == 1) {
                    if ($scope.selectedoption === 'RajasthanSamparkDB') {
                        if (!$scope.RajSamFilterList.length ||
                            !$scope.RajSamDB.startDate || !$scope.RajSamDB.endDate || !$scope.RajSamDB.grievance || !$scope.RajSamDB.grievanceId) {
                            appFactory.showError('Mandtory fields need to be mapped');
                            return;
                        }
                        $scope.SearchRajSamDB($scope.RajSamDB);
                        return;
                    }
                    else if($scope.selectedoption === 'File'){
                        var errMsg = validateUploadContactFields();
                        if (errMsg) {
                            appService.showError(errMsg);
                            return;
                        }
                        if ($scope.selectedoption !== 'Sample') {
                            // $scope.UploadVoiceCampaignRes.UploadID = ($scope.useoutscope) ? $scope.Selectedcampaignforuploaddata[0].ID :
                            //                                                                   $scope.stepData[0].data.selectedcamp.ID;
                            $scope.UploadVoiceCampaignRes.UploadID = $scope.stepData[0].data.selectedcamp.ID;
                            $scope.UploadVoiceCampaignRes.mobileNoField = $scope.stepData[0].data.mobileno;
                        } else {
                            var selectedGridData = $rootScope.selectedGridData;
                            $scope.Ismultiplesampleselected = (selectedGridData.length > 1);
                            var sampleProcessCount = 0;
                            if (selectedGridData.length > 0) {
                                selectedGridData.forEach((gridData) => {
                                    sampleProcessCount = sampleProcessCount + gridData.ProcessRecords;
                                })
                            };
                            $scope.sampleProcessCount = sampleProcessCount;
                            postSampleData();
                        }
                    } else if($scope.selectedoption === 'SAS') {
                        var userToken = sessionStorage.getItem('SSOToken');
                        // var userToken = 'NUpYZktraUY4aUMyWllIOHRwOXllZ2N4NjEyTDJad1RVbmpscVV3YTJYTkVDWnFnZGhGM1MzaFdrZUJqYm5Xa0RKZ0ZHSFBNcVlkY3NELzZtN2ZITnRmS1RnZnlleFF3eURiOHc3MmdTbkZhei8zczI0N0tYVFgyV2Rma1VWcXZXVVJHb0lJUlNmUDVKbUcyb3ZkcGlidG9SeVBwMUJnSUd3WnJjUmkvdElzPQ==';
                        var surveyId = $scope.stepData[0].data.surveyName.ID;
                        var campaignId = $scope.stepData[0].data.selectedcamp.ID;
                        var questionTypeId = $scope.stepData[0].data.surveyType.ID;
                        var url = config.LINK_APP_URL.SAS;
                        var returnURL = config.LINK_APP_URL.SAS_UCG;
                        sessionStorage.setItem('SASSurvey', JSON.stringify($scope.stepData[0].data));
                        sessionStorage.setItem('SASToken', userToken);
                        window.location.href = url + '?token=' + userToken + '&campaign_id=' + campaignId + '&survey_id=' + surveyId + '&question_type_id=' + questionTypeId + '&redirecturl=' + returnURL + '?token=' + userToken;
                        return;
                    }
                    if ($scope.selectedoption === 'Sample') {
                        var selectedGridData = $rootScope.selectedGridData;
                        var sampleProcessCount = 0;
                        if (selectedGridData.length > 0) {
                            selectedGridData.forEach((gridData) => {
                                sampleProcessCount = sampleProcessCount + gridData.ProcessRecords;
                            })
                        };
                        $scope.sampleProcessCount = sampleProcessCount;
                    }
                }
            }
            if (stepvalue == 2) {
                /* handled in step 3 finial finish **/
                // $scope.CreateSampleSurvey($scope.selectedoption);
                $scope.UploadVoiceCampaignRes.uploadStatus = "READY";
                $scope.UploadVoiceCampaignRes.mobileNoField = $scope.stepData[0].data.mobileno;
    
                $scope.sampleSetting.intervalInDays = '1';
                surveyCampFactory.getLCMCampaignInfo($scope.stepData[0].data.selectedcamp.LCMCampaignName).then(
                    function(data) {
                        if (data.data && data.data.CreateCampaign) {
                            var CreateCampaign = data.data.CreateCampaign;
                            enableNextStepper(stepData, isSkip);
                            $scope.sampleSetting.startDate = CreateCampaign.StartDate;
                            $scope.sampleSetting.endDate = CreateCampaign.EndDate;
                            $scope.sampleSetting.campaignStartDate = CreateCampaign.StartDate;
                            $scope.sampleSetting.campaignEndDate = CreateCampaign.EndDate;
                        }
                    },
                    function(data) {

                    }
                );
                // $scope.sampleSetting.isAutomatedIVR = true;
                // setStartAndEndTime($scope.sampleSetting);
            }
            if (stepvalue == 3) {
                $scope.isValid = true;
                $('#uploadContacts').modal('hide');
                // $scope.CreateSampleSurvey($scope.selectedoption);
            }
            if (stepvalue !== 2) {
                enableNextStepper(stepData, isSkip);
            }
            
        };

        var enableNextStepper = function(stepData, isSkip) {
            if (!stepData.completed && !isSkip) {
                //simulate $http
                var deferred = $q.defer();
                $timeout(function () {
                    $scope.validateOnSubmit = false;
                    $scope.showBusyText = false;
                    deferred.resolve({
                        status: 200,
                        statusText: 'success',
                        data: {}
                    });
                    //move to next step when success
                    stepData.completed = true;
                    $scope.enableNextStep();
                }, 1000)
            } else {
                $scope.validateOnSubmit = false;
                $scope.showBusyText = false;
                $scope.enableNextStep();
            }
        }
    
        var postSampleData = function () {
            var sampleData = {};
            sampleData.rajSamparkFilter = {};
            sampleData.bhamashaFilter = {};
            sampleData.dataSourceType = 'SampleData';
            sampleData.sampleID = $rootScope.selectedGridData[0].ID; // $scope.stepData[0].data.selectedExtSample.ID;
            sampleData.lcmCampaignID = $scope.stepData[0].data.selectedcamp.LCMCampaignName;
            sampleData.sampleName = $scope.stepData[0].data.selectedcamp.CampaignName;
            sampleData.uploadDepID = $scope.stepData[0].data.selectedcamp.Department;
            // sampleData.sampleID  = 10;
            surveyFactory.postSampleData(sampleData, cbsPostSampleData, cbsPostSampleData);
        };
    
        var cbsPostSampleData = function (data) {
            $scope.showBusyText = false;
            if (!data.data || !data.data.uploadSampleData.length) {
                appFactory.showError('Error while uploading sample data');
                return;
            }
            $scope.campaignUsage = data.data.campaignSurveyUsage[0];
            $scope.campaignUsage.totalRecords = data.data.totalRecords;
            $scope.isExceedsMaxAvailableCount = false;
            if (!$scope.campaignUsage || ($scope.campaignUsage.TotalAvailableCount < ($scope.campaignUsage.TotalUsedCount + $scope.campaignUsage.totalRecords))) {
                appFactory.showToasterErr('Exceeds Avaliable Count');
                $scope.isExceedsMaxAvailableCount = true;
                appFactory.HideLoader();
                return;
            }
            $scope.UploadVoiceCampaignRes = data.data;
            $scope.sampleSetting.startDate = $scope.UploadVoiceCampaignRes.campaignStartDate;
            $scope.sampleSetting.endDate = $scope.UploadVoiceCampaignRes.campaignEndDate;
            $scope.sampleSetting.campaignStartDate = $scope.UploadVoiceCampaignRes.campaignStartDate;
            $scope.sampleSetting.campaignEndDate = $scope.UploadVoiceCampaignRes.campaignEndDate;
            $scope.SurveyContactGrid.data = data.data.uploadSampleData;
            $scope.enableNextStep();
        };
        var cbfPostSampleData = function (data) {
    
        }
        /*** Step process ***/
    
        // ***** End of Upload Contact funcationality ***** //
    
    
        // ***** Rajasthan Sampark grievance database methods   ****//
        $scope.RajSamFilterList = [];
        $scope.RajSamDBSet = {};
        $scope.deptList = [];
        $scope.schemeList = [];
        $scope.divisionList = [];
        $scope.districtList = [];
        $scope.panchayatList = [];
        $scope.gramPanchayatList = [];
        $scope.villageList = [];
        $scope.grievanceList = [{
            id: 1,
            name: 'grivance 1'
        },
        {
            id: 2,
            name: 'grivance 2'
        },
        {
            id: 3,
            name: 'grivance 3'
        },
        ]
        $scope.RajSampDBDetails = {};
    
        var createRajSamDBList = function (list) {
            // var errorMsg = validateRajSamFilter(list);
            // if (errorMsg) {
            //     toaster.pop({
            //         type: 'Failure',
            //         body: errorMsg,
            //         bodyOutputType: 'trustedHtml'
            //     });
            //     return;
            // }
            var RajSamFilterList = [];
            var selectedFileds = {};
            if (list.deptType) {
                selectedFileds.deptType = list.deptType.DEPT_TYPE_ID;
            }
            if (list.scheme) {
                selectedFileds.scheme = list.scheme.COMP_TYPE_ID;
            }
            if (list.division) {
                selectedFileds.division = list.division.DIVISION_ID;
                selectedFileds.text = list.division.DIVISION_NAME;
            }
            if (list.district) {
                selectedFileds.district = list.district.DISTRICT_ID;
            }
            if (list.village) {
                selectedFileds.village = list.village.LOC_ID;
            }
            if (list.gramPanchayat) {
                selectedFileds.gramPanchayat = list.gramPanchayat.LOC_ID;
            }
            if (list.panchayat) {
                selectedFileds.panchayat = list.panchayat.LOC_ID;
            }
            RajSamFilterList.push(selectedFileds);
            return RajSamFilterList;
        };
    
        var validateRajSamFilter = function (rajSamDBSet) {
            var errorMessage = '';
            if (!rajSamDBSet) {
                return errorMessage = 'Please Select Values';
            }
            if (!rajSamDBSet.deptType.DEPT_TYPE_NAME) {
                return errorMessage = 'Please Select Department type';
            }
            if (!rajSamDBSet.dept.DEPT_NAME) {
                return errorMessage = 'Please Select Values Department';
            }
            if (!rajSamDBSet.scheme.COMP_TYPE_NAME) {
                return errorMessage = 'Please Select Values work/service/scheme';
            }
            if (!rajSamDBSet.division.DIVISION_NAME) {
                return errorMessage = 'Please Select Divion';
            }
            if (!rajSamDBSet.district.DISTRICT_NAME) {
                return errorMessage = 'Please Select District';
            }
            if (!rajSamDBSet.village.LOC_NAME) {
                return errorMessage = 'Please Select Village';
            }
            if (!rajSamDBSet.gramPanchayat.LOC_NAME) {
                return errorMessage = 'Please Select Gram Panchayat';
            }
            if (!rajSamDBSet.panchayat.LOC_NAME) {
                return errorMessage = 'Please Select Panchayat';
            }
        };
    
        $scope.AddRajSamDBList = function () {
            var RajSamDBSet = createRajSamDBList($scope.RajSamDBSet);
            if (!RajSamDBSet) {
                return;
            }
            $scope.RajSamFilterList = $scope.RajSamFilterList.concat(RajSamDBSet);
            var rajSamDBSet = $scope.RajSamDBSet;
            $scope.RajSamDBSet = {};
            rajSamDBSet.division = '';
            rajSamDBSet.district = '';
            rajSamDBSet.gramPanchayat = '';
            rajSamDBSet.panchayat = '';
            rajSamDBSet.village = '';
            $scope.RajSamDBSet = rajSamDBSet;
        };
    
        $scope.loadTags = function (query) {
            return $http.get('/tags?query=' + query);
        };
    
        $scope.onClearRajSamDB = function () {
            $scope.RajSamDBSet = {};
            $scope.RajSamDB = {};
            $scope.RajSamFilterList = {};
        };
    
        $scope.open = {
            startDate: false,
            endDate: false
        }
        $scope.openCalendar = function (e, date) {
            e.preventDefault();
            e.stopPropagation();
            $scope.open = {};
            $scope.open[date] = true;
        };
    
        var isValidateDates = function (startDate, endDate) {
            var errMsg = appFactory.validateDates(startDate, endDate);
            if (!errMsg) {
                return true;
            }
            toaster.pop({
                type: "error",
                body: errMsg
            });
            return false;
        };
    
        var isGreaterThanCurentDates = function (startDate, endDate) {
            var errMsg = appFactory.isGreaterThanCurentDates(startDate, endDate);
            if (!errMsg) {
                return true;
            }
            toaster.pop({
                type: "error",
                body: errMsg
            });
            return false;
        };
    
        $scope.SearchRajSamDB = function (rajSamparkDB) {
            var rajSamparkFilter = $scope.RajSamFilterList[0];
            if (!isGreaterThanCurentDates(rajSamparkDB.startDate, rajSamparkDB.endDate)) {
                return
            }
            var rajSamparkFilter = {
                deptType: rajSamparkFilter.deptType,
                dept: rajSamparkFilter.dept,
                scheme: rajSamparkFilter.scheme,
                startDate: moment(rajSamparkDB.startDate),
                endDate: moment(rajSamparkDB.endDate),
                grievance: rajSamparkDB.grievance,
                grievanceId: rajSamparkDB.grievanceId,
                rajSamparkMainFilter: $scope.RajSamFilterList
            }
            $scope.RajSampDBDetails = rajSamparkFilter;
            $scope.CreateSampleSurvey('RajasthanSamparkDB');
            surveyCampFactory.searchRajasthanSampakDB($scope.CreateSampleReq).then(function (data) { });
        };
    
        $scope.onFinishSurvey = function () {
            var isValidDates = $scope.isValidSampleSettingDates(true);
            var isValidSetting = isValidSettings($scope.sampleSetting);
            if (!isValidSetting || !isValidDates) {
                return;
            }
            // if (selectedoption === 'Sample') {
            //     createSampleSetting($scope.postedSampleData);    
            // } else {
            $scope.CreateSampleSurvey($scope.selectedoption);
            // }
        };
    
        $scope.isValidSampleSettingDates = function () {
            var sampleSetting = $scope.sampleSetting;
            var isValidStartDate = appFactory.isWithInDate(sampleSetting.campaignStartDate, sampleSetting.startDate);
            var isValidEndDate = appFactory.isWithInDate(sampleSetting.campaignEndDate, sampleSetting.endDate, true);
            var isValidDates = appFactory.isValidStartAndEndDate(sampleSetting.startDate, sampleSetting.endDate);
    
            $scope.sampleSetting.inValidStartDate = !isValidStartDate;
            $scope.sampleSetting.inValidEndDate = !isValidEndDate;
            if (!isValidDates) {
                $scope.sampleSetting.inValidStartDate = true;
                $scope.sampleSetting.inValidEndDate = true;
            }
            if (!isValidStartDate || !isValidEndDate || !isValidDates) {
                $scope.campaignStartDate = moment(sampleSetting.campaignStartDate).format('DD/MM/YYYY');
                $scope.campaignEndDate = moment(sampleSetting.campaignEndDate).format('DD/MM/YYYY');
                return false;
            }
            return true;
        };
    
        var createSampleSetting = function (sampleId) {
            var sampleSetting = createSetting(sampleId);
            surveyCampFactory.createSampleSetting(sampleSetting).then(function (data) {
                $('#uploadContacts').modal('hide');
                if (data.data === 'success') {
                    $scope.clearcontrols();
    
                }
                $scope.GetAllUploadList();
            });
        };
    
        var isValidSettings = function (sampleSetting) {
            var errMsg = ''
            if ($scope.stepData[1].data.surveyType.QuestionType === $scope.surveyType.OBJECTIVE) {
                if (!sampleSetting.isManualCalling && !sampleSetting.isAutomatedIVR && !sampleSetting.isEmailSurvey) {
                    errMsg = 'Please a select survey mode';
                } else {
                    if (sampleSetting.isEmailSurvey && (sampleSetting.isManualCalling || sampleSetting.isAutomatedIVR)) {
                        var isValidNumber = true;
                        if (sampleSetting.isEmailSurvey && sampleSetting.isAutomatedIVR) {
                            isValidNumber = isValidNum(sampleSetting.intervalInDaysIVR);
                            isValidNumber = isValidNumber || (isValidNum(sampleSetting.intervalInHoursIVR));
                        }
                        if ((sampleSetting.isEmailSurvey && sampleSetting.isManualCalling) || (sampleSetting.isAutomatedIVR && sampleSetting.isManualCalling)) {
                            isValidNumber = isValidNumber && (isValidNum(sampleSetting.daysInterval) || sampleSetting.intervalInDays);
                        }
                        if (!isValidNumber) {
                            errMsg = 'Please enter valid interval in days';
                        } else {
                            if (sampleSetting.intervalInHoursIVR && sampleSetting.intervalInHoursIVR > 24) {
                                errMsg = 'Interval in hours with in 24 hours';
                            }
                            if (sampleSetting.isEmailSurvey && (sampleSetting.isManualCalling || sampleSetting.isAutomatedIVR)) {
                                var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.daysInterval);
                                if (!isValidInterval) {
                                    errMsg = 'Interval in days with in start and end days';
                                }
                            }
                            if (sampleSetting.isEmailSurvey && sampleSetting.isAutomatedIVR) {
                                var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.intervalInDaysIVR);
                                if (!isValidInterval) {
                                    errMsg = 'Interval in days with in start and end days';
                                }
                            }
                        }
                    }
                }
            } else {
                if (!sampleSetting.isManualCalling && !sampleSetting.isEmailSurvey) {
                    errMsg = 'Please a select survey mode';
                }
                if (sampleSetting.isManualCalling && sampleSetting.isEmailSurvey) {
                    if (!sampleSetting.daysInterval && sampleSetting.intervalInDays < 0) {
                        errMsg = 'Please enter valid interval in days';
                    } else {
                        var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.daysInterval);
                        if (!isValidInterval) {
                            errMsg = 'Interval in days with in start and end days';
                        }
                    }
                }
            }
    
            if (sampleSetting.isSMSIntimate) {
                if (!sampleSetting.smsIntimateText) {
                    errMsg = 'Please Fill SMS intimation text';
                }
                if (!sampleSetting.scheduleDuration) {
                    errMsg = 'Please Fill Schedule Duration';
                } else if (sampleSetting.scheduleDuration > 24) {
                    errMsg = 'Schedule Duration should be with in 24 hours';
                }
            }
            if (sampleSetting.isSMSAcknowledge && !sampleSetting.smsAcknowledgeText) {
                errMsg = 'Please Fill SMS Acknowledgement text';
            }
    
            if (errMsg) {
                toaster.pop({
                    type: "error",
                    body: errMsg
                });
                return false;
            }
            return true;
        };
    
        var isValidNum = function (value) {
            if (!value || value <= 0) {
                return false;
            }
            return true;
        };
    
        $scope.isValidHours = function (hours, isDuration) {
            if (hours > 24) {
                hours = 24;
            } else if (hours < 0) {
                hours = 0;
            }
            if (isDuration) {
                $scope.sampleSetting.scheduleDuration = hours;
            } else {
                $scope.sampleSetting.intervalInHoursIVR = hours;
            }
        };
    
        $scope.isValidDays = function (days, isIVR) {
            // if (!days)
            if (days > 365) {
                days = 365;
            } else if (days < 0) {
                days = 0;
            }
            if (isIVR) {
                $scope.sampleSetting.intervalInDaysIVR = days;
            } else {
                $scope.sampleSetting.daysInterval = days;
            }
        };
        $scope.SearchCampaign = function () {
            getSearchCampaign();
        };
    
        function getSearchCampaign() {
            vm.GetCampaignList = {};
            vm.GetCampaignList.fromDate = moment(vm.range.startDate).format('YYYY-MM-DD HH:mm:ss');
            vm.GetCampaignList.toDate = moment(vm.range.endDate).format('YYYY-MM-DD HH:mm:ss');
            var Dateval = appFactory.validateReportDates(vm.GetCampaignList.fromDate, vm.GetCampaignList.toDate);
            if (Dateval) {
                appFactory.showToasterErr(Dateval);
            } else {
                if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
                    vm.GetCampaignList.departmentID = $rootScope.departmentName;
                    var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? $scope.surveyCampaigns.departmentSearch : $rootScope.departmentName;
                    // var departmentName = $scope.surveyCampaigns.departmentSearch;
                    if (!departmentName) {
                        vm.GetCampaignList.departmentID = -1;
    
                    } else if (departmentName.ID) {
    
                        vm.GetCampaignList.departmentID = departmentName.ID;
                    }
                    else {
                        vm.GetCampaignList.departmentID = departmentName;
                    }
    
    
    
    
                    surveyCampFactory.GetCampaignList(vm.GetCampaignList).then(function (data) {
                        if (data.data != null && data.data != undefined) {
                            $rootScope.allCampaignList = data.data;
                            if (!$rootScope.allCampaignList.length) {
                                appFactory.showWarning("No Data Found");
                            } else {
    
                                appFactory.showSuccess("Search applied");
                            }
    
    
                        } else {
                            $rootScope.allCampaignList = null;
    
                        }
                    });
    
    
                };
            }
    
        }
    
        var isWithinGivenDates = function (startDate, endDate, days) {
            var startDateObj = moment(startDate);
            var endDateObj = moment(endDate);
            if (endDateObj.diff(startDateObj, 'days') < days) {
                return false;
            }
            return true;
        };
    
        $scope.onChangeSurveyMode = function () {
            $scope.sampleSetting.daysInterval = '';
        };
    
    
        var createSetting = function (sampleId) {
            var sampleSettingObj = $scope.sampleSetting;
            var sampleSetting = {};
    
            sampleSetting = {
                SampleId: sampleId,
                IsEmailSurvey: sampleSettingObj.isEmailSurvey,
                IsAutomatedIVR: sampleSettingObj.isAutomatedIVR,
                IsManualCalling: sampleSettingObj.isManualCalling,
                EmailNoOfTimes: 1,
                DayIntervalBetweenEmailAttempts: sampleSettingObj.intervalInDaysIVR,
                HoursIntervalBetweenEmailAttempts: sampleSettingObj.intervalInHoursIVR,
                NoOfAutomatedIVRCallCount: 1,
                NoOfManualCallCount: Number(sampleSettingObj.intervalInDays),
                IsSMSIntimate: sampleSettingObj.isSMSIntimate,
                SMSIntimateText: sampleSettingObj.smsIntimateText,
                IsSMSAcknowledge: sampleSettingObj.isSMSAcknowledge,
                SMSAcknowledgeText: sampleSettingObj.smsAcknowledgeText,
                IntimateTimeType: 'Schedule',
                ScheduleDuration: sampleSettingObj.scheduleDuration,
                SurveyStartTime: moment(sampleSettingObj.startDate).format('YYYY-MM-DD HH:mm:ss'),
                SurveyEndTime: moment(sampleSettingObj.endDate).format('YYYY-MM-DD HH:mm:ss'),
                // SurveyStartTime: moment(sampleSettingObj.startDate).format('DD/MM/YYYY HH:MM'),
                // SurveyEndTime: moment(sampleSettingObj.endDate).format('DD/MM/YYYY HH:MM'),
            }
            if (sampleSettingObj.isManualCalling && (sampleSettingObj.isAutomatedIVR || sampleSettingObj.isEmailSurvey)) {
                sampleSetting.DayIntervalBetweenManualAttempts = sampleSettingObj.daysInterval;
            }
            return sampleSetting;
        };
        // ***** Rajasthan Sampark grievance database methods End  ****//
    
    
        //***** Private Methods *****//
    
        $scope.UploadContact = function () {
            appFactory.ShowLoader();
            IsValidInputs();
            if ($scope.isValid == true && $scope.validateOnSubmit == false) {
                var formData = new FormData();
                var formData = new FormData();
                if ($scope.useoutscope)
                    formData.append("uploadID", angular.toJson($scope.Selectedcampaignforuploaddata[0].ID));
                else
                    formData.append("uploadID", angular.toJson($scope.stepData[0].data.selectedcamp.ID));
                formData.append("uploadDepID", $scope.stepData[0].data.selectedcamp.Department);
                formData.append("uploadedBy", userObj.SSOID);
                formData.append("lcmCampaignID", $scope.stepData[0].data.selectedcamp.LCMCampaignName);
                formData.append("CreateContactFile", $scope.stepData[0].data.voiceuploadfile);
                $scope.uploadedFileName = $scope.stepData[0].data.voiceuploadfile.name;
                surveyCampFactory.UploadContactFile(formData).then(function (data) {
                    $scope.SurveyContactGrid.data = null;
                    if (data.data != null & data.data != undefined) {
                        if (data.data.statusMessage = "Success") {
                            $scope.campaignUsage = data.data.campaignSurveyUsage[0];
                            $scope.campaignUsage.totalRecords = data.data.totalRecords;
                            // campaignUsage.TotalAvailableCount = 10;
                            $scope.isExceedsMaxAvailableCount = false;
                            if (!$scope.campaignUsage || ($scope.campaignUsage.TotalAvailableCount < ($scope.campaignUsage.TotalUsedCount + $scope.campaignUsage.totalRecords))) {
                                appFactory.showToasterErr('Exceeds Avaliable Count');
                                $scope.isExceedsMaxAvailableCount = true;
                                appFactory.HideLoader();
                                return;
                            }
                            $scope.UploadVoiceCampaignRes = data.data;
                            $scope.Isnotnull = true;
                            $scope.isfileupload = true;
                            $scope.validateOnSubmit  = false;
                            $scope.SurveyContactGrid.data = $scope.UploadVoiceCampaignRes.uploadSampleData;
                            $scope.sampleSetting.startDate = $scope.UploadVoiceCampaignRes.campaignStartDate;
                            $scope.sampleSetting.endDate = $scope.UploadVoiceCampaignRes.campaignEndDate;
                            $scope.sampleSetting.campaignStartDate = $scope.UploadVoiceCampaignRes.campaignStartDate;
                            $scope.sampleSetting.campaignEndDate = $scope.UploadVoiceCampaignRes.campaignEndDate;
                            toaster.pop({
                                type: 'success',
                                body: "Contacts successfully uploaded",
                                bodyOutputType: 'trustedHtml'
                            });
    
    
                            angular.forEach($scope.UploadVoiceCampaignRes.CampaignHeaders, function (value, key) {
                                if (value.toLowerCase().search(/citizen/) >= 0) {
                                    $scope.stepData[0].data.citizenName = value;
                                } else if (value.toLowerCase().search(/mob/) >= 0) {
                                    $scope.stepData[0].data.mobileno = value;
                                } else if (value.toLowerCase().search(/gender/) >= 0) {
                                    $scope.stepData[0].data.gender = value;
                                } else if (value.toLowerCase().search(/father/) >= 0) {
                                    $scope.stepData[0].data.fatherName = value;
                                } else if (value.toLowerCase().search(/district/) >= 0) {
                                    $scope.stepData[0].data.District = value;
                                } else if (value.toLowerCase().search(/geo/) >= 0 || value.toLowerCase().search(/loc/) >= 0) {
                                    $scope.stepData[0].data.locationType = value;
                                } else if (value.toLowerCase().search(/panchayat/) >= 0) {
                                    $scope.stepData[0].data.panchayat = value;
                                } else if (value.toLowerCase().search(/gram/) >= 0) {
                                    $scope.stepData[0].data.grampanchayat = value;
                                } else if (value.toLowerCase().search(/village/) >= 0) {
                                    $scope.stepData[0].data.village = value;
                                } else if (value.toLowerCase().search(/mail/) >= 0) {
                                    $scope.stepData[0].data.email = value;
                                }
                            })
    
                        } else {
                            $scope.Isnotnull = false;
                            $scope.isfileupload = false;
                            $scope.SurveyContactGrid.data = null;
                            toaster.pop({
                                type: "error",
                                body: "Failed while uploading contacts",
                                bodyOutputType: 'trustedHtml'
                            });
                        }
                        appFactory.HideLoader();
    
    
                    } else {
                        $scope.Isnotnull = false;
                        $scope.isfileupload = false;
                        $scope.SurveyContactGrid.data = null;
                        //$scope.UploadVoiceCampaignRes = null;
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading contacts",
                            bodyOutputType: 'trustedHtml'
                        });
                        appFactory.HideLoader();
                    }
                });
            } else {
                appFactory.HideLoader();
            }
    
    
        }
        //save sample 
        $scope.CreateSampleSaveClose = function () {
            if ($scope.UploadVoiceCampaignRes.UploadID != null && $scope.UploadVoiceCampaignRes.UploadID != undefined) {
                $scope.UploadVoiceCampaignRes.uploadStatus = "READY";
                $scope.UploadVoiceCampaignRes.mobileNoField = $scope.stepData[0].data.mobileno;
                var filedMappingData = {
                    'CITIZEN_NAME': $scope.stepData[0].data.citizenName,
                    'MOBILE_NO': $scope.stepData[0].data.mobileno,
                    'GENDER': $scope.stepData[0].data.gender,
                    'FATHER_NAME': $scope.stepData[0].data.fatherName,
                    'DISTRICT': $scope.stepData[0].data.district,
                    'LOCATIONTYPE': $scope.stepData[0].data.locationType,
                    'PANCHAYAT': $scope.stepData[0].data.panchayat,
                    'GRAMPANCHAYAT': $scope.stepData[0].data.grampanchayat,
                    'Village': $scope.stepData[0].data.village,
                    'EMAIL': $scope.stepData[0].data.email,
                };
    
                $scope.CreateSampleReq = {
                    'surveyCampaignID': $scope.UploadVoiceCampaignRes.VoiceCampaignID,
                    'sampleName': $scope.stepData[0].data.sampleName,
                    'sampleType': 1, //$scope.stepData[1].data.surveyType.ID,
                    'surveyID': 1, //$scope.stepData[1].data.surveyName.ID,
                    'fileName': $scope.UploadVoiceCampaignRes.fileName,
                    'campaignFileName': $scope.UploadVoiceCampaignRes.campaignFileName,
                    'dataSourceType': "File",
                    'dataSourceQuery': '',
                    'totalRecords': $scope.UploadVoiceCampaignRes.totalRecords,
                    'mobileNoField': $scope.UploadVoiceCampaignRes.mobileNoField,
                    'geographicalField': '',
                    'fieldMapping': JSON.stringify(filedMappingData),
                    'downloadFileName': '',
                    'uploadedBy': $scope.UploadVoiceCampaignRes.uploadedBy,
                    'uploadDescription': $scope.UploadVoiceCampaignRes.uploadDescription,
                    'isDemo': false,
                }
    
                if ($scope.CreateSampleReq != null && $scope.CreateSampleReq != undefined) {
                    surveyCampFactory.CreateSample($scope.CreateSampleReq).then(function (data) {
                        $rootScope.selectedGridData = [];
                        $('#uploadContacts').modal('hide');
                        toaster.pop({
                            type: "success",
                            body: "Sample saved Successfully",
                            bodyOutputType: 'trustedHtml'
                        });
                        $scope.clearcontrols();
                    });
                }
            }
        }
        $scope.CampAssociationdata = [];
        $scope.GetCampaignAssociation = function (campaignid) {
            $scope.Obj.poptab = 1;
            surveyCampFactory.GetCampaignAssociation(campaignid).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $scope.AssociationContactDetailsGrid.data = data.data;
                } else {
                    $scope.CampAssociationdata = [];
                }
            });
        }
        $scope.CreateSampleSurvey = function (dstype) {
            if (dstype == 'File') {
                if ($scope.UploadVoiceCampaignRes.UploadID != null && $scope.UploadVoiceCampaignRes.UploadID != undefined) {
                    $scope.UploadVoiceCampaignRes.uploadStatus = "READY";
                    $scope.UploadVoiceCampaignRes.mobileNoField = $scope.stepData[0].data.mobileno;
                    var filedMappingData = {
                        'CITIZEN_NAME': $scope.stepData[0].data.citizenName,
                        'MOBILE_NO': $scope.stepData[0].data.mobileno,
                        'GENDER': $scope.stepData[0].data.gender,
                        'FATHER_NAME': $scope.stepData[0].data.fatherName,
                        'DISTRICT': $scope.stepData[0].data.district,
                        'LOCATIONTYPE': $scope.stepData[0].data.locationType,
                        'PANCHAYAT': $scope.stepData[0].data.panchayat,
                        'GRAMPANCHAYAT': $scope.stepData[0].data.grampanchayat,
                        'Village': $scope.stepData[0].data.village,
                        'EMAIL': $scope.stepData[0].data.email,
                    };
    
                    $scope.CreateSampleReq = {
                        'surveyCampaignID': $scope.UploadVoiceCampaignRes.VoiceCampaignID,
                        'sampleName': $scope.stepData[0].data.sampleName,
                        'sampleType': $scope.stepData[1].data.surveyType.ID,
                        'surveyID': $scope.stepData[1].data.surveyName.ID,
                        'fileName': $scope.UploadVoiceCampaignRes.fileName,
                        'campaignFileName': $scope.UploadVoiceCampaignRes.campaignFileName,
                        'dataSourceType': dstype,
                        'dataSourceQuery': '',
                        'totalRecords': $scope.UploadVoiceCampaignRes.totalRecords,
                        'mobileNoField': $scope.UploadVoiceCampaignRes.mobileNoField,
                        'geographicalField': '',
                        'fieldMapping': JSON.stringify(filedMappingData),
                        'downloadFileName': '',
                        'uploadedBy': $scope.UploadVoiceCampaignRes.uploadedBy,
                        'uploadDescription': $scope.UploadVoiceCampaignRes.uploadDescription,
                        'isDemo': false,
                    }
                }
            } else if (dstype === 'Sample') {
                $scope.UploadVoiceCampaignRes.uploadStatus = "READY";
                $scope.UploadVoiceCampaignRes.mobileNoField = $scope.stepData[0].data.mobileno;
                var filedMappingData = {};
                var arrydata = pickrequireddata();
                var samplename = ''
                // if (arrydata.length == 1) {
                //     samplename = arrydata[0].SampleName;
                // } else
                    // samplename = 'MultiSource'
                    samplename = $scope.stepData[0].data.sampleName;
                $scope.CreateSampleReq = {
                    'surveyCampaignID': $scope.stepData[0].data.selectedcamp.ID,
                    'MultiSource': JSON.stringify(arrydata),
                    'sampleName': samplename, //$scope.stepData[0].data.selectedExtSample.SampleName,
                    'sampleType': $scope.stepData[1].data.surveyType.ID,
                    'surveyID': $scope.stepData[1].data.surveyName.ID,
                    'sampleCondition': '',
                    //'existingSampleID': $scope.stepData[0].data.selectedExtSample.ID, //multiple sample mix
                    'fileName': '',
                    'totalRecords': arrydata[0].TotalRecords,
                    'campaignFileName': $scope.UploadVoiceCampaignRes.campaignFileName,
                    'dataSourceType': 'MultiSource',
                    'uploadedBy': $scope.UploadVoiceCampaignRes.uploadedBy,
                    'uploadDescription': $scope.UploadVoiceCampaignRes.uploadDescription,
                    'isDemo': false,
                }
            } else if (dstype == 'SAS') {
                    $scope.UploadVoiceCampaignRes.uploadStatus = "READY";
                    $scope.CreateSampleReq = {
                        'surveyCampaignID': $scope.UploadVoiceCampaignRes.VoiceCampaignID,
                        'sampleName': '',
                        'sampleType': $scope.stepData[1].data.surveyType.ID,
                        'surveyID': $scope.stepData[1].data.surveyName.ID,
                        'fileName': '',
                        'campaignFileName': '',
                        'dataSourceType': dstype,
                        'dataSourceQuery': '',
                        'totalRecords': $scope.UploadVoiceCampaignRes.totalRecords,
                        'mobileNoField': $scope.UploadVoiceCampaignRes.mobileNoField,
                        'geographicalField': '',
                        'fieldMapping': JSON.stringify(filedMappingData),
                        'downloadFileName': '',
                        'uploadedBy': $scope.UploadVoiceCampaignRes.uploadedBy,
                        'uploadDescription': $scope.UploadVoiceCampaignRes.uploadDescription,
                        'isDemo': false,
                }
            } else if (dstype == 'RajasthanSamparkDB') {
    
                $scope.CreateSampleReq = {
                    'surveyCampaignID': $scope.stepData[0].data.selectedcamp.ID,
                    'sampleName': $scope.stepData[0].data.sampleName,
                    // 'sampleType': $scope.stepData[1].data.surveyType.ID,
                    'sampleType': 12,
                    // 'surveyID': $scope.stepData[1].data.surveyName.ID,
                    'fileName': '',
                    'campaignFileName': '',
                    'dataSourceType': dstype,
                    'dataSourceQuery': '',
                    'bhamashaFilter': '',
                    'rajSamparkFilter': $scope.RajSampDBDetails,
                    'totalRecords': '',
                    'mobileNoField': '',
                    'geographicalField': '',
                    'fieldMapping': '',
                    'downloadFileName': '',
                    'uploadedBy': 'testuser',
                    'uploadDescription': '',
                    'isDemo': false,
                }
            } else if (dstype == 'BhamashahDB') {
    
                $scope.CreateSampleReq = {
                    'surveyCampaignID': $scope.UploadVoiceCampaignRes.VoiceCampaignID,
                    'sampleName': $scope.stepData[0].data.sampleName,
                    'sampleType': $scope.stepData[1].data.surveyType.ID,
                    'surveyID': $scope.stepData[1].data.surveyName.ID,
                    'fileName': $scope.UploadVoiceCampaignRes.fileName,
                    'campaignFileName': $scope.UploadVoiceCampaignRes.campaignFileName,
                    'dataSourceType': dstype,
                    'dataSourceQuery': '',
                    'totalRecords': $scope.UploadVoiceCampaignRes.totalRecords,
                    'mobileNoField': $scope.UploadVoiceCampaignRes.mobileNoField,
                    'geographicalField': '',
                    'downloadFileName': '',
                    'fieldMapping': '',
                    'uploadedBy': $scope.UploadVoiceCampaignRes.uploadedBy,
                    'uploadDescription': $scope.UploadVoiceCampaignRes.uploadDescription,
                    'isDemo': false,
                }
            } else if (dstype == 'storedDB') { }
    
            if ($scope.CreateSampleReq != null && $scope.CreateSampleReq != undefined) {
                surveyCampFactory.CreateSample($scope.CreateSampleReq).then(function (data) {
                    $rootScope.selectedGridData = [];
                    getAllSamples();
                    if (data.data != null & data.data != undefined) {
                        if (data.data && data.data.length) {
                            toaster.pop({
                                type: "success",
                                body: "Survey contact file uploded successfully",
                                bodyOutputType: 'trustedHtml'
                            });
                            if ($scope.stepProgress === 3) {
                                createSampleSetting(data.data[0].sampleID);
                            }
    
                        } else {
                            toaster.pop({
                                type: "error",
                                body: "Failed while uploading survey contact file",
                                bodyOutputType: 'trustedHtml'
                            });
                        }
    
                    } else {
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading survey contact file",
                            bodyOutputType: 'trustedHtml'
                        });
                        $scope.isCompleted = false;
                    }
                });
            }
        };
    
        var pickrequireddata = function () {
            var jsonarray = [];
            for (var i = 0; i < $rootScope.selectedGridData.length; i++) {
                jsonarray.push({
                    'SampleID': $rootScope.selectedGridData[i].ID,
                    'ProcessRecords': $rootScope.selectedGridData[i].ProcessRecords,
                    'SampleName': $rootScope.selectedGridData[i].SampleName,
                    'TotalRecords': 0
                });
                jsonarray[0].TotalRecords += $rootScope.selectedGridData[i].ProcessRecords;
            }
            return jsonarray;
        }
    
        var setStartAndEndTime = function (obj) {
            var starttime = new Date();
            var endtime = new Date();
            endtime.setHours(62);
            obj.startDate = starttime;
            obj.endDate = endtime;
            $scope.sampleSetting.manualCallInterval
        };
    
        var IsValidInputs = function () {
            var msgFileUpload = '';
            $scope.validateOnSubmit  = false;
           
            $scope.isValid = true;
            if ($scope.stepData[0].data.selectedcamp == undefined || $scope.stepData[0].data.selectedcamp == null ||
                $scope.stepData[0].data.selectedcamp.ID == "0") {
                 $scope.validateOnSubmit  = true;
                // toaster.pop({
                //     type: "error",
                //     body: "Please select valid campaign",
                //     bodyOutputType: 'trustedHtml'
                // });
              $scope.isValid = false;
            } 
            if ($scope.stepData[0].data.voiceuploadfile == undefined || $scope.stepData[0].data.voiceuploadfile == null || $scope.stepData[0].data.voiceuploadfile.name == null) {
                // toaster.pop({
                //     type: "error",
                //     body: "Please select valid file to upload",
                //     bodyOutputType: 'trustedHtml'
                // });
                $scope.validateOnSubmit  = true;
                msgFileUpload = "Please select valid file to upload";
                $scope.isValid = false;
            } else if ($scope.stepData[0].data.voiceuploadfile.name != null) {
               
                var validFormats = ['xls', 'xlsx', 'csv', 'txt'];
                var output = $filter('validfile')($scope.stepData[0].data.voiceuploadfile.name, validFormats);
                if (output == false) {
                    $scope.validateOnSubmit  = true;
                    // toaster.pop({
                    //     type: "error",
                    //     body: "File format should be xls,xlsx,csv & txt",
                    //     bodyOutputType: 'trustedHtml'
                    // });
                    msgFileUpload = "File format should be xls,xlsx,csv & txt";
                    $scope.isValid = false;
                } else {
                    $scope.isValid = true;
                }
            } else {
                $scope.isValid = true;
            }

            $scope.inlineValidationMsg = msgFileUpload;
            $scope.validateOnSubmit;
    
    
        }
    
    
        $scope.clearcontrols = function () {
            $scope.stepperControlInit();
            angular.element("input[type='file']").val(null);
            $scope.SurveyContactGrid.length = 0;
            $scope.SurveyContactGrid.data = [];
            $scope.SurveyContactGrid.data = null;
            $scope.Isnotnull = false;
            $scope.isfileupload = false;
            $scope.GetAllcampaignList();
            $scope.GetAllUploadList();
            $rootScope.selectedGridData = [];
            getAllSamples();
    
        }
        $scope.Reset = function () {
            vm.open = {};
            var d = new Date();
            d.setHours(0, 0, 0, 0);
    
            vm.range = {
                startDate: d,
                endDate: new Date()
            };
            $scope.surveyCampaigns.departmentSearch = ''
            $scope.GetAllcampaignList();
    
        }
    
        $scope.stepperControlInit = function () {
            $scope.selectedStep = 0;
            $scope.stepProgress = 1;
            $scope.maxStep = 3;
            $scope.showBusyText = false;
            $scope.sampleSetting = {};
            $scope.stepData = [{
                step: 1,
                completed: false,
                optional: false,
                data: {}
            },
            {
                step: 2,
                completed: false,
                optional: false,
                data: {}
            },
            {
                step: 3,
                completed: false,
                optional: false,
                data: {}
            },
    
            ];
        }
    
        //***** End of Private Methods *****//
    
        $scope.onTabChange = function (tab) {
    
            $('.modal-dialog .card').resizable().draggable({
                containment: ".page-content"
            });
            $('.modal').on('hidden.bs.modal', function (e) {
                $('.modal-dialog .card').css({ top: 0, left: 0 });
                $scope.validateOnSubmit    = false;
            })
            appFactory.ShowLoader();
            $scope.searchIndex = '';
            if (tab == 1 || tab == 2) {
    
    
                $scope.refresh();
            } else if (tab == 3) {
                $scope.GetAllUploadList();
    
            }
            $scope.tab = tab;
            calltimeout();
            $timeout(function () {
                appFactory.HideLoader();
            }, 1000)
        };
    
        $scope.GetAllQuestionType = function () {
            surveyFactory.GetAllQuestionType().then(
                function success(data) {
                    $scope.QuestionType = data.data;
                },
                function error(data) { }
            )
        };
    
        $scope.onTypeSearchValues = function () {
            var filteredData = appFactory.getDataBySearchIndex($scope.searchIndex);
            if ($scope.tab == 1) {
    
                $scope.ActiveCampaignGrid.data = filteredData;
                return;
            }
            if ($scope.tab == 2) {
    
                $scope.CampaignGrid.data = filteredData;
                return;
            }
            if ($scope.tab == 3) {
    
                $scope.ContactDetailsGrid.data = filteredData;
                return;
            }
        };
    
        var getSearchableFields = function (gridConfig) {
            appFactory.getSearchableFields(gridConfig);
        };
    
        var getDepartments = function () {
            if (appFactory.rights.type !== appConst.RIGHTS_TYPES.SUPER_ADMIN) {
                return;
            }
            profileFactory.GetAllDepartment().then(
                function success(data) {
                    $scope.Departments = data.data;
                    $scope.withoutdata = _.findWhere($scope.Departments, {
                        DepartmentName: "Generic"
                    })
    
                    $scope.Departments = _.without($scope.Departments, $scope.withoutdata)
                },
                function error(data) { }
            );
        };
    
        var getAllSamples = function () {
            var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
            var postdata = {
                departmentId: departmentName,
                user: 'ALL'
            };
            surveyFactory.getAllSamples(postdata).then(
                function success(data) {
                    if (data.data && data.data.length) {
                        $scope.samples = data.data;
                        for (var i = 0; i < $scope.samples.length; i++) {
                            $scope.samples[i].ProcessRecords = $scope.samples[i].TotalRecords;
                        }
    
                        $scope.Samplegrid.data = $scope.samples;
    
                    }
                },
                function err(data) {
    
                });
        };

        var checkSASRedirectingURL = function() {
            var queryParams = $location.search();
            if (!queryParams.token) {
                return;
            }
            var redirectedToken = queryParams.token;
            var redirectedSessionToken = sessionStorage.getItem('SASToken');
            // if (redirectedToken !== redirectedSessionToken) {
            //     appFactory.showError('Invalid User');
            // }
            var storedStepData = sessionStorage.getItem('SASSurvey');
            $scope.stepData[0].data = JSON.parse(storedStepData);
            setTimeout(function() {
                $scope.onTabChange(3);
                $scope.showUpload();
                $scope.selectedoption = 'SAS';
                $scope.isSuccesFullyRedirected = true;
                $scope.stepData[1].data.completed = true;
                setTimeout(function() {
                    $scope.stepProgress = 3;
                    $scope.selectedStep = 3;
                })
            }, 1000);
            sessionStorage.removeItem('SASToken');
            sessionStorage.removeItem('SASSurvey');
            // window.history.pushState({}, document.title, "/" + appConst.LINK_APP_URL.SAS_UCG );
        };

                
        var init = function () {
            checkSASRedirectingURL();
            resetcalender();
            $scope.GetAllQuestionType();
            getDepartments();
            // $scope.GetAllSurveyCampaignList();
            $scope.GetAllCampaignbyDept();
            getAllSamples();
            $scope.GetAllcampaignList();
        };
        var calltimeout = function () {
            window.setTimeout(function () {
                $(window).resize();
                $(window).resize();
            }, 1000);
        };
        init();
    
    }]);