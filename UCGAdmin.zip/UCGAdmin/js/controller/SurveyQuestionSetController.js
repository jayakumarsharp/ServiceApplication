app.controller('SurveyQuestionSetController', ['$scope', '$timeout', '_', 'roleFactory', 'appFactory', 'profileFactory', 'surveyFactory', 'toaster', '$compile', '$rootScope', '$window', 'surveyCampFactory', '$q', '$filter', function ($scope, $timeout, _, roleFactory, appFactory, profileFactory, surveyFactory, toaster, $compile, $rootScope, $window, surveyCampFactory, $q, $filter) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId;
    $scope.isSuperIdmin = false;
    //$rootScope.departmentName = "103";
    $scope.Createtitle = "Create Survey";
    $scope.permissions = appFactory.permissions[appConst.MENUS.RCHK_MGMT.MGMT_QUES_SET];
    // $scope.permissions = {
    //     'Add': true,
    //     'Modify': true,
    //     'Delete': true
    // };
    //   var userObj = {
    //      SSOID: 'admin'
    //  };
    $scope.isAddPopup = false;
    $scope.changedetected = false;
    $scope.ismainactive = true;
    $scope.showvalidation = false;
    $scope.Message = "";
    $scope.Questions = [];
    $scope.rowdata = [];
    $scope.Config = {
        Nodename: '',
        ObjQuestion: '',
        QuestionType: '',
        InputType: '',
        childnodes: '',
        NodeType: '',
        PromptFilename: '',
        FileName: ''
    };
    $scope.slider = {
        minValue: 0,
        maxValue: 100,
        options: {
            floor: 0,
            ceil: 100,
            step: 1
        }
    };
    $scope.Optionlist = []; //loaded all available options
    $scope.optionname = '';
    $scope.optionDTMF = '';
    $scope.showobjective = true;
    $scope.showaddoptions = false;
    $scope.AvailableNodeids = [];
    $scope.CopyNodeid = '';
    $scope.IscopyBuffer = false;
    $scope.DefautState = false;
    $scope.zoom = 0;
    $scope.ismainactive = true;
    $('.modal-dialog .card').resizable().draggable();
    //displaying prompt file name by spliting guid id by : (semicolon)
    $scope.getpromptname = function (rowdata) {
        if (rowdata.PhraseType == 'WAV') {
            return rowdata.WelcomeMessage.split(':')[1];
        } else
            return rowdata.WelcomeMessage;
    }

    //displaying prompt file name by spliting guid id by : (semicolon)
    $scope.getthankspromptname = function (rowdata) {
        if (rowdata.PhraseType == 'WAV') {
            return rowdata.ThanksMessage.split(':')[1];
        } else
            return rowdata.ThanksMessage;
    }

    var isValidAudio = function (file) {
        $scope.Message = "";
        if (!file || !file.name) {
            // toaster.pop({
            //     type: "error",
            //     body: "Please select valid file to upload"
            // });
            $scope.Message = "Please select valid file to upload"
            return false;
        }
        if (file.name != null) {
            var validFormats = ['wav'];
            var output = $filter('validfile')(file.name, validFormats);
            if (output == false) {
                // toaster.pop({
                //     type: "error",
                //     body: "File format should be wav"
                // });
                $scope.Message = "File format should be wav"
                return false;
            }
        }
        return true;
    };

    //****************** */
    //Grid data start
    //****************** */

    $scope.QuestionsetGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
            name: 'S.No', width: '5%', enableSorting: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
        },
        { name: 'Survey Name', field: 'QuestionSetName', isSearchable: true, cellTooltip: true },
        { name: 'Department', field: 'DepartmentName', isSearchable: true, cellTooltip: true },
        { name: 'Language', field: 'Language', isSearchable: true, cellTooltip: true },
        { name: 'Type', field: 'QuestionType', isSearchable: true, cellTooltip: true },
        { name: 'Mode', field: 'InputMode', isSearchable: true, cellTooltip: true },
        {
            name: 'Created Date', field: 'UpdatedDate', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\''
        },
        // {
        //     name: 'Welcome Message', field: 'WelcomeMessage', isSearchable: true, cellTooltip: true,
        //     cellTemplate: '<span ng-bind="grid.appScope.getpromptname(row.entity)"></span>'
        // },
        // {
        //     name: 'Thanks Message', field: 'ThanksMessage', isSearchable: true, cellTooltip: true,
        //     cellTemplate: '<span ng-bind="grid.appScope.getthankspromptname(row.entity)"></span>'
        // },
        {
            name: 'View', width: '6%',
            cellTemplate: '<a href="#" ng-if="grid.appScope.permissions.Modify" ng-click="grid.appScope.Edit(row.entity)"><span class="fa fa-eye"></span></a><a href="#" ng-if="!grid.appScope.permissions.Modify"><span class="fa fa-edit" style="color:#666; cursor: not-allowed;" ></span></a>'
        },
        {
            name: 'Clone', width: '6%',
            cellTemplate: '<a href="#" ng-if="grid.appScope.permissions.Add" ng-click="grid.appScope.copymodal(row.entity)"><span class="fa fa-clone"></span></a><a href="#" ng-if="!grid.appScope.permissions.Add" ><span class="fa fa-clone" style="color:#666; cursor: not-allowed;" ></span></a>'
        },
        {
            name: 'Delete', width: '6%',
            cellTemplate: '<a href="#"  ng-if="grid.appScope.permissions.Delete" ng-click="grid.appScope.DeleteQuestion(row.entity)"><span class="fa fa-trash"></span></a><a href="#"  ng-if="!grid.appScope.permissions.Delete" ><span class="fa fa-trash" style="color:#666; cursor: not-allowed;" ></span></a>'
        }

        ]
    };
    $scope.QuestionsetGrid.onRegisterApi = function (gridApi) {
        $scope.QuestionsetGridgridApi = gridApi;
    };
    //****************** */
    //Grid data end
    //****************** */


    //****************** */
    // page events start
    //****************** */

    //****************** */
    // cloning model
    //****************** */
    $scope.isClone = false;
    $scope.CurrentQuestionSetID = 0;
    $scope.copymodal = function (rowdata) {
        $scope.Createtitle = "Clone Survey";
        appFactory.ShowLoader();
        $scope.QuestionsetInfo = rowdata;
        $scope.CurrentQuestionSetID = rowdata.ID;
        $scope.showrowdata($scope.QuestionsetInfo.questiontypeId);
        $scope.QuestionsetInfo.QuestionsetName = rowdata.QuestionSetName;
        $scope.QuestionsetInfo.languageId = rowdata.LanguageID;
        $scope.QuestionsetInfo.departmentId = _.findWhere($scope.Departments, {
            ID: rowdata.DepartmentID
        });
        $scope.QuestionsetInfo.phraseType = rowdata.PhraseType;
        $scope.QuestionsetInfo.inputMode = rowdata.InputMode;
        $scope.QuestionsetInfo.jSONData = rowdata.JSONData;
        $scope.QuestionsetInfo.IsActive = rowdata.ISActive.toString();
        $scope.QuestionsetInfo.questiontypeId = rowdata.QuestiontypeID.toString();
        $scope.isClone = true;
        $scope.EditView = true;
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });

        })
        $('#addQuestions').modal('show');
        $scope.stepperControlInit();
        $timeout(function () {
            appFactory.HideLoader();
        }, 1000);

    }

    //****************** */
    // cloning model
    //****************** */

    $scope.back = function () {

        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });

        })

        if ($scope.changedetected || ($scope.item.PhraseType != "WAV" && ($scope.PrevData.WelcomeMessage != $scope.item.WelcomeMessage || $scope.PrevData.ThanksMessage != $scope.item.ThanksMessage)))

            $('#confirmModalSurvey').modal('show');
        else
            $scope.backModel();
    }
    $scope.backModel = function () {
        $('#confirmModalSurvey').modal('hide');
        appFactory.ShowLoader();
        $scope.ismainactive = true;
        $scope.randomSize();
        $scope.MakeContainerFullScreen($scope.DefautState, "Y");
        $timeout(function () {
            $(window).resize();
            $(window).resize();
        }, 100);
        $timeout(function () {
            appFactory.HideLoader();
        }, 1000)
    }
    $scope.randomSize = function () {
        $timeout(function () {
            $scope.gridApi.core.handleWindowResize();
        }, 200);
    };

    $scope.DeleteQuestion = function (rowdata) {
        $scope.deletedata = rowdata;
        $scope.deleteItem = rowdata.QuestionSetName;
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });

        })
        $('#confirmModal').modal('show');

    }
    $scope.delete = function () {
        var json = {
            id: $scope.deletedata.ID,
            departmentId: $scope.deletedata.DepartmentID,
            QuestionSetName: $scope.deletedata.QuestionSetName,
            flowName: $scope.deletedata.QuestionSetName,
            WelcomeMessage: $scope.deletedata.WelcomeMessage,
            ThanksMessage: $scope.deletedata.ThanksMessage,
            jSONData: 'delete',
            IVRData: 'delete',
            IsActive: false
        }
        surveyFactory.UpdateQuestionSet(json)
            .then(function (success) {
                appFactory.showSuccess("Survey deleted successfully");
                $scope.GetAllQuestionSet("");
            }, function (error) {
                alert("contacterror");
            });
        $scope.deletedata = {};
        $('#confirmModal').modal('hide');

    }
    var isWithinGivenDates = function (startDate, endDate, days) {
        var startDateObj = moment(startDate);
        var endDateObj = moment(endDate);
        if (endDateObj.diff(startDateObj, 'days') < days) {
            return false;
        }
        return true;
    };

    $scope.Edit = function (rowdata) {
        appFactory.ShowLoader();
        $scope.iseditable = false;
        $scope.ismainactive = false;
        $scope.item = rowdata;
        $scope.DepartmentID = rowdata.DepartmentID;

        $scope.PrevData = {
            ThanksMessage: rowdata.ThanksMessage,
            WelcomeMessage: rowdata.WelcomeMessage
        };
        if (rowdata.PhraseType == "WAV") {
            $scope.item.Thanks = rowdata.ThanksMessage.split(':')[1];
            $scope.item.Welcome = rowdata.WelcomeMessage.split(':')[1];
        }
        $timeout(function () {
            $scope.redraw = false;
            changeCallFlow(rowdata);
            CallTree.savebeforeaction();
            // $scope.Redesign();
            appFactory.HideLoader();
            $scope.changedetected = false;
        }, 1000);

    }
    $scope.showAdd = function () {
        $scope.Createtitle = "Create Survey";
        $scope.Action = 'Add';
        $scope.showvalidation = false;
        $scope.isClone = false;
        $scope.EditView = true;
        $scope.showrowdata(1);
        $scope.QuestionsetInfo.languageId = $scope.defLang;
        if (!$scope.isSuperIdmin) {
            $scope.QuestionsetInfo.departmentId = _.findWhere($scope.Departments, {
                ID: $rootScope.departmentName
            })
        }

        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });

        })

        $('#addQuestions').modal('show');
    }

    $scope.CreateQuestionset = function (val) {
        $scope.showvalidation = true;
        $scope.Upload = val;

        // $scope.GetAllQuestionSet("check");
        if (validatequestionset()) {
            $scope.GetAllQuestionSet("check");
        }
    }

    $scope.showrowdata = function (type) {
        $scope.showobjective = false;
        if (type == 1) {
            $scope.QuestionsetInfo = {
                questiontypeId: "1",
                IsActive: "true",
                phraseType: "TTS",
                inputMode: "VOICE"
            };
            $scope.showobjective = true;
        } else if (type == 2) {
            $scope.QuestionsetInfo.inputMode = "";
            $scope.QuestionsetInfo.phraseType = "";

        } else if (type == 3) {
            $scope.QuestionsetInfo.inputMode = "";
            $scope.QuestionsetInfo.phraseType = "";
        }
    }


    $scope.GetAllQuestionSet = function (check) {
        $scope.showvalidation = false;
        surveyFactory.GetAllQuestionSet().then(
            function success(data) {
                //$scope.Griddata = data.data;
                if ($scope.isSuperIdmin) {
                    $scope.Griddata = data.data;
                } else {
                    $scope.Griddata = _.filter(data.data, function (item) {
                        return item.DepartmentID == $rootScope.departmentName;
                    });
                }
                $scope.QuestionsetGrid.data = $scope.Griddata;
                if (!$scope.QuestionsetGrid.data) {
                    $scope.QuestionsetGridgridApi.grid.modifyRows($scope.QuestionsetGrid.data);
                }

                getSearchableFields($scope.QuestionsetGrid);
                $scope.QuestionsetGrid.data = $scope.Griddata;
                if (!$scope.QuestionsetGrid.data) {
                    $scope.QuestionsetGridgridApi.core.refresh();
                }

                if (check == "Edit") {
                    var rowdata = _.where($scope.Griddata, {
                        QuestionSetName: $scope.QuestionsetInfo.QuestionsetName
                    });
                    $scope.Edit(rowdata[0]);
                    $scope.MakeEdit();
                    $scope.QuestionsetInfo = {};
                } else if (check == "check") {
                    var isexist = !!_.where($scope.Griddata, {
                        QuestionSetName: $scope.QuestionsetInfo.QuestionsetName
                    }).length;
                    if (!isexist) {
                        if ($scope.QuestionsetInfo.jSONData == undefined)
                            $scope.QuestionsetInfo.jSONData = "";
                        $scope.QuestionsetInfo.createdby = userObj.SSOID;
                        $scope.QuestionsetInfo.departmentId = $scope.QuestionsetInfo.departmentId.ID;
                        $scope.DepartmentID = $scope.QuestionsetInfo.departmentId.ID;
                        surveyFactory.CreateQuestionSet($scope.QuestionsetInfo).then(
                            function success(data) {
                                $('#addQuestions').modal('hide');
                                if (!$scope.Upload) {
                                    $scope.isClone = false;
                                    $scope.GetAllQuestionSet("Edit");
                                } else {
                                    if (data.data.length > 0)
                                        $scope.CurrentQuestionSetID = parseInt(data.data[0].insertCount);
                                    else
                                        $scope.CurrentQuestionSetID = $scope.QuestionsetInfo.ID;
                                    getAllSamples();
                                    surveyFactory.GetCloneSurvey($scope.QuestionsetInfo.ID).then(
                                        function success(data) {
                                            console.log(data.data);
                                            var newdata = {};
                                            if (data.data.length > 0) {
                                                $scope.stepData[0].data.selectedcamp = _.findWhere($rootScope.allCampaignList, {
                                                    ID: data.data[0].CampaignID
                                                });
                                                newdata.isSMSIntimate = data.data[0].isSMSIntimate;
                                                newdata.smsIntimateText = data.data[0].SMSIntimateText;
                                                newdata.isSMSAcknowledge = data.data[0].IsSMSAcknowledge;
                                                newdata.iSMSAcknowledgeText = data.data[0].smsAcknowledgeText;
                                                newdata.SurveyEndTime = data.data[0].SurveyEndTime; //.format('DD/MM/YYYY');
                                                newdata.SurveyStartTime = data.data[0].SurveyStartTime;
                                                newdata.campaignEndDate = data.data[0].campaignEndDate;
                                                newdata.campaignStartDate = data.data[0].campaignStartDate;
                                                newdata.isManualCalling = data.data[0].IsManualCalling;
                                                newdata.isAutomatedIVR = data.data[0].IsAutomatedIVR;
                                                newdata.isEmailSurvey = data.data[0].IsEmailSurvey;
                                                newdata.isSMSAcknowledge = data.data[0].IsSMSAcknowledge;
                                                newdata.intervalInDaysIVR = data.data[0].DayIntervalBetweenEmailAttempts;
                                                newdata.intervalInHoursIVR = data.data[0].HoursIntervalBetweenEmailAttempts;
                                                newdata.NoOfManualCallCount = data.data[0].intervalInDays;
                                                newdata.daysInterval = data.data[0].DayIntervalBetweenManualAttempts;
                                            }
                                            $scope.sampleSetting = newdata;

                                            $('.modal-dialog .card').resizable().draggable({
                                                containment: ".page-content"
                                            });
                                            $('.modal').on('hidden.bs.modal', function (e) {
                                                $('.modal-dialog .card').css({ top: 0, left: 0 });

                                            })

                                            $('#uploadContacts').modal('show');
                                        },
                                        function error(data) {
                                            appFactory.showError('Server Unavailable');
                                        }
                                    )
                                }

                            },
                            function error(data) {
                                appFactory.showError('Server Unavailable');
                            }
                        )
                    } else
                        toaster.pop({
                            type: "error",
                            body: "Survey name already exists! ",
                            bodyOutputType: 'trustedHtml'
                        });
                }
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    }
    $scope.GetAllQuestionOptions = function () {
        surveyFactory.GetAllQuestionOptions().then(
            function success(data) {
                $scope.Optionlist = data.data;
            },
            function error(data) { }
        )
    }
    $scope.GetAllDepartment = function () {
        profileFactory.GetAllDepartment().then(
            function success(data) {
                $scope.Departments = data.data;
                $scope.withoutdata = _.findWhere($scope.Departments, {
                    DepartmentName: "Generic"
                })

                $scope.Departments = _.without($scope.Departments, $scope.withoutdata)
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    }
    $scope.GetAllLanguage = function () {
        surveyFactory.GetAllLanguage().then(
            function success(data) {

                $scope.Languages = data.data;
                $scope.defaultLang = _.findWhere(data.data, {
                    ID: 2
                })
                $scope.defLang = $scope.defaultLang.ID;
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    }
    $scope.GetAllQuestion = function () {
        surveyFactory.GetAllQuestion().then(
            function success(data) {
                $scope.Questions = data.data;
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    }

    $scope.checkifsuperadmin = function () {
        if (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) {
            $scope.isSuperIdmin = true;
        } else
            $scope.isSuperIdmin = false;
        $scope.GetAllQuestion();
        $scope.GetAllLanguage();
        $scope.GetAllQuestionSet("");
        $scope.GetAllDepartment();
        $scope.GetAllQuestionOptions();
    }
    $scope.checkifsuperadmin();


    $scope.Copy = function (event) {
        //jsPlumb.repaintEverything();
        $scope.IscopyBuffer = true;
        $scope.CopyNodeid = $(event.currentTarget).parent();
        CallTree.getAllchildnode($scope.CopyNodeid[0]);
    }

    $scope.changeMode = function (type) {
        if (type == "Thanks") {
            var r = confirm("Do you really want to add thanks node");
            if (r == true) {
                //CallTree.deleteNode($(event.currentTarget).parent());
            }
        }
    }
    $scope.Redesign = function (event) {
        CallTree.getquestionoptioncount();
    }
    $scope.ZoomIn = function () {
        //appFactory.ShowLoader();
        if ($scope.zoom < 0.8) {
            $scope.zoom = $scope.zoom + 0.3;
            var transformOrigin = [0.5, 0.5];

            var el = jsPlumb.getContainer();
            var p = ["webkit", "moz", "ms", "o"],
                s = "scale(" + $scope.zoom + ")",
                oString = (transformOrigin[0] * 100) + "% " + (transformOrigin[1] * 100) + "%";

            for (var i = 0; i < p.length; i++) {
                el.style[p[i] + "Transform"] = s;
                el.style[p[i] + "TransformOrigin"] = oString;
            }
            el.style["transform"] = s;
            el.style["transformOrigin"] = oString;
            ZoomProcess($scope.zoom);
            jsPlumb.setZoom($scope.zoom);
            $timeout(function () {
                triggerpageevent(1);
                jsPlumb.repaintEverything();
                //appFactory.HideLoader();
            }, 500);
        }
    }

    $scope.ZoomOut = function () {
        //appFactory.ShowLoader();
        if ($scope.zoom > 0.3)
            $scope.zoom = $scope.zoom - 0.3;
        if ($scope.zoom > 0) {
            var transformOrigin = [0.5, 0.5];
            var el = jsPlumb.getContainer();
            var p = ["webkit", "moz", "ms", "o"],
                s = "scale(" + $scope.zoom + ")",
                oString = (transformOrigin[0] * 100) + "% " + (transformOrigin[1] * 100) + "%";
            for (var i = 0; i < p.length; i++) {
                el.style[p[i] + "Transform"] = s;
                el.style[p[i] + "TransformOrigin"] = oString;
            }
            el.style["transform"] = s;
            el.style["transformOrigin"] = oString;
            $timeout(function () {
                ZoomProcess($scope.zoom)
                triggerpageevent(1);
                jsPlumb.repaintEverything();
                //appFactory.HideLoader();
            }, 500)
            jsPlumb.setZoom($scope.zoom);
        }
    }

    $scope.isValidQuestion = function () {
        var response = true;


        if ($scope.item.QuestionType == 'Objective') {

            if (!$scope.Config.QuestionType) {
                toaster.pop({ type: "error", body: "Select Question Type" });
                return false;
            }
            else if (!$scope.Config.ObjQuestion) {
                toaster.pop({ type: "error", body: "Question Name should not be empty" });
                return false;
            }

        }
        else {
            if (!$scope.Config.ObjQuestion) {
                toaster.pop({ type: "error", body: "Question Name should not be empty" });
                return false;
            }
        }
        return response;
    }
    $scope.Undo = function () {
        $scope.changedetected = true;
        $scope.Redrawcalltree = $scope.PrevStatedata;
        $scope.redraw = true;
        changeCallFlow($scope.item);
    }
    $scope.Paste = function (event) {
        $scope.changedetected = true;
        CallTree.savebeforeaction();
        $scope.IscopyBuffer = false;
        var pasteNodeid = $(event.currentTarget).parent();
        $scope.CopyNodedata.nodes = _.filter($scope.CopyNodedata.nodes, function (node) {
            return node.type != "link";
        });
        var rootnode = _.where($scope.CopyNodedata.nodes, {
            id: $scope.CopyNodedata.Copyroot
        });

        function getNextNodes(node, nextparent) {
            if (node.nodeOptions.childnodes.length <= 0) {
                return;
            } else {
                for (var t = 0; t < node.nodeOptions.childnodes.length; t++) {
                    var childnode = _.where($scope.CopyNodedata.nodes, {
                        id: node.nodeOptions.childnodes[t].targetId
                    });
                    $scope.optionname = childnode[0].name;
                    $scope.OptionVarients = node.nodeOptions.childnodes[t].OptionVarients;
                    var nextnodeparent1 = null;
                    if (childnode[0].nodeOptions.NodeType == "Option") {
                        current_config_nodeID = nextparent;
                        nextnodeparent1 = addoptiontotree(node.nodeOptions.childnodes[t].OptionVarients, $scope.Weightage);
                    } else {
                        nextnodeparent1 = CallTree.createnodemanual(nextparent[0], childnode[0].nodeOptions.NodeType, "", 0);
                    }
                    getNextNodes(childnode[0], nextnodeparent1);
                }
                // i = 0;
            }
        }
        $scope.optionname = rootnode[0].nodeOptions.Nodename;
        var nextnodeparent = CallTree.createnodemanual(pasteNodeid[0], rootnode[0].nodeOptions.NodeType, "", 0);
        getNextNodes(rootnode[0], nextnodeparent);
    }

    $scope.canceledit = function () {
        if ($scope.item.QuestionType == "Objective")
            $('#Fields-RuleNewField').modal('hide');
        else
            $('#Fields-RuleNewField1').modal('hide');

        var countcheck = getChildNode(current_config_nodeID[0].id);
        if (countcheck == 0 && $scope.isAddPopup)
            CallTree.deleteNodeManual(current_config_nodeID[0].id);
        $scope.Config.ObjQuestion = '';
        $scope.optionname = '';
        $scope.OptionVarients = '';
        $scope.showaddoptions = false;

    }


    $scope.ConfirmNodeType = function (type) {
        $('#confirmtype').modal('hide');

        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });

        })
        $('#Fields-RuleNewField1').modal('show');
        createObjectivequestion();
    }
    $scope.cancelconfirm = function () {
        $scope.currentquestiontype = 'Subjective';
        $('#confirmtype').modal('hide');

    }

    $scope.addnode = function (event) {
        $scope.isAddPopup = true;
        CallTree.savebeforeaction();
        $scope.ThanksType = "Question";
        current_config_nodeID = $(event.currentTarget).parent(); //angular bridge
        var countcheck = getChildNode(current_config_nodeID[0].id);
        // if (current_config_nodeID[0].id != 'StartFlowNode' && countcheck.length >= 1) {
        //     toaster.pop({
        //         type: "warning",
        //         body: "Only one question allowed for option ",
        //         bodyOutputType: 'trustedHtml'
        //     });
        // } else
        $scope.currentquestiontype = 'Subjective';

        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });

        })

        if ($scope.item.QuestionType == "Mixed") {
            $('#confirmtype').modal('show');
        } else if ($scope.item.QuestionType == "Subjective") {
            $('#Fields-RuleNewField1').modal('show');
            createObjectivequestion();
        } else {
            $('#Fields-RuleNewField').modal('show');
            createObjectivequestion();
        }

    }

    $scope.editnode = function (event) {
        $scope.isAddPopup = false;
        $scope.showaddoptions = false;
        current_config_nodeID = $(event.currentTarget).parent(); //angular bridge
        $scope.optionname = "";
        $scope.OptionVarients = "";
        $scope.optionDTMF = "";
        angular.element(document.querySelector('#loader')).removeClass('hide');
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });

        })
        if ($scope.item.QuestionType == "Objective")
            $('#Fields-RuleNewField').modal('show');
        else
            $('#Fields-RuleNewField1').modal('show');
        var scope = angular.element(document.getElementById('addQuestions')).scope();
        $('#moduleConfigurationDiv').css('width', '94%');
        var node = current_config_nodeID,
            moduleConfigurationDiv = $('#moduleConfigurationDiv');
        var featureName = node.attr('data-node-name');
        var parsingdata = node.attr('data-node-json');
        var nodeattributes = {}
        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '') {
            nodeattributes = $.parseJSON(parsingdata);
            $scope.ThanksType = nodeattributes.NodeType;
        }
        if ($scope.item.QuestionType != "Objective")
            $scope.currentquestiontype = nodeattributes.InputType;

        $timeout(function () {
            // $scope.refreshSlider();
            angular.element(document.querySelector('#loader')).addClass('hide');
        }, 1000);
        $scope.rowdata = getChildNode(current_config_nodeID[0].id);
        $scope.Config = {
            Nodename: featureName,
            ObjQuestion: nodeattributes.ObjQuestion,
            QuestionType: nodeattributes.QuestionType,
            InputType: nodeattributes.InputType,
            childnodes: nodeattributes.childnodes,
            OptionVarients: nodeattributes.OptionVarients,
            NodeType: nodeattributes.NodeType,
            Weightage: nodeattributes.Weightage
        };
        if (nodeattributes.QuestionType == "WAV") {
            $scope.Config.FileName = nodeattributes.Nodename.split(':')[1];
            $scope.Config.PromptFilename = nodeattributes.Nodename;
        }
    }
    $scope.UpdateNodedata = function (event, dataConfig) {
        if ($scope.isValidQuestion()) {
            var nodename = "";
            if ($scope.Config.QuestionType != "WAV") {
                if ($scope.Config.ObjQuestion != undefined && $scope.Config.ObjQuestion != '') {
                    $("#" + current_config_nodeID[0].id + " .nodeName").text($scope.Config.ObjQuestion)
                    $("#" + current_config_nodeID[0].id + " .nodeName").attr('title', $scope.Config.ObjQuestion);
                    $("#" + current_config_nodeID[0].id).attr("data-node-name", $scope.Config.ObjQuestion);
                    //nodename = $.parseJSON($scope.Config.ObjQuestion).Question;
                    nodename = $scope.Config.ObjQuestion;
                } else {
                    $("#" + current_config_nodeID[0].id).find(".nodeName").text("Question");
                    $("#" + current_config_nodeID[0].id).attr("data-node-name", "Question");
                    nodename = "Question";
                }

                var isexist = !!_.where($scope.Questions, {
                    Question: $scope.Config.ObjQuestion
                }).length;
                if (!isexist) {
                    if ($scope.ThanksType != "Thanks") {
                        var QuestionInfo = {
                            departmentId: $scope.DepartmentID,
                            Question: $scope.Config.ObjQuestion,
                            QuestionType: "Specific",
                        }
                        surveyFactory.CreateQuestions(QuestionInfo).then(
                            function success(data) {
                                $scope.GetAllQuestion();
                            },
                            function error(data) {
                                appFactory.showError('Server Unavailable');
                            }
                        );
                    }
                }
            } else {
                nodename = $scope.Config.PromptFilename;
                $("#" + current_config_nodeID[0].id + " .nodeName").text($scope.Config.FileName)
                $("#" + current_config_nodeID[0].id + " .nodeName").attr('title', $scope.Config.FileName);
                $("#" + current_config_nodeID[0].id).attr("data-node-name", $scope.Config.PromptFilename);
                //nodename = $.parseJSON($scope.Config.ObjQuestion).Question;
                //nodename = $scope.Config.PromptFilename;
                //$scope.Config.FileName = orginalmessage;
            }
            var nodeattributes = {
                InputType: $scope.Config.InputType,
                Nodename: nodename,
                ObjQuestion: $scope.Config.ObjQuestion,
                QuestionType: $scope.Config.QuestionType,
                //OptionVarients: $scope.Config.OptionVarients,
                NodeType: $scope.Config.NodeType,
                childnodes: getChildNode(current_config_nodeID[0].id)
            };
            if ($scope.ThanksType == "Thanks") {
                nodeattributes.NodeType = "Thanks";
                $("#" + current_config_nodeID[0].id).attr("data-node-OptionVarients", "Thanks");
                nodeattributes.childnodes = "";
            }
            if ($scope.item.QuestionType != "Objective")
                nodeattributes.InputType = $scope.currentquestiontype;
            $("#" + current_config_nodeID[0].id).attr("data-node-json", JSON.stringify(nodeattributes));
            if ($scope.item.QuestionType == "Objective")
                $('#Fields-RuleNewField').modal('hide');
            else
                $('#Fields-RuleNewField1').modal('hide');
        }
    }
    $scope.deletenode = function (event) {
        var r = confirm("Do you really want to delete!!");
        if (r == true) {
            CallTree.savebeforeaction();
            CallTree.deleteNode($(event.currentTarget).parent());
        }
    }
    $scope.saveQuestionset = function () {
        CallTree.saveCallTree();
        $scope.changedetected = false;

        $('#viewQuestions').modal('hide');
        // jsPlumb.doWhileSuspended(function () {
        //     var connections = CallTree.tabInstances["drawing"].getConnections({
        //         source: 'StartFlowNode'
        //     });
        //     for (var i = 0, j = connections.length; i < j; i++) {
        //         jsPlumb.connect(connections[i]);
        //     }
        // }, true);
    }
    $scope.UploadFile = function () {
        var formData = new FormData();
        formData.append("uploadID", angular.toJson($scope.item.ID));
        //   formData.append("uploadedBy", userObj.SSOID);
        formData.append("SurveyFile", $scope.surveyuploadfile);
        if (isValidAudio($scope.surveyuploadfile)) {
            surveyFactory.PostSurveyAudioFile(formData).then(function (data) {
                var orginalmessage = data.data.Message;
                var splitdata = orginalmessage.split(':');
                $scope.Config.PromptFilename = orginalmessage;
                $scope.Config.FileName = splitdata[1];
            }, function error(data) {
                appFactory.showError('Server Unavailable');
            });
        }
    }

    $scope.WelcomeUploadFile = function (type) {
        var formData = new FormData();
        formData.append("uploadID", 1);
        //   formData.append("uploadedBy", userObj.SSOID);
        var isvalidfile = false;
        $scope.isvalidflag = true;
        if (type == 1) {
            formData.append("SurveyFile", $scope.Welcomeuploadfile);
            isvalidfile = isValidAudio($scope.Welcomeuploadfile);
        } else {
            formData.append("SurveyFile", $scope.Thanksuploadfile);
            isvalidfile = isValidAudio($scope.Thanksuploadfile);
        }

        $scope.isvalidflag = isvalidfile

        if (isvalidfile) {
            surveyFactory.PostSurveyAudioFile(formData).then(function (data) {
                var orginalmessage = data.data.Message;
                var splitdata = orginalmessage.split(':');
                if (type == 2) {
                    $scope.QuestionsetInfo.ThanksMessage = orginalmessage;
                    $scope.Thanks = splitdata[1];
                } else {
                    $scope.QuestionsetInfo.WelcomeMessage = orginalmessage;
                    $scope.Welcome = splitdata[1];
                }
            }, function error(data) {
                appFactory.showError('Server Unavailable');
            });
        }
    }

    //add option for question
    $scope.addoptions = function (event) {
        CallTree.savebeforeaction();
        if ($scope.item.InputMode == "VOICE") {
            if ($scope.optionname.trim() != "" && $scope.OptionVarients.trim() != "" ) {
                if (!$scope.Weightage) {
                    toaster.pop({  type: "error", body: "Please ensure weightage value is entered",   bodyOutputType: 'trustedHtml' });
                }
                else if($scope.Weightage < 0 && $scope.Weightage > 100){
                    toaster.pop({  type: "error", body: "Please ensure weightage value must between 1 and 100",   bodyOutputType: 'trustedHtml' });
                } else {
                    addoptiontotree($scope.OptionVarients, $scope.Weightage);
                }                 
            } else
                toaster.pop({                    type: "error",
                    body: "Please ensure valid option and optionvarients are entered",
                    bodyOutputType: 'trustedHtml'
                });
        } else if ($scope.item.InputMode == "DTMF") {
            if ($scope.optionname.trim() != "" && $scope.optionDTMF != "" && $scope.optionDTMF <= 9 && $scope.optionDTMF >= 0) {
                var isexist = !!_.where($scope.rowdata, {
                    OptionVarients: $scope.optionDTMF.toString()
                }).length;
                if (!isexist) {
                    addoptiontotree($scope.optionDTMF, $scope.Weightage);
                    $scope.optionDTMF = "";
                } else {
                    // var max = _.max($scope.rowdata, function (o) {
                    //     return parseInt(o.OptionVarients);
                    // });
                    toaster.pop({
                        type: 'warning',
                        body: "Option DTMF values should be unique",
                        bodyOutputType: 'trustedHtml'
                    });
                    $scope.optionDTMF = "";
                }

            } else
                toaster.pop({
                    type: "error",
                    body: "Please ensure valid option and DTMF values are entered",
                    bodyOutputType: 'trustedHtml'
                });

        } else {
            if ($scope.optionname.trim() != "") {
                addoptiontotree('');
            } else
                toaster.pop({
                    type: "error",
                    body: "Please ensure option and optionvarients are entered",
                    bodyOutputType: 'trustedHtml'
                });
        }

    }
    //add option for question


    $scope.showAddoptions = function () {
        $scope.showaddoptions = true;
    }
    $scope.typeaheadOnSelectFunction = function () {
        var isexist = !!_.where($scope.Optionlist, {
            OptionValue: $scope.optionname
        }).length;
        if (isexist) {
            varfinddata = _.where($scope.Optionlist, {
                OptionValue: $scope.optionname
            });

            $scope.OptionVarients = varfinddata[0].OptionVarients;
            $scope.Weightage = varfinddata[0].OptionWeightage;
        }
    }

    $scope.deletenodeoptions = function (nodeid) {
        CallTree.savebeforeaction();
        $scope.rowdata = _.without($scope.rowdata, _.findWhere($scope.rowdata, {
            targetId: nodeid.targetId
        }))
        if (nodeid.targetId)
            CallTree.deleteNodeManual(nodeid.targetId);
    }

    $scope.refreshSlider = function (passvalue) {
        $timeout(function () {
            $scope.$broadcast('rzSliderForceRender');
            $scope.Weightage = passvalue;
        });
    };
    $scope.refreshSlider(0);

    $scope.refresh = function () {
        $scope.searchIndex = "";
        $scope.GetAllQuestionSet("");
    }
    $scope.MakeContainerFullScreen = function (state, setstate) {
        angular.element(document.querySelector('#loader')).removeClass('hide');
        $scope.DefautState = !state;
        if ($scope.DefautState && setstate != "Y") {
            document.getElementsByClassName('side-navbar')[0].style.display = "none";
            document.getElementsByClassName('header')[0].style.display = "none";
            //document.getElementsByClassName('main-footer')[0].style.display = "none";
            // $('#map').addClass('col-lg-12').removeClass('col-lg-12');
            //$('#sidebar').addClass('col-lg-0').removeClass('col-lg-2');
            $('#contentpage').css('width', '100%');
            $('#contentpage').removeClass('content-inner');
        } else {
            $scope.DefautState = false;
            document.getElementsByClassName('side-navbar')[0].style.display = "block";
            document.getElementsByClassName('header')[0].style.display = "block";
            //document.getElementsByClassName('main-footer')[0].style.display = "block";
            $('#contentpage').addClass('content-inner');
            //    $('#sidebar').addClass('col-lg-2').removeClass('col-lg-0');
            //   $('.content-inner').css('width', 'calc(100% - 250px)');
        }
        //  triggerpageevent(150);
        $timeout(function () {
            angular.element(document.querySelector('#loader')).addClass('hide');
        }, 500)
    };

    $scope.onTypeSearchValues = function () {
        var filteredData = appFactory.getDataBySearchIndex($scope.searchIndex);
        $scope.QuestionsetGrid.data = filteredData;
    };

    var getSearchableFields = function () {
        appFactory.getSearchableFields($scope.QuestionsetGrid);
    };


    //****************** */
    // page events end
    //****************** */

    //****************** */
    // functional operations
    //****************** */

    function validatequestionset() {
        if (!$scope.QuestionsetInfo.QuestionsetName) {
            // toaster.pop({
            //     type: "warning",
            //     body: "please enter survey name",
            //     bodyOutputType: 'trustedHtml'
            // });
            return false;
        } else if (!$scope.QuestionsetInfo.departmentId) {
            // toaster.pop({
            //     type: "warning",
            //     body: "please select department",
            //     bodyOutputType: 'trustedHtml'
            // });
            return false;
        } else if (!$scope.QuestionsetInfo.languageId) {
            toaster.pop({
                type: "warning",
                body: "please select language",
                bodyOutputType: 'trustedHtml'
            });
            return false;
        } else if ($scope.QuestionsetInfo.questiontypeId == 1) {
            if (!$scope.QuestionsetInfo.inputMode) {
                toaster.pop({
                    type: "warning",
                    body: "please select input mode",
                    bodyOutputType: 'trustedHtml'
                });
                return false;
            }
            if (!$scope.QuestionsetInfo.phraseType) {
                toaster.pop({
                    type: "warning",
                    body: "please select phrase type",
                    bodyOutputType: 'trustedHtml'
                });
                return false;
            } else {
                if (!$scope.QuestionsetInfo.WelcomeMessage) {
                    // toaster.pop({
                    //     type: "warning",
                    //     body: "please enter Welcome Message",
                    //     bodyOutputType: 'trustedHtml'
                    // });
                    return false;
                } else if (!$scope.QuestionsetInfo.ThanksMessage) {
                    // toaster.pop({
                    //     type: "warning",
                    //     body: "please enter Thanks Message",
                    //     bodyOutputType: 'trustedHtml'
                    // });
                    return false;
                }
            }
        }
        return true;
    }

    (function () {
        Array.prototype.last = function () {
            return this[this.length - 1];
        };
        Array.prototype.lastIdx = function () {
            return this.length - 1;
        };
        jsPlumb.ready(function () {
            CallTree = {
                sourceEndpoint: {
                    endpoint: "Dot",
                    paintStyle: { strokeStyle: "#544e4e", fillStyle: "transparent", radius: 6, lineWidth: 3 },
                    maxConnections: -1,
                    isSource: true,
                    connector: ["Flowchart", {
                        stub: [40, 60],
                        gap: 10,
                        cornerRadius: 3,
                        alwaysRespectStubs: false,
                    }],
                    connectorStyle: {
                        lineWidth: 2,
                        strokeStyle: "#544e4e",
                        joinstyle: "round"
                    },
                    hoverPaintStyle: {
                        fillStyle: "#544e4e",
                        strokeStyle: "#544e4e"
                    },
                    connectorHoverStyle: {
                        lineWidth: 3,
                        strokeStyle: "#544e4e"
                    },
                    dragOptions: {}
                },
                targetEndpoint: {
                    endpoint: "Dot",
                    paintStyle: {
                        fillStyle: "#544e4e",
                        radius: 8
                    },
                    hoverPaintStyle: {
                        fillStyle: "#544e4e",
                        strokeStyle: "#544e4e"
                    },
                    maxConnections: 9,
                    dropOptions: {
                        hoverClass: "hover",
                        activeClass: "active"
                    },
                    isTarget: true,
                },
                mainMenu: {},
                flowsContext: {},
                connectorNames: {},
                //entryConnectPoints: {},
                init: function (source) {
                    var that = this;
                    this.tabInstances = {};
                    this.loadModules();
                },
                loadMultipleFlows: function () {
                    //drawing existing treee from DB
                    var that = this;
                    for (var f = 0; f < flowDataStore.length; f++) {
                        var flowName = flowDataStore[f].flowName;
                        if (typeof flowDataStore[f].callTree != 'object' && flowDataStore[f].callTree != undefined && flowDataStore[f].callTree != '')
                            flowDataStore[f].callTree = $.parseJSON(flowDataStore[f].callTree);
                    }
                },
                createContainers: function (flowName) {
                    //creating fresh call tree
                    jsPlumb.reset();
                    jsPlumb.setContainer("drawing");
                    // $scope.zoom = 0.6;
                    // $scope.ZoomIn();
                    var that = this;
                    that.tabInstances = {};
                    var currFlow = flowName.QuestionSetName;
                    that.initTabSettings('drawing');
                    var isexist = !!_.where(flowDataStore, {
                        FlowName: flowName.QuestionSetName
                    }).length;
                    if (isexist) {
                        var seldata = _.where(flowDataStore, {
                            FlowName: flowName.QuestionSetName
                        });

                        that.loadCallTree(seldata[0].callTree.nodes);

                    } else {
                        if ($scope.redraw) {
                            flowDataStore.push({
                                callTree: {
                                    nodes: $scope.Redrawcalltree
                                },
                                FlowName: $scope.item.QuestionSetName
                            });
                            that.loadCallTree($scope.Redrawcalltree);

                        } else {
                            that.tabInstances = {};
                            that.initTabSettings('drawing');
                            var startNodeTopPosition = 1,
                                startNodeLeftPosition = 250;
                            var node = "";
                            var node = that.createNode({
                                id: 'StartFlowNode',
                                type: 'entryConnector',
                                value: 'Question Root',
                                NodeType: 'Option',
                                OptionVarients: '',
                            });
                            node.css({
                                top: startNodeTopPosition,
                                left: startNodeLeftPosition
                            });
                            node.attr('data-node-position', startNodeTopPosition + ":" + startNodeLeftPosition);
                            node.attr('data-node-OptionVarients', '');


                            $compile(node)($scope);
                            $('#' + 'drawing').append(node);
                            that.tabInstances['drawing'].draggable(node);
                            $(node).draggable({
                                stop: function (e, ui) {
                                    node.attr('data-node-position', ui.position.top + ":" + ui.position.left);
                                }
                            });
                            that.addEndPoints(node.attr('id'), node.attr('data-node-type'), that.tabInstances['drawing']);
                            flowDataStore.push({
                                "flowName": flowName.QuestionSetName,
                                "callTree": {
                                    "flowName": flowName.QuestionSetName,
                                    "nodes": [{
                                        "id": "StartFlowNode",
                                        "name": "StartFlowNode",
                                        "NodeType": 'Option',
                                        "type": "entryConnector",
                                        "nodeOptions": {},
                                        "element": {
                                            "id": "StartFlowNode",
                                            "left": startNodeLeftPosition,
                                            "position": startNodeTopPosition + ":" + startNodeLeftPosition,
                                            "sourceAnchor": "",
                                            "targetAnchor": "",
                                            "top": startNodeTopPosition
                                        }
                                    }],
                                }
                            });
                        }
                    }

                },
                initTabSettings: function (tabID) {
                    var that = this;
                    var tabInstance = jsPlumb.getInstance({
                        DragOptions: {
                            cursor: "pointer",
                            zIndex: 2000
                        },
                        Container: tabID,
                    });
                    tabInstance.bind("dblclick", function (connInfo) {
                        var r = confirm("Do you really want to delete!!");
                        if (r == true) {
                            var nodeId = connInfo.endpoints[1].getUuid();
                            tabInstance.detach(connInfo);
                        }
                    }); //here pharase ll be there additional
                    that.tabInstances["drawing"] = tabInstance;
                },
                loadModules: function (thisTabId) {
                    //drag and drop purpose
                    var that = this;
                    $('#modulesContainer .drag').each(function () {
                        $(this).draggable({
                            revert: 'invalid',
                            helper: 'clone',
                            connectToSortable: '.calltree',
                            tolerance: 'intersect'
                        });
                    });
                },
                createnodemanual: function (Source, type, OptionVarients, Weightage) {
                    that = this;
                    var pos = Source.attributes['data-node-position'].nodeValue.split(':');
                    var child = getChildNode(Source.id);
                    var plusleftvalue = 0,
                        plustopvalue = 0;
                    if (type == "Option") {
                        if (child.length % 2 == 0) {
                            plusleftvalue = parseInt(pos[1]) - 100;
                            if (child.length == 0)
                                plustopvalue = parseInt(pos[0]) + 120;
                            else
                                plustopvalue = parseInt(pos[0]) + (120 * (child.length / 2 + 1));
                        } else {
                            plusleftvalue = parseInt(pos[1]) + 100;
                            if (child.length == 1)
                                plustopvalue = parseInt(pos[0]) + 120;
                            else
                                plustopvalue = parseInt(pos[0]) + (120 * Math.floor(child.length / 2 + 1));
                        }
                    } else {
                        plusleftvalue = parseInt(pos[1]);
                        plustopvalue = parseInt(pos[0]) + 120;
                    }
                    var nodeText = $scope.optionname,
                        nodeTopPosition = plustopvalue,
                        nodeLeftPosition = plusleftvalue;
                    // nodeTopPosition = parseInt(pos[0]) + 100,
                    // nodeLeftPosition = parseInt(pos[1]) + 100;

                    var node = that.createNode({
                        type: 'feature',
                        value: nodeText,
                        NodeType: type,
                        OptionVarients: OptionVarients,
                        Weightage: Weightage
                    });
                    $compile(node)($scope);
                    node.attr('data-node-position', nodeTopPosition + ":" + nodeLeftPosition);
                    nodeattributes = {
                        Nodename: '',
                        ObjQuestion: '',
                        QuestionType: 'TTS',
                        NodeType: type,
                        OptionVarients: OptionVarients,
                        InputType: 'Custom',
                        childnodes: '',
                        PromptFilename: '',
                        FileName: ''
                    }
                    node.attr("data-node-json", JSON.stringify(nodeattributes));
                    node.attr("data-node-OptionVarients", nodeattributes.OptionVarients);
                    node.attr('data-node-Weightage', nodeattributes.Weightage);
                    document.getElementById("drawing").appendChild(node[0]);
                    node.css({
                        top: nodeTopPosition,
                        left: nodeLeftPosition
                    });
                    that.tabInstances["drawing"].draggable(node);
                    $(node).draggable({
                        stop: function (e, ui) {
                            node.attr('data-node-position', ui.position.top + ":" + ui.position.left);
                        }
                    });
                    that.addEndPoints(node.attr('id'), 'feature', that.tabInstances["drawing"]);
                    that.tabInstances["drawing"].connect({
                        uuids: ["endPoint-" + Source.id + "Bottom",
                        "endPoint-" + node.attr('id') + "Top"
                        ],
                    });
                    return node;
                },
                generateUniqueId: function (prefix) {
                    function rand() {
                        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
                    }
                    return prefix + '_' + rand() + rand() + '-' + rand() + '-' + rand();
                },
                addEndPoint: function (plumbInstance, nodeId, sourceAnchors, targetAnchors, nodeType) {
                    var sourceEndPoint = this.sourceEndpoint,
                        targetEndpoint = this.targetEndpoint;
                    if (typeof sourceAnchors == 'object') {
                        for (var i = 0; i < sourceAnchors.length; i++) {
                            var sourceUUID = 'endPoint-' + nodeId + sourceAnchors[i];
                            plumbInstance.addEndpoint(nodeId, sourceEndPoint, {
                                anchor: sourceAnchors[i],
                                uuid: sourceUUID,
                                connectionsDetachable: true,
                            });
                        }
                    }
                    if (typeof targetAnchors == 'object') {
                        for (var j = 0; j < targetAnchors.length; j++) {
                            var targetUUID = 'endPoint-' + nodeId + targetAnchors[j];
                            plumbInstance.addEndpoint(nodeId, targetEndpoint, {
                                anchor: targetAnchors[j],
                                uuid: targetUUID
                            });
                        }
                    }
                },
                addEndPoints: function (nodeId, nodeType, plumbInstance) {
                    if (nodeType === 'StartFlowNode' || nodeType === 'entryConnector') {
                        this.addEndPoint(plumbInstance, nodeId, ['Bottom'], [], nodeType);
                    } else {
                        this.addEndPoint(plumbInstance, nodeId, ['Bottom'], ['Top'], nodeType);
                    }
                },
                createNode: function (nodeData) {
                    var nodeId = nodeData.id || this.generateUniqueId(nodeData.type),
                        node = $('<div ng-class="{\'notallowededit\': !iseditable }">'),
                        deleteIcon = $('<div class="deleteIconClick deleteIcon"  ng-show="iseditable" ng-click="deletenode($event)"> <i class="fa fa-trash-o" aria-hidden="true"></i>'),
                        nodeName = $('<p class="nodeName" style="word-wrap: break-word;">'),
                        EditIcon, ruleConfigIcon, CopyIcon = $('<div class="copyIcon" ng-show="iseditable" ng-click="Copy($event)"> <i class="fa fa-files-o" aria-hidden="true"></i>'),
                        PasteIcon = $('<div class="pasteIcon" ng-show="IscopyBuffer" ng-show="iseditable"  ng-click="Paste($event)"> <i class="fa fa-clipboard" aria-hidden="true"></i>');
                    node.attr('id', nodeId);
                    node.addClass('draggableNode');
                    node.attr('data-node-type', nodeData.type);
                    node.attr('data-node-name', nodeData.value);
                    node.attr('data-node-OptionVarients', nodeData.OptionVarients);
                    node.attr('data-node-Weightage', nodeData.Weightage);
                    node.addClass(nodeData.NodeType);
                    nodeName.text(nodeData.value);
                    nodeName.attr("title", nodeData.value);
                    EditIcon = $('<div id="FF_' + nodeId + '"  class="AddruleConfigIcon ruleConfigIcon" ng-show="iseditable" ng-click="editnode($event)"  title=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>');
                    ruleConfigIcon = $('<div id="R_' + nodeId + '" ng-click="addnode($event)" ng-show="iseditable" class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>');
                    if (nodeId == "StartFlowNode") {
                        node.addClass('entryConnector');
                        node.append('<div class="questionIcon" > <i class="fa fa-question" aria-hidden="true"></i>'); //ng-click="addnode($event)" 
                        node.append(nodeName);
                        node.append(ruleConfigIcon); // add icon question
                        node.append(PasteIcon);
                    } else if (nodeData.NodeType == "Option") {
                        node.append(nodeName);
                        node.append(ruleConfigIcon); // add icon question
                        node.append(PasteIcon);
                    } else if (nodeData.NodeType == "Question" || nodeData.NodeType == "Thanks") {
                        node.append(nodeName);
                        node.append(EditIcon); //// add icon option
                        if ($scope.item.QuestionType == "Objective")
                            node.append('<div class="questionIcon questiontop"> <i class="fa fa-question" aria-hidden="true"></i>');
                        else if ($scope.item.QuestionType == "Subjective")
                            node.append($('<div id="R_' + nodeId + '" ng-click="addnode($event)" ng-show="iseditable" class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>'));
                        else if ($scope.item.QuestionType == "Mixed") {
                            if ($scope.currentquestiontype == "Subjective")
                                node.append($('<div id="R_' + nodeId + '" ng-click="addnode($event)" ng-show="iseditable" class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>'));
                            else
                                node.append('<div class="questionIcon questiontop"> <i class="fa fa-question" aria-hidden="true"></i>');
                        }
                        node.append(deleteIcon);
                        node.append(CopyIcon);

                    }
                    return node;
                },
                isNullOrEmpty: function (data) {
                    if (data === undefined || data === null || data === "") {
                        return true;
                    }
                    return false;
                },
                saveCallTree: function () {
                    var callTreeObj = {
                        "flowName": $scope.item.QuestionSetName,
                        "calltree": ""
                    },
                        calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    function getNextNodes(sourceId, nodeId, connection, legIdx) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;
                        if ($('#' + nodeId).attr('data-node-type') == 'feature') {
                            if ($('#' + sourceId).attr('data-node-type') == 'menu' || $('#' + sourceId).attr('data-node-type') == 'feature' || $('#' + sourceId).attr('data-node-type') == 'StartFlowNode' || $('#' + sourceId).attr('data-node-type') == 'entryConnector') {
                                if (connection != null) {
                                    targetAnchorId = connection.endpoints[1].getUuid();
                                    nodes.push({ // Create link node
                                        "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                        "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                        "type": "link",
                                        "element": {},
                                    });
                                }
                            }
                        } else {
                            if (connection != undefined) {
                                targetAnchorId = connection.endpoints[1].getUuid();
                                nodes.push({
                                    "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                    "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                    "type": "link",
                                    "element": {},
                                });
                            }
                        }
                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                "position": $('#' + nodeId).attr("data-node-position"),
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                            "Weightage":$('#' + nodeId).attr("data-node-Weightage"),
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove')
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], null);
                                }
                            }
                            // i=0;
                        }
                    }
                    var tempEntryConnectorList = $(".calltree").find(".entryConnector"); // save StartFlowNode point
                    for (var i = 0; i < tempEntryConnectorList.length; i++) {
                        flowDataStore[0].mainMenu = tempEntryConnectorList[i].id;
                        getNextNodes(null, tempEntryConnectorList[i].id);

                    }
                    flowDataStore[0].callTree = calltree;
                    var postData = {
                        "flowName": '',
                        "callTree": {},
                    };
                    postData.IVRData = converttoIVR(flowDataStore[0].callTree, flowDataStore[0].mainMenu);
                    if (postData.IVRData != "") {
                        postData.IVRData = JSON.stringify(postData.IVRData);
                        postData.EMAILData = JSON.stringify(converttoEmail(flowDataStore[0].callTree, flowDataStore[0].mainMenu));
                        postData.NoOfQuestions = $scope.Qinfo.TotalQuestions
                        postData.callTree = JSON.stringify(flowDataStore[0].callTree);
                        saveflow(postData);
                    }
                },
                loadCallTree: function (nodesObj) {
                    $scope.AvailableNodeids = [];
                    if ($scope.redraw)
                        nodesObj = $scope.Redrawcalltree;
                    var rootnode = _.where(nodesObj, {
                        type: "entryConnector"
                    });

                    function getNextNodes(node) {
                        for (var t = 0; t < node.nodeOptions.childnodes.length; t++) {
                            var childnode = _.where(nodesObj, {
                                id: node.nodeOptions.childnodes[t].targetId
                            });
                            var isexist = !!_.where($scope.AvailableNodeids, {
                                Id: node.nodeOptions.childnodes[t].targetId
                            }).length;
                            if (isexist > 0) {
                                this.CallTree.tabInstances["drawing"].connect({
                                    uuids: ["endPoint-" + node.id + "Bottom",
                                    "endPoint-" + childnode[0].element.id + "Top"
                                    ],
                                });
                                return;
                            } else {
                                $scope.AvailableNodeids.push({
                                    Id: childnode[0].id
                                });
                                this.CallTree.loadtree(childnode[0]);
                                getNextNodes(childnode[0]);
                            }
                        }
                        // i = 0;
                    }
                    $scope.AvailableNodeids.push({
                        Id: rootnode[0].id
                    });
                    this.loadtree(rootnode[0]);
                    getNextNodes(rootnode[0]);
                },
                loadtree: function (nodeObj) {
                    var that = this;
                    var nodePosition = nodeObj.element.position.split(":");
                    var nodeText = nodeObj.name;
                    if (nodeObj.type == "entryConnector") {
                        nodeText = CallTree.connectorNames[nodeObj.id] || "Question Root";
                    }

                    if (nodeObj.nodeOptions.QuestionType == "WAV") {
                        nodeText = nodeObj.nodeOptions.Nodename.split(':')[1];
                    }
                    $scope.currentquestiontype = nodeObj.nodeOptions.InputType;
                    newNode = that.createNode({
                        id: nodeObj.id,
                        type: nodeObj.type,
                        value: nodeText,
                        NodeType: nodeObj.nodeOptions.NodeType,
                        OptionVarients: nodeObj.nodeOptions.OptionVarients,
                    });
                    newNode.attr("data-node-Weightage", nodeObj.Weightage== undefined? '0' : nodeObj.Weightage);
                    $('#drawing').append(newNode);
                    $compile(newNode)($scope);
                    newNode.css({
                        top: parseInt(nodePosition[0]),
                        left: parseInt(nodePosition[1])
                    });
                    newNode.attr("data-node-position", nodeObj.element.position);
                    newNode.attr("data-node-json", JSON.stringify(nodeObj.nodeOptions));
                    that.tabInstances["drawing"].draggable(newNode);
                    that.addEndPoints(nodeObj.id, nodeObj.type, that.tabInstances["drawing"]);
                    $(newNode).draggable({
                        stop: function (e, ui) {
                            var position = ui.position.top + ":" + ui.position.left;
                            $(e.target).attr({
                                "data-node-position": position
                            });
                        }
                    });
                    if (nodeObj.type == "entryConnector" && nodeObj.element.sourceAnchor == '' && nodeObj.element.targetAnchor != '') {
                        that.tabInstances["drawing"].connect({
                            uuids: ["endPoint-" + nodeObj.id + "Bottom",
                            nodeObj.element.targetAnchor
                            ],
                        });
                    } else if (nodeObj.element.sourceAnchor != '' || nodeObj.element.targetAnchor != '') {
                        that.tabInstances["drawing"].connect({
                            uuids: [nodeObj.element.sourceAnchor,
                            nodeObj.element.targetAnchor
                            ],
                        });
                    }
                },
                deleteNode: function (node) {
                    var nodeId = $(node).attr('id');
                    this.removeAllchildnode(nodeId);
                },
                deleteNodeManual: function (nodeId) {
                    this.removeAllchildnode(nodeId);
                },
                removeAllchildnode: function (nodeId) {
                    function getNextNodes(nodeId) {
                        var connections = this.CallTree.tabInstances["drawing"].getConnections({
                            source: nodeId
                        });
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove');
                            this.CallTree.deleteNodeGeneric(nodeId);
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    getNextNodes(connections[i].targetId);
                                }
                            }
                            this.CallTree.deleteNodeGeneric(nodeId);
                            i = 0;
                        }
                    }
                    getNextNodes(nodeId);
                },
                getAllchildnode: function (node) {
                    var calltree = {
                        "flowName": $scope.item.QuestionSetName,
                        "nodes": []
                    },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    function getNextNodes(sourceId, nodeId, connection, legIdx) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;

                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                "position": $('#' + nodeId).attr("data-node-position"),
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove')
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], null);
                                }
                            }
                            // i=0;
                        }
                    }
                    calltree.Copyroot = node.id;
                    getNextNodes(null, node.id);
                    $scope.CopyNodedata = calltree;
                },
                getquestionoptioncount: function () {
                    var callTreeObj = {
                        "flowName": $scope.item.QuestionSetName,
                        "calltree": ""
                    },
                        calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    var setcurentblock = true;
                    var arrayleveljson = [];
                    var instances = this.tabInstances,
                        source, target, sourceId, targetId;
                    var loopval = 0;

                    function getNextNodes(sourceId, nodeId, connection, loopvalue) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;
                        if ($('#' + nodeId).attr('data-node-type') == 'feature') {
                            if ($('#' + sourceId).attr('data-node-type') == 'menu' || $('#' + sourceId).attr('data-node-type') == 'feature' || $('#' + sourceId).attr('data-node-type') == 'StartFlowNode' || $('#' + sourceId).attr('data-node-type') == 'entryConnector') {
                                if (connection != null) {
                                    targetAnchorId = connection.endpoints[1].getUuid();
                                    nodes.push({ // Create link node
                                        "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                        "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                        "type": "link",
                                        "element": {},
                                    });
                                }
                            }
                        } else {
                            if (connection != undefined) {
                                targetAnchorId = connection.endpoints[1].getUuid();
                                nodes.push({
                                    "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                    "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                    "type": "link",
                                    "element": {},
                                });
                            }
                        }
                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        var poscalc = "20:160"
                        if (nodeId != "StartFlowNode")
                            poscalc = (loopvalue - 1) * 180 + ':' + (arrayleveljson[loopvalue - 1].question + arrayleveljson[loopvalue - 1].option) * 150;
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                // "position": $('#' + nodeId).attr("data-node-position"),
                                "position": poscalc,
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                            //"level": loopvalue - 1 + ':' + (arrayleveljson[loopvalue - 1].question + arrayleveljson[loopvalue - 1].option)
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove');
                            --loopval;
                            return;
                        } else {
                            setcurentblock = true;
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    if (setcurentblock) {
                                        var isexist = !!_.where(arrayleveljson, {
                                            level: loopvalue
                                        }).length;

                                        if (!isexist) {
                                            arrayleveljson.push({
                                                level: loopvalue,
                                                question: 0,
                                                option: 0
                                            });
                                        }
                                        if ($.parseJSON($('#' + connections[i].targetId).attr("data-node-json")).NodeType == "Question")
                                            arrayleveljson[loopvalue].question++;
                                        else
                                            arrayleveljson[loopvalue].option++;
                                        setcurentblock = false;
                                    } else {
                                        if ($.parseJSON($('#' + connections[i].targetId).attr("data-node-json")).NodeType == "Question")
                                            arrayleveljson[loopvalue].question++;
                                        else
                                            arrayleveljson[loopvalue].option++;
                                    }
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], ++loopval);
                                }
                                --loopval;
                            }
                        }
                    }
                    arrayleveljson.push({
                        level: loopval,
                        question: 0,
                        option: 1
                    });

                    getNextNodes(null, 'StartFlowNode', null, ++loopval);
                    $scope.Redrawcalltree = calltree.nodes;
                    //Redraw
                    $scope.redraw = true;
                    //this.loadCallTree(calltree.nodes);
                    changeCallFlow($scope.item);
                },
                savebeforeaction: function () {
                    $scope.changedetected = true;
                    $scope.PrevStatedata = [];
                    var callTreeObj = {
                        "flowName": $scope.item.QuestionSetName,
                        "calltree": ""
                    },
                        calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    var setcurentblock = true;
                    var arrayleveljson = [];
                    var instances = this.tabInstances,
                        source, target, sourceId, targetId;
                    var loopval = 0;

                    function getNextNodes(sourceId, nodeId, connection, loopvalue) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;
                        nodes = calltree.nodes;
                        if ($('#' + nodeId).attr('data-node-type') == 'feature') {
                            if ($('#' + sourceId).attr('data-node-type') == 'menu' || $('#' + sourceId).attr('data-node-type') == 'feature' || $('#' + sourceId).attr('data-node-type') == 'StartFlowNode' || $('#' + sourceId).attr('data-node-type') == 'entryConnector') {
                                if (connection != null) {
                                    targetAnchorId = connection.endpoints[1].getUuid();
                                    nodes.push({ // Create link node
                                        "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                        "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                        "type": "link",
                                        "element": {},
                                    });
                                }
                            }
                        } else {
                            if (connection != undefined) {
                                targetAnchorId = connection.endpoints[1].getUuid();
                                nodes.push({
                                    "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                    "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                    "type": "link",
                                    "element": {},
                                });
                            }
                        }
                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        var poscalc = "20:160"
                        if (nodeId != "StartFlowNode")
                            poscalc = (loopvalue - 1) * 180 + ':' + (arrayleveljson[loopvalue - 1].question + arrayleveljson[loopvalue - 1].option) * 150;
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                "position": poscalc,
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove');
                            --loopval;
                            return;
                        } else {
                            setcurentblock = true;
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    if (setcurentblock) {
                                        var isexist = !!_.where(arrayleveljson, {
                                            level: loopvalue
                                        }).length;

                                        if (!isexist) {
                                            arrayleveljson.push({
                                                level: loopvalue,
                                                question: 0,
                                                option: 0
                                            });
                                        }
                                        if ($.parseJSON($('#' + connections[i].targetId).attr("data-node-json")).NodeType == "Question")
                                            arrayleveljson[loopvalue].question++;
                                        else
                                            arrayleveljson[loopvalue].option++;
                                        setcurentblock = false;
                                    } else {
                                        if ($.parseJSON($('#' + connections[i].targetId).attr("data-node-json")).NodeType == "Question")
                                            arrayleveljson[loopvalue].question++;
                                        else
                                            arrayleveljson[loopvalue].option++;
                                    }
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], ++loopval);
                                }
                                --loopval;
                            }
                        }
                    }
                    arrayleveljson.push({
                        level: loopval,
                        question: 0,
                        option: 1
                    });
                    getNextNodes(null, 'StartFlowNode', null, ++loopval);
                    $scope.PrevStatedata = calltree.nodes;
                },
                deleteNodeGeneric: function (sourceId) {
                    this.tabInstances["drawing"].detachAllConnections(sourceId);
                    this.tabInstances["drawing"].removeAllEndpoints(sourceId);
                    delete this.connectorNames[sourceId];
                    $('#' + sourceId).remove();
                },
            };

            CallTree.init();
        });


    })(); //Jquery library ending here

    function createObjectivequestion() {
        angular.element(document.querySelector('#loader')).removeClass('hide');
        $scope.optionname = "Question ";
        var node = CallTree.createnodemanual(current_config_nodeID[0], 'Question', "");
        current_config_nodeID = node;
        $scope.optionname = "";
        var scope = angular.element(document.getElementById('addQuestions')).scope();
        $('#moduleConfigurationDiv').css('width', '94%');
        var node = current_config_nodeID,
            moduleConfigurationDiv = $('#moduleConfigurationDiv');
        var featureName = node.attr('data-node-name');
        var parsingdata = node.attr('data-node-json');
        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
            nodeattributes = $.parseJSON(parsingdata);
        $timeout(function () {
            // $scope.refreshSlider();
            angular.element(document.querySelector('#loader')).addClass('hide');
            $scope.$apply(function () {
                $scope.rowdata = getChildNode(current_config_nodeID[0].id);

                $scope.Config = {
                    Nodename: featureName,
                    ObjQuestion: nodeattributes.ObjQuestion,
                    QuestionType: nodeattributes.QuestionType,
                    InputType: nodeattributes.InputType,
                    childnodes: nodeattributes.childnodes,
                    OptionVarients: nodeattributes.OptionVarients,
                    NodeType: nodeattributes.NodeType,
                };

            })
        }, 1000);
    }

    function addoptiontotree(value, Weightage) {
        var isexist = !!_.where($scope.Optionlist, {
            OptionValue: $scope.optionname
        }).length;
        if (!isexist) {
            var json = {
                option: $scope.optionname,
                OptionVarients: $scope.OptionVarients,
                weightage : Weightage
            }
            surveyFactory.Create_Options(json)
                .then(function (success) {
                    $scope.GetAllQuestionOptions();
                });
        }
        var cnode = CallTree.createnodemanual(current_config_nodeID[0], 'Option', value, Weightage);
        $scope.rowdata.push({
            TargetValue: $scope.optionname,
            OptionVarients: value,
            targetId: cnode[0].id,
            Weightage: Weightage
        });
        $scope.optionname = "";
        $scope.OptionVarients = "";
        $scope.refreshSlider(0);
        return cnode;
    }


    function getChildNode(nodeid) {
        var constructjson = [];
        var connections = CallTree.tabInstances["drawing"].getConnections({
            source: nodeid
        });
        for (var i = 0; i < connections.length; i++)
            constructjson.push({
                targetId: connections[i].targetId,
                TargetValue: $('#' + connections[i].targetId).attr('data-node-name'),
                OptionVarients: $('#' + connections[i].targetId).attr('data-node-OptionVarients'),
                Weightage: $('#' + connections[i].targetId).attr('data-node-Weightage') == undefined ? 0 : $('#' + connections[i].targetId).attr('data-node-Weightage')
            })
        return constructjson;
    }

    function changeCallFlow(currFlow) {
        flowDataStore = [];
        $('#drawing').remove();
        if (currFlow.QuestionSetName != "--Select--") {
            if (currFlow.JSONData != '') {
                flowDataStore.push({
                    callTree: {},
                    FlowName: currFlow.QuestionSetName
                });
                flowDataStore[0].callTree = $.parseJSON(currFlow.JSONData);
            }
            $("div#tabs").append("<div class='container calltree' style='background: #fff;' id='drawing'/>");
            if (currFlow.JSONData != '')
                CallTree.loadMultipleFlows();
            CallTree.createContainers(currFlow);
        }
        triggerpageevent(0);
    }

    function saveflow(postData) {
        if ($scope.item.WelcomeMessage && $scope.item.ThanksMessage) {
            var json = {
                id: $scope.item.ID,
                departmentId: $scope.item.DepartmentID,
                QuestionSetName: $scope.item.QuestionSetName,
                flowName: $scope.item.QuestionSetName,
                WelcomeMessage: $scope.item.WelcomeMessage,
                ThanksMessage: $scope.item.ThanksMessage,
                jSONData: postData.callTree,
                IVRData: postData.IVRData,
                EMAILData: postData.EMAILData,
                IsActive: true,
                NoOfQuestions: postData.NoOfQuestions
            }
            surveyFactory.UpdateQuestionSet(json)
                .then(function (success) {
                    appFactory.showSuccess("Survey saved successfully");
                    $scope.GetAllQuestionSet("");
                    $scope.iseditable = false;
                }, function (error) {
                    alert("contacterror");
                });
        } else
            appFactory.showWarning('Please ensure welcome and thanks message are filled.')
    }

    function converttoIVR(inputdata, mainmenu) {
        $scope.Qinfo = {
            TotalQuestions: 0,
        };
        var IVRdata = {
            mainMenu: mainmenu,
            Nodes: []
        };
        var filtered = _.filter(inputdata.nodes, function (node) {
            return node.type != "link";
        });
        for (var j = 0; j < filtered.length; j++) {
            var processjson = {
                childnodes: []
            };
            processjson.NodeId = filtered[j].id;
            processjson.NodeValue = filtered[j].name;
            processjson.Weightage = filtered[j].Weightage;
            if (processjson.NodeId != "StartFlowNode") {
                processjson.NodeType = filtered[j].nodeOptions.NodeType;
                // processjson.Weightage = filtered[j].nodeOptions.Weightage;
                if ($scope.item.QuestionType != "Objective") {
                    processjson.NodeValue = processjson.NodeValue;
                } else {

                    if (filtered[j].nodeOptions.NodeType == "Option") {
                        if ($scope.item.InputMode == "VOICE")
                            processjson.NodeValue += '-' + filtered[j].nodeOptions.OptionVarients;
                        else
                            processjson.NodeValue = filtered[j].nodeOptions.OptionVarients + '/' + processjson.NodeValue;
                    }
                }
            }
            if (filtered[j].nodeOptions.QuestionType != undefined) {
                processjson.Question = filtered[j].nodeOptions.ObjQuestion;
                if (filtered[j].nodeOptions.QuestionType == 'WAV')
                    processjson.Question = filtered[j].nodeOptions.Nodename;
                processjson.QuestionType = filtered[j].nodeOptions.QuestionType;
                processjson.InputType = filtered[j].nodeOptions.InputType;
            }
            var childNodes = getChildNode(processjson.NodeId);
            if ($scope.item.QuestionType == "Objective") {
                if (filtered[j].nodeOptions.NodeType == "Question" && childNodes.length <= 0) {
                    toaster.pop({
                        type: 'warning',
                        body: "Survey question " + processjson.Question + "must have option",
                        bodyOutputType: 'trustedHtml'
                    });
                    return "";
                }
            }
            if (filtered[j].nodeOptions.NodeType == "Question") {
                $scope.Qinfo.TotalQuestions++;
            }
            if (childNodes.length > 0) {
                var questionReadoutconstruct = "";
                if ($scope.item.InputMode == "VOICE") {
                    if ($scope.item.LanguageID == 1)
                        questionReadoutconstruct = " Please say ";
                    else
                        questionReadoutconstruct = " कृपया कहे ";
                }
                for (var k = 0; k < childNodes.length; k++) {
                    var nodevarient = "";
                    var convertoptionvarient = childNodes[k].OptionVarients == undefined ? "" : childNodes[k].OptionVarients;

                    if ($scope.item.QuestionType == "Objective") {
                        if ($scope.item.InputMode == "VOICE") {
                            nodevarient = childNodes[k].TargetValue + '-' + convertoptionvarient;
                            if (convertoptionvarient != "Thanks") {
                                if ($scope.item.LanguageID == 1) {
                                    if (k === childNodes.length - 1)
                                        questionReadoutconstruct += childNodes[k].TargetValue;
                                    else
                                        questionReadoutconstruct += childNodes[k].TargetValue + " or ";
                                } else {
                                    var optionvarientfirstvalue = convertoptionvarient.split(',');
                                    if (k === childNodes.length - 1)
                                        questionReadoutconstruct += " " + optionvarientfirstvalue[0];
                                    else
                                        questionReadoutconstruct += " " + optionvarientfirstvalue[0] + " या ";
                                }
                            }
                        } else {
                            if (convertoptionvarient != "Thanks") {
                                if ($scope.item.LanguageID == 1) {
                                    if (k === childNodes.length - 1)
                                        questionReadoutconstruct += " Press " + convertoptionvarient + " for " + childNodes[k].TargetValue;
                                    else
                                        questionReadoutconstruct += " Press " + convertoptionvarient + " for " + childNodes[k].TargetValue; //+ " or ";
                                } else {
                                    if (k === childNodes.length - 1)

                                        questionReadoutconstruct += childNodes[k].TargetValue + " के लिए " + convertoptionvarient + "  दबाएं ";
                                    else
                                        questionReadoutconstruct += " " + childNodes[k].TargetValue + " के लिए " + convertoptionvarient + "  दबाएं"; // या";
                                }
                            }
                            nodevarient = convertoptionvarient + "/" + childNodes[k].TargetValue;
                        }
                    }
                    if ($scope.item.QuestionType != "Objective") {
                        nodevarient = childNodes[k].TargetValue;
                    }
                    processjson.childnodes.push({
                        'NextNodeId': childNodes[k].targetId,
                        'NextNodeValue': nodevarient
                    });
                }
                if ($scope.item.QuestionType != "Objective") {
                    if (childNodes.length == 1 && processjson.NodeType == "Question")
                        processjson.InputType = "Subjective";
                    if (childNodes.length > 1 && processjson.NodeType == "Question")
                        processjson.InputType = "Objective";
                    if (processjson.NodeType == "Option")
                        processjson.InputType = "Option";
                }
                if (processjson.NodeId != "StartFlowNode")
                    processjson.Question = processjson.Question + questionReadoutconstruct;
            }
            if ($scope.item.QuestionType != "Objective") {
                if (childNodes.length == 0 && processjson.NodeType == "Question")
                    processjson.InputType = "Subjective";
                if (processjson.NodeType == "Option")
                    processjson.InputType = "Option";
            }

            IVRdata.Nodes.push(processjson);
        }
        return IVRdata;
    }

    function converttoEmail(inputdata, mainmenu) {
        var IVRdata = {
            mainMenu: mainmenu,
            Nodes: []
        };
        var filtered = _.filter(inputdata.nodes, function (node) {
            return node.type != "link";
        });
        for (var j = 0; j < filtered.length; j++) {
            var processjson = {
                childnodes: []
            };
            processjson.NodeId = filtered[j].id;
            processjson.NodeValue = filtered[j].name;
            if (processjson.NodeId != "StartFlowNode") {
                processjson.NodeType = filtered[j].nodeOptions.NodeType;

                processjson.NodeValue = processjson.NodeValue;
            }
            if (filtered[j].nodeOptions.QuestionType != undefined) {
                processjson.Question = filtered[j].nodeOptions.ObjQuestion;
                if (filtered[j].nodeOptions.QuestionType == 'WAV')
                    processjson.Question = filtered[j].nodeOptions.Nodename;
                processjson.QuestionType = filtered[j].nodeOptions.QuestionType;
                processjson.InputType = filtered[j].nodeOptions.InputType;
            }
            var childNodes = getChildNode(processjson.NodeId);
            if ($scope.item.QuestionType == "Objective") {
                if (filtered[j].nodeOptions.NodeType == "Question" && childNodes.length <= 0) {
                    appFactory.showWarning("Survey question " + processjson.Question + "must have option");
                    return "";
                }
            }
            if (childNodes.length > 0) {
                for (var k = 0; k < childNodes.length; k++) {
                    var nodevarient = "";
                    nodevarient = childNodes[k].TargetValue;
                    processjson.childnodes.push({
                        'NextNodeId': childNodes[k].targetId,
                        'NextNodeValue': nodevarient
                    });
                }
                if (childNodes.length == 1 && processjson.NodeType == "Question")
                    processjson.InputType = "Subjective";
                if (childNodes.length > 1 && processjson.NodeType == "Question")
                    processjson.InputType = "Objective";
                if (processjson.NodeType == "Option")
                    processjson.InputType = "Option";
            }

            if (childNodes.length == 0 && processjson.NodeType == "Question")
                processjson.InputType = "Subjective";
            if (processjson.NodeType == "Option")
                processjson.InputType = "Option";
            if (processjson.NodeType == "Thanks")
                processjson.InputType = "Thanks";

            IVRdata.Nodes.push(processjson);
        }
        return IVRdata;
    }


    function ZoomProcess(zoomvalue) {
        $("#drawing").css({
            "-webkit-transform": "scale(" + zoomvalue + ")",
            "-moz-transform": "scale(" + zoomvalue + ")",
            "-ms-transform": "scale(" + zoomvalue + ")",
            "-o-transform": "scale(" + zoomvalue + ")",
            "transform": "scale(" + zoomvalue + ")"
        });
    }

    function triggerpageevent(val) {
        $(window).resize(function () {
            $('#drawing').height($(window).height() - 180);
        });
        $(window).trigger('resize');
    }

    //****************** */
    // functional operations end
    //****************** */



    //**************************** */
    //survey clone process
    //**************************** */

    $scope.GetAllcampaignList = function (isFromActiveCampaign) {
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
            var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
            surveyCampFactory.GetAllSurveyCampaignList(departmentName).then(function (data) {

                if (data.data != null && data.data != undefined) {
                    $rootScope.allCampaignList = data.data;
                } else {
                    $rootScope.allCampaignList = null;
                }
                if ($scope.updatecampaingnforupload) {
                    $scope.isfileupload = false;
                    $('.modal-dialog .card').resizable().draggable({
                        containment: ".page-content"
                    });
                    $('.modal').on('hidden.bs.modal', function (e) {
                        $('.modal-dialog .card').css({ top: 0, left: 0 });

                    })

                    $('#uploadContacts').modal('show');
                    $scope.Selectedcampaignforuploaddata = _.filter($rootScope.allCampaignList, function (term) {
                        return term.CampaignName.toLowerCase() == $scope.surveyCampaigns.campaignName.toLowerCase();
                    });
                    if ($scope.Selectedcampaignforuploaddata.length) {
                        $scope.stepData[0].data.selectedcamp = $scope.Selectedcampaignforuploaddata[0];
                    }
                }
                if (!isFromActiveCampaign) {
                    $scope.voiceCampaignsName = "";
                }
                $scope.updatecampaingnforupload = false;
            });
        }
    }

    $scope.stepperControlInit = function () {
        $scope.selectedStep = 0;
        $scope.stepProgress = 1;
        $scope.maxStep = 3;
        $scope.showBusyText = false;

        $scope.stepData = [{
            step: 1,
            completed: false,
            optional: false,
            data: {}
        },
        // {
        //     step: 2,
        //     completed: false,
        //     optional: false,
        //     data: {}
        // },
        {
            step: 2,
            completed: false,
            optional: false,
            data: {}
        },

        ];
    }

    $scope.SurveyContactGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableRowSelection: true,
        enableSelectAll: true,
        multiSelct: true,
    };

    $rootScope.selectedGridData = [];
    $scope.Samplegrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
            name: 'S.No', width: '10%',
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
        },
        { name: 'Campaign Name', field: 'CampaignName', isSearchable: true, cellTooltip: true },
        { name: 'Sample Name', field: 'SampleName', isSearchable: true, cellTooltip: true },
        { name: 'File Name', field: 'FileName', isSearchable: true, cellTooltip: true },
        { name: 'Uploaded Date', field: 'UploadedDate', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
        { name: 'Total Records', field: 'TotalRecords', cellTooltip: true },
        { name: 'Process Records', field: 'ProcessRecords', enableCellEdit: true, cellClass: 'Created' },
        { name: 'UploadedBy', cellTooltip: true, width: '10%' }
        ]

    }

    $scope.Samplegrid.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
        gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
            if (newValue > rowEntity.TotalRecords) {
                appFactory.showWarning("Process record count should not be greater than total records");
                rowEntity.ProcessRecords = oldValue
            }
            $scope.$apply();
        });
        gridApi.selection.on.rowSelectionChanged($scope, function (row) {
            var msg = 'row selected on single' + row.isSelected;
            console.log(msg);
            if (row.isSelected == true) {
                $rootScope.IsselectedGrid = true;
                $rootScope.selectedGridData.push(row.entity);
            } else {
                $rootScope.IsselectedGrid = false;
                $rootScope.selectedGridData = _.without($rootScope.selectedGridData, _.findWhere($rootScope.selectedGridData, {
                    ID: row.entity.ID
                }))
            }
        });

        gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
            var msg = 'row length:' + row.length;
            console.log(msg);
            if (row.length > 0) {

                for (index = 0; index < row.length; index++) {
                    console.log(row[index]);
                    if (row[index].isSelected == true) {
                        $rootScope.IsselectedGrid = true;
                        $rootScope.selectedGridData.push(row[index].entity);
                    } else {
                        $rootScope.IsselectedGrid = false;
                        $rootScope.selectedGridData = [];
                    }
                }
            }
            if ($rootScope.IsselectedGrid == false) {
                $rootScope.selectedGridData = null;
                $rootScope.selectedGridData = [];
            }
        });

    };

    $scope.clearcontrols = function () {
        $scope.stepperControlInit();

        angular.element("input[type='file']").val(null);
        $scope.SurveyContactGrid.data = [];
        $scope.Isnotnull = false;
        $scope.isfileupload = false;
        $scope.GetAllcampaignList();
    }

    var getAllSamples = function () {
        var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
        var postdata = {
            departmentId: departmentName,
            user: 'ALL'
        };
        surveyFactory.getAllSamples(postdata).then(
            function success(data) {
                if (data.data && data.data.length) {
                    $scope.samples = data.data;
                    for (var i = 0; i < $scope.samples.length; i++) {
                        $scope.samples[i].ProcessRecords = $scope.samples[i].TotalRecords;
                    }
                    $scope.Samplegrid.data = $scope.samples;
                    window.setTimeout(function () {
                        $(window).resize();
                        $(window).resize();
                    }, 1000);
                }
            },
            function err(data) {

            });
    };

    $scope.GetAllQuestionType = function () {
        surveyFactory.GetAllQuestionType().then(
            function success(data) {
                $scope.QuestionType = data.data;
            },
            function error(data) { }
        )
    };
    $scope.GetAllCampaignbyDept = function () {
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
            var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
            surveyCampFactory.GetAllCampaignbyDept(departmentName).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $scope.resultdata = data.data;
                    $scope.campaignData = data.data;
                } else {
                    $scope.resultdata = null;
                    $scope.campaignData = null;
                }
            });
        }
    }
    //campaign process starrt point
    var init = function () {
        $scope.GetAllQuestionType();
        // $scope.GetAllSurveyCampaignList();
        $scope.GetAllCampaignbyDept();
        getAllSamples();
        $scope.GetAllcampaignList();
    };
    init();

    var isValidNum = function (value) {
        if (!value || value <= 0) {
            return false;
        }
        return true;
    };

    $scope.clearcontrols();
    $scope.UploadVoiceCampaignRes = {};

    $scope.CreateSampleSurvey = function (dstype) {
        $scope.UploadVoiceCampaignRes.uploadStatus = "READY";
        $scope.UploadVoiceCampaignRes.mobileNoField = $scope.stepData[0].data.mobileno;
        var filedMappingData = {};
        var arrydata = pickrequireddata();
        var samplename = ''
        if (arrydata.length == 1) {
            samplename = arrydata[0].SampleName;
        } else
            samplename = 'MultiSource'
        $scope.CreateSampleReq = {
            'surveyCampaignID': $scope.stepData[0].data.selectedcamp.ID,
            'MultiSource': JSON.stringify(arrydata),
            'sampleName': samplename, //$scope.stepData[0].data.selectedExtSample.SampleName,
            'sampleType': $scope.QuestionsetInfo.questiontypeId,
            'surveyID': $scope.CurrentQuestionSetID,
            'sampleCondition': '',
            //'existingSampleID': $scope.stepData[0].data.selectedExtSample.ID, //multiple sample mix
            'fileName': '',
            'totalRecords': arrydata[0].TotalRecords,
            'campaignFileName': $scope.UploadVoiceCampaignRes.campaignFileName,
            'dataSourceType': 'MultiSource',
            'uploadedBy': $scope.UploadVoiceCampaignRes.uploadedBy,
            'uploadDescription': $scope.UploadVoiceCampaignRes.uploadDescription,
            'isDemo': false,
        }
        if ($scope.CreateSampleReq != null && $scope.CreateSampleReq != undefined) {
            surveyCampFactory.CreateSample($scope.CreateSampleReq).then(function (data) {
                $rootScope.selectedGridData = [];
                getAllSamples();
                if (data.data != null & data.data != undefined) {
                    if (data.data && data.data.length) {
                        toaster.pop({
                            type: "success",
                            body: "Survey contact file uploded successfully",
                            bodyOutputType: 'trustedHtml'
                        });
                        createSampleSetting(data.data[0].sampleID);
                    } else {
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading survey contact file",
                            bodyOutputType: 'trustedHtml'
                        });
                    }

                } else {
                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading survey contact file",
                        bodyOutputType: 'trustedHtml'
                    });
                    $scope.isCompleted = false;
                }
            });
        }
    };

    var pickrequireddata = function () {
        var jsonarray = [];
        for (var i = 0; i < $rootScope.selectedGridData.length; i++) {
            jsonarray.push({
                'SampleID': $rootScope.selectedGridData[i].ID,
                'ProcessRecords': $rootScope.selectedGridData[i].ProcessRecords,
                'SampleName': $rootScope.selectedGridData[i].SampleName,
                'TotalRecords': 0
            });
            jsonarray[0].TotalRecords += $rootScope.selectedGridData[i].ProcessRecords;
        }
        return jsonarray;
    }

    $scope.submitCurrentStep = function submitCurrentStep(stepData, isSkip) {
        var deferred = $q.defer();
        $scope.showBusyText = true;
        var stepvalue = $scope.stepProgress;
        if (!$scope.stepData[0].data) {
            return;
        }
        if (stepvalue == 1) {
            postSampleData();
        }

        if (!stepData.completed && !isSkip) {
            //simulate $http
            $timeout(function () {
                $scope.showBusyText = false;
                deferred.resolve({
                    status: 200,
                    statusText: 'success',
                    data: {}
                });
                //move to next step when success
                stepData.completed = true;
                $scope.enableNextStep();
            }, 1000)
        } else {
            $scope.showBusyText = false;
            $scope.enableNextStep();
        }
    };


    $scope.GetSurveyNamesByType = function (typeId) {
        surveyFactory.GetSurveyNamesByType(typeId.ID).then(
            function success(data) {
                $scope.SurveyNames = data.data;
            },
            function error(data) { }
        )
    }
    $scope.enableNextStep = function nextStep() {
        //do not exceed into max step
        if (!$scope.stepData[1].data) {
            return;
        }
        if ($scope.selectedStep >= $scope.maxStep) {
            return;
        }
        //do not increment $scope.stepProgress when submitting from previously completed step
        if ($scope.selectedStep === $scope.stepProgress - 1) {
            $scope.stepProgress = $scope.stepProgress + 1;
        }
        $scope.selectedStep = $scope.selectedStep + 1;
    }

    $scope.moveToPreviousStep = function moveToPreviousStep() {
        if ($scope.selectedStep > 0) {
            $scope.stepProgress = $scope.selectedStep;
            $scope.selectedStep = $scope.selectedStep - 1;
        }
    };

    $scope.CreateRetrySchdule = function () {
        $scope.CreateSampleReq = {
            'surveyCampaignID': $scope.item.SurveyCampaignID,
            'sampleName': $scope.item.SampleName,
            'sampleType': $scope.item.QuestiontypeID,
            'surveyID': $scope.item.SurveyID,
            'sampleCondition': '',
            'existingSampleID': $scope.item.SampleId,
            'fileName': '',
            'totalRecords': $scope.item.FailureCount,
            'campaignFileName': '',
            'dataSourceType': 'RETRY',
            'uploadedBy': 'admin',
            'uploadDescription': 'test',
            'isDemo': false,
        }
        surveyCampFactory.CreateSample($scope.CreateSampleReq).then(function (data) {
            if (data.data != null & data.data != undefined) {
                if (data.data && data.data.length) {
                    createSampleSetting(data.data[0].sampleID);
                } else {
                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading survey contact file",
                        bodyOutputType: 'trustedHtml'
                    });
                }

            } else {
                toaster.pop({
                    type: "error",
                    body: "Failed while uploading survey contact file",
                    bodyOutputType: 'trustedHtml'
                });
                $scope.isCompleted = false;
            }
        });
    }
    var createSampleSetting = function (sampleId) {
        var sampleSetting = createSetting(sampleId);
        surveyCampFactory.createSampleSetting(sampleSetting).then(function (data) {
            $('#uploadContacts').modal('hide');
            $scope.clearcontrols();
        });
    };
    $scope.clearcontrols = function () {
        $scope.item = {};
        $scope.stepperControlInit();
    }
    var createSetting = function (sampleId) {
        var sampleSettingObj = $scope.sampleSetting;
        var sampleSetting = {};
        sampleSetting = {
            SampleId: sampleId,
            isEmailSurvey: sampleSettingObj.isEmailSurvey,
            isAutomatedIVR: sampleSettingObj.isAutomatedIVR,
            isManualCalling: sampleSettingObj.isManualCalling,
            EmailNoOfTimes: 1,
            DayIntervalBetweenEmailAttempts: sampleSettingObj.intervalInDaysIVR,
            HoursIntervalBetweenEmailAttempts: sampleSettingObj.intervalInHoursIVR,
            NoOfAutomatedIVRCallCount: 1,
            NoOfManualCallCount: Number(sampleSettingObj.intervalInDays),
            IsSMSIntimate: sampleSettingObj.isSMSIntimate,
            SMSIntimateText: sampleSettingObj.smsIntimateText,
            IsSMSAcknowledge: sampleSettingObj.isSMSAcknowledge,
            SMSAcknowledgeText: sampleSettingObj.smsAcknowledgeText,
            IntimateTimeType: 'Schedule',
            ScheduleDuration: sampleSettingObj.scheduleDuration,
            SurveyStartTime: moment(sampleSettingObj.startDate).format('YYYY-MM-DD HH:mm:ss'),
            SurveyEndTime: moment(sampleSettingObj.endDate).format('YYYY-MM-DD HH:mm:ss'),
        }
        if (sampleSettingObj.isManualCalling && (sampleSettingObj.isAutomatedIVR || sampleSettingObj.isEmailSurvey)) {
            sampleSetting.DayIntervalBetweenManualAttempts = sampleSettingObj.daysInterval;
        }
        return sampleSetting;
    };

    var postSampleData = function () {
        var sampleData = {};
        sampleData.rajSamparkFilter = {};
        sampleData.bhamashaFilter = {};
        sampleData.dataSourceType = 'SampleData';
        sampleData.sampleID = $rootScope.selectedGridData[0].ID; // $scope.stepData[0].data.selectedExtSample.ID;
        sampleData.lcmCampaignID = $scope.stepData[0].data.selectedcamp.LCMCampaignName;
        sampleData.sampleName = $scope.stepData[0].data.selectedcamp.CampaignName;
        // sampleData.sampleID  = 10;
        surveyFactory.postSampleData(sampleData, cbsPostSampleData, cbsPostSampleData);
    };

    var cbsPostSampleData = function (data) {
        $scope.showBusyText = false;
        if (!data.data || !data.data.uploadSampleData.length) {
            appFactory.showError('Error while uploading sample data');
            return;
        }
        $scope.UploadVoiceCampaignRes = data.data;
        $scope.sampleSetting.startDate = $scope.UploadVoiceCampaignRes.campaignStartDate;
        $scope.sampleSetting.endDate = $scope.UploadVoiceCampaignRes.campaignEndDate;
        $scope.sampleSetting.campaignStartDate = $scope.UploadVoiceCampaignRes.campaignStartDate;
        $scope.sampleSetting.campaignEndDate = $scope.UploadVoiceCampaignRes.campaignEndDate;
        $scope.SurveyContactGrid.data = data.data.uploadSampleData;
        $scope.enableNextStep();
    };
    var cbfPostSampleData = function (data) {

    }
    $scope.sampleSetting = {
        startDate: new Date(),
        endDate: new Date()
    }

    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        e.preventDefault();
        e.stopPropagation();
        $scope.open = {};
        $scope.open[date] = true;
    };

    $scope.onFinishSurvey = function () {
        var isValidDates = $scope.isValidSampleSettingDates(true);
        var isValidSetting = isValidSettings($scope.sampleSetting);
        if (!isValidSetting || !isValidDates) {
            return;
        }
        $scope.CreateSampleSurvey();
    };
    $scope.ExportToPdf = function () {
        var printContents = document.getElementById("drawing").innerHTML;
        var originalContents = document.body.innerHTML;
        var popupWin = window.open('', '_blank', 'width=300,height=300');
        popupWin.document.open()
        var label = '<div class="row" ><div class="col-md-12"><label class="col-md-6" >Welcome Message : </label><label class="col-md-6">' + $scope.item.WelcomeMessage + '</label> <br /> <label class="col-md-6">Thanks Message : </label><label class="col-md-6">' + $scope.item.ThanksMessage + '</label><br/><br/><br/><br/></div>';
        popupWin.document.write('<html> <base href="/ucgAdmin/" /> <head><title>' + $scope.item.QuestionSetName + '</title><link rel="stylesheet" type="text/css" href="chart/css/internal.css"  /><link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"   /><link rel="stylesheet" type="text/css" href="fonts/Roboto.css"   /><link href="chart/css/custom.css" rel="stylesheet"   /><link href="chart/css/mfb.css" rel="stylesheet"   /><link href="css/slider.css" rel="stylesheet"   />   <link rel="stylesheet" href="css/bootstrap3.min.css" /> </head> <body onload="window.print()">' + label + '<div class="col-md-12">' + printContents + '</div></div><script>setTimeout(function(){window.print();window.close();},1000);</script><script src="chart/lib/jquery-1.9.0.js"></script>        <script src="chart/js/jquery.form.js"></script>        <script src="chart/lib/jquery-ui-1.9.2-min.js"></script>        <script src="chart/lib/jquery.jsPlumb-1.7.5-min.js"></script>        <script src="chart/js/session_data.js"></script>        <script src="chart/js/bootstrap.min.js"></script><script src="chart/angular_content/global_constants.js"></script></body></html>');

    }

    $scope.iseditable = false;
    $scope.MakeEdit = function () {
        $scope.iseditable = true;
        $scope.changedetected = false;
    }

    $scope.ViewDetail = function () {
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });

        })

        $('#viewQuestions').modal('show');
    }

    $scope.isValidSampleSettingDates = function () {
        var sampleSetting = $scope.sampleSetting;
        var isValidStartDate = appFactory.isWithInDate(sampleSetting.campaignStartDate, sampleSetting.startDate);
        var isValidEndDate = appFactory.isWithInDate(sampleSetting.campaignEndDate, sampleSetting.endDate, true);
        var isValidDates = appFactory.isValidStartAndEndDate(sampleSetting.startDate, sampleSetting.endDate);

        $scope.sampleSetting.inValidStartDate = !isValidStartDate;
        $scope.sampleSetting.inValidEndDate = !isValidEndDate;
        if (!isValidDates) {
            $scope.sampleSetting.inValidStartDate = true;
            $scope.sampleSetting.inValidEndDate = true;
        }
        if (!isValidStartDate || !isValidEndDate || !isValidDates) {
            $scope.campaignStartDate = moment(sampleSetting.campaignStartDate).format('DD/MM/YYYY');
            $scope.campaignEndDate = moment(sampleSetting.campaignEndDate).format('DD/MM/YYYY');
            return false;
        }
        return true;
    };

    var isValidSettings = function (sampleSetting) {
        var errMsg = ''
        if ($scope.QuestionsetInfo.questiontypeId == 1) {
            if (!sampleSetting.isManualCalling && !sampleSetting.isAutomatedIVR && !sampleSetting.isEmailSurvey) {
                errMsg = 'Please a select survey mode';
            } else {
                if (sampleSetting.isEmailSurvey && (sampleSetting.isManualCalling || sampleSetting.isAutomatedIVR)) {
                    var isValidNumber = true;
                    if (sampleSetting.isEmailSurvey && sampleSetting.isAutomatedIVR) {
                        isValidNumber = isValidNum(sampleSetting.intervalInDaysIVR);
                        isValidNumber = isValidNumber || (isValidNum(sampleSetting.intervalInHoursIVR));
                    }
                    if ((sampleSetting.isEmailSurvey && sampleSetting.isManualCalling) || (sampleSetting.isAutomatedIVR && sampleSetting.isManualCalling)) {
                        isValidNumber = isValidNumber && (isValidNum(sampleSetting.daysInterval) || sampleSetting.intervalInDays);
                    }
                    if (!isValidNumber) {
                        errMsg = 'Please enter valid interval in days';
                    } else {
                        if (sampleSetting.intervalInHoursIVR && sampleSetting.intervalInHoursIVR > 24) {
                            errMsg = 'Interval in hours with in 24 hours';
                        }
                        if (sampleSetting.isEmailSurvey && (sampleSetting.isManualCalling || sampleSetting.isAutomatedIVR)) {
                            var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.daysInterval);
                            if (!isValidInterval) {
                                errMsg = 'Interval in days with in start and end days';
                            }
                        }
                        if (sampleSetting.isEmailSurvey && sampleSetting.isAutomatedIVR) {
                            var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.intervalInDaysIVR);
                            if (!isValidInterval) {
                                errMsg = 'Interval in days with in start and end days';
                            }
                        }
                    }
                }
            }
        } else {
            if (!sampleSetting.isManualCalling && !sampleSetting.isEmailSurvey) {
                errMsg = 'Please a select survey mode';
            }
            if (sampleSetting.isManualCalling && sampleSetting.isEmailSurvey) {
                if (!sampleSetting.daysInterval && sampleSetting.intervalInDays < 0) {
                    errMsg = 'Please enter valid interval in days';
                } else {
                    var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.daysInterval);
                    if (!isValidInterval) {
                        errMsg = 'Interval in days with in start and end days';
                    }
                }
            }
        }

        if (sampleSetting.isSMSIntimate) {
            if (!sampleSetting.smsIntimateText) {
                errMsg = 'Please Fill SMS intimation text';
            }
            if (!sampleSetting.scheduleDuration) {
                errMsg = 'Please Fill Schedule Duration';
            } else if (sampleSetting.scheduleDuration > 24) {
                errMsg = 'Schedule Duration should be with in 24 hours';
            }
        }
        if (sampleSetting.isSMSAcknowledge && !sampleSetting.smsAcknowledgeText) {
            errMsg = 'Please Fill SMS Acknowledgement text';
        }

        $scope.isValidHours = function (hours, isDuration) {
            if (hours > 24) {
                hours = 24;
            } else if (hours < 0) {
                hours = 0;
            }
            if (isDuration) {
                $scope.sampleSetting.scheduleDuration = hours;
            } else {
                $scope.sampleSetting.intervalInHoursIVR = hours;
            }
        };


        if (errMsg) {
            toaster.pop({
                type: "error",
                body: errMsg
            });
            return false;
        }
        return true;
    };

}]);