app.controller('CampaignController', ['$scope', '$rootScope', '_', '$q', 'appFactory', 'masterDataFactory', 'uiGridConstants', '$timeout', '$filter', 'toaster', 'profileFactory', 'campaignFactory', function ($scope, $rootScope, _, $q, appFactory, masterDataFactory, uiGridConstants, $timeout, $filter, toaster, profileFactory, campaignFactory) {
    // Global variable declarations

    $scope.voiceCampaigns = {};
    $scope.resvoiceCampaigns = {};
    $scope.detailsCampInfo = [];
    $scope.actionCampaigns = {};
    $scope.validateOnSubmit    = false;
    $scope.campaignData = [];
    $scope.iscampaignNameExist=false;
    $rootScope.allCampaignList = [];
    $scope.isValid = false;
    $scope.searchIndex = '';    
    $scope.appFactory = appFactory;
    $scope.appConst = appConst;
    $scope.permissions = $scope.appFactory.permissions[appConst.MENUS.RCHK_MGMT.MGMT_RCHK_CAMP];
    $scope.tab = 1;
    $scope.selectedDays = [];
    $scope.wordCheck = true;
    $scope.Obj = { poptab: 1 };
    $scope.ValidateInsertMessage = false;
    $scope.inlineValidationMsg = '';

    // $scope.form = {};

    $scope.voiceCampaigns.DayNumber = [];
    $scope.workDays = [
        { id: 1, name: 'M', fullName: 'Monday' },
        { id: 2, name: 'T', fullName: 'Tuesday' },
        { id: 3, name: 'W', fullName: 'Wednesday' },
        { id: 4, name: 'T', fullName: 'Thursday' },
        { id: 5, name: 'F', fullName: 'Friday' },
        { id: 6, name: 'S', fullName: 'Saturday' },
        { id: 7, name: 'S', fullName: 'Sunday' }
    ];

    $scope.form = {};

    // $scope.disableCampaign = false; 
    $scope.resultdata = [];
    $scope.voiceuploadfile = {};
    $scope.CiscoCampaign = [];
    $scope.permissions = appFactory.permissions[appConst.MENUS.CAMP_MGNT.MGNT_CAMP];

    // ***** Start of Campaign Index funcationality ***** //
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    //  var userObj = {
    //      SSOID: 'admin'
    //  };
    //  $rootScope.departmentName = 103;
    //  $scope.permissions = {
    //     'Add': true,
    //     'Modify': true,
    //     'Delete': true
    // };
   $rootScope.departmentName = userObj.departmentId; 

    $scope.AddworkingDay = function (dayID) {
        if (!$scope.voiceCampaigns.DayNumber) {
            $scope.voiceCampaigns.DayNumber = [];
        }
        var itemIndex = $scope.voiceCampaigns.DayNumber.indexOf(dayID);
        if (itemIndex < 0) {
            $scope.voiceCampaigns.DayNumber.push(dayID);
        } else {
            $scope.voiceCampaigns.DayNumber.splice(itemIndex, 1);
        }
    };
    $scope.Reset = function () {
        $scope.open = {};
        var d = new Date();
        d.setHours(0, 0, 0, 0);

        $scope.range = {
            startDate: d,
            endDate: new Date()
        };
        $scope.voiceCampaigns.departmentSearch = '';

        $scope.GetAllCampaignList();

    }
    $scope.SearchCampaign = function () {
        getSearchCampaign();
    };



    function getSearchCampaign() {

        $scope.GetCampaignList = {};
        $scope.GetCampaignList.fromDate = moment($scope.range.startDate).format('YYYY-MM-DD HH:mm:ss');
        $scope.GetCampaignList.toDate = moment($scope.range.endDate).format('YYYY-MM-DD HH:mm:ss');
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
            $scope.GetCampaignList.departmentID = $rootScope.departmentName;
            //var departmentName =$scope.voiceCampaigns.departmentSearch.ID;

            var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? $scope.voiceCampaigns.departmentSearch : $rootScope.departmentName;

            if (!departmentName) {
                $scope.GetCampaignList.departmentID = -1;
            } else if (departmentName.ID) {
                $scope.GetCampaignList.departmentID = departmentName.ID;
            } else {
                $scope.GetCampaignList.departmentID = departmentName;
            }
            campaignFactory.GetCampaignList($scope.GetCampaignList).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $rootScope.allCampaignList = data.data;

                    if (!$rootScope.allCampaignList.length) {
                        appFactory.showWarning("No Data Found");
                    } else {

                        appFactory.showSuccess("Search applied");
                    }
                }
                else {
                    $rootScope.allCampaignList = null;

                }
            });
        };
    }

    $scope.abusiveWords = [];
    $scope.GetAbusiveWords = function () {
        masterDataFactory.GetInvalidWords().then(
            function success(response) {
                //  console.log("edit", data);
                $scope.abusiveWords = response.data;
            },
            function error(response) {
                toaster.pop({
                    type: "error",
                    body: "Error occured while retreiving the data"
                });

            }
        )
    }
    $scope.GetAbusiveWords();

    $scope.CampaignGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
            name: 'S.No', width: '6%',
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>',
            enableSorting: false
        },
        { name: 'Campaign Name', field: 'CampaignId', isSearchable: true, cellTooltip: true, },
        {
            name: 'Department', field: 'departmentName', width: '20%',
            // cellTemplate: "<span> {{row.entity.LCMCampaignId.split('_')[0]}}</span>",
            isSearchable: true, cellTooltip: true
        },
        { name: 'noOfTries', field: 'noOfTries', visible: false },
        { name: 'Start Date', field: 'StartDate',cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
        { name: 'End Date', field: 'EndDate',cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
        {
            name: 'Status', field: 'CampaignLCMStatus', isSearchable: true, cellTooltip: true,
             // cellTemplate: "<span> {{row.entity.CampaignPercentage==0?'CREATED':row.entity.CampaignPercentage==100?'COMPLETED':row.entity.CampaignStatus}}<span>",
            //cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            // if (grid.getCellValue(row, col) == "CREATED") {
            // return 'Created';
            // } else if (grid.getCellValue(row, col) == "EXECUTING") {
            //    return 'Executing';
           // } else if (grid.getCellValue(row, col) == "STOPPED") {
           //    return 'Stopped'
          // }
          //}
        },
        { name: '%', width: '5%', field: 'CampaignPercentage', visible: false },
        {
            name: 'Options', width: '18%', enableSorting: false,
            cellTemplate: '<span>' +
            '<a href="#" ng-if="grid.appScope.permissions.Modify" class="action-status" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil" title="Edit Campaign"></span></a> <span ng-if="!grid.appScope.permissions.Modify" class="fa fa-pencil" style="color:#666; cursor: not-allowed;"  title="Edit Campaign"></span>' +
            '| <a href="#" ng-if="grid.appScope.permissions.Delete && row.entity.CampaignStatus != \'EXECUTING\'" class="action-status" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o" title="Delete Campaign"></span></a> <span ng-if="!grid.appScope.permissions.Delete || row.entity.CampaignStatus === \'EXECUTING\'" class="fa fa-trash-o" style="color:#666; cursor: not-allowed;" title="Delete Campaign"></span>' +
            ' | <a href="#" class="action-status" ng-click="grid.appScope.showDetails(row.entity,1)"><span class="fa fa-eye" title="View Campaign"></span></a> ' +
	    '| <a href="#" class="action-status" ng-click="grid.appScope.showUpload(row.entity)"><span class="fa fa-upload" title="Upload"></span></a>' +
            '</span>'
        },
        {
            name: 'Actions', width: '13%', enableSorting: false,
            cellTemplate: '<span ng-if="grid.appScope.permissions.Modify">' +
            ' <a href="#" class="action-status ac-play"  ng-click="grid.appScope.showStart(row.entity)"  ng-disabled="row.entity.CampaignStatus === \'EXECUTING\'"><span class="fa fa-play-circle" title="Resume Campaign"></span></a>' +
            '| <a class="action-status ac-stop" href="#"  ng-click="grid.appScope.showStop(row.entity)"  ng-disabled="(row.entity.CampaignStatus === \'STOPPED\' || row.entity.CampaignStatus === \'CREATED\')"><span class="fa fa-pause-circle" title="Pause Campaign"></span></a>' +
            ' </span>' +
            ' <span ng-if="!grid.appScope.permissions.Modify">' +
            ' <span class="fa fa-play-circle" style="color:#666; cursor: not-allowed;"  title="Resume Campaign"></span>' +
            '| <span class="fa fa-pause-circle" style="color:#666; cursor: not-allowed;"  title="Pause Campaign"></span>' +
            ' </span>'
        }

        ]
    };

    $scope.open = {};
    var d = new Date();
    d.setHours(0, 0, 0, 0);

    $scope.range = {
        startDate: d,
        endDate: new Date()
    };

    $scope.openCalendar = function (e, date) {
        $scope.open[date] = !$scope.open[date];
        $scope.open = {};
        e.preventDefault();
        e.stopPropagation();
        $scope.open[date] = true;
    };


    //$scope.ActiveCampaignGrid = angular.copy($scope.CampaignGrid);
    $scope.ActiveCampaignGrid={
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
            name: 'S.No', width: '6%',
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>',
            enableSorting: false
        },
        { name: 'Campaign Name', field: 'CampaignId', isSearchable: true, cellTooltip: true, },
        {
            name: 'Department', field: 'departmentName', width: '20%',
            // cellTemplate: "<span> {{row.entity.LCMCampaignId.split('_')[0]}}</span>",
            isSearchable: true, cellTooltip: true
        },
        { name: 'noOfTries', field: 'noOfTries', visible: false },
        { name: 'Start Date', field: 'StartDate',cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
        { name: 'End Date', field: 'EndDate',cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
        {
            name: 'Status', field: 'CampaignLCMStatus', isSearchable: true, cellTooltip: true,
             // cellTemplate: "<span> {{row.entity.CampaignPercentage==0?'CREATED':row.entity.CampaignPercentage==100?'COMPLETED':row.entity.CampaignStatus}}<span>",
            //cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            // if (grid.getCellValue(row, col) == "CREATED") {
            // return 'Created';
            // } else if (grid.getCellValue(row, col) == "EXECUTING") {
            //    return 'Executing';
           // } else if (grid.getCellValue(row, col) == "STOPPED") {
           //    return 'Stopped'
          // }
          //}
        },
        { name: '%', width: '5%', field: 'CampaignPercentage', visible: false },
        {
            name: 'Options', width: '18%', enableSorting: false,
            cellTemplate: '<span>' +
            '<a href="#" ng-if="grid.appScope.permissions.Modify" class="action-status" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil" title="Edit Campaign"></span></a> <span ng-if="!grid.appScope.permissions.Modify" class="fa fa-pencil" style="color:#666; cursor: not-allowed;"  title="Edit Campaign"></span>' +
            '| <a href="#" class="action-status" ng-click="grid.appScope.showDetails(row.entity,1)"><span class="fa fa-eye" title="View Campaign"></span></a> ' +
	    '| <a href="#" class="action-status" ng-click="grid.appScope.showUpload(row.entity)"><span class="fa fa-upload" title="Upload"></span></a>' +
            '</span>'
        },
        {
            name: 'Actions', width: '13%', enableSorting: false,
            cellTemplate: '<span ng-if="grid.appScope.permissions.Modify">' +
            ' <a href="#" class="action-status ac-play"  ng-click="grid.appScope.showStart(row.entity)"  ng-disabled="row.entity.CampaignStatus === \'EXECUTING\'"><span class="fa fa-play-circle" title="Resume Campaign"></span></a>' +
            '| <a class="action-status ac-stop" href="#"  ng-click="grid.appScope.showStop(row.entity)"  ng-disabled="(row.entity.CampaignStatus === \'STOPPED\' || row.entity.CampaignStatus === \'CREATED\')"><span class="fa fa-pause-circle" title="Pause Campaign"></span></a>' +
            ' </span>' +
            ' <span ng-if="!grid.appScope.permissions.Modify">' +
            ' <span class="fa fa-play-circle" style="color:#666; cursor: not-allowed;"  title="Resume Campaign"></span>' +
            '| <span class="fa fa-pause-circle" style="color:#666; cursor: not-allowed;"  title="Pause Campaign"></span>' +
            ' </span>'
        }

        ]
    };
    $scope.ActiveCampaignGriddata = [];
    $scope.OtherCampaignGriddata = [];
    $scope.GetAllCampaignbyDept = function () {
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
            var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
            campaignFactory.GetAllCampaignbyDept(departmentName).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $scope.resultdata = data.data;
                    _.find($scope.resultdata, function (item, index) {
                        if (item["CampaignStatus"] === "STOPPED") {
                            $scope.resultdata[index].CampaignStatus = 'PAUSED';
                        }
                    });
                    var campaignData = angular.copy($scope.resultdata);
                    $timeout(function () {
                        $scope.campaignData = angular.copy(campaignData);
                        $scope.OtherCampaignGriddata = $scope.resultdata;
                        // $scope.OtherCampaignGriddata = _.filter($scope.resultdata, function (resultItem) {
                        //     return resultItem.CampaignStatus != "EXECUTING";
                        // });

                        if ($scope.tab === 1) {
                            $scope.ActiveCampaignGriddata = _.filter(campaignData, function (resultItem) {
                                return resultItem.CampaignStatus == "EXECUTING";
                            });
                            $scope.ActiveCampaignGrid.data = $scope.ActiveCampaignGriddata;
                            getSearchableFields($scope.ActiveCampaignGrid);
                        } else {
                        }
                        $scope.CampaignGrid.data = $scope.OtherCampaignGriddata;
                        if ($scope.tab === 2) {
                            getSearchableFields($scope.CampaignGrid);
                        }
                    }, 10);
                } else {
                    $scope.resultdata = [];
                    $scope.CampaignGrid.data = [];
                    $scope.campaignData = [];
                }
            });
        }
    }
    $scope.refresh = function () {
        $scope.searchIndex = '';
        $scope.GetAllCampaignbyDept();
    }


    $scope.campTabs = function (campaignTab) {
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });
            $scope.validateOnSubmit    = false;

        })


        appFactory.ShowLoader();
        $scope.searchIndex = '';
        $scope.tab = campaignTab;
        $scope.tabCopy = campaignTab;
        if (campaignTab === 1 || campaignTab === 2) {
            $scope.refresh();
        } else if (campaignTab === 3) {
            $scope.GetAllUploadList();
        }
        calltimeout();
        $timeout(function () {
            appFactory.HideLoader();
        }, 1000)

    }

    $scope.GetAllCampaignList = function () {
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
            var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
            campaignFactory.GetAllCampaignList(departmentName).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $rootScope.allCampaignList = data.data;
                } else {
                    $rootScope.allCampaignList = [];
                }
            });
        }
    }

    $scope.GetCiscoCampaignbyDept = function (departmentName) {
        if (departmentName != null && departmentName != undefined) {
            campaignFactory.GetCiscoCampaignbyDept(departmentName).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $scope.CiscoCampaign = data.data; // = $scope.voiceCampaigns.campaignName;
                } else {
                    $scope.CiscoCampaign = [];
                }
            });
        }
    }
   
    $scope.showDetails = function (getrowdata,tabNo) {
        $scope.receivedRowdata = getrowdata;
        $scope.actionCampaigns = {};
        $scope.detailsCampInfo = [];
        $scope.actionCampaigns.departmentID = $rootScope.departmentName;
        $scope.actionCampaigns.campaignName = getrowdata.LCMCampaignId;
        $scope.actionCampaigns.campaignNameShow = getrowdata.CampaignId;
        $scope.actionCampaigns.GroupName = "Collections";
        $scope.Obj.poptab = tabNo;        

        campaignFactory.GetDetailedCampaignInfo($scope.actionCampaigns).then(function (data) {
            if (data.statusText == 'OK') {
                $('.modal-dialog .card').resizable().draggable({
                    containment: ".page-content"
                });
                $('.modal').on('hidden.bs.modal', function (e) {
                    $('.modal-dialog .card').css({ top: 0, left: 0 });
                    $scope.validateOnSubmit    = false;

                })

                $('#detailsCampaignInfo').modal('show');
                $scope.campDetails = data.data.campaignInfo[0];
                $scope.detailsCampInfo = data.data.campaignFullDetail.objContactDetails;
                $scope.campaignSuccessCount=data.data.CampaignSuccessCount;
            } else {
                toaster.pop({
                    type: "error",
                    body: "Error while selecting campaign details"
                });
            }
        });


    }
    $scope.refreshLivedata = function(tabNo){
        $scope.showDetails($scope.receivedRowdata,tabNo);
    }

    $scope.showStart = function (getrowdata) {
        var actionCampaigns = {};
        actionCampaigns.department = $rootScope.departmentName;
        actionCampaigns.LCMcampaignID = getrowdata.LCMCampaignId;
        actionCampaigns.campaignID = getrowdata.CampaignId;
        actionCampaigns.status = "START";
        actionCampaigns.GroupName = getrowdata.CampaignGroup;
        campaignFactory.DoCampaignAction(actionCampaigns).then(function (data) {
            if (data.statusText == 'OK') {
                $scope.GetAllCampaignbyDept();
                //toaster.pop({ type: "success", body: "Campaign started successfully" });
            } else {
                $scope.GetAllCampaignbyDept();
                toaster.pop({
                    type: "error",
                    body: "Error while starting Campaign"
                });
            }
        });
    }
    $scope.showFlush = function (getrowdata) {
        $scope.actionCampaigns = {};
        $scope.actionCampaigns.department = $rootScope.departmentName;
        $scope.actionCampaigns.campaignID = getrowdata.CampaignId;
        $scope.actionCampaigns.LCMcampaignID = getrowdata.LCMCampaignId;
        $scope.actionCampaigns.status = "FLUSH";
        $scope.actionCampaigns.GroupName = getrowdata.CampaignGroup;
        $('#confirmFlush').modal('show');
    }
    $scope.showStop = function (getrowdata) {
        $scope.actionCampaigns = {};
        $scope.actionCampaigns.department = $rootScope.departmentName;
        $scope.actionCampaigns.campaignID = getrowdata.CampaignId;
        $scope.actionCampaigns.LCMcampaignID = getrowdata.LCMCampaignId;
        $scope.actionCampaigns.status = "STOP";
        $scope.actionCampaigns.GroupName = getrowdata.CampaignGroup;
        campaignFactory.DoCampaignAction($scope.actionCampaigns).then(function (data) {
            if (data.statusText == 'OK') {
                $scope.GetAllCampaignbyDept();
                //toaster.pop({ type: "success", body: "Campaign stopped successfully" });
            } else {
                $scope.GetAllCampaignbyDept();
                toaster.pop({
                    type: "error",
                    body: "Error while stopping Campaign"
                });

            }
        });

    }



    $scope.showAdd = function () {
        resetcalender();
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });
            $scope.validateOnSubmit    = false;
            $scope.iscampaignNameExist=false;
        })
        $scope.voiceCampaigns.departmentName = $rootScope.departmentName;
        $scope.GetCiscoCampaignbyDept($rootScope.departmentName);
     
        $('#addCampaigns').modal('show');
    };
    $scope.closeModifyCamp = function () {
        if ($scope.form.campaignForm.$dirty) {
            $('#modifyconfirmClose').modal('show');
        }
    }
    $scope.closeAddCamp = function () {
        if ($scope.form.campaignForm.$dirty) {
            $('#confirmClose').modal('show');
        }
    }

    $scope.yesModeModalpop = function () {
        $('#confirmClose').modal('show');
        $('#addCampaigns').modal('show');
    }
    $scope.closeModalpop = function () {
        $('#addCampaigns').modal('hide');

    }
    $scope.yesModifyCamp = function () {
        $('#modifyconfirmClose').modal('show');
        $('#modifyCampaigns').modal('show');
    }
    $scope.closeModifyCamp = function () {
        $('#modifyCampaigns').modal('hide');
    }
    $scope.showEdit = function (getrowdata) {
        
        $scope.voiceCampaigns = {};
        campaignFactory.GETCampaignInfo(getrowdata.LCMCampaignId, $rootScope.departmentName).then(function (campdata) {
            if (campdata.data.length < 1) {
                return;
            }
            $scope.voiceCampaigns.description = campdata.data.campaignInfo[0].CampaignDescription;
            $scope.voiceCampaigns.UpdatedBy = campdata.data.campaignInfo[0].CreatedBy;
            $scope.voiceCampaigns.createdStartDate = getrowdata.StartDate;
            $scope.voiceCampaigns.createdEndDate = getrowdata.EndDate;
            $scope.voiceCampaigns.DayNumber = campdata.data.workingDay;
            if (campdata.data.campaignResponse.CreateCampaign.DialPlanRetries > 0) {
                $scope.voiceCampaigns.noOfTries = (campdata.data.campaignResponse.CreateCampaign.DialPlanRetries).toString();
            }

            $scope.workDays = [{ id: 1, selected: false, name: 'M', fullName: 'Monday' },
            { id: 2, selected: false, name: 'T', fullName: 'Tuesday' },
            { id: 3, selected: false, name: 'W', fullName: 'Wednesday' },
            { id: 4, selected: false, name: 'T', fullName: 'Thursday' },
            { id: 5, selected: false, name: 'F', fullName: 'Friday' },
            { id: 6, selected: false, name: 'S', fullName: 'Saturday' },
            { id: 7, selected: false, name: 'S', fullName: 'Sunday' },
            ];


            $scope.workDays.forEach(function (value, key) {
                if (campdata.data.workingDay.length > 0) {
                    campdata.data.workingDay.forEach(function (dayID) {
                        if (value.id == dayID) {
                            value.selected = true;
                            $scope.selectedDays.push(value);
                        } else {
                            $scope.selectedDays.push(value);
                        }
                    })
                }
            });


            campaignFactory.GetCiscoCampaignbyDept($rootScope.departmentName).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $scope.CiscoCampaign = data.data;
                    $scope.voiceCampaigns.departmentName = $rootScope.departmentName;
                    $scope.voiceCampaigns.campaignName = getrowdata.CampaignId;
                    $scope.voiceCampaigns.LCMcampaignID = getrowdata.LCMCampaignId
                    $scope.voiceCampaigns.startDate = getrowdata.StartDate;
                    $scope.voiceCampaigns.endDate = getrowdata.EndDate;
                    $scope.voiceCampaigns.enableDisable = true;
                    $('.modal-dialog .card').resizable().draggable({
                        containment: ".page-content"
                    });
                    $('.modal').on('hide.bs.modal', function (e) {
                        $('.modal-dialog .card').css({ top: 0, left: 0 });
                        // if ($scope.form.campaignForm.$dirty ) {              

                        //     $('#modifyconfirmClose').modal('show');
                        // }                    
                    })

                    $('#modifyCampaigns').modal('show');
                } else {

                    $scope.CiscoCampaign = null;
                }
            });
        });
    }
    $scope.showDelete = function (getrowdata) {
        $scope.actionCampaigns = {};
        $scope.actionCampaigns.department = $rootScope.departmentName;
        $scope.actionCampaigns.campaignID = getrowdata.CampaignId;
        $scope.actionCampaigns.LCMcampaignID = getrowdata.LCMCampaignId;
        $scope.actionCampaigns.status = "DELETE";
        $scope.actionCampaigns.GroupName = getrowdata.CampaignGroup;
        $('#confirmModal').modal('show');
    }
    // *****  End of Campaign Index funcationality ***** //
    // ***** Start of Add Campaign funcationality ***** //
    function resetcalender() {
        var starttime = new Date();
        starttime.setHours(9);
        starttime.setMinutes(0);
        var endtime = new Date();
        endtime.setHours(18);
        endtime.setMinutes(0);
        $scope.voiceCampaigns = {
            startDate: starttime,
            endDate: endtime,
        }


        $scope.workDays = [{ id: 1, selected: true, name: 'M', fullName: 'Monday' },
        { id: 2, selected: true, name: 'T', fullName: 'Tuesday' },
        { id: 3, selected: true, name: 'W', fullName: 'Wednesday' },
        { id: 4, selected: true, name: 'T', fullName: 'Thursday' },
        { id: 5, selected: true, name: 'F', fullName: 'Friday' },
        { id: 6, selected: false, name: 'S', fullName: 'Saturday' },
        { id: 7, selected: false, name: 'S', fullName: 'Sunday' },
        ];
        $scope.voiceCampaigns.DayNumber = [1, 2, 3, 4, 5];
    }

    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        $scope.open = {};
        e.preventDefault();
        e.stopPropagation();
        $scope.open[date] = true;
    };
    // ***** End Add Campaign funcationality ***** //
    // ***** Private Methods ***** //
    $scope.FlushCampaign = function () {
        if ($scope.actionCampaigns != null) {
            campaignFactory.DoCampaignAction($scope.actionCampaigns).then(function (data) {
                if (data.data == 1) {
                    $scope.GetAllCampaignbyDept();
                    //toaster.pop({ type: "success", body: "Campaign flushed successfully" });
                    $('#confirmFlush').modal('hide');
                } else {
                    $scope.GetAllCampaignbyDept();
                    toaster.pop({
                        type: "error",
                        body: "Error while flushing Campaign"
                    });
                }
            });
        }
    }

    $scope.CreateVoiceCampaign = function (opt) {



        $scope.validateOnSubmit    = true;
            IsValidInputscampaign("ADD");
        // $scope.isValid = true;
        if ($scope.isValid == true) {
            var startdate = moment($scope.voiceCampaigns.startDate).format("YYYY-MM-DD HH:mm:ss");
            var enddate = moment($scope.voiceCampaigns.endDate).format("YYYY-MM-DD HH:mm:ss");

            $scope.voiceCampaignsList = {
                createcampaign: {
                    "CampaignId": $scope.voiceCampaigns.campaignName,
                    "CreateUser": "1",
                    "CreateTime": $scope.voiceCampaigns.startDate,
                    "StartDate": startdate,
                    "EndDate": enddate,
                    "PaceMode": 8,
                    "TypeId": "CISCO",
                    "StartTime": startdate,
                    "EndTime": enddate,
                    "Description": $scope.voiceCampaigns.description,
                    "ZoneName": "(UTC+05:30) Chennai Kolkata Mumbai New Delhi",
                    "AutoStopDays": 0,
                    "DialPlanRetries": parseInt($scope.voiceCampaigns.noOfTries),
                    "OutcomeGroup": "",
                    "DialPlanName": "Default_Advanced_Strategy",
                    "FilePath": "",
                    "GroupName": "",
                    "CallGuide": 0,
                    "DayNames": "sat;sun",
                    "EnabledStateLaw": false,
                    "CloseGlobalRetry": false,
                    "DPRetriesType": "\u0000",
                    "IsCiscoGroup": true,
                    "RetainPCB": false,
                    "EnableChaining": false,
                    "CallStartegyType": 1,
                    "CycleRetryCount": 1,
                    "CycleRetryClose": true,
                    "CycleDays": 0,
                    "CycleHours": 0,
                    "CycleMinute": 0,
                    "IsCycleRetryEnabled": true,
                    "StateLawFollowType": "\u0000",
                    "DailyRetries": $scope.voiceCampaigns.noOfTries,
                    "TimeToLive": 365,
                    "TimezoneType": 0,
                    "SMSServerId": 0,
                    "EmailServerId": 0,
                    "Prefix": "",
                    "Suffix": "",
                    "EnableDNC": $scope.voiceCampaigns.enableDisable,
                    "GlobalDNC": $scope.voiceCampaigns.enableDisable,
                    "Callback": true,
                    "PCBRetries": 1,
                    "PCBOffsetDays": 0,
                    "PCBOffsetHours": 0,
                    "PCBOffsetMinute": 0,
                    "CallbackStrategy": "Default_Callback_Strategy",
                    "PreCallScript": false,
                    "CallbackStrategyType": "R",
                    "ResetGlobalRetries": false,
                    "PEWC": false,
                    "IsULCampaign": false,
                    "PostCallScript": false,
                    "PrecallScriptValue": 1,
                    "PostcallScriptValue": 0,
                    "EmailThreshold": 5,
                    "WindowGlobalRetry": false,
                    "WindowAttempts": 0,
                    "WindowDuration": 0,
                    "MultipleZipCode": false,
                    "ISMultipleZipCodeEnable": false,
                    "CampaignKey": 6,
                    "CampaignType": 1,
                    "DedicatedCampaignGroupType": 0,
                    "CampaignGroupType": 0
                }
            }
            $scope.voiceCampaignsList.uploadedBy = userObj.SSOID;
            $scope.voiceCampaignsList.DayNumber = $scope.voiceCampaigns.DayNumber;

            $scope.voiceCampaignsList.description = $scope.voiceCampaigns.description;
            $scope.voiceCampaignsList.actionFlag = '1';

            if (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) {
                $scope.voiceCampaignsList.departmentName = $scope.voiceCampaigns.department.ID;
            } else {
                $scope.voiceCampaignsList.departmentName = $rootScope.departmentName;
            }
            $scope.voiceCampaignsList.campaignName = $scope.voiceCampaigns.campaignName;

            //$scope.voiceCampaigns.startDate = moment($scope.startDate).format('DD/MM/YYYY HH:mm');
            // $scope.voiceCampaigns.endDate = moment($scope.endDate).format('DD/MM/YYYY HH:mm');
            //alert(json2xml($scope.voiceCampaigns));
            $scope.voiceCampaignsName = $scope.voiceCampaigns.campaignName;
            campaignFactory.CreateVoiceCampaign($scope.voiceCampaignsList).then(function (data) {
                if (data.data.statusMessage == "Success") {
                    $scope.GetAllCampaignbyDept();
                    if (opt == 2) {
                        $('#addCampaigns').modal('hide');
                        $scope.showUpload(2);
                    } else
                        $scope.campTabs(1);
                    toaster.pop({
                        type: "success",
                        body: "Campaign created successfully"
                    });
                    $('#addCampaigns').modal('hide');
                    $scope.voiceCampaigns = {};
                } else {
                    $scope.GetAllCampaignbyDept();
                    toaster.pop({
                        type: "error",
                        body: "Error while creating Campaign"
                    });
                    //$scope.voiceCampaigns = {};
                }
            });
        }
    }
    $scope.ModifyVoiceCampaign = function () {
        $scope.validateOnSubmit    = true;

        IsValidInputscampaign("MODIFY");
        if ($scope.isValid == true) {
            var startdate = moment($scope.voiceCampaigns.startDate).format("YYYY-MM-DD HH:mm:ss");
            var enddate = moment($scope.voiceCampaigns.endDate).format("YYYY-MM-DD HH:mm:ss");

            $scope.voiceCampaignsList = {
                editCampaign: {
                    "CampaignId": $scope.voiceCampaigns.campaignName,
                    "CreateUser": "1",
                    "CreateTime": $scope.voiceCampaigns.startDate,
                    "StartDate": startdate,
                    "EndDate": enddate,
                    "PaceMode": 8,
                    "TypeId": "CISCO",
                    "StartTime": startdate,
                    "EndTime": enddate,
                    "Description": $scope.voiceCampaigns.description,
                    "ZoneName": "(UTC+05:30) Chennai Kolkata Mumbai New Delhi",
                    "AutoStopDays": 0,
                    "DialPlanRetries": parseInt($scope.voiceCampaigns.noOfTries),
                    "OutcomeGroup": "",
                    "DialPlanName": "Default_Advanced_Strategy",
                    "FilePath": "",
                    "GroupName": "",
                    "CallGuide": 0,
                    "DayNames": "sat;sun",
                    "EnabledStateLaw": false,
                    "CloseGlobalRetry": false,
                    "DPRetriesType": "\u0000",
                    "IsCiscoGroup": true,
                    "RetainPCB": false,
                    "EnableChaining": false,
                    "CallStartegyType": 1,
                    "CycleRetryCount": 1,
                    "CycleRetryClose": true,
                    "CycleDays": 0,
                    "CycleHours": 0,
                    "CycleMinute": 0,
                    "IsCycleRetryEnabled": true,
                    "StateLawFollowType": "\u0000",
                    "DailyRetries": $scope.voiceCampaigns.noOfTries,
                    "TimeToLive": 365,
                    "TimezoneType": 0,
                    "SMSServerId": 0,
                    "EmailServerId": 0,
                    "Prefix": "",
                    "Suffix": "",
                    "EnableDNC": $scope.voiceCampaigns.enableDisable,
                    "GlobalDNC": $scope.voiceCampaigns.enableDisable,
                    "Callback": true,
                    "PCBRetries": 1,
                    "PCBOffsetDays": 0,
                    "PCBOffsetHours": 0,
                    "PCBOffsetMinute": 0,
                    "CallbackStrategy": "Default_Callback_Strategy",
                    "PreCallScript": false,
                    "CallbackStrategyType": "R",
                    "ResetGlobalRetries": false,
                    "PEWC": false,
                    "IsULCampaign": false,
                    "PostCallScript": false,
                    "PrecallScriptValue": 1,
                    "PostcallScriptValue": 0,
                    "EmailThreshold": 5,
                    "WindowGlobalRetry": false,
                    "WindowAttempts": 0,
                    "WindowDuration": 0,
                    "MultipleZipCode": false,
                    "ISMultipleZipCodeEnable": false,
                    "CampaignKey": 6,
                    "CampaignType": 1,
                    "DedicatedCampaignGroupType": 0,
                    "CampaignGroupType": 0
                }
            }
            $scope.voiceCampaignsList.uploadedBy = userObj.SSOID;
            $scope.voiceCampaignsList.description = $scope.voiceCampaigns.description;
            $scope.voiceCampaignsList.DayNumber = $scope.voiceCampaigns.DayNumber;
            // $scope.voiceCampaignsList.LCMcampaignID = $scope.voiceCampaigns.LCMcampaignID;
            $scope.voiceCampaignsList.actionFlag = '1';
            $scope.voiceCampaignsList.departmentName = $rootScope.departmentName;
            $scope.voiceCampaignsList.campaignName = $scope.voiceCampaigns.LCMcampaignID;
            campaignFactory.ModifyVoiceCampaign($scope.voiceCampaignsList).then(function (data) {
                if (data.data == "50025") {
                    $scope.GetAllCampaignbyDept();
                    $('#modifyCampaigns').modal('hide');
                    toaster.pop({
                        type: "success",
                        body: "Campaign edited successfully"
                    });
                    $scope.voiceCampaigns = {};
                } else {
                    $scope.GetAllCampaignbyDept();
                    toaster.pop({
                        type: "error",
                        body: "Error while editing Campaign"
                    });
                }
            });
        }
    }

    $scope.DeleteVoiceCampaign = function () {
        if ($scope.actionCampaigns != null && $scope.actionCampaigns != undefined) {
            $scope.actionCampaigns.uploadedBy = userObj.SSOID;
            $scope.actionCampaigns.updateID = '';
            $scope.actionCampaigns.actionFlag = 'D';
            campaignFactory.DoCampaignAction($scope.actionCampaigns).then(function (data) {
                if (data.data == '50014') {
                    $scope.GetAllCampaignbyDept();
                    // toaster.pop({ type: "success", body: "Campaign deleted successfully" });
                    $('#confirmModal').modal('hide');
                } else {
                    $scope.GetAllCampaignbyDept();
                    toaster.pop({
                        type: "error",
                        body: "Error while deleting Campaign"
                    });
                }
            });
        }
    }
    var IsValidInputscampaign = function (action) {


        $scope.isValid = true;
        // if($scope.voiceCampaigns.DayNumber.length == 0){

        // }
        var errMsg = campaignFactory.validateCampaign(action, $scope.voiceCampaigns, $scope.campaignData);
        if (!errMsg) {
            $scope.isValid = true;
            $scope.iscampaignNameExist=false;
            $scope.Message='';
            
        } else {
            $scope.iscampaignNameExist=false;
            $scope.Message='';
            $scope.isValid = false;
            if(errMsg==2){
                $scope.iscampaignNameExist=true;
                        }
            if(isNaN(errMsg)){
                $scope.Message=errMsg;               
            }
            
            // toaster.pop({
            //     type: 'error',
            //     body: errMsg
            // });
        }
    }
    // ***** End Private Methods *****//

    //Region Upload controller code


    $scope.selectedStep = 0;
    $scope.stepProgress = 1;
    $scope.maxStep = 3;
    $scope.showBusyText = false;
    $scope.stepData = [{ step: 1, completed: false, optional: false, data: {} },
    { step: 2, completed: false, optional: false, data: {} },
    { step: 3, completed: false, optional: false, data: {} },
    ];
    $scope.Languages = [ //{ id: 1, value: 'BOTH', DisplayName: 'Mixed' },
        { id: 2, value: 'ENG', DisplayName: 'English' },
        { id: 3, value: 'HIN', DisplayName: 'Hindi' }
    ];
    $scope.UploadVoiceCampaignReq = {};
    $scope.UploadVoiceCampaignRes = [];
    $scope.uploadStatusInfo = [];
    $scope.UpdateUploadmsgReq = {};
    $scope.isfileupload = false;
    $scope.Isnotnull = false;
    $rootScope.isDemo = false;
    $rootScope.selectedCampaign = "";
    $scope.CampaignListByDept = {};
    $scope.resultdata = [];
    $scope.updatecampaingnforupload = false;
    $scope.useoutscope = false;

    // ***** Start of Upload Contact funcationality ***** //
    $scope.ContactDetailsGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
            name: 'S.No', width: '10%',
            enableSorting: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
        },
        { name: 'Campaign Name', field: 'campaignName', isSearchable: true, cellTooltip: true, },
        { name: 'Uploaded By', field: 'UploadedBy',cellTooltip: true },
        { name: 'File Name', field: 'FileName', isSearchable: true, cellTooltip: true, },
        { name: 'Uploaded Date', field: 'UploadedDate', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
        { name: 'Total Records', field: 'TotalRecords',cellTooltip: true },
        {
            name: 'Options', width: '12%', enableSorting: false,
            cellTemplate: '<a href="#" class="action-status" ng-click="grid.appScope.showUploadStatus(row.entity)">'
            + '<span class="fa fa-eye" title="View Status"></span></a>'
            // + ' | ' + '<a href="#" class="action-status" ng-click="grid.appScope.showUpload(row.entity)">'
            // + '<span class="fa fa-upload" title="Upload"></span></a>'
            //  <a href="#" class="action-status" ng-click="grid.appScope.showDemoTemplate(row.entity)"> <span class="fa fa-chevron-circle-right" title="Demo View"></span></a>
        },
        ],
        data: $scope.resultdata
    };

    $scope.ContactDetailsGrid.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
        // $scope.GetAllUploadList();
    };
    $scope.GetAllcampaignListContactupload = function (isFromActiveCampaign) {
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
            var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
            campaignFactory.GetAllCampaignList(departmentName).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $rootScope.allCampaignList = data.data;
                } else {
                    $rootScope.allCampaignList = null;
                }

                if ($scope.updatecampaingnforupload) {
                    $('.modal-dialog .card').resizable().draggable({
                        containment: ".page-content"
                    });
                    $('.modal').on('hidden.bs.modal', function (e) {
                        $('.modal-dialog .card').css({ top: 0, left: 0 });
                        $scope.validateOnSubmit    = false;
            
                    })
                    $scope.isExceedsMaxAvailableCount = false;  
                    $('#uploadContacts').modal('show');
                    $scope.Selectedcampaignforuploaddata = _.where($rootScope.allCampaignList, {
                        CampaignName: $scope.voiceCampaignsName
                    })
                    if ($scope.Selectedcampaignforuploaddata.length) {
                        $scope.stepData[0].data.selectedcamp = $scope.Selectedcampaignforuploaddata[0];
                    }
                }
                if (!isFromActiveCampaign) {
                    $scope.voiceCampaignsName = "";
                }
                $scope.updatecampaingnforupload = false;
            });
        }
    }


    $scope.GetAllUploadList = function () {
        $scope.searchIndex = '';
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
            var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
            campaignFactory.GetAllUploadList(departmentName).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $scope.resultdata = _.filter(data.data, function (rowdata) {
                        return rowdata.IsDemo == false
                    });
                    $scope.ContactDetailsGrid.data = $scope.resultdata;
                    getSearchableFields($scope.ContactDetailsGrid);
                    $scope.gridApi.grid.modifyRows($scope.ContactDetailsGrid.data);
                    $scope.gridApi.core.refresh();
                } else {
                    $scope.resultdata = [];
                    $scope.ContactDetailsGrid.data = [];
                    getSearchableFields($scope.ContactDetailsGrid);
                }
            });
        }
    }

    $scope.refreshuploadlist = function () {
        $scope.GetAllUploadList();
    }


    $scope.showUpload = function (opt) {
        $scope.stepperControlInit();
        $scope.isfileupload = false;
        $scope.voiceuploadfile={};
        
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });
            $scope.validateOnSubmit    = false;

        })

        if (opt == 2) {
            $scope.updatecampaingnforupload = true;
            $scope.useoutscope = true;
            $scope.disableCampaign = true;
        } else {
			 $scope.isExceedsMaxAvailableCount = false; 
            $('#uploadContacts').modal('show');

            $scope.disableCampaign = false;
            $scope.useoutscope = false;
        }

        $scope.clearcontrols(true);
        $rootScope.isDemo = false;

        if (opt) {
            if (opt.campaignName) {
                $scope.stepData[0].data.selectedcamp = {
                    // 'CampaignDescription' : '',
                    'CampaignName': opt.campaignName,
                    // 'CiscoCampaignName' : '',
                    'Department' :opt.department,
                    'ID': opt.VoiceCampaignID,
                    // 'IsActive' : '',
                    // 'LCMCampaignName': opt.LCMCampaignID,
                    // 'UpdatedBy' :opt.UploadedBy,
                    // 'UpdatedDate' : opt.UploadedDate
                };
            }else if(opt.CampaignId){
                $scope.stepData[0].data.selectedcamp = {
                    'CampaignName': opt.CampaignId,
                    'Department' :opt.department,                
                    'ID': opt.campaignID
                }
            }
        }

    }
    $scope.showDemoTemplate = function (getrowdata) {
        $scope.clearcontrols();
        $rootScope.isDemo = true;
        $scope.stepData[0].data.selectedcamp = getrowdata.campaignName;
		 $scope.isExceedsMaxAvailableCount = false; 
        $('#uploadContacts').modal('show');
    }
    $scope.showUploadStatus = function (getrowdata) {
        $scope.actionCampaigns = {};
        $scope.actionCampaigns.departmentID = $rootScope.departmentName;
        // $scope.actionCampaigns.campaignName = getrowdata.CampaignId;
        $scope.actionCampaigns.campaignName = getrowdata.LCMCampaignID;
        // $scope.actionCampaigns.GroupName =getrowdata.CampaignGroup;
        $scope.actionCampaigns.GroupName = "Collections";

        campaignFactory.GetDetailUploadStatus($scope.actionCampaigns).then(function (data) {
            $scope.campaignName = getrowdata.campaignName;
            $('#detailsContactInfo').modal('show');
            $scope.uploadStatusInfo = data.data;
        });
    }

    $scope.ContactDataGrid = {
        paginationPageSizes: [5, 10, 15],
        paginationPageSize: 5,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableColumnResizing: true,
    };

    /*** Step process ***/
    $scope.enableNextStep = function nextStep() {
        //do not exceed into max step
        if ($scope.selectedStep >= $scope.maxStep) {
            return;
        }
        //do not increment $scope.stepProgress when submitting from previously completed step
        if ($scope.selectedStep === $scope.stepProgress - 1) {
            $scope.stepProgress = $scope.stepProgress + 1;
        }
        $scope.selectedStep = $scope.selectedStep + 1;
    }

    $scope.moveToPreviousStep = function moveToPreviousStep() {
        if ($scope.selectedStep > 0) {
            $scope.selectedStep = $scope.selectedStep - 1;
        }
    }

    $scope.submitCurrentStep = function submitCurrentStep(stepData, isSkip) {
        $scope.validateOnSubmit = true;
        var deferred = $q.defer();
        $scope.showBusyText = true;
        var stepvalue = $scope.stepProgress;
        console.log('On before submit');

        if ($scope.stepData[0].data != null || $scope.stepData[1].data != null || $scope.stepData[2].data != null) {
            if (stepvalue == 1) {
                if ($scope.useoutscope)
                    $scope.UpdateUploadmsgReq.UploadID = $scope.Selectedcampaignforuploaddata[0].ID
                else
                    $scope.UpdateUploadmsgReq.UploadID = $scope.stepData[0].data.selectedcamp.ID;
            }
            if (stepvalue == 2) {

                $scope.UploadVoiceCampaignRes.mobileNoField = $scope.stepData[1].data.mobileno;
                $scope.UploadVoiceCampaignRes.geographicalField = $scope.stepData[1].data.geographicalField;
                $scope.isMsg = true;
                $scope.stepData[2].data.Selected = "Message";
                var defLang = {}
                $scope.Languages.forEach(function (value, key) {
                    if (value.value = 'HIN') {
                        defLang = value;
                    }
                })
                $scope.stepData[2].data.messagelang = defLang.value;
            }
            if (stepvalue == 3) {

            }
        }

        if (!stepData.completed && !isSkip) {
            //simulate $http
            $timeout(function () {
                $scope.validateOnSubmit = false;
                $scope.showBusyText = false;
                console.log('On submit success');
                deferred.resolve({
                    status: 200,
                    statusText: 'success',
                    data: {}
                });
                //move to next step when success
                stepData.completed = true;
                $scope.enableNextStep();
            }, 1000)
        } else {
            $scope.validateOnSubmit = false;
            $scope.showBusyText = false;
            $scope.enableNextStep();
        }
    }
    /*** Step process ***/
    // ***** End of Upload Contact funcationality ***** //
    //***** Private Methods *****//
    $scope.ContactDataGrid.onRegisterApi = function (gridApi) {
        $scope.uploadContactGridApi = gridApi;
    };
    $scope.UploadContact = function (fileObj) {
        
        appFactory.ShowLoader();
        $scope.voiceuploadfile =  $('#contactfile')[0].files[0];
        if ($scope.disableCampaign) {
            $scope.stepData[0].data.selectedcamp = $scope.Selectedcampaignforuploaddata[0];
        }
        IsValidInputs();
        if ($scope.isValid == true) {
            var formData = new FormData();
            if ($scope.useoutscope) {
                formData.append("uploadID", angular.toJson($scope.Selectedcampaignforuploaddata[0].ID));
            } else {
                formData.append("uploadID", angular.toJson($scope.stepData[0].data.selectedcamp.ID));
            }
            formData.append("uploadDepID", $scope.stepData[0].data.selectedcamp.Department);
            formData.append("uploadedBy", userObj.SSOID);
            formData.append("CreateContactFile", $scope.voiceuploadfile);
            $scope.uploadedFileName = $scope.voiceuploadfile.name;
            campaignFactory.UploadContactFile(formData).then(function (data) {
                $scope.ContactDataGrid.data = null;
                $('#contactfile').replaceWith($('#contactfile').val('').clone(true));
                if (data.data != null & data.data != undefined) {
                    if (data.data.statusMessage = "Success") {
                        $scope.campaignUsage = data.data.campaignUsage[0];
                        $scope.campaignUsage.totalRecords = data.data.totalRecords;
                        // campaignUsage.TotalAvailableCount = 10;
                        $scope.isExceedsMaxAvailableCount = false;
                        if (!$scope.campaignUsage || ($scope.campaignUsage.TotalAvailableCount < ($scope.campaignUsage.TotalUsedCount + $scope.campaignUsage.totalRecords))) {
                            appFactory.showToasterErr('Exceeds Avaliable Count');
                            $scope.isExceedsMaxAvailableCount = true;
                            appFactory.HideLoader();
                            return;
                        }
                        $scope.UploadVoiceCampaignRes = data.data;
                        $scope.Isnotnull = true;
                        $scope.ContactDataGrid.data = [];
                        $scope.ContactDataGrid.columnDefs = [];
                        $scope.isfileupload = true;
                        $scope.ContactDataGrid.data = $scope.UploadVoiceCampaignRes.uploadSampleData;
                        if($scope.uploadContactGridApi){
                        $scope.uploadContactGridApi.core.notifyDataChange(uiGridConstants.dataChange.ALL);
                        }
                        $scope.voiceuploadfile = null;
                        $scope.validateOnSubmit  = false;
                        toaster.pop({
                            type: 'success',
                            body: "Contacts successfully uploaded",
                            bodyOutputType: 'trustedHtml'
                        });

                        angular.forEach($scope.UploadVoiceCampaignRes.CampaignHeaders, function (value, key) {
                            if (value.toLowerCase().search(/mob/) >= 0) {
                                $scope.stepData[1].data.mobileno = value;
                            } else if (value.toLowerCase().search(/geo/) >= 0 || value.toLowerCase().search(/loc/) >= 0) {
                                $scope.stepData[1].data.geographicalField = value;
                            }
                        })

                    } else {
                        $scope.Isnotnull = false;
                        $scope.isfileupload = false;
                        $scope.ContactDataGrid.data = null;
                        //$scope.UploadVoiceCampaignRes = null;
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading contacts",
                            bodyOutputType: 'trustedHtml'
                        });
                    }
                    appFactory.HideLoader();
                } else {
                    $scope.Isnotnull = false;
                    $scope.isfileupload = false;
                    $scope.ContactDataGrid.data = null;
                    //$scope.UploadVoiceCampaignRes = null;
                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading contacts",
                        bodyOutputType: 'trustedHtml'
                    });
                    appFactory.HideLoader();
                }  
            });
        }else{
            appFactory.HideLoader();
        }
    }
    $scope.UploadMessgae = function () {
        if ($scope.UploadVoiceCampaignRes.UploadID != null && $scope.UploadVoiceCampaignRes.UploadID != undefined) {
            $scope.UploadVoiceCampaignRes.isdemo = $rootScope.isDemo;
            $scope.UploadVoiceCampaignRes.uploadStatus = "READY";
            // $scope.UploadVoiceCampaignRes.uploadStatus = "INITIATED";
            $scope.UploadVoiceCampaignRes.messageLang = $scope.stepData[2].data.messagelang;
            campaignFactory.UpdateUploadContactFile($scope.UploadVoiceCampaignRes).then(function (data) {
                if (data.data != null & data.data != undefined) {
                    $scope.tab = 3;
                    $scope.campTabs(3);


                    if (data.data = "Success") {
                        setTimeout(function () {
                            $scope.campTabs(1);

                        }, 2000);
                        toaster.pop({
                            type: "success",
                            body: "Message File successfully uploaded"
                        });
                        $scope.stepData[2].data.messagedata = "";
                        $scope.isCompleted = true;
                        if ($scope.isCompleted == true) {
                            $scope.ValidateInsertMessage = false;
                            $('#uploadContacts').modal('hide');
                            $scope.clearcontrols();
                        }

                        // $scope.GetAllUploadList();
                    } else {
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading message file",
                            bodyOutputType: 'trustedHtml'
                        });
                        $scope.isCompleted = false;
                        $scope.stepData[2].data.messagedata = "";
                    }
                } else {
                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading message file",
                        bodyOutputType: 'trustedHtml'
                    });
                    $scope.isCompleted = false;
                }
            });
        }
    };
    $scope.sampleUploadGrid = {
        enableColumnResizing: true,
        enableColumnMenus: false,
        columnDefs: [{ name: 'Citizen Name', },
        { name: 'Mobile No', },
        { name: 'EmailID', },
        { name: 'Gender', },
        { name: 'District', }
        ]
    }
    $scope.UploadAudioFile = function () {
        if ($scope.isValid == true) {
            $scope.UploadVoiceCampaignRes.isdemo = $rootScope.isDemo;
            $scope.UploadVoiceCampaignRes.uploadStatus = "READY";
            var formData = new FormData();
            formData.append("UploadCampaignRes", angular.toJson($scope.UploadVoiceCampaignRes));
            formData.append("contactAudioFile", $scope.wavuploadfile);



            campaignFactory.UploadAudioFile(formData).then(function (data) {

                //


                if (data.data != null & data.data != undefined) {
                    if (data.data = "Success") {
                        toaster.pop({
                            type: "success",
                            body: "Audio file successfully uploaded",
                            bodyOutputType: 'trustedHtml'
                        });

                        angular.element(document.getElementById('wavfile'))[0].value = "";
                        $scope.wavuploadfile = null;
                        $scope.isCompleted = true;
                        $scope.isfileupload = true;
                        if ($scope.isCompleted == true) {
                            $scope.ValidateInsertMessage = false;
                            $('#uploadContacts').modal('hide');
                            $scope.clearcontrols();
                        }
                    } else {
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading audio",
                            bodyOutputType: 'trustedHtml'
                        });
                        $scope.isCompleted = false;
                        $scope.isfileupload = false;
                    }
                } else {

                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading audio",
                        bodyOutputType: 'trustedHtml'
                    });
                    $scope.isCompleted = false;
                    $scope.isfileupload = false;
                }
            });

        }
    }

    $scope.dynamicMsg = function (data) {
        var stepdata = data;
        var cursorPosition = $('#messagedata').prop("selectionStart");
        console.log(cursorPosition);
        var messagedata = "";
        if ($scope.stepData[2].data.messagedata == undefined) {
            $scope.stepData[2].data.messagedata = "";
            messagedata = $scope.stepData[2].data.messagedata;
        } else {
            messagedata = $scope.stepData[2].data.messagedata
        }
        var messageHeaders = $scope.stepData[2].data.messageheaders;
        if (messageHeaders == undefined)
            return;
        var template = ' {' + messageHeaders + '} ';

        var output = [messagedata.slice(0, cursorPosition), template, messagedata.slice(cursorPosition)].join('');
        $scope.stepData[2].data.messagedata = output;
    }

    var splitValues = function(value) {
        if (!value) {
            return;
        }
        var splitedValues = [];
        var isMatchedStart = false;
        var values = "";
        for (var i = 0; i < value.length; i ++) {
            if (value[i] === '{') {
                isMatchedStart = true;
            }
            if (value[i] === '}') {
                isMatchedStart = false;
                splitedValues.push(values);
                values = "";
            }
            if (isMatchedStart) {
                if ((value[i] !== '{') && (value[i] !== '}')) {
                    values = values + value[i];
                }
            }
        }
        return splitedValues;
    }

    $scope.InsertMessage = function () {

     $scope.ValidateInsertMessage = true;
        $scope.wordCheck = true;
        var words = $scope.stepData[2].data.messagedata;
        var splittedValues = splitValues(words);
        var isValueNotMatched = false;
        if (splittedValues && splittedValues.length) {
            splittedValues.forEach(function(val) {
                var indexOfExisting = _.indexOf($scope.UploadVoiceCampaignRes.CampaignHeaders, val);
                if (indexOfExisting < 0) {
                    isValueNotMatched = true;
                }
            })
        }
        if (isValueNotMatched) {
            appFactory.showToasterErr('Invalid template');
            return;
        }
        var arr = words.split(" ");
        //    var arr =  arrword.value.split(",", 2);
        $scope.wrongWords = [];

        arr.forEach(function (value, key) {

            $scope.abusiveWords.forEach(function (data) {
                if (data && data.InvalidWord && value) {
                    var dbword = data.InvalidWord.toLowerCase();
                    var enteredWord = value.toLowerCase();
                    if (enteredWord == dbword) {
                        $scope.wordCheck = false;
                       
                        $scope.wrongWords.push(value);
                    }
                }
            })
        });


        if ($scope.wordCheck) {
            if (!($scope.stepData[1].data.mobileno ||  !$scope.UploadVoiceCampaignRes.mobileNoField )) {
                toaster.pop({
                    type: "error",
                    body: "Please select proper mapping in step2",
                    bodyOutputType: 'trustedHtml'
                });

            } else {
                isValidUploadContactInputs();
                if (!$scope.isValid) {
                    return;
                }
                if ($scope.stepData[2].data.Selected === 'Message') {
                    $scope.UploadVoiceCampaignRes.messageTempalte = $scope.stepData[2].data.messagedata;
                    if ($scope.UploadVoiceCampaignRes != null && $scope.UploadVoiceCampaignRes != undefined) {
                        $scope.UploadMessgae();
                    }
                } else {
                    $scope.UploadAudioFile();
                }
            }

        } else {
            toaster.pop({
                type: "warning",
                body: "The message content should not contain the below mensioned words",
                bodyOutputType: 'trustedHtml'
            });
        }
    }


    var IsValidInputs = function () {
        $scope.isValid = '';     
        var msgFileUpload = '';
        $scope.validateOnSubmit = false;
        if (!$scope.useoutscope && ($scope.stepData[0].data.selectedcamp == undefined || $scope.stepData[0].data.selectedcamp == null ||
            $scope.stepData[0].data.selectedcamp.ID == "0")) {
            $scope.validateOnSubmit  = true;
            // toaster.pop({
            //     type: "error",
            //     body: "Please select valid campaign",
            //     bodyOutputType: 'trustedHtml'
            // });
          
            $scope.isValid = false;
        }
        if ($scope.voiceuploadfile === null) {
            $scope.validateOnSubmit  = true;
            // toaster.pop({
            //     type: "warning",
            //     body: "File already uploaded",
            //     bodyOutputType: 'trustedHtml'
            // });
            msgFileUpload = "File already uploaded";
            $scope.isValid = false;
        } else if (!$scope.voiceuploadfile || !$scope.voiceuploadfile.name) {
            $scope.validateOnSubmit  = true;
            // toaster.pop({
            //     type: "error",
            //     body: "Please select valid file to upload"
            // });
            msgFileUpload = "Please select valid file to upload";
            $scope.isValid = false;
        } else if ($scope.voiceuploadfile.name != null) {
         
            var validFormats = ['xls', 'xlsx', 'csv', 'txt'];
            var output = $filter('validfile')($scope.voiceuploadfile.name, validFormats);
            if (output == false) {
                $scope.validateOnSubmit  = true;
                // toaster.pop({
                //     type: "error",
                //     body: "File format should be xls,xlsx,csv & txt",
                //     bodyOutputType: 'trustedHtml'
                // });
                msgFileUpload = "File format should be xls,xlsx,csv & txt";
                $scope.isValid = false;
            } else {
                $scope.isValid = true;
            }
        } else {
            $scope.isValid = true;
        }
        $scope.inlineValidationMsg = msgFileUpload;
    }

    var isValidAudio = function () {
        var msgFileUpload = '';
        if (!$scope.wavuploadfile || !$scope.wavuploadfile.name) {
            $scope.ValidateInsertMessage  = true;
           
            // toaster.pop({
            //     type: "error",
            //     body: "Please select valid file to upload"
            // });
            msgFileUpload = "Please select valid file to upload";
            $scope.inlineValidationMsg = msgFileUpload;
            return false;
        }
       if ($scope.wavuploadfile.name != null) {
            $scope.ValidateInsertMessage  = true;
            var validFormats = ['wav'];
            var output = $filter('validfile')($scope.wavuploadfile.name, validFormats);
            if (output == false) {
                // toaster.pop({
                //     type: "error",
                //     body: "File format should be wav"
                // });
                msgFileUpload = "File format should be wav";
                $scope.inlineValidationMsg = msgFileUpload;
                return false;
            }
        }
        
        return true;
        
    };

    var isValidMsg = function () {
        if (!$scope.stepData[2].data.messagedata || !$scope.stepData[2].data.messagelang) {
            toaster.pop({
                type: "error",
                body: "Mandatory fields need to be filled"
            });
            return false;
        }
        return true;
    };
    var isValidUploadContactInputs = function () {
        $scope.isValid = true;
        if ($scope.stepData[2].data.Selected === 'Message') {
            $scope.isValid = isValidMsg();
        } else {
            $scope.isValid = isValidAudio();
        }
    };

    $scope.clearcontrols = function (isFromActiveCampaign) {

        $scope.stepperControlInit();
        clearSelectFileModel();
        $scope.ContactDataGrid.length = 0;
        $scope.ContactDataGrid.data = [];
        $scope.ContactDataGrid.data = null;
        $scope.Isnotnull = false;
        $scope.voiceuploadfile={};
        $scope.tab = $scope.tab;
        $scope.GetAllcampaignListContactupload(isFromActiveCampaign);
        $scope.GetAllUploadList();
        $scope.open = {};
        var d = new Date();
        d.setHours(0, 0, 0, 0);

        $scope.range = {
            startDate: d,
            endDate: new Date()
        };

    }

    $scope.checkstatus = function () {
        if ($scope.stepData[0].data != undefined && $scope.stepData[0].data != null) {
            var selectedcampaign = $scope.stepData[0].data.selectedcamp.CampaignName;
            var status = $filter('getCampStatus')(selectedcampaign, $rootScope.allCampaignList);
            if (status == 'STOPPED') {

                angular.element(document.getElementById('contactupload'))[0].disabled = true;
                angular.element(document.getElementById('contactfile'))[0].disabled = true;
                toaster.pop({
                    type: "info",
                    body: "Campaign is in stopped mode,so unable to upload contacts",
                    bodyOutputType: 'trustedHtml'
                });
            } else {
                angular.element(document.getElementById('contactupload'))[0].disabled = false;
                angular.element(document.getElementById('contactfile'))[0].disabled = false;
            }
        }
    }
    $scope.checkMsgTypes = function (msgtypes, val) {
        if (msgtypes == "Message") {
            $scope.isMsg = true;
            $scope.isAudio = false;
            $scope.wavuploadfile = null;

        } else if (msgtypes == "Audio") {
            $scope.isMsg = false;
            $scope.isAudio = true;
            $scope.stepData[2].data.messagedata = "";
        }
    }



    $scope.stepperControlInit = function () {
        $scope.selectedStep = 0;
        $scope.stepProgress = 1;
        $scope.maxStep = 3;
        $scope.showBusyText = false;
        $scope.stepData = [{ step: 1, completed: false, optional: false, data: {} },
        { step: 2, completed: false, optional: false, data: {} },
        { step: 3, completed: false, optional: false, data: {} }
        ];
    }

    $scope.onTypeSearchValues = function (searchIndex) {
        if (searchIndex !== undefined) {
            $scope.searchIndex = searchIndex;
        }
        var filteredData = appFactory.getDataBySearchIndex($scope.searchIndex);
        if ($scope.tab == 1) {
            $scope.ActiveCampaignGrid.data = filteredData;
        } else if ($scope.tab == 2) {
            $scope.CampaignGrid.data = filteredData;
        } else {
            $scope.ContactDetailsGrid.data = filteredData;
        }
    };

    var getSearchableFields = function (gridConfig) {
        appFactory.getSearchableFields(gridConfig);
    };

    var getDepartments = function () {
        if (appFactory.rights.type !== appConst.RIGHTS_TYPES.SUPER_ADMIN) {
            return;
        }
        profileFactory.GetAllDepartment().then(
            function success(data) {
                $scope.Departments = data.data;
                $scope.withoutdata = _.findWhere($scope.Departments, {
                    DepartmentName: "Generic"
                })

                $scope.Departments = _.without($scope.Departments, $scope.withoutdata)
            },
            function error(data) { }
        );
    };

    var clearSelectFileModel = function () {
        appFactory.clearFileModel();
    };


    // $('#addCampaigns').on('shown.bs.modal', function (e) {
    //      $(this).find('form[data-toggle=validator]').validator('destroy');
    //       $(this).find('form[data-toggle=validator]').validator()
    //      });


    var init = function () {
        resetcalender();
        $scope.GetAllCampaignbyDept();
        $scope.GetAllCampaignList();
        //  $scope.GetAllcampaignListContactupload();
        getDepartments();
    };
    var calltimeout = function () {
        window.setTimeout(function () {
            $(window).resize();
            $(window).resize();
        }, 1000);
    };
    init();
    //end region
}]);