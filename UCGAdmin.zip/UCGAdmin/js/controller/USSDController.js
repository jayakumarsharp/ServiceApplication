app.controller('USSDController',['$scope','$rootScope','$q','$timeout','$http','$filter','toaster','campaignFactory', function ($scope, $rootScope, $q, $timeout, $http, $filter, toaster, campaignFactory) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId;
    //* Private Variable declaration  */
    $scope.selectedStep = 0;
    $scope.stepProgress = 1;
    $scope.maxStep = 2;
    $scope.showBusyText = false;
    $scope.stepData = [{
            step: 1,
            completed: false,
            optional: false,
            data: {}
        },
        {
            step: 2,
            completed: false,
            optional: false,
            data: {}
        },


    ];

    $scope.UploadVoiceCampaignReq = {};
    $scope.UploadVoiceCampaignRes = [];
    $scope.uploadStatusInfo = [];

    $scope.UpdateUploadmsgReq = {};

    $scope.isfileupload = false;
    $scope.Isnotnull = false;

    //$rootScope.departmentName = "8";
    $rootScope.isDemo = false;
    $scope.CampaignListByDept = {};

    // ***** Start of Upload Contact funcationality ***** //

    // var statusTemplate = '<div>{{COL_FIELD == "READY" ? "'<div><i class="fa fa-{{COL_FIELD}}"></i></div>'" : (COL_FIELD == "FILE_UPLOADED" ? "FU"  : "Deleted")}}</div>';

    $scope.ContactDetailsGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'USSD',
                field: 'campaignName'
            },
            {
                name: 'File Name',
                field: 'FileName'
            },
            {
                name: 'Uploaded Date',
                field: 'UploadedDate',
                cellFilter: 'date:"dd/MM/yyyy HH:mm"'
            },
            {
                name: 'Total Records',
                field: 'TotalRecords'
            },
            // {
            //     name: 'Upload Status', field: 'UploadStatus',
            //     cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
            //         //var value=grid.getCellValue(row, col);
            //         if (grid.getCellValue(row, col) == "READY") {
            //             return 'Ready';
            //         }
            //         else if (grid.getCellValue(row, col) == "FILE_UPLOADED") {
            //             return 'FileUpload';
            //         }
            //         else if (grid.getCellValue(row, col) == "WAITING") {
            //             return 'Waiting'
            //         }
            //         else if (grid.getCellValue(row, col) == "UPLOADING") {
            //             return 'Uploading'
            //         }
            //     },
            //     cellTemplate:
            //     '<div class="upload-status" ng-if="row.entity.UploadStatus === \'READY\'"><i class="fa fa fa-check"></i><span>READY</span></div><div class="upload-status"  ng-if="row.entity.UploadStatus === \'FILE_UPLOADED\'"><i class="fa fa-upload"></i><span>FILE UPLOADED</span></div><div class="upload-status"  ng-if="row.entity.UploadStatus === \'WAITING\'"><i class="fa fa-exclamation-circle"></i><span>WAITING</span></div><div class="upload-status"  ng-if="row.entity.UploadStatus === \'UPLOADING\'"><i class="fa fa-spinner"></i><span>UPLOADING</span></div>'



            // },
            {
                name: 'Options',
                enableSorting: false,
                width: '10%',
                cellTemplate: '<a href="#" class="action-status" ng-click="grid.appScope.showUploadStatus(row.entity)"> <span class="fa fa-eye" title="View Status"></span></a> '
                // | <a href="#" class="action-status" ng-click="grid.appScope.showDemoTemplate(row.entity)"> <span class="fa fa-chevron-circle-right" title="Demo View"></span></a>'
            },
        ]
    };





    $scope.GetAllcampaignList = function () {
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {

            campaignFactory.GetAllCampaignList($rootScope.departmentName).then(function (data) {
                //
                


                if (data.data != null && data.data != undefined) {
                    $rootScope.allCampaignList = data.data;
                } else {

                    $rootScope.allCampaignList = null;

                }
            });
        }

    }

    $scope.GetAllUploadList = function () {
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {

            campaignFactory.GetAllUploadList($rootScope.departmentName).then(function (data) {
                //
                

                if (data.data != null && data.data != undefined) {

                    $scope.ContactDetailsGrid.data = _.filter(data.data, function (rowdata) {
                        return rowdata.IsDemo == false
                    });

                } else {
                    $scope.ContactDetailsGrid.data = null;

                }
            });
        }

    }

    // $scope.GetAllCampaignbyDept = function () {
    //     if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {


    //         campaignFactory.GetAllCampaignbyDept($rootScope.departmentName).then(function (data) {
    //             
    //             


    //             if (data.data != null && data.data != undefined) {
    //                 $scope.CampaignListByDept = data.data;
    //             }
    //             else {

    //                 $scope.CampaignListByDept = null;

    //             }
    //         });
    //     }
    // }
    $scope.GetAllcampaignList();
    // $scope.GetAllCampaignbyDept();
    $scope.GetAllUploadList();

    $scope.showUpload = function () {

        $scope.clearcontrols();
        $rootScope.isDemo = false;
        // $scope.UploadVoiceCampaignRes.isdemo=false;
        $('#uploadUSSDContacts').modal('show');
        console.log("hello");

    }
    $scope.showDemoTemplate = function (getrowdata) {
        $scope.clearcontrols();
        $rootScope.isDemo = true;
        $scope.stepData[0].data.selectedcamp = getrowdata.campaignName;
        // $scope.UploadVoiceCampaignRes.isdemo=true;
        $('#uploadContacts').modal('show');
    }

    $scope.showUploadStatus = function (getrowdata) {

        $scope.actionCampaigns = {};
        $scope.actionCampaigns.departmentID = $rootScope.departmentName;
        // $scope.actionCampaigns.campaignName = getrowdata.CampaignId;
        $scope.actionCampaigns.campaignName = getrowdata.CampaignId;
        // $scope.actionCampaigns.GroupName =getrowdata.CampaignGroup;
        $scope.actionCampaigns.GroupName = "Collections";

        campaignFactory.GetDetailUploadStatus($scope.actionCampaigns).then(function (data) {
            // 
            // 

            if (data.statusText == 'OK') {

                $('#detailsContactInfo').modal('show');
                $scope.upInfo = JSON.parse(data.data);
                $scope.uploadStatusInfo = $scope.upInfo.ListEnhancementDetails;

                console.log($scope.uploadStatusInfo);

                // for (i = 0; i < $scope.uploadStatusInfo.ListEnhancementDetails.length; i++) {
                //     console.log("hai",$scope.uploadStatusInfo.ListEnhancementDetails.UploadHistoryDetails);
                // for (j = 0; j < $scope.uploadStatusInfo.ListEnhancementDetails.UploadHistoryDetails.length; j++) {
                //    console.log("hai",$scope.uploadStatusInfo.ListEnhancementDetails.UploadHistoryDetails);
                //    console.log("hai",$scope.uploadStatusInfo.ListEnhancementDetails.UploadHistoryDetails.CampaignGroupID);
                // }

                // }
            } else {
                toaster.pop({
                    type: "error",
                    body: "Error while selecting uploaded details",
                    bodyOutputType: 'trustedHtml'
                });

            }
        });

    }





    $scope.ContactDataGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        // columnDefs: [
        //     { name: 'File Name', field: 'Name' },
        //     { name: 'Address', field: 'Address' },
        //     { name: 'Company', field: 'Company' },
        //     { name: 'Mobile', field: 'Mobile' },
        // ]
    };


    /*** Step process ***/

    $scope.enableNextStep = function nextStep() {
        //do not exceed into max step
        if ($scope.selectedStep >= $scope.maxStep) {
            return;
        }
        //do not increment $scope.stepProgress when submitting from previously completed step
        if ($scope.selectedStep === $scope.stepProgress - 1) {
            $scope.stepProgress = $scope.stepProgress + 1;
        }
        $scope.selectedStep = $scope.selectedStep + 1;
    }

    $scope.moveToPreviousStep = function moveToPreviousStep() {
        if ($scope.selectedStep > 0) {
            $scope.selectedStep = $scope.selectedStep - 1;
        }
    }

    $scope.submitCurrentStep = function submitCurrentStep(stepData, isSkip) {
        var deferred = $q.defer();
        $scope.showBusyText = true;
        var stepvalue = $scope.stepProgress;
        console.log('On before submit');

        if ($scope.stepData[0].data != null || $scope.stepData[1].data != null || $scope.stepData[2].data != null) {
            if (stepvalue == 1) {
                $scope.UpdateUploadmsgReq.UploadID = $scope.stepData[0].data.selectedcamp.ID;
            }
            if (stepvalue == 2) {

                $scope.UploadVoiceCampaignRes.mobileNoField = $scope.stepData[1].data.mobileno;
                $scope.UploadVoiceCampaignRes.geographicalField = $scope.stepData[1].data.geographicalField;


                // $scope.UpdateUploadmsgReq.mobileNoField = $scope.stepData[1].data.mobileno;
                // $scope.UpdateUploadmsgReq.uploadedBy = 'testuser';
                // $scope.UpdateUploadmsgReq.geoGraphicalField = $scope.stepData[1].data.geographicalField;
                $scope.isMsg = true;
                $scope.stepData[2].data.Selected = "Message";
            }
            if (stepvalue == 3) {

            }
        }

        if (!stepData.completed && !isSkip) {
            //simulate $http
            $timeout(function () {
                $scope.showBusyText = false;
                console.log('On submit success');
                deferred.resolve({
                    status: 200,
                    statusText: 'success',
                    data: {}
                });
                //move to next step when success
                stepData.completed = true;
                $scope.enableNextStep();
            }, 1000)
        } else {
            $scope.showBusyText = false;
            $scope.enableNextStep();
        }
    }

    /*** Step process ***/

    // ***** End of Upload Contact funcationality ***** //


    //***** Private Methods *****//

    $scope.UploadContact = function () {

        IsValidInputs();
        if ($scope.isValid == true) {
            var formData = new FormData();

            formData.append("uploadID", angular.toJson($scope.stepData[0].data.selectedcamp.ID));
            formData.append("uploadedBy", 'testuser');
            formData.append("CreateContactFile", $scope.voiceuploadfile);

            campaignFactory.UploadContactFile(formData).then(function (data) {
                $scope.ContactDataGrid.data = null;

                //
                

                if (data.data != null & data.data != undefined) {
                    if (data.data.statusMessage = "Success") {
                        $scope.UploadVoiceCampaignRes = data.data;
                        $scope.Isnotnull = true;
                        $scope.isfileupload = true;
                        $scope.ContactDataGrid.data = $scope.UploadVoiceCampaignRes.uploadSampleData;
                        toaster.pop({
                            type: 'success',
                            body: "Contacts successfully uploaded",
                            bodyOutputType: 'trustedHtml'
                        });
                    } else {
                        $scope.Isnotnull = false;
                        $scope.isfileupload = false;
                        $scope.ContactDataGrid.data = null;
                        //$scope.UploadVoiceCampaignRes = null;
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading contacts",
                            bodyOutputType: 'trustedHtml'
                        });
                    }


                } else {
                    $scope.Isnotnull = false;
                    $scope.isfileupload = false;
                    $scope.ContactDataGrid.data = null;
                    //$scope.UploadVoiceCampaignRes = null;
                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading contacts",
                        bodyOutputType: 'trustedHtml'
                    });
                }
            });
        }


    }


    $scope.UploadMessgae = function () {

        if ($scope.UploadVoiceCampaignRes.UploadID != null && $scope.UploadVoiceCampaignRes.UploadID != undefined) {
            $scope.UploadVoiceCampaignRes.isdemo = $rootScope.isDemo;
            campaignFactory.UpdateUploadContactFile($scope.UploadVoiceCampaignRes).then(function (data) {
                //

                if (data.data != null & data.data != undefined) {
                    if (data.data = "Success") {
                        toaster.pop({
                            type: "success",
                            body: "Message File successfully uploaded",
                            bodyOutputType: 'trustedHtml'
                        });
                        $scope.stepData[2].data.messagedata = "";
                        $scope.isCompleted = true;

                    } else {
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading message file",
                            bodyOutputType: 'trustedHtml'
                        });
                        $scope.isCompleted = false;
                        $scope.stepData[2].data.messagedata = "";

                    }

                } else {
                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading message file",
                        bodyOutputType: 'trustedHtml'
                    });
                    $scope.isCompleted = false;
                }

            });
        }


        // if ($scope.UpdateUploadmsgReq.UploadID != null && $scope.UpdateUploadmsgReq.UploadID != undefined) {

        //     campaignFactory.UpdateUploadContactFile($scope.UpdateUploadmsgReq).then(function (data) {
        //         

        //         if (data.data != null & data.data != undefined) {
        //             if (data.data = "Success") {
        //                 toaster.pop({ type: "success", body: "Message File successfully uploaded" });
        //                 $scope.stepData[2].data.messagedata = "";
        //                 $scope.isCompleted = true;
        //             }
        //             else {
        //                 toaster.pop({ type: "error", body: "Failed while uploading message file" });
        //                 $scope.isCompleted = false;
        //             }

        //         }
        //         else {
        //             toaster.pop({ type: "error", body: "Failed while uploading message file" });
        //             $scope.isCompleted = false;
        //         }

        //     });
        // }

    }


    $scope.UploadAudioFile = function () {

        IsValidAudio();
        if ($scope.isValid == true) {
            $scope.UploadVoiceCampaignRes.isdemo = $rootScope.isDemo;
            var formData = new FormData();
            // formData.append("UploadID", angular.toJson($scope.stepData[0].data.selectedcamp.ID));
            // formData.append("isDemo", angular.toJson($rootScope.isDemo));
            // formData.append("uploadedBy", 'testuser');
            // formData.append("mobileNoField", angular.toJson($scope.stepData[1].data.mobileno));
            // formData.append("geoGraphicalField", angular.toJson($scope.stepData[1].data.geographicalField));
            formData.append("UploadCampaignRes", angular.toJson($scope.UploadVoiceCampaignRes));
            formData.append("contactAudioFile", $scope.wavuploadfile);



            campaignFactory.UploadAudioFile(formData).then(function (data) {

                //
                

                if (data.data != null & data.data != undefined) {
                    if (data.data = "Success") {
                        toaster.pop({
                            type: "success",
                            body: "Audio file successfully uploaded",
                            bodyOutputType: 'trustedHtml'
                        });

                        angular.element(document.getElementById('wavfile'))[0].value = "";
                        $scope.wavuploadfile = null;
                        $scope.isCompleted = true;
                        $scope.isfileupload = true;
                    } else {
                        toaster.pop({
                            type: "error",
                            body: "Failed while uploading audio",
                            bodyOutputType: 'trustedHtml'
                        });
                        $scope.isCompleted = false;
                        $scope.isfileupload = false;
                    }
                } else {

                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading audio",
                        bodyOutputType: 'trustedHtml'
                    });
                    $scope.isCompleted = false;
                    $scope.isfileupload = false;
                }
            });

        }
    }

    $scope.dynamicMsg = function (data) {
        var stepdata = data;
        var messagedata = "";
        if ($scope.stepData[2].data.messagedata == undefined) {
            $scope.stepData[2].data.messagedata = "";
            messagedata = $scope.stepData[2].data.messagedata;
        } else {
            messagedata = $scope.stepData[2].data.messagedata
        }
        var messageHeaders = $scope.stepData[2].data.messageheaders;
        var template = messagedata + ' {' + messageHeaders + '} ';
        $scope.stepData[2].data.messagedata = template;
    }

    $scope.InsertMessage = function () {
        IsValidMsg();
        if ($scope.isValid == true) {

            $scope.UploadVoiceCampaignRes.messageTempalte = $scope.stepData[2].data.messagedata;
            if ($scope.UploadVoiceCampaignRes != null && $scope.UploadVoiceCampaignRes != undefined) {
                $scope.UploadMessgae();
            }

            // $scope.UpdateUploadmsgReq.messageTempalte = $scope.stepData[2].data.messagedata;
            // if ($scope.UpdateUploadmsgReq != null && $scope.UpdateUploadmsgReq != undefined) {
            //     $scope.UploadMessgae();
            // }
        }
    }

    var IsValidInputs = function () {
        $scope.isValid = '';
        if ($scope.stepData[0].data.selectedcamp == undefined || $scope.stepData[0].data.selectedcamp == null ||
            $scope.stepData[0].data.selectedcamp.ID == "0") {
            toaster.pop({
                type: "error",
                body: "Please select valid campaign",
                bodyOutputType: 'trustedHtml'
            });
            $scope.isValid = false;
        } else if ($scope.voiceuploadfile == undefined || $scope.voiceuploadfile == null || $scope.voiceuploadfile.name == null) {
            toaster.pop({
                type: "error",
                body: "Please select valid file to upload",
                bodyOutputType: 'trustedHtml'
            });
            $scope.isValid = false;
        } else if ($scope.voiceuploadfile.name != null) {
            var validFormats = ['xls', 'xlsx', 'csv', 'txt'];
            var output = $filter('validfile')($scope.voiceuploadfile.name, validFormats);
            if (output == false) {
                toaster.pop({
                    type: "error",
                    body: "File format should be xls,xlsx,csv & txt",
                    bodyOutputType: 'trustedHtml'
                });
                $scope.isValid = false;
            } else {
                $scope.isValid = true;
            }
        } else {
            $scope.isValid = true;
        }
    }

    var IsValidAudio = function () {
        $scope.isValid = '';
        if ($scope.wavuploadfile == undefined || $scope.wavuploadfile == null || $scope.wavuploadfile.name == null) {
            toaster.pop({
                type: "error",
                body: "Please select valid file to upload",
                bodyOutputType: 'trustedHtml'
            });
            $scope.isValid = false;
        } else if ($scope.wavuploadfile.name != null) {
            // var validFormats = ['xls', 'xlsx','csv','txt'];
            var validFormats = ['wav'];
            var output = $filter('validfile')($scope.wavuploadfile.name, validFormats);
            if (output == false) {
                toaster.pop({
                    type: "error",
                    body: "File format should be wav",
                    bodyOutputType: 'trustedHtml'
                });
                $scope.isValid = false;
            } else {
                $scope.isValid = true;
            }
        } else {
            $scope.isValid = true;
        }
    }


    var IsValidMsg = function () {
        $scope.isValid = '';
        if ($scope.stepData[2].data.messagedata == undefined || $scope.stepData[2].data.messagedata == null ||
            $scope.stepData[2].data.messagedata == "") {
            toaster.pop({
                type: "error",
                body: "Please enter valid message format",
                bodyOutputType: 'trustedHtml'
            });
            $scope.isValid = false;
        } else {
            $scope.isValid = true;
        }
    }

    $scope.clearcontrols = function () {
        $scope.stepperControlInit();
        angular.element("input[type='file']").val(null);
        $scope.ContactDataGrid.length = 0;
        $scope.ContactDataGrid.data = [];
        $scope.ContactDataGrid.data = null;
        $scope.Isnotnull = false;
        $scope.GetAllcampaignList();
        $scope.GetAllUploadList();
    }
    $scope.checkstatus = function () {

        if ($scope.stepData[0].data != undefined && $scope.stepData[0].data != null) {
            var selectedcampaign = $scope.stepData[0].data.selectedcamp.CampaignName;
            var status = $filter('getCampStatus')(selectedcampaign, $rootScope.allCampaignList);
            if (status == 'STOPPED') {

                angular.element(document.getElementById('contactupload'))[0].disabled = true;
                angular.element(document.getElementById('contactfile'))[0].disabled = true;
                toaster.pop({
                    type: "info",
                    body: "Campaign is in stopped mode,so unable to upload contacts",
                    bodyOutputType: 'trustedHtml'
                });
            } else {
                angular.element(document.getElementById('contactupload'))[0].disabled = false;
                angular.element(document.getElementById('contactfile'))[0].disabled = false;
            }
        }

    }
    $scope.checkMsgTypes = function (msgtypes, val) {
        if (msgtypes == "Message") {
            $scope.isMsg = true;
            $scope.isAudio = false;
            // angular.element(document.getElementById('wavfile'))[0].value = "";
            angular.element(document.getElementById('btnaudiofile'))[0].disabled = true;

        } else if (msgtypes == "Audio") {

            $scope.isMsg = false;
            $scope.isAudio = true;
            angular.element(document.getElementById('btnaudiofile'))[0].disabled = false;
            $scope.stepData[2].data.messagedata = "";
            // if (angular.element(document.getElementById('wavfile'))[0].value != null) {
            //     angular.element(document.getElementById('btnaudiofile'))[0].disabled = false;
            // }
            // else {
            //     angular.element(document.getElementById('btnaudiofile'))[0].disabled = true;
            // }

        }
    }

    $scope.stepperControlInit = function () {
        $scope.selectedStep = 0;
        $scope.stepProgress = 1;
        $scope.maxStep = 3;
        $scope.showBusyText = false;
        $scope.stepData = [{
                step: 1,
                completed: false,
                optional: false,
                data: {}
            },
            {
                step: 2,
                completed: false,
                optional: false,
                data: {}
            },
            {
                step: 3,
                completed: false,
                optional: false,
                data: {}
            },

        ];
    }

    //***** End of Private Methods *****//

}]);