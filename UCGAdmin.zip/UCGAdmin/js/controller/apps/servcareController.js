app.controller('servcareController', ['$scope', 'applicationFactory', function ($scope, applicationFactory) {
    
    $scope.trimString = appConst.LINK_APP_R_NAME.SERVCARE;
    $scope.RoutingStatus = '';

    $scope.init = function () {
        $scope.careObj = {}

        var userObj;
        var roleArray;
        var role = '';
        var token;

        // var SSOIdRoles = '{"sAMAccountName":"ESANCHAR2.TEST","Roles":["MIS","AWS","MDCM","SMS","USSD","CRM","REALITYCHECK","OBD","INB","PROFILE5","PROFILE4","PROFILE3","PROFILE2","PROFILE1","CONFIGURATION","OUTBOUND","INBOUND","SUPERADMIN","ADMIN","RUMAP","SERVINTUIT DEV USER","SERVINTUIT SERV ADMIN"]}';

        if (sessionStorage.getItem('SSOUserDetails')) {
            userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
        }
        // Commented For Testing
        if (sessionStorage.getItem('SSOId')) {
            roleArray = JSON.parse(sessionStorage.getItem('SSOId'));
        }

        //Added for Testing
        // roleArray = JSON.parse(SSOIdRoles);

        if (sessionStorage.getItem('SSOToken')) {
            token = sessionStorage.getItem('SSOToken');
        }

        if (roleArray.Roles) {
            for (i = roleArray.Roles.length - 1; i >= 0; i--) {
                if (roleArray.Roles[i].startsWith($scope.trimString) && role == '') {
                    role = roleArray.Roles[i].substring($scope.trimString.length, roleArray.Roles[i].length);
                    // roleArray.Roles[i].substring(4,roleArray.Roles[i].length)
                }
            }
        }

        // if (role != '' && role != null && role != undefined) {

            $scope.careObj = {
                userId: userObj.SSOID,
                userName: userObj.displayName,
                roleType: role,
                accessToken: token,
                requestToken: stringGen(10) + token
            }


                    var receiver = document.getElementById("ServCare").contentWindow;

                    setTimeout(function () {

                    receiver.postMessage({
                        RajSSOToken: $scope.careObj.accessToken,
                        SSOID : userObj.SSOID,
                        UserRole: role
                    }, '*');
                } ,2000);

            // applicationFactory.routeSerIntuit($scope.careObj).then(
            //     function success(response) {

            //         var receiver = document.getElementById("ServIntuit").contentWindow;

            //         receiver.postMessage({
            //             RajSSOToken: $scope.careObj.accessToken,
            //             requestToken: $scope.careObj.requestToken
            //         }, '*');

            //         // window.location.href = appConst.LINK_APP_URL.SERVINTUIT;
            //         // window.open(appConst.LINK_APP_URL.SERVINTUIT);

            //         $scope.RoutingStatus = 'IVR Call Management will be open in new tab';
            //     },
            //     function error(response) {
            //         $scope.RoutingStatus = 'Technical failure Occured. Please try again later.';
            //     }
            // );
        // } else {
        //     $scope.RoutingStatus = 'You Dont have roles to access this page. Please contact Admin';
        // }


    }

    function stringGen(len) {
        var text = " ";

        var charset = "abcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < len; i++)
            text += charset.charAt(Math.floor(Math.random() * charset.length));

        return text;
    }

    $scope.init();

}]);