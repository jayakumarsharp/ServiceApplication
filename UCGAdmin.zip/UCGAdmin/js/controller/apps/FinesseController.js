app.controller('FinesseController', ['$scope', '$rootScope', '$http', function ($scope, $rootScope, $http) {

    $scope.RoutingStatus = '';

    $scope.init = function () {
        window.open(appConst.LINK_APP_URL.FINESSE);

        $scope.RoutingStatus = 'Finesse Agent Desktop will be open in new tab';
    }

    $scope.init();

}])