app.controller('TextFilterController', ['$scope', '$rootScope', 'masterDataFactory', 'toaster', function ($scope, $rootScope, masterDataFactory, toaster) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    // $rootScope.departmentName = userObj.departmentId;
    $rootScope.departmentName = "103";
    $scope.smsCodeEdit = [];
    $scope.Formlist = {};
    $scope.form = {};
    $scope.SmsCode = {};
    $scope.InvalidWords = {};

    $scope.abusiveWords = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
                name: 'S.No',
                enableSorting: false,
                width: '10%',
                enableFiltering: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            // { name: 'langID', field: 'LangID' },
            {
                name: 'invalidWords',
                field: 'InvalidWord',
				cellTooltip: true
            },
            {
                name: 'Options', enableSorting: false,
                width: '17%',
                enableFiltering: false,
                width: '10%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
            }
        ],
    };


    $scope.GetAbusiveWords = function () {
        masterDataFactory.GetInvalidWords().then(
            function success(response) {
                //  console.log("edit", data);
                $scope.abusiveWords.data = response.data;

            },
            function error(response) {
                toaster.pop({
                    type: "error",
                    body: "Error occured while retreiving the data"
                });

            }
        )
    }
    $scope.GetAbusiveWords();

    $scope.GetLanguageFormat = function () {
        masterDataFactory.GetLanguageFormat().then(
            function success(data) {

                // console.log("editSMS",data);
                $scope.DepartmentDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }
    $scope.GetLanguageFormat();



    $scope.showAdd = function () {
        $scope.Formlist = {};
        // $scope.form.AbuseWordAdd.invalidWord.$error.validationError = false;
        // $scope.form.AbuseWordAdd.$setPristine();
        $('#addAbusiveWords').modal('show');

    }


    $scope.CreateInvalidWord = function () {
        // $scope.validateserver($scope.Formlist.invalidWord);
        $scope.form.AbuseWordAdd.invalidWord.$error.validationError = false;
        angular.forEach($scope.abusiveWords.data, function (rowdata) {
            if (rowdata.invalidWord == $scope.Formlist.invalidWord) {
                $scope.form.AbuseWordAdd.invalidWord.$error.validationError = true;
            }
        });
        if ($scope.form.AbuseWordAdd.invalidWord.$error.validationError == false) {
            // $scope.SmsCodeAdd.ThresholdType = 2;

            $scope.InvalidWords.UpdatedBy = userObj.SSOID;
            // $scope.InvalidWords.UpdatedBy = "ESANCHAR2.TEST";
            $scope.InvalidWords.langID = $scope.Formlist.langID;
            $scope.InvalidWords.invalidWord = $scope.Formlist.invalidWord;
            masterDataFactory.CreateInvalidWord($scope.InvalidWords).then(function (data) {
                if (data.data == "Success") {
                    $scope.GetAbusiveWords();
                    $('#addAbusiveWords').modal('hide');
                    $scope.Formlist = {};
                    $scope.form.AbuseWordAdd.$setPristine();
                    toaster.pop({
                        type: "Success",
                        body: "Words added successfully"
                    });
                } else {
                    $scope.GetAbusiveWords();
                    toaster.pop({
                        type: "error",
                        body: "Error while adding words"
                    });

                }
            });
        }



    }

    $scope.showEdit = function (getRowData) {
        $scope.wordEdit = {};
        // console.log("edit2", getRowData);
        $scope.wordEdit.LangID = getRowData.LangID;
        $scope.wordEdit.invalidWords = getRowData.InvalidWord;
        $scope.wordEdit.Id = getRowData.ID;
        $scope.form.invalidWordModify.invalidWord.$error.validationError = false;
        //console.log("hello");
        $scope.EditView = true;
        $('#modifyAbusiveWord').modal('show');
    }

    $scope.UpdateInvalidWord = function () {

        $scope.form.invalidWordModify.invalidWord.$error.validationError = false;
        if ($scope.Urlvalidate != $scope.wordEdit.invalidWord) {
            angular.forEach($scope.abusiveWords.data, function (rowdata) {
                    if (rowdata.invalidWord == $scope.wordEdit.invalidWord) {
                        $scope.form.invalidWordModify.invalidWord.$error.validationError = true;
                    }
                }

            );
        }

        if ($scope.form.invalidWordModify.invalidWord.$error.validationError == false) {
            $scope.invalidWordUpdate = {};

            $scope.invalidWordUpdate.Id = $scope.wordEdit.Id;
            $scope.invalidWordUpdate.invalidWords = $scope.wordEdit.invalidWords;
            // $scope.invalidWordUpdate.Id = $scope.wordEdit.Id;
            masterDataFactory.UpdateInvalidWord($scope.invalidWordUpdate).then(function (data) {
                if (data.data == "Success") {
                    $scope.GetAbusiveWords();
                    $('#modifyAbusiveWord').modal('hide');
                    toaster.pop({
                        type: "Success",
                        body: "Word modified successfully"
                    });
                } else {
                    $scope.GetAbusiveWords();
                    toaster.pop({
                        type: "error",
                        body: "Error while Modifying Word"
                    });

                }
            });
        }

    }
    //Delete functionality
    $scope.showDelete = function (getRowData) {
        //$scope.ussdCodeDelete = {};
        $scope.CodeID = getRowData.ID;
        $scope.EditView = true;
        $('#confirmModal').modal('show');
    }

    $scope.Delete = function () {
        $scope.NuanceServerDelete = {};
        // var Id = $scope.CodeID;
        $scope.NuanceServerDelete.Id = $scope.CodeID;
        // $scope.NuanceServerDelete.UpdatedBy = userObj.SSOID;
        // $scope.NuanceServerDelete.UpdatedBy = "ESANCHAR2.TEST";
        masterDataFactory.DeleteInvalidWord($scope.NuanceServerDelete.Id).then(function (data) {
            // 
            // 
            if (data.data == "Success") {
                $scope.GetAbusiveWords();
                $('#confirmModal').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "The Word has been deleted successfully"
                });

            } else {
                $scope.GetAbusiveWords();
            }
        });

    }



}]);