app.controller('SurveyCampaignRetryController', ['$scope', '$rootScope', '$q', '$timeout', '$filter', 'toaster', 'surveyCampFactory', 'surveyFactory', '$compile', '_', 'appFactory', function ($scope, $rootScope, $q, $timeout, $filter, toaster, surveyCampFactory, surveyFactory, $compile, _, appFactory) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId;
    //$rootScope.departmentName = "103";
    // Global variable declarations
    $scope.Pendingresultdata = [];
    //  $scope.permissions = appFactory.permissions[appConst.MENUS.RCHK_MGMT.RCHK_APVL];
    // ***** Start of Campaign Index funcationality ***** //
    $scope.searchIndex = "";
    $scope.sampleSetting = {};
    $scope.showpending = true;
    $scope.SurveyRetryGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '6%',
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'ID',
                field: 'ID',
                visible: false
            },
            {
                name: 'CampaignName',
                field: 'CampaignDisplayName',
                isSearchable: true,
                // grouping: {
                //     groupPriority: 0
                // },
                // width: 100,
                // enableColumnMenu: false,
                cellTooltip: true
            },

            {
                name: 'SampleName',
                field: 'SampleName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Survey',
                field: 'QuestionSetName',
                isSearchable: true,
                cellTooltip: true
            },

            {
                name: 'TotalCount',
                field: 'TotalCount',
                // isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Email Outcome',
                field: 'SuccessEmailCount',
                // isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'IVR Calls Outcome',
                field: 'SuccessIVRCount',
                //    isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Manual Calls Outcome',
                field: 'SuccessManualCount',
                // isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'RetryCycle',
                field: 'RetryCycle',
                //isSearchable: true,
                cellTooltip: true

            },
            {
                name: 'Executed DateTime',
                field: 'CreatedDateTime',
				cellTooltip: true,
                cellFilter: 'date:\'dd-MM-yy HH:mm\''
            },
            {
                name: 'Action',
                enableSorting: false,
                width: '10%',

                //cellTemplate: '<div><input type="button" ng-show="grid.appScope.showpending" ng-click="grid.appScope.Approve(row.entity)" class="btn btn-primary"   style="float:left;width:30%;margin-right:10px" value="Approve" /><input type="button" ng-show="grid.appScope.showpending" ng-click="grid.appScope.Reject(row.entity)" class="btn btn-danger" style="float:left;width:20%;margin-right:10px" value="Reject" /><input type="button" ng-click="grid.appScope.getdatabyid(row.entity)" class="btn  btn-default" style="float:left;width:40%;margin-right:10px" value="View Questionset" />'
                // cellTemplate: '<a href="#" ng-click="grid.appScope.getdatabyid(row.entity)"><span class="fa fa-play-circle" title="Re-run Campaign"></span> <span ng-show="grid.appScope.showcompleted" class="fa fa-eye" title="Re-run Campaign"></span></a>'
                cellTemplate: '<a href="#" ng-if="row.entity.TotalCount>(row.entity.SuccessEmailCount+row.entity.SuccessIVRCount+row.entity.SuccessManualCount)" ng-click="grid.appScope.getdatabyid(row.entity)"><span class="fa fa-play-circle" title="Re-run Campaign"></span></a><span ng-if="!(row.entity.TotalCount>(row.entity.SuccessEmailCount+row.entity.SuccessIVRCount+row.entity.SuccessManualCount))" class="fa fa-play-circle" title="Re-run Campaign"></span> <span ng-show="grid.appScope.showcompleted" class="fa fa-eye" title="Re-run Campaign"></span>|<a  href="#" ng-click="grid.appScope.getdatabyidview(row.entity)"><span class="fa fa-eye"></span></a>'

            },
        ]
    };
    $scope.SurveyRetryGrid.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
    };

    $scope.onTypeSearchValues = function () {
        var filteredData = appFactory.getDataBySearchIndex($scope.searchIndex);
        $scope.SurveyRetryGrid.data = filteredData;
    };

    var getSearchableFields = function () {
        appFactory.getSearchableFields($scope.SurveyRetryGrid);
    };
    $scope.selectedtab = 0;
    $scope.getdatabyidview = function (item) {
        $scope.selectedtab = 0;
        surveyFactory.GetAllQuestionSetbyId(item.QuestiontypeID).then(function (data) {
            var result = data.data;
            $scope.item = result[0];
            $scope.item.Id = item.Id;
            $scope.item.Language = item.Language;
            $scope.item.IsAutomatedIVR = item.IsAutomatedIVR;
            $scope.item.IsManualCalling = item.IsManualCalling;
            $scope.item.IsEmailSurvey = item.IsEmailSurvey;
            $scope.item.SampleName = item.SampleName;
            $scope.item.SMSIntimateText = item.SMSIntimateText;
            $scope.item.SMSAcknowledgeText = item.SMSAcknowledgeText;
            $scope.item.TotalRecords = item.TotalRecords;
            $scope.item.DayIntervalBetweenEmailAttempts = item.DayIntervalBetweenEmailAttempts;
            $scope.item.HoursIntervalBetweenEmailAttempts = item.HoursIntervalBetweenEmailAttempts;
            $scope.item.DayIntervalBetweenManualAttempts = item.DayIntervalBetweenManualAttempts;
            $scope.item.NoOfManualCallCount = item.NoOfManualCallCount;
            $scope.item.Comments = item.Comments;
            $scope.item.ActionTakenDateTime = item.ActionTakenDateTime;
            $scope.item.ActionTakenby = item.ActionTakenby;
            $scope.item.CampaignCreatedDate = item.UpdatedDate;
            $scope.item.IsApproved = item.IsApproved;
            $scope.item.IsRejected = item.IsRejected;

            setTimeout(function () {
                changeCallFlow(result[0]);
            }, 500);
            if ($scope.item.PhraseType == "WAV") {
                $scope.item.ThanksMessage = $scope.item.ThanksMessage.split(':')[1];
                $scope.item.WelcomeMessage = $scope.item.WelcomeMessage.split(':')[1];
            }
            $scope.item.SurveyEndTime = moment(item.SurveyEndTime).format('DD/MM/YYYY HH:mm');
            $scope.item.SurveyStartTime = moment(item.SurveyStartTime).format('DD/MM/YYYY HH:mm');
            $scope.item.CampaignName = item.CampaignName;
            $scope.Qinfo = {
                TotalQuestions: $scope.item.NoOfQuestions
            };
            $scope.item.CreatedBy = item.CreatedBy;
            $scope.item.UpdatedTime = moment(item.CreatedTime).format('DD/MM/YYYY HH:mm');

           // $('#detailView').modal('show');

            surveyFactory.GetLCMCampaignInfo(item.CampaignName).then(function (lcmdata) {
                if (lcmdata.data.CreateCampaign) {
                    $scope.item.CampaignStartTime = moment(lcmdata.data.CreateCampaign.StartDate).format('DD/MM/YYYY HH:mm');
                    $scope.item.CampaignEndTime = moment(lcmdata.data.CreateCampaign.EndDate).format('DD/MM/YYYY HH:mm');
                }
                var endDate = moment(new Date());
                var dateDiffMin = endDate.diff($scope.item.CampaignEndTime, 'days');
                if ($scope.showpending) {
                    var currentDate = moment();
                    var endDateObj = moment(item.SurveyEndTime);
                    if (endDateObj.diff(currentDate) < 0) {
                        appFactory.showWarning('campaign date expired');
                    } else
                        $('#detailView').modal('show');
                } else
                    $('#detailView').modal('show');
            });
        });
      
    }

    function changeCallFlow(currFlow) {
        flowDataStore = [];
        $('#drawing').remove();
        if (currFlow.QuestionSetName != "--Select--") {
            if (currFlow.JSONData != '') {
                flowDataStore.push({
                    callTree: {},
                    FlowName: currFlow.QuestionSetName
                });
                flowDataStore[0].callTree = $.parseJSON(currFlow.JSONData);
            }
            $("div#tabs").append("<div class='container calltree' style='background: #fff;' id='drawing'/>");
            if (currFlow.JSONData != '')
                CallTree.loadMultipleFlows();
            CallTree.createContainers(currFlow);
        }
        triggerpageevent(0);
    }


    $scope.getdatabyid = function (item) {
        $scope.item = item;
        surveyFactory.GetLCMCampaignInfo(item.CampaignName).then(function (lcmdata) {
            if (lcmdata.data.CreateCampaign) {
                $scope.sampleSetting.campaignStartDate = moment(lcmdata.data.CreateCampaign.StartDate).format('DD/MM/YYYY HH:mm');
                $scope.sampleSetting.campaignEndDate = moment(lcmdata.data.CreateCampaign.EndDate).format('DD/MM/YYYY HH:mm');
                $scope.sampleSetting.startDate = lcmdata.data.CreateCampaign.StartDate;
                $scope.sampleSetting.endDate = lcmdata.data.CreateCampaign.EndDate;
                var endDate = moment(new Date());

                var dateDiffMin = endDate.diff($scope.sampleSetting.campaignEndDate, 'days');
                if (dateDiffMin >= 0)
                    $('#viewschedule').modal('show');
                else
                    appFactory.showWarning('campaign date expired');

            }
        });
    }

    $scope.GetAlldata = function () {
        surveyFactory.GetAllSurveyFailedContacts().then(function (data) {
            $scope.Pendingresultdata = data.data;
            $scope.showpending = false;
            $scope.showapproved = false;
            $scope.showcompleted = false;
            var pendingdata = _.filter($scope.Pendingresultdata, function (item) {
                return (item.Status == 'READY');
            })

            var data = pendingdata;
            if ($scope.isSuperIdmin) {
                $scope.Pendingresultdata = data;
            } else {
                $scope.Pendingresultdata = _.filter(data, function (item) {
                    return item.depid == $rootScope.departmentName;
                });
            }
            $scope.SurveyRetryGrid.data = $scope.Pendingresultdata;
            $scope.SurveyRetryGrid.grid.modifyRows($scope.Pendingresultdata);
            getSearchableFields();
            $scope.gridApi.core.refresh();
        });

    }

    var isValidNum = function (value) {
        if (!value || value <= 0) {
            return false;
        }
        return true;
    };

    $scope.refresh = function () {
        $scope.searchIndex = "";
        $scope.GetAlldata();
    }

    $scope.CreateRetrySchdule = function () {
        $scope.CreateSampleReq = {
            'surveyCampaignID': $scope.item.SurveyCampaignID,
            'sampleName': $scope.item.SampleName,
            'sampleType': $scope.item.QuestiontypeID,
            'surveyID': $scope.item.SurveyID,
            'sampleCondition': '',
            'existingSampleID': $scope.item.SampleId,
            'fileName': '',
            'totalRecords': $scope.item.FailureCount,
            'campaignFileName': '',
            'dataSourceType': 'RETRY',
            'uploadedBy': 'admin',
            'uploadDescription': 'test',
            'isDemo': false,
        }
        surveyCampFactory.CreateSample($scope.CreateSampleReq).then(function (data) {
            if (data.data != null & data.data != undefined) {
                if (data.data && data.data.length) {
                    createSampleSetting(data.data[0].sampleID);
                } else {
                    toaster.pop({
                        type: "error",
                        body: "Failed while uploading survey contact file",
                        bodyOutputType: 'trustedHtml'
                    });
                }

            } else {
                toaster.pop({
                    type: "error",
                    body: "Failed while uploading survey contact file",
                    bodyOutputType: 'trustedHtml'
                });
                $scope.isCompleted = false;
            }
        });
    }

    var createSampleSetting = function (sampleId) {
        var sampleSetting = createSetting(sampleId);
        $scope.GetAlldata();
        surveyCampFactory.createSampleSetting(sampleSetting).then(function (data) {
            $('#viewschedule').modal('hide');
            var updatedata = {
                ScheduleID: $scope.item.ScheduleID,
                RetryCycle: $scope.item.RetryCycle
            };
            surveyFactory.UpdateRetrySurveyCampaign(updatedata).then(function (data) {
                toaster.pop({
                    type: "success",
                    body: 'Contact rescheduled successfully'
                });
            });

            $scope.clearcontrols();

        });
    };
    $scope.clearcontrols = function () {
        $scope.item = {};
        $scope.sampleSetting = {};
    }
    var createSetting = function (sampleId) {
        var sampleSettingObj = $scope.sampleSetting;
        var sampleSetting = {};
        sampleSetting = {
            SampleId: sampleId,
            IsEmailSurvey: sampleSettingObj.isEmailSurvey,
            IsAutomatedIVR: sampleSettingObj.isAutomatedIVR,
            IsManualCalling: sampleSettingObj.isManualCalling,
            EmailNoOfTimes: 1,
            DayIntervalBetweenEmailAttempts: sampleSettingObj.intervalInDaysIVR,
            HoursIntervalBetweenEmailAttempts: sampleSettingObj.intervalInHoursIVR,
            NoOfAutomatedIVRCallCount: 1,
            NoOfManualCallCount: Number(sampleSettingObj.intervalInDays),
            IsSMSIntimate: sampleSettingObj.isSMSIntimate,
            SMSIntimateText: sampleSettingObj.smsIntimateText,
            IsSMSAcknowledge: sampleSettingObj.isSMSAcknowledge,
            SMSAcknowledgeText: sampleSettingObj.smsAcknowledgeText,
            IntimateTimeType: 'Schedule',
            ScheduleDuration: sampleSettingObj.scheduleDuration,
            SurveyStartTime: moment(sampleSettingObj.startDate).format('YYYY-MM-DD HH:mm:ss'),
            SurveyEndTime: moment(sampleSettingObj.endDate).format('YYYY-MM-DD HH:mm:ss'),
        }
        if (sampleSettingObj.isManualCalling && (sampleSettingObj.isAutomatedIVR || sampleSettingObj.isEmailSurvey)) {
            sampleSetting.DayIntervalBetweenManualAttempts = sampleSettingObj.daysInterval;
        }
        return sampleSetting;
    };


    $scope.sampleSetting = {
        startDate: new Date(),
        endDate: new Date()
    }

    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        e.preventDefault();
        e.stopPropagation();
        $scope.open = {};
        $scope.open[date] = true;
    };

    $scope.onFinishSurvey = function () {
        var isValidDates = $scope.isValidSampleSettingDates(true);
        var isValidSetting = isValidSettings($scope.sampleSetting);
        if (!isValidSetting || !isValidDates) {
            return;
        }
        $scope.CreateRetrySchdule();
    };

    $scope.isValidSampleSettingDates = function () {
        var sampleSetting = $scope.sampleSetting;
        var isValidStartDate = appFactory.isWithInDate(sampleSetting.campaignStartDate, sampleSetting.startDate);
        var isValidEndDate = appFactory.isWithInDate(sampleSetting.campaignEndDate, sampleSetting.endDate, true);
        var isValidDates = appFactory.isValidStartAndEndDate(sampleSetting.startDate, sampleSetting.endDate);

        $scope.sampleSetting.inValidStartDate = !isValidStartDate;
        $scope.sampleSetting.inValidEndDate = !isValidEndDate;
        if (!isValidDates) {
            $scope.sampleSetting.inValidStartDate = true;
            $scope.sampleSetting.inValidEndDate = true;
        }
        if (!isValidStartDate || !isValidEndDate || !isValidDates) {
            $scope.campaignStartDate = moment(sampleSetting.campaignStartDate).format('DD/MM/YYYY');
            $scope.campaignEndDate = moment(sampleSetting.campaignEndDate).format('DD/MM/YYYY');
            return false;
        }
        return true;
    };

    var isValidSettings = function (sampleSetting) {
        var errMsg = ''
        if ($scope.item.QuestiontypeID == 1) {
            if (!sampleSetting.isManualCalling && !sampleSetting.isAutomatedIVR && !sampleSetting.isEmailSurvey) {
                errMsg = 'Please a select survey mode';
            } else {
                if (sampleSetting.isEmailSurvey && (sampleSetting.isManualCalling || sampleSetting.isAutomatedIVR)) {
                    var isValidNumber = true;
                    if (sampleSetting.isEmailSurvey && sampleSetting.isAutomatedIVR) {
                        isValidNumber = isValidNum(sampleSetting.intervalInDaysIVR);
                        isValidNumber = isValidNumber || (isValidNum(sampleSetting.intervalInHoursIVR));
                    }
                    if ((sampleSetting.isEmailSurvey && sampleSetting.isManualCalling) || (sampleSetting.isAutomatedIVR && sampleSetting.isManualCalling)) {
                        isValidNumber = isValidNumber && (isValidNum(sampleSetting.daysInterval) || sampleSetting.intervalInDays);
                    }
                    if (!isValidNumber) {
                        errMsg = 'Please enter valid interval in days';
                    } else {
                        if (sampleSetting.intervalInHoursIVR && sampleSetting.intervalInHoursIVR > 24) {
                            errMsg = 'Interval in hours with in 24 hours';
                        }
                        if (sampleSetting.isEmailSurvey && (sampleSetting.isManualCalling || sampleSetting.isAutomatedIVR)) {
                            var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.daysInterval);
                            if (!isValidInterval) {
                                errMsg = 'Interval in days with in start and end days';
                            }
                        }
                        if (sampleSetting.isEmailSurvey && sampleSetting.isAutomatedIVR) {
                            var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.intervalInDaysIVR);
                            if (!isValidInterval) {
                                errMsg = 'Interval in days with in start and end days';
                            }
                        }
                    }
                }
            }
        } else {
            if (!sampleSetting.isManualCalling && !sampleSetting.isEmailSurvey) {
                errMsg = 'Please a select survey mode';
            }
            if (sampleSetting.isManualCalling && sampleSetting.isEmailSurvey) {
                if (!sampleSetting.daysInterval && sampleSetting.intervalInDays < 0) {
                    errMsg = 'Please enter valid interval in days';
                } else {
                    var isValidInterval = isWithinGivenDates(sampleSetting.startDate, sampleSetting.endDate, sampleSetting.daysInterval);
                    if (!isValidInterval) {
                        errMsg = 'Interval in days with in start and end days';
                    }
                }
            }
        }


        if (sampleSetting.isSMSIntimate) {
            if (!sampleSetting.smsIntimateText) {
                errMsg = 'Please Fill SMS intimation text';
            }
            if (!sampleSetting.scheduleDuration) {
                errMsg = 'Please Fill Schedule Duration';
            } else if (sampleSetting.scheduleDuration > 24) {
                errMsg = 'Schedule Duration should be with in 24 hours';
            }
        }
        if (sampleSetting.isSMSAcknowledge && !sampleSetting.smsAcknowledgeText) {
            errMsg = 'Please Fill SMS Acknowledgement text';
        }
        if (errMsg) {
            toaster.pop({
                type: "error",
                body: errMsg
            });
            return false;
        }
        return true;
    };
    $scope.isSuperIdmin = false;
    $scope.isValidHours = function (hours, isDuration) {
        if (hours > 24) {
            hours = 24;
        } else if (hours < 0) {
            hours = 0;
        }
        if (isDuration) {
            $scope.sampleSetting.scheduleDuration = hours;
        } else {
            $scope.sampleSetting.intervalInHoursIVR = hours;
        }
    };
    var isWithinGivenDates = function (startDate, endDate, days) {
        var startDateObj = moment(startDate);
        var endDateObj = moment(endDate);
        if (endDateObj.diff(startDateObj, 'days') < days) {
            return false;
        }
        return true;
    };
    $scope.checkifsuperadmin = function () {
        if (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) {
            $scope.isSuperIdmin = true;
        } else
            $scope.isSuperIdmin = false;


        $scope.GetAlldata();

    }
    $scope.checkifsuperadmin();

    (function () {
        Array.prototype.last = function () {
            return this[this.length - 1];
        };
        Array.prototype.lastIdx = function () {
            return this.length - 1;
        };
        jsPlumb.ready(function () {
            CallTree = {
                sourceEndpoint: {
                    endpoint: "Dot",
                    paintStyle: {
                        strokeStyle: "#544e4e",
                        fillStyle: "transparent",
                        radius: 6,
                        lineWidth: 3
                    },
                    maxConnections: -1,
                    isSource: true,
                    connector: ["Flowchart", {
                        stub: [40, 60],
                        gap: 10,
                        cornerRadius: 3,
                        alwaysRespectStubs: false,
                    }],
                    connectorStyle: {
                        lineWidth: 2,
                        strokeStyle: "#544e4e",
                        joinstyle: "round"
                    },
                    hoverPaintStyle: {
                        fillStyle: "#544e4e",
                        strokeStyle: "#544e4e"
                    },
                    connectorHoverStyle: {
                        lineWidth: 3,
                        strokeStyle: "#544e4e"
                    },
                    dragOptions: {}
                },
                targetEndpoint: {
                    endpoint: "Dot",
                    paintStyle: {
                        fillStyle: "#544e4e",
                        radius: 8
                    },
                    hoverPaintStyle: {
                        fillStyle: "#544e4e",
                        strokeStyle: "#544e4e"
                    },
                    maxConnections: 9,
                    dropOptions: {
                        hoverClass: "hover",
                        activeClass: "active"
                    },
                    isTarget: true,
                },
                mainMenu: {},
                flowsContext: {},
                connectorNames: {},
                //entryConnectPoints: {},
                init: function (source) {
                    var that = this;
                    this.tabInstances = {};
                    this.loadModules();
                },
                loadMultipleFlows: function () {
                    var that = this;
                    for (var f = 0; f < flowDataStore.length; f++) {
                        var flowName = flowDataStore[f].flowName;
                        if (typeof flowDataStore[f].callTree != 'object' && flowDataStore[f].callTree != undefined && flowDataStore[f].callTree != '')
                            flowDataStore[f].callTree = $.parseJSON(flowDataStore[f].callTree);
                    }
                },
                createContainers: function (flowName) {
                    jsPlumb.reset();
                    jsPlumb.setContainer("drawing");
                    $scope.zoom = 0.6;
                    $scope.ZoomIn();
                    var that = this;
                    that.tabInstances = {};
                    var currFlow = flowName.QuestionSetName;
                    that.initTabSettings('drawing');
                    var isexist = !!_.where(flowDataStore, {
                        FlowName: flowName.QuestionSetName
                    }).length;
                    if (isexist) {
                        var seldata = _.where(flowDataStore, {
                            FlowName: flowName.QuestionSetName
                        });

                        that.loadCallTree(seldata[0].callTree.nodes);

                    } else {
                        if ($scope.redraw) {
                            flowDataStore.push({
                                callTree: {
                                    nodes: $scope.Redrawcalltree
                                },
                                FlowName: $scope.item.QuestionSetName
                            });
                            that.loadCallTree($scope.Redrawcalltree);

                        } else {
                            that.tabInstances = {};
                            that.initTabSettings('drawing');
                            var startNodeTopPosition = 1,
                                startNodeLeftPosition = 250;
                            var node = "";
                            var node = that.createNode({
                                id: 'StartFlowNode',
                                type: 'entryConnector',
                                value: 'Question Root',
                                NodeType: 'Option',
                                OptionVarients: '',
                            });
                            $compile(node)($scope);
                            $('#' + 'drawing').append(node);
                            that.tabInstances['drawing'].draggable(node);
                            flowDataStore.push({
                                "flowName": flowName.QuestionSetName,
                                "callTree": {
                                    "flowName": flowName.QuestionSetName,
                                    "nodes": [{
                                        "id": "StartFlowNode",
                                        "name": "StartFlowNode",
                                        "NodeType": 'Option',
                                        "type": "entryConnector",
                                        "nodeOptions": {},
                                        "element": {
                                            "id": "StartFlowNode",
                                            "left": startNodeLeftPosition,
                                            "position": startNodeTopPosition + ":" + startNodeLeftPosition,
                                            "sourceAnchor": "",
                                            "targetAnchor": "",
                                            "top": startNodeTopPosition
                                        }
                                    }],
                                }
                            });
                            node.css({
                                top: startNodeTopPosition,
                                left: startNodeLeftPosition
                            });
                            node.attr('data-node-position', startNodeTopPosition + ":" + startNodeLeftPosition);
                            node.attr('data-node-OptionVarients', '');
                            $(node).draggable({
                                stop: function (e, ui) {
                                    node.attr('data-node-position', ui.position.top + ":" + ui.position.left);
                                }
                            });

                            that.addEndPoints(node.attr('id'), node.attr('data-node-type'), that.tabInstances['drawing']);
                        }
                    }

                },
                initTabSettings: function (tabID) {
                    var that = this;
                    var tabInstance = jsPlumb.getInstance({
                        DragOptions: {
                            cursor: "pointer",
                            zIndex: 2000
                        },
                        Container: tabID,
                    });
                    tabInstance.bind("dblclick", function (connInfo) {
                        var r = confirm("Do you really want to delete!!");
                        if (r == true) {
                            var nodeId = connInfo.endpoints[1].getUuid();
                            tabInstance.detach(connInfo);
                        }
                    }); //here pharase ll be there additional
                    that.tabInstances["drawing"] = tabInstance;
                },
                loadModules: function (thisTabId) {
                    var that = this;
                    $('#modulesContainer .drag').each(function () {
                        $(this).draggable({
                            revert: 'invalid',
                            helper: 'clone',
                            connectToSortable: '.calltree',
                            tolerance: 'intersect'
                        });
                    });
                },
                createnodemanual: function (Source, type, OptionVarients) {
                    that = this;
                    var pos = Source.attributes['data-node-position'].nodeValue.split(':');
                    console.log(pos);
                    var child = getChildNode(Source.id);
                    var plusleftvalue = 0,
                        plustopvalue = 0;
                    if (type == "Option") {
                        if (child.length % 2 == 0) {
                            plusleftvalue = parseInt(pos[1]) - 100;
                            if (child.length == 0)
                                plustopvalue = parseInt(pos[0]) + 120;
                            else
                                plustopvalue = parseInt(pos[0]) + (120 * (child.length / 2 + 1));
                        } else {
                            plusleftvalue = parseInt(pos[1]) + 100;
                            if (child.length == 1)
                                plustopvalue = parseInt(pos[0]) + 120;
                            else
                                plustopvalue = parseInt(pos[0]) + (120 * Math.floor(child.length / 2 + 1));
                        }
                    } else {
                        plusleftvalue = parseInt(pos[1]);
                        plustopvalue = parseInt(pos[0]) + 120;
                    }
                    var nodeText = $scope.optionname,
                        nodeTopPosition = plustopvalue,
                        nodeLeftPosition = plusleftvalue;
                    // nodeTopPosition = parseInt(pos[0]) + 100,
                    // nodeLeftPosition = parseInt(pos[1]) + 100;

                    var node = that.createNode({
                        type: 'feature',
                        value: nodeText,
                        NodeType: type,
                        OptionVarients: OptionVarients,
                    });
                    $compile(node)($scope);
                    node.attr('data-node-position', nodeTopPosition + ":" + nodeLeftPosition);
                    nodeattributes = {
                        Nodename: '',
                        ObjQuestion: '',
                        QuestionType: 'TTS',
                        NodeType: type,
                        OptionVarients: OptionVarients,
                        InputType: 'Custom',
                        childnodes: '',
                        PromptFilename: '',
                        FileName: ''
                    }
                    node.attr("data-node-json", JSON.stringify(nodeattributes));
                    node.attr("data-node-OptionVarients", nodeattributes.OptionVarients);
                    document.getElementById("drawing").appendChild(node[0]);
                    node.css({
                        top: nodeTopPosition,
                        left: nodeLeftPosition
                    });
                    that.tabInstances["drawing"].draggable(node);
                    $(node).draggable({
                        stop: function (e, ui) {
                            node.attr('data-node-position', ui.position.top + ":" + ui.position.left);
                        }
                    });
                    that.addEndPoints(node.attr('id'), 'feature', that.tabInstances["drawing"]);
                    that.tabInstances["drawing"].connect({
                        uuids: ["endPoint-" + Source.id + "Bottom",
                            "endPoint-" + node.attr('id') + "Top"
                        ],
                    });
                    return node;
                },
                generateUniqueId: function (prefix) {
                    function rand() {
                        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
                    }
                    return prefix + '_' + rand() + rand() + '-' + rand() + '-' + rand();
                },
                addEndPoint: function (plumbInstance, nodeId, sourceAnchors, targetAnchors, nodeType) {
                    var sourceEndPoint = this.sourceEndpoint,
                        targetEndpoint = this.targetEndpoint;
                    if (typeof sourceAnchors == 'object') {
                        for (var i = 0; i < sourceAnchors.length; i++) {
                            var sourceUUID = 'endPoint-' + nodeId + sourceAnchors[i];
                            plumbInstance.addEndpoint(nodeId, sourceEndPoint, {
                                anchor: sourceAnchors[i],
                                uuid: sourceUUID,
                                connectionsDetachable: true,
                            });
                        }
                    }
                    if (typeof targetAnchors == 'object') {
                        for (var j = 0; j < targetAnchors.length; j++) {
                            var targetUUID = 'endPoint-' + nodeId + targetAnchors[j];
                            plumbInstance.addEndpoint(nodeId, targetEndpoint, {
                                anchor: targetAnchors[j],
                                uuid: targetUUID
                            });
                        }
                    }
                },
                addEndPoints: function (nodeId, nodeType, plumbInstance) {
                    if (nodeType === 'StartFlowNode' || nodeType === 'entryConnector') {
                        this.addEndPoint(plumbInstance, nodeId, ['Bottom'], [], nodeType);
                    } else {
                        this.addEndPoint(plumbInstance, nodeId, ['Bottom'], ['Top'], nodeType);
                    }
                },
                createNode: function (nodeData) {
                    var nodeId = nodeData.id || this.generateUniqueId(nodeData.type),
                        node = $('<div>'),
                        deleteIcon = $('<div class="deleteIconClick deleteIcon"> <i class="fa fa-trash-o" aria-hidden="true"></i>'),
                        nodeName = $('<p class="nodeName" style="word-wrap: break-word;">'),
                        EditIcon, ruleConfigIcon, CopyIcon = $('<div class="copyIcon" > <i class="fa fa-files-o" aria-hidden="true"></i>'),
                        PasteIcon = $('<div class="pasteIcon" ng-show="IscopyBuffer" > <i class="fa fa-clipboard" aria-hidden="true"></i>');
                    node.attr('id', nodeId);
                    node.addClass('draggableNode');
                    node.attr('data-node-type', nodeData.type);
                    node.attr('data-node-name', nodeData.value);
                    node.attr('data-node-OptionVarients', nodeData.OptionVarients);
                    node.addClass(nodeData.NodeType);
                    nodeName.text(nodeData.value);
                    nodeName.attr("title", nodeData.value);
                    EditIcon = $('<div id="FF_' + nodeId + '"  class="AddruleConfigIcon ruleConfigIcon"  title=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>');
                    ruleConfigIcon = $('<div id="R_' + nodeId + '"  class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>');
                    if (nodeId == "StartFlowNode") {
                        node.addClass('entryConnector');
                        node.append('<div class="questionIcon"> <i  class="fa fa-question" aria-hidden="true"></i>');
                        node.append(nodeName);
                        node.append(ruleConfigIcon); // add icon question
                        node.append(PasteIcon);
                    } else if (nodeData.NodeType == "Option") {
                        node.append(nodeName);
                        node.append(ruleConfigIcon); // add icon question
                        node.append(PasteIcon);
                    } else if (nodeData.NodeType == "Question" || nodeData.NodeType == "Thanks") {
                        node.append(nodeName);
                        node.append(EditIcon); //// add icon option
                        if ($scope.item.QuestionType == "Objective")
                            node.append('<div class="questionIcon questiontop"> <i class="fa fa-question" aria-hidden="true"></i>');
                        else if ($scope.item.QuestionType == "Subjective")
                            node.append($('<div id="R_' + nodeId + '"  class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>'));
                        else if ($scope.item.QuestionType == "Mixed") {
                            if ($scope.currentquestiontype == "Subjective")
                                node.append($('<div id="R_' + nodeId + '" class="featureConfigIcon" title="Rule Config" ><i class="fa fa-plus" aria-hidden="true"></i>'));
                            else
                                node.append('<div class="questionIcon questiontop"> <i class="fa fa-question" aria-hidden="true"></i>');
                        }
                        node.append(deleteIcon);
                        node.append(CopyIcon);

                    }
                    return node;
                },
                isNullOrEmpty: function (data) {
                    if (data === undefined || data === null || data === "") {
                        return true;
                    }
                    return false;
                },
                saveCallTree: function () {
                    var callTreeObj = {
                            "flowName": $scope.item.QuestionSetName,
                            "calltree": ""
                        },
                        calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    function getNextNodes(sourceId, nodeId, connection, legIdx) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;
                        if ($('#' + nodeId).attr('data-node-type') == 'feature') {
                            if ($('#' + sourceId).attr('data-node-type') == 'menu' || $('#' + sourceId).attr('data-node-type') == 'feature' || $('#' + sourceId).attr('data-node-type') == 'StartFlowNode' || $('#' + sourceId).attr('data-node-type') == 'entryConnector') {
                                if (connection != null) {
                                    targetAnchorId = connection.endpoints[1].getUuid();
                                    nodes.push({ // Create link node
                                        "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                        "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                        "type": "link",
                                        "element": {},
                                    });
                                }
                            }
                        } else {
                            if (connection != undefined) {
                                targetAnchorId = connection.endpoints[1].getUuid();
                                nodes.push({
                                    "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                    "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                    "type": "link",
                                    "element": {},
                                });
                            }
                        }
                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                "position": $('#' + nodeId).attr("data-node-position"),
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove')
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], null);
                                }
                            }
                            // i=0;
                        }
                    }
                    var tempEntryConnectorList = $(".calltree").find(".entryConnector"); // save StartFlowNode point
                    for (var i = 0; i < tempEntryConnectorList.length; i++) {
                        flowDataStore[0].mainMenu = tempEntryConnectorList[i].id;
                        getNextNodes(null, tempEntryConnectorList[i].id);

                    }
                    flowDataStore[0].callTree = calltree;
                    var postData = {
                        "flowName": '',
                        "callTree": {},
                    };
                    converttoIVR(flowDataStore[0].callTree, flowDataStore[0].mainMenu);

                },
                loadCallTree: function (nodesObj) {

                    $scope.AvailableNodeids = [];
                    if ($scope.redraw)
                        nodesObj = $scope.Redrawcalltree;
                    var rootnode = _.where(nodesObj, {
                        type: "entryConnector"
                    });

                    function getNextNodes(node) {
                        for (var t = 0; t < node.nodeOptions.childnodes.length; t++) {
                            var childnode = _.where(nodesObj, {
                                id: node.nodeOptions.childnodes[t].targetId
                            });
                            var isexist = !!_.where($scope.AvailableNodeids, {
                                Id: node.nodeOptions.childnodes[t].targetId
                            }).length;
                            if (isexist > 0) {
                                console.log('Already node detected stop');
                                this.CallTree.tabInstances["drawing"].connect({
                                    uuids: ["endPoint-" + node.id + "Bottom",
                                        "endPoint-" + childnode[0].element.id + "Top"
                                    ],
                                });
                                return;
                            } else {
                                $scope.AvailableNodeids.push({
                                    Id: childnode[0].id
                                });
                                this.CallTree.loadtree(childnode[0]);
                                getNextNodes(childnode[0]);
                            }
                        }
                        // i = 0;
                    }
                    $scope.AvailableNodeids.push({
                        Id: rootnode[0].id
                    });
                    this.loadtree(rootnode[0]);
                    getNextNodes(rootnode[0]);
                },
                loadtree: function (nodeObj) {
                    var that = this;
                    var nodePosition = nodeObj.element.position.split(":");
                    var nodeText = nodeObj.name;
                    if (nodeObj.type == "entryConnector") {
                        nodeText = CallTree.connectorNames[nodeObj.id] || "Question Root";
                    }

                    if (nodeObj.nodeOptions.QuestionType == "WAV") {
                        nodeText = nodeObj.nodeOptions.Nodename.split(':')[1];
                    }
                    $scope.currentquestiontype = nodeObj.nodeOptions.InputType;
                    newNode = that.createNode({
                        id: nodeObj.id,
                        type: nodeObj.type,
                        value: nodeText,
                        NodeType: nodeObj.nodeOptions.NodeType,
                        OptionVarients: nodeObj.nodeOptions.OptionVarients,
                    });
                    $('#drawing').append(newNode);
                    $compile(newNode)($scope);
                    newNode.css({
                        top: parseInt(nodePosition[0]),
                        left: parseInt(nodePosition[1])
                    });
                    newNode.attr("data-node-position", nodeObj.element.position);
                    newNode.attr("data-node-json", JSON.stringify(nodeObj.nodeOptions));
                    that.tabInstances["drawing"].draggable(newNode);
                    that.addEndPoints(nodeObj.id, nodeObj.type, that.tabInstances["drawing"]);
                    $(newNode).draggable({
                        stop: function (e, ui) {
                            console.log(e);
                            console.log(ui);
                            console.log(ui.position.top + ':' + ui.position.left);
                            var position = ui.position.top + ":" + ui.position.left;
                            $(e.target).attr({
                                "data-node-position": position
                            });
                        }
                    });
                    if (nodeObj.type == "entryConnector" && nodeObj.element.sourceAnchor == '' && nodeObj.element.targetAnchor != '') {
                        that.tabInstances["drawing"].connect({
                            uuids: ["endPoint-" + nodeObj.id + "Bottom",
                                nodeObj.element.targetAnchor
                            ],
                        });
                    } else if (nodeObj.element.sourceAnchor != '' || nodeObj.element.targetAnchor != '') {
                        that.tabInstances["drawing"].connect({
                            uuids: [nodeObj.element.sourceAnchor,
                                nodeObj.element.targetAnchor
                            ],
                        });
                    }
                },
                deleteNode: function (node) {
                    var nodeId = $(node).attr('id');
                    this.removeAllchildnode(nodeId);
                },
                deleteNodeManual: function (nodeId) {
                    this.removeAllchildnode(nodeId);
                },
                removeAllchildnode: function (nodeId) {
                    function getNextNodes(nodeId) {
                        var connections = this.CallTree.tabInstances["drawing"].getConnections({
                            source: nodeId
                        });
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove');
                            console.log(nodeId);
                            this.CallTree.deleteNodeGeneric(nodeId);
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    getNextNodes(connections[i].targetId);
                                }
                            }
                            console.log(nodeId);
                            this.CallTree.deleteNodeGeneric(nodeId);
                            i = 0;
                        }
                    }
                    getNextNodes(nodeId);
                },
                getAllchildnode: function (node) {
                    var calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    function getNextNodes(sourceId, nodeId, connection, legIdx) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;

                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                "position": $('#' + nodeId).attr("data-node-position"),
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove')
                            return;
                        } else {
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], null);
                                }
                            }
                            // i=0;
                        }
                    }
                    calltree.Copyroot = node.id;
                    getNextNodes(null, node.id);
                    $scope.CopyNodedata = calltree;
                    console.log($scope.CopyNodedata)

                },
                getquestionoptioncount: function () {
                    var callTreeObj = {
                            "flowName": $scope.item.QuestionSetName,
                            "calltree": ""
                        },
                        calltree = {
                            "flowName": $scope.item.QuestionSetName,
                            "nodes": []
                        },
                        instances = this.tabInstances,
                        source, target, sourceId, targetId;

                    var setcurentblock = true;
                    var arrayleveljson = [];
                    var instances = this.tabInstances,
                        source, target, sourceId, targetId;
                    var loopval = 0;

                    function getNextNodes(sourceId, nodeId, connection, loopvalue) {
                        var i = 0,
                            connections, nodes = [],
                            targetAnchorID;

                        nodes = calltree.nodes;
                        if ($('#' + nodeId).attr('data-node-type') == 'feature') {
                            if ($('#' + sourceId).attr('data-node-type') == 'menu' || $('#' + sourceId).attr('data-node-type') == 'feature' || $('#' + sourceId).attr('data-node-type') == 'StartFlowNode' || $('#' + sourceId).attr('data-node-type') == 'entryConnector') {
                                if (connection != null) {
                                    targetAnchorId = connection.endpoints[1].getUuid();
                                    nodes.push({ // Create link node
                                        "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                        "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                        "type": "link",
                                        "element": {},
                                    });
                                }
                            }
                        } else {
                            if (connection != undefined) {
                                targetAnchorId = connection.endpoints[1].getUuid();
                                nodes.push({
                                    "id": "endPoint-" + nodeId + "Top-Src-" + sourceId, // target anchor id
                                    "name": "endPoint-" + nodeId + "Top-Src-" + sourceId,
                                    "type": "link",
                                    "element": {},
                                });
                            }
                        }
                        var parsingdata = $('#' + nodeId).attr("data-node-json");
                        var nodeattributes = {};
                        if (typeof parsingdata != 'object' && parsingdata != undefined && parsingdata != '')
                            nodeattributes = $.parseJSON(parsingdata);
                        nodeattributes.childnodes = getChildNode(nodeId);
                        var poscalc = "20:160"
                        if (nodeId != "StartFlowNode")
                            poscalc = (loopvalue - 1) * 180 + ':' + (arrayleveljson[loopvalue - 1].question + arrayleveljson[loopvalue - 1].option) * 150;
                        nodes.push({
                            "id": nodeId,
                            "name": $('#' + nodeId).attr('data-node-name'),
                            "type": $('#' + nodeId).attr('data-node-type'),
                            "nodeOptions": nodeattributes,
                            "element": {
                                "id": nodeId,
                                // "position": $('#' + nodeId).attr("data-node-position"),
                                "position": poscalc,
                                "sourceAnchor": "",
                                "targetAnchor": ""
                            },
                            //"level": loopvalue - 1 + ':' + (arrayleveljson[loopvalue - 1].question + arrayleveljson[loopvalue - 1].option)
                        });
                        if (connection != null) {
                            nodes.last().element.sourceAnchor = connection.endpoints[0].getUuid();
                            nodes.last().element.targetAnchor = connection.endpoints[1].getUuid();
                        }
                        if (instances["drawing"] != undefined) {
                            connections = instances["drawing"].getConnections({
                                source: nodeId
                            });
                        }
                        if (connections != undefined && connections.length == 0) {
                            console.log('hitting here but exit connection remove');
                            --loopval;
                            return;
                        } else {
                            setcurentblock = true;
                            if (connections != undefined) {
                                for (i = 0; i < connections.length; i++) {
                                    if (setcurentblock) {
                                        var isexist = !!_.where(arrayleveljson, {
                                            level: loopvalue
                                        }).length;

                                        if (!isexist) {
                                            arrayleveljson.push({
                                                level: loopvalue,
                                                question: 0,
                                                option: 0
                                            });
                                        }
                                        if ($.parseJSON($('#' + connections[i].targetId).attr("data-node-json")).NodeType == "Question")
                                            arrayleveljson[loopvalue].question++;
                                        else
                                            arrayleveljson[loopvalue].option++;
                                        setcurentblock = false;
                                    } else {
                                        if ($.parseJSON($('#' + connections[i].targetId).attr("data-node-json")).NodeType == "Question")
                                            arrayleveljson[loopvalue].question++;
                                        else
                                            arrayleveljson[loopvalue].option++;
                                    }
                                    source = connections[i].source;
                                    target = connections[i].target;
                                    sourceId = source.id;
                                    targetId = target.id; // Change Leg
                                    getNextNodes(sourceId, targetId, connections[i], ++loopval);
                                }
                                --loopval;
                            }
                        }
                    }
                    arrayleveljson.push({
                        level: loopval,
                        question: 0,
                        option: 1
                    });

                    getNextNodes(null, 'StartFlowNode', null, ++loopval);
                    console.log('nodes');
                    console.log(arrayleveljson);
                    console.log(calltree.nodes);
                    $scope.Redrawcalltree = calltree.nodes;
                    //Redraw
                    $scope.redraw = true;
                    //this.loadCallTree(calltree.nodes);
                    changeCallFlow($scope.item);
                },
                deleteNodeGeneric: function (sourceId) {
                    this.tabInstances["drawing"].detachAllConnections(sourceId);
                    this.tabInstances["drawing"].removeAllEndpoints(sourceId);
                    delete this.connectorNames[sourceId];
                    $('#' + sourceId).remove();
                },
            };

            CallTree.init();
        });


    })(); //Jquery library ending here


    

    $scope.Redesign = function (event) {
        CallTree.getquestionoptioncount();
    }


    $scope.ZoomIn = function () {
        $scope.zoom = $scope.zoom + 0.3;
        var transformOrigin = [0.5, 0.5];

        var el = jsPlumb.getContainer();
        var p = ["webkit", "moz", "ms", "o"],
            s = "scale(" + $scope.zoom + ")",
            oString = (transformOrigin[0] * 100) + "% " + (transformOrigin[1] * 100) + "%";

        for (var i = 0; i < p.length; i++) {
            el.style[p[i] + "Transform"] = s;
            el.style[p[i] + "TransformOrigin"] = oString;
        }

        el.style["transform"] = s;
        el.style["transformOrigin"] = oString;


        ZoomProcess($scope.zoom);
        jsPlumb.setZoom($scope.zoom);
        $timeout(function () {
            triggerpageevent(1);
            jsPlumb.repaintEverything();
        }, 1000)
    }

    $scope.ZoomOut = function () {
        if ($scope.zoom > 0)
            $scope.zoom = $scope.zoom - 0.3;
        if ($scope.zoom > 0) {
            var transformOrigin = [0.5, 0.5];
            var el = jsPlumb.getContainer();
            var p = ["webkit", "moz", "ms", "o"],
                s = "scale(" + $scope.zoom + ")",
                oString = (transformOrigin[0] * 100) + "% " + (transformOrigin[1] * 100) + "%";
            for (var i = 0; i < p.length; i++) {
                el.style[p[i] + "Transform"] = s;
                el.style[p[i] + "TransformOrigin"] = oString;
            }
            el.style["transform"] = s;
            el.style["transformOrigin"] = oString;
            $timeout(function () {
                //ZoomProcess($scope.zoom)
                triggerpageevent(1);
                jsPlumb.repaintEverything();
            }, 1000)
            jsPlumb.setZoom($scope.zoom);
        }
    }
    function ZoomProcess(zoomvalue) {
        $("#drawing").css({
            "-webkit-transform": "scale(" + zoomvalue + ")",
            "-moz-transform": "scale(" + zoomvalue + ")",
            "-ms-transform": "scale(" + zoomvalue + ")",
            "-o-transform": "scale(" + zoomvalue + ")",
            "transform": "scale(" + zoomvalue + ")"
        });
    }
    function triggerpageevent(val) {
        $(window).resize(function () {
            //$('#mainContainer').height($(window).height() - 100);
            $('#drawing').height($(window).height() - 120);
            // $('.calltreeContainer').height($(window).height() - (200));
            //$('#featureConfig, .ruleConfig').height($(window).height() - 190);
        });
        $(window).trigger('resize');
    }


}]);