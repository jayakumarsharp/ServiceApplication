app.controller('CampaignApprovalController', ['$scope', '$rootScope', '$q', '$timeout', '$filter', 'toaster', 'campaignFactory', 'surveyFactory', '$compile', '_', 'appFactory', function ($scope, $rootScope, $q, $timeout, $filter, toaster, campaignFactory, surveyFactory, $compile, _, appFactory) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $('.modal-dialog .card').resizable().draggable();
    userObj = {
        SSOID: ''
    };
    //$rootScope.departmentName = userObj.departmentId;
    //$rootScope.departmentName = "103";
    // Global variable declarations
    $scope.Pendingresultdata = [];

    //$scope.permissions = appFactory.permissions[appConst.MENUS.RCHK_MGMT.RCHK_APVL];
    var newdate = new Date();
    newdate.setDate(newdate.getDate() - 30);
    $scope.ms = {
        startDate: newdate,
        // startDate: setImmediate(, 
        endDate: new Date()
    }

    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        $scope.open = {};
        e.preventDefault();
        e.stopPropagation();
        $scope.open[date] = true;
    };

    $scope.FilterData = function (type) {
        $scope.FilterDates = {};
        $scope.FilterDates.FromDate = moment($scope.ms.startDate).format('YYYY-MM-DD  00:00:00');
        $scope.FilterDates.EndDate = moment($scope.ms.endDate).format('YYYY-MM-DD 23:59:59');
        $scope.FilterDates.Type = type;
        campaignFactory.GetAllVoiceUploadFilter($scope.FilterDates).then(function (data) {
            console.log(data);
            if ($scope.isSuperIdmin) {
                $scope.Pendingresultdata = data.data;
            } else {
                $scope.Pendingresultdata = _.filter(data.data, function (item) {
                    return item.depid == $rootScope.departmentName;
                });
            }
            $scope.Pendingresultdata = $scope.Pendingresultdata;
            $scope.GetAlldata($scope.currentwindow);
        });
    }

    $scope.FilterData('INITIATED');

    // ***** Start of Campaign Index funcationality ***** //
    $scope.searchIndex = "";
    $scope.currentwindow = 1;
    $scope.PendingContactDetailsGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                enableSorting: false,
                width: '6%',
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'Id',
                field: 'id',
                visible: false
            },

            {
                name: 'Campaign',
                field: 'CampaignName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Department',
                field: 'DepartmentName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'FileName',
                field: 'FileName',
                isSearchable: true,
                cellTooltip: true
            },
            {
                name: 'Uploaded User',
                field: 'UploadedBy',
            },

            // {
            //     name: 'CreatedTime',
            //     field: 'CreatedTime',
            //     cellTooltip: true,
            //     cellFilter: 'date:"dd/MM/yyyy HH:mm"'
            // },
            {
                name: 'Action',
                width: '10%',
                enableSorting: false,
                cellTemplate: '<a ng-click="grid.appScope.getdatabyid(row.entity)"><span class="fa fa-eye"></span></a>'
            },
        ]
    };

    $scope.onTypeSearchValues = function () {
        var filteredData = appFactory.getDataBySearchIndex($scope.searchIndex);
        $scope.PendingContactDetailsGrid.data = filteredData;
    };

    var getSearchableFields = function () {
        appFactory.getSearchableFields($scope.PendingContactDetailsGrid);
    };
    $scope.PendingContactDetailsGrid.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
    };
    $scope.Approve = function (row) {
        if (row.Comments) {
            var pendingdata = {
                id: row.ID,
                approvedBy: userObj.SSOID,
                Comments: row.Comments,
                UploadId: row.ContactUploadedId,
                type: 'APPROVED'
            };
            campaignFactory.UpdateApprovalStatus(pendingdata).then(function (data) {
                $scope.FilterData();
                $('#viewcalltree').modal('hide');
                appFactory.showSuccess('Survey approved successfully');

            });
        } else
            appFactory.showWarning('Please enter comments');
    }
    $scope.Reject = function (row) {
        if (row.Comments) {
            var pendingdata = {
                id: row.ID,
                approvedBy: userObj.SSOID,
                Comments: row.Comments,
                UploadId: row.ContactUploadedId,
                type: 'REJECTED'
            };
            campaignFactory.UpdateApprovalStatus(pendingdata).then(function (data) {
                $scope.FilterData();
                $('#viewcalltree').modal('hide');
                appFactory.showSuccess('Survey rejected successfully');
            });
        } else
            appFactory.showWarning('Please enter comments');
    }

    $scope.refresh = function () {
        $scope.searchIndex = "";
        $scope.FilterData();
    }

    $scope.selectedtab = 0;
    $scope.getdatabyid = function (item) {
        console.log(item);
        $scope.item = item;
        $('#viewcalltree').modal('show');
        $scope.selectedtab = 0;
        $scope.item.UpdatedTime = moment(item.CreatedTime).format('DD/MM/YYYY HH:mm');

        surveyFactory.GetLCMCampaignInfo(item.CampaignName).then(function (lcmdata) {
            if (lcmdata.data.CreateCampaign) {
                $scope.item.CampaignStartTime = moment(lcmdata.data.CreateCampaign.StartDate).format('DD/MM/YYYY HH:mm');
                $scope.item.CampaignEndTime = moment(lcmdata.data.CreateCampaign.EndDate).format('DD/MM/YYYY HH:mm');
            }
        });

    }

    $scope.GetAlldata = function (type) {
        $scope.showpending = false;
        $scope.showapproved = false;
        $scope.showrejected = false;

        var pendingdata = _.filter($scope.Pendingresultdata, function (item) {
            return item.status == "INITIATED";
        })
        $scope.pendingdatacount = pendingdata.length;

        var approveddata = _.filter($scope.Pendingresultdata, function (item) {
            return item.status == "APPROVED";
        })
        $scope.approveddatacount = approveddata.length;

        var rejectdata = _.filter($scope.Pendingresultdata, function (item) {
            return item.status == "REJECTED";
        })

        $scope.rejectdatacount = rejectdata.length;
        var data = [];
        if (type == 1) {
            data = pendingdata;
            $scope.showpending = true;
        } else if (type == 2) {
            data = approveddata;
            $scope.showapproved = true;
        } else if (type == 3) {
            data = rejectdata;
            $scope.showrejected = true;
        }
        $scope.PendingContactDetailsGrid.data = data;
        $scope.gridApi.grid.modifyRows(data);
        getSearchableFields();
        $scope.gridApi.core.refresh();
        $scope.currentwindow = type;
    }



    $scope.Edit = function (rowdata) {
        $scope.ismainactive = false;
        $scope.item = rowdata;
        $timeout(function () {
            $scope.redraw = false;
            changeCallFlow(rowdata);
        }, 500);
    }


    $scope.isSuperIdmin = false;

    $scope.checkifsuperadmin = function () {
        if (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) {
            $scope.isSuperIdmin = true;
        } else
            $scope.isSuperIdmin = false;

        $scope.FilterData();

    }
    $scope.checkifsuperadmin();

}]);