var app = angular.module('adminApp');

app.controller('AppController', ['$scope', function($scope) {

    $scope.greeting = 'Hola!';
    var init = function() {
        alert('App loaded')
    };
    
    init();
}]);
// app.controller('assignCallController', function ($scope, $sce, $rootScope, $q, $timeout, toaster, missCall, uiGridConstants, uiGridExporterConstants) {

// });