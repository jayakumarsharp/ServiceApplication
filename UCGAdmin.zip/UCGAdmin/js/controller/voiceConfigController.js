app.controller('voiceConfigController', ['$scope', 'appFactory', '$window', 'voiceTransFactory', '$filter', 'toaster', '$rootScope', '$timeout', function ($scope, appFactory, $window, voiceTransFactory, $filter, toaster, $rootScope, $timeout) {
    $scope.Formlist = {};
    $scope.ms = {};
    $scope.form = {};
    $scope.BatchName = {};
   // $scope.IsRecurring=true;
    $scope.flag=false;
   
    $scope.workDays = [
        { id: 2, name: 'M', fullName: 'Monday' },
        { id: 3, name: 'T', fullName: 'Tuesday' },
        { id: 4, name: 'W', fullName: 'Wednesday' },
        { id: 5, name: 'T', fullName: 'Thursday' },
        { id: 6, name: 'F', fullName: 'Friday' },
        { id: 7, name: 'S', fullName: 'Saturday' },
        { id: 1, name: 'S', fullName: 'Sunday' }
    ];
    var vm = this;
    //  var stat;
    // $scope.permissions = appFactory.permissions[appConst.MENUS.CAMP_MGNT.MGNT_CAMP];
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId;
    // $rootScope.departmentName = 103;
    // var userObj = {
    //     SSOID: 'admin'
    // };

    $scope.gridVoiceConfig = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableColumnResizing: true,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
            name: 'S.No',
            width: '5%',
            enableSorting: false,
            enableFiltering: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
        },
        {
            name: 'BatchName',
            field: 'BatchName',
            cellTooltip: true
        },
        {
            name: 'Location',
            cellTooltip: true,
            width: '35%',
            cellTemplate: '<span class="ui-grid-cell-contents ng-binding ng-scope" title="{{row.entity.SourceSystem}}\\{{row.entity.SourceDirectory}}">{{row.entity.SourceSystem}}\\{{row.entity.SourceDirectory}}</span>',

            //cellTemplate: '<span>{{row.entity.SourceSystem}}\\{{row.entity.SourceDirectory}}</span>'
        },
        {
            name: 'Recurring',
            field: 'IsRecurring',
            width: '10%',
            cellTooltip: true
            
        },
        {
            name: 'Schedule Start',
            field: 'startTime',
            cellTooltip: true,
            cellTemplate: '<span ng-if="row.entity.IsRecurring" class="ui-grid-cell-contents ng-binding ng-scope" title="{{row.entity.RecurringStartTime}}">{{row.entity.RecurringStartTime}}</span><span ng-if="!row.entity.IsRecurring" class="ui-grid-cell-contents ng-binding ng-scope" title="{{row.entity.startTime | date : \'dd-MM-y\'}}">{{row.entity.startTime | date : "dd-MM-y"}}</span>',
            //cellFilter: 'date:\'dd/MM/yyyy HH:mm\''
        },
        {
            name: 'Schedule End',
            field: 'endTime',
            cellTooltip: true,
            cellTemplate: '<span ng-if="row.entity.IsRecurring" class="ui-grid-cell-contents ng-binding ng-scope" title="{{row.entity.RecurringEndTime}}">{{row.entity.RecurringEndTime}}</span><span ng-if="!row.entity.IsRecurring" class="ui-grid-cell-contents ng-binding ng-scope" title="{{row.entity.endTime | date : \'dd-MM-y\' }}">{{row.entity.endTime | date : "dd-MM-y"}}</span>',
           // cellFilter: 'date:\'dd/MM/yyyy HH:mm\''
        },

        {
            name: 'Options',
            enableSorting: false,
            enableFiltering: false,
            width: '10%',
            cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
        }

        ],
    };








    $scope.gridVoiceConfig.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
    };

    $scope.gridVoiceConfigRefresh = function (data) {
        // $scope.gridVoiceConfig.data = data;
        $scope.ConfigData = data;
        $scope.gridVoiceConfig.data = _.filter($scope.ConfigData, function (item) {
            return item.ConfigID != 1 && item.ConfigID != 2;
        });
        //  $scope.gridApi.grid.refresh();

    }
    $scope.RecurringDays={};
    $scope.RecurringDays.DayNumber = [];


   

    $scope.AddworkingDay = function (dayID) {
        if (!$scope.RecurringDays.DayNumber) {
            $scope.RecurringDays.DayNumber = [];
        }
        var itemIndex = $scope.RecurringDays.DayNumber.indexOf(dayID);
        if (itemIndex < 0) {
            $scope.RecurringDays.DayNumber.push(dayID);
        } else {
            $scope.RecurringDays.DayNumber.splice(itemIndex, 1);
        }
    };




    $scope.GetVoiceConfigData = function () {

        voiceTransFactory.GetVoiceConfig().then(
            function success(data) {

                $scope.gridVoiceConfigRefresh(data.data);

            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while retrieving Voice ConfigData"
                });
            }
        )
    }

    // $scope.GetBatchName = function () {

    //     voiceTransFactory.GetBatchName().then(
    //         function success(data) {

    //             $scope.BatchName = data.data;

    //         },
    //         function error(data) {
    //             toaster.pop({
    //                 type: "error",
    //                 body: "Error while retrieving Voice ConfigData"
    //             });
    //         }
    //     )
    // }
    $scope.GetVoiceConfigData();


    $scope.DepartmentDropDownValue = [{
        LanguageCode: 'ENG',
        Languge: 'English'
    },
    {
        LanguageCode: 'HIN',
        Languge: 'Hindi'
    }
    ];



    $scope.Priority = [{
        Code: 2,
        Name: 'High'
    },
    {
        Code: 1,
        Name: 'Low'
    }
    ];

    $scope.showAdd = function () {
        //$scope.form.VoiceConfig.$setPristine();
        $scope.Formlist = {};
        $scope.DepartmentDropDownValue.forEach(function (value, key) {
            if (value.LanguageCode = 'HIN') {
                $scope.defLang = value;
            }
        });
        $scope.Formlist.FileFormat = $scope.defLang.LanguageCode;
        $scope.Formlist.Priority = 1;
        $scope.Formlist.IsRecurring=false;
        $scope.workDays = [{ id: 2, selected: true, name: 'M', fullName: 'Monday' },
        { id: 3, selected: true, name: 'T', fullName: 'Tuesday' },
        { id: 4, selected: true, name: 'W', fullName: 'Wednesday' },
        { id: 5, selected: true, name: 'T', fullName: 'Thursday' },
        { id: 6, selected: true, name: 'F', fullName: 'Friday' },
        { id: 7, selected: false, name: 'S', fullName: 'Saturday' },
        { id: 1, selected: false, name: 'S', fullName: 'Sunday' },
        ];
         $scope.RecurringDays.DayNumber = [ 2, 3, 4, 5,6];
        $scope.form.VoiceConfig.BatchName.$error.validationError = false;
        $scope.form.VoiceConfig.$setPristine();
        // For popup resize and draggable
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });          
        })
        $('#AddConfiguration').modal('show');
    }


    $scope.open = {
        startDate: new Date(),
        endDate: new Date()
    }
    $scope.ms = {
        startDate: new Date(),
        endDate: new Date()
    }
    $scope.EditTime = {
        startDate: new Date(),
        endDate: new Date()
    }
    $scope.timeOptions = {
        readonlyInput: false,
        showMeridian: false
    }
    $scope.openCalendar = function (e, date) {
        e.preventDefault();
        e.stopPropagation();
        $scope.open = {};
        $scope.open[date] = true;
    };
    $scope.Add = function () {
        var VoiceConfigAdd = {};
        appFactory.ShowLoader();
        VoiceConfigAdd.BatchName = $scope.Formlist.BatchName;
        var location = $scope.Formlist.Location;
        $scope.Validpath = "";
        if (location.includes("\\\\", 0)) {
            $scope.Validpath = "Please enter the path without \\\\";
            appFactory.HideLoader();
        };
        $scope.form.VoiceConfig.BatchName.$error.validationError = false;

        voiceTransFactory.GetBatchName().then(
            function success(data) {

                $scope.BatchNameVerify = data.data;
                angular.forEach($scope.BatchNameVerify, function (rowdata) {
                    if (rowdata == VoiceConfigAdd.BatchName) {
                        appFactory.HideLoader();
                        $scope.form.VoiceConfig.BatchName.$error.validationError = true;
                    }
                });
                if (!$scope.form.VoiceConfig.BatchName.$error.validationError && !location.includes("\\\\", 0)) {


                    VoiceConfigAdd.SourceSystem = $scope.Formlist.Location.split('\\')[0];
                    VoiceConfigAdd.SourceDirectory = location.replace(VoiceConfigAdd.SourceSystem + '\\', "");
                    VoiceConfigAdd.Updatedby = userObj.SSOID;
                    VoiceConfigAdd.DestinationDirectory = config.VoiceDestinationDirectory;
                    VoiceConfigAdd.DestinationSystem = config.VoiceDestinationSystem;
                    VoiceConfigAdd.FileFormat = $scope.Formlist.FileFormat;
                    VoiceConfigAdd.Priority = $scope.Formlist.Priority;
                    VoiceConfigAdd.IsRecurring=$scope.Formlist.IsRecurring;
                    VoiceConfigAdd.SelectedDays=$scope.RecurringDays.DayNumber.toString();
                    var RecurringstartTime = moment($scope.ms.startDate).format("HH:mm");
                    var RecurringendTime = moment($scope.ms.endDate).format("HH:mm");
                    VoiceConfigAdd.RecurringStartTime = RecurringstartTime;
                    VoiceConfigAdd.RecurringEndTime = RecurringendTime;   
                                     
                    
                    var startTime = moment($scope.ms.startDate).format('YYYY-MM-DD HH:mm:ss');
                    var endTime = moment($scope.ms.endDate).format('YYYY-MM-DD HH:mm:ss');

                    VoiceConfigAdd.startTime = startTime;
                    VoiceConfigAdd.endTime = endTime;
                    var RecurStartObj= moment($scope.ms.startDate);
                    var RecurEndObj = moment( $scope.ms.endDate);
                    // $scope.VoiceConfigUpdate.RecurringStartTime = RecurringstartTime;
                    // $scope.VoiceConfigUpdate.RecurringEndTime = RecurringendTime; 
                    if(!$scope.Formlist.IsRecurring){
                        var validMessage = appFactory.validateDates($scope.ms.startDate, $scope.ms.endDate);
                    }
                    else if(RecurStartObj.diff(RecurEndObj) > 0){
                       validMessage='start Time Should be less than currentTime';
                    }
                    else{
                        validMessage='';
                    }
                    $scope.Message = '';

                    if (validMessage) {
                        appFactory.HideLoader();
                        $scope.Message = validMessage;
                        // toaster.pop({
                        //     type: "error",
                        //     body: vallidMessage
                        // });
                    }
                    else {
                        voiceTransFactory.CreateVoiceConfig(VoiceConfigAdd).then(function (data) {
                            if (data.data == "Success") {
                                appFactory.HideLoader();
                                $scope.GetVoiceConfigData();

                                $('#AddConfiguration').modal('hide');
                                $scope.Formlist = {};
                                $scope.form.VoiceConfig.$setPristine();
                                toaster.pop({
                                    type: "success",
                                    body: "Added Successfully"
                                });
                            } else {
                                $scope.GetVoiceConfigData();

                                if (data.data == "Failure") {
                                    appFactory.HideLoader();
                                    toaster.pop({
                                        type: "error",
                                        body: "Error while Adding Voice config"
                                    });
                                } else {
                                    appFactory.HideLoader();
                                    $scope.Validpath = data.data;
                                    // toaster.pop({
                                    //     type: "error",
                                    //     body: data.data
                                    // });
                                }
                            }
                        });
                    }

                }

            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while retrieving Voice ConfigData"
                });
            }
        )

        // angular.forEach($scope.ConfigData, function (rowdata) {
        //     if (rowdata.BatchName == VoiceConfigAdd.BatchName) {
        //         appFactory.HideLoader();
        //         $scope.form.VoiceConfig.BatchName.$error.validationError = true;
        //     }
        // });


    }



    $scope.showEdit = function (getRowData) {
        $scope.VoiceConfigEdit = {};
        $scope.VoiceConfigEdit.SourceSystem = getRowData.SourceSystem;
        $scope.VoiceConfigEdit.SourceDirectory = getRowData.SourceDirectory;
        $scope.VoiceConfigEdit.BatchName = getRowData.BatchName;
        $scope.VoiceConfigEdit.Location = getRowData.SourceSystem + '\\' + getRowData.SourceDirectory;
        $scope.VoiceConfigEdit.ShortCodeID = getRowData.ConfigID;
        $scope.VoiceConfigEdit.FileFormat = getRowData.FileFormat;
        $scope.VoiceConfigEdit.Priority = getRowData.priorityCheck;
        $scope.VoiceConfigEdit.IsRecurring=getRowData.IsRecurring;
        $scope.RecurringDays.DayNumber=JSON.parse("[" +getRowData.selectedDays + "]");
        $scope.workDays = [{ id: 2, selected: false, name: 'M', fullName: 'Monday' },
        { id: 3, selected: false, name: 'T', fullName: 'Tuesday' },
        { id: 4, selected: false, name: 'W', fullName: 'Wednesday' },
        { id: 5, selected: false, name: 'T', fullName: 'Thursday' },
        { id: 6, selected: false, name: 'F', fullName: 'Friday' },
        { id: 7, selected: false, name: 'S', fullName: 'Saturday' },
        { id: 1, selected: false, name: 'S', fullName: 'Sunday' },
        ];
        angular.forEach($scope.RecurringDays.DayNumber,function(item){
            angular.forEach($scope.workDays,function(ob){
                if(ob.id==item){
                    ob.selected=true;                    
                }
            })
        });       
        $scope.validateStartTime = getRowData.startTime;
        var scheduledTim = getRowData.startTime;
        var scheduledEndtime = getRowData.endTime;
        var stat = moment(scheduledTim, 'YYYY-MM-DD HH:mm:ss').format('DD-MMM-YYYY HH:mm:ss');
        $scope.EditTime.startDate = new Date(stat);
        var endtim = moment(scheduledEndtime, 'YYYY-MM-DD HH:mm:ss').format('DD-MMM-YYYY HH:mm:ss');
        $scope.EditTime.endDate = new Date(endtim);
         // For popup resize and draggable
         $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });          
        })
        $('#modifyConfiguration').modal('show');
        var RecurStartTime = getRowData.RecurringStartTime;
        var RecurEndTime = getRowData.RecurringEndTime;
        var Rstart = moment(RecurStartTime, 'HH:mm:ss').format('DD-MMM-YYYY HH:mm:ss');
        $scope.EditTime.RecurringStartDate = new Date(Rstart);
        var REnd = moment(RecurEndTime, 'HH:mm:ss').format('DD-MMM-YYYY HH:mm:ss');
        $scope.EditTime.RecurringEndDate = new Date(REnd);
    }

    $scope.UpdateVoiceConfig = function () {
        $scope.VoiceConfigUpdate = {};
        $scope.VoiceConfigUpdate.UpdatedBy = userObj.SSOID;
        var location = $scope.VoiceConfigEdit.Location;
        $scope.VoiceConfigUpdate.BatchName = $scope.VoiceConfigEdit.BatchName;
        $scope.VoiceConfigUpdate.SourceSystem = $scope.VoiceConfigEdit.Location.split('\\')[0];;
        $scope.VoiceConfigUpdate.SourceDirectory = location.replace($scope.VoiceConfigUpdate.SourceSystem + '\\', "");;
        $scope.VoiceConfigUpdate.ConfigID = $scope.VoiceConfigEdit.ShortCodeID;
        $scope.VoiceConfigUpdate.FileFormat = $scope.VoiceConfigEdit.FileFormat;
        $scope.VoiceConfigUpdate.Priority = $scope.VoiceConfigEdit.Priority;
        $scope.VoiceConfigUpdate.SelectedDays=$scope.RecurringDays.DayNumber.toString();
        var startTime = moment($scope.EditTime.startDate).format("YYYY-MM-DD HH:mm:ss");
        var endTime = moment($scope.EditTime.endDate).format("YYYY-MM-DD HH:mm:ss");
        $scope.VoiceConfigUpdate.startTime = startTime;
        $scope.VoiceConfigUpdate.endTime = endTime;
        $scope.VoiceConfigUpdate.IsRecurring=$scope.VoiceConfigEdit.IsRecurring;
        var currenDate = moment(moment().format('YYYY-MM-DD HH:mm:ss'));

        var RecurringstartTime = moment($scope.EditTime.RecurringStartDate).format("HH:mm");
        var RecurringendTime = moment( $scope.EditTime.RecurringEndDate).format("HH:mm");
        var RecurStartObj= moment($scope.EditTime.RecurringStartDate);
        var RecurEndObj = moment( $scope.EditTime.RecurringEndDate);
        $scope.VoiceConfigUpdate.RecurringStartTime = RecurringstartTime;
        $scope.VoiceConfigUpdate.RecurringEndTime = RecurringendTime; 

        var validMessage='';
       
        if( $scope.VoiceConfigEdit.IsRecurring){
            if(RecurStartObj.diff(RecurEndObj) > 0){
                validMessage='start Time Should be less than currentTime';
             }
        }else{
            if ($scope.validateStartTime != $scope.EditTime.startDate) {
                validMessage = appFactory.validateDates($scope.ms.startDate, $scope.ms.endDate);
            } else if (endTime.diff(startTime) > 0) {
                validMessage = "End date Should be less than Start date"
            }
        }
        if (validMessage) {
            $scope.EditMessage = validMessage;
            // toaster.pop({
            //     type: "error",
            //     body: validMessage
            // });
        }
        else {
            voiceTransFactory.UpdateVoiceConfig($scope.VoiceConfigUpdate).then(function (data) {
                if (data.data == "Success") {
                    $scope.GetVoiceConfigData();
                    $('#modifyConfiguration').modal('hide');
                    toaster.pop({
                        type: "Success",
                        body: "Voice configuration Modified successfully"
                    });
                } else {
                    $scope.GetVoiceConfigData();
                    if (data.data == "Failure") {
                        toaster.pop({
                            type: "error",
                            body: "Error while updating"
                        });
                    } else {
                        toaster.pop({
                            type: "error",
                            body: data.data
                        });
                    }
                }
            });
        }
    }
    $scope.showDelete = function (getRowData) {
        $scope.CodeID = getRowData.ConfigID;
        $('#confirmModal').modal('show');
    }
    $scope.Delete = function (index) {
        var ConfigID = $scope.CodeID;
        voiceTransFactory.DeleteVoiceConfig(ConfigID).then(function (data) {
            if (data.data == "Success") {
                $('#confirmModal').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "Voice configuration Deleted successfully"
                });
                //Updating the table data
                $scope.GetVoiceConfigData();
            } else {
                $scope.GetVoiceConfigData();
            }

        });
    }







}]);