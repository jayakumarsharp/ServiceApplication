app.controller('SurveyQuestionController', ['$scope', '$timeout', '_', 'roleFactory', 'profileFactory', 'appFactory', 'surveyFactory', '$rootScope', function ($scope, $timeout, _, roleFactory, profileFactory, appFactory, surveyFactory, $rootScope) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId; 
   // $rootScope.departmentName = "103";
    $scope.permissions = appFactory.permissions[appConst.MENUS.RCHK_MGMT.MGMT_QUES];
    // $scope.permissions = {
    //     'Add': true,
    //     'Modify': true,
    //     'Delete': true
    // };
    //   var userObj = {
    //      SSOID: 'admin'
    //  };
    $scope.Griddata = [];
    $scope.EditID = 0;
    $scope.data={};
    $scope.filtervalue = '';
    $rootScope.selectedGridData = [];
    $scope.searchIndex = '';
    $scope.QuestionGrid = {
        enableRowSelection: true,
        // enableFiltering: true,
        enableColumnResizing: true,
        enableSelectAll: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
            name: 'S.No',
            width: '10%',
            enableSorting: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>',
            cellTooltip: true
        },
        {
            name: 'ID',
            field: 'ID',
            visible: false
        },
        {
            name: 'Department',
            field: 'DepartmentName',
            isSearchable: true,
            cellTooltip: true
        },
        {
            name: 'Type',
            field: 'Type',
            isSearchable: true,
            cellTooltip: true
        },
        {
            name: 'Question',
            field: 'Question',
            isSearchable: true,
            cellTooltip: true
        },
        {
            name: 'Edit',
            width: '7%',
            enableSorting: false,
            cellTemplate: '<a href="#" ng-if="grid.appScope.permissions.Modify" ng-click="grid.appScope.Edit(row.entity)"><span class="fa fa-edit"></span></a><span ng-if="!grid.appScope.permissions.Modify" class="fa fa-edit" style="color:#666; cursor: not-allowed;" ></span>'
        },
        {
            name: 'Delete',
            width: '7%',
            enableSorting: false,
            cellTemplate: '<a href="#"  ng-if="grid.appScope.permissions.Delete && (grid.appScope.isSuperIdmin || row.entity.DepartmentId !=-1)" ng-click="grid.appScope.DeleteQuestion(row.entity)"><span class="fa fa-trash"></span></a><span ng-if="!grid.appScope.permissions.Delete" class="fa fa-trash" style="color:#666; cursor: not-allowed;" ></span>'
        },
        ],
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                var msg = 'row selected on single' + row.isSelected;
                console.log(msg);

                if (row.isSelected == true) {
                    $rootScope.IsselectedGrid = true;
                    $rootScope.selectedGridData.push(row.entity.ID);
                } else {
                    $rootScope.IsselectedGrid = false;
                    $rootScope.selectedGridData.splice($rootScope.selectedGridData.indexOf(row.entity.ID), 1);
                }
            });

            gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
                var msg = 'row length:' + row.length;
                console.log(msg);
                if (row.length > 0) {

                    for (index = 0; index < row.length; index++) {
                        console.log(row[index]);
                        if (row[index].isSelected == true) {
                            $rootScope.IsselectedGrid = true;
                            $rootScope.selectedGridData.push(row[index].entity.ID);
                        } else {
                            $rootScope.IsselectedGrid = false;
                            $rootScope.selectedGridData = [];
                        }
                    }
                }
                if ($rootScope.IsselectedGrid == false) {
                    $rootScope.selectedGridData = null;
                    $rootScope.selectedGridData = [];
                }
            });
        },
    };
    $scope.Header = "Create Question";
    //copymodal
    $('.modal-dialog .card').resizable().draggable();
    $scope.copymodal = function () {
     

        if ($rootScope.selectedGridData.length > 0) {
            if ($rootScope.selectedGridData.length == 1) {
                $scope.Header = "Clone Question";
                var rowdata = _.where($scope.Griddata, {
                    ID: $rootScope.selectedGridData[0]
                });
                if (rowdata[0].Type == "Generic") {
                    appFactory.showWarning("Generic questions not allowed to clone");
                } else {
                    $scope.QuestionInfo = rowdata[0];
                    $scope.QuestionInfo.departmentId = rowdata[0].DepartmentId;
                    $scope.QuestionInfo.QuestionType = rowdata[0].Type;
                    $scope.EditView = true;
                    $('.modal-dialog .card').resizable().draggable({
                        containment: ".page-content"
                    });
                    $('.modal').on('hidden.bs.modal', function (e) {
                        $('.modal-dialog .card').css({ top: 0, left: 0 });
                      
                    })
                    $('#addQuestions').modal('show');
                }
            } else {
                $scope.Header = "Clone Questions";
                var resultsetdata = [];
                for (var i = 0; i < $rootScope.selectedGridData.length; i++) {
                    var rowdata = _.where($scope.Griddata, {
                        ID: $rootScope.selectedGridData[i]
                    });
                    resultsetdata.push(rowdata[0]);
                }
                var groupresult = _.groupBy(resultsetdata, function (obj) {
                    return obj.DepartmentName;
                });
                // if (Object.keys(groupresult).length > 1) {
                //     appFactory.showWarning("Multiple department questions not allowed to clone");


                // } else {
                if (groupresult.hasOwnProperty('Generic')) {
                    appFactory.showWarning("Generic questions not allowed to clone");
                } else {
                    var dept = angular.copy($scope.Departments);
                    var keyname = "";
                    var keyNames = Object.keys(groupresult);
                    for (var k = 0; k < keyNames.length; k++) {
                        keyname = keyNames[k];
                    }
                    $scope.AvailableDepartments = _.without(dept, _.findWhere(dept, {
                        DepartmentName: keyname
                    }))
                    $scope.AvailableDepartments.push($scope.withoutdata);
                    if (Object.keys(groupresult).length > 1) {
                        //$scope.AvailableDepartments = [];
                        //$scope.AvailableDepartments.push($scope.withoutdata);
                        $scope.ClonedepartmentId = $scope.withoutdata;
                    } else {
                        //  $scope.AvailableDepartments = _.without($scope.AvailableDepartments, _.findWhere($scope.AvailableDepartments))
                    }
                    $('.modal-dialog .card').resizable().draggable({
                        containment: ".page-content"
                    });
                    $('.modal').on('hidden.bs.modal', function (e) {
                        $('.modal-dialog .card').css({ top: 0, left: 0 });
                      
                    })
                    $('#CloneQuestions').modal('show');
                }
                //}
            }

        } else {
            appFactory.showWarning("Please select question to clone");
        }

    }

    $scope.deletemultiple=function(){
        var deleteID=[];
        if ($rootScope.selectedGridData.length > 0) {
            for (var i = 0; i < $rootScope.selectedGridData.length; i++) {
                var rowdata = _.where($scope.Griddata, {
                    ID: $rootScope.selectedGridData[i]
                });
                deleteID.push(rowdata[0].ID);
            }
           
            angular.forEach(deleteID,function(data){
                $scope.Deletemultiplequestion(data);
            });
            $rootScope.selectedGridData={};
            $timeout(function () {
                $scope.GetAllQuestion();
                appFactory.showSuccess("Question deleted successfully");
            }, 1000);
        }
        else{
            appFactory.showWarning("Please select question to delete");
        }
    }

    $scope.Deletemultiplequestion= function(ID){
       
            surveyFactory.DeleteQuestion(ID).then(
                function success(data) {
                    
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            );
        

    }



    $scope.ClonedepartmentId = {};

    $scope.withoutdata = {};
    $scope.showrow = true;

    $scope.changeQtype = function (QuestionType) {

        if ($scope.isSuperIdmin) {
            if (QuestionType == "Generic") {
                $scope.showrow = false;
                $scope.Departments.push($scope.withoutdata);
                $scope.QuestionInfo.departmentId = _.findWhere($scope.Departments, {
                    ID: -1
                });
            } else {
                $scope.showrow = true;
                var removegen = _.findWhere($scope.Departments, {
                    DepartmentName: "Generic"
                })
                if (!removegen)
                    $scope.Departments = _.without($scope.Departments, removegen);
                //$scope.QuestionInfo.departmentId = "";
                $scope.QuestionInfo.departmentId = {};
            }
        } else {
            if (QuestionType == "Generic") {
                $scope.QuestionInfo.departmentId = _.findWhere($scope.Departments, {
                    ID: -1
                });
                //$scope.QuestionInfo.departmentId = -1;
            } else {
                $scope.QuestionInfo.departmentId = _.findWhere($scope.Departments, {
                    ID: $rootScope.departmentName
                });
                //$scope.QuestionInfo.departmentId = $rootScope.departmentName;
            }
        }
    }

    $scope.Edit = function (rowdata) {
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });
          
        })
        $scope.editQinfo = rowdata;
        $scope.EnableEdit = false;
        if(rowdata.Type=='Generic'){
            $scope.EnableEdit = true;
        }
        $('#editQuestions').modal('show');
        if ($scope.isSuperIdmin) {
            $scope.changeedittype(rowdata.Type);
        }
      //  $scope.editQinfo = rowdata;
        $scope.editQinfo.DepartmentId = _.findWhere($scope.Departments, {
            ID: rowdata.DepartmentId
        });

    }

    $scope.changeedittype = function (type) {
        if (type == "Generic") {
            $scope.showrow = false;
            var isexist = !!_.where($scope.Departments, {
                DepartmentName: "Generic"
            }).length;
            if (!isexist) {
                $scope.Departments.push($scope.withoutdata)
            }
        } else {
            $scope.showrow = true;
            var removedept = _.findWhere($scope.Departments, {
                ID: -1
            });
            if (!removedept)
                $scope.Departments = _.without($scope.Departments, removedept)
        }
    }
    $scope.showAdd = function () {
        $scope.Header = "Create Question";
        $scope.Action = 'Add';
        $scope.QuestionInfo = {
            QuestionType: "Specific"
        };
        $scope.EditView = true;
        $scope.changeQtype('Specific');
        $('.modal-dialog .card').resizable().draggable({
            containment: ".page-content"
        });
        $('.modal').on('hidden.bs.modal', function (e) {
            $('.modal-dialog .card').css({ top: 0, left: 0 });
          
        })
        $('#addQuestions').modal('show');
    }

    $scope.refresh = function () {
        $scope.searchIndex = "";
        $scope.GetAllQuestion();
    }
    $scope.UpdateQuestion = function (question) {
        if (validatequestion(question.DepartmentId, question.Question)) {
            surveyFactory.GetAllQuestion().then(
                function success(data) {
                    if ($scope.isSuperIdmin) {
                        $scope.Griddata = data.data;
                    } else {
                        $scope.Griddata = _.filter(data.data, function (item) {
                            return item.DepartmentId == $rootScope.departmentName || item.DepartmentId == -1;
                        });
                    }

                    $scope.QuestionGrid.data = $scope.Griddata;
                    $scope.gridApi.grid.modifyRows($scope.Griddata);
                    $scope.gridApi.core.refresh();
                    getSearchableFields();
                    var filterdata = [];

                    filterdata = _.filter($scope.Griddata, function (item) {
                        return item.DepartmentId == question.DepartmentId.ID && item.Question == question.Question.trim();
                    });

                    if (filterdata.length > 0) {
                        if (question.ID != filterdata[0].ID)
                            appFactory.showWarning("Question already exists");
                        else
                        {
                            appFactory.showSuccess("Question updated successfully");
                            $('#editQuestions').modal('hide');
                        }
                           
                    } else {
                        question.DepartmentId = question.DepartmentId.ID;
                        updatequestion(question);
                    }
                },
                function error(data) {
                    appFactory.showError('Server Unavailable');
                }
            )


        }
    }

    function updatequestion(question) {
        surveyFactory.UpdateQuestion(question).then(
            function success(data) {
                $('#editQuestions').modal('hide');
                $scope.GetAllQuestion();
                appFactory.showSuccess("Question updated successfully");
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )

    }

    function validatequestion(dept, ques) {
        if (!dept.ID) {
            appFactory.showWarning("Please select department");
            return false;
        } else if (!ques) {
            appFactory.showWarning("Please enter question");
            return false;
        }
        return true;
    }

    $scope.CloneQuestion = function (department) {
        $scope.isclone = true;
        var resultsetdata = [];
       // var department= $scope.ClonedepartmentId.ID;
        for (var i = 0; i < $rootScope.selectedGridData.length; i++) {
            var rowdata = _.where($scope.Griddata, {
                ID: $rootScope.selectedGridData[i]
            });

            resultsetdata.push({
                QuestionType: 'Generic',
                departmentId: department,
                Question: rowdata[0].Question
            });
        }
        for (var k = 0; k < resultsetdata.length; k++) {
            // surveyFactory.CreateQuestions(resultsetdata[k]).then(
            //     function success(data) {
            //         $scope.GetAllQuestion();
            //     },
            //     function error(data) {}
            // )

            validatequestionalreadyexist(resultsetdata[k]);
        }
        $('#CloneQuestions').modal('hide');
        appFactory.showSuccess("Question added successfully");
        $rootScope.selectedGridData = [];
        $timeout(function () {
            $scope.GetAllQuestion();
        }, 1000);
    }

    function validatequestionalreadyexist(questiondata) {
        surveyFactory.GetAllQuestion().then(
            function success(data) {
                if ($scope.isSuperIdmin) {
                    $scope.Griddata = data.data;
                } else {
                    $scope.Griddata = _.filter(data.data, function (item) {
                        return item.DepartmentId == $rootScope.departmentName || item.DepartmentId == -1;
                    });
                }

                $scope.QuestionGrid.data = $scope.Griddata;
                if (!$scope.QuestionGrid.data) {
                    $scope.gridApi.grid.modifyRows($scope.Griddata);
                    $scope.gridApi.core.refresh();
                }

                getSearchableFields();
                var filterdata = [];

                filterdata = _.filter($scope.Griddata, function (item) {
                    return item.DepartmentId == questiondata.departmentId.ID && item.Question == questiondata.Question.trim();
                });

                if (filterdata.length > 0)
                    appFactory.showWarning("Question already exists");
                else {
                    questiondata.departmentId = questiondata.departmentId.ID;
                    surveyFactory.CreateQuestions(questiondata).then(
                        function success(data) {
                            $('#addQuestions').modal('hide');
                            if (!$scope.isclone) {
                                $scope.GetAllQuestion();
                                appFactory.showSuccess("Question added successfully");
                            }
                        },
                        function error(data) {
                            appFactory.showError('Server Unavailable');
                        }
                    )

                }
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    }

    $scope.delete = function () {
        surveyFactory.DeleteQuestion($scope.deletedata.ID).then(
            function success(data) {
                $('#editQuestions').modal('hide');
                $scope.GetAllQuestion();
                appFactory.showSuccess("Question deleted successfully");

            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
        $scope.deletedata = {};
        $('#confirmModal').modal('hide');
    }

    $scope.DeleteQuestion = function (rowdata) {
        $scope.deletedata = rowdata;
        $scope.deleteItem = "";
        $('#confirmModal').modal('show');
    }
    $scope.isclone = false;
    $scope.CreateQuestion = function () {
        if (validatequestion($scope.QuestionInfo.departmentId, $scope.QuestionInfo.Question)) {
            $scope.isclone = false;
            validatequestionalreadyexist($scope.QuestionInfo);
            $rootScope.selectedGridData = [];
        }
    }

    $scope.GetAllQuestion = function () {
        surveyFactory.GetAllQuestion().then(
            function success(data) {
                if ($scope.isSuperIdmin) {
                    $scope.Griddata = data.data;
                } else {
                    $scope.Griddata = _.filter(data.data, function (item) {
                        return item.DepartmentId == $rootScope.departmentName || item.DepartmentId == -1;
                    });
                }

                $scope.QuestionGrid.data = $scope.Griddata;
                if (!$scope.QuestionGrid.data) {
                    $scope.gridApi.grid.modifyRows($scope.Griddata);
                    $scope.gridApi.core.refresh();
                }
                getSearchableFields();
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    }
    $scope.GetAllLanguage = function () {
        surveyFactory.GetAllLanguage().then(
            function success(data) {
                console.log(data.data)
                $scope.Languages = data.data;
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    }
    $scope.GetAllDepartment = function () {
        profileFactory.GetAllDepartment().then(
            function success(data) {
                $scope.Departments = data.data;
                $scope.withoutdata = _.findWhere($scope.Departments, {
                    DepartmentName: "Generic"
                })
                $scope.Departments = _.without($scope.Departments, $scope.withoutdata);
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    };

    $scope.GetAllQuestionType = function () {
        surveyFactory.GetAllQuestionType().then(
            function success(data) {
                $scope.QuestionType = data.data;
            },
            function error(data) {
                appFactory.showError('Server Unavailable');
            }
        )
    };

    $scope.onTypeSearchValues = function () {
        var filteredData = appFactory.getDataBySearchIndex($scope.searchIndex);
        $scope.QuestionGrid.data = filteredData;
    };

    var getSearchableFields = function () {
        appFactory.getSearchableFields($scope.QuestionGrid);
    };
    $scope.isSuperIdmin = false;
    $scope.checkifsuperadmin = function () {
        if (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) {
            $scope.isSuperIdmin = true;
        } else
            $scope.isSuperIdmin = false;

        $scope.GetAllQuestion();
        $scope.GetAllQuestionType();
        $scope.GetAllDepartment();
    }
    $scope.checkifsuperadmin();

}]);