app.controller('MasterDataController', ['$scope', '$rootScope', '$http', function ($scope, $rootScope, $http) {

   $scope.AppName = $scope.$parent.AppName;
  //$scope.AppName= '/ucgAdmin_uat';

}]);