app.controller('questionImportController', ['$scope', 'appFactory', '$window', 'voiceTransFactory','profileFactory', 'masterDataFactory','$filter', 'toaster', '$rootScope', '$timeout', function ($scope, appFactory, $window, voiceTransFactory,profileFactory,masterDataFactory, $filter, toaster, $rootScope, $timeout) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
     $rootScope.departmentName = userObj.departmentId;
    //  $rootScope.departmentName = "103";
    //     var userObj = {
    //       SSOID: 'admin'
    //    };
       $scope.question={};
       $scope.validateOnSubmit=false;

    $scope.GetDepartmentName = function () {
        
                masterDataFactory.GetDepartmentName().then(
                    function success(data) {
                        $scope.Departments = data.data;
                    },
                    function error(data) {
                        toaster.pop({
                            type: "error",
                            body: "Error while getting department"
                        });
                    }
                )
            }
            $scope.GetDepartmentName();

            $scope.reset = function () {
                angular.element("input[type='file']").val(null);
                $scope.question.department=null;
                $scope.validateOnSubmit=false;
                $scope.uploadfile=null;
            };


            $scope.UploadQuestion = function () {
                $scope.validateOnSubmit=true;
                IsValidFile();
                if ($scope.isValid == true) {
                    var formData = new FormData();
                    formData.append("uploadedBy", angular.toJson(userObj.SSOID));
                    formData.append("questionFile", $scope.uploadfile);
                    formData.append("DepartmentID",$scope.question.department.ID);
                    masterDataFactory.ImportQuestion(formData).then(function(data){
                        if (data.data.Message === 'Success') {
                        
                            toaster.pop({
                                                 type: "success",
                                                 body: "file successfully uploaded",
                                             bodyOutputType: 'trustedHtml'
                                            });
                                            $scope.reset();
                        }else if (data.data.Message==='Failure'){
                            toaster.pop({
                                type: "error",
                                body: "Error while uploading file",
                                bodyOutputType: 'trustedHtml'
                            });
                        }
                        else{
                            toaster.pop({
                                type: "error",
                                body: data.data.Message,
                                bodyOutputType: 'trustedHtml'
                            });
                        }

                    });
        
                    // if ($scope.dnc.SelectedDnc == "Add") {
                    //     campaignFactory.UploadAddDNCFile(formData, $scope.dnc.SelectedDnc).then(function (data) {
                    //         //
                    //         if (data.data.Message === 'Success') {
                    //             toaster.pop({
                    //                 type: "success",
                    //                 body: "Dnc file successfully uploaded to add",
                    //                 bodyOutputType: 'trustedHtml'
                    //             });
                    //             $scope.GetDNCCount();
                    //             $scope.dnccomments = '';
                    //             $scope.dncvar='';
                    //             $scope.reset();
                    //         } else {
                    //             toaster.pop({
                    //                 type: "error",
                    //                 body: "Error while uploading dnc file to add",
                    //                 bodyOutputType: 'trustedHtml'
                    //             });
                    //         }
                    //     });
                    // } else if ($scope.dnc.SelectedDnc == "Remove") {
                    //     campaignFactory.UploadRemoveDNCFile(formData, $scope.dnc.SelectedDnc).then(function (data) {
                    //         //
        
                    //         if (data.data.Message === 'Success') {
                    //             toaster.pop({
                    //                 type: "success",
                    //                 body: "Dnc file successfully uploaded to remove",
                    //                 bodyOutputType: 'trustedHtml'
                    //             });
                    //              $scope.dnccomments = '';
                    //              $scope.dncvar='';
                    //              $scope.reset();
                    //         } else {
                    //             toaster.pop({
                    //                 type: "error",
                    //                 body: "Error while uploading dnc file to remove",
                    //                 bodyOutputType: 'trustedHtml'
                    //             });
                    //         }
                    //     });
                    // }
        
                }
        
            }

            var IsValidFile = function () {
                $scope.isValid = '';
                $scope.Message='';              
               if ($scope.uploadfile == undefined || $scope.uploadfile == null || $scope.uploadfile.name == null) {
                    // toaster.pop({
                    //     type: "error",
                    //     body: "Please select valid file to upload",
                    //     bodyOutputType: 'trustedHtml'
                    // });
                    $scope.Message="Please select valid file to upload";
                    $scope.isValid = false;
                    return;
                } else if ($scope.uploadfile.name != null) {
                     var validFormats = ['csv'];
                    //var validFormats = ['csv'];
                    var output = $filter('validfile')($scope.uploadfile.name, validFormats);
                    if (output == false) {
                        // toaster.pop({
                        //     type: "error",
                        //     body: "File format should be csv,xls,xlsx",
                        //     bodyOutputType: 'trustedHtml'
                        // });
                        $scope.Message="File format should be csv";
                        $scope.isValid = false;                        
                        return;
                    } else {
                        $scope.isValid = true;
                        // toaster.pop({
                        //     type: "error",
                        //     body: "valid file",
                        //     bodyOutputType: 'trustedHtml'
                        // });
                        return;
                    }
                } 
            }


}]);