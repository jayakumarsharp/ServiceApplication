app.controller('UssdCodeController', ['$scope', '$rootScope', 'masterDataFactory', 'toaster', function ($scope, $rootScope, masterDataFactory, toaster) {
    $scope.ussdCodeEdit = [];
    $scope.Formlist = {};
    $scope.form = {};

    $scope.gridUssdCodeOptions = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
                name: 'Department',
                field: 'DepartmentName'
            },
            {
                name: 'ApplicationUse',
                field: 'ApplicationUse'
            },

            {
                name: 'Type',
                field: 'CodeType'
            },
            {
                name: 'CodeName',
                field: 'CodeName'
            },
            {
                name: 'CodeDescription',
                field: 'CodeDescription'
            },


            //  { name: 'Options', enableFiltering: false, width: '10%', cellTemplate: ' <a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity.UserId)"><span class="fa fa-trash-o"></span></a>' }
            {
                name: 'Options',
                enableSorting: false,
                enableFiltering: false,
                width: '10%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>'
            }
        ],
    };
    // $scope.UssdCodeData = [
    //     { 'Department': 'R001', 'ApplicationUse': 'SMS', 'Type': 'Short', 'CodeName': 'ABC', 'CodeDescription': 'ShortCode' },
    //     { 'Department': 'R002', 'ApplicationUse': 'SURVEY', 'Type': 'Long', 'CodeName': '9000900090', 'CodeDescription': 'LongCode' },
    //     { 'Department': 'R003', 'ApplicationUse': 'CAMPAIGN', 'Type': 'Short', 'CodeName': 'ABC', 'CodeDescription': 'ShortCode' },

    // ];

    $scope.GetUssdCode = function () {

        masterDataFactory.GetUssdCode().then(
            function success(data) {

                console.log("edit", data);
                $scope.gridUssdCodeOptions.data = data.data;
            },
            function error(data) {

            }
        )
    }
    $scope.GetUssdCode();

    // $scope.gridUssdCodeOptions.data = $scope.UssdCodeData;

    //dropdown values
    $scope.GetApplicationName = function () {

        masterDataFactory.GetApplicationName().then(
            function success(data) {

                // console.log("editSMS",data);
                $scope.ApplicationUseDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }

    $scope.GetApplicationName();
    $scope.GetDepartmentName = function () {

        masterDataFactory.GetDepartmentName().then(
            function success(data) {

                // console.log("editSMS",data);
                $scope.DepartmentDropDownValue = data.data;
            },
            function error(data) {

            }
        )
    }
    $scope.GetDepartmentName();
    //$scope.DepartmentValue=["R001","R002","R003","R004","R005"];
    // $scope.ApplicationUseDropDownValue=["SMS","SURVEY","CAMPAIGN"];
    $scope.Type = ["Short", "Long"];

    $scope.showAdd = function () {
        $scope.Formlist = {};
        $scope.form.UssdCode.$setPristine();
        $('#AddUssdCode').modal('show');
    }



    $scope.CreateUssdCodes = function () {

        $scope.UssdCodeAdd = {};

        // $scope.SmsCodeAdd.ThresholdType = 2;
        $scope.UssdCodeAdd.UpdatedBy = 'Admin';

        $scope.UssdCodeAdd.DepartmentID = $scope.Formlist.DepartmentID;
        $scope.UssdCodeAdd.ApplicationID = $scope.Formlist.ApplicationID;
        $scope.UssdCodeAdd.CodeName = $scope.Formlist.CodeName;
        $scope.UssdCodeAdd.CodeDescription = $scope.Formlist.CodeDescription;
        $scope.UssdCodeAdd.CodeType = $scope.Formlist.CodeType;
        $scope.UssdCodeAdd.LastModifiedBy = '2017-10-13 17:47:33.460';

        masterDataFactory.CreateUssdCode($scope.UssdCodeAdd).then(function (data) {



            if (data.data == "Success") {
                $scope.GetUssdCode();

                $('#AddUssdCode').modal('hide');
                $scope.Formlist = {};
                $scope.form.UssdCode.$setPristine();
                toaster.pop({
                    type: "Success",
                    body: "USSD code created successfully"
                });

            } else {
                $scope.GetUssdCode();
                toaster.pop({
                    type: "error",
                    body: "Error while creating USSD code"
                });

            }
        });

    }

    $scope.showEdit = function (getRowData) {
        $scope.ussdCodeEdit = {};
        //console.log("edit2", getRowData);
        $scope.ussdCodeEdit.DepartmentID = getRowData.DepartmentID;
        $scope.ussdCodeEdit.ApplicationID = getRowData.ApplicationID;
        $scope.ussdCodeEdit.CodeType = getRowData.CodeType;
        $scope.ussdCodeEdit.CodeName = getRowData.CodeName;
        $scope.ussdCodeEdit.CodeDescription = getRowData.CodeDescription;
        $scope.ussdCodeEdit.UssdCodeID = getRowData.UssdCodeID;
        $scope.EditView = true;
        $('#modifyUssdCode').modal('show');
    }
    //Delete functionality
    $scope.showDelete = function (getRowData) {
        //$scope.ussdCodeDelete = {};

        $scope.CodeID = getRowData.UssdCodeID;
        $scope.EditView = true;
        $('#confirmModal').modal('show');
    }

    $scope.Delete = function () {
        // $scope.ussdCodeDelete = {};
        var CodeID = $scope.CodeID;
        masterDataFactory.DeleteUssdCode(CodeID).then(function (data) {



            if (data.data == "Success") {
                $scope.GetUssdCode();

                $('#confirmModal').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "USSD code deleted successfully"
                });

            } else {
                $scope.GetUssdCode();
                toaster.pop({
                    type: "error",
                    body: "Error while deleting USSD code",
                    toasterId: 1
                });

            }
        });

    }

    $scope.UpdateUssdCodes = function () {

        $scope.UssdCodeUpdate = {};

        $scope.UssdCodeUpdate.UpdatedBy = 'Admin';

        $scope.UssdCodeUpdate.DepartmentID = $scope.ussdCodeEdit.DepartmentID;
        $scope.UssdCodeUpdate.ApplicationID = $scope.ussdCodeEdit.ApplicationID;
        $scope.UssdCodeUpdate.CodeName = $scope.ussdCodeEdit.CodeName;
        $scope.UssdCodeUpdate.CodeDescription = $scope.ussdCodeEdit.CodeDescription;
        $scope.UssdCodeUpdate.CodeType = $scope.ussdCodeEdit.CodeType;
        //  $scope.SmsCodeUpdate.LastModifiedBy = '2017-10-13 17:47:33.460';
        $scope.UssdCodeUpdate.UssdCodeID = $scope.ussdCodeEdit.UssdCodeID;

        masterDataFactory.UpdateUssdCode($scope.UssdCodeUpdate).then(function (data) {



            if (data.data == "Success") {
                $scope.GetUssdCode();

                $('#modifyUssdCode').modal('hide');
                toaster.pop({
                    type: "Success",
                    body: "USSD code updated successfully"
                });

            } else {
                $scope.GetUssdCode();
                toaster.pop({
                    type: "error",
                    body: "Error while updating USSD code"
                });

            }
        });

    }





}]);