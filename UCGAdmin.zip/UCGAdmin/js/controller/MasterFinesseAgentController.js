

    app.controller('MasterFinesseAgent', MasterFinesseAgentController);
    
        MasterFinesseAgentController.$inject = ['appFactory','masterDataFactory', 'toaster','profileFactory','$rootScope'];
    
        function MasterFinesseAgentController(appFactory,masterDataFactory, toaster,profileFactory,$rootScope) {
            var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
            // $rootScope.departmentName = userObj.departmentId; 
           $rootScope.departmentName = "103";
            var vm = this;
            vm.form = {};
            vm.Formlist={};
            vm.DepartmentRoleId= [];            
            vm.showStatus =false;
            vm.gridFinesseAgent = {
                paginationPageSizes: [10, 20, 30],
                paginationPageSize: 10,
                enableColumnMenus: false,
                enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
                enableVerticalScrollbar: 1,
                columnDefs: [
                    { name: 'S.No', width: '10%',cellTooltip: true,enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
                    { name: 'Agent', field: 'AgentName',cellTooltip: true },
                    { name: 'Agent ID', field: 'AgentID',cellTooltip: true },
                    { name: 'Department', field: 'DepartmentName',cellTooltip: true },
                    // { name: 'DepartmentID', field: 'DepartmentId' },
    
                    { name: 'Options', enableSorting: false, enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }
                ],
            };
            vm.verifyUser = function () {
    
                  
            }
    
            vm.GetFinesseAgent = function () {
                masterDataFactory.GetFinesseAgent().then(
                    function success(response) {                    
                        vm.gridFinesseAgent.data = response.data;                
                    },
                    function error(data) {
                        toaster.pop({ type: "error", body: "Error while getting department dropdown" });
                    }
                )
            }
            vm.GetFinesseAgent(); 
    
            vm.setUserRoles = function(data) {
                vm.validflag = false;
                // vm.validflag = true;
                vm.UserRoles = [];    
                if (data != null && data != undefined && data != 'null') {
                    var userDetails = JSON.parse(data);    
                    vm.showStatus = true;
                    vm.validflag = true;
                    vm.SSOStatus = 'Valid';
                    
               
                    profileFactory.GetSSOUserRoles(userDetails.sAMAccountName).then(
                        function success(data) {
                            var result = data.data;	
                        
                            vm.CreateFinesseAgent(result);
                        })
       
                    $('#AddFinesseAgent').modal('show'); 
    
                } else {
                    vm.showStatus = true;
                    vm.validflag = false;
                    vm.SSOStatus = 'User does not exist';
                    toaster.pop({ type: "error", body: "User does not exist" });
                 
                }
              
            }
        
           
            vm.GetSSOUserRoles = function(ssoId) {   
                var idExist = true;         
                angular.forEach(vm.gridFinesseAgent.data, function(value,key) {
                    var capsSSOID = ssoId.toUpperCase();
                    if(value.AgentName == capsSSOID ){   
                        idExist = false;      
                    }
                });
                //console.log("idExist",idExist);
    
                if(idExist){
                    profileFactory.GetSSOUserRoles(ssoId).then(
                        function success(data) {                    
                            vm.setUserRoles(data.data);
                        },
                        function error(data) {
                            
                        }
                    )
                } else if(!idExist){
                    toaster.pop({ type: "error", body: "Agent ID already exist" });
                }
                
               
            };
    
           
    
            vm.CreateFinesseAgent = function (data) {  
                
                   
                   var ssoUser = JSON.parse(data);    
                   var departmentId = appFactory.getDepartmentFromRole(data);
                   if (!departmentId) {                
                       return;    
                   }  
                   
                            var FinAgentAdd = {
                                AgentID: ssoUser.sAMAccountName,
                                AgentName : ssoUser.sAMAccountName,                        
                                DepartmentID : departmentId,
                                DepartmentName : '',                              
                            };
                     
                            masterDataFactory.CreateFinesseAgent(FinAgentAdd).then(
                                function success(data) {
                                    vm.GetFinesseAgent();
                                    $('#AddFinesseAgent').modal('hide');
                                    toaster.pop({ type: "success", body: "Added Successfully" });            
                                },
                                function error(data) {
                                    toaster.pop({ type: "error", body: "Error while Adding Agent" });
                
                                }
                            );
                        }
    
            vm.showAdd = function () {  
    
                vm.SSOStatus = '';
                vm.showStatus = false;
                vm.Formlist = {};
                vm.flagA = false;
                vm.form.FinesseAgent.$setPristine();
                $('#AddFinesseAgent').modal('show');
    
            }
    
            vm.GetDepartmentName = function () {
                
                masterDataFactory.GetDepartmentName().then(
                    function success(data) {
                        vm.DepartmentDropDownValue = data.data;
                    },
                    function error(data) {
                        toaster.pop({ type: "error", body: "Error while getting department dropdown" });
    
                    }
                )
            }
            vm.GetDepartmentName();
    
              
    
            vm.showDelete=function(getRowData){
                vm.Formlist.ID= getRowData.ID;           
                $('#confirmModalFinesseAgent').modal('show');
            }
    
            vm.Delete=function(){
                var DelFinesseAgent={};
                DelFinesseAgent.ID= vm.Formlist.ID;
                DelFinesseAgent.UpdatedBy=userObj.SSOID;
                masterDataFactory.DeleteFinesseAgent(DelFinesseAgent).then(
                    function success(data) {
                        vm.GetFinesseAgent();
                        $('#confirmModalFinesseAgent').modal('hide');
                        toaster.pop({ type: "success", body: "Deleted Successfully" });    
                    },
                    function error(data) {
                        toaster.pop({ type: "error", body: "Error while Deleting agent" });
    
                    }
                );
    
    
            }
    
    
        }
    
    
    
    