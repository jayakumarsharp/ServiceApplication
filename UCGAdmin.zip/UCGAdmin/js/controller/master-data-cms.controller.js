app.controller('MasterDataCMSController', MasterCMSController)

MasterCMSController.$inject = ['masterDataFactory', 'toaster', 'appFactory', 'profileFactory', 'UCGService'];

function MasterCMSController(masterDataFactory, toaster, appFactory, profileFactory, UCGService) {
    var vm = this;
    vm.form = {};
    vm.addUser = {};
    vm.addEscalationMatrix = {};
    vm.modifyEscalation = {}
    vm.cmsModify = {};
    vm.updateUser;
    vm.cmsDelete = {};
    vm.tab = 1;
    vm.showStatus = false;
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    vm.EscalatedTypeDropDownValue = [{ "ID": "AS", "EscalatedType": "Dept to users" }, { "ID": "ST", "EscalatedType": "User escalation" }];
    vm.levels = {
        user: [
            // { "ID": 1, "UserLevel": "L1" },
            { "ID": 2, "UserLevel": "L2" },
            { "ID": 3, "UserLevel": "L3" }
        ],
        fromLevel: [
            { "ID": 1, "UserLevel": "L1" },
            { "ID": 2, "UserLevel": "L2" },
            { "ID": 3, "UserLevel": "L3" }
        ],
        toLevel: [
            { "ID": 2, "UserLevel": "L2" },
            { "ID": 3, "UserLevel": "L3" }
        ],
    }
    vm.SLAHoursDropDownValue = [];
    vm.SLADaysDropDownValue = [];
    vm.gridEscalationMatrix = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [
            { name: 'S.No',enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            // { name: 'DepartmentName', field: 'DepartmentName', cellTooltip: true, width: "20%" },
            { name: 'Type', field: 'EsclationType', 
              cellTemplate: '<span ng-if="(row.entity.EsclationType === \'ST\')"> User escalation</span>' +
                             '<span ng-if="(row.entity.EsclationType === \'AS\')"> Dept to users</span>' 
            },
            { name: 'From Level',cellTooltip: true, field: 'EsclationFromLevel'},
            { name: 'To Level',cellTooltip: true, field: 'Userlevel' },
            { name: 'SLA Period',cellTooltip: true, field: 'SLAInHours', 
              cellTemplate: '<span ng-if="(row.entity.EsclationType === \'ST\')"> {{row.entity.SLAInHours / 24}} days</span>' +
                            '<span ng-if="(row.entity.EsclationType === \'AS\')"> {{row.entity.SLAInHours}} hours</span>'  },
            // { name: 'Email', field: 'Email', cellTooltip: true, width: "23%" },
            // { name: 'Phone', field: 'Phone', cellTooltip: true, width: "15%" },
            // { name: 'Active', field: 'IsActive', width: "7%" },
            { name: 'Options', enableSorting: false,
              enableFiltering: false,
              cellTemplate: '<a href="#" ng-click="grid.appScope.vm.onModifyEscalation(row.entity)"><span class="fa fa-pencil"></span></a>' +
                              '| <a href="#" ng-click="grid.appScope.vm.onDeleteEscalation(row.entity)"><span class="fa fa-trash-o"></span></a>' 
            }
        ],
    };
    vm.gridCMSUser = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [
            { name: 'S.No', width: '6%',enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            { name: 'DepartmentName', field: 'DepartmentName', cellTooltip: true, },
            { name: 'SSO ID', field: 'SSOID', cellTooltip: true, },
            { name: 'First Name', field: 'FirstName', cellTooltip: true,  },
            { name: 'Last Name', field: 'LastName', cellTooltip: true,  },
            { name: 'DOB', field: 'DOB', cellTooltip: true, cellFilter: 'date:\'dd-MM-yyyy\'',  },
            { name: 'Designation', field: 'Designation', cellTooltip: true,  },
            { name: 'Email', field: 'Email',cellTooltip: true, },
            { name: 'Phone No', field: 'Phone',cellTooltip: true, },
            // { name: 'Active', field: 'IsActive', },
            { name: 'Options', enableSorting: false, enableFiltering: false, 
              cellTemplate: '<a href="#" ng-click="grid.appScope.vm.editUser(row.entity)"><span class="fa fa-pencil"></span></a>' + 
                            '| <a href="#" ng-click="grid.appScope.vm.onDeleteUser(row.entity)"><span class="fa fa-trash-o"></span></a>'
                            
             }
        ],
    };
    vm.gridL1Users = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [
            { name: 'S.No', width: '6%',enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            { name: 'DepartmentName', field: 'DepartmentName', cellTooltip: true,  },
            { name: 'SSO ID', field: 'SSOID', cellTooltip: true,  },
            { name: 'First Name', field: 'FirstName', cellTooltip: true,  },
            { name: 'Last Name', field: 'LastName', cellTooltip: true,  },
            { name: 'DOB', field: 'DOB', cellTooltip: true, cellFilter: 'date:\'dd-MM-yyyy\'',  },
            { name: 'Designation', field: 'Designation', cellTooltip: true,  },
            // { name: 'UserLevel', field: 'Level',  },
            { name: 'Email', field: 'Email',cellTooltip: true,  },
            { name: 'Phone No', field: 'Phone',cellTooltip: true,  },
            { name: 'Options', enableSorting: false, enableFiltering: false, 
              cellTemplate: '<a href="#" ng-click="grid.appScope.vm.editUser(row.entity)"><span class="fa fa-pencil"></span></a>' + 
                            '| <a href="#" ng-click="grid.appScope.vm.onDeleteUser(row.entity)"><span class="fa fa-trash-o"></span></a>'
                            
             }
        ],
    };
    vm.gridL3Users = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [
            { name: 'S.No', width: '6%', enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            // { name: 'DepartmentName', field: 'DepartmentName', cellTooltip: true,  },
            { name: 'SSO ID', field: 'SSOID', cellTooltip: true  },
            // { name: 'UserLevel', field: 'Level',  },
            { name: 'Email', field: 'Email',cellTooltip: true },
            { name: 'Phone No', field: 'Phone',cellTooltip: true,  },
            { name: 'Options', enableSorting: false, enableFiltering: false, 
              cellTemplate: '<a href="#" ng-click="grid.appScope.vm.editUser(row.entity, 3)"><span class="fa fa-pencil"></span></a>' + 
                            '| <a href="#" ng-click="grid.appScope.vm.onDeleteUser(row.entity, 3)"><span class="fa fa-trash-o"></span></a>'
                            
             }
        ],
    };

    var getEscalationMatrix = function () {
        UCGService.getEscalationMatrix(
            function success(response) {
                vm.gridEscalationMatrix.data = response;
            },
            function error(data) {
                appFactory.showError("Error while getting department dropdown");
            }
        )
    };

    var getCMSUsers = function (userLevel) {
        userLevel = (userLevel) ? userLevel : 1;
        UCGService.getAllCMSUser(userLevel,
            function success(response) {
                if (!userLevel || userLevel === 1) {
                    vm.gridL1Users.data = response;
                } else {
                    if (userLevel === 2) {
                        vm.gridCMSUser.data = response;
                    } else {
                        vm.gridL3Users.data = response;
                    }
                }
            },
            function error(data) {
                appFactory.showError("Error while getting department dropdown");
            }
        )
    };

    vm.deleteUser = function (ssoId) {
        UCGService.deleteUser(ssoId,
            function success(response) {
                vm.gridCMSUser.data = response;
            },
            function error(data) {
                appFactory.showError("Error while getting department dropdown");
            }
        )
    }

    vm.createCMSUser = function () {
        var userLevel = vm.tab;
        if (vm.addUser.ssoUser.SSOID.toLowerCase() !== vm.addUser.AgentSSOID.toLowerCase()) {
            vm.addUser.SSOStatus = 'invalid';
            return;
        }
        var cmsData = {
            DepartmentId: Number(vm.addUser.ssoUser.departmentId),
            SSOID: vm.addUser.ssoUser.SSOID,
            UserLevel: userLevel,
            PhoneNo: vm.addUser.ssoUser.mobile,
            FirstName :  vm.addUser.firstName,
            Gender :  vm.addUser.ssoUser.gender,
            LastName :  vm.addUser.lastName,
            DOB : (vm.addUser.ssoUser.dateOfBirth) ?  moment(vm.addUser.ssoUser.dateOfBirth).format('YYYY-MM-DD HH:mm:ss') : null,
            Designation :  vm.addUser.ssoUser.designation,
            Email: vm.addUser.email,
            Active: true,
        };
        UCGService.createCMSUser(cmsData,
            function success(data) {
                getCMSUsers(userLevel);
                $('#AddCMSUser').modal('hide');
                appFactory.showSuccess("Added Successfully");
            },
            function error(data) {
                appFactory.showError("Error while creating User");

            }
        );
    }

    vm.onDeleteEscalation = function(rowData) {
        vm.deleteEscalationID = '';
        vm.deleteEscalationID = rowData.EsclationID;
        $('#confirmCMSEsclation').modal('show');
    };

    vm.onDeleteEscalationMatrix = function() {
        UCGService.deleteEscalationMatrix(vm.deleteEscalationID,
            function success(data) {
                if (data === 200) {
                    getEscalationMatrix();
                    vm.deleteEscalationID = '';
                    $('#confirmCMSEsclation').modal('hide');
                    appFactory.showSuccess("Deleted Successfully");
                } else {
                    appFactory.showError("Error while Deleting");
                }
            },
            function error(data) {
                appFactory.showError("Error while Deleting");
            }
        )
    };

    var isEscalationAlreadyExist = function(escalationObj, isUpdate) {
        var isEscalationExist = false;
        if (!isUpdate) {
            escalationObj.escalationTypeObj = getEscalationType(escalationObj.escalatedType);
            angular.forEach(vm.gridEscalationMatrix.data, function(value, key) {
                if (value.EsclationFromLevel === escalationObj.escalationFromLevel && 
                    value.Userlevel === escalationObj.escalationToLevelObj.ID &&
                    escalationObj.escalationTypeObj.ID === value.EsclationType) {
                    isEscalationExist = true;
                }
            });
        } else {
            angular.forEach(vm.gridEscalationMatrix.data, function(value, key) {
                // if (escalationObj.departmentID === value.DepartmentID || escalationObj.departmentName === value.DepartmentID) {
                if (escalationObj.origEscalationType !== escalationObj.escalationType) {
                    if (value.EsclationFromLevel === escalationObj.escalationFromLevel && 
                        value.Userlevel === escalationObj.escalationToLevelObj.ID &&
                        escalationObj.escalationType === value.EsclationType) {
                        isEscalationExist = true;      
                    }
                }
                // }
            });
        }
        if (isEscalationExist) {
            appFactory.showToasterErr("Escalation Already Exist");
            return true;
        }
        return false;
    };

    var getEscalationType = function(type) {
        var escalationObj = {};
        if (type.toLowerCase() === 'dept to users') {
            escalationObj = { "ID": "AS", "EscalatedType": "Dept to users" }
        } else {
            escalationObj = { "ID": "ST", "EscalatedType": "User escalation" }
        }
        return escalationObj;
    };

    vm.onChangeEscalationType = function() {
        if (vm.addEscalationMatrix.escalatedType !== 'Dept to users') {
            vm.addEscalationMatrix.escalationFromLevel = '';
            vm.addEscalationMatrix.escalationToLevel = '';
            return;
        }
        vm.addEscalationMatrix.escalationFromLevel = 2;
        vm.addEscalationMatrix.escalationToLevel = 'L1';
        vm.onSelectFormLevel(true, true);

    };

    vm.createEscationMatrix = function () {
        var isEscalationExist = isEscalationAlreadyExist(vm.addEscalationMatrix);
        if (isEscalationExist) {
            return;
        }
        var cmsData = {
            DepartmentID: Number(userObj.departmentId),
            EsclationType: vm.addEscalationMatrix.escalationTypeObj.ID,
            Userlevel: vm.addEscalationMatrix.escalationToLevelObj.ID,
            EsclationFromLevel: vm.addEscalationMatrix.escalationFromLevel,
            SLAInHours: (vm.addEscalationMatrix.escalationTypeObj.ID === 'AS') ? vm.addEscalationMatrix.SLAHours : vm.addEscalationMatrix.SLAHours * 24,
            Email: '',
            Phone: '',
            IsActive: 1 ,
            LastModifiedBy: userObj.SSOID,
        };
        UCGService.createEscalationMatrix(cmsData,
            function success(data) {
                if (data === 200) {
                    getEscalationMatrix();
                    $('#AddCMSEscalation').modal('hide');
                     appFactory.showSuccess("Added Successfully");
                } else {
                    appFactory.showError("Error while Adding Escalation");
                }
            },
            function error(data) {
                appFactory.showError("Error while Adding Escalation");
            }
        );
    };

    
    vm.onModifyEscalation = function (getrowdata) {
        vm.modifyEscalation = {};
        vm.modifyEscalation.DepartmentName = getrowdata.DepartmentName;
        vm.modifyEscalation.departmentID = getrowdata.DepartmentID;
        vm.modifyEscalation.escalationFromLevel = getrowdata.EsclationFromLevel;
        var isStatus = (getrowdata.EsclationType === 'AS');
        var esclationToLevelObj = getEsclationToLevel(getrowdata.EsclationFromLevel, isStatus);
        vm.modifyEscalation.escalationToLevel  = esclationToLevelObj.Level;
        vm.modifyEscalation.escalationToLevelObj  = esclationToLevelObj;
        vm.modifyEscalation.escalationID = getrowdata.EsclationID;
        vm.modifyEscalation.escalationType = getrowdata.EsclationType;
        vm.modifyEscalation.SLAHours =  getrowdata.SLAInHours;
        vm.modifyEscalation.escaltionId = getrowdata.EsclationID;
        vm.modifyEscalation.origFromLevel = getrowdata.EsclationFromLevel;
        vm.modifyEscalation.origToLevel = esclationToLevelObj.ID;
        vm.modifyEscalation.origEscalationType = getrowdata.EsclationType;
        $('#ModifyCMSEscalation').modal('show');
    };

    vm.onUpdateEscation = function() {
        var isEscalationExist = isEscalationAlreadyExist(vm.modifyEscalation, true);
        if (isEscalationExist) {
            return;
        }
        var cmsData = {
            EsclationID: vm.modifyEscalation.escalationID,
            EsclationType: vm.modifyEscalation.escalationType,
            Userlevel: vm.modifyEscalation.escalationToLevelObj.ID,
            DepartmentID: Number(userObj.departmentId),
            SLAInHours: (vm.modifyEscalation.escalationType === 'AS') ? vm.modifyEscalation.SLAHours : vm.modifyEscalation.SLAHours * 24,
            Email: '',
            Phone: '',
            IsActive: 1,
            LastModifiedBy: userObj.SSOID,
            EsclationFromLevel: vm.modifyEscalation.escalationFromLevel,
        };
        UCGService.updateEscalationMatrix(cmsData,
            function success(data) {
                if (data === 200) {
                    getEscalationMatrix();
                    $('#ModifyCMSEscalation').modal('hide');
                     appFactory.showSuccess("Updated Successfully");
                } else {
                    appFactory.showError("Error while Adding Agent");
                }
            },
            function error(data) {
                appFactory.showError("Error while Adding Agent");
            }
        )
    };

    vm.onTabNav = function(tab) {
        vm.tab = tab;
        getCMSUsers(tab);
    };

    var isSSOIDAlreadyExist = function(data, ssoID) {
        var isSSOIDExist = false;
        if (!data || !data.length) {
            return isSSOIDExist;
        }
        angular.forEach(data, function(value,key) {
            value.SSOID = value.SSOID.trim();
            if (value.SSOID.toUpperCase() === ssoID.toUpperCase()) {   
                isSSOIDExist = true;      
            }
        });
        return isSSOIDExist;
    };

    vm.validateSSOID = function(isL1User) {
        if (!isL1User) {
            vm.addUser.showStatus = false;
            vm.addUser.ssoUser = {};
            vm.addUser.deparmtment = "";
        }
        var ssoID = vm.addUser.AgentSSOID;
        var isSSOIDExist = isSSOIDAlreadyExist(vm.gridCMSUser.data, ssoID);
        var isSSOIDExistL1User = isSSOIDAlreadyExist(vm.gridL1Users.data, ssoID);
        var isSSOIDExistL1User = isSSOIDAlreadyExist(vm.gridL3Users.data, ssoID);
        if (isSSOIDExist || isSSOIDExistL1User) {
            var errMsg = '';
            if (isL1User) {
                errMsg = (isSSOIDExistL1User) ? 'SSOID already exist' : 'SSOID already exist for user L2 or L3'
            } else {
                errMsg = (isSSOIDExist) ? 'SSOID already exist' : 'SSOID already exist for user L1'
            }
            vm.addUser.isValidSSOID = false;
            vm.addUser.showStatus = true;
            vm.addUser.SSOStatus = 'Invalid';
            appFactory.showToasterErr(errMsg);
            return;
        }
        vm.addUser.isValidSSOID = true;
        profileFactory.GetSSOUserRoles(vm.addUser.AgentSSOID).then(
            function success(data) {
                if (data.data && data.data !== 'null') {
                    setUserRoles(data.data);
                } else {
                    cbfValidateDeptUser();
                }                    
            }
        );
    };

    vm.onSelectFormLevel = function(isFromAdd, isStatus) {
        if (isFromAdd) {
            var escalationToLevel = getEsclationToLevel(vm.addEscalationMatrix.escalationFromLevel, isStatus);
            vm.addEscalationMatrix.escalationToLevel = escalationToLevel.Level;
            vm.addEscalationMatrix.escalationToLevelObj = escalationToLevel;
        } else {
            var escalationToLevel = getEsclationToLevel(vm.modifyEscalation.escalationFromLevel, isStatus);
            vm.modifyEscalation.escalationToLevel = escalationToLevel.Level;
            vm.modifyEscalation.escalationToLevelObj = escalationToLevel;
        }
    };

    var getEsclationToLevel = function(fromLevelID, isStatus) {
        var esclationToLevel = {};
        if (isStatus) {
            esclationToLevel = {ID: 1, Level: 'L1'}
        } else if (fromLevelID === 1) {
            esclationToLevel = {ID: 2, Level: 'L2'}
        } else {
            esclationToLevel = {ID: 3, Level: 'L3'}
        }
        return esclationToLevel;
    };

    var setUserRoles = function(data) {
        vm.addUser.validflag = false;
        vm.addUser.UserRoles = [];
        vm.addUser.showStatus = true;
        if (data != null && data != undefined && data != 'null') {
            var userDetails = JSON.parse(data); 
            var departmentId = appFactory.getDepartmentFromRole(data, true);
            if (!departmentId) {
                cbfValidateDeptUser();
                return;    
            }   
            vm.addUser.validflag = true;
            vm.addUser.SSOStatus = 'Valid';
            getUserDetailsBySSOID(userDetails.sAMAccountName, true, departmentId);
            $('#AddFinesseAgent').modal('show'); 
        } else {
           
        }
    }

    var getUserDetailsBySSOID = function(ssoID, isCreate, departmentId) {
        if (!ssoID) {
            return;
        }
        profileFactory.GetSSOUserDetails(ssoID).then(
            function success(data) {
                var ssoUser = JSON.parse(data.data);
                if (isCreate) {
                    vm.addUser.ssoUser = ssoUser;
                    vm.addUser.deparmtment =  ssoUser.department;
                    vm.addUser.ssoUser.departmentId =  departmentId;
                } else {
                    vm.updateUser.designation = ssoUser.designation;
                    vm.updateUser.dob = (ssoUser.dateOfBirth) ? moment(ssoUser.dateOfBirth).format('DD-MM-YYYY') : null;
                    vm.updateUser.gender = ssoUser.gender;
                }
            }
        );
    }
    var cbfValidateDeptUser = function() {
        vm.addUser.showStatus = true;
        vm.addUser.validflag = false;
        vm.addUser.SSOStatus = 'Invalid';
        vm.addUser.ssoUser = {};
        vm.addUser.deparmtment = '';
    }
    vm.showAddCmsEscaltionMatrix = function () {
        vm.SSOStatus = '';
        vm.showStatus = false;
        vm.addUser = {};
        vm.addEscalationMatrix = {};
        vm.modifyEscalation.Email = '';
        vm.modifyEscalation.Phone = '';
        $('#AddCMSEscalation').modal('show');
        
    };
    
    vm.showAddCmsUser = function () {
        vm.SSOStatus = '';
        vm.showStatus = false;
        vm.addUser = {};
        $('#AddCMSUser').modal('show');
 
    };

    vm.onDeleteUser = function(rowData, isL1User) {
        vm.deleteUserID = '';
        vm.deleteUserID = rowData.UserMapID;
        $('#confirmCMSUser').modal('show');
    };

    vm.onDeleteUserMapping = function() {
        var isL1User = (vm.tab === 1);
        UCGService.deleteUserMapping(vm.deleteUserID, isL1User,
            function success(data) {
                if (data === 200) {
                    getCMSUsers(vm.tab);
                    vm.deleteUserID = '';
                    $('#confirmCMSUser').modal('hide');
                    appFactory.showSuccess("Deleted Successfully");
                } else {
                    appFactory.showError("Error while Deleting");
                }
            },
            function error(data) {
                appFactory.showError("Error while Deleting");
            }
        )
    };

    vm.editUser = function(rowData) {
        vm.updateUser = {};
        getUserDetailsBySSOID(rowData.SSOID);
        var udpateUser = {
            ssoID: rowData.SSOID,
            deparmtment: rowData.DepartmentName,
            userLevel: rowData.Level,
            email: rowData.Email,
            phone: Number(rowData.Phone),
            departmentId: rowData.DepartmentID,
            firstName: (rowData.FirstName) ? rowData.FirstName.trim() : '',
            lastName: (rowData.LastName) ? rowData.LastName.trim() : '',
        }
        vm.updateUser = udpateUser;
        $('#update-user-model').modal('show');
    };

    // vm.updateUser = function() {
    //     $('#UpdateCMSUser').modal('hide');
    // }

    vm.updateCMSUser = function(isL1User) {
        var isL1User = (vm.tab === 1);
        var updateUsr = vm.updateUser;
        var cmsData = {
            DepartmentId: Number(updateUsr.departmentId),
            SSOID: updateUsr.ssoID,
            UserLevel: updateUsr.userLevel,
            PhoneNo: updateUsr.phone.toString(),
            FirstName :  updateUsr.firstName,
            Gender :  updateUsr.gender,
            LastName :  updateUsr.lastName,
            DOB :  (updateUsr.dob) ? moment(updateUsr.dob).format('YYYY-MM-DD HH:mm:ss') : null,
            Designation :  updateUsr.designation,
            Email: updateUsr.email,
            isL1User : isL1User,
            Active: true
        };
        UCGService.updateCMSUser(cmsData,
            function success(data) {
                getCMSUsers(vm.tab);
                $('#update-user-model').modal('hide');
                appFactory.showSuccess("Updated Successfully");
            },
            function error(data) {
                appFactory.showError("Error while creating User");

            }
        );
    };
    
    var getDepartments = function () {
        masterDataFactory.GetDepartmentName().then(
            function success(data) {
                vm.DepartmentDropDownValue = data.data;
            },
            function error(data) {
                appFactory.showError("Error while getting department dropdown");
            }
        );
    };

    var generateValues = function(isHours, isWholeNumers, maxValue) {
        var key = 'ID';
        var value = (isHours) ? 'SLAHours' : 'SLADays'
        var values = [];
        for (var i = 1; i <= maxValue; i ++ ) {
            var obj = {};
            obj[key] = i;
            obj[value] = (isWholeNumers) ? i - 1 : i;
            values.push(obj);
        }
        return values;
    };

    var generateEsaclationMatrixDropDownValues = function() {
        vm.SLAHoursDropDownValue = generateValues(true, true, 72);
        vm.SLADaysDropDownValue = generateValues(false, false, 31);
    };

    var init = function() {
        // userObj = {};
        // userObj.SSOID = 'esanchar2.test';
        // userObj.departmentId = 5800002;
        generateEsaclationMatrixDropDownValues();
        getCMSUsers();
        getEscalationMatrix();
        getDepartments();
    }

    init();
}
