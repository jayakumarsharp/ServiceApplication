app.controller('MasterDataServIntuitController', MasterCMSController)

MasterCMSController.$inject = ['masterDataFactory', 'toaster', 'appFactory', 'profileFactory', 'UCGService'];

function MasterCMSController(masterDataFactory, toaster, appFactory, profileFactory, UCGService) {
    var vm = this;
    vm.form = {};
    vm.addUser = {};
    vm.addEscalationMatrix = {};
    vm.modifyEscalation = {}
    vm.cmsModify = {};
    vm.cmsDelete = {};
    vm.tab = 1;
    vm.showStatus = false;
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));

    vm.levels = {
        user: [{
                "ID": "Administrator",
                "UserLevel": "Administrator"
            },
            {
                "ID": 'Maker',
                "UserLevel": "Maker"
            },
            {
                "ID": 'Checker',
                "UserLevel": "Checker"
            }
        ]
    }

    vm.gridCMSUser = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [{
                name: 'S.No',
                width: '6%',
                enableFiltering: false,
                enableSorting: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'SSO ID',
                field: 'SSO_NAME',
                cellTooltip: true,
            },
            {
                name: 'User Type',
                field: 'UserType',
                width: "30%"
            },
            // {
            //     name: 'Active',
            //     field: 'IsActive',
            //     width: "10%"
            // },
            {
                name: 'Options', enableSorting: false,
                enableFiltering: false,
                width: '15%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.vm.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> |<a href="#" ng-click="grid.appScope.vm.onDeleteUser(row.entity)"><span class="fa fa-trash-o"></span></a>'
            }
        ],
    };
    vm.showedit = false;
    vm.showEdit = function (getRowData) {
        vm.showedit = true;
        vm.addUser = {};
        vm.addUser.ID = getRowData.Id;
        vm.addUser.AgentSSOID = getRowData.SSO_NAME;

        for (var i = 0; i < vm.levels.user.length; i++) {
            if (vm.levels.user[i].ID == getRowData.UserType) {
                vm.addUser.UserLevel = vm.levels.user[i];
            }
        }

        $('#AddCMSUser').modal('show');
    }

    var getCMSUsers = function () {
        masterDataFactory.GetServIntuitusers().then(
            function success(data) {
                vm.gridCMSUser.data = data.data;
            },
            function error(data) {
                appFactory.showError("Error while getting department dropdown");
            }
        )
    };

    vm.deleteUser = function (ssoId) {
        masterDataFactory.deleteUser(ssoId).then(
            function success(response) {
                vm.gridCMSUser.data = response;
            },
            function error(data) {
                appFactory.showError("Error while getting department dropdown");
            }
        )
    }
    vm.updateCMSUser = function () {

        var cmsData = {
            Id: vm.addUser.ID,
            UserName: vm.addUser.AgentSSOID,
            UserType: vm.addUser.UserLevel.ID,
            CreatedBy: userObj.SSOID,
            IsActive: true
        };
        masterDataFactory.UpdateServIntuituser(cmsData).then(
            function success(data) {
                getCMSUsers();
                $('#AddCMSUser').modal('hide');
                appFactory.showSuccess("User updated Successfully");
            },
            function error(data) {
                appFactory.showError("Error while creating User");

            }
        );
    }
    vm.createCMSUser = function () {
        if (vm.addUser.ssoUser.SSOID.toLowerCase() !== vm.addUser.AgentSSOID.toLowerCase()) {
            vm.addUser.SSOStatus = 'invalid';
            return;
        }
        var cmsData = {
            UserName: vm.addUser.ssoUser.SSOID,
            UserType: vm.addUser.UserLevel.ID,
            CreatedBy: userObj.SSOID
        };
        masterDataFactory.CreateServIntuitusers(cmsData).then(
            function success(data) {
                getCMSUsers();
                $('#AddCMSUser').modal('hide');
                appFactory.showSuccess("User added Successfully");
            },
            function error(data) {
                appFactory.showError("Error while creating User");

            }
        );
    }


    vm.validateSSOID = function () {
        var isSSOIDExist = false;
        var ssoID = vm.addUser.AgentSSOID;
        angular.forEach(vm.gridCMSUser.data, function (value, key) {
            value.SSOID = value.SSO_NAME.trim();
            if (value.SSO_NAME.toUpperCase() === ssoID.toUpperCase()) {
                isSSOIDExist = true;
            }
        });
        if (isSSOIDExist) {
            vm.addUser.isValidSSOID = false;
            appFactory.showError("SSO ID already exist");
        } else {
            vm.addUser.isValidSSOID = true;
            profileFactory.GetSSOUserRoles(vm.addUser.AgentSSOID).then(
                function success(data) {
                    setUserRoles(data.data);
                },
                function error(data) {

                }
            );
        }
    };

    var setUserRoles = function (data) {
        vm.addUser.validflag = false;
        vm.addUser.UserRoles = [];
        vm.addUser.showStatus = true;
        if (data != null && data != undefined && data != 'null') {
            var userDetails = JSON.parse(data);
            vm.addUser.validflag = true;
            vm.addUser.SSOStatus = 'Valid';
            profileFactory.GetSSOUserDetails(userDetails.sAMAccountName).then(
                function success(data) {
                    vm.addUser.ssoUser = JSON.parse(data.data);
                    vm.addUser.deparmtment = vm.addUser.ssoUser.department;
                }
            );
            //$('#AddFinesseAgent').modal('show');
        } else {
            vm.addUser.validflag = false;
            vm.addUser.SSOStatus = 'Invalid';
            vm.addUser.ssoUser = {};
            vm.addUser.deparmtment = '';
        }
    }



    vm.showAddCmsUser = function () {
        vm.SSOStatus = '';
        vm.showStatus = false;
        vm.addUser = {};
        $('#AddCMSUser').modal('show');
        vm.showedit = false;

    };

    vm.onDeleteUser = function (rowData) {
        vm.deleteUserID = '';
        vm.deleteUserID = rowData.Id;
        vm.UserName = rowData.SSO_NAME;
        vm.UserType = rowData.UserType;
        $('#confirmCMSUser').modal('show');
    };

    vm.onDeleteUserMapping = function () {
        var cmsData = {
            Id: vm.deleteUserID,
            UserName: vm.UserName,
            UserType: vm.UserType,
            CreatedBy: userObj.SSOID,
            IsActive: false
        };
        masterDataFactory.UpdateServIntuituser(cmsData).then(
            function success(data) {
                getCMSUsers();
                vm.deleteUserID = '';
                vm.UserName = '';
                vm.UserType = '';
                $('#confirmCMSUser').modal('hide');
                appFactory.showSuccess("User deleted Successfully");
            },
            function error(data) {
                appFactory.showError("Error while Deleting");
            }
        )
    };


    var init = function () {
        userObj = {};
        userObj.SSOID = 'esanchar2.test';
        getCMSUsers();
    }

    init();
}