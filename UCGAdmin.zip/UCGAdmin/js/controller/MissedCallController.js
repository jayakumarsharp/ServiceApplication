app.controller('MissedCallController',function($scope, $rootScope){


  $scope.missedCallData = [
        { 'Department': 'Social Security', 'CalledNumber': '8888988889', 'ContactNumber': '9999999999', 'CallDateTime': '18/08/2017', 'Status': 'Pending', 'Active': true },
        { 'Department': 'Health', 'CalledNumber': '8888988889', 'ContactNumber': '9999999999', 'CallDateTime': '18/08/2017', 'Status': 'Pending', 'Active': true }
    ];


   /* $scope.ShowAssignMissedCall=function(){
        alert('test');
    };
*/

})