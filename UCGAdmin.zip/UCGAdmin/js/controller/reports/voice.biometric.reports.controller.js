angular.module('adminApp')
       .controller('VoiceBiometricReportsContoller', VoiceBiometricReportsContoller);
        VoiceBiometricReportsContoller.$inject = ['$http', '$scope', 'voiceBioMetricFactory', 'uiGridExporterConstants', 'appFactory', 'uiGridExporterService', 'exportFactory', 'ReportsFactory'];
        function VoiceBiometricReportsContoller($http, $scope, voiceBioMetricFactory, uiGridExporterConstants, appFactory, uiGridExporterService, exportFactory, ReportsFactory) {

    var vm = this;

    vm.types = voiceBioMetricFactory.reportTypes;
    vm.filter = {
		
        startDate: new Date(),
        endDate: new Date(),
        reportType: '',
    };

    /* for date time picker **/
    vm.open = {};
	
    vm.openCalendar = function (e, date) {
        vm.open = {};
        vm.open[date] = !vm.open[date];
        e.preventDefault();
        e.stopPropagation();
        vm.open[date] = true;
    };

    vm.voiceBiometricGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        },
        exporterHeaderFilterUseName: function (displayName) {
          return 'col: ' + name;
        },
        exporterCsvFilename: 'voice_biometric_report.xlsx',
        exporterPdfFilename: 'voice_biometric_report.pdf',
        exporterPdfDefaultStyle: {
          fontSize: 10
        },
        exporterPdfTableStyle: {
          margin: [0, 30, 0, 15]
        },
        exporterPdfTableHeaderStyle: {
          fontSize: 10,
          bold: true,
          italics: true,
          color: 'red'
        },
        exporterPdfHeader: {
          margin: [2, 14, 0, 0],
          text: 'Voice Biometric Report',
          style: 'headerStyle',
          alignment: 'center'
        },
        exporterPdfFooter: function (currentPage, pageCount) {
          return {
            text: currentPage.toString() + ' of ' + pageCount.toString(),
            style: 'footerStyle'
          };
        },
        exporterPdfCustomFormatter: function (docDefinition) {
          docDefinition.styles.headerStyle = {
            fontSize: 22,
            bold: true,
            alignment: 'left'
          };
          docDefinition.styles.footerStyle = {
            fontSize: 10,
            bold: true,
            alignment: 'center'
          };
          return docDefinition;
        },
        exporterPdfOrientation: 'landscape',
        exporterPdfPageSize: 'A4',
        exporterPdfMaxGridWidth: 720,
        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
    };

    vm.onSearchReports = function() {
        appFactory.ShowLoader();
        var params = {
            startDate : moment(vm.filter.startDate).format('MM/DD/YYYY h:mm:ssA'),
            endDate : moment(vm.filter.endDate).format('MM/DD/YYYY h:mm:ssA'),
            type : vm.filter.reportType,
        }
        /* Reading data from file all are handled in service **/
        voiceBioMetricFactory.getReportsPath(params, cbsGetReports);
    };

    var cbsGetReports = function(res) {
        if (res && res.data === 'Failure') {
            cbfActions();
        }
        vm.parsedData = voiceBioMetricFactory.parsedReportsData;
        setColumDef();
		appFactory.HideLoader();
        vm.voiceBiometricGrid.data = vm.parsedData;
        if (!$scope.gridApi) {
            vm.onSearchReports();
        } else {
            $scope.gridApi.core.refresh();
        }
    };

    var cbfActions = function() {
        appFactory.HideLoader();
        appFactory.showToasterErr('Internal server error');
    };

    vm.exportExcel = function () {
        var exportColumnHeaders = uiGridExporterService.getColumnHeaders($scope.gridApi.grid, uiGridExporterConstants.ALL);
        var exportData = uiGridExporterService.getData($scope.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
        var docDefinition = uiGridExporterService.prepareAsPdf($scope.gridApi.grid, exportColumnHeaders, exportData);
        var tableData = docDefinition.content[0].table.body;
        // vm.excelData = JSON.parse(angular.toJson(vm.tsreportGrid.data));
        exportFactory.getExcel(tableData, 'VoiceBiometricReports' + '.xlsx');
    };
    
    vm.exportPDF = function () {
        var exportColumnHeaders = uiGridExporterService.getColumnHeaders($scope.gridApi.grid, uiGridExporterConstants.ALL);
        var exportData = uiGridExporterService.getData($scope.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
        var docDefinition = uiGridExporterService.prepareAsPdf($scope.gridApi.grid, exportColumnHeaders, exportData);
        if (uiGridExporterService.isIE() || navigator.appVersion.indexOf("Edge") !== -1) {
          uiGridExporterService.downloadPDF("VoiceBiometricReports.pdf", docDefinition);
        } else {
          pdfMake.createPdf(docDefinition).download("VoiceBiometricReports.pdf");
        }
    };

    var setColumDef = function() {
        var reportType = vm.filter.reportType.DISPLAY;
        var columnDefs = [];
        switch (reportType) {
            case (vm.types.ENROLL.DISPLAY):
            {
                columnDefs = [
                    { name: 'Speaker ID', field: 'SPEAKER_ID', cellTooltip: true },
                    { name: 'Timestamp', field: 'TIMESTAMP', cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
                ]
                break;
            }
            case ( vm.types.VOICE_PRINT.DISPLAY):
                columnDefs = [
                    { name: 'Speaker ID', field: 'SPEAKER_ID', cellTooltip: true },
                    { name: 'Timestamp', field: 'TIMESTAMP', cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
                    { name: 'Activity Type', field: 'ACTIVITYTYPE', cellTooltip: true },
                ]
                break;
            case (vm.types.VERIFICATION.DISPLAY):
                columnDefs = [
                    { name: 'Dates', field: 'DATES', cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
                    { name: 'Verified', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.VERIFIED"> {{row.entity.VERIFIED.slice(2, row.entity.VERIFIED.length-1)}} </span>' },
                    { name: 'Wrong Phrase', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.WRONGPHRASE"> {{row.entity.WRONGPHRASE.slice(2, row.entity.WRONGPHRASE.length-1)}} </span>' },
                    { name: 'Playback', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.PLAYBACK"> {{row.entity.PLAYBACK.slice(2, row.entity.PLAYBACK.length-1)}} </span>' },
                    { name: 'VP Mismatch', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.VPMISMATCH"> {{row.entity.VPMISMATCH.slice(2, row.entity.VPMISMATCH.length-1)}} </span>' },
                    { name: 'Audio Errors', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.AUDIOERRORS"> {{row.entity.AUDIOERRORS.slice(2, row.entity.AUDIOERRORS.length-1)}} </span>' },
                    { name: 'Verif Attempts', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.VERIFICATIONATTEMPTS"> {{row.entity.VERIFICATIONATTEMPTS.slice(2, row.entity.VERIFICATIONATTEMPTS.length-1)}} </span>' },
                ]
                break;
            case (vm.types.MOST_SUCCES.DISPLAY):
                columnDefs = [
                    { name: 'Speaker ID', field: 'SPEAKER_ID', cellTooltip: true },
                    { name: 'Verified', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.VERIFIED"> {{row.entity.VERIFIED.slice(2, row.entity.VERIFIED.length-1)}} </span>' },
                    { name: 'Total Attempts', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.TOTALATTEMPTS"> {{row.entity.TOTALATTEMPTS.slice(2, row.entity.TOTALATTEMPTS.length-1)}} </span>' },
                ]
                break;
            case ( vm.types.LEST_SUCCES.DISPLAY):
                    columnDefs = [
                        { name: 'Speaker ID', field: 'SPEAKER_ID', cellTooltip: true },
                        { name: 'Verified', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.VERIFIED"> {{row.entity.VERIFIED.slice(2, row.entity.VERIFIED.length-1)}} </span>' },
                        { name: 'Total Attempts', cellTooltip: true, cellTemplate: '<span ng-if="row.entity.TOTALATTEMPTS"> {{row.entity.TOTALATTEMPTS.slice(2, row.entity.TOTALATTEMPTS.length-1)}} </span>' },
                    ]     
                break;
            case (vm.types.SCOPE_LIST.DISPLAY):
                columnDefs = [
                    { name: 'Scope ID', field: 'SCOPE_ID', cellTooltip: true },
                    { name: 'Name', field: 'NAME', cellTooltip: true },
                ]
                break;
            }
        vm.voiceBiometricGrid.columnDefs = columnDefs;
        // vm.gridApi.core.refresh();
    };
    
    var init = function init() {

    }

    init();

};