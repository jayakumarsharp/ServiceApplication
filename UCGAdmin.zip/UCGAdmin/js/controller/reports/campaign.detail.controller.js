
  angular
    .module('adminApp')
    .controller('CampaignDetailController', CampaignDetailController);

    CampaignDetailController.$inject = ['uiGridExporterConstants','$scope','appFactory','uiGridExporterService', 'toaster', 'exportFactory', 'ReportsFactory','$location'];

  function CampaignDetailController(uiGridExporterConstants,$scope,appFactory, uiGridExporterService, toaster, exportFactory, ReportsFactory,$location) {

    var vm = this;
 
    // vm.campaigns = [
    //   {'Id': 1, 'Value': 'Testcampaign1'},
    //   {'Id': 2, 'Value': 'Testcampaign2'},
    //   {'Id': 3, 'Value': 'Testcampaign3'}
    // ];
    // vm.campaigns.splice(0, 0, { Id: 0, Value: "ALL" });

  //  var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));

  //  var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? '-1' : $rootScope.departmentName;
  //  var departmentID = '-1';

  //  if (!departmentName) {
  //       departmentID = -1;
  //   } else if (departmentName.ID) {
  //       departmentID = departmentName.ID;
  //   } else {
  //       departmentID = departmentName;
  //   }



  
  vm.getCampList = function (depId){
    ReportsFactory.getdeptVoiceCampaignList(depId).then(
      function success(response) {
        vm.campaigns = response.data;
      //  if (vm.campaigns) {
        //  vm.campaigns.splice(0, 0, { LCMCampaignName: 'ALL', CampaignName: "ALL" });
        //  vm.campaign = 'ALL'
       // }
        if (!vm.campaigns) {
          toaster.pop({ type: "error", body: "No Campaign Available" });
        }
      },
      function error(data) {
        toaster.pop({ type: "error", body: "Error while retreiving Outcome Report Data" });
      }
    )}

    if(appFactory.rights.type !== appConst.RIGHTS_TYPES.SUPER_ADMIN){   
      vm.getCampList(-1)
    }
    
    ReportsFactory.getalldepartment().then(
     function success(data) {
        vm.Departments = data.data;
         if (!vm.Departments) {
            toaster.pop({ type: "error", body: "No department Available" });
         }
     },
     function error(data) { 

     })
    


    vm.CampaignDetailGrid = {
      columnDefs: [

{ name: 'Call Time',displayName: 'Call Time', field: 'StartTime', cellTooltip: true,cellFilter: 'date:\'dd-MM-yy HH:mm\''},

{ name: 'Mobile No',displayName: 'Mobile No', field: 'MobileNo', cellTooltip: true},

{ name: 'Campaign',displayName: 'Campaign', field: 'CampaignId', cellTooltip: true,

// cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.CampaignId.substring(row.entity.CampaignId.indexOf("_VOICE_")+7,row.entity.CampaignId.length)}}</div>'

},

{ name: 'OutCome',displayName: 'OutCome', field: 'OutCome', cellTooltip: true },

{ name: 'Message',displayName: 'Message', field: 'Meassage', cellTooltip: true },

        // { name: 'SUCCESSCOUNT',displayName: 'Selected count(Success)', field: 'SUCCESSCOUNT', cellTooltip: true },

      ],
      enableColumnResizing: true,
      paginationPageSizes: [10, 20, 30],
      paginationPageSize: 10,
      enableColumnMenus: false,
      enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
      enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
      exporterHeaderFilterUseName: function( displayName ){ return 'col: ' + name; },
      exporterCsvFilename: 'exportedData.xlsx',
      exporterPdfFilename: 'pdfFileFormat.pdf',
      exporterPdfDefaultStyle: { fontSize: 10 },
      exporterPdfTableStyle: { margin: [0, 30, 0, 15] },
      exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
      exporterPdfHeader: {
        margin: [2, 14, 0, 0],
        text: 'Campaign Detail Report',
        style: 'headerStyle',
        alignment: 'center'
      },
      // exporterPdfHeader: {
      //   columns: [
      //     {
      //       image: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QBgRXhpZgAASUkqAAgAAAACADEBAgAHAAAAJgAAAGmHBAABAAAALgAAAAAAAABHb29nbGUAAAMAAJAHAAQAAAAwMjIwAqAEAAEAAAB8AAAAA6AEAAEAAAB7AAAAAAAAAP/bAEMAAgEBAgEBAgICAgICAgIDBQMDAwMDBgQEAwUHBgcHBwYHBwgJCwkICAoIBwcKDQoKCwwMDAwHCQ4PDQwOCwwMDP/bAEMBAgICAwMDBgMDBgwIBwgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAHsAfAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP1V1z4P6B+w58JJvE2n2h1fxPIIYZLm/naRZJCDkKoK/uwc4HbiuB0v/gpT4mRYm1DQNGmym/FnE4Ib6mRh09q9C/4KZ66IfhtpNiH/AOPi68zHrtxXxpFzCtfK1aUKL9nTjorHpKUqms9z7I8C/wDBSLwzrO1NZ0y701/4iq7l/KvaPAXxt8IfEuFH0vWLSWR/uxF9so7/AHa/M/YO4Vh6N0NRrFPZ3cRsJp7e8aRfJMP8LEjFbUq39xMU6Ol0frStnGcfL16H1pJLFAa8i8U/F2b9nD9mnTtT1u4/tDVY4I41EvWeVgMD8M/pXGfBD/gopofjS4jsPFFuvh2+kGQ7/wCrcmvTth+dQnGzZyP2lrn0b9iT/Jp6WqZ/+vTNNvYNXtEuLaaOeCQbkdDkEVY8srXT9Uw/SKMueY37MnvTTbJ6U/5qTJqvqtP+UXOM+yL70n2JPSpNxo3Gj6rT/lDnI/sSelKLNAelPyacoNH1Wn/KHOMeyQp0qP7DHVnJppBo+q0/5R+0Z8X/APBTrxAJfF3hrTl/5ZwPK34181sMoK+n/wBt79mnxr45+KlvrmiWI1Ow8ny9mf8AUcV4JqvwV8a+HHJvfDd/tT73lLn26V89i6VT2rv5HbS2OZwEZd3TcP513v7MHw3f4n/HTRLPO2HT2+1TH2ByP1AriNSsrnTM/a7G9tVH3g8O0gfWvor9jyKP4MfAXxV8R7+FYprlGgss/eYDAX9SKnCQ5ql/5dTR7GB/wUB+La+Ofija+G7KQNpugRlpAO8vSvCp4FnjHnKrBegboadPez6ve3F/c/8AHzqDtPL9WOaRBiprVHOo5DprSx6T8CP2ofFH7P14Ugd9T0Pdl7F/vRr0+X+dfd/wS+OWhfHbwvHqWjXQY7R59s3+ttm9Gr8ynn8sDHJLKoHqSQB/Ovp/4aG3/YU+BMviG+An8W+Kzm1sj0C5BGfoOa78vrT1ctjmq0j7K8ugJg188fsvfty2nxXZNI8TQrpOvN9wj/U3H+774r6FAzMDznGOOhr2KVWM1eByuFiSiiitACiiigAooooAaq4A+lJNGksRV1DKeoIzmlB6UrfdqF0AwdX+HWha/E6Xek2FwHHIkhHNeDftdftIfA74Yz2Hwx+IGuWmhvrkYe1tY12eXzgNkdK+kbmUW9q7uwVFGWJ7Dv8ApX86H/BS74wW/wC0x+3N401ic/arHSpv7OtOvyrGdvbmtMPho1W09j2cmy/63Vabskj9MPE/7FV5J4c/tn4da3Y+NdDA2pHBNuljXOeleN39tPol7Na38UllcQnbJFc9SfavgH4FftJ/ED9lzXxfeBfFGo6UQ297Uyu0EnB4ZDwRX6e/8E9v25dF/wCCnVxqfhL4keDBF4h8NW63NzrNqvlW0qjnLN26Vx4zJYf8uzuxuR1cMvaKV4nU/si/CjT5ba9+JXi1BD4Y0EE2cU3/AC1lQdvxxXnfxo+Ml98c/iBc69flvsW4xafEv3YYuo/lX0X+2v8ADnUvEvwm0GLwJHbah4O0vPnWtg4cNjoxI9Dg/hXyPZyJMuV3rtJRkfrGwrycRF0IqijxYfEiXd9pHmLJJDNF80ckf3kI719n/sEftT3vxGL+DteMlzq2mQ74L0D5biLHAPuAK+OvD/h3U/G3iG00fSbc32qX0ojjA/h7k/gAT+Fe9a746sP2JvDy+HPCxh1b4g3rK+rXr/6q06Hyh79vxqcFKdOTqS2Kr7H3VTJDgH8q8y/Zb/aFtfj94Ejuvlh1Wz/dX0B6q4H3h7GvTWAcV70J8yU4nANTPFPC5bNRPlB3HIqWL7laiHUUUUrIZCrdKWV8Qt9KSP7o+lKxwvNTHZAjwT/gpT+0FH+zN+x34w8RASm4+yNaweX94PINufwya/nb0rU01iy+2tPHNc3rfaJ5F6uz5bBr+obxv4C0b4j+GJtJ13TrbVtNuRtlt7mPzI3GQeR+AP1Ar45+P3/BB/4J/FpZ7vSbK+8J6m6kJJYzbYl75KdxXZRrez0Pp8izXD4SDpTjqz8TdO0i/wDFeu2mk6TaS32sazItraQR/ed2OP0GT+Ffdv7T/iLT/wDglz+xzZ/BDwtco/xU+IkKX3irUI22PZxOBmLd9MgfX3r3j9kD/gjdefsMfEDxT8StSvIfH+s6Hp8n/CL6dty6ygHDH35Nflt8fPHnivx78d/EusfES01DTfF+r3shngu4/LESHOI1PYAV029pqj6KjiKWOxCjCV4Q19X/AMA9N/Yq/wCCi/xM/YN1KG20bVbzxT4PwGuNEvpPNYc4Z0PbOa/Sz4eN8P8A/gpr8OT45+FNzFo/ii3IGqaVN1hkPDB/1r8kPgD8AfFv7V3xWs/A/guylu9Ru2U3V2OLfTYehd29hnHvivs34q/ta+G/+CRvhe3+EvwEjsNe8fJOtz4v8QXUe9JZFwWiU+pwVHuRXPjMNSrpQlucmaYCjWny0Y/vX22sfVfiXVLb9jDQJvDeiNDf/ErWbcHVNSb/AFdhESPlj98ZH414YkbysXmuJZ7maQvNM/35Sf6V7R8J/iz4a/4Krfs9L4q0LydN+JXh+DZqenh9sgZfvDHowzj61yfwh/Zy1z4t39y+pb/DGh6VxqN/fHyymDyqfXp+NfL47C1FP2Utj5d0pUpOnPdbmt+xB4r1rw3+0HZpodvNd2uoReRqMaf6uFc9W/HH41+ikSfvN3sRXwN4m/ad0X4J+Hn0H4SWMYEEmL3Wbhd012F5O1vw/Kvs/wCBPjdviR8KNE1qT/XXlspkPq3eunLpWvT7HDXOtYZFELbolPqKU9KSM5X8a9OO7OcdRRRVAQoMAfSlYZFOUZUfSmyLxUR2QDFbrVLxHrlt4b0K6vryRY7a1iaWRmOBgDJq452Rk54A5rxX9t74Y+MPjJ8KLnQPBuo2VpeXDj7UkzbfNj/u57Zxj8a68NCE60Y1HZNq77HmZriquGwc6tGPPNJ2Xd9D4R+KP7ZXjPxb8d9R8W+H9XvNNt4JzbWVsr74vKXIBI9K9h8LaT4Q/wCCovwT1uH4qeEbTSbjSF8qLxPEixo0hIG5WPfPr614z4L/AGKvGSeNl0fxXpP/AAjOgaZAbjUdTlXMDRqDlVb37fWk/aH/AGj7Tx54fg8G+DU/sP4b6KPJCxHbJqLDrKT6Z6V+iYvA4XFKFDCJaby7f8Ofzlw9xZnOS4ipmmLnNNt2pv7UvTokX/2yPhhqX/BJ/wDYRt9J+BulzalD4pn2eIPGJRHuYIWxzkc47fjX5d+E9LuPE+sQ6do0Nz4g13WJMxRwjzpb1ycl29O9fsT+wLqHiuy8K6pD4zNqfg3LbGB/7ck3lienlj8q8f8A24/hvpH/AASO+HKeLvgZ4QsJf+E9uWEviq5bzDoKSHIWI9sgn86+SxeG+qVXBu/9fmf1Z4eccwznBc04OFefR7+vocX+yf4J8P8A/BHfX4vib8YPFBj8a69FHZweDdJfL2sT8B5x7bs/hX2Z+3z4huPiF8OvBvjPR9RP/CIatAsjW8fRmkAI3fQkfiK/Hz4dfs5fFn9tPxVf3mlaRq/i3UtVc/atf1STZbc8+YD2Uf0r9sP2Av2dbXSv2MdL+GnjLxLofjy60F9l1Jpsm+K3PBEWfVTXjZjh3Up3W59HnlNQtW5rz2fofLvwx+EHiD40agdO8OWEs0X+rkuW/wBTCGGCa/RH9m74RXHwQ+E2neH7q+N/Par80g6AntXS+C/BWl+BNKhsNJsbeytLeMIixDt71sMa8rCYJUfelufKValxpJHIGeaIHyWBwDnOA2Tjtn9ae1MZtvA616BlsSUVCZGHenKxxSGOQYUfSiQboz9KUdKWojsgPH/2z/jNffBD4Q3N/paD+0LtvIhkZdwiPrj6Zr4p8M674w+IWrz3k3ijUkuFKRblk2F5W5AUfXFffH7RfwXg+OfwwvtEaTyZ3Uvbyf3ZM5H6ivzwuo9W+B/i59M1i0ntri2YLJ5v3ZipxvWvKx7mql5fCdFLyPaIvjj43+CuzRfiRYDxB4YvwEmW7XMyKe4b8qr/ABC/ZP8Ahj4G8Mz/ABc0Cxu9f0Czi+1Q6On+pR++fYZyR7VwvxE+Plx8RtNH9pvNqFxHF9ntWb/Vwx+/+etes/8ABN/VZ/EHgbxRoVxH/aOi26MUiI+Queqn616OT5xUoYhUoSbi9/Q8Lifh3B5jh+apTXtEtJb2fRnyV44+IfxC/bIuYIYdIvrnS0XFlo+nW3l2lnGeQfc8fpX1l4B+Gms6T/wT317TPil4WsNbXw9ayXFhp0377eq/MgYc4wwBx7V474u8Y/tAWerapYeHvDDeHfD9ldSR2aWEHzNHzg7u1e+/8E1Ph74ss/h94i1Dx39vnl1eYhob5clx349K/Qs7beCsuVJNPR3Z+LeH3PQ4hVW1WdTVSk9IWXS35H5O6t+1P+0b+2JpTeHvB/h3XNE8PI5t4dL8Nab9khKLlP3jd+Pav0v/AOCFP7Hfjb9k34BeIIvHVrJYap4g1P7YlvJN5kirtx83oea9Ztf25PgZ8KfEt74ZsdS02y1XTnK3VhYW/wA9uefvAYr0v4MftReBv2gVu08Ka/ZancWGPtNsjYmg/wB5etfIVajcLcp/UOYZlUqUvYwp8q0PRFXbS5rzLxt+1d4H+GfxO07wfrWsJYeIdXA+xWsoy1wDz8v5H8q2fjL8evC3wH8J/wBseKdVg0u0J2RiQ/PM391VHJNcZ4KozbSS3O0IzTdu09K8M+F//BQ/4ZfFLXk0yDWTpd5IAYU1GJrfz89NpPBrtfjh+0v4O/Z58OWeq+LNVi0zT7+UQQXDrmNnOAoz7kgfjQFShODtNHfFKbVHwv4gtvFOhWeoWkiTW17CJ4pE6Op6Gr5XmgyHIcoKWmx/dH0p1THZAFcn8Tvgv4c+LeneRrumwXhxtWQjDp9DXWUyb7npTkk1Zhe2p8beI/2T/hFo3jl9Ln8RXenzq2wWjnlyOdq/lUvxO/aC8B/BH4KnR/CaTxaBfTtpt9qtgu6XTZicEyD9Pxr6K+In7P8A4a+Klzp8+rWEZuNMuhdW8sB2srg55rK8O/sk+CfDU+uFdLWW18RzC4vbOZt8EkufvhfU8V3YFZfh2qji+Y+SzehnmK5sPRnBQd7PW/zPk74T/sz/ABV+IN9pt74U+LF3f+CLlhKNRdsSyKDym39K+8vD+mto2iW1o8z3D20QjaR/vSkDqfeovCnhbTvB2mRafpVlbWFlbjbHBCmAlaZUA8Vpj8xliZeS2N+HOHKeVU/dk5Slvdtr5J7I/O79gzwHoeu/8FUP2lJ9R0ixu7pZ4NktygZwMsDgH2NY37YPhHTvhT/wVw+C03wxhgsfE+sb08RWGmnaklpn/WTqOPp7gVW/Z0+D5+NH/BQn9p/TrbWdQ0LU1ljS1urNtphc7sNn616h/wAE0Ljwvo3xp8W+E/E9lM/xt8JEw6hqeoLuuNTtCcJOjehB59jWUvi+R+mVnyVHU3tHb1W5g/8ABQOGC4/4Kqfs5u0QklQyqmPvL856Vgft9fFLR/g3/wAFTPhrrPxWt3b4ZyacYdLuZgDZ218cjMmePvEY98V0X7f0Zb/gqX+zxt6/vMY/3mr6n+MPhP4XftQzaj8OvFdto/iC6tI/OuNOuBumgVujqOvUdqxMXVjSp0XOOji7nLfG74DfCn9v/wCD0+lw3Wj30LMJbPUdMdPNtZA6sGDLyOmD7ZrwD/gtF4Ei8B/8E8fDPh+R21JdK1TTbbzpVy8hRlAbPauN/a5/4JVv+x/4F1X4mfs+eMde8F6r4ZjOoXGkvdNJZ3saD5k2np8pOPfFL/wUY+NN1+0V/wAEnfAPjG+g+y32t3+nT3MQHSQSBWYfU1S3QYalFVaU6Um4c2zP0E+C3Hwl8M/LsxpluAP+2a11Z61y/wAGx/xajw17aZb/APota3xq1s5OJlODg1yv42eDX0nL1Zbj+6PpTqbGu0DFOpR2RIUjNgUtRt1qwAHFPDZplFAElMuCRC2ACccA9CacOlJJ92hAfJ/7K37GnjX4Hfto/Ez4iapqWk3Wj/EKRHFnAMSWYUcH35xTv2rf+Cf+t/En9rjwJ8Y/AXiRPC3iTw9iy1gspK6pZE8ofwJ/Svq5DkUkjYP41pzyvc7VjqvtPadbW+R8n/tU/sb+NvjR+2J8NfiNpGqaZaaf4EYo9rOcNdhyc4I+v6VL+0d/wT+vvFnxtX4v/DzxHc+FfifBbJbuzyb7G+iAOYZF9Dk/oa+qTwRTWOeafO0KOOqLl227dD4z+IX7P37Q/wC1X4fi8JeOda8N+FPCt2ANYOkEvPqUeeYvZWwPzrov24f2Ar747fssaF8M/Al5a+HLLQ7iCSCSQbighwUGO+cc/WvqpBmnx9qXOH16cZqcUlbyPji++DX7VB+Gsfh608W+D7MxWa2a3ywYljVU27vrivoH9m/4T6r8Kfg3ouia5q7atrFrFm8vF4WeQ9WFeknpSIuRS52TVxc6nxJfcf/Z',
      //       width: 50,
      //       fit: [50, 50],
      //       pageBreak: 'after',
      //       alignment: 'right'
      //     },
      //     {
      //       margin: [2, 14, 0, 0],
      //       text: 'Survey Response Percentage Report',
      //       style: 'headerStyle',
      //       alignment: 'center'
      //     }
      //   ]
      // },

      exporterPdfFooter: function (currentPage, pageCount) {
        return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
      },
      exporterPdfCustomFormatter: function (docDefinition) {
        docDefinition.styles.headerStyle = { fontSize: 22, bold: true, alignment: 'left' };
        docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center' };
        return docDefinition;
      },
      exporterPdfOrientation: 'landscape',
      exporterPdfPageSize: 'A4',
      exporterPdfMaxGridWidth: 720,
      exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
      onRegisterApi: function (gridApi) {
        vm.gridApi = gridApi;
      }
    };
    vm.open = {};
    var d = new Date();
     d.setHours(0, 0, 0, 0);
     vm.range = {
      startDate: d,
      endDate: new Date()
    };

    vm.openCalendar = function (e, date) {
	  vm.open = {};
      vm.open[date] = !vm.open[date];
      e.preventDefault();
      e.stopPropagation();
      vm.open[date] = true;
    };
     
  // ReportsFactory.getalloutcome().then(
    //  function success(data) {
    //     vm.Outcomes = data.data;
    //     if (vm.Outcomes) {
    //       vm.Outcomes.splice(0, 0, { OUTCOMEID: 'ALL', DISPLAYNAME: "ALL" });
    //       vm.Outcome = 'ALL'
    //     }
    //      if (!vm.Outcomes) {
    //         toaster.pop({ type: "error", body: "No outcome Available" });
    //      }
    //  },
    //  function error(data) { 

    //  });
	  vm.Outcomes = [{
      'Id': '',
      'DISPLAYNAME': 'Success'
    }, {
      'Id': '',
      'DISPLAYNAME': 'Abandoned'
    }, {
      'Id': '',
      'DISPLAYNAME': 'Invalid'
    }, {
      'Id': '',
      'DISPLAYNAME': 'Busy'
    }, {
      'Id': '',
      'DISPLAYNAME': 'DNC'
    },
    {
      'Id': '',
      'DISPLAYNAME': 'No Answer'
    },
    {
      'Id': '',
      'DISPLAYNAME': 'Rejected'
    },
     {
      'Id': '',
      'DISPLAYNAME': 'DialError'
    }
  ];
  if (vm.Outcomes) {
          vm.Outcomes.splice(0, 0, { OUTCOMEID: 'ALL', DISPLAYNAME: "ALL" });
          vm.Outcome = { OUTCOMEID: 'ALL', DISPLAYNAME: "ALL" }
        }
  //   vm.campaignstatus = [{
  //   'Id': '',
  //   'Value': 'Success'
  // }, {
  //   'Id': '',
  //   'Value': 'DNC'
  // }];
  // vm.campaignstatus.splice(0, 0, {
  //   Id: 0,
  //   Value: "ALL"
  // });
  // vm.Status = 'ALL';



    vm.onSearchReports = function () {
      if (!validation()) {
        return;
      }
      getcampaigndetailReports();
    };

    vm.exportExcel = function () {
      var exportColumnHeaders = uiGridExporterService.getColumnHeaders(vm.gridApi.grid, uiGridExporterConstants.ALL);
      var exportData = uiGridExporterService.getData(vm.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
      var docDefinition = uiGridExporterService.prepareAsPdf(vm.gridApi.grid, exportColumnHeaders, exportData);
      var tableData = docDefinition.content[0].table.body;
      // vm.excelData = JSON.parse(angular.toJson(vm.surveyResponseGrid.data));
      exportFactory.getExcel(tableData, 'Outbound Detailed Report' + '.xlsx');
    };

    vm.exportPDF = function () {
      var exportColumnHeaders = uiGridExporterService.getColumnHeaders(vm.gridApi.grid, uiGridExporterConstants.ALL);
      var exportData = uiGridExporterService.getData(vm.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
      var docDefinition = uiGridExporterService.prepareAsPdf(vm.gridApi.grid, exportColumnHeaders, exportData);
      if (uiGridExporterService.isIE() || navigator.appVersion.indexOf("Edge") !== -1) {
        uiGridExporterService.downloadPDF("OutboundDetailedReport.pdf", docDefinition);
      } else {
        pdfMake.createPdf(docDefinition).download("OutboundDetailedReport.pdf");
      }
    };

    function validation() {
      var isValid = true;
      if (vm.department == undefined || !vm.department ) {
        toaster.pop({ type: "error", body: "Please select the departement" });
        isValid = false;
      }
      if (vm.campaign == undefined || !vm.campaign) {
        toaster.pop({ type: "error", body: "Please select valid campaign" });
        isValid = false;
      }
     
      // if (vm.user == undefined || !vm.user) {
      //   toaster.pop({ type: "error", body: "Please select valid user" });
      //   isValid = false;
      // }
      if (vm.range.startDate == undefined || !vm.range.startDate) {
        toaster.pop({ type: "error", body: "Please enter valid Start date time" });
        isValid = false;
      }
      if (vm.range.endDate == undefined || !vm.range.endDate) {
        toaster.pop({ type: "error", body: "Please enter valid End date time" });
        isValid = false;
      }
      // if (vm.Outcome == undefined || !vm.Outcome) {
      //   toaster.pop({
      //     type: "error", body: "Please select valid Outcome" });        
      //   isValid = false;
      // }
      var errMsg = appFactory.validateReportDates(vm.range.startDate, vm.range.endDate);
      if (errMsg) {
      toaster.pop({ type: "error",body: errMsg });
      return false;
      }
      return isValid;
    };



    vm.redirectOffline = function(){
      //Acciones si el usuario confirma
      appFactory.HideLoader();
      $('#confirmRedirect').modal('hide'); 
      $(".modal-backdrop").removeClass("modal-backdrop");
      $location.path("/reports/offlinereport");
    }



    function getcampaigndetailReports() {
      vm.redirect =false;
      vm.getcdreports = {};
      vm.getcdreports.FromDate = moment(vm.range.startDate).format('YYYY/MM/DD 00:00:00');
      vm.getcdreports.ToDate = moment(vm.range.endDate).format('YYYY/MM/DD 23:59:59');
      vm.getcdreports.CampaignId = vm.campaign.LCMCampaignName;
      vm.getcdreports.mobileNumber  = vm.mobileNumber == undefined || !vm.mobileNumber ? 'ALL' : vm.mobileNumber;
      vm.getcdreports.status  = vm.Outcome.DISPLAYNAME || { OUTCOMEID: 'ALL', DISPLAYNAME: "ALL" };
      vm.getcdreports.checkDate  = vm.datefields;
      vm.getcdreports.Departments = vm.department.ID;
      vm.getcdreports.runOffline = vm.offline;
      appFactory.ShowLoader();
      ReportsFactory.getcampaigndetail(vm.getcdreports).then(
        function success(response) {
          if(response.data == "REQUESTED"){
            $('.modal-dialog .card').resizable().draggable({
              containment: ".page-content"
          });
          $('.modal').on('hidden.bs.modal', function (e) {
              $('.modal-dialog .card').css({ top: 0, left: 0 });             

          })

            $('#confirmRedirect').modal('show'); 
          }else{
            vm.CampaignDetailGrid.data = response.data;
          }
          appFactory.HideLoader();
         
          if(!vm.CampaignDetailGrid.data.length)
          {
            // toaster.pop({ type: "error", body: "No data available" });
          }
        },
        function error(response) {
            appFactory.HideLoader();
          toaster.pop({ type: "error", body: "Error while retreiving Survey Response Reports Data" });
        }
      );
    };

  };