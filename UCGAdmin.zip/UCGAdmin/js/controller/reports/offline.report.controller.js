
app.controller('offlineReportController',['$scope','ReportsFactory','toaster', function ($scope,ReportsFactory,toaster) {

var vm = this;

vm.offlineReportGrid = {
  columnDefs: [{
      name: 'ReportName',cellTooltip: true,

      field: 'ReportName'
    },
    {
      name: 'ReportStatus',cellTooltip: true,  
      field: 'ReportStatus'
    },
    {
        name: 'RequestedDate',cellTooltip: true,  
        field: 'RequestedDate',cellFilter: 'date:\'dd-MM-yy  HH:mm\''
    },
    {
        name: 'Download',cellTooltip: true,  
        cellTemplate: '<a href="#" ng-if="row.entity.ReportStatus == \'COMPLETE\'" class="action-status" ng-click="grid.appScope.vm.downloadFile(row.entity)"><span class="fa fa-download" title="Download"></span></a>'
    },
  

  ],
  enableColumnResizing: true,
  paginationPageSizes: [10, 20, 30],
  paginationPageSize: 10,
  enableColumnMenus: false,
  enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
  enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed

}
vm.downloadFile =function(rowData){
    ReportsFactory.DownLoadFile(rowData.ReportFileName);
}

vm.refresh = function(){
  getOfflineReports();
}

vm.getOfflineReports = function(){
   ReportsFactory.getUserOfflineReport().then(
     function success(response) {
       vm.offlineReportGrid.data = response.data;
       if (!vm.offlineReportGrid.data.length) {
         toaster.pop({
           type: "error",
           body: "No data available"
         });
       }
     },
     function error(response) {
       toaster.pop({
         type: "error",
         body: "Error while retreiving Missed Call Reports Data"
       });
     }
   );
 };
 vm.getOfflineReports();
}]);