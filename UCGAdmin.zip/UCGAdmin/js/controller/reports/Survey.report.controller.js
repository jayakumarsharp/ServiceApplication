angular
    .module('adminApp')
    .controller('SurveyReportController', SurveyReportController);

SurveyReportController.$inject = ['$scope', '_', 'appFactory', 'uiGridExporterConstants', 'uiGridExporterService', 'toaster', 'exportFactory', 'ReportsFactory', 'uiGridConstants'];

function SurveyReportController($scope, _, appFactory, uiGridExporterConstants, uiGridExporterService, toaster, exportFactory, ReportsFactory, uiGridConstants) {

    var vm = this;

    vm.modules = [{ 'Id': 1, 'Value': 'Survey Response Report' },
    { 'Id': 2, 'Value': 'Survey Questionwise Report' },
    { 'Id': 3, 'Value': 'Survey Call Outcome Report' },
    { 'Id': 4, 'Value': 'Survey Campaign Detail Report' },
    { 'Id': 5, 'Value': 'Survey Summary Report' }];



// vm.getsurveydetails = function(Id) {
//     if(vm.module=='Survey Response Report') {
//         window.location = "#/views/reports/surveyResponseReport.html";
        
//     }
//       if(vm.module=='Survey Questionwise Report') {
//         window.location = "#/views/reports/surveyQueswiseReport.html";
   
//     }
//       if(vm.module=='Survey Call Outcome Report') {
//         window.location = "#/views/reports/surveyCallOutcomeReport.html";
       
//     }
//       if(vm.module=='Survey Call Outcome Report') {
//        window.location = "#/views/reports/surveyCampDetailReport.html";
      
//     }
//       if(vm.module=='Survey Call Outcome Report') {
//        window.location = "#/views/reports/surveySummaryReport.html";
        
//     }
// }

};