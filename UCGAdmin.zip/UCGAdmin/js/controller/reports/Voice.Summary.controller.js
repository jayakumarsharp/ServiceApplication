
  angular
    .module('adminApp')
    .controller('VoiceSummaryController', VoiceSummaryController);

    VoiceSummaryController.$inject = ['uiGridExporterConstants','$scope','appFactory','uiGridExporterService', 'toaster', 'exportFactory', 'ReportsFactory'];

  function VoiceSummaryController(uiGridExporterConstants,$scope,appFactory, uiGridExporterService, toaster, exportFactory, ReportsFactory) {

    var vm = this;

     vm.getCampList = function (depId){
    ReportsFactory.getdeptVoiceCampaignList(depId).then(
      function success(response) {
         vm.campaigns = response.data;
      //  if (vm.campaigns) {
        //  vm.campaigns.splice(0, 0, { LCMCampaignName: 'ALL', CampaignName: "ALL" });
        //  vm.campaign = 'ALL'
       // }
        if (!vm.campaigns) {
          toaster.pop({ type: "error", body: "No Campaign Available" });
        }
      },
      function error(data) {
        toaster.pop({ type: "error", body: "Error while retreiving Outcome Report Data" });
      }
    )}
    if(appFactory.rights.type !== appConst.RIGHTS_TYPES.SUPER_ADMIN){   
      // vm.getCampList(-1)
    }
    
    ReportsFactory.getalldepartment().then(
     function success(data) {
        vm.Departments = data.data;
        if (vm.Departments) {
        vm.Departments.splice(0, 0, { ID: 0, DepartmentName: "ALL" });
        vm.department ={ ID: 0, DepartmentName: "ALL" }
       }
         if (!vm.Departments) {
            toaster.pop({ type: "error", body: "No department Available" });
         }
     },
     function error(data) { 

     })


    vm.getCampdatewiseList = function (){
      var input = {
        startDate:moment(vm.range.startDate).format('YYYY-MM-DD HH:mm:ss'),
        endDate:moment(vm.range.endDate).format('YYYY-MM-DD HH:mm:ss')
      }
  
    ReportsFactory.getVoiceCampaignByDateList(input).then(
      function success(response) {
         var value=[], splitvalue="_VOICE_",temp={};
         for (var i = 0; i < response.data.length; i++) {
            temp={
              'CampaignId': response.data[i].CampaignId.substr(response.data[i].CampaignId.indexOf(splitvalue) + splitvalue.length, response.data[i].CampaignId.length),
              'CampaignValue' : response.data[i].CampaignId            
          }
            value.push(temp);
      
          }
        vm.campaigns = value;
         if (vm.campaigns) {
         vm.campaigns.splice(0, 0, { CampaignId: 'ALL', CampaignValue:'ALL'});
         vm.campaign =  { CampaignId: 'ALL',CampaignValue:'ALL' }
       }
     
        if (!vm.campaigns) {
          toaster.pop({ type: "error", body: "No Campaign Available" });
        }
      },
      function error(data) {
        toaster.pop({ type: "error", body: "Error while retreiving Outcome Report Data" });
      }
    )}

    
    vm.SummaryGrid = {
      columnDefs: [

      {
        name: 'S.No', width: '8%',enableSorting: false,enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
      },
      { name: 'Department',displayName: 'Department', field: 'DepartmentName',width:"40%", cellTooltip: true},
        
      { name: 'Campaign',displayName: 'Campaign', field: 'CampaignId',width:"25%",cellTooltip: true},
      //  cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.CampaignId.substring(row.entity.CampaignId.indexOf("_VOICE_")+7,row.entity.CampaignId.length)}}</div>'},
      
      { name: 'Total Contact',displayName: 'Total Contact', field: 'TotalContact',width:"13%", cellTooltip: true },
      
      { name: 'Retry',displayName: 'Retry', field: 'NumberOfAttempts',width:"8%", cellTooltip: true },

      { name: 'Total Dialed',displayName: 'Total Dialed', field: 'TotalDialed',width:"11%", cellTooltip: true },

      { name: 'Total Abandoned',displayName: 'Total Abandoned', field: 'TotalAbandoned',width:"14%", cellTooltip: true },

      { name: 'Total Success',displayName: 'Total Success', field: 'TotalSuccess',width:"13%", cellTooltip: true },

      { name: 'Total Failed',displayName: 'Total Failed', field: 'TotalFailed',width:"12%", cellTooltip: true },
        
      { name: 'Status',displayName: 'Status', field: 'Status',width:"15%", cellTooltip: true },

      { name: 'Execution Rate',displayName: 'Execution Rate(%)', field: 'ExecutionRate', width:"16%",
      
        cellTemplate: '<span title="{{row.entity.ExecutionRate|number:2}}">{{row.entity.ExecutionRate|number:2}}<span>',
        cellTooltip: true},

      { name: 'Success Rate',displayName: 'Success Rate(%)', field: 'SuccessRate',width:"14%", 
       cellTemplate: '<span title="{{row.entity.SuccessRate|number:2}}">{{row.entity.SuccessRate|number:2}}<span>',
       cellTooltip: true },

      { name: 'Failed Rate',displayName: 'Failed Rate(%)', field: 'FailedRate',width:"14%", 
      cellTemplate: '<span title="{{row.entity.FailedRate|number:2}}">{{row.entity.FailedRate|number:2}}<span>',
      cellTooltip: true },

      { name: 'Abondon Rate',displayName: 'Abondon Rate(%)', field: 'AbondonRate',width:"15%",
      cellTemplate: '<span title="{{row.entity.AbondonRate|number:2}}">{{row.entity.AbondonRate|number:2}}<span>',
      cellTooltip: true },
      

      ],
      enableColumnResizing: true,
      paginationPageSizes: [10, 20, 30],
      paginationPageSize: 10,
      enableColumnMenus: false,
      enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
      enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
      exporterHeaderFilterUseName: function( displayName ){ return 'col: ' + name; },
      exporterCsvFilename: 'exportedData.xlsx',
      exporterPdfFilename: 'pdfFileFormat.pdf',
      exporterPdfDefaultStyle: { fontSize: 10 },
      exporterPdfTableStyle: { margin: [0, 30, 0, 15] },
      exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
      exporterPdfHeader: {
        margin: [2, 14, 0, 0],
        text: 'Voice Summary Report',
        style: 'headerStyle',
        alignment: 'center'
      },

      exporterPdfFooter: function (currentPage, pageCount) {
        return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
      },
      exporterPdfCustomFormatter: function (docDefinition) {
        docDefinition.styles.headerStyle = { fontSize: 22, bold: true, alignment: 'left' };
        docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center' };
        return docDefinition;
      },
      exporterPdfOrientation: 'landscape',
      exporterPdfPageSize: 'A4',
      exporterPdfMaxGridWidth: 720,
      exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
      onRegisterApi: function (gridApi) {
        vm.gridApi = gridApi;
      }
    };
    vm.open = {};
    var d = new Date();
    d.setHours(0, 0, 0, 0);
    vm.range = {
      startDate: d,
      endDate: new Date()
    };

    vm.openCalendar = function (e, date) {
      vm.open = {};
      vm.open[date] = !vm.open[date];
      e.preventDefault();
      e.stopPropagation();
      vm.open[date] = true;
    };
  // vm.campstatus = [{ 'Id': '','Value': 'CREATED'  },
  //   {      'Id': '',      'Value': 'READY'    },
  //   {      'Id': '',      'Value': 'EXCEUTING'    },
  //   {      'Id': '',      'Value': 'TIME SUSPENDED'    },
  //   {      'Id': '',      'Value': 'USER SUSPENDED'    },
  //   {      'Id': '',      'Value': 'STOPPED'       },
  //   {      'Id': '',      'Value': 'LIST UPLOADED'      
  //   }
  // ];
  // vm.campstatus.splice(0, 0, {
  //   Id: 0,
  //   Value: "ALL"
  // });
  // vm.campst = 'ALL';

    vm.onSearchReports = function () {
      if (!validation()) {
        return;
      }
      getVSDetailReports();
    };

    vm.exportExcel = function () {
      var exportColumnHeaders = uiGridExporterService.getColumnHeaders(vm.gridApi.grid, uiGridExporterConstants.ALL);
      var exportData = uiGridExporterService.getData(vm.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
      var docDefinition = uiGridExporterService.prepareAsPdf(vm.gridApi.grid, exportColumnHeaders, exportData);
      var tableData = docDefinition.content[0].table.body;
      // vm.excelData = JSON.parse(angular.toJson(vm.surveyResponseGrid.data));
      exportFactory.getExcel(tableData, 'Voice Summary Report' + '.xlsx');
    };

    vm.exportPDF = function () {
      var exportColumnHeaders = uiGridExporterService.getColumnHeaders(vm.gridApi.grid, uiGridExporterConstants.ALL);
      var exportData = uiGridExporterService.getData(vm.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
      var docDefinition = uiGridExporterService.prepareAsPdf(vm.gridApi.grid, exportColumnHeaders, exportData);
      if (uiGridExporterService.isIE() || navigator.appVersion.indexOf("Edge") !== -1) {
        uiGridExporterService.downloadPDF("VoiceSummaryReport.pdf", docDefinition);
      } else {
        pdfMake.createPdf(docDefinition).download("VoiceSummaryReport.pdf");
      }
    };

    function validation() {
      var isValid = true;
      if (vm.campaign == undefined || !vm.campaign) {
        toaster.pop({ type: "error", body: "Please select valid campaign" });
        isValid = false;
      }
  
     if (vm.department == undefined || !vm.department) {
        toaster.pop({ type: "error", body: "Please select valid Department" });
        isValid = false;
      }
      if (vm.range.startDate == undefined || !vm.range.startDate) {
        toaster.pop({ type: "error", body: "Please enter valid Start date time" });
        isValid = false;
      }
      if (vm.range.endDate == undefined || !vm.range.endDate) {
        toaster.pop({ type: "error", body: "Please enter valid End date time" });
        isValid = false;
      }
     
      var errMsg = appFactory.validateReportDates(vm.range.startDate, vm.range.endDate);
      if (errMsg) {
      toaster.pop({ type: "error",body: errMsg });
      return false;
      }
      return isValid;
    };

    function getVSDetailReports() {
      vm.getvsreports = {};
      vm.getvsreports.fromDate = moment(vm.range.startDate).format('YYYY-MM-DD 00:00:00');
      vm.getvsreports.toDate = moment(vm.range.endDate).format('YYYY-MM-DD 23:59:59');
      vm.getvsreports.CampaignId = vm.campaign.CampaignValue;
      vm.getvsreports.department = vm.department.ID;
      appFactory.ShowLoader();
      ReportsFactory.getVCReport(vm.getvsreports).then(
        function success(response) {
           appFactory.HideLoader();
          vm.SummaryGrid.data = response.data;
          if(!vm.SummaryGrid.data.length)
          {
            //toaster.pop({ type: "error", body: "No data available" });
          }
        },
        function error(response) {
           appFactory.HideLoader();
          toaster.pop({ type: "error", body: "Error while retreiving Survey Response Reports Data" });
        }
      );
    };

  };