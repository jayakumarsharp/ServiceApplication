angular
    .module('adminApp')
    .controller('InboundReportController', InboundReportController);

InboundReportController.$inject = ['$scope', '_', 'appFactory', 'uiGridExporterConstants', 'uiGridExporterService', 'toaster', 'exportFactory', 'ReportsFactory', 'uiGridConstants'];

function InboundReportController($scope, _, appFactory, uiGridExporterConstants, uiGridExporterService, toaster, exportFactory, ReportsFactory, uiGridConstants) {

    var vm = this;

    // vm.agents = [
    //   { 'Id': '', 'Value': 'Agent1' },
    //   { 'Id': '', 'Value': 'Agent2' },
    //   { 'Id': '', 'Value': 'Agent3' }
    // ];
    // vm.agents.splice(0, 0, { Id: 0, Value: "ALL" });
    ReportsFactory.GetAllAgent().then(
        function success(response) {
            vm.agents = response.data;
            if (vm.agents) {
                vm.agents.splice(0, 0, { ID: 0, VALUE: "ALL" });
                vm.agentId = 0
            }
            if (!vm.agents) {
                toaster.pop({ type: "error", body: "No Agents Available" });
            }
        },
        function error(data) {
            toaster.pop({ type: "error", body: "Error while retreiving Agent" });
        }
    )


    // vm.skillgroup = [
    // 	{ 'Id': '', 'Value': 'Sk1' },
    // 	{ 'Id': '', 'Value': 'Sk2' },
    // 	{ 'Id': '', 'Value': 'Sk3' }
    //   ];
    // vm.skillgroup.splice(0, 0, { Id: 0, Value: "ALL" });
    ReportsFactory.GetAllSkillGroup().then(
        function success(response) {
            vm.skillgroup = response.data;
            if (vm.skillgroupskillgroup) {
                vm.skillgroup.splice(0, 0, { ID: 0, VALUE: "ALL" });
                vm.skillId = 0
            }
            if (!vm.skillgroup) {
                toaster.pop({ type: "error", body: "No Agents Available" });
            }
        },
        function error(data) {
            toaster.pop({ type: "error", body: "Error while retreiving Skill Group" });
        }
    )

    vm.modules = [{ 'Id': 1, 'Value': 'Number of calls – Inbound' },
    { 'Id': 2, 'Value': 'Number of calls – Outbound' },
    { 'Id': 3, 'Value': 'Number of Calls' },
    { 'Id': 4, 'Value': 'Queue analysis' },
    { 'Id': 5, 'Value': 'Agent Summary Report' },
    { 'Id': 6, 'Value': 'Outbound Calls' },
    { 'Id': 7, 'Value': 'Agent Detailed Report' },
    { 'Id': 8, 'Value': 'Call Detailed Report' }];

    vm.reportsGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
       
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        exporterHeaderFilterUseName: function (displayName) {
            return 'col: ' + name;
        },
        exporterCsvFilename: 'exportedData.xlsx',
        exporterPdfFilename: 'pdfFileFormat.pdf',
        exporterPdfDefaultStyle: { fontSize: 10 },
        exporterPdfTableStyle: { margin: [0, 30, 0, 15] },
        exporterPdfTableHeaderStyle: {
            fontSize: 10,
            bold: true,
            italics: true,
            color: 'red'
        },
        exporterPdfHeader: {
            text: "Inbound Reports",
            style: 'headerStyle',
            alignment: 'center',
            margin: [2, 14, 0, 0]
        },
        exporterPdfFooter: function (currentPage, pageCount) {
            return {
                text: currentPage.toString() + ' of ' + pageCount.toString(),
                style: 'footerStyle'
            };
        },
        exporterPdfCustomFormatter: function (docDefinition) {
            docDefinition.styles.headerStyle = { fontSize: 22, bold: true, alignment: 'left' };
            docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center' };
            return docDefinition;
        },
        exporterPdfOrientation: 'landscape',
        exporterPdfPageSize: 'A4',
        exporterPdfMaxGridWidth: 720,
        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")), 
           onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
        }


    
    };

    vm.open = {};
    var d = new Date();
    d.setHours(0, 0, 0, 0); 
    vm.range = {
        startDate: d,
        endDate: new Date()
    };

    vm.openCalendar = function (e, date) {
		vm.open = {};
        vm.open[date] = !vm.open[date];
        e.preventDefault();
        e.stopPropagation();
        vm.open[date] = true;
    };

    vm.onSearchReports = function () {

        if (!validation()) {
            return;
        }
        vm.reportsGrid.excludeProperties = ['$$hashKey'];
        getIBReports(vm.module);
    };

    vm.exportExcel = function () {
        var exportColumnHeaders = uiGridExporterService.getColumnHeaders( $scope.gridApi.grid, uiGridExporterConstants.ALL);
        var exportData = uiGridExporterService.getData( $scope.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
        var docDefinition = uiGridExporterService.prepareAsPdf( $scope.gridApi.grid, exportColumnHeaders, exportData);
        var tableData = docDefinition.content[0].table.body;
        exportFactory.getExcel(tableData, vm.module + '.xlsx');
    };

    vm.exportPDF = function () {
        vm.reportsGrid.exporterPdfHeader.text = vm.module;
        var exportColumnHeaders = uiGridExporterService.getColumnHeaders($scope.gridApi.grid, uiGridExporterConstants.ALL);
        var exportData = uiGridExporterService.getData($scope.gridApi.grid, uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, true);
        var docDefinition = uiGridExporterService.prepareAsPdf($scope.gridApi.grid, exportColumnHeaders, exportData);
        var reportname = vm.module + '.pdf';
        if (uiGridExporterService.isIE() || navigator.appVersion.indexOf("Edge") !== -1) {

            uiGridExporterService.downloadPDF(reportname, docDefinition);
        } else {
            pdfMake.createPdf(docDefinition).download(reportname);
        }
    };
     vm.redirectOffline = function(){
      //Acciones si el usuario confirma
      appFactory.HideLoader();
      $('#confirmRedirect').modal('hide'); 
      $(".modal-backdrop").removeClass("modal-backdrop");
      $location.path("/reports/offlinereport");
       }

    function validation() {
        var isValid = true;

        var errMsg = appFactory.validateReportDates(vm.range.startDate, vm.range.endDate);

        if (vm.range.startDate == undefined || !vm.range.startDate) {
            toaster.pop({ type: "error", body: "Please enter valid Start date time" });
            isValid = false;
        } else if (vm.range.endDate == undefined || !vm.range.endDate) {
            toaster.pop({ type: "error", body: "Please enter valid End date time" });
            isValid = false;
        } else if (!vm.module) {
            toaster.pop({ type: "error", body: "Please Select Valid Report" });
            isValid = false;
        } else if (errMsg) {
            toaster.pop({ type: "error", body: errMsg });
            return false;
        }

        return isValid;
    };

    function gridLoadCulmHeader(module) {
        switch (module) {
            case "Number of calls – Inbound":
                vm.reportsGrid.columnDefs = [];
                vm.reportsGrid.columns = [];
                vm.myDef = [{ name: 'Date', displayName: 'Date', field: 'Date', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
                { name: 'Count of calls', displayName: 'Count of calls', field: 'Count', cellTooltip: true }
                ];
                vm.reportsGrid.columnDefs = vm.myDef;
                break;
            case "Number of calls – Outbound":
                vm.reportsGrid.columnDefs = [];
                vm.reportsGrid.columns = [];
                vm.myDef = [{ name: 'Date', displayName: 'Date', field: 'Date', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
                { name: 'Count of calls', displayName: 'Count of calls', field: 'Count', cellTooltip: true }
                ];
                vm.reportsGrid.columnDefs = vm.myDef;
                break;
          case "Number of Calls":
                vm.reportsGrid.columnDefs = [];
                vm.reportsGrid.columns = [];
                vm.myDef = [{ name: 'Date', displayName: 'Date', field: 'SummDate', cellTooltip: true,width:"14%",cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
                { name: 'CLI', displayName: 'CLI', field: 'Ani', cellTooltip: true,width:"14%" },
                { name: 'DNIS', displayName: 'DNIS', field: 'Dnis', width:"14%",cellTooltip: true },
                { name: 'Last Menu Accessed', displayName: 'Last Menu Accessed', field: 'LastMenuAccessed', cellTooltip: true,width:"18%" },
                { name: 'Agent Transferred', displayName: 'Agent Transferred', field: 'AgentTransferredCount', cellTooltip: true,width:"16%" },
                { name: 'IVR Disconnect', displayName: 'IVR Disconnect', field: 'IVRDisconnectedCount', cellTooltip: true,width:"15%" },
                { name: 'Transferred to other call Centre', displayName: 'Transferred to other call Centre', field: 'Transcode',width:"23%", cellTooltip: true }
                ];
                vm.reportsGrid.columnDefs = vm.myDef;
                break;
            case "Queue analysis":
                vm.reportsGrid.columnDefs = [];
                vm.reportsGrid.columns = [];
                vm.myDef = [
                    // { name: 'Date', displayName: 'Date', field: 'DateTime', cellTooltip: true },
                    { name: 'Skill Group Name', displayName: 'Skill Group Name', field: 'QueueName', cellTooltip: true },
                    { name: 'Number of Waiting Calls', displayName: 'Number of Waiting Calls', field: 'RouterMaxCallsQueued', cellTooltip: true },
                    { name: 'Average Call Time', displayName: 'Average Call Time', field: 'AvgHandledCallsTalkTime', cellTooltip: true },
                    { name: 'Average Waiting Time', displayName: 'Average Waiting Time', field: 'AnswerWaitTime', cellTooltip: true },
                    { name: 'Number of Abandoned Calls', displayName: 'Number of Abandoned Calls', field: 'AbandonedCalls', cellTooltip: true }
                ];
                vm.reportsGrid.columnDefs = vm.myDef;
                break;
            case "Agent Summary Report":
                vm.reportsGrid.columnDefs = [];
                vm.reportsGrid.columns = [];
                vm.myDef = [{ name: 'Login Time', displayName: 'Login Time', field: 'LoginDateTime', cellTooltip: true,width:"18%", cellFilter: 'date:\'dd-MM-yyyy hh:mm:ss a\'' },
                { name: 'Logout Time', displayName: 'Logout Time', field: 'LogoutDateTime', cellTooltip: true,width:"18%", cellFilter: 'date:\'dd-MM-yyyy hh:mm:ss a\'' },
                { name: 'Average Speed of Answer Time', displayName: 'Average Speed of Answer Time',width:"25%", field: 'AvgAnsTime', cellTooltip: true },
                { name: 'Average Talk Time', displayName: 'Average Talk Time', field: 'AvgTalkTime',width:"16%", cellTooltip: true },
                // { name: 'Average Handling Time Average Hold Time', displayName: 'Average Handling Time', field: 'AvgHandleTime', cellTooltip: true },
                { name: 'Average Handling Time Average Hold Time', displayName: 'Average Hold Time',width:"16%", field: 'AvgHoldTime', cellTooltip: true },
                { name: 'Average Wrap up time', displayName: 'Average Wrap up time', field: 'AvgWrapupTime',width:"18%", cellTooltip: true },
                { name: 'Number of Dropped Calls before Pickup', displayName: 'Number of Dropped Calls before Pickup',width:"29%", field: 'AbandonRingCalls', cellTooltip: true },
                { name: 'Number of Dropped Calls after Pickup', displayName: 'Number of Dropped Calls after Pickup',width:"28%", field: 'ShortCalls', cellTooltip: true },
                { name: 'Idle Time', displayName: 'Idle Time', field: 'AvailTime',width:"15%", cellTooltip: true },,
                    // { name: 'Time Agent is Ready', displayName: 'Time Agent is Ready', field: 'AgentReadyTime', cellTooltip: true }
                ];
                vm.reportsGrid.columnDefs = vm.myDef;
                vm.reportsGrid.exporterPdfMaxGridWidth = 680;
                break;
            case "Outbound Calls":
                vm.reportsGrid.columnDefs = [];
                vm.reportsGrid.columns = [];
                vm.myDef = [
                    // { name: 'Date', displayName: 'From Date', field: 'FromDate', cellTooltip: true },
                    { name: 'Campaign Name', displayName: 'Campaign Name', field: 'CampaignName', cellTooltip: true },
                    { name: 'Destination Numbers Duration', displayName: 'Destination Numbers Duration', field: 'CallDuration', cellTooltip: true },
                    { name: 'No Answer', displayName: 'No Answer', field: 'NoAnswer', cellTooltip: true },
                    { name: 'No of call backs', displayName: 'No of call backs', field: 'CallBacks', cellTooltip: true },
                ];
                vm.reportsGrid.columnDefs = vm.myDef;
                break;
            case "Agent Detailed Report":
                vm.reportsGrid.columnDefs = [];
                vm.reportsGrid.columns = [];
                vm.myDef = [{ name: 'Login Time', displayName: 'Login Time', field: 'LoginDateTime',width:"18%", cellTooltip: true, cellFilter: 'date:\'dd-MM-yyyy hh:mm:ss a\'' },
                { name: 'Logout Time', displayName: 'Logout Time', field: 'LogoutDateTime',width:"18%", cellTooltip: true, cellFilter: 'date:\'dd-MM-yyyy hh:mm:ss a\'' },
                { name: 'Extension', displayName: 'Extension', field: 'Extension',width:"10%", cellTooltip: true },
                { name: 'Skill Group', displayName: 'Skill Group', field: 'EnterpriseName',width:"14%", cellTooltip: true },
                { name: 'Average Speed of Answer Time', displayName: 'Average Speed of Answer Time', field: 'AvgAnsTime',width:"25%", cellTooltip: true },
                { name: 'Average Talk Time', displayName: 'Average Talk Time', field: 'AvgTalkTime',width:"16%", cellTooltip: true },
                // { name: 'Average Handling Time Average Hold Time', displayName: 'Average Handling Time', field: 'AvgHandleTime', cellTooltip: true },
                { name: 'Average Handling Time Average Hold Time', displayName: 'Average Hold Time',width:"16%", field: 'AvgHoldTime', cellTooltip: true },
                { name: 'Average Wrap up time', displayName: 'Average Wrap up time', field: 'AvgWrapupTime',width:"18%", cellTooltip: true },
                { name: 'Number of Dropped Calls before Pickup', displayName: 'Number of Dropped Calls before Pickup',width:"29%", field: 'AbandonRingCalls', cellTooltip: true },
                { name: 'Number of Dropped Calls after Pickup', displayName: 'Number of Dropped Calls after Pickup',width:"28%", field: 'ShortCalls', cellTooltip: true },
                { name: 'Idle Time', displayName: 'Idle Time', field: 'AvailTime',width:"15%", cellTooltip: true },
                    // { name: 'Time Agent is Ready', displayName: 'Time Agent is Ready', field: 'AgentReadyTime', cellTooltip: true }
                ];
                vm.reportsGrid.columnDefs = vm.myDef;
                vm.reportsGrid.exporterPdfMaxGridWidth = 680;
                break;
                case "Call Detailed Report":
                vm.reportsGrid.columnDefs = [];
                vm.reportsGrid.columns = [];
                vm.myDef = [{ name: 'Start Date', displayName: 'Start Date', field: 'CallStartTime', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'' },
                { name: 'Call Date', displayName: 'Call Date', field: 'CallEndTime', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\''  },
                { name: 'ANI', displayName: 'ANI', field: 'ANI', cellTooltip: true },
                { name: 'DNIS', displayName: 'DNIS', field: 'DNIS', cellTooltip: true },
                { name: 'Last Menu Accessed', displayName: 'Last Menu Accessed', field: 'LastMenuAccessed', cellTooltip: true },
                { name: 'Call End Type', displayName: 'Call End Type', field: 'CallEndType', cellTooltip: true },
                ];
                vm.reportsGrid.columnDefs = vm.myDef;
                break;
        }

    }

    function getIBReports(reportName) {
        vm.getIBReportsData = {};
        vm.reportsGrid.data = null;
        switch (vm.module) {
            case "Number of calls – Inbound":
            case "Number of calls – Outbound":
            case "Number of Calls":
            case "Queue analysis":
            case "Outbound Calls":
            case "Call Detailed Report":


                vm.getIBReportsData.fromDate = moment(vm.range.startDate).format('YYYY/MM/DD 00:00:00');
                vm.getIBReportsData.toDate = moment(vm.range.endDate).format('YYYY/MM/DD 23:59:59');
                vm.getIBReportsData.runOffline = vm.offline;

                break;
            case "Agent Summary Report":
                vm.getIBReportsData.fromDate = moment(vm.range.startDate).format('YYYY/MM/DD 00:00:00');
                vm.getIBReportsData.toDate = moment(vm.range.endDate).format('YYYY/MM/DD 23:59:59');
                vm.getIBReportsData.agentId = vm.agentId == undefined || !vm.agentId ? 0 : vm.agentId;
                vm.getIBReportsData.runOffline = vm.offline;

                break;

            case "Agent Detailed Report":
                vm.getIBReportsData.fromDate = moment(vm.range.startDate).format('YYYY/MM/DD 00:00:00');
                vm.getIBReportsData.toDate = moment(vm.range.endDate).format('YYYY/MM/DD 23:59:59');
                vm.getIBReportsData.agenetId = vm.agentId == undefined || !vm.agentId ? 0 : vm.agentId;
                vm.getIBReportsData.skillgroupId = vm.skillId == undefined || !vm.skillId ? 0 : vm.skillId;
                vm.getIBReportsData.runOffline = vm.offline;
                break;
        }
        appFactory.ShowLoader();
        ReportsFactory.getIBReports(vm.module, vm.getIBReportsData).then(
            function success(response) {
             if(response.data == "REQUESTED"){
            $('.modal-dialog .card').resizable().draggable({
              containment: ".page-content"
          });
          $('.modal').on('hidden.bs.modal', function (e) {
              $('.modal-dialog .card').css({ top: 0, left: 0 });             

          })

            $('#confirmRedirect').modal('show'); 
          }else{
           gridLoadCulmHeader(vm.module);
           vm.reportsGrid.data = response.data;
           vm.reportsGrid.onRegisterApi();
           }
           appFactory.HideLoader();
               
                if (!vm.reportsGrid.data.length) {
                    //toaster.pop({ type: "error", body: "No data available" });
                }
            },
            function error(response) {
                  appFactory.HideLoader();
                toaster.pop({ type: "error", body: "Error while retreiving Inbound Reports Data" });
            }
        );
    };

};