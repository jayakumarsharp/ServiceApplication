app.controller('voiceTransDownloadController', ['$scope','appFactory', '$rootScope', 'voiceTransFactory', 'toaster', function ($scope,appFactory, $rootScope, voiceTransFactory, toaster) {


    $scope.gridVoiceDownload = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableColumnResizing: true,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [
            { name: 'S.No', width: '10%',enableSorting: false, enableFiltering: false, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>' },
            { name: 'UserName', field: 'UserName',cellTooltip: true },
            { name: 'Batch ID', field: 'BatchID', cellTooltip: true },
            { name: 'Uploaded Date', field: 'CreatedDate', cellTooltip: true, cellFilter: 'date:\'dd-MM-yy HH:mm\'', },
            { name: 'Comments',field: 'Comments', cellTooltip: true},
            {
                name: 'Download', enableSorting: false,
                cellTemplate: '<a href="#" class="action-status" ng-click="grid.appScope.DownloadfileByBatchID(row.entity)"><span class="fa fa-download" title="Download"></span></a>'
            }

        ],
    };
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
  //$rootScope.departmentName = userObj.departmentId;
    // $scope.UserName = userObj.SSOID;
   
   $scope.UserName='ESANCHAR2.TEST'

   
 
    $scope.open = {};
    var d = new Date();
    d.setHours(0, 0, 0, 0);

    $scope.range = {
        startDate: d,
        endDate: new Date()
    };
    
    $scope.openCalendar = function (e, date) {
        $scope.open[date] = !$scope.open[date];
        e.preventDefault();
        e.stopPropagation();
        $scope.open[date] = true;
    };

    GetCompletedUserRequest();
    $scope.onSearchdownload = function () {

    if (!validation()) {
      return;
    }
    GetCompletedUserRequest();
  };
  
 function validation() {
    var isValid = true;

    if ($scope.range.startDate == undefined || !$scope.range.startDate) {
      toaster.pop({
        type: "error",
        body: "Please enter valid Start date time"
      });
      isValid = false;
    }
    if ($scope.range.endDate == undefined || !$scope.range.endDate) {
      toaster.pop({
        type: "error",
        body: "Please enter valid End date time"
      });
      isValid = false;
    }
    var errMsg = appFactory.validateReportDates($scope.range.startDate, $scope.range.endDate);
    if (errMsg) {
      toaster.pop({
        type: "error",
        body: errMsg
      });
      return false;
    }

    return isValid;
  };

    var refresh = function() {
    $scope.refresh = true;
    $timeout(function() {
      $scope.refresh = false;
    }, 0);
  };

function GetCompletedUserRequest() {
    $scope.GetCompletedUserRequest = {};
    $scope.GetCompletedUserRequest.fromDate = moment($scope.range.startDate).format('YYYY-MM-DD HH:mm:ss');
    $scope.GetCompletedUserRequest.toDate = moment($scope.range.endDate).format('YYYY-MM-DD HH:mm:ss');
    $scope.GetCompletedUserRequest.UserName= $scope.UserName;
    appFactory.ShowLoader();
        voiceTransFactory.GetCompletedUserRequest($scope.GetCompletedUserRequest).then(
            function success(data) {
                appFactory.HideLoader();
                console.log(data.data)
                $scope.gridVoiceDownload.data = data.data;
           
               if (!$scope.gridVoiceDownload.data.length) {
                   $scope.flaghide=false;
       
            }else{
          $scope.flaghide=true;
        }
            },
            function error(data) {
                 appFactory.HideLoader();
                toaster.pop({ type: "error", body: "Error while retrieving Voice Download Data" });
            }
        )
    };

    GetCompletedUserRequest();

    $scope.FolderInfo = ['D:/Test', 'C:/Test', 'E:Test'];

    $scope.DownloadfileByBatchID = function (data) {
        var filename = data.BatchID + ".zip";
        voiceTransFactory.DownLoadZipFile(filename);
    }

}]);