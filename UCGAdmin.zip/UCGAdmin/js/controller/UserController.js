app.controller('UserController', ['$scope', '$rootScope', 'userFactory', function ($scope, $rootScope, userFactory) {

    $scope.usrData = [{
            'UserId': 'Srini',
            'ProfileName': 'Agriculture Profile',
            'Department': 'Agriculture Department',
            'RoleName': 'Campaign Management',
            'RightsGroup': 'Dev',
            'Active': true
        },
        {
            'UserId': 'John',
            'ProfileName': 'Sales Profile',
            'Department': 'Sales Department',
            'RoleName': 'Survey Management',
            'RightsGroup': 'Lead',
            'Active': true
        }
    ];

    $scope.highlightFilteredHeader = function (row, rowRenderIndex, col, colRenderIndex) {
        if (col.filters[0].term) {
            return 'header-filtered';
        } else {
            return '';
        }
    };

    $scope.UserGrid = {
        enableColumnResizing: true,
        enableFiltering: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                enableFiltering: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'SSO Id',
                field: 'UserId',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Profile Name',
                field: 'ProfileName',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Department',
                field: 'Department',
                headerCellClass: $scope.highlightFilteredHeader
            },
            // { name: 'Active', enableFiltering: false, field: 'Active' },
            {
                name: 'Options',
                enableSorting: false,
                enableFiltering: false,
                width: '10%',
                cellTemplate: '<a href="#" ng-click="grid.appScope.showView(row.entity)"><span class="fa fa-eye"></span></a> | <a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity.UserId)"><span class="fa fa-trash-o"></span></a>'
            },
        ]
    };

    $scope.UserGrid.data = $scope.usrData;

    $scope.ADUserData = [{
            'Userid': 'Sowba',
            'UserName': 'Sowbakiyavathi',
            'Department': 'CCA',
            'EmailId': 'sowbakiyavathi@servion.com',
            'MobileNumber': '9876543210'
        },
        {
            'Userid': 'John',
            'UserName': 'John Albert',
            'Department': 'CCA',
            'EmailId': 'john@servion.com',
            'MobileNumber': '9876543210'
        },
        {
            'Userid': 'Srini',
            'UserName': 'Srinivasan',
            'Department': 'CCA',
            'EmailId': 'srini@servion.com',
            'MobileNumber': '9876543210'
        },
        {
            'Userid': 'Dinesh',
            'UserName': 'Dinesh Kumar',
            'Department': 'CCA',
            'EmailId': 'dinesh@servion.com',
            'MobileNumber': '9876543210'
        }
    ];

    $scope.ADUserGrid = {
        enableColumnResizing: true,
        enableFiltering: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                width: '10%',
                enableSorting: false,
                enableFiltering: false,
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            {
                name: 'User ID',
                field: 'Userid',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'User Name',
                field: 'UserName',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Email Id',
                field: 'EmailId',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Mobile Number',
                field: 'MobileNumber',
                headerCellClass: $scope.highlightFilteredHeader
            },
            {
                name: 'Select User',
                enableFiltering: false,
                width: '10%',
                cellTemplate: '<input type="checkbox" />'
            },
        ]
    };

    // $scope.ADUserGrid.data = $scope.ADUserData;

    $scope.showAdd = function () {
        $('#addUser').modal('show');
    }

    $scope.showView = function () {
        $scope.EditView = false;
        $('#modifyUser').modal('show');
    }

    $scope.showEdit = function () {
        $scope.EditView = true;
        $('#modifyUser').modal('show');
    }

    $scope.showDelete = function () {
        $('#confirmModal').modal('show');
    }

    $scope.GetAllAdUsers = function () {
        // 
        userFactory.GetAllSSOUsers('*').then(
            function success(data) {
                // 
                // 
                $scope.ADUserGrid.data = data.data;
            },
            function error(error) {
                // 
            }
        )
    }

    $scope.GetAllAdUsers();


    $scope.profileModel = [{
            listName: "Available Profile",
            items: [],
            dragging: false
        },
        {
            listName: "Selected Profile",
            items: [],
            dragging: false
        }
    ];

    $scope.GetAllProfile = function () {

        userFactory.GetAllProfile().then(
            function success(data) {

                $scope.profileModel[0].items = data.data;
            },
            function error(error) {

            }
        )
    }
    $scope.GetAllProfile();




    // Generate the initial model
    // angular.forEach($scope.profileModel, function(list) {
    //     for (var i = 1; i <= 4; ++i) {
    //         list.items.push({ label: "Item " + list.listName + i });
    //     }
    // });

    $scope.getSelectedItemsIncluding = function (list, item) {
        item.selected = true;
        return list.items.filter(function (item) {
            return item.selected;
        });
    };

    $scope.onDragstart = function (list, event) {
        list.dragging = true;
        // if (event.dataTransfer.setDragImage) {
        //     var img = new Image();
        //     img.src = 'framework/vendor/ic_content_copy_black_24dp_2x.png';
        //     event.dataTransfer.setDragImage(img, 0, 0);
        // }
    };

    $scope.onDrop = function (list, items, index) {
        angular.forEach(items, function (item) {
            item.selected = false;
        });
        list.items = list.items.slice(0, index)
            .concat(items)
            .concat(list.items.slice(index));
        return true;
    };

    $scope.onMoved = function (list) {
        list.items = list.items.filter(function (item) {
            return !item.selected;
        });
    };



}])