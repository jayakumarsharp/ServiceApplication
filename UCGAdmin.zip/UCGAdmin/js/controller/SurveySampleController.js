//SurveySampleController
app.controller('SurveySampleController', ['$scope', '$rootScope', '$q', '$timeout', '$http', '$filter', 'toaster', 'surveyFactory', 'surveyCampFactory', 'missCall', function ($scope, $rootScope, $q, $timeout, $http, $filter, toaster, surveyFactory, surveyCampFactory, missCall) {
    //* Private Variable declaration  */
    $('.modal-dialog .card').resizable().draggable();
    var getAllSamples = function () {
        var departmentName = (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN) ? -1 : $rootScope.departmentName;
        var postdata = {
            departmentId: departmentName,
            user: 'ALL'
        };
        surveyFactory.getAllSamples(postdata).then(
            function success(data) {
                if (data.data && data.data.length) {
                    $scope.samples = data.data;
                    for (var i = 0; i < $scope.samples.length; i++) {
                        $scope.samples[i].ProcessRecords = $scope.samples[i].TotalRecords;
                    }

                    $scope.Samplegrid.data = $scope.samples;

                }
            },
            function err(data) {

            });
    };
    var init = function () {
        getDepartments();
        $scope.GetAllCampaignbyDept();
        getAllSamples();
    };

    init();
}]);