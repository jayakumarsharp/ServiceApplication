app.controller('assignSurveyController', ['$scope', '$sce', '$rootScope', '$q', '$timeout', 'toaster', 'missCall', 'surveyFactory', 'uiGridConstants', 'uiGridExporterConstants', function ($scope, $sce, $rootScope, $q, $timeout, toaster, missCall, surveyFactory, uiGridConstants, uiGridExporterConstants) {


    $scope.showDatePopup = [];
    $scope.showDatePopup.push({
        opened: false
    });
    $scope.showDatePopup.push({
        opened: false
    });
    $scope.selectedGridData = [];
    $scope.assignedUsers = [];
    $scope.finesseUsers = [];
    $scope.sursubjectivedata = [];
    $scope.isValid = false;
    $scope.IsexportDisable = true;
    $scope.IsselectedGrid = false;
    $scope.IsselectedUsers = false;
    $scope.isgridShow = false;
    $scope.isDataEmpty = true;
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId;

    // $rootScope.departmentName = "8";
    $('.modal-dialog .card').resizable().draggable();
    $scope.multiselect = {
        selected: [],
        options: [],
        config: {
            hideOnBlur: false,
            showSelected: false,
            itemTemplate: function (item) {
                return $sce.trustAsHtml(item.name);
            },
            labelTemplate: function (item) {
                return $sce.trustAsHtml(item.name);
            }
        }
    };
 
    $scope.displayUsers = function () {
        return $scope.multiselect.selected.map(function (each) {
            return each.name;
        }).join(', ');
    };



    $scope.ms = {
        startDate: new Date(),
        endDate: new Date()
    }

    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        $scope.open = {};
        e.preventDefault();
        e.stopPropagation();

        $scope.open[date] = true;
    };

    $scope.subSurveygrid = {
        //    enableFiltering: true,
        enableRowSelection: true,
        enableSelectAll: true,
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        multiSelect: true,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                var msg = 'row selected on single' + row.isSelected;
                console.log(msg);

                if (row.isSelected == true) {
                    $scope.IsselectedGrid = true;
                    $scope.selectedGridData.push(row.entity.ID);
                } else {
                    $scope.IsselectedGrid = false;
                    $scope.selectedGridData.splice($scope.selectedGridData.indexOf(row.entity.ID), 1);

                }

                console.log($scope.selectedGridData);

            });

            gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
                var msg = 'row length:' + row.length;
                console.log(msg);
                if (row.length > 0) {
                    $scope.selectedGridData = [];
                    for (index = 0; index < row.length; index++) {
                        console.log(row[index]);
                        if (row[index].isSelected == true) {
                            $scope.IsselectedGrid = true;
                            $scope.selectedGridData.push(row[index].entity.ID);
                        } else {
                            $scope.IsselectedGrid = false;

                        }

                    }
                }
                if ($scope.IsselectedGrid == false) {
                    $scope.selectedGridData = null;
                    $scope.selectedGridData = [];
                }


                console.log($scope.selectedGridData);

            });
        },
    };


    $scope.assignUsers = function () {
        $scope.assignedUsers = [];
        var msUsers = $scope.multiselect.selected;
        if (msUsers.length == 0 || msUsers == "") {
            $scope.assignedUsers = null;
            $scope.IsselectedUsers = false;
        }
        for (index = 0; index < msUsers.length; index++) {
            console.log("msUsers", msUsers[index]);
            if (msUsers[index].name != 'ALL') {
                $scope.assignedUsers.push(msUsers[index].name);
                $scope.IsselectedUsers = true;
            }

        }

    }

    $scope.finesseAgents = function () {
        missCall.finesseAgents()
            .then(function (success) {
                $scope.finesseUsers = success.data;

                success.data.splice(0, 0, {
                    Id: 0,
                    AgentName: "ALL",
                    AgentID: "ALL",
                    Department: ""
                });

                console.log("data", success.data);

                $scope.multiselect.options = success.data.map(function (item) {
                    console.log("item", item);
                    return {
                        name: item.AgentName,
                        id: item.Id
                    };
                });

                console.log("$scope.multiselect.options", $scope.multiselect.options);
            }, function (error) {
                //alert("error");
            });
    }
    $scope.finesseAgents();

    $scope.AssignSubData = function () {


        if ($scope.IsselectedGrid == false) {
            toaster.pop({
                type: "error",
                body: "Please select contcts to assign"
            });
        } else if ($scope.IsselectedUsers == false) {
            toaster.pop({
                type: "error",
                body: "Please select users to assign"
            });
        } else {
            if ($scope.selectedGridData != null && $scope.selectedGridData.length > 0 &&
                $scope.assignedUsers != null && $scope.assignedUsers.length > 0) {

                if ($scope.selectedGridData.length < $scope.assignedUsers.length) {
                    toaster.pop({
                        type: "error",
                        body: "Selected contacts should not be greater than selected users"
                    });
                } else {
                    var mcData = {
                        "Status": "Assigned",
                        "assignedContacts": $scope.selectedGridData,
                        "assignedAgents": $scope.assignedUsers,

                    };

                    surveyFactory.AssignSurSubjective(mcData)
                        .then(function (success) {
                            if (success.data != 0) {
                                toaster.pop({
                                    type: "error",
                                    body: "Selected contacts successfully assigned to selected users"
                                });
                                $scope.multiselect.selected = [];
                                $scope.IsselectedGrid = false;
                                $scope.IsselectedUsers = false;
                                $scope.contactRecords("Unassigned");
                                $scope.finesseAgents();

                            }

                        }, function (error) {
                            console.log("error", error);
                            toaster.pop({
                                type: "error",
                                body: "Error while assigning users"
                            });
                            $scope.IsselectedGrid = false;
                            $scope.IsselectedUsers = false;

                        });
                }
            }

        }

    }


    // Validations

    $scope.formatString = function (format) {
        var day = parseInt(format.substring(0, 2));
        var month = parseInt(format.substring(3, 5));
        var year = parseInt(format.substring(6, 10));
        var date = new Date(year, month - 1, day);
        return date;
    }
    $scope.clearUsers = function () {
        $scope.multiselect = {
            selected: [],
            options: [],
            config: {
                hideOnBlur: false,
                showSelected: false,
                itemTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                },
                labelTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                }
            }
        };
        $scope.finesseAgents();
    }

    var IsValidInputs = function () {
        $scope.isValid = false;

        var now = new Date();

        var currentDate = new Date(now);
        var startDate = new Date($scope.ms.startDate);
        var endDate = new Date($scope.ms.endDate);

        // var output = (datetwo - dateone) / 1000 / 60 / 60 / 24;
        $scope.currentStDayDiff = Math.round((startDate - currentDate) / 1000 / 60 / 60 / 24);
        $scope.currentEnDayDiff = Math.round((endDate - currentDate) / 1000 / 60 / 60 / 24);
        $scope.stendDayDifference = Math.round((startDate - endDate) / 1000 / 60 / 60 / 24);
        var timediffinseconds = moment(currentDate, "DD/MM/YYYY HH:mm:ss").diff(moment(startDate, "DD/MM/YYYY HH:mm:ss"));


        if ($scope.ms.startDate == null && (!moment(startDate, "DD/MM/YYYY HH:mm", true).isValid())) {
            toaster.pop({
                type: "error",
                body: "Please enter valid Start date time"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.ms.endDate == null && (!moment(endDate, "DD/MM/YYYY HH:mm", true).isValid())) {
            toaster.pop({
                type: "error",
                body: "Please enter valid End date time"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.currentStDayDiff > 0) {

            toaster.pop({
                type: "error",
                body: "Start date should not be greater than current date"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.currentEnDayDiff > 0) {

            toaster.pop({
                type: "error",
                body: "End date should not be greater than current date"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.stendDayDifference > 0) {

            toaster.pop({
                type: "error",
                body: "Start date should not be greater than end date"
            });
            $scope.isValid = false;
            return;
        }

        $scope.isValid = true;
    }


    $scope.getSearchData = function () {

        IsValidInputs();
        if ($scope.isValid == true) {
            var filterData = {
                "FromDate": moment($scope.ms.startDate).format('YYYY-MM-DD HH:mm:ss'),
                "ToDate": moment($scope.ms.endDate).format('YYYY-MM-DD HH:mm:ss'),
                "DepartmentNumber": 'ALL'
            };

            console.log("filterData", filterData);
            surveyFactory.GetAllSubjectiveSurvey(filterData)
                .then(function (success) {
                    $scope.sursubjectivedata = success.data;

                    if ($scope.sursubjectivedata != null && $scope.sursubjectivedata.length > 0) {
                        $scope.IsexportDisable = false;
                        $scope.isgridShow = true;
                        $scope.isDataEmpty = false;
                        $scope.subSurveygrid.data = $scope.sursubjectivedata;
                    } else {
                        $scope.IsexportDisable = true;
                        $scope.isgridShow = false;
                        $scope.sursubjectivedata.length = 0;
                        $scope.subSurveygrid.data = null;
                        $scope.isDataEmpty = true;

                        // toaster.pop({ type: "error", body: "No record found" });
                        if ($scope.subSurveygrid.data != null && $scope.subSurveygrid.data.length > 0) {
                            $scope.IsexportDisable = false;
                        } else {
                            $scope.IsexportDisable = true;
                        }

                    }

                }, function (error) {
                    //alert("contacterror");
                });
        } else {

            $scope.IsexportDisable = true;
            $scope.sursubjectivedata.length = 0;
            $scope.subSurveygrid.data = null;
            $scope.isgridShow = false;



        }

    }

    $scope.getSearchData();



}]);