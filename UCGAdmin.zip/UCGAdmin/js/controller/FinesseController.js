app.controller('FinesseController', function($scope, $rootScope, $http) {

})