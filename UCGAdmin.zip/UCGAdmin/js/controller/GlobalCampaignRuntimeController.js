app.controller('GlobalCampaignRuntimeController', function ($scope, $rootScope, masterDataFactory,toaster) {
    $scope.smsCodeEdit = [];
    $scope.Formlist = {};
    $scope.SmsCode={};

    $scope.globalCampOptions = {
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1,
        columnDefs: [
            { name: 'Department', field: 'DepartmentName' },
            { name: 'ApplicationUse', field: 'ApplicationUse' },

            { name: 'StartDate', field: 'StartDate', cellFilter: 'date:"dd-MM-yy HH:mm"' },
            { name: 'EndDate', field: 'EndDate', cellFilter: 'date:"dd-MM-yy HH:mm"' },
            //{ name: 'CodeDescription', field: 'CodeDescription' },

            { name: 'Options', enableSorting: false, enableFiltering: false, width: '10%', cellTemplate: '<a href="#" ng-click="grid.appScope.showEdit(row.entity)"><span class="fa fa-pencil"></span></a> | <a href="#" ng-click="grid.appScope.showDelete(row.entity)"><span class="fa fa-trash-o"></span></a>' }
        ],
    };
    $scope.globalCampOptions.data = [
        { 'DepartmentName': 'R001', 'ApplicationUse': 'SMS', 'StartDate': '25/10/2017 12:30', 'EndDate': '25/10/2017 12:30'},
        { 'DepartmentName': 'R002', 'ApplicationUse': 'SURVEY', 'StartDate': '25/10/2017 12:30', 'EndDate': '25/10/2017 12:30'},
        { 'DepartmentName': 'R003', 'ApplicationUse': 'CAMPAIGN', 'StartDate': '25/10/2017 12:30', 'EndDate': '25/10/2017 12:30'},

    ];

    $('.modal-dialog .card').resizable().draggable();
    //dropdown values
    // $scope.GetApplicationName = function () {
    //     
    //     masterDataFactory.GetApplicationName().then(
    //         function success(data) {
    //             
    //             // console.log("editSMS",data);
    //             $scope.ApplicationUseDropDownValue = data.data;
    //         },
    //         function error(data) {
    //             
    //         }
    //     )
    // }

    // $scope.GetApplicationName();
    // $scope.GetDepartmentName = function () {
    //     
    //     masterDataFactory.GetDepartmentName().then(
    //         function success(data) {
    //             
    //             // console.log("editSMS",data);
    //             $scope.DepartmentDropDownValue = data.data;
    //         },
    //         function error(data) {
    //             
    //         }
    //     )
    // }
    // $scope.GetDepartmentName();
    // //  $scope.DepartmentValue=["R001","R002","R003","R004","R005"];
    // // $scope.ApplicationUseDropDownValue=["SMS","SURVEY","COMPAIGN"];
    // $scope.Type = ["Short", "Long"];


    // $scope.GetSmsCode = function () {
    //     
    //     masterDataFactory.GetSmsCode().then(
    //         function success(data) {
    //             
    //             console.log("edit", data);
    //             $scope.gridSmsCodeOptions.data = data.data;
    //         },
    //         function error(data) {
    //             
    //         }
    //     )
    // }
    // $scope.GetSmsCode();

    // //  $scope.gridSmsCodeOptions.data = $scope.SmsCodeData;

    $scope.showAdd = function () {
        //console.log("hi");
       

        $('#AddCampaignRuntime').modal('show');
        
    }
   // $scope.voiceCampaigns.startDate;

    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
      
        e.preventDefault();
        e.stopPropagation();
        $scope.open = {};
        $scope.open[date] = true;
    };

    $scope.showEdit = function (getRowData) {
        // $scope.smsCodeEdit = {};
        // // console.log("edit2", getRowData);
        // $scope.smsCodeEdit.Department = getRowData.Department;
        // $scope.smsCodeEdit.ApplicationUse = getRowData.ApplicationUse;
        // $scope.smsCodeEdit.Type = getRowData.Type;
        // $scope.smsCodeEdit.CodeName = getRowData.CodeName;
        // $scope.smsCodeEdit.CodeDescription = getRowData.CodeDescription;
        // $scope.smsCodeEdit.ShortCodeID = getRowData.ShortCodeID;

        //console.log("hello");
        $scope.EditView = true;
        $('#modifyCampaignRuntime').modal('show');
    }

    // $scope.CreateSmsCodes = function () {

    //     $scope.SmsCodeAdd = {};

    //    // $scope.SmsCodeAdd.ThresholdType = 2;
    //     $scope.SmsCodeAdd.UpdatedBy = 'Admin';

    //     $scope.SmsCodeAdd.DepartmentID = $scope.Formlist.DepartmentID;
    //     $scope.SmsCodeAdd.ApplicationID = $scope.Formlist.ApplicationID;
    //     $scope.SmsCodeAdd.CodeName = $scope.Formlist.CodeName;
    //     $scope.SmsCodeAdd.CodeDescription = $scope.Formlist.CodeDescription;
    //     $scope.SmsCodeAdd.CodeType = $scope.Formlist.CodeType;
    //     $scope.SmsCodeAdd.LastModifiedBy = '2017-10-13 17:47:33.460';

    //     masterDataFactory.CreateSmsCode($scope.SmsCodeAdd).then(function (data) {
    //         
    //         

    //         if (data.data == "Success") {
    //             $scope.GetSmsCode();                
    //             $('#AddShortCode').modal('hide');
    //             toaster.pop({ type: "Success", body: "SMS Code Created successfully"});

    //         }
    //         else {
    //             $scope.GetSmsCode();
    //             toaster.pop({ type: "error", body: "Error while creating SMS Code"});

    //         }
    //     });

    // }

    // $scope.showEdit = function (getRowData) {
    //     $scope.smsCodeEdit = {};
    //     // console.log("edit2", getRowData);
    //     $scope.smsCodeEdit.DepartmentID = getRowData.DepartmentID;
    //     $scope.smsCodeEdit.ApplicationID = getRowData.ApplicationID;
    //     $scope.smsCodeEdit.CodeType = getRowData.CodeType;
    //     $scope.smsCodeEdit.CodeName = getRowData.CodeName;
    //     $scope.smsCodeEdit.CodeDescription = getRowData.CodeDescription;
    //     $scope.smsCodeEdit.ShortCodeID = getRowData.ShortCodeID;

    //     //console.log("hello");
    //     $scope.EditView = true;
    //     $('#modifyShortCode').modal('show');
    // }

    // $scope.UpdateSmsCodes = function () {
        
    //             $scope.SmsCodeUpdate = {};
        
    //             $scope.SmsCodeUpdate.UpdatedBy = 'Admin';
                
    //                     $scope.SmsCodeUpdate.DepartmentID = $scope.smsCodeEdit.DepartmentID;
    //                     $scope.SmsCodeUpdate.ApplicationID = $scope.smsCodeEdit.ApplicationID;
    //                     $scope.SmsCodeUpdate.CodeName = $scope.smsCodeEdit.CodeName;
    //                     $scope.SmsCodeUpdate.CodeDescription = $scope.smsCodeEdit.CodeDescription;
    //                     $scope.SmsCodeUpdate.CodeType = $scope.smsCodeEdit.CodeType;
    //                   //  $scope.SmsCodeUpdate.LastModifiedBy = '2017-10-13 17:47:33.460';
    //                     $scope.SmsCodeUpdate.ShortCodeID = $scope.smsCodeEdit.ShortCodeID;
        
    //             masterDataFactory.UpdateSmsCode($scope.SmsCodeUpdate).then(function (data) {
    //                 
    //                 
        
    //                 if (data.data == "Success") {
    //                     $scope.GetSmsCode();
        
    //                     $('#modifyShortCode').modal('hide');
    //                     toaster.pop({ type: "Success", body: "SMS Code Modified successfully"});
        
    //                 }
    //                 else {
    //                     $scope.GetSmsCode();
    //                      toaster.pop({ type: "error", body: "Error while Modifying SMS Code"});
        
    //                 }
    //             });
        
    //         }
    //     //Delete functionality
    // $scope.showDelete = function (getRowData) {
    //     //$scope.ussdCodeDelete = {};
       
    //     $scope.CodeID = getRowData.ShortCodeID;
    //     $scope.EditView = true;
    //     $('#confirmModal').modal('show');
    // }

    // $scope.Delete=function(){
    //   // $scope.ussdCodeDelete = {};
    //      var CodeID=$scope.CodeID;
    //      masterDataFactory.DeleteSmsCode(CodeID).then(function (data) {
    //         
    //         

    //         if (data.data == "Success") {
    //             $scope.GetSmsCode();

    //             $('#confirmModal').modal('hide');
    //             toaster.pop({ type: "Success", body: "SMS Code Deleted successfully"});

    //         }
    //         else {
    //             $scope.GetSmsCode();
    //             //   toaster.pop({ type: "error", body: "Error while creating USSD Threshold", toasterId: 1 });

    //         }
    //     });

    // }



});