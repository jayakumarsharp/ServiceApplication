app.controller('VoiceBiometricContoller',
              ['$scope', 'appFactory', 'voiceBioMetricFactory', 
    function ($scope, appFactory, voiceBioMetricFactory) {
    
    var vm = this;
    
    $scope.permissions = appFactory.permissions[appConst.MENUS.VCE_BIO];
    var voicePrintLock = [];
    var enrollments = [];
    vm.selectedSpeakerIds = [];
    vm.selectedSpeakerId = '';
    vm.reasonForLocking = '';
    vm.searchIndex = '';
    vm.sessionId;
    vm.voiceBioMetricGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [25, 50, 75],
        paginationPageSize: 25,
        isValidUser: true,
        columnDefs: [
            { name: 'Speaker ID', field: 'SPEAKER_ID', isSearchable: true},
            { name: 'Created Date', field: 'TIMESTAMP', cellFilter: 'date:"dd/MM/yyyy HH:mm"' },
            { name: 'Status', field: 'ACTIVITYTYPE', isSearchable: true},
            { name: 'Action',enableSorting: false,
              cellTemplate: '<a href="#" ng-if="(row.entity.ACTIVITYTYPE === \'Activated\' && grid.appScope.permissions.Modify)" ng-click="grid.appScope.vm.showLockModel(row.entity)"><span class="fa fa-lock" title="Lock"></span></a>' +
                            '<span class="fa fa-lock" title="Lock" ng-if="(row.entity.ACTIVITYTYPE === \'Activated\' && !grid.appScope.permissions.Modify)"></span>' +
                            '<a href="#" ng-if="(row.entity.ACTIVITYTYPE === \'Deactivated\' && grid.appScope.permissions.Modify)" ng-click="grid.appScope.vm.unLock(row.entity)"><span class="fa fa-unlock" title="Unlok"></span></a>' +
                            '<span ng-if="(row.entity.ACTIVITYTYPE === \'Deactivated\' && !grid.appScope.permissions.Modify)" class="fa fa-unlock" title="Unlok"></span>' 
                            // '| <a href="#" data-toggle="modal" data-target="#delete-popup" ng-click="grid.appScope.vm.delete(row.entity)"><span class="fa fa-trash-o" title="Assign Ticket"></span></a>'
          }
        ],
        onRegisterApi: function (gridApi) {
            vm.gridApi = gridApi;
            // vm.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
            //     vm.onContactsSelected('Single', row);
            // });

            // vm.gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
            //     vm.onContactsSelected('', row);
            // });
        },
    };

    vm.onContactsSelected = function (type, row) {
        if (type === 'Single') {
            if (row.isSelected == true) {
                vm.selectedSpeakerIds.push(row.entity.SPEAKER_ID);
            } else {
                vm.selectedSpeakerIds.splice(vm.selectedSpeakerIds.indexOf(row.entity.SPEAKER_ID), 1);
            }
        } else {
            if (row.length < 1) {
                manualCall.selectedGridData = [];
                return;
            }
            for (index = 0; index < row.length; index++) {
                if (row[index].isSelected == true) {
                    vm.selectedSpeakerIds.push(row[index].entity.SPEAKER_ID);
                } else {
                    vm.selectedSpeakerIds = [];
                }
            }
        }
    };
    
    vm.showLockModel = function(row) {
        vm.reasonForLocking = '';
        vm.selectedSpeakerId = row.SPEAKER_ID;
        $('#modify-voice-print').modal('show');
    };

    vm.onLockVoicePrint = function() {
        var params = {
            speakerId: vm.selectedSpeakerId,
            reason: vm.reasonForLocking
        };
        startSession(function(sessionID) {
            params.sessionId = 0;
            vm.sessionId = sessionID;
            voiceBioMetricFactory.lock(params, cbsLock).then(cbsLock, cbfActions);
        });
    };

    var cbsLock = function(res) {
        appFactory.HideLoader();
        if (res && res.data === 'Failure') {
            cbfActions();
        }
        $('#modify-voice-print').modal('hide');
        // voiceBioMetricFactory.endSession(vm.sessionId);
        vm.selectedSpeakerId = '';
        getVoiceBioMetrics();
    };

    vm.unLock = function(row) {
        appFactory.ShowLoader();
        var params = {
            speakerId: row.SPEAKER_ID
        };
        startSession(
            function(sessionID) {
                params.sessionId = 0;
                vm.sessionId = sessionID;
                voiceBioMetricFactory.unLock(params).then(cbsLock, cbfActions);
            }
        );
    };

    var cbfActions = function() {
        appFactory.HideLoader();
        appFactory.showToasterErr('Internal server error');
    };

    var startSession = function(cbsSetSession) {
        voiceBioMetricFactory.startSession().then(
            function(res) {
                if (res && res.data && res.data.sessionIdField) {
                    cbsSetSession(res.data.sessionIdField);
                }
            },
            function(res) {
                cbfActions();
            }
        )
    };

    var getVoicePrintLock = function() {
        var params = {
            startDate : moment().subtract(1, 'years').format('MM/DD/YYYY h:mm:ssA'),
            endDate : moment().format('MM/DD/YYYY h:mm:ssA'),
            type : voiceBioMetricFactory.reportTypes.ENROLL,
        }
        /* Reading data from file all are handled in service **/
        voiceBioMetricFactory.getReportsPath(params, getEnrollments);
    };

    var getEnrollments = function() {
        enrollments = voiceBioMetricFactory.parsedReportsData;
        var params = {
            startDate : moment().subtract(1, 'years').format('MM/DD/YYYY h:mm:ssA'),
            endDate : moment().format('MM/DD/YYYY h:mm:ssA'),
            type : voiceBioMetricFactory.reportTypes.VOICE_PRINT,
        }
        /* Reading data from file all are handled in service **/
        voiceBioMetricFactory.getReportsPath(params, prepareVoiceBioMetricData);
    };

    var prepareVoiceBioMetricData = function() {
        voicePrintLock = voiceBioMetricFactory.parsedReportsData;
        vm.voiceBioMetricGrid.data = [];
        if (!enrollments || !enrollments.length) {
            return;
        }
        var deactivedSpeakerIds = [];
        if (voicePrintLock && voicePrintLock.length && voicePrintLock[0].SPEAKER_ID) {
            deactivedSpeakerIds = _.map(voicePrintLock, function(voicePrint) {
                return voicePrint['SPEAKER_ID'];
            });
        }
        enrollments.forEach(function(enroll) {
            enroll['ACTIVITYTYPE'] = 'Activated';
            if (deactivedSpeakerIds && deactivedSpeakerIds.length) {
                var isDeactivatedSpeakerID = _.contains(deactivedSpeakerIds, enroll['SPEAKER_ID']);
                if (isDeactivatedSpeakerID) {
                    enroll['ACTIVITYTYPE'] = 'Deactivated';
                }
            }
        });
        vm.voiceBioMetricGrid.data = enrollments;
        getSearchableFields(vm.voiceBioMetricGrid);
        vm.gridApi.core.refresh();
        appFactory.HideLoader();
    };

    vm.onTypeSearchValues = function onTypeSearchValues() {
        var filteredData = appFactory.getDataBySearchIndex(vm.searchIndex);
        vm.voiceBioMetricGrid.data = filteredData;
    };

    var getSearchableFields = function (gridConfig) {
        vm.searchIndex = '';
        appFactory.getSearchableFields(gridConfig);
    };
    var getVoiceBioMetrics = function() {
        appFactory.ShowLoader();
        getVoicePrintLock();
        
    };

    var init = function() {
        getVoiceBioMetrics();
    };

    init();
}]);