app.controller('CampaignViewController', ['$scope', '$rootScope', '$q', '$timeout', '$http', '$filter', 'toaster', 'campaignFactory', '_', function ($scope, $rootScope, $q, $timeout, $http, $filter, toaster, campaignFactory, _) {

    // Global variable declarations
    $scope.ReportFilter = {};
    $scope.selectedcamp = {};
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $rootScope.departmentName = userObj.departmentId;
    //$rootScope.departmentName = "103";
    $('.modal-dialog .card').resizable().draggable();

    $scope.CampaignReportGrid = {
        enableColumnResizing: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        columnDefs: [{
                name: 'S.No',
                enableSorting: false,
                width: '10%',
                cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
            },
            // { name: 'CampaignGroup', field: 'CampaignGroup' },
            {
                name: 'Campaign Name',
                field: 'CampaignID'
            },
            {
                name: 'Call StartDateTime',
                field: 'CallStartDateTime',
                cellFilter: 'date:"dd-MM-yy HH:mm"'
            },
            {
                name: 'Call EndDateTime',
                field: 'CallEndDateTime',
                cellFilter: 'date:"dd-MM-yy HH:mm"'
            },
            // { name: 'Call Mode', field: 'CallMode' },
            {
                name: 'Dialed Number',
                field: 'DialedNumber'
            },
            {
                name: 'OutCome',
                field: 'OutCome'
            },
        ]
    };




    $scope.changecampaignreport = function () {
        console.log($scope.selectedcamp);

        $scope.getdata($scope.selectedcamp.CampaignName.CampaignName)
    }

    // ***** Private Methods ***** //

    $scope.GetAllcampaign = function () {
        if ($rootScope.departmentName != null && $rootScope.departmentName != undefined) {
            campaignFactory.GetAllCampaignList($rootScope.departmentName).then(function (data) {
                if (data.data != null && data.data != undefined) {
                    $rootScope.allCampaignList = data.data;
                } else {
                    $rootScope.allCampaignList = [];
                }
            });
        }
    }
    $scope.getdata = function (obj) {
        $scope.ReportFilter.campaignName = obj;
        $scope.ReportFilter.departmentID = $rootScope.departmentName;

        campaignFactory.GetDetailedCampaignReport($scope.ReportFilter).then(function (data) {
            if (data && data.data) {
                $scope.CampaignReportGrid.data = data.data;
            } else {
                $scope.CampaignReportGrid.data = [];
            }
        });
    }
    $scope.GetAllcampaign();
}]);