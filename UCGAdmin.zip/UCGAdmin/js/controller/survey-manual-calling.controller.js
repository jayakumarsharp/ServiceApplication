app.controller('ManualCallingController', ['$scope', '$sce', '$rootScope', 'toaster', 'missCall', 'appFactory', 'surveyCampFactory', 'profileFactory', 'masterDataFactory', 'uiGridExporterConstants', 'profileFactory', function ($scope, $sce, $rootScope, toaster, missCall, appFactory, surveyCampFactory, profileFactory, masterDataFactory, uiGridExporterConstants, profileFactory) {
    
        var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
        // $rootScope.departmentName = userObj.departmentId;
        
        manualCall = this;
		manualCall.AssignedContact=false;
        $scope.depName = '';
        manualCall.appFactory = appFactory;
        manualCall.appConst = appConst;
        manualCall.permissions = appFactory.permissions[appConst.MENUS.RCHK_MGMT.MNL_CALL];
        manualCall.departments = [];
        manualCall.selectedContactsId = [];
        $scope.showContactsAssigned = false;
        manualCall.permissions = {
            'Add': true,
            'Modify': true
        };
    var userObj = {
         SSOID: '',
         departmentId:103
     }
        manualCall.filter = {
                sampleType: '',
                departmentType: '',
                phoneNo: '',
                startDate: '',
                endDate: ''
            },
            manualCall.gridConfig = {
                 enableRowSelection: true,
                enableSelectAll: true,
                paginationPageSizes: [10, 20, 30],
                paginationPageSize: 10,
                enableColumnMenus: false,
                enableHorizontalScrollbar: 1,
                enableVerticalScrollbar: 1,
                data: [],
                columnDefs: [{
                        name: 'S.No',
                        width: '10%',
                        enableSorting: false,
                        cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'
                    },
                    {
                        name: 'Citizen Name',
                        field: 'CITIZEN_NAME',
                        cellTooltip: true
                    },
                    {
                        name: 'Mobile Number',
                        field: 'MOBILE_NO',
                        cellTooltip: true
                    },
                    {
                        name: 'Question Set',
                        field: 'questionsetname',
                        cellTooltip: true
                    },
                   
                    
                ],
                multiSelect: true,
                onRegisterApi: function (gridApi) {
                    manualCall.gridApi = gridApi;
                    manualCall.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                        manualCall.onContactsSelected('Single', row);
                    });
    
                    manualCall.gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
                        manualCall.onContactsSelected('', row);
                    });
                },
            };
        manualCall.multiselect = {
            selected: [],
            options: [],
            config: {
                hideOnBlur: false,
                showSelected: false,
                itemTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                },
                labelTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                }
            }
        };
    
         manualCall.selectVisible = function() {
        //selectAllVisibleRows(event)  
        //	alert("Visible rows: " + (manualCall.gridApi.core.getVisibleRows(manualCall.gridApi.grid)).length);  
                for(var i=0; i<manualCall.gridConfig.paginationPageSize; i++){   
                manualCall.gridApi.selection.selectRowByVisibleIndex(i);  
                }  
            
            
        }
    
       
        manualCall.onContactsSelected = function (type, row) {
            if (type === 'Single') {
                if (row.isSelected == true) {
                    manualCall.selectedContactsId.push(row.entity.ID);
                } else {
                    manualCall.selectedContactsId.splice(manualCall.selectedContactsId.indexOf(row.entity.ID), 1);
                }
            } else {
                if (row.length > 0) {
                    for (index = 0; index < row.length; index++) {
                        if (row[index].isSelected == true) {
                            manualCall.selectedContactsId.push(row[index].entity.ID);
                        } else {
                            manualCall.selectedContactsId = [];
                        }
                    }
                } else {
                    manualCall.selectedGridData = [];
                }
            }
        };
    
      
    
        manualCall.showAssignpopup = function () {
            getFinesseAgents();
            angular.element('#assignUserModal').modal('show');
    
        };
    
        manualCall.oncloseAssignContact = function () {
            manualCall.multiselect.selected = [];
        };
    
        manualCall.onAssignContacts = function () {
    
            var manualCallData = {
                Status: 'Assigned',
                assignedContacts: manualCall.selectedContactsId,
                assignedAgents: getAssignUsers()
            }
            surveyCampFactory.assignManualCalls(manualCallData).then(function (data) {
                if (data.data === 'SUCCESS') {
                    manualCall.onSearchManualcallContacts(true);
                    toaster.pop({
                        type: "success",
                        body: "Selected contacts successfully assigned to selected users"
                    });
                    angular.element('#assignUserModal').modal('hide');
                    //getContactsByFilter(criteria);
                    manualCall.multiselect.selected = [];
                } else {
    
                }
            });
        };
    
        var getAssignUsers = function () {
            var selectedUsers = manualCall.multiselect.selected;
            var assignedUsers = [];
            for (index = 0; index < selectedUsers.length; index++) {
                // if (selectedUsers[index].name != 'ALL') {
                assignedUsers.push(selectedUsers[index].name);
                // }
            }
            return assignedUsers;
        };
    
        /* for calender open and close **/
        manualCall.open = {
            startDate: false,
            endDate: false
        };
    
        manualCall.openCalendar = function (e, date) {
            e.preventDefault();
            e.stopPropagation();
            manualCall.open[date] = true;
        };
    
    
        var loadSearchManualcallContacts = function () {
            var filter = manualCall.filter;
            var criteria = {
                startdate: moment(filter.startDate).add(-7, 'days').format('YYYY-MM-DD HH:mm:ss'),
                enddate: moment(filter.endDate).format('YYYY-MM-DD HH:mm:ss'),
                mobileNo: 'ALL',
                sampleName: 'ALL',
                department: JSON.parse(userObj.departmentId)
            };
            // setTimeout(function () {
            //    manualCall.filter.departmentObj = getDeparmentObj(Number(userObj.departmentId), false);
            // });
         
            getContactsByFilter(criteria);
        };

        manualCall.showAssignedRecored = function(){
             manualCall.gridConfig.columnDefs.push( {
                name: 'Assigned User',
                field: 'USER',
                cellTooltip: true
            });
            manualCall.onSearchManualcallContacts();
        }
    
        manualCall.onSearchManualcallContacts = function (isCallback) {
            if (!isCallback) {
                var departmentObj  = getDeparmentObj(manualCall.filter.departmentType.DepartmentName, true);
                manualCall.filter.departmentObj  = departmentObj;
            }
            var criteria = {
                showAssigned: manualCall.AssignedContact,
                startdate: moment(manualCall.filter.startDate).format('YYYY-MM-DD HH:mm:ss'),
                enddate: moment(manualCall.filter.endDate).format('YYYY-MM-DD HH:mm:ss'),
                mobileNo: (manualCall.filter.mobileNo) ? manualCall.filter.mobileNo : 'ALL',
                sampleName: (manualCall.filter.sampleType) ? manualCall.filter.sampleType : 'ALL',
            };
            if ((manualCall.appFactory.rights.type !== manualCall.appConst.RIGHTS_TYPES.SUPER_ADMIN)) {
                criteria.department = userObj.departmentId;
            } else {
                criteria.department = (manualCall.filter.departmentObj && manualCall.filter.departmentObj.ID != -1) ?
                    manualCall.filter.departmentObj.ID : 'ALL';
            }
            getContactsByFilter(criteria);
    
        };
    
        var getContactsByFilter = function (criteria) {
            appFactory.ShowLoader();
            surveyCampFactory.getManualCallContacts(criteria).then(function (data) {
                if (data.data) {
                    appFactory.HideLoader();
                    manualCall.gridConfig.data = data.data;
                }
            });
        };
    
        var getDeparmentObj = function (departmentName, isByDeptName) {
            var deptObj = {};
            if (!isByDeptName) {
                deptObj  =  _.filter(manualCall.departments,  function  (rowdata) {
                    return  rowdata.ID  === departmentName;
                });
            } else {
                deptObj  =  _.filter(manualCall.departments,  function  (rowdata) {
                    return  rowdata.DepartmentName  ===  departmentName;
                });
            }
            return deptObj[0];
        };
    
        var isValidDates = function (startDate, endDate) {
            var currenDate = moment();
            var startDateObj = moment(startDate);
            if (startDateObj.diff(currenDate) < 0) {
                toaster.pop({
                    type: "error",
                    body: "Start date cannot be less than current date"
                });
            }
            var endDateObj = moment(endDate);
            if (endDateObj.diff(startDateObj) < 0) {
                toaster.pop({
                    type: "error",
                    body: "End date cannot be less than Start date"
                });
                return false;
            }
            return true;
        };
        $('.modal-dialog .card').resizable().draggable();
        manualCall.onExportData = function () {
            if (manualCall.gridConfig.data != null && manualCall.gridConfig.data.length > 0) {
                manualCall.gridApi.exporter.csvExport(uiGridExporterConstants.VISIBLE, uiGridExporterConstants.ALL);
            }
        };
        
    
        var setStartAndEndDate = function (obj) {
            var starttime = new Date();
            starttime.setDate(starttime.getDate() - 7);
            starttime.setHours(9);
            starttime.setMinutes(0);
            var endtime = new Date();
            endtime.setHours(23);
            endtime.setMinutes(0);
            obj.startDate = starttime;
            obj.endDate = endtime;
        };
    
        var getFinesseAgents = function (depInfo) {
            var deptfilter = [];
            manualCall.agentflag = false;
            masterDataFactory.GetFinesseAgent().then(function (success) {
                manualCall.finesseUsers = success.data;
                angular.forEach(manualCall.finesseUsers, function (value, key) {
                    if (value.DepartmentId == manualCall.filter.departmentObj.ID) {
                        deptfilter.push(value);
                        manualCall.agentflag = true;
                    }
                }, this);
                if (manualCall.agentflag = false) {
                    deptfilter = success.data;
                }
                success.data.splice(0, 0, {
                    Id: 0,
                    AgentName: "ALL",
                    AgentID: "ALL",
                    DepartmentId: "ALL"
                });
                manualCall.multiselect.options = deptfilter.map(function (item) {
                    return {
                        name: item.AgentName,
                        id: item.Id
                    };
                });
            }, function (error) {});
        };
    
        var getDepartments = function () {
            profileFactory.GetAllDepartment().then(
                function success(data) {
                    manualCall.departments = data.data;
                    manualCall.filter.departmentObj = getDeparmentObj(Number(userObj.departmentId), false);
                    $scope.withoutdata = _.findWhere(manualCall.departments, {
                        ID: JSON.parse(userObj.departmentId)
                    })
                    manualCall.filter.departmentType = $scope.withoutdata;
                    $scope.depName = manualCall.filter.departmentType;
                },
                function error(data) {}
            );
        };
    
        // add sso based user 
    
        manualCall.setUserRoles = function (data) {
            manualCall.validflag = false;
            // manualCall.validflag = true;
            manualCall.UserRoles = [];
            if (data != null && data != undefined && data != 'null') {
                var userDetails = JSON.parse(data);
                manualCall.showStatus = true;
                manualCall.validflag = true;
                manualCall.SSOStatus = 'Valid';
                // $('#agentIDStatus').removeClass('Valid Invalid');
                // $('#agentIDStatus').addClass('Valid');    
                profileFactory.GetSSOUserRoles(userDetails.sAMAccountName).then(
                    function success(data) {
                        var result = data.data;
                        manualCall.CreateFinesseAgent(result);
                    })
    
                // $('#AddFinesseAgent').modal('show'); 
    
            } else {
                manualCall.showStatus = true;
                manualCall.validflag = false;
                manualCall.SSOStatus = 'Invalid';
                // $('#agentIDStatus').removeClass('Valid Invalid');
                // $('#agentIDStatus').addClass('Invalid');
                // manualCall.AdditionalPermissionGrid.data = [];
                // manualCall.UserRoles = [];
            }
    
        }
    
    
        manualCall.GetSSOUserRoles = function (ssoId) {
        
             profileFactory.GetSSOUserRoles(ssoId).then(
                    function success(data) {
                        var addedSSO = JSON.parse(data.data);
                        if(addedSSO.sAMAccountName == ssoId){
                            toaster.pop({   type: "error",  body: "Agent ID already exist"      });
                        }else{
                            manualCall.setUserRoles(data.data);
                        }
                      
                    }
                );
            
        };
    
        manualCall.CreateFinesseAgent = function (data) {
			 var departmentID =  appFactory.getDepartmentFromRole(data);
            var ssoUser = JSON.parse(data);
            if (departmentID != manualCall.filter.departmentObj.ID) {
                manualCall.validflag = false;
                manualCall.SSOStatus = 'Invalid';
                toaster.pop({
                    type: "error",
                    body: "This user doesn't belong to the selected departement"
                });
            } else {
                var FinAgentAdd = {
                    AgentName: ssoUser.sAMAccountName,
                    AgentID: ssoUser.sAMAccountName,
                    // DepartmentName: ssoUser.department,
                    DepartmentID: departmentID
                };
                masterDataFactory.CreateFinesseAgent(FinAgentAdd).then(
                    function success(data) {
                        getFinesseAgents();
                    },
                    function error(data) {
                        toaster.pop({
                            type: "error",
                            body: "Error while Adding Agent"
                        });
                    }
                );
            }
        }
    
        var init = function () {
            getDepartments();
            setStartAndEndDate(manualCall.filter);
            loadSearchManualcallContacts();
    
        };
    
        init();
    }]);