app.controller('assignCallController', ['$scope', '$sce', '$rootScope', '$q', '$timeout','profileFactory','masterDataFactory', 'appFactory', 'toaster', 'missCall', 'uiGridConstants', 'uiGridExporterConstants', function ($scope, $sce, $rootScope, $q, $timeout, profileFactory, masterDataFactory, appFactory, toaster, missCall, uiGridConstants, uiGridExporterConstants) {
    var userObj = JSON.parse(sessionStorage.getItem('SSOUserDetails'));
    $scope.permissions = appFactory.permissions[appConst.MENUS.MSD_CALL.ASN_MSD_CALL];
    $scope.genders = [{
        id: 1,
        value: 'male'
    }, {
        id: 2,
        value: 'female'
    }];
    $scope.departments = [];
    $scope.deptAgents = [];

    // $scope.GetAllMissedCallDepartment = function () {
    //     missCall.GetAllMissedCallDepartment().then(
    //         function success(response) {
    //             $scope.departments = response.data;
    //             $scope.departments.splice(0, 0, {
    //                 DepartmentNumber: 'ALL',
    //                 DepartmentName: "ALL"
    //             });
    //             $scope.ms.deptNumber = 'ALL';
    //         },
    //         function error(response) {
    //             toaster.pop({
    //                 type: "error",
    //                 body: "Failed to Load Department"
    //             });
    //         }
    //     )
    // };
    // $scope.GetAllMissedCallDepartment();


    $scope.status = ["Assigned", "Unassigned", "In Progress", "Closed"];
    //$scope.users = ["User 1 ", "User 2", "User 3", "User 4", "User 5", "User 6"];
    $scope.department = [];
    $scope.showDatePopup = [];
    $scope.showDatePopup.push({
        opened: false
    });
    $scope.showDatePopup.push({
        opened: false
    });
    $rootScope.selectedGridData = [];
    $scope.assignedUsers = [];
    $scope.finesseUsers = [];
    $scope.misscalldata = [];
    $scope.isValid = false;
    $scope.IsexportDisable = true;
    $rootScope.IsselectedGrid = false;
    $scope.IsselectedUsers = false;
    $scope.isgridShow = false;
    $scope.isDisableUserBtn = true;
    $scope.multiselect = {
        selected: [],
        options: [],
        config: {
            hideOnBlur: false,
            showSelected: false,
            itemTemplate: function (item) {
                return $sce.trustAsHtml(item.name);
            },
            labelTemplate: function (item) {
                return $sce.trustAsHtml(item.name);
            }
        }
    };

    $('.modal-dialog .card').resizable().draggable();
    
    $scope.displayUsers = function () {
        return $scope.multiselect.selected.map(function (each) {
            return each.name;
        }).join(', ');
    };

    $scope.checkStatus = function (statusTerm) {
        $scope.contactRecordsSubmit();
        if (statusTerm == 'Unassigned') {
            $scope.isDisableUserBtn = false;
        } else {
            $scope.isDisableUserBtn = true;
        }

    };




    $scope.ms = {
        startDate: new Date(),
        endDate: new Date()
    }
    $scope.ms.startDate.setDate($scope.ms.startDate.getDate() - 7);
    $scope.open = {
        startDate: false,
        endDate: false
    }
    $scope.openCalendar = function (e, date) {
        e.preventDefault();
        e.stopPropagation();
        $scope.open = {};
        $scope.open[date] = true;
    };

    $scope.missedCallgrid = {

        // multiselect:true,
        // modifierKeysToMultiSelect :false,
        // noUnselect :true,
        // enableRowSelection: true, 
        // enableRowHeaderSelection: false,
        enableRowSelection: true,
        enableSelectAll: true,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        multiSelect: true,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                var msg = 'row selected on single' + row.isSelected;
                console.log(msg);
                if (row.isSelected == true) {
                    $rootScope.IsselectedGrid = true;
                    $rootScope.selectedGridData.push(row.entity.ID);
                } else {
                    $rootScope.IsselectedGrid = false;
                    $rootScope.selectedGridData.splice($rootScope.selectedGridData.indexOf(row.entity.ID), 1);
                }
            });

            gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
                var msg = 'row length:' + row.length;
                console.log(msg);
                if (row.length > 0) {

                    for (index = 0; index < row.length; index++) {
                        console.log(row[index]);
                        if (row[index].isSelected == true) {
                            $rootScope.IsselectedGrid = true;
                            $rootScope.selectedGridData.push(row[index].entity.ID);
                        } else {
                            $rootScope.IsselectedGrid = false;
                            $rootScope.selectedGridData = [];
                        }
                    }
                }
                if ($rootScope.IsselectedGrid == false) {
                    $rootScope.selectedGridData = null;
                    $rootScope.selectedGridData = [];
                }
            });
        },
        columnDefs: [

            {
                name: 'mobileNo',
                field: 'ContactNo',
                enableFiltering: false,
				cellTooltip: true
            },
            {
                name: 'date & time',
                field: 'CreatedDate',
				cellTooltip: true,
                cellFilter: 'date:\'dd-MM-yy HH:mm\''
            },
            {
                name: 'status',
				cellTooltip: true,
                field: 'Status'
            }

        ]
    };


    $scope.missedCallgrid2 = {

        multiselect: false,
        modifierKeysToMultiSelect: false,
        noUnselect: true,
        enableRowHeaderSelection: false,
        enableRowSelection: false,
        paginationPageSizes: [10, 20, 30],
        paginationPageSize: 10,
        enableColumnMenus: false,
        enableHorizontalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        enableVerticalScrollbar: 1, // 0- Disable, 1- Enable, 2- Enable when_needed
        // multiSelect: true,
        onRegisterApi: function (gridApi) {
            $scope.gridApi = gridApi;
            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                var msg = 'row selected on single' + row.isSelected;
                console.log(msg);

                if (row.isSelected == true) {
                    $rootScope.IsselectedGrid = true;
                    $rootScope.selectedGridData.push(row.entity.ID);
                } else {
                    $rootScope.IsselectedGrid = false;
                    $rootScope.selectedGridData.splice($rootScope.selectedGridData.indexOf(row.entity.ID), 1);
                }
            });

            gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
                var msg = 'row length:' + row.length;
                console.log(msg);
                if (row.length > 0) {

                    for (index = 0; index < row.length; index++) {
                        console.log(row[index]);
                        if (row[index].isSelected == true) {
                            $rootScope.IsselectedGrid = true;
                            $rootScope.selectedGridData.push(row[index].entity.ID);
                        } else {
                            $rootScope.IsselectedGrid = false;
                            $rootScope.selectedGridData = [];
                        }
                    }
                }
                if ($rootScope.IsselectedGrid == false) {
                    $rootScope.selectedGridData = null;
                    $rootScope.selectedGridData = [];
                }
            });
        },
        columnDefs: [{
                name: 'mobileNo',
                field: 'ContactNo',
				cellTooltip: true,
                enableFiltering: false
            },
            {
                name: 'date & time',
                field: 'CreatedDate',
				cellTooltip: true,
                cellFilter: 'date:\'dd-MM-yy HH:mm\''
            },
            {
                name: 'status',
				cellTooltip: true,
                field: 'Status'
            },
            {
                name: 'agent name',
				cellTooltip: true,
                field: 'AgentName'
            },
            {
                name: 'comments',
				cellTooltip: true,
                field: 'AgentComment'
            }

        ]

    };

    $scope.selectVisible = function() {
        //selectAllVisibleRows(event)  
        //	alert("Visible rows: " + ( $scope.gridApi.core.getVisibleRows( $scope.gridApi.grid)).length);  
                for(var i=0; i< $scope.missedCallgrid.paginationPageSize; i++){   
                    $scope.gridApi.selection.selectRowByVisibleIndex(i);  
                }             
            
        }
    // $scope.resetGridColumn = function () {
    //     if ($scope.ms.statusTerm == "Closed" || $scope.ms.statusTerm == "Assigned" || $scope.ms.statusTerm == "In Progress" ) {
    //         // $scope.missedCallgrid.enableRowSelection = false,
    //         // $scope.missedCallgrid.enableSelectAll = false,
    //         // $scope.missedCallgrid.multiSelect = false,
    //         // $scope.missedCallgrid.enableRowHeaderSelection = false;
    //         // $scope.gridApi.selection.setMultiSelect(!$scope.gridApi.grid.options.multiSelect);
    //         // $scope.missedCallgrid.enableRowSelection = !$scope.gridOptions.enableRowSelection;          

    //         $scope.missedCallgrid.columnDefs = [
    //             { name: 'mobileNo', field: 'ContactNo', enableFiltering: false },
    //             {   
    //                 name: 'date & time', field: 'CreatedDate', cellFilter: 'date:"dd/MM/yyyy HH:mm"'
    //             },
    //             {   
    //                 name: 'status', field: 'Status'
    //             },
    //             {
    //                 name: 'agent name', field: 'AgentName'
    //             },
    //             {
    //                 name: 'comments', field: 'AgentComment'
    //             }

    //         ]
    //     } else {

    //         $scope.missedCallgrid.columnDefs = [

    //             { name: 'mobileNo', field: 'ContactNo', enableFiltering: false },
    //             {
    //                 name: 'date & time', field: 'CreatedDate', cellFilter: 'date:"dd/MM/yyyy HH:mm"'
    //             },
    //             {
    //                 name: 'status', field: 'Status'
    //             }

    //         ]

    //     };

    //     // $scope.missedCallgrid.multiSelect = false;
    //     //     $scope.missedCallgrid.modifierKeysToMultiSelect = false;
    //     //     $scope.missedCallgrid.noUnselect = true;
    // }

    $rootScope.contactRecords = function (status) {
        $scope.misscalldata = null;
        $scope.IsexportDisable = true;
        $scope.ms.statusTerm = "Unassigned";
        // $scope.resetGridColumn();
        var filterData = {
            "MissedCallNo": 'ALL',
            "Status": $scope.ms.statusTerm,
            "FromDate": moment($scope.ms.startDate).add(-7, 'days').format('YYYY-MM-DD HH:mm:ss'),
            "ToDate": moment($scope.ms.endDate).format('YYYY-MM-DD HH:mm:ss'),
        };

        missCall.contact(filterData)
            .then(function (success) {
                $scope.misscalldata = success.data;
                if ($scope.misscalldata != null && $scope.misscalldata.length > 0) {
                    $scope.IsexportDisable = false;
                    $scope.isgridShow = true;
                    $scope.missedCallgrid.data = $scope.misscalldata;
                    $scope.missedCallgrid2.data = $scope.misscalldata;

                } else {
                    $scope.IsexportDisable = true;
                    $scope.isgridShow = true;
                    $scope.misscalldata.length = 0;
                    $scope.missedCallgrid.data = null;
                    $scope.missedCallgrid2.data = null;
                }


                if (($scope.misscalldata != null && $scope.misscalldata.length > 0) && ($scope.ms.statusTerm == 'Unassigned')) {
                    $scope.isDisableUserBtn = false;
                } else {
                    $scope.isDisableUserBtn = true;
                }
            }, function (error) {});
    }


    $scope.contactRecordsSubmit = function () {
        IsValidInputs();
        // $scope.resetGridColumn();
        if ($scope.isValid == true) {
            var filterData = {
                "MissedCallNo": $scope.ms.mobileNum,
                "Status": $scope.ms.statusTerm,
                "FromDate": moment($scope.ms.startDate).format('YYYY-MM-DD HH:mm:ss'),
                "ToDate": moment($scope.ms.endDate).format('YYYY-MM-DD HH:mm:ss'),
                // "DepartmentNumber": $scope.ms.term
                "department": $scope.ms.deptNumber
            };


            if ($scope.ms.mobileNum == "" || $scope.ms.mobileNum == undefined) {
                filterData.MissedCallNo = 'ALL';
            }
            appFactory.ShowLoader();
            missCall.contact(filterData)
                .then(function (success) {
                    appFactory.HideLoader();
                    $scope.misscalldata = success.data;
                    if ($scope.misscalldata != null && $scope.misscalldata.length > 0) {
                        $scope.IsexportDisable = false;
                        $scope.isgridShow = true;
                        $scope.missedCallgrid.data = $scope.misscalldata;
                        $scope.missedCallgrid2.data = $scope.misscalldata;
                    } else {
                        $scope.IsexportDisable = true;
                        $scope.isgridShow = false;
                        $scope.misscalldata.length = 0;
                        $scope.missedCallgrid.data = null;
                        $scope.missedCallgrid2.data = null;
                        toaster.pop({
                            type: "error",
                            body: "No record found",
                        });

                    }

                    if (($scope.misscalldata != null && $scope.misscalldata.length > 0) && ($scope.ms.statusTerm != 'Closed')) {
                        $scope.isDisableUserBtn = false;
                    } else {
                        $scope.isDisableUserBtn = true;
                    }

                }, function (error) {
                    appFactory.HideLoader();
                });
        } else {

            $scope.IsexportDisable = true;
            $scope.misscalldata.length = 0;
            $scope.missedCallgrid.data = null;
            $scope.missedCallgrid2.data = null;
            $scope.isgridShow = false;
        }

    }

    $scope.showAdditionalAddPopup = function () {
        // $scope.Action = 'AddPermission';
        // $scope.EditView = true;
        // $scope.addit = {};
        // $scope.SSOStatus = '';
        // $('#SSOStatus').removeClass();
        // // $scope.UserRoles = [];
        // // $scope.AdditionalPermissionGrid.data = [];
        // $scope.GetPermissionFromProfile();
        $('#additionalPermission').modal('show');
    }




    $scope.downloadCSV = function () {

        if ($scope.IsexportDisable == false) {
            if ($scope.missedCallgrid.data != null && $scope.missedCallgrid.data.length > 0 && $scope.missedCallgrid2.data != null && $scope.missedCallgrid2.data.length > 0) {
                $scope.gridApi.exporter.csvExport(uiGridExporterConstants.VISIBLE, uiGridExporterConstants.ALL);
            }
        }


    };

    $scope.assignUsers = function () {
        $scope.assignedUsers = [];
        var msUsers = $scope.multiselect.selected;
        if (msUsers.length == 0 || msUsers == "") {
            $scope.assignedUsers = null;
            $scope.IsselectedUsers = false;
        }
        for (index = 0; index < msUsers.length; index++) {
            console.log("msUsers", msUsers[index]);
            if (msUsers[index].name != 'ALL') {
                $scope.assignedUsers.push(msUsers[index].name);
                $scope.IsselectedUsers = true;
            }

        }


    }

    // $rootScope.finesseAgents = function () {
    //     missCall.finesseAgents()
    //         .then(function (success) {
    //             $scope.finesseUsers = success.data;

    //             success.data.splice(0, 0, {
    //                 Id: 0,
    //                 AgentName: "ALL",
    //                 AgentID: "ALL",
    //                 Department: ""
    //             });

    //             console.log("data", success.data);

    //             $scope.multiselect.options = success.data.map(function (item) {
    //                 console.log("item", item);
    //                 return {
    //                     name: item.AgentName,
    //                     id: item.Id
    //                 };
    //             });

    //             console.log("$scope.multiselect.options", $scope.multiselect.options);
    //         }, function (error) {
    //             //alert("error");
    //         });
    // }
    // $rootScope.finesseAgents();

    $scope.AssignMCData = function () {

        // $scope.multiselect.options = [];
        // $scope.Departments = [];
        $scope.departmentName();

        if ($rootScope.IsselectedGrid == false) {
            toaster.pop({
                type: "error",
                body: "Please select contacts to assign"
            });
        } else if ($scope.IsselectedUsers == false) {
            toaster.pop({
                type: "error",
                body: "Please select users to assign"
            });
        } else {
            if ($rootScope.selectedGridData != null && $rootScope.selectedGridData.length > 0 &&
                $scope.assignedUsers != null && $scope.assignedUsers.length > 0) {

                if ($scope.selectedGridData.length < $scope.assignedUsers.length) {
                    toaster.pop({
                        type: "error",
                        body: "Selected contacts should not be greater than selected users",
                    });
                } else {
                    var mcData = {
                        "Status": "Assigned",
                        "assignedContacts": $rootScope.selectedGridData,
                        "assignedAgents": $scope.assignedUsers,

                    };

                    missCall.AssignMissedCalls(mcData)
                        .then(function (success) {
                            if (success.data != 0) {
                                toaster.pop({
                                    type: "success",
                                    body: "Selected contacts successfully assigned to selected users",
                                });
                                $scope.multiselect.selected = [];
                                $rootScope.IsselectedGrid = false;
                                $scope.IsselectedUsers = false;
                                $scope.contactRecordsSubmit();
                                //     $rootScope.deptBasedAgents();
                                angular.element('#assignUserModal').modal('hide');
                            }

                        }, function (error) {
                            console.log("error", error);
                            toaster.pop({
                                type: "error",
                                body: "Error while assigning users",

                            });
                            $rootScope.IsselectedGrid = false;
                            $scope.IsselectedUsers = false;

                        });


                }


            }

        }

    }


    // Validations

    // $scope.showModal=function()
    // {
    //     $('#assignUserModal').modal('close');
    //     var data=$rootScope.selectedGridData;
    //     var result=$rootScope.IsselectedGrid ;
    // }// $scope.showModal=function()
    // {
    //     $('#assignUserModal').modal('show');
    //     var data=$rootScope.selectedGridData;
    //     var result=$rootScope.IsselectedGrid ;
    // }

    $scope.showAgentModal = function () {
        $scope.department = '';
        $scope.multiselect.options = [];
        getFinesseAgents();
        $('#assignUserModal').modal('show');
    }

    $scope.formatString = function (format) {
        var day = parseInt(format.substring(0, 2));
        var month = parseInt(format.substring(3, 5));
        var year = parseInt(format.substring(6, 10));
        var date = new Date(year, month - 1, day);
        return date;
    }

    $scope.clearPopup = function () {

        $scope.multiselect = {

            options: [],
            config: {
                hideOnBlur: false,
                showSelected: false,
                itemTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                },
                labelTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                }
            }
        };
        // $rootScope.contactRecords("Unassigned");
        $rootScope.finesseAgents();
    }

    $scope.clearUsers = function () {

        $scope.departmentName();
        $scope.multiselect = {
            selected: [],
            options: [],
            config: {
                hideOnBlur: false,
                showSelected: false,
                itemTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                },
                labelTemplate: function (item) {
                    return $sce.trustAsHtml(item.name);
                }
            }
        };
        // $rootScope.contactRecords("Unassigned");

        // $rootScope.deptBasedAgents();
    }

    $scope.Departments = [];
    $scope.departmentName = function () { 

        missCall.GetAllDepartment().then(
            function success(data) {
                $scope.Departments = data.data;              

                // This is temporary department
                $scope.Departments.splice(0, 0, {
                    DepartmentNumber: -111,
                    DepartmentName: "IVR"
                });
                // $scope.ms.deptNumber = 'ALL';


                $scope.withoutdata = _.findWhere($scope.Departments, {
                    DepartmentName: "Generic"
                })

                $scope.Departments = _.without($scope.Departments, $scope.withoutdata)
            },
            function error(data) {}
        );

    }

    // $scope.deptAgents = [];
    // $rootScope.deptBasedAgents = function (deptInfo) {  
    //     $scope.multiselect.options = [];      
    //     var dept = {
    //         deptId: deptInfo
    //     }
    //     if(!deptInfo){
    //         dept.deptId = '-111'
    //     }     

    //     $scope.deptAgents.splice(0, 0, { Id: 0, AgentName: "SWAMINATHAN.SERVION", AgentID: "SWAMINATHAN.SERVION", Department: "" });


    //     $scope.multiselect.options = $scope.deptAgents.map(function (item) {
    //                     console.log("item", item);
    //                     return {
    //                         name: item.AgentName,
    //                         id: item.Id
    //                     };
    //                 });


    // missCall.getFinesseAgentsByDept(dept.deptId).then(

    //     function success(data) {

    //         $scope.deptAgents = data.data;
    //         $scope.multiselect.options = data.data.map(function (item) {
    //             console.log("item", item);
    //             return {
    //                 name: item.AgentName,
    //                 id: item.Id
    //             };
    //         });

    //         console.log("$scope.multiselect.options", $scope.multiselect.options);

    //     },
    //     function error(data) {}
    // );


    // };


    $scope.GetSSOUserRoles = function (ssoId) {

        var idExist = true;
        if (idExist) {
            profileFactory.GetSSOUserRoles(ssoId).then(
                function success(data) {
                    $scope.setUserRoles(data.data);
                }
            );
        } else if (!idExist) {
            toaster.pop({
                type: "error",
                body: "Agent ID already exist"
            });
        }
    };

    $scope.setUserRoles = function (data) {
        $scope.validflag = false;
        // $scope.validflag = true;
        $scope.UserRoles = [];
        if (data != null && data != undefined && data != 'null') {
            var userDetails = JSON.parse(data);
            $scope.showStatus = true;
            $scope.validflag = true;
            $scope.SSOStatus = 'Valid';
            profileFactory.GetSSOUserRoles(userDetails.sAMAccountName).then(
                function success(data) {
                    var result = data.data;
                    $scope.CreateFinesseAgent(result);
                })

            // $('#AddFinesseAgent').modal('show'); 

        } else {
            $scope.showStatus = true;
            $scope.validflag = false;
            $scope.SSOStatus = 'Invalid';
        }

    }

    $scope.CreateFinesseAgent = function (data) {
        var departmentID =  appFactory.getDepartmentFromRole(data);
        var ssoUser = JSON.parse(data);
         if (ssoUser.departmentId != userObj.departmentId) {
            $scope.validflag = false;
            $scope.SSOStatus = 'Invalid';
            toaster.pop({ type: "error", body: "This user doesn't belong to the selected departement" });
        } else {
        var FinAgentAdd = {
            AgentName: ssoUser.SSOID,
            AgentID: ssoUser.displayName,
            DepartmentName: ssoUser.department,
            DepartmentID: departmentID
        };
        masterDataFactory.CreateFinesseAgent(FinAgentAdd).then(
            function success(data) {
                getFinesseAgents();
            },
            function error(data) {
                toaster.pop({
                    type: "error",
                    body: "Error while Adding Agent"
                });
            }
        );
        }
    }

    var getFinesseAgents = function (depInfo) {
        var deptfilter = [];
        $scope.agentflag = false;
        masterDataFactory.GetFinesseAgent().then(function (success) {
            $scope.finesseUsers = success.data;
            angular.forEach($scope.finesseUsers, function (value, key) {
                if (value.DepartmentId == userObj.departmentId || (appFactory.rights.type === appConst.RIGHTS_TYPES.SUPER_ADMIN)) {
                    deptfilter.push(value);
                    $scope.agentflag = true;
                }
            }, this);
            if ($scope.agentflag = false) {
                deptfilter = success.data;
            }

            success.data.splice(0, 0, {
                Id: 0,
                AgentName: "ALL",
                AgentID: "ALL",
                DepartmentId: "ALL"
            });
            // success.data.splice(0, 0,{ Id: 1, AgentName: "SWAMINATHAN.SERVION", AgentID: "SWAMINATHAN.SERVION", Department: "" });
            $scope.multiselect.options = deptfilter.map(function (item) {
                return {
                    name: item.AgentName,
                    id: item.Id
                };
            });
        }, function (error) {});
    };













    var IsValidInputs = function () {
        $scope.isValid = false;
        var now = new Date();
        var currentDate = new Date(now);
        var startDate = new Date($scope.ms.startDate);
        var endDate = new Date($scope.ms.endDate);

        // var output = (datetwo - dateone) / 1000 / 60 / 60 / 24;
        $scope.currentStDayDiff = Math.round((startDate - currentDate) / 1000 / 60 / 60 / 24);
        $scope.currentEnDayDiff = Math.round((endDate - currentDate) / 1000 / 60 / 60 / 24);
        $scope.stendDayDifference = Math.round((startDate - endDate) / 1000 / 60 / 60 / 24);
        var timediffinseconds = moment(currentDate, "DD/MM/YYYY HH:mm:ss").diff(moment(startDate, "DD/MM/YYYY HH:mm:ss"));

        // var currentDate = moment(now).format('DD/MM/YYYY HH:mm');
        // var startDate = moment($scope.ms.startDate).format('DD/MM/YYYY HH:mm');
        // var endDate = moment($scope.ms.endDate).format('DD/MM/YYYY HH:mm');

        // var curdate = new Date($scope.formatString(currentDate));
        // var stdate = new Date($scope.formatString(startDate));
        // var enddate = new Date($scope.formatString(endDate));


        // var stendtimeDiff = Math.abs(enddate.getTime() - stdate.getTime());
        // $scope.stendDayDifference = Math.ceil(stendtimeDiff / (1000 * 3600 * 24));




        // var curtsttimeDiff = Math.abs(stdate.getTime() - curdate.getTime());
        // $scope.currentStDayDiff = Math.ceil(curtsttimeDiff / (1000 * 3600 * 24));

        // var curtendtimeDiff = Math.abs(enddate.getTime() - curdate.getTime());
        // $scope.currentEnDayDiff = Math.ceil(curtendtimeDiff / (1000 * 3600 * 24));

        if ($scope.ms.statusTerm == undefined || $scope.ms.statusTerm == null) {
            toaster.pop({
                type: "error",
                body: "Select valid status"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.ms.startDate == null && (!moment(startDate, "DD-MM-YY HH:mm", true).isValid())) {
            toaster.pop({
                type: "error",
                body: "Please enter valid Start date time"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.ms.endDate == null && (!moment(endDate, "DD-MM-YY HH:mm", true).isValid())) {
            toaster.pop({
                type: "error",
                body: "Please enter valid End date time"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.currentStDayDiff > 0) {

            toaster.pop({
                type: "error",
                body: "Start date should not be greater than current date"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.currentEnDayDiff > 0) {

            toaster.pop({
                type: "error",
                body: "End date should not be greater than current date"
            });
            $scope.isValid = false;
            return;
        } else if ($scope.stendDayDifference > 0) {

            toaster.pop({
                type: "error",
                body: "Start date should not be greater than end date"
            });
            $scope.isValid = false;
            return;
        }

        $scope.isValid = true;
    }

    $rootScope.contactRecords("Unassigned");
    $scope.departmentName();
}]);