/*
 ServIntuit v2.1
*/
var STRING_NUMBER = "Number";
var STRING_STRING = "String";
var STRING_UPLOAD = "Upload";
var STRING_LIST = "List";
var STRING_TABLE = "Table";
var STRING_NUMBERRANGE = "Numberrange";
var STRING_DATETIME = "Datetime";
var STRING_MEDIA = "Prompt";
var STRING_DATERANGE = "Daterange";
var STRING_BOOLEAN ="Boolean";
var STRING_SERV_ADMIN ="SERV ADMIN";
var STRING_DEV_USER ="DEV USER";
var STRING_DEV_REVIEWER ="DEV REVIEWER";
var STRING_BUSINESS_USER ="BUSINESS USER";
var STRING_BUSINESS_REVIEWER ="BUSINESS REVIEWER";
var STRING_CONFIG_DELIMITER = "~";
var STRING_CURRENT_TAB1 = 'Feature_Master_List';
var STRING_CURRENT_TAB2 = 'menu1';
var Constant_privArray = ['Call_Tree_Creation','BC_Call_Tree_Creation','Feature_Management','BC_Feature_Management','Business_Rule_Management','BC_Business_Rule_Management','Administration','BC_Administration','Feature_Master_List','Create_Feature','Edit_Feature','Feature_Configuration','Create_Global_Data','Global_Data_Configuration','Create_Global_Data','Rules_Master','User_Creation','Audit_Trial','edit_global_config','add_global_config','GC_global_id_comments','RMSubmit','lnk_feature_review','lnk_feature_conf_review','lnk_gData_review','lnk_gConfig_review','ivr_flow_mgmt','bc_ivr_flow_mgmt'];
/* var globalConstants = {isRESupport:true}; */
/*$(document).mousedown(function(e){
          if( e.button == 2 ) {
             alert('Sorry, this functionality is disabled!');
			 //console.log('Sorry, this functionality is disabled!');
             return false;
           } /*else {
             return true;
            }

        });*/
		
/* $(document).ready(function(){

    $(document).bind("contextmenu",function(e){

        return false;

    });
	
	

}); */
function handsOnTable(data,id){			  
	  $('#'+id).handsontable({
			data: data,
			rowHeaders: true,
			colHeaders: true,
			stretchH: 'all',
			minSpareRows: 1,
			contextMenu: true
	  });
	  function bindDumpButton() {
		  $('body').on('click', 'button[name=dump]', function () {
			var dump = $(this).data('dump');
			var $container = $(dump);
			console.log('data of ' + dump, $container.handsontable('getData'));
		  });
		}
	  bindDumpButton();
	}
		
function getBrowser(){
	var nVer = navigator.appVersion;
	var nAgt = navigator.userAgent;
	var browserName  = navigator.appName;
	var fullVersion  = ''+parseFloat(navigator.appVersion); 
	var majorVersion = parseInt(navigator.appVersion,10);
	var nameOffset,verOffset,ix;

	// In Opera, the true version is after "Opera" or after "Version"
	if ((verOffset=nAgt.indexOf("Opera"))!=-1) {
	 browserName = "Opera";
	 fullVersion = nAgt.substring(verOffset+6);
	 if ((verOffset=nAgt.indexOf("Version"))!=-1) 
	   fullVersion = nAgt.substring(verOffset+8);
	}
	// In MSIE, the true version is after "MSIE" in userAgent
	else if ((verOffset=nAgt.indexOf("MSIE"))!=-1) {
	 browserName = "Microsoft Internet Explorer";
	 fullVersion = nAgt.substring(verOffset+5);
	}
	// In Chrome, the true version is after "Chrome" 
	else if ((verOffset=nAgt.indexOf("Chrome"))!=-1) {
	 browserName = "Chrome";
	 fullVersion = nAgt.substring(verOffset+7);
	}
	// In Safari, the true version is after "Safari" or after "Version" 
	else if ((verOffset=nAgt.indexOf("Safari"))!=-1) {
	 browserName = "Safari";
	 fullVersion = nAgt.substring(verOffset+7);
	 if ((verOffset=nAgt.indexOf("Version"))!=-1) 
	   fullVersion = nAgt.substring(verOffset+8);
	}
	// In Firefox, the true version is after "Firefox" 
	else if ((verOffset=nAgt.indexOf("Firefox"))!=-1) {
	 browserName = "Firefox";
	 fullVersion = nAgt.substring(verOffset+8);
	}
	// In most other browsers, "name/version" is at the end of userAgent 
	else if ( (nameOffset=nAgt.lastIndexOf(' ')+1) < 
			  (verOffset=nAgt.lastIndexOf('/')) ) 
	{
	 browserName = nAgt.substring(nameOffset,verOffset);
	 fullVersion = nAgt.substring(verOffset+1);
	 if (browserName.toLowerCase()==browserName.toUpperCase()) {
	  browserName = navigator.appName;
	 }
	}
	// trim the fullVersion string at semicolon/space if present
	if ((ix=fullVersion.indexOf(";"))!=-1)
	   fullVersion=fullVersion.substring(0,ix);
	if ((ix=fullVersion.indexOf(" "))!=-1)
	   fullVersion=fullVersion.substring(0,ix);

	majorVersion = parseInt(''+fullVersion,10);
	if (isNaN(majorVersion)) {
	 fullVersion  = ''+parseFloat(navigator.appVersion); 
	 majorVersion = parseInt(navigator.appVersion,10);
	}
	
	return browserName;
	/*alert(browserName);
	alert(fullVersion);
	alert(majorVersion);
	alert(navigator.appName);
	alert(navigator.userAgent);
	*/
}

function isValidDate(date){
	if(date == "" || date == " " || date == undefined){
		return false;
	}else{
		var arrDate = date.split("/");
		if(arrDate.length>0){
			if(arrDate[0].length != 2 ||  arrDate[1].length != 2 || arrDate[2].length != 4){
				return false;
			}else{
				return true;
			}
		}else{
			return false;
		}
	}
}

function UrlExists(url){
    var http = new XMLHttpRequest();
    http.open('HEAD', url, false);
    http.send();
    return http.status!=404;
}

function isValidLimitation(config_type,value1_from,value1_to,value2_from,value2_to){
	var return_value = true;
	if((config_type == "Number" || config_type == "Numberrange")){		
			if(!$.isNumeric(value1_from) && !$.isNumeric(value1_to)){
				return_value = false;		
			}else if(value1_to < value1_from){						
				return_value = false;						 
			}
		
	}
	if(config_type == "Numberrange"){
		if(!$.isNumeric(value2_from) && !$.isNumeric(value2_to)){
				return_value = false;		
			}else if(value2_to < value2_from){						
				return_value = false;						 
			}
	}
	
	return return_value;
	
}
function parseDate(date){
	if(date == undefined)
		return false;
	var arrDateInfo = date.split("/");
	var dateInfoMap = {'dd':arrDateInfo[0], 'mm' : arrDateInfo[1], 'yyyy' : arrDateInfo[2]};
	return dateInfoMap;	
}
function compareDate(fromDate, toDate){
	var returnValue = " ";
	if(fromDate == undefined || fromDate == "" || fromDate == " " || fromDate == undefined || fromDate == "" || fromDate == " "){
		returnValue = " ";
	}else{
		var arrFromDate = fromDate.split("/");
		var toDate = toDate.split("/");
		for(var i=0; i<arrFromDate.length ; i++){
			if(parseInt(arrFromDate[i]) > parseInt(toDate[i])){
				returnValue = "greater";
			}
		}
	}
	
	return returnValue;
}
function createDateField(id,fromDate, toDate){
	var arrDate = fromDate.split("-");
								var fromDateInfo = parseDate(arrDate[0]);
								var toDateInfo = parseDate(arrDate[1]);
								$('#fDate_'+id).datepick({
									rangeSelect : false,
									minDate: new Date(parseInt(fromDateInfo.yyyy), parseInt(fromDateInfo.mm)-1, parseInt(fromDateInfo.dd)), 
									maxDate: new Date(parseInt(toDateInfo.yyyy), parseInt(toDateInfo.mm)-1, parseInt(toDateInfo.dd)),
									dateFormat : "dd/mm/yyyy",
									closeText : 'Apply',
									onSelect:$('#fDate_'+id).datepick('option', 'minDate', $('#fDate_'+id).val() || null)
								});
								var arrDate1 = toDate.split("-");
								if(compareDate(arrDate[1], arrDate1[0]) != " " && compareDate(arrDate[1], arrDate1[0]) == "greater"){						
									arrDate1[0] = arrDate[0];
									//$('#tDate_'+id).val(arrDate1[0]);
								}
								fromDateInfo = parseDate(arrDate1[0]);
								toDateInfo = parseDate(arrDate1[1]);
								$('#tDate_'+id).datepick({
									rangeSelect : false,
									minDate: new Date(parseInt(fromDateInfo.yyyy), parseInt(fromDateInfo.mm)-1, parseInt(fromDateInfo.dd)), 
									maxDate: new Date(parseInt(toDateInfo.yyyy), parseInt(toDateInfo.mm)-1, parseInt(toDateInfo.dd)),
									dateFormat : "dd/mm/yyyy",
									closeText : 'Apply',
									onSelect:$('#tDate_'+id).datepick('option', 'maxDate', $('#tDate_'+id).val() || null)
								});
}

function value_drim(value){
		if(value == "" || value == " " || value == undefined){
			return "";
		}else{
			var arrValue = value.split("~");
			return arrValue[0];
		}
	  }

function checkOngoingMigration(errorCode, user_id, access_token, app_root_url){
	console.log("Is logout called due to migration? "+$.session.get("logout_due_to_migration"));
	if(errorCode == 412 && $.session.get("logout_due_to_migration") == 'false'){
		logout(user_id,access_token,app_root_url);
	}
}