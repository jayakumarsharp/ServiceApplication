/**
* Common functions
*
*/
(function ($) {

    // Object.keys support for older browsers
    if (!Object.keys) {
        Object.keys = (function () {
            var hasOwnProperty = Object.prototype.hasOwnProperty,
                hasDontEnumBug = !({ toString: null }).propertyIsEnumerable('toString'),
                dontEnums = [
                    'toString',
                    'toLocaleString',
                    'valueOf',
                    'hasOwnProperty',
                    'isPrototypeOf',
                    'propertyIsEnumerable',
                    'constructor'
                ],
                dontEnumsLength = dontEnums.length;

            return function (obj) {
                if (typeof obj !== 'object' && typeof obj !== 'function' || obj === null) throw new TypeError('Object.keys called on non-object');

                var result = [];

                for (var prop in obj) {
                    if (hasOwnProperty.call(obj, prop)) result.push(prop);
                }

                if (hasDontEnumBug) {
                    for (var i = 0; i < dontEnumsLength; i++) {
                        if (hasOwnProperty.call(obj, dontEnums[i])) result.push(dontEnums[i]);
                    }
                }
                return result;
            };
        })();
    }

    if (!Object.clone) {
        Object.clone = function (o) {
            if (typeof o === 'object') {
                return JSON.parse(JSON.stringify(o));
            }
            return o;
        }
    }

    if (!Array.indexOfElement) {
        Array.indexOfElement = function (arr, f) {
            "use strict";

            var len = arr.length;

            if (typeof f !== null && typeof f === 'function') {
                for (var i = 0; i < len; i++) {
                    if (f(i, arr[i])) {
                        return i;
                    }
                }
            }

            return -1;
        }
    }

    // Extend Array Prototype Interface
    Array.prototype.contains = function (f) {
        "use strict";

        var t = Object(this);
        var len = t.length;

        if (typeof f !== null && typeof f === 'function') {
            for (var i = 0; i < len; i++) {
                if (f(i, t[i]) === true) {
                    return true;
                }
            }
        }

        return false;
    }

    Array.prototype.remove = function (f) {
        "use strict";

        if (typeof f !== null && typeof f === 'function') {
            for (var i = this.length - 1; i >= 0; i--) {
                if (f(i, this[i]) === true) {
                    this.splice(i, 1);
                    return true;
                }
            }
        }

        return false;
    }

    Array.prototype.addOrUpdate = function (o, f) {
        "use strict";

        var t = Object(this);
        var len = t.length;

        if (o !== undefined && o !== null && typeof f === 'function') {

            for (var i = 0; i < len; i++) {
                if (f(t[i], o) === true) {
                    t[i] = o;
                    return true;
                }
            }

            t.push(o);
            return true;
        }

        return false;
    }

    // Validation functions
    SV_Validation = {

        isNullOrEmpty: function (data) {
            if (data === undefined || data === null || data === "") {
                return true;
            }
            return false;
        },

        isNotNullOrUndefinedString: function (data) {
            if (data === undefined || data === null || data === '' || data === 'undefined' || data === 'null') {
                return false;
            }
            return true;
        },

        isNotNullOrEmpty: function (data) {
            if (data === undefined || data === null || data === "") {
                return false;
            }
            return true;
        },

        isNotNull: function (data) {
            if (data === undefined || data === null || data === "") {
                return false;
            }
            return true;
        },

        isNullOrEmptyArray: function (data) {
            if (typeof data !== 'object' || !this.isNumber(data.length) || data.length === 0) {
                return true;
            }
            return false;
        },

        isNumber: function (n) {
            return !isNaN(parseFloat(n)) && isFinite(n);
        },

        isValidObject: function (o) {
            return o !== null && typeof o === 'object';
        },

        isValidFunction: function (f) {
            /// <summary>
            /// Checks if the parameter is valid function
            /// </summary>
            /// <param name="f">Object to check</param>
            /// <returns type="bool">true if parameter is function</returns>

            return f !== null && typeof f === 'function';
        },

        isValidEmail: function (data) {
            /// <summary>
            ///Check the string to valid email id format. 
            /// </summary>
            /// <param name="data">String value</param>
            /// <returns type="Boolean">isValidEmail</returns>
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return filter.test(data);
        },

        isValidPhoneNumber: function (data) {
            /// <summary>
            /// Check the given value is an valid inContact phone number format
            /// </summary>
            /// <param name="data"></param>
            /// <returns type=""></returns>
            var filter = /^(\+?)([0-9#\*])+$/;

            if (filter.test(data) && data.length <= 16) {
                return true;
            }
            return false;
        },

        isValidURL: function (url) {
            var validURL = /((?:https?\:\/\/|www\.)(?:[-a-z0-9]+\.)*[-a-z0-9]+.*)/i
            return validURL.test(url);
        }
    };

    // Common utility functions      
    SV_Common = {

        loggers: [],

        generateUniqueId: function (prefix) {
            /// <summary>
            /// This function returns unique id every time it is called. It generates unique id by 
            /// joining input prefix, timeInMillis and random number generator.
            /// </summary>
            /// <param name="prefix">String that needs to be prefixed to the generated unique id</param>
            /// <returns type="String">Returns unique identifier</returns>

            function rand() {
                return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
            }

            return prefix + '_' + rand() + rand() + '-' + rand() + '-' + rand();
        },

        discardElement: function (element) {
            /// <summary>
            /// Destroy UI elments from the page without memory leak in IE browsers
            /// </summary>
            /// <param name="element">UI element</param>

            var garbageBin = document.getElementById('IELeakGarbageBin');
            if (!garbageBin) {
                garbageBin = document.createElement('DIV');
                garbageBin.id = 'IELeakGarbageBin';
                garbageBin.style.display = 'none';
                document.body.appendChild(garbageBin);
            }
            // move the element to the garbage bin
            garbageBin.appendChild(element);
            garbageBin.innerHTML = '';
        },

        secondsToTime: function (seconds) {
            /// <summary>
            /// Converting given seconds to Time format
            /// </summary>
            /// <param name="seconds">value in seconds</param>
            /// <returns type="String">Time String</returns>

            var time = ':00',
                hours, mins, secs;

            if (seconds !== null && seconds !== undefined && typeof seconds === 'number') {

                if (seconds <= 0) {
                    return time;
                }

                hours = Math.floor(seconds / 3600), mins = Math.floor(seconds / 60) % 60, secs = seconds % 60;

                if (hours > 0) {
                    time = hours + ":" + (mins > 9 ? mins : "0" + mins) + ":" + (secs > 9 ? secs : "0" + secs);
                } else if (mins <= 0) {
                    time = ":" + (secs > 9 ? secs : "0" + secs);
                } else {
                    time = mins + ":" + (secs > 9 ? secs : "0" + secs);
                }

                return time;
            } else if (seconds === 0) {
                return time;
            }

            return time;
        },

        toBoolean: function (val) {
            /// <summary>
            /// Converts the string 'true' or 'false' to Boolean. This function is case insensitive.
            /// If the input string is 'true', boolean true will be returned or else boolean false will be returned.
            /// </summary>
            /// <param name="val">string 'true' or 'false'</param>
            /// <returns type="Boolean">Returns true or false</returns>

            return val !== null && val !== undefined && val.toLowerCase() === 'true';
        },

        toNumber: function (val) {
            /// <summary>
            /// Converts the string to number
            /// </summary>
            /// <param name="val">String number</param>
            /// <returns type="Integer">Returns converted value or 0 if NAN</returns>/
            if (val !== null && val !== undefined && isNaN(val) === false) {
                return parseInt(val);
            }
            return 0;
        },

        formQueryString: function (map) {
            var queryString = '',
                key = '';

            for (key in map) {
                if (map.hasOwnProperty(key)) {
                    if (queryString !== '') {
                        queryString += '&';
                    }
                    queryString += key + '=' + encodeURIComponent(map[key]);
                }
            }

            return (queryString === '') ? queryString : '?' + queryString;
        },

        appendQueryString: function (url, map) {
            var queryString = '',
                key = '';

            for (key in map) {
                if (map.hasOwnProperty(key)) {
                    if (queryString !== '') {
                        queryString += '&';
                    }
                    queryString += key + '=' + encodeURIComponent(map[key]);
                }
            }

            if (url.indexOf("?") === -1) {
                url += (queryString === '') ? queryString : '?' + queryString;
            } else {
                url += (queryString === '') ? queryString : '&' + queryString;
            }
            return url;
        },

        dateFromISO: function (s) {
            if ($.browser.msie) {
                s = s.split(/\D/);
                var ms = s[6] || '';
                ms = ms.substring(0, 3);
                return new Date(Date.UTC(s[0], --s[1] || '', s[2] || '', s[3] || '', s[4] || '', s[5] || '', ms));
            } else {
                return s;
            }
        },

        toISODateString: function (d) {
            /// <summary>
            /// Function to format JavaScript object into ISO 8601 Date String for browsers that don't natively support
            /// Date.toISOString() function.
            /// </summary>
            /// <param name="d">Date object</param>
            /// <returns type="String">ISO 8601 formatted date string</returns>

            function pad(n) { return n < 10 ? '0' + n : n }
            return d.getUTCFullYear() + '-'
                + pad(d.getUTCMonth() + 1) + '-'
                + pad(d.getUTCDate()) + 'T'
                + pad(d.getUTCHours()) + ':'
                + pad(d.getUTCMinutes()) + ':'
                + pad(d.getUTCSeconds()) + 'Z';
        },

        timeDiffFromNow: function (epoch) {
            var cur_epoch = parseInt((new Date().getTime() * 0.001).toFixed(0));
            return cur_epoch - epoch;
        },

        timeDiff: function (time1, time2) {
            var time1_sec = parseInt((time1 * 0.001).toFixed(0)),
                time2_sec = parseInt((time2 * 0.001).toFixed(0));
            return time1_sec - time2_sec;
        },

        parseUrl: function (url) {
            var urlDom = document.createElement('a');
            urlDom.href = url;

            return {
                protocol: urlDom.protocol,
                host: urlDom.host,
                hostname: urlDom.hostname,
                port: urlDom.port,
                path: urlDom.pathname,
                search: urlDom.search,
                hash: urlDom.hash
            };
        },

        getCurrentTime: function () {
            var today,
                hrs, mts, secs,
                ampm, curTime;

            today = new Date();
            hrs = today.getHours();
            mts = today.getMinutes();
            secs = today.getSeconds();
            ampm = hrs >= 12 ? 'pm' : 'am';
            hrs = hrs % 12;
            hrs = hrs ? hrs : 12; // the hour '0' should be '12'
            mts = mts < 10 ? '0' + mts : mts;
            curTime = hrs + ':' + mts + ' ' + ampm;
            return curTime;
        },

        getMonday: function (date) {
            /// <summary>
            /// Gets the Date of monday for the week of date passed-in
            /// </summary>
            /// <param name="date">Any date of the week for that monday to be calculated</param>
            /// <returns type="">Date object of Monday</returns>

            date = date || new Date();
            var day = date.getDay(),
                diff = date.getDate() - day + (day == 0 ? -6 : 1);
            return new Date(date.setDate(diff));
        },

        toShortDateString: function (date) {
            /// <summary>
            /// Converts the date object into MM/DD/YYYY format string
            /// </summary>
            /// <param name="date">Date string in MM/DD/YYYY format</param>

            date = date || new Date();
            var pattern = 'MM/dd/yyyy';

            return pattern.replace('yyyy', date.getFullYear())
                .replace('dd', IC_Common.twoDigitText(date.getDate()))
                .replace('MM', IC_Common.twoDigitText(date.getMonth() + 1));

        },

        toDateTimeString: function (date) {
            /// <summary>
            /// Converts the DateTime object into MM/DD/YYYY hh:mm AM/PM format string
            /// </summary>
            /// <param name="date">DateTime formatted string</param>

            date = date || new Date();
            var pattern = 'hh:mm tt',
                HH = date.getHours(),
                mm = date.getMinutes(),
                ampm = HH > 11 ? 'PM' : 'AM',
                hh = HH % 12;
            hh = hh ? hh : 12;

            return IC_Common.toShortDateString(date) + ' ' +
                pattern.replace('hh', IC_Common.twoDigitText(hh))
                    .replace('mm', IC_Common.twoDigitText(mm))
                    .replace('tt', ampm);
        },

        isIE: function () {
            return navigator.appName === 'Microsoft Internet Explorer';
        },

        isIE8: function () {
            return jQuery.browser.msie && jQuery.browser.version == '8.0';
        },

        isIE9: function () {
            return jQuery.browser.msie && jQuery.browser.version == '9.0';
        },

        isIE10: function () {
            return jQuery.browser.msie && jQuery.browser.version == '10.0';
        },

        isIE8or9: function () {
            return this.isIE8() || this.isIE9();
        }
    }

    $(document).on('click', ".erorAlertHide", function () {
        $(this).parent().hide();
    });

}(jQuery));

// $(function () {
//     $(window).resize(function () {
//         $('#mainContainer, #tabs-createCallFlow').height($(window).height() - 50);
//         $('#tabs').height($(window).height() - 70);
//         $('.calltreeContainer').height($(window).height() - 100);
//         $('#CTRlAsgn').height($(window).height() - 190);
//         $('#featureConfig, .ruleConfig').height($(window).height() - 190);
//         $('#modulesContainer').height('100px !important'); //$(window).height()-

//     });
//     $(window).trigger('resize');
// });
